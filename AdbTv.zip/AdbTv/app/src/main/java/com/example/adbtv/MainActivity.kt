package com.example.adbtv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private val options = intArrayOf(0, 1, 5, 15, 30, 60)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var statusView: TextView
    private lateinit var intervalBtn: Button
    private lateinit var watchBtn: Button

    private val refresh = object : Runnable {
        override fun run() {
            statusView.text = AdbService.status
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        statusView = TextView(this).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 48)
        }
        val runBtn = Button(this).apply {
            text = "İndi icra et"
            setOnClickListener { sendToService(Intent(AdbService.ACTION_RUN)) }
        }
        intervalBtn = Button(this).apply {
            setOnClickListener { cycleInterval() }
        }

        watchBtn = Button(this).apply {
            setOnClickListener {
                val on = !prefs().getBoolean(AdbService.KEY_WATCH, true)
                prefs().edit().putBoolean(AdbService.KEY_WATCH, on).apply()
                updateWatchLabel()
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(64, 64, 64, 64)
            addView(statusView)
            addView(runBtn)
            addView(intervalBtn)
            addView(watchBtn)
        })
        runBtn.requestFocus()
        updateIntervalLabel()
        updateWatchLabel()

        startForegroundService(Intent(this, AdbService::class.java))
    }

    private fun sendToService(intent: Intent) {
        intent.setClass(this, AdbService::class.java)
        startForegroundService(intent)
    }

    private fun prefs() = getSharedPreferences(AdbService.PREFS, MODE_PRIVATE)

    private fun cycleInterval() {
        val cur = prefs().getInt(AdbService.KEY_INTERVAL, AdbService.DEFAULT_INTERVAL)
        val next = options[(options.indexOf(cur) + 1) % options.size]
        prefs().edit().putInt(AdbService.KEY_INTERVAL, next).apply()
        updateIntervalLabel()
    }

    private fun updateIntervalLabel() {
        val m = prefs().getInt(AdbService.KEY_INTERVAL, AdbService.DEFAULT_INTERVAL)
        intervalBtn.text = if (m == 0) "Təkrar: söndürülüb" else "Təkrar: hər $m dəq."
    }

    private fun updateWatchLabel() {
        val on = prefs().getBoolean(AdbService.KEY_WATCH, true)
        watchBtn.text = if (on) "Key Mapper nəzarəti: aktiv" else "Key Mapper nəzarəti: söndürülüb"
    }

    override fun onResume() { super.onResume(); handler.post(refresh) }
    override fun onPause() { handler.removeCallbacks(refresh); super.onPause() }

}
