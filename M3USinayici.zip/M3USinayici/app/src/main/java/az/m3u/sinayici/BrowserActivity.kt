package az.m3u.sinayici

import android.app.DownloadManager
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import kotlin.concurrent.thread

/** Qaranlıq mövzulu daxili brauzer. Endirilən .m3u/.m3u8 → avtomatik 1-ci playlist + test. */
class BrowserActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var urlBox: EditText
    private lateinit var progress: ProgressBar
    private val home = "https://www.google.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        web = findViewById(R.id.web)
        urlBox = findViewById(R.id.urlBox)
        progress = findViewById(R.id.progress)

        web.setBackgroundColor(0xFF0F141B.toInt())
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = false
        }
        applyDarkTheme()
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.setDownloadListener { url, ua, cd, mime, _ -> onDownload(url, ua, cd, mime) }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val scheme = u.scheme ?: ""
                if (scheme != "http" && scheme != "https") return true
                val path = (u.path ?: "").lowercase()
                if (path.endsWith(".m3u") || path.endsWith(".m3u8")) {
                    importPlaylist(u.toString(), URLUtil.guessFileName(u.toString(), null, null), view.settings.userAgentString)
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                if (url != null && !urlBox.hasFocus()) urlBox.setText(url)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        findViewById<View>(R.id.btnBack).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.btnFwd).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.btnReload).setOnClickListener { web.reload() }
        findViewById<View>(R.id.btnHome).setOnClickListener { web.loadUrl(home) }
        findViewById<View>(R.id.btnDone).setOnClickListener { finish() }

        urlBox.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                go(urlBox.text.toString())
                urlBox.clearFocus()
                true
            } else false
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        val start = intent.getStringExtra("url")
        go(if (start.isNullOrBlank()) home else start)
    }

    @Suppress("DEPRECATION")
    private fun applyDarkTheme() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, true)
            }
        } else {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(web.settings, WebSettingsCompat.FORCE_DARK_ON)
                if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK_STRATEGY)) {
                    WebSettingsCompat.setForceDarkStrategy(
                        web.settings, WebSettingsCompat.DARK_STRATEGY_USER_AGENT_DARKENING_ONLY
                    )
                }
            }
        }
    }

    private fun go(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(url)
    }

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun onDownload(url: String, ua: String?, cd: String?, mime: String?) {
        val name = URLUtil.guessFileName(url, cd, mime)
        val low = url.lowercase().substringBefore('?')
        val isM3u = low.endsWith(".m3u") || low.endsWith(".m3u8") ||
            name.lowercase().let { it.endsWith(".m3u") || it.endsWith(".m3u8") } ||
            (mime ?: "").lowercase().contains("mpegurl")
        if (isM3u) {
            importPlaylist(url, name, ua)
            return
        }
        try {
            val req = DownloadManager.Request(Uri.parse(url))
                .setMimeType(mime)
                .addRequestHeader("User-Agent", ua ?: Net.UA)
                .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Endirmə başladı: $name")
        } catch (e: Exception) {
            toast("Endirmək olmadı: ${e.message}")
        }
    }

    private fun importPlaylist(url: String, name: String, ua: String?) {
        if (!url.startsWith("http")) {
            toast("Bu növ link dəstəklənmir (blob/data). Birbaşa .m3u linkindən istifadə edin.")
            return
        }
        toast("⏳ Playlist endirilir...")
        val cookie = CookieManager.getInstance().getCookie(url)
        thread {
            try {
                val text = Net.fetchText(url, ua, cookie)
                when {
                    Net.isStreamPlaylist(text) -> runOnUiThread {
                        startActivity(
                            Intent(this, PlayerActivity::class.java)
                                .putExtra("name", name)
                                .putExtra("urls", org.json.JSONArray().put(url).toString())
                        )
                    }
                    Net.looksLikePlaylist(text) -> {
                        Store.saveFirst(this, name, text)
                        val n = Net.countChannels(text)
                        runOnUiThread {
                            Toast.makeText(this, "✔ $n kanal 1-ci Playlistə əlavə olundu, test başlayır", Toast.LENGTH_LONG).show()
                            finish()
                        }
                    }
                    else -> toast("Bu fayl M3U siyahısı deyil")
                }
            } catch (e: Exception) {
                toast("Endirmə xətası: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
