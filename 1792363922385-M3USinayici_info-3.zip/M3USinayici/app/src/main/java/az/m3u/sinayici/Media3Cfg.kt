package az.m3u.sinayici

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory

/** Player panelindəki Media3 (ExoPlayer) üçün ortaq, canlı IPTV yayımına uyğunlaşdırılmış ayarlar. */
object Media3Cfg {
    /** Qüsurlu IPTV TS axınları üçün: keyframe-siz başlanğıc və giriş vahidlərinin aşkarlanması. */
    val TS_FLAGS = DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
        DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS

    /** Tez start (1 san), rebufer-dən sonra 3 san, sabit yaddaş: köhnə bufer saxlanmır (canlı yayımda lazım deyil). */
    fun loadControl(): DefaultLoadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(15_000, 50_000, 1_000, 3_000)
        .setPrioritizeTimeOverSizeThresholds(true)
        .setBackBuffer(0, false)
        .build()

    /** Dekoder açılmasa ehtiyat (proqram) dekoderə keçir. */
    fun renderers(ctx: Context): DefaultRenderersFactory = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)

    /** Altyazı izləri söndürülür (lazımsız yük); qarışıq MIME adaptivliyinə icazə verilir. */
    fun trackSelector(ctx: Context): DefaultTrackSelector {
        val ts = DefaultTrackSelector(ctx)
        val b = ts.buildUponParameters()
        b.setAllowVideoMixedMimeTypeAdaptiveness(true)
        b.setAllowAudioMixedMimeTypeAdaptiveness(true)
        b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        ts.setParameters(b.build())
        return ts
    }

    /** Səs fokusu: başqa tətbiq səs çıxaranda dayanır; qulaqlıq çıxanda avtomatik pauza. */
    fun audio(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA)
        .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
        .build()

    fun mediaSourceFactory(ds: DataSource.Factory): DefaultMediaSourceFactory =
        DefaultMediaSourceFactory(ds, DefaultExtractorsFactory().setTsExtractorFlags(TS_FLAGS).setConstantBitrateSeekingEnabled(true))

    /** HLS: TS bayraqları və seqmentsiz (chunkless) hazırlıq — kanal daha tez açılır. */
    fun hlsSource(ds: DataSource.Factory, item: MediaItem): MediaSource =
        HlsMediaSource.Factory(ds)
            .setExtractorFactory(DefaultHlsExtractorFactory(TS_FLAGS, false))
            .setAllowChunklessPreparation(true)
            .createMediaSource(item)

    /** Keçici xəta: eyni profil bir neçə dəfə təkrar sınanır, dərhal növbəti profilə keçilmir. */
    fun transient(code: Int): Boolean =
        code == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
        code == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ||
        code == PlaybackException.ERROR_CODE_IO_UNSPECIFIED ||
        code == PlaybackException.ERROR_CODE_TIMEOUT ||
        code == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
        code == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED

    private val kindCache = java.util.concurrent.ConcurrentHashMap<String, Int>()

    /** Şəbəkəsiz, ani növ: uzantıdan və ya əvvəl aşkarlanmış nəticədən; bilinmirsə 0 (avto). Kanal dəyişəndə açılışı yubatmır. */
    fun fastKind(t: Net.Target): Int {
        val path = try { Uri.parse(t.url).path?.lowercase() ?: "" } catch (e: Exception) { "" }
        if (path.endsWith(".m3u8") || path.endsWith(".m3u")) return 1
        if (path.endsWith(".mpd")) return 2
        return kindCache[t.url] ?: 0
    }

    /** Yayım növü: 0 avto/TS/progressiv, 1 HLS, 2 DASH (yönləndirici linklərdə SON ünvana və məzmuna görə). */
    fun kindOf(t: Net.Target): Int {
        val path = try { Uri.parse(t.url).path?.lowercase() ?: "" } catch (e: Exception) { "" }
        if (path.endsWith(".m3u8") || path.endsWith(".m3u")) return 1
        if (path.endsWith(".mpd")) return 2
        val k = Net.sniffKind(t)
        kindCache[t.url] = k
        return k
    }
}
