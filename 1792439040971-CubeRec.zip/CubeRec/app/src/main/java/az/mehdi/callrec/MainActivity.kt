package az.mehdi.callrec

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val ad = Ad()
    private var mp: MediaPlayer? = null
    private var playingPath: String? = null
    private var curSeek: SeekBar? = null
    private var curTime: TextView? = null
    private val h = Handler(Looper.getMainLooper())
    private val df = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

    private val tick = object : Runnable {
        override fun run() {
            val m = mp; val s = curSeek
            if (m != null && s != null && s.tag == playingPath) {
                s.progress = m.currentPosition
                curTime?.text = fmt(m.currentPosition) + "/" + fmt(m.duration)
            }
            h.postDelayed(this, 500)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        val lv = findViewById<ListView>(R.id.list)
        lv.adapter = ad
        lv.emptyView = findViewById(R.id.empty)
        lv.setOnItemLongClickListener { _, _, p, _ ->
            val r = ad.items[p]
            AlertDialog.Builder(this).setTitle("Silinsin?")
                .setPositiveButton("Sil") { _, _ ->
                    if (playingPath == r.file) stopPlay()
                    File(r.file).delete(); Store.remove(this, r.file); reload()
                }.setNegativeButton("Ləğv", null).show()
            true
        }
        findViewById<Button>(R.id.setup).setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }
        val need = perms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
        h.post(tick)
    }

    private fun perms(): List<String> {
        val l = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        startSvc(); refresh()
    }

    override fun onResume() {
        super.onResume()
        RecService.onChange = { runOnUiThread { reload() } }
        startSvc(); reload()
        h.postDelayed({ refresh() }, 700)
    }

    override fun onPause() { RecService.onChange = null; super.onPause() }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); stopPlay(); super.onDestroy() }

    private fun startSvc() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            try { startForegroundService(Intent(this, RecService::class.java)) } catch (e: Exception) { }
        }
    }

    private fun refresh() {
        val acc = Settings.Secure.getString(contentResolver, "enabled_accessibility_services")
            ?.contains(packageName) == true
        findViewById<TextView>(R.id.status).text =
            "Xidmət: " + (if (RecService.inst != null) "✅" else "❌") +
            "    WhatsApp izləmə: " + (if (acc) "✅" else "❌ (ADB düyməsindən aktiv et)")
    }

    private fun reload() {
        ad.items = Store.all(this).filter { File(it.file).exists() }
        ad.notifyDataSetChanged()
    }

    private fun fmt(ms: Int): String { val s = ms / 1000; return "%02d:%02d".format(s / 60, s % 60) }

    private fun stopPlay() {
        try { mp?.release() } catch (e: Exception) { }
        mp = null; playingPath = null
        ad.notifyDataSetChanged()
    }

    private fun toggle(r: Rec, seek: SeekBar, btn: ImageButton, tm: TextView) {
        val m = mp
        if (m != null && playingPath == r.file) {
            if (m.isPlaying) { m.pause(); btn.setImageResource(R.drawable.ic_play) }
            else { m.start(); btn.setImageResource(R.drawable.ic_pause) }
            return
        }
        stopPlay()
        try {
            val p = MediaPlayer()
            p.setDataSource(r.file); p.prepare(); p.start()
            p.setOnCompletionListener { stopPlay() }
            mp = p; playingPath = r.file; curSeek = seek; curTime = tm
            seek.max = p.duration
            btn.setImageResource(R.drawable.ic_pause)
        } catch (e: Exception) {
            Toast.makeText(this, "Fayl açılmadı", Toast.LENGTH_SHORT).show()
        }
    }

    inner class Ad : BaseAdapter() {
        var items: List<Rec> = emptyList()
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val v = cv ?: layoutInflater.inflate(R.layout.item_rec, parent, false)
            val r = items[p]
            val ic = v.findViewById<ImageView>(R.id.ic)
            ic.setImageResource(if (r.incoming) R.drawable.ic_in else R.drawable.ic_out)
            ic.backgroundTintList = ColorStateList.valueOf(if (r.incoming) 0xFF2E7D32.toInt() else 0xFF1565C0.toInt())
            v.findViewById<TextView>(R.id.title).text = r.number.ifEmpty { "Naməlum" }
            val app = v.findViewById<TextView>(R.id.app)
            app.text = if (r.app == "WhatsApp") "WhatsApp" else "Phone"
            app.backgroundTintList = ColorStateList.valueOf(if (r.app == "WhatsApp") 0xFFC8E6C9.toInt() else 0xFFBBDEFB.toInt())
            v.findViewById<TextView>(R.id.sub).text =
                (if (r.incoming) "Gələn · " else "Gedən · ") + df.format(Date(r.time))
            val seek = v.findViewById<SeekBar>(R.id.seek)
            val btn = v.findViewById<ImageButton>(R.id.btn)
            val tm = v.findViewById<TextView>(R.id.tm)
            seek.tag = r.file
            val m = mp
            val playing = m != null && playingPath == r.file
            seek.max = if (playing) m!!.duration else maxOf(r.dur.toInt(), 1)
            seek.progress = if (playing) m!!.currentPosition else 0
            btn.setImageResource(if (playing && m!!.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            tm.text = if (playing) fmt(m!!.currentPosition) + "/" + fmt(m.duration) else fmt(r.dur.toInt())
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, pr: Int, u: Boolean) {
                    if (u && playingPath == r.file) mp?.seekTo(pr)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
            btn.setOnClickListener { toggle(r, seek, btn, tm) }
            return v
        }
    }
}
