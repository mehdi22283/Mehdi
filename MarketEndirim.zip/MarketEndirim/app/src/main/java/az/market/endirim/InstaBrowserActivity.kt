package az.market.endirim

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import coil.load
import org.json.JSONArray
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Mini brauzer: bütün marketlərin Instagram səhifələri.
 *  - Canlı rejim: giriş bir dəfə edilir (cookie yadda qalır).
 *  - Giriş olunandan sonra hər marketin SON 3 POSTU (şəkillər + yazı + tarix) telefona saxlanır.
 *  - "Saxlanmışlar" rejimi (internet olmayanda avtomatik): saxlanmış postlar offline açılır.
 *  - Sağa/sola sürüşdürmə (canlı rejimdə): digər marketə keçid.
 */
class InstaBrowserActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var holder: FrameLayout
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var btnSave: Button
    private lateinit var btnMode: Button
    private lateinit var savedScroll: ScrollView
    private lateinit var savedBox: LinearLayout
    private val tabs = ArrayList<Button>()
    private val users: List<Pair<String, String>> = Insta.users()
    private var current = 0

    private var savedMode = false
    private var syncing = false
    private var forceSync = false
    private var needLogin = true
    private var lastSyncAt = 0L
    private var jsDone = false
    private var pending = 0
    private var savedMarkets = 0

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    /** Üfüqi sürüşdürməni tutur (uşaq görünüşlər toxunuşu öz qaydasında işləməyə davam edir). */
    private inner class SwipeFrame(c: Context) : FrameLayout(c) {
        private var downX = 0f
        private var downY = 0f
        private var multi = false

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            val r = super.dispatchTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = ev.x; downY = ev.y; multi = false }
                MotionEvent.ACTION_POINTER_DOWN -> multi = true
                MotionEvent.ACTION_UP -> {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (!multi && Math.abs(dx) > dp(90) && Math.abs(dx) > Math.abs(dy) * 2) {
                        val next = if (dx < 0) current + 1 else current - 1
                        if (next in users.indices) open(next)
                    }
                }
            }
            return r
        }
    }

    /** Səhifədəki JS-dən çağırılır (yalnız Instagram səhifəsi yüklənir; giriş məlumatı Kotlin-ə gəlmir). */
    private inner class Bridge {
        @JavascriptInterface
        fun posts(user: String, json: String) {
            val market = users.firstOrNull { it.second == user }?.first ?: return
            runOnUiThread { pending++ }
            InstaSaved.save(applicationContext, market, json) { n ->
                runOnUiThread {
                    pending--
                    if (n > 0) savedMarkets++
                    if (savedMode && users[current].first == market) showSaved()
                    checkDone()
                }
            }
        }

        @JavascriptInterface
        fun fail(user: String, why: String) {
        }

        @JavascriptInterface
        fun finished(login: Boolean) {
            runOnUiThread {
                jsDone = true
                needLogin = login
                if (!login) lastSyncAt = System.currentTimeMillis()
                checkDone()
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brand.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
        }
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        users.forEachIndexed { i, (market, _) ->
            val b = Button(this, null, 0, com.google.android.material.R.style.Widget_MaterialComponents_Button_TextButton).apply {
                text = market
                isAllCaps = false
                setOnClickListener { open(i) }
            }
            tabs.add(b)
            tabRow.addView(b)
        }
        tabScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabRow)
        }
        root.addView(tabScroll)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), 0, dp(8), 0)
        }
        btnSave = Button(this, null, 0, com.google.android.material.R.style.Widget_MaterialComponents_Button_OutlinedButton).apply {
            text = "💾 Yadda saxla"
            isAllCaps = false
            setOnClickListener {
                forceSync = true
                if (savedMode && Store.online(this@InstaBrowserActivity)) setMode(false) else syncNow(true)
            }
        }
        btnMode = Button(this, null, 0, com.google.android.material.R.style.Widget_MaterialComponents_Button_OutlinedButton).apply {
            text = "📂 Saxlanmışlar"
            isAllCaps = false
            setOnClickListener { setMode(!savedMode) }
        }
        actions.addView(btnSave, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        actions.addView(btnMode, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(actions)

        status = TextView(this).apply {
            textSize = 13f
            setPadding(dp(16), 0, dp(16), dp(4))
        }
        root.addView(status)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        web = WebView(this)
        holder = SwipeFrame(this)
        holder.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(holder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        savedBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(24))
        }
        savedScroll = ScrollView(this).apply {
            visibility = View.GONE
            addView(savedBox)
        }
        root.addView(savedScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            userAgentString = Insta.UA
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.addJavascriptInterface(Bridge(), "AndroidInsta")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val sc = request.url.scheme
                return sc != "http" && sc != "https"
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                // səhifə dəyişibsə, yarımçıq JS dayanıb — növbəti dəfə yenidən cəhd olunsun
                if (syncing && !jsDone) syncing = false
            }

            override fun onPageFinished(view: WebView, url: String?) {
                progress.visibility = View.GONE
                if (savedMode || syncing || url == null || !url.contains("instagram.com")) return
                // giriş olunandan sonra (və ya vaxtı keçəndə) postlar avtomatik saxlanır
                if (forceSync || needLogin || System.currentTimeMillis() - lastSyncAt > 5 * 60_000L) syncNow(false)
            }
        }
        web.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!savedMode && web.visibility == View.VISIBLE && web.canGoBack()) web.goBack() else finish()
            }
        })
        val start = users.indexOfFirst { it.first == intent.getStringExtra("market") }.coerceAtLeast(0)
        open(start)
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    private fun highlight(i: Int) {
        current = i
        tabs.forEachIndexed { k, b ->
            b.alpha = if (k == i) 1f else 0.55f
            b.setTypeface(null, if (k == i) Typeface.BOLD else Typeface.NORMAL)
            if (k == i) b.setTextColor(Brand.colorOf(users[k].first))
        }
        tabScroll.post { tabScroll.smoothScrollTo((tabs[i].left - dp(48)).coerceAtLeast(0), 0) }
    }

    private fun applyMode() {
        holder.visibility = if (savedMode) View.GONE else View.VISIBLE
        savedScroll.visibility = if (savedMode) View.VISIBLE else View.GONE
        btnMode.text = if (savedMode) "🌐 Canlı" else "📂 Saxlanmışlar"
    }

    private fun setMode(saved: Boolean) {
        savedMode = saved
        applyMode()
        open(current)
    }

    private fun open(i: Int) {
        highlight(i)
        if (!savedMode && !Store.online(this)) {
            savedMode = true
            applyMode()
        }
        if (savedMode) {
            showSaved()
            return
        }
        web.visibility = View.VISIBLE
        web.loadUrl("https://www.instagram.com/${users[i].second}/")
        if (!syncing) status.text = "Canlı"
    }

    // ---------------------------------------------------------------- saxlama

    private fun syncNow(manual: Boolean) {
        if (syncing) return
        if (!Store.online(this)) {
            status.text = "İnternet yoxdur"
            return
        }
        val u = web.url ?: ""
        if (!u.contains("instagram.com")) {
            if (manual) status.text = "Əvvəl Instagram səhifəsinin açılmasını gözləyin"
            return
        }
        forceSync = false
        syncing = true
        jsDone = false
        pending = 0
        savedMarkets = 0
        status.text = "Postlar yadda saxlanılır…"
        val js = SYNC_JS.replace("%USERS%", JSONArray(users.map { it.second }).toString())
        web.evaluateJavascript(js, null)
    }

    private fun checkDone() {
        if (!syncing || !jsDone || pending > 0) return
        syncing = false
        status.text = if (needLogin && savedMarkets == 0) {
            "Instagram hesabınıza daxil olun — postlar avtomatik saxlanacaq"
        } else {
            "✔ $savedMarkets market üçün son ${InstaSaved.KEEP} post saxlandı"
        }
        if (savedMode) showSaved()
    }

    private fun fmt(pattern: String, millis: Long) = SimpleDateFormat(pattern, Locale.getDefault()).format(Date(millis))

    private fun showSaved() {
        val market = users[current].first
        val posts = InstaSaved.load(this, market)
        val at = InstaSaved.lastSync(this, market)
        if (!syncing) {
            status.text = (if (Store.online(this)) "Saxlanmış postlar" else "Offline — saxlanmış postlar") +
                (if (at > 0) " • yenilənib: " + fmt("dd.MM HH:mm", at) else "")
        }
        savedBox.removeAllViews()
        if (posts.isEmpty()) {
            savedBox.addView(TextView(this).apply {
                textSize = 15f
                setPadding(dp(4), dp(24), dp(4), dp(4))
                text = "$market üçün hələ saxlanmış post yoxdur.\n\nİnternet olanda «🌐 Canlı» rejimində Instagram hesabınıza daxil olun — son ${InstaSaved.KEEP} post avtomatik saxlanacaq."
            })
            return
        }
        val dir = InstaSaved.dirOf(this, market)
        for (p in posts) {
            val urls = p.files.map { Uri.fromFile(File(dir, it)).toString() }
            val head = fmt("dd.MM.yyyy HH:mm", p.ts * 1000) +
                (if (p.files.size > 1) "  •  ${p.files.size} şəkil" else "") +
                (if (p.video) "  •  🎬 video (yalnız üz qabığı saxlanıb)" else "")
            savedBox.addView(TextView(this).apply {
                text = head
                textSize = 13f
                setTypeface(null, Typeface.BOLD)
                setPadding(0, dp(14), 0, dp(6))
            })
            savedBox.addView(ImageView(this).apply {
                adjustViewBounds = true
                maxHeight = dp(460)
                scaleType = ImageView.ScaleType.FIT_CENTER
                load(urls[0])
                setOnClickListener {
                    startActivity(
                        Intent(this@InstaBrowserActivity, ViewerActivity::class.java)
                            .putExtra("catalog", Catalog(market, "Instagram", null, Kind.IMAGES, urls))
                    )
                }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            if (p.caption.isNotBlank()) {
                savedBox.addView(TextView(this).apply {
                    text = p.caption
                    textSize = 14f
                    setTextIsSelectable(true)
                    setPadding(0, dp(6), 0, 0)
                })
            }
        }
    }

    private companion object {
        /**
         * Instagram səhifəsinin içində işləyir (eyni mənşə, giriş cookie-si ilə):
         * hər market üçün profil məlumatını çəkir, ən yeni postları bu tətbiqə ötürür.
         * Giriş yoxdursa (401/403) dayanır.
         */
        const val SYNC_JS = """
(async function(){
  var users=%USERS%;
  var need=false;
  for(var k=0;k<users.length;k++){
    var u=users[k];
    try{
      var r=await fetch('/api/v1/users/web_profile_info/?username='+encodeURIComponent(u),
        {credentials:'include',headers:{'X-IG-App-ID':'936619743392459','X-Requested-With':'XMLHttpRequest'}});
      if(r.status==401||r.status==403||r.status==400){need=true;AndroidInsta.fail(u,'HTTP '+r.status);break;}
      if(!r.ok){AndroidInsta.fail(u,'HTTP '+r.status);continue;}
      var j=await r.json();
      var es=j.data.user.edge_owner_to_timeline_media.edges;
      var out=[];
      for(var i=0;i<es.length;i++){
        var n=es[i].node,urls=[];
        var ch=n.edge_sidecar_to_children;
        if(ch&&ch.edges&&ch.edges.length){
          for(var c=0;c<ch.edges.length&&c<10;c++)urls.push(ch.edges[c].node.display_url);
        }else{urls.push(n.display_url);}
        var cap=(n.edge_media_to_caption&&n.edge_media_to_caption.edges.length)?n.edge_media_to_caption.edges[0].node.text:'';
        out.push({c:n.shortcode,t:n.taken_at_timestamp,x:cap,v:!!n.is_video,u:urls});
      }
      AndroidInsta.posts(u,JSON.stringify(out));
    }catch(e){need=true;AndroidInsta.fail(u,String(e));break;}
    await new Promise(function(res){setTimeout(res,800);});
  }
  AndroidInsta.finished(need);
})();
"""
    }
}
