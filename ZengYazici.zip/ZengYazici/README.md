# Zəng Yazıcı (Shizuku-suz, tam avtomatik)

Tətbiq özü Wireless ADB müştərisidir (libadb-android). Özünə qoşulub bütün icazələri verir, əlçatanlıq xidmətini yandırır, batareya məhdudiyyətini götürür və xidməti başladır.

## İstifadə
1. GitHub-a yükləyin → Actions → "Build APK" → APK-nı quraşdırın.
2. Developer options → **Wireless debugging** yandırın (Wi-Fi-a qoşulu olun).
3. Tətbiqdə **"Avtomatik quraşdır"** basın. İcazələri verin.
4. "Pair device with pairing code" pəncərəsini açın → bildirişdəki **"Kodu yaz"** düyməsinə 6 rəqəmli kodu yazın.
5. Bitdi. Sonrakı açılışlarda tətbiq özü Wireless debugging-i yandırıb qoşulur və xidməti başladır.

Yazılar: `Music/ZengYazici`.

## Məhdudiyyətlər
- Cütləşmə (kod daxil etmə) ilk dəfə mütləq istifadəçi tərəfindən edilməlidir, Android bunu avtomatlaşdırmağa icazə vermir.
- Wireless debugging yalnız Wi-Fi qoşulu olanda işləyir.
- Android 10+ zəng səsini (VOICE_CALL) adi/shell tətbiqlərə vermir; mikrofon rejimində qarşı tərəf üçün dinamik açıq olmalıdır.
- libadb-android JitPack-dan `master-SNAPSHOT` kimi çəkilir; build alınmazsa, JitPack-da son tag versiyasını yazın.
