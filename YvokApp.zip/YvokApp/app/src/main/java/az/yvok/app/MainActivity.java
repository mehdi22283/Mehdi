package az.yvok.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String EBEL_URL = "https://e-belediyye.gov.az/tax-debts";
    private static final Pattern CODE = Pattern.compile("^10011[A-Z0-9]{7}$");
    private static final Pattern NAME_OK = Pattern.compile("^[\\p{L}\\s.'\\-]{3,100}$");
    private static final Pattern DEBT_OK = Pattern.compile("^(\\d{1,9}(\\.\\d{1,2})?)?$");

    private WebView ui, ebel;
    private String injectJs;
    private boolean ebelLoaded = false;
    private String pending = null;

    // ---- Növbə: tək YVÖK sorğusu + toplu yoxlama eyni gizli WebView-dan ardıcıl keçir ----
    private static class Job {
        final String code;
        final boolean batch;
        Job(String code, boolean batch) { this.code = code; this.batch = batch; }
    }
    private final ArrayDeque<Job> jobs = new ArrayDeque<>();
    private Job current = null;
    private final Runnable watchdog = this::onWatchdog;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        injectJs = readAsset("inject.js");

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ebel = new WebView(this);
        ebel.setBackgroundColor(Color.WHITE);
        ebel.setFocusable(false);                       // klaviaturanı/fokusu oğurlamasın
        ebel.setFocusableInTouchMode(false);
        ui = new WebView(this);
        ui.setBackgroundColor(Color.BLACK);
        ui.setFocusable(true);
        ui.setFocusableInTouchMode(true);

        // e-belediyye WebView-u ekranda GÖRÜNMÜR: tam ölçüdə, amma ui-nin ARXASINDA işləyir.
        // (GONE olsa layout olmaz və sayt elementləri tapılmaz, ona görə arxada saxlanılır.)
        root.addView(ebel, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(ui, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        setupCommon(ui);
        setupCommon(ebel);

        // ---- Yuxarı: öz səhifəmiz (assets/index.html) ----
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        ui.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                ui.requestFocus();
                ui.evaluateJavascript("document.getElementById('phone-input').focus();", null);
                ui.postDelayed(() -> {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(ui, InputMethodManager.SHOW_IMPLICIT);
                }, 350);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {                                   // whatsapp:// və xarici linklər
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Tətbiq tapılmadı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        ui.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void reset() {
                runOnUiThread(() -> {
                    pending = null;
                    ebelLoaded = false;
                    jobs.removeIf(j -> !j.batch);
                    ebel.removeCallbacks(watchdog);
                    if (current != null) {
                        if (current.batch) jobs.addFirst(current);   // toplu sorğu itməsin
                        current = null;
                    }
                    ebel.stopLoading();
                    ebel.loadUrl(EBEL_URL);   // sayt ilkin vəziyyətə qayıdır, xanalar təmizlənir
                    pump();
                });
            }

            @JavascriptInterface
            public void fill(String code) {
                final String v = "10011" + (code == null ? "" : code.toUpperCase());
                if (!CODE.matcher(v).matches()) return;
                runOnUiThread(() -> {
                    jobs.removeIf(j -> !j.batch);
                    if (current != null && !current.batch) {
                        current = null;
                        ebel.removeCallbacks(watchdog);
                    }
                    jobs.addFirst(new Job(v, false));
                    status("loading");
                    pump();
                });
            }

            // Toplu yoxlama: vergüllə ayrılmış tam kodlar (10011XXXXXXX)
            @JavascriptInterface
            public void batch(String csv) {
                if (csv == null) return;
                final String[] parts = csv.split(",");
                runOnUiThread(() -> {
                    for (String c : parts) {
                        c = c.trim().toUpperCase();
                        if (!CODE.matcher(c).matches()) continue;
                        if (current != null && current.batch && current.code.equals(c)) continue;
                        boolean dup = false;
                        for (Job j : jobs) if (j.batch && j.code.equals(c)) { dup = true; break; }
                        if (!dup) jobs.addLast(new Job(c, true));
                    }
                    pump();
                });
            }

            @JavascriptInterface
            public void batchStop() {
                runOnUiThread(() -> jobs.removeIf(j -> j.batch));
            }
        }, "Android");
        ui.loadUrl("https://" + HOST + "/assets/index.html");

        // ---- Aşağı: e-belediyye.gov.az (WebView) ----
        ebel.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void result(final String code, final String name, final String debt) {
                runOnUiThread(() -> onEbelResult(code, name, debt));
            }

            @JavascriptInterface
            public void fail(final String code, final String reason) {
                runOnUiThread(() -> onEbelFail(code, reason));
            }
        }, "AndroidEbel");
        ebel.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                ebelLoaded = true;
                if (pending != null) {
                    String p = pending;
                    pending = null;
                    runFill(p);
                }
            }
        });
        ebel.loadUrl(EBEL_URL);
    }

    private void pump() {
        if (current != null) return;
        Job j = jobs.pollFirst();
        if (j == null) return;
        current = j;
        ebel.removeCallbacks(watchdog);
        ebel.postDelayed(watchdog, 45000);
        if (j.batch) batchState(j.code, "loading", null); else status("loading");
        fillEbel(j.code);
    }

    private void onEbelResult(String code, String name, String debt) {
        Job j = current;
        if (j == null || code == null || !j.code.equals(code)) return;   // köhnə/yad nəticə
        current = null;
        ebel.removeCallbacks(watchdog);
        final String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        final String d = debt == null ? "" : debt.trim();
        if (!NAME_OK.matcher(n).matches() || !DEBT_OK.matcher(d).matches()) {
            failJob(j, "Məlumat formatı tanınmadı");
        } else if (j.batch) {
            ui.evaluateJavascript("window.setBatchResult(" + JSONObject.quote(j.code) + ","
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
        } else {
            ui.evaluateJavascript("window.setEbelStatus('ok');window.setEbelResult("
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
            if (d.isEmpty()) toast("Borc məbləği tapılmadı");
        }
        pump();
    }

    private void onEbelFail(String code, String reason) {
        Job j = current;
        if (j == null || (code != null && !j.code.equals(code))) return;
        current = null;
        ebel.removeCallbacks(watchdog);
        failJob(j, reason == null || reason.length() > 80 ? "Məlumat tapılmadı" : reason);
        pump();
    }

    private void onWatchdog() {
        Job j = current;
        if (j == null) return;
        current = null;
        failJob(j, "Sayt cavab vermədi");
        pending = null;
        ebelLoaded = false;
        ebel.stopLoading();
        ebel.loadUrl(EBEL_URL);   // ilişən səhifəni təzələ, növbə davam etsin
        pump();
    }

    private void failJob(Job j, String msg) {
        if (j.batch) batchState(j.code, "fail", msg);
        else { status("fail"); toast(msg); }
    }

    private void batchState(String code, String st, String msg) {
        if ("fail".equals(st)) {
            ui.evaluateJavascript("window.setBatchFail(" + JSONObject.quote(code) + ","
                    + JSONObject.quote(msg == null ? "" : msg) + ");", null);
        }
    }

    private void setupCommon(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("OK", (d, x) -> res.confirm())
                        .setOnCancelListener(d -> res.confirm()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("Bəli", (d, x) -> res.confirm())
                        .setNegativeButton("Xeyr", (d, x) -> res.cancel())
                        .setOnCancelListener(d -> res.cancel()).show();
                return true;
            }
        });
    }

    private void fillEbel(String value) {
        if (ebelLoaded) runFill(value); else pending = value;
    }

    private void runFill(String value) {
        ebel.evaluateJavascript(injectJs + ";window.__yvokRun('" + value + "');", null);
    }

    private void status(final String st) {
        runOnUiThread(() -> ui.evaluateJavascript("window.setEbelStatus('" + st + "');", null));
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
