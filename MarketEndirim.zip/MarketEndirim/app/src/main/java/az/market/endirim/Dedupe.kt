package az.market.endirim

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Eyni məhsulun siyahıya iki dəfə düşməsinin qarşısını alır. Tipik hallar:
 *  - marka sətri + təsvir sətri:  "Cappy"  /  "Cappy meyvə şirəsi çeşidləri"  → yalnız ikincisi qalır;
 *  - OCR səhvi ilə yazılmış eyni ad:  "Pepsl"  /  "Pepsi sərinləşdirici içki çeşidləri";
 *  - eyni mətnin iki fərqli oxunuşu:  "COOLSY sərinləşdirici içki"  /  "COOLSY sarinlaş dirici igki çeşidlari"  → daha düzgün oxunan qalır.
 * Ölçü/say fərqli olan adlar (0.5L / 1L) heç vaxt birləşdirilmir.
 */
object NameDedupe {
    /** "16.Cappy", "3) Fairy" kimi sıra nömrəsi (arxasında hərf gəlirsə) silinir; "1.5L Pepsi" toxunulmaz qalır. */
    private val NUM_PREFIX = Regex("""^\s*\d{1,3}\s*[.)\-:]\s*(?=\p{L})""")
    private val SPLIT = Regex("[^\\p{L}\\p{N}]+")

    fun stripNumber(s: String): String = NUM_PREFIX.replace(s, "").trim()

    private class Key(val tokens: List<String>, val squash: String, val digits: String, val score: Int)

    private fun keyOf(name: String): Key {
        val n = Categorizer.norm(stripNumber(name))
        // "çeşid", "çeşidləri", "çeşidli" — məhsulu ayırd etməyən ümumi söz
        val toks = n.split(SPLIT).filter { it.isNotEmpty() && !it.startsWith("cesid") }
        return Key(toks, toks.joinToString(""), n.filter { it.isDigit() }, toks.count { AzText.isKnownWord(it) })
    }

    private fun tokMatch(a: String, b: String): Boolean =
        a == b || (a.length >= 4 && b.length >= 4 && Categorizer.editDistance(a, b, 1) <= 1)

    private fun isDup(a: Key, b: Key): Boolean {
        if (a.tokens.isEmpty() || b.tokens.isEmpty()) return false
        if (a.digits.isNotEmpty() && b.digits.isNotEmpty() && a.digits != b.digits) return false
        if (a.squash == b.squash) return true
        // 1) qısa ad uzun adın başlanğıcıdır (marka sətri + təsvir sətri)
        val s = if (a.tokens.size <= b.tokens.size) a else b
        val l = if (s === a) b else a
        if (s.tokens.size < l.tokens.size && (s.tokens.size >= 2 || s.tokens[0].length >= 4) &&
            s.tokens.indices.all { tokMatch(s.tokens[it], l.tokens[it]) }) return true
        // 2) eyni mətnin OCR ilə pozulmuş ikinci oxunuşu (≤ 20% fərq)
        val minLen = min(a.squash.length, b.squash.length)
        if (minLen >= 8 && abs(a.squash.length - b.squash.length) <= max(2, minLen / 4)) {
            val tol = minLen / 5
            if (Categorizer.editDistance(a.squash, b.squash, tol) <= tol) return true
        }
        return false
    }

    /** Dublikatları atır; sıra saxlanır. Hansı variantın qalacağı: daha çox düzgün (lüğətdə/brend) söz, bərabərdirsə daha uzun ad. */
    fun merge(list: List<Product>): List<Product> {
        if (list.size < 2) return list
        val keys = list.map { keyOf(it.name) }
        val order = list.indices.sortedWith(
            compareByDescending<Int> { keys[it].score }.thenByDescending { keys[it].tokens.size }.thenBy { it }
        )
        val kept = HashMap<Char, MutableList<Int>>()     // ilk hərfə görə qruplaşdırılıb (müqayisə sayı azalsın)
        val drop = BooleanArray(list.size)
        for (i in order) {
            val k = keys[i]
            if (k.squash.isEmpty()) continue
            val bucket = kept.getOrPut(k.squash[0]) { ArrayList() }
            if (bucket.any { isDup(keys[it], k) }) drop[i] = true else bucket.add(i)
        }
        return list.filterIndexed { i, _ -> !drop[i] }
    }
}
