package az.airpods.pro2;

import android.bluetooth.BluetoothDevice;

import java.lang.reflect.Method;

/** İstənilən qoşulu Bluetooth qulaqlıq üçün batareya (Android-in öz məlumatından, reflection ilə). */
final class GenericBt {
    static final String ACTION_BATTERY = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED";

    static PodsState read(BluetoothDevice d) {
        PodsState s = new PodsState();
        s.generic = true;
        try { s.address = d.getAddress(); } catch (Throwable ignored) { }
        String n = null;
        try { n = d.getName(); } catch (Throwable ignored) { }
        s.name = (n == null || n.isEmpty()) ? "Bluetooth qulaqlıq" : n;
        s.single = battery(d);
        // Fast Pair / TWS qulaqlıqların ayrıca sol, sağ, qab məlumatı (metadata açarları 10..15)
        s.left = meta(d, 10);
        s.right = meta(d, 11);
        s.caseLevel = meta(d, 12);
        s.chgL = flag(d, 13);
        s.chgR = flag(d, 14);
        s.chgC = flag(d, 15);
        return s;
    }

    static boolean hasData(PodsState s) {
        return s.single >= 0 || s.left >= 0 || s.right >= 0 || s.caseLevel >= 0;
    }

    private static int battery(BluetoothDevice d) {
        try {
            Method m = BluetoothDevice.class.getMethod("getBatteryLevel");
            Object o = m.invoke(d);
            if (o instanceof Integer) {
                int v = (Integer) o;
                return (v >= 0 && v <= 100) ? v : -1;
            }
        } catch (Throwable ignored) { }
        return -1;
    }

    private static String raw(BluetoothDevice d, int key) {
        try {
            Method m = BluetoothDevice.class.getMethod("getMetadata", int.class);
            Object o = m.invoke(d, key);
            if (o instanceof byte[]) return new String((byte[]) o).trim();
        } catch (Throwable ignored) { }
        return null;
    }

    private static int meta(BluetoothDevice d, int key) {
        String s = raw(d, key);
        if (s == null) return -1;
        try {
            int v = Integer.parseInt(s);
            return (v >= 0 && v <= 100) ? v : -1;
        } catch (Exception e) { return -1; }
    }

    private static boolean flag(BluetoothDevice d, int key) {
        String s = raw(d, key);
        return s != null && (s.equals("1") || s.equalsIgnoreCase("true"));
    }

    private GenericBt() {}
}
