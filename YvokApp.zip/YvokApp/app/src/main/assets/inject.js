(function () {
  var timer = null, rtimer = null;

  function send(fn, a, b, c) {
    try { if (window.AndroidEbel && AndroidEbel[fn]) AndroidEbel[fn](a, b, c); } catch (e) {}
  }

  // Nəticə blokunda "10011XXXXXXX / Ad Soyad Ata" və "Vergi borcu: XXX.XX manat" axtarır.
  // Kodu dəqiq uyğunlaşdırdığı üçün əvvəlki sorğunun köhnə nəticəsini götürmür.
  function readResult(val) {
    var text = (document.body ? document.body.innerText : '').replace(/\u00a0/g, ' ');
    var m = new RegExp(val + '\\s*[\\/\\\\|\\-\u2013\u2014]\\s*([^\\n\\r]+)', 'i').exec(text);
    if (!m) return null;
    var name = m[1].trim();
    var rest = text.slice(m.index + m[0].length);
    var d = /borc[^\d\n]{0,60}?(\d[\d ]*(?:[.,]\d{1,2})?)/i.exec(rest) ||
            /(\d[\d ]*(?:[.,]\d{1,2})?)\s*(?:manat|azn|\u20bc)/i.exec(rest);
    var debt = d ? d[1].replace(/ /g, '').replace(',', '.') : '';
    return { name: name, debt: debt };
  }

  function watchResult(val) {
    if (rtimer) clearInterval(rtimer);
    var k = 0, last = null;
    rtimer = setInterval(function () {
      k++;
      var r = readResult(val);
      if (r) last = r;
      if (r && r.debt) {
        clearInterval(rtimer);
        send('result', val, r.name, r.debt);
        return;
      }
      if (k > 40) {                       // ~20 saniyə
        clearInterval(rtimer);
        if (last) send('result', val, last.name, last.debt);
        else send('fail', val, 'Bu YVÖK üçün məlumat tapılmadı');
      }
    }, 500);
  }

  window.__yvokRun = function (val) {
    if (timer) clearInterval(timer);
    if (rtimer) clearInterval(rtimer);
    var n = 0, filled = false;
    timer = setInterval(function () {
      n++;
      var ins = [].slice.call(document.querySelectorAll('input')).filter(function (i) {
        return ['hidden', 'checkbox', 'radio', 'button', 'submit'].indexOf(i.type) < 0 && i.offsetParent !== null;
      });
      var inp = ins.filter(function (i) {
        return /yv[\u00f6o]k|v[\u00f6o]en/i.test((i.placeholder || '') + (i.name || '') + (i.id || ''));
      })[0] || ins[0];
      var btn = [].slice.call(document.querySelectorAll('button,input[type=submit],a,div[role=button]'))
        .filter(function (x) { return /yoxla/i.test(x.innerText || x.value || ''); })[0];

      if (inp && inp.value !== val) {
        // focus() ÇAĞIRILMIR: gizli səhifə klaviaturanı/fokusu ələ keçirməsin
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(inp, val);
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        inp.dispatchEvent(new Event('change', { bubbles: true }));
        filled = true;
      } else if (inp && inp.value === val) {
        filled = true;
      }
      if (filled && btn && !btn.disabled) {
        clearInterval(timer);
        setTimeout(function () { btn.click(); watchResult(val); }, 400);
        return;
      }
      if (n > 60) {
        clearInterval(timer);
        send('fail', val, 'Sayt açılmadı, internetə baxın');
      }
    }, 500);
  };
})();
