package com.example.callrec

import android.media.MediaRecorder
import android.os.Looper
import java.io.File
import java.net.InetAddress
import java.net.ServerSocket
import kotlin.system.exitProcess

/**
 * app_process ilə SHELL (uid 2000) kimi işləyir:
 * CLASSPATH=<apk> app_process /system/bin com.example.callrec.ShellRecorder <token>
 */
object ShellRecorder {
    private var mr: MediaRecorder? = null

    @JvmStatic
    fun main(args: Array<String>) {
        val token = args.getOrNull(0) ?: return
        try { Looper.prepareMainLooper() } catch (_: Throwable) {}
        val server = try {
            ServerSocket(Prefs.PORT, 5, InetAddress.getByName("127.0.0.1"))
        } catch (_: Throwable) { return }          // artıq işləyir
        while (true) {
            try {
                server.accept().use { s ->
                    val line = s.getInputStream().bufferedReader().readLine() ?: return@use
                    val p = line.split(" ")
                    val reply = if (p.size < 2 || p[0] != token) "ERR" else when (p[1]) {
                        "PING" -> "OK"
                        "START" -> if (p.size >= 4 && start(p[2], p[3].split(",").map { it.toInt() })) "OK" else "ERR"
                        "STOP" -> { stop(); "OK" }
                        "QUIT" -> { stop(); s.getOutputStream().write("OK\n".toByteArray()); exitProcess(0) }
                        else -> "ERR"
                    }
                    s.getOutputStream().write("$reply\n".toByteArray())
                }
            } catch (_: Throwable) {}
        }
    }

    private fun start(path: String, sources: List<Int>): Boolean {
        stop()
        File(path).parentFile?.mkdirs()
        for (src in sources) {
            try {
                val r = MediaRecorder(FakeContext.create())
                r.setAudioSource(src)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioEncodingBitRate(96000)
                r.setAudioSamplingRate(44100)
                r.setOutputFile(path)
                r.prepare(); r.start()
                mr = r
                return true
            } catch (_: Throwable) { File(path).delete() }
        }
        return false
    }

    private fun stop() {
        try { mr?.stop() } catch (_: Throwable) {}
        try { mr?.release() } catch (_: Throwable) {}
        mr = null
    }
}
