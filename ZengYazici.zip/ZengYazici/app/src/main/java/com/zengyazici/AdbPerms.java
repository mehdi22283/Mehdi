package com.zengyazici;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import io.github.muntashirakon.adb.AdbStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** ADB shell (uid 2000) vasitəsilə tətbiqə lazım olan icazələri verir. */
public class AdbPerms {
    private static long last;

    private static String exec(AdbMgr m, String cmd) {
        final StringBuilder sb = new StringBuilder();
        AdbStream s = null;
        try {
            s = m.openStream("shell:" + cmd);
            final AdbStream fs = s;
            Thread t = new Thread(() -> {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(fs.openInputStream()))) {
                    String l;
                    while ((l = br.readLine()) != null) {
                        synchronized (sb) { if (sb.length() < 300) sb.append(l).append(' '); }
                    }
                } catch (Exception e) { }
            });
            t.setDaemon(true);
            t.start();
            t.join(8000);
            if (t.isAlive()) return "vaxt aşımı";
        } catch (Throwable e) {
            return "xəta: " + e.getMessage();
        } finally {
            try { if (s != null) s.close(); } catch (Throwable e) { }
        }
        synchronized (sb) { return sb.toString().trim(); }
    }

    private static boolean ok(String out) {
        String o = out.toLowerCase(Locale.US);
        String[] bad = {"exception", "error", "unknown", "denied", "not found", "failed", "usage:", "xəta", "vaxt", "not a changeable", "has not requested"};
        for (String b : bad) if (o.contains(b)) return false;
        return true;
    }

    private static class Cmd {
        final String name, cmd;
        final boolean opt;
        Cmd(String n, String c, boolean o) { name = n; cmd = c; opt = o; }
    }

    /** Qoşulu ADB ilə bütün icazələri verir. Nəticə mətnini qaytarır (null: tezliklə artıq icra olunub). */
    public static synchronized String apply(Context c, boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - last < 30000) return null;
        AdbMgr m = AdbMgr.peek();
        if (m == null || !m.isConnected()) return "ADB qoşulmayıb";
        last = now;

        String p = c.getPackageName();
        List<Cmd> l = new ArrayList<>();
        l.add(new Cmd("Telefon vəziyyəti", "pm grant " + p + " android.permission.READ_PHONE_STATE", false));
        l.add(new Cmd("Zəng jurnalı", "pm grant " + p + " android.permission.READ_CALL_LOG", false));
        l.add(new Cmd("Mikrofon", "pm grant " + p + " android.permission.RECORD_AUDIO", false));
        if (Build.VERSION.SDK_INT >= 33)
            l.add(new Cmd("Bildirişlər", "pm grant " + p + " android.permission.POST_NOTIFICATIONS", false));
        l.add(new Cmd("Təhlükəsiz ayarlar", "pm grant " + p + " android.permission.WRITE_SECURE_SETTINGS", true));
        l.add(new Cmd("Zəng səsi tutma (CAPTURE_AUDIO_OUTPUT)", "pm grant " + p + " android.permission.CAPTURE_AUDIO_OUTPUT", true));
        l.add(new Cmd("Mikrofon appop", "appops set " + p + " RECORD_AUDIO allow", false));
        l.add(new Cmd("Audio çıxış appop", "appops set " + p + " RECORD_AUDIO_OUTPUT allow", true));
        l.add(new Cmd("Shell mikrofon appop", "appops set com.android.shell RECORD_AUDIO allow", true));
        l.add(new Cmd("Üstündə göstərmə", "appops set " + p + " SYSTEM_ALERT_WINDOW allow", false));
        l.add(new Cmd("Arxa fon", "appops set " + p + " RUN_IN_BACKGROUND allow", true));
        l.add(new Cmd("Arxa fon (hamısı)", "appops set " + p + " RUN_ANY_IN_BACKGROUND allow", true));
        l.add(new Cmd("Dəqiq alarm", "appops set " + p + " SCHEDULE_EXACT_ALARM allow", true));
        l.add(new Cmd("Batareya məhdudiyyəti", "dumpsys deviceidle whitelist +" + p, false));
        l.add(new Cmd("Bildiriş girişi", "cmd notification allow_listener " + p + "/" + p + ".WaListener", false));

        String comp = p + "/" + p + ".KeepAliveAccessibility";
        String cur = Settings.Secure.getString(c.getContentResolver(), "enabled_accessibility_services");
        if (cur == null || cur.equals("null")) cur = "";
        if (!cur.contains(comp)) {
            String v = cur.isEmpty() ? comp : cur + ":" + comp;
            l.add(new Cmd("Əlçatımlılıq siyahısı", "settings put secure enabled_accessibility_services '" + v + "'", false));
        }
        l.add(new Cmd("Əlçatımlılıq aktiv", "settings put secure accessibility_enabled 1", false));

        int good = 0, total = 0;
        for (Cmd k : l) {
            String out = exec(m, k.cmd);
            boolean r = ok(out);
            if (!k.opt) { total++; if (r) good++; }
            if (!r) RecService.log("ADB icazə: " + k.name + " — " + (out.length() > 90 ? out.substring(0, 90) : out));
        }
        String res = "ADB icazələri: " + good + "/" + total + " verildi";
        RecService.log(res);
        return res;
    }
}
