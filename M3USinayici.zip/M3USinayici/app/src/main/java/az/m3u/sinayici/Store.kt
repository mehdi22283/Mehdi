package az.m3u.sinayici

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Birinci playlist faylı, giriş tarixləri və xarab kanallar tarixçəsi. */
object Store {
    private const val PREFS = "m3u"
    private fun sp(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun fmt(ts: Long): String =
        if (ts <= 0) "—" else SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(ts))

    fun registerLogin(c: Context) {
        val s = sp(c)
        val cur = s.getLong("curLogin", 0L)
        s.edit().putLong("prevLogin", cur).putLong("curLogin", System.currentTimeMillis()).apply()
    }

    private fun firstFile(c: Context) = File(c.filesDir, "first_playlist.m3u")

    @Synchronized
    fun saveFirst(c: Context, name: String, text: String) {
        firstFile(c).writeText(text)
        sp(c).edit().putString("firstName", name).putBoolean("pending", true).apply()
    }

    private fun firstJson(c: Context): String {
        val f = firstFile(c)
        if (!f.exists()) return ""
        return JSONObject()
            .put("name", sp(c).getString("firstName", "playlist.m3u"))
            .put("text", f.readText())
            .toString()
    }

    @Synchronized
    fun takePending(c: Context): String {
        val s = sp(c)
        if (!s.getBoolean("pending", false)) return ""
        s.edit().putBoolean("pending", false).apply()
        return firstJson(c)
    }

    fun getFirst(c: Context): String = firstJson(c)

    private fun loadHistory(c: Context): JSONObject =
        try { JSONObject(sp(c).getString("history", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    @Synchronized
    fun report(c: Context, arr: JSONArray) {
        val h = loadHistory(c)
        val now = System.currentTimeMillis()
        var changed = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val n = o.optString("n")
            val u = o.optString("u")
            val st = o.optString("s")
            val key = "$n|$u"
            val e = h.optJSONObject(key)
            if (st == "dead") {
                if (e == null) {
                    h.put(key, JSONObject().put("n", n).put("u", u).put("first", now).put("last", now).put("cur", "dead"))
                    changed = true
                } else if (e.optString("cur") != "dead") {
                    e.put("cur", "dead").put("last", now)
                    changed = true
                }
            } else if (st == "ok" && e != null && e.optString("cur") == "dead") {
                e.put("cur", "ok")
                changed = true
            }
        }
        if (changed) sp(c).edit().putString("history", h.toString()).apply()
    }

    @Synchronized
    fun clearHistory(c: Context) {
        sp(c).edit().putString("history", "{}").apply()
    }

    @Synchronized
    fun stats(c: Context): String {
        val s = sp(c)
        val prev = s.getLong("prevLogin", 0L)
        val cur = s.getLong("curLogin", 0L)
        val h = loadHistory(c)
        val list = ArrayList<JSONObject>()
        val keys = h.keys()
        while (keys.hasNext()) {
            val e = h.optJSONObject(keys.next()) ?: continue
            e.put("firstStr", fmt(e.optLong("first")))
            list.add(e)
        }
        list.sortByDescending { it.optLong("first") }
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        return JSONObject()
            .put("prevLogin", if (prev == 0L) "ilk giriş" else fmt(prev))
            .put("curLogin", fmt(cur))
            .put("history", arr)
            .toString()
    }
}
