package az.mehdi.iptvplayer

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Sıfırdan qurulmuş VLC pleyer mühərriki.
 *
 * Çökmənin əsas səbəbi bu idi: stop / setMedia / play / detachViews / getVideoTracks / setAspectRatio
 * əmrləri fərqli thread-lərdən bir-birinə qarışırdı və native VLC thread-ləri ilə yarışırdı.
 * Burada qaydalar sadədir:
 *   1. Bütün native əmrlər YALNIZ bir "vlc-engine" thread-ində, ardıcıl icra olunur.
 *   2. Hər açılış yeni "token" alır. Köhnə tokenə aid hadisələr və gecikmiş əmrlər atılır.
 *   3. Kanal dəyişəndə növbədəki köhnə açılışlar silinir, yalnız SON kanal açılır.
 *   4. Hər açılış: stop() → yeni Media → setMedia → media.release() → play()  (rəsmi VLC qaydası).
 *   5. attach/detachViews yalnız UI thread-ində, stop() bitdikdən sonra çağırılır.
 *   6. Xəta / dayanma / bitmə halında avtomatik yenidən qoşulma (2 cəhd), sonra aydın xəta mesajı.
 */
class VlcEngine(context: Context, private val cb: Callback) {

    interface Callback {
        /** Yeni kanal açılır və ya yenidən qoşulunur: köhnə kadrı örtün, yüklənmə göstərin. */
        fun onLoading()

        /** Yayım başladı: örtüyü və yüklənmə göstəricisini silin. */
        fun onPlaying()

        /** Yayım başladıqdan sonrakı buferləmə (yalnız göstərici üçün). */
        fun onBuffering(active: Boolean)

        /** Bütün cəhdlər uğursuz oldu. */
        fun onFailed(message: String)
    }

    companion object {
        // 80 Mbit sabit internet üçün, millisaniyə.
        private const val NETWORK_CACHING_MS = 3_000
        private const val LIVE_CACHING_MS = 2_500
        private const val OPEN_TIMEOUT_MS = 15_000L       // Playing gəlməsə yenidən cəhd
        private const val STALL_TIMEOUT_MS = 15_000L      // Playing-dən sonra vaxt irəliləməsə yenidən cəhd
        private const val STALL_CHECK_MS = 3_000L
        private const val STABLE_RESET_MS = 20_000L       // bu qədər sabit getsə cəhd sayğacı sıfırlanır
        private const val MAX_RETRIES = 2
        private const val SWITCH_DEBOUNCE_MS = 180L       // tez-tez dəyişəndə native əmrləri seyrəlt
    }

    private val ui = Handler(Looper.getMainLooper())
    private val thread = HandlerThread("vlc-engine").apply { start() }
    private val worker = Handler(thread.looper)

    private val libVLC: LibVLC = LibVLC(
        context.applicationContext,
        arrayListOf(
            "--network-caching=$NETWORK_CACHING_MS",
            "--live-caching=$LIVE_CACHING_MS",
            "--http-reconnect",
            "--no-stats",
            "--no-sub-autodetect-file"
        )
    )
    private val mp: MediaPlayer = MediaPlayer(libVLC)

    // ---- yalnız UI thread-i ----
    private var url: String? = null
    private var layout: VLCVideoLayout? = null
    private var needsStart = false
    private var released = false
    private var retries = 0
    private var playing = false
    private var paused = false
    private var playingSince = 0L
    private var lastStartAt = 0L
    private var openTimeout: Runnable? = null
    private var stallWatch: Runnable? = null

    // ---- thread-lər arası ----
    private val token = AtomicInteger(0)
    @Volatile private var liveToken = -1          // hadisələri qəbul edilən açılış nömrəsi
    @Volatile private var attached = false
    @Volatile private var progressAt = 0L
    @Volatile private var lastTimeMs = Long.MIN_VALUE
    @Volatile private var surfaceW = 0
    @Volatile private var surfaceH = 0

    init {
        mp.setEventListener { ev ->
            val t = liveToken
            if (t < 0 || t != token.get()) return@setEventListener
            when (ev.type) {
                MediaPlayer.Event.TimeChanged -> {
                    val tm = ev.timeChanged
                    if (tm != lastTimeMs) {
                        lastTimeMs = tm
                        progressAt = SystemClock.elapsedRealtime()
                    }
                }
                MediaPlayer.Event.Playing -> ui.post { onPlayingEvent(t) }
                MediaPlayer.Event.Buffering -> {
                    val b = ev.buffering
                    ui.post { onBufferingEvent(t, b) }
                }
                MediaPlayer.Event.Vout -> applyFillAsync(t)
                MediaPlayer.Event.EncounteredError -> ui.post { recover(t, "Kanal açıla bilmədi") }
                MediaPlayer.Event.EndReached -> ui.post { recover(t, "Yayım kəsildi") }
                else -> {}
            }
        }
    }

    // ------------------------------------------------------------------ public (UI thread)

    /** Kanal aç. Tez-tez çağırılsa belə yalnız sonuncu açılacaq. */
    fun play(newUrl: String) {
        if (released) return
        url = newUrl
        retries = 0
        paused = false
        val now = SystemClock.uptimeMillis()
        val delay = if (now - lastStartAt < 1_000L) SWITCH_DEBOUNCE_MS else 0L
        start(delay)
    }

    fun setSurfaceSize(w: Int, h: Int) {
        if (w <= 0 || h <= 0 || (w == surfaceW && h == surfaceH)) return
        surfaceW = w; surfaceH = h
        val t = liveToken
        if (t >= 0) applyFillAsync(t)
    }

    fun togglePause() {
        if (released || !playing) return
        val t = token.get()
        paused = !paused
        if (!paused) progressAt = SystemClock.elapsedRealtime()
        worker.post {
            if (t != token.get()) return@post
            runCatching { if (mp.isPlaying) mp.pause() else mp.play() }
        }
    }

    /** onStart: video səthini bağla və fonda dayandırılmış kanalı davam etdir. */
    fun attach(videoLayout: VLCVideoLayout) {
        if (released || attached) return
        layout = videoLayout
        runCatching { mp.attachViews(videoLayout, null, false, false) }
        attached = true
        if (needsStart && url != null) {
            needsStart = false
            start(0L)
        }
    }

    /** onStop: yayımı dayandır (bitənə qədər gözlə), sonra səthi ayır. */
    fun stopForBackground() {
        if (released) return
        token.incrementAndGet()
        liveToken = -1
        cancelWatchers()
        playing = false
        needsStart = url != null
        worker.removeCallbacksAndMessages(null)
        val done = CountDownLatch(1)
        worker.post {
            runCatching { mp.stop() }
            done.countDown()
        }
        runCatching { done.await(2, TimeUnit.SECONDS) }
        if (attached) {
            runCatching { mp.detachViews() }
            attached = false
        }
        layout = null
    }

    /** onDestroy. */
    fun release() {
        if (released) return
        released = true
        token.incrementAndGet()
        liveToken = -1
        cancelWatchers()
        ui.removeCallbacksAndMessages(null)
        runCatching { mp.setEventListener(null) }
        worker.removeCallbacksAndMessages(null)
        val wasAttached = attached
        attached = false
        if (wasAttached) runCatching { mp.detachViews() }
        worker.post {
            runCatching { mp.stop() }
            runCatching { mp.release() }
            runCatching { libVLC.release() }
            thread.quitSafely()
        }
    }

    // ------------------------------------------------------------------ açılış

    private fun start(delayMs: Long) {
        if (released) return
        val u = url ?: return
        val t = token.incrementAndGet()
        liveToken = -1              // köhnə açılışın hadisələri dərhal kəsilir
        playing = false
        lastStartAt = SystemClock.uptimeMillis()
        cancelWatchers()
        cb.onLoading()
        worker.removeCallbacksAndMessages(null)   // gözləyən köhnə açılışlar silinir
        worker.postDelayed({ openOnWorker(t, u) }, delayMs)
        armOpenTimeout(t)
    }

    /** Yalnız vlc-engine thread-i. */
    private fun openOnWorker(t: Int, u: String) {
        if (t != token.get() || released) return
        if (!attached) {                       // səth yoxdur (fondadır): ön plana qayıdanda başlayacaq
            ui.post { if (t == token.get()) needsStart = true }
            return
        }
        try {
            runCatching { mp.stop() }          // əvvəlki yayım tam bitsin
            if (t != token.get() || released) return

            val media = Media(libVLC, Uri.parse(u))
            media.setHWDecoderEnabled(true, false)
            media.addOption(":network-caching=$NETWORK_CACHING_MS")
            media.addOption(":live-caching=$LIVE_CACHING_MS")
            mp.media = media                   // player öz nüsxəsini saxlayır
            media.release()                    // bizim istinadı dərhal buraxırıq (rəsmi qayda)

            if (t != token.get() || released) return
            lastTimeMs = Long.MIN_VALUE
            progressAt = SystemClock.elapsedRealtime()
            liveToken = t
            mp.play()
            applyFillAsync(t)
        } catch (e: Throwable) {
            ui.post { recover(t, "Kanal açıla bilmədi") }
        }
    }

    // ------------------------------------------------------------------ hadisələr (UI thread)

    private fun onPlayingEvent(t: Int) {
        if (t != token.get() || released) return
        if (!playing) {
            playing = true
            playingSince = SystemClock.elapsedRealtime()
            progressAt = playingSince
            cancelOpenTimeout()
            startStallWatch(t)
            cb.onPlaying()
        }
        applyFillAsync(t)
    }

    private fun onBufferingEvent(t: Int, percent: Float) {
        if (t != token.get() || released || !playing) return
        cb.onBuffering(percent < 100f)
    }

    /** Xəta / bitmə / dayanma: 2 dəfə təmiz yenidən qoşul, sonra xəta göstər. */
    private fun recover(t: Int, message: String) {
        if (t != token.get() || released) return
        if (retries < MAX_RETRIES) {
            retries++
            start(400L * retries)
        } else {
            cancelWatchers()
            playing = false
            token.incrementAndGet()
            liveToken = -1
            worker.removeCallbacksAndMessages(null)
            worker.post { runCatching { mp.stop() } }
            cb.onFailed("$message. Başqa kanal seçin.")
        }
    }

    // ------------------------------------------------------------------ nəzarətçilər

    private fun armOpenTimeout(t: Int) {
        val r = Runnable {
            openTimeout = null
            if (t == token.get() && !playing) recover(t, "Yayım açılmadı")
        }
        openTimeout = r
        ui.postDelayed(r, OPEN_TIMEOUT_MS)
    }

    private fun cancelOpenTimeout() {
        openTimeout?.let { ui.removeCallbacks(it) }
        openTimeout = null
    }

    private fun startStallWatch(t: Int) {
        val r = object : Runnable {
            override fun run() {
                if (t != token.get() || released || !playing) { stallWatch = null; return }
                val now = SystemClock.elapsedRealtime()
                if (!paused) {
                    if (now - playingSince > STABLE_RESET_MS && now - progressAt < STALL_TIMEOUT_MS) retries = 0
                    if (now - progressAt > STALL_TIMEOUT_MS) {
                        stallWatch = null
                        recover(t, "Yayım dayandı")
                        return
                    }
                }
                ui.postDelayed(this, STALL_CHECK_MS)
            }
        }
        stallWatch = r
        ui.postDelayed(r, STALL_CHECK_MS)
    }

    private fun cancelWatchers() {
        cancelOpenTimeout()
        stallWatch?.let { ui.removeCallbacks(it) }
        stallWatch = null
    }

    // ------------------------------------------------------------------ görüntünü ekrana uzat

    /** Video ekrandan kiçikdirsə ekranı doldurmaq üçün uzadılır. Reflection və track sorğusu yoxdur. */
    private fun applyFillAsync(t: Int) {
        val w = surfaceW
        val h = surfaceH
        if (w <= 0 || h <= 0) return
        worker.post {
            if (t != token.get() || released) return@post
            runCatching {
                mp.setAspectRatio("$w:$h")
                mp.setScale(0f)
            }
        }
    }
}
