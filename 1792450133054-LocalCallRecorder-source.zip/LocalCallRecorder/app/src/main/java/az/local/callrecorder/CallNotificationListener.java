package az.local.callrecorder;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import java.util.Locale;

/**
 * Heuristic WhatsApp call detector. It only reacts to recognizable ongoing-call text;
 * notification text differs by WhatsApp version and device language.
 */
public class CallNotificationListener extends NotificationListenerService {
    private boolean whatsappCallActive = false;

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (!isWhatsAppPackage(sbn.getPackageName())) return;
        String text = getNotificationText(sbn.getNotification());
        boolean ongoing = looksLikeOngoingCall(text);
        if (ongoing && !whatsappCallActive) {
            whatsappCallActive = true;
            sendServiceAction(RecordingService.ACTION_WA_START);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        if (!isWhatsAppPackage(sbn.getPackageName())) return;
        // WhatsApp commonly removes its ongoing-call notification at hang-up.
        if (whatsappCallActive) {
            whatsappCallActive = false;
            sendServiceAction(RecordingService.ACTION_WA_STOP);
        }
    }

    private boolean isWhatsAppPackage(String p) {
        return "com.whatsapp".equals(p) || "com.whatsapp.w4b".equals(p);
    }

    private String getNotificationText(Notification n) {
        Bundle e = n.extras;
        if (e == null) return "";
        StringBuilder s = new StringBuilder();
        append(s, e.getCharSequence(Notification.EXTRA_TITLE));
        append(s, e.getCharSequence(Notification.EXTRA_TEXT));
        append(s, e.getCharSequence(Notification.EXTRA_BIG_TEXT));
        append(s, e.getCharSequence(Notification.EXTRA_SUB_TEXT));
        append(s, e.getCharSequence(Notification.EXTRA_SUMMARY_TEXT));
        return s.toString().toLowerCase(Locale.ROOT);
    }

    private void append(StringBuilder s, CharSequence value) {
        if (!TextUtils.isEmpty(value)) s.append(' ').append(value);
    }

    private boolean looksLikeOngoingCall(String text) {
        if (text.contains("missed call") || text.contains("buraxılmış zəng") || text.contains("incoming call")
                || text.contains("gələn zəng") || text.contains("calling you")) return false;
        return text.contains("ongoing call") || text.contains("call in progress") || text.contains("active call")
                || text.contains("on a call") || text.contains("ongoing voice call")
                || text.contains("zəng davam edir") || text.contains("aktiv zəng")
                || text.contains("səsli zəng davam edir") || text.contains("video zəng davam edir");
    }

    private void sendServiceAction(String action) {
        try {
            // The user must first start the visible foreground service in the app.
            startService(new Intent(this, RecordingService.class).setAction(action));
        } catch (RuntimeException ignored) {
            // Some Android builds prohibit background service starts; open the app and start it manually.
        }
    }
}
