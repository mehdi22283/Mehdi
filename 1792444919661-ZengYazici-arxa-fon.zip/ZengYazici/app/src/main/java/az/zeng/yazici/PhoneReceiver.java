package az.zeng.yazici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.telephony.TelephonyManager;

/** Adi telefon zəngləri: PHONE_STATE ilə başlayır və bitir. Heç bir daimi xidmət yoxdur. */
public class PhoneReceiver extends BroadcastReceiver {
    @SuppressWarnings("deprecation")
    @Override
    public void onReceive(Context c, Intent i) {
        SharedPreferences p = c.getSharedPreferences("st", 0);
        if (!p.getBoolean("monitor_enabled", false)) return;
        String act = i.getAction();
        if (Intent.ACTION_NEW_OUTGOING_CALL.equals(act)) {
            p.edit().putString("out_num", i.getStringExtra(Intent.EXTRA_PHONE_NUMBER)).apply();
            return;
        }
        if (!TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(act)) return;

        String st = i.getStringExtra(TelephonyManager.EXTRA_STATE);
        String num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
        final PendingResult pr = goAsync();

        if (TelephonyManager.EXTRA_STATE_RINGING.equals(st)) {
            SharedPreferences.Editor e = p.edit().putBoolean("ph_ring", true);
            if (num != null && !num.isEmpty()) e.putString("ph_num", num);
            e.apply();
            pr.finish();
        } else if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(st)) {
            boolean inc = p.getBoolean("ph_ring", false);
            String n = inc ? p.getString("ph_num", "") : p.getString("out_num", "");
            if (n == null || n.isEmpty()) n = "Naməlum";
            RecorderClient.begin(c, "ph", inc ? "in" : "out", n, pr::finish);
        } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(st)) {
            p.edit().putBoolean("ph_ring", false).remove("ph_num").remove("out_num").apply();
            RecorderClient.end(c, "ph", pr::finish);
        } else {
            pr.finish();
        }
    }
}
