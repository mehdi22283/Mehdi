package az.yvok.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;

import java.io.IOException;
import java.io.InputStream;

/**
 * OCR üçün şəkli yükləyir (EXIF-ə görə düzgün çevirir). Heç bir rəng/kontrast effekti tətbiq olunmur:
 * Cloud Vision orijinal rəngli şəkildə ən dəqiq işləyir.
 */
final class OcrImage {
    private static final int MAX_SIDE = 6000;          // uzun tərəf bundan böyük olmasın
    private static final long MAX_PIXELS = 16_000_000L; // yaddaş qoruyucusu

    private OcrImage() { }

    /** Şəkli yükləyir, EXIF-ə görə düzgün çevirir və lazım olsa kiçildir. */
    static Bitmap load(Context c, Uri uri) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, o);
        }
        int w0 = o.outWidth, h0 = o.outHeight;
        if (w0 <= 0 || h0 <= 0) throw new IOException("şəkil oxunmadı");

        int sample = 1;
        while (Math.max(w0, h0) / (sample * 2) >= MAX_SIDE) sample *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = sample;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bmp;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            bmp = BitmapFactory.decodeStream(in, null, o);
        }
        if (bmp == null) throw new IOException("şəkil açılmadı");

        // EXIF çevrilməsi
        int orient = ExifInterface.ORIENTATION_NORMAL;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in != null) orient = new ExifInterface(in).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
        } catch (Exception ignored) { }
        Matrix m = new Matrix();
        switch (orient) {
            case ExifInterface.ORIENTATION_ROTATE_90: m.postRotate(90); break;
            case ExifInterface.ORIENTATION_ROTATE_180: m.postRotate(180); break;
            case ExifInterface.ORIENTATION_ROTATE_270: m.postRotate(270); break;
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_FLIP_VERTICAL: m.postScale(1, -1); break;
            case ExifInterface.ORIENTATION_TRANSPOSE: m.postRotate(90); m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_TRANSVERSE: m.postRotate(270); m.postScale(-1, 1); break;
            default: break;
        }
        // Kiçiltmə (ölçü həddi)
        float scale = 1f;
        int w = bmp.getWidth(), h = bmp.getHeight();
        int maxSide = Math.max(w, h);
        if (maxSide > MAX_SIDE) scale = Math.min(scale, (float) MAX_SIDE / maxSide);
        if ((long) w * h > MAX_PIXELS) scale = Math.min(scale, (float) Math.sqrt((double) MAX_PIXELS / ((double) w * h)));
        if (scale < 1f) m.postScale(scale, scale);

        if (!m.isIdentity()) {
            Bitmap t = Bitmap.createBitmap(bmp, 0, 0, w, h, m, true);
            if (t != bmp) bmp.recycle();
            bmp = t;
        }
        return bmp;
    }
}
