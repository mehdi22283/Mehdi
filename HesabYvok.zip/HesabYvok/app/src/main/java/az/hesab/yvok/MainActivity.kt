package az.hesab.yvok

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import org.json.JSONTokener

class MainActivity : AppCompatActivity() {

    companion object {
        const val BASE_URL =
            "https://hesab.az/unregistered/#/direct-pay/government/gppbelediyye/parameters/?portalPay=kommunal_az&lang=az&yvok="
        const val MAX_TRIES = 30       // 30 x 1 san = 30 saniyə
        const val POLL_MS = 1000L

        // Səhifədən Abonent / YVÖK / Balans dəyərlərini oxuyur
        val EXTRACT_JS = """
(function(){
  var t=(document.body&&document.body.innerText)||'';
  var lines=t.split('\n').map(function(s){return s.trim();}).filter(function(s){return s.length>0;});
  function find(re){
    for(var i=lines.length-1;i>=0;i--){
      if(re.test(lines[i])){
        var rest=lines[i].replace(re,'').replace(/^[\s:\-–]+/,'').trim();
        if(rest) return rest;
        if(i+1<lines.length && !/^(abonent|yv[öo]k|balans)/i.test(lines[i+1])) return lines[i+1];
      }
    }
    return '';
  }
  if(!window.__tried){
    var btns=document.querySelectorAll('button, input[type=submit], a.btn');
    for(var j=0;j<btns.length;j++){
      var bt=(btns[j].innerText||btns[j].value||'').trim();
      if(/^(davam|yoxla|axtar|sorğu|göstər|növbəti)/i.test(bt) && !btns[j].disabled){
        window.__tried=true; btns[j].click(); break;
      }
    }
  }
  return JSON.stringify({
    abonent:find(/^abonent\b/i),
    yvok:find(/^yv[öo]k\b/i),
    balans:find(/^balans\b/i),
    raw:t.substring(0,1500)
  });
})()
"""
    }

    private lateinit var webView: WebView
    private lateinit var etYvok: EditText
    private lateinit var progress: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var resultBox: LinearLayout
    private lateinit var tvAbonent: TextView
    private lateinit var tvYvok: TextView
    private lateinit var tvBalans: TextView
    private lateinit var tvRaw: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var tries = 0
    private var session = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        etYvok = findViewById(R.id.etYvok)
        progress = findViewById(R.id.progress)
        tvStatus = findViewById(R.id.tvStatus)
        resultBox = findViewById(R.id.resultBox)
        tvAbonent = findViewById(R.id.tvAbonent)
        tvYvok = findViewById(R.id.tvYvok)
        tvBalans = findViewById(R.id.tvBalans)
        tvRaw = findViewById(R.id.tvRaw)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()

        findViewById<Button>(R.id.btnSearch).setOnClickListener { startSearch() }
        etYvok.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { startSearch(); true } else false
        }
    }

    private fun startSearch() {
        val text = etYvok.text.toString().trim()
        if (text.isEmpty()) {
            tvStatus.text = "Zəhmət olmasa mətn yazın."
            return
        }
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etYvok.windowToken, 0)

        session++
        val mySession = session
        tries = 0
        handler.removeCallbacksAndMessages(null)
        resultBox.visibility = View.GONE
        tvRaw.visibility = View.GONE
        progress.visibility = View.VISIBLE
        tvStatus.text = "Məlumat yüklənir..."

        // Hash-route eyni səhifədə dəyişməsin deyə əvvəlcə boş səhifə yüklənir
        webView.loadUrl("about:blank")
        handler.postDelayed({
            if (mySession == session) {
                webView.loadUrl(BASE_URL + Uri.encode(text))
                handler.postDelayed({ poll(mySession) }, 3000)
            }
        }, 300)
    }

    private fun poll(mySession: Int) {
        if (mySession != session) return
        tries++
        webView.evaluateJavascript(EXTRACT_JS) { raw ->
            if (mySession != session) return@evaluateJavascript
            var abonent = ""; var yvok = ""; var balans = ""; var page = ""
            try {
                val json = JSONObject(JSONTokener(raw).nextValue() as String)
                abonent = json.optString("abonent")
                yvok = json.optString("yvok")
                balans = json.optString("balans")
                page = json.optString("raw")
            } catch (_: Exception) { }

            if (balans.isNotEmpty() || (abonent.isNotEmpty() && yvok.isNotEmpty())) {
                progress.visibility = View.GONE
                tvStatus.text = ""
                tvAbonent.text = abonent.ifEmpty { "—" }
                tvYvok.text = yvok.ifEmpty { "—" }
                tvBalans.text = balans.ifEmpty { "—" }
                resultBox.visibility = View.VISIBLE
            } else if (tries >= MAX_TRIES) {
                progress.visibility = View.GONE
                tvStatus.text = "Məlumat tapılmadı. Kodu yoxlayın və ya yenidən cəhd edin."
                if (page.isNotEmpty()) {
                    tvRaw.text = "Səhifənin mətni:\n\n$page"
                    tvRaw.visibility = View.VISIBLE
                }
            } else {
                handler.postDelayed({ poll(mySession) }, POLL_MS)
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        webView.destroy()
        super.onDestroy()
    }
}
