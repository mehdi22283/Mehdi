package az.vakansiya

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Yadda saxlanılan "Xüsusi Vakansiya" qeydi. ts = ilk dəfə tapıldığı vaxt, seen = "baxıldı" basılıb. */
data class Sp(val siteName: String, val siteUrl: String, val hit: Hit, val ts: Long, var seen: Boolean)

/**
 * Xüsusi vakansiyalar "baxıldı" ikonuna basılana qədər qalır (tətbiq bağlansa da, yenilənsə də).
 * Həm tətbiq, həm də arxa plan yoxlaması (CheckWorker) bura yazır.
 */
object SpecialStore {
    private const val KEEP_SEEN_MS = 14L * 24 * 3600 * 1000
    private const val MAX = 300

    private fun p(c: Context) = c.getSharedPreferences("special", Context.MODE_PRIVATE)

    @Synchronized
    fun load(c: Context): MutableList<Sp> {
        val l = mutableListOf<Sp>()
        val s = p(c).getString("list", null) ?: return l
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                l.add(Sp(o.optString("sn"), o.optString("su"),
                    Hit(o.optString("t"), o.optString("u"), o.optInt("k"), 0),
                    o.optLong("ts"), o.optBoolean("v")))
            }
        } catch (e: Exception) { }
        return l
    }

    private fun save(c: Context, l: List<Sp>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("sn", it.siteName).put("su", it.siteUrl).put("t", it.hit.title)
                .put("u", it.hit.url).put("k", it.hit.kind).put("ts", it.ts).put("v", it.seen))
        }
        p(c).edit().putString("list", a.toString()).apply()
    }

    /** Yeni tapılanları əlavə edir (artıq olanlar, o cümlədən "baxıldı" olanlar təkrar əlavə olunmur). */
    @Synchronized
    fun add(c: Context, found: List<Pair<Site, Hit>>) {
        val l = load(c)
        val now = System.currentTimeMillis()
        var changed = false
        val have = HashSet<String>(l.map { it.hit.url })
        for ((s, h) in found) {
            if (h.url.isEmpty() || !have.add(h.url)) continue
            l.add(Sp(s.name, s.url, h, now, false))
            changed = true
        }
        // köhnə "baxıldı" qeydlərini təmizlə (təkrar çıxmasın deyə 14 gün saxlanır)
        if (l.removeAll { it.seen && now - it.ts > KEEP_SEEN_MS }) changed = true
        while (l.size > MAX) {
            val idx = l.indexOfFirst { it.seen }.let { if (it >= 0) it else 0 }
            l.removeAt(idx); changed = true
        }
        if (changed) save(c, l)
    }

    /** "Baxıldı": siteUrl == null → hamısı, əks halda yalnız həmin saytın qeydləri. */
    @Synchronized
    fun markSeen(c: Context, siteUrl: String?) {
        val l = load(c)
        var changed = false
        for (x in l) if (!x.seen && (siteUrl == null || x.siteUrl == siteUrl)) { x.seen = true; changed = true }
        if (changed) save(c, l)
    }
}
