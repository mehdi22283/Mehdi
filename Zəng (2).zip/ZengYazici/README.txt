ZƏNG YAZICI - quraşdırma (hamısı telefonda, kompüter və Shizuku lazım deyil)

Qısa iş prinsipi: tətbiq telefonun öz Wireless debugging xidməti ilə (pairing kodu) cütləşir, sonra shell icazəsi ilə kiçik yazıcı proses (Daemon) başladır. Proses başlayandan sonra Wi-Fi sönsə də işləyir. Telefon yenidən başlayanda proses bağlanır; Wi-Fi + Wireless debugging açıq olanda tətbiq onu zəng zamanı özü yenidən başlada bilər (3-cü düymə də var).

Tətbiqi açın: pəncərədəki TƏK düyməni basın. Düymə hər dəfə növbəti çatışmayan addımı göstərir və icra edir (1/5 ... 5/5):
  1/5 İcazələri ver
  2/5 Cütləşdir: bildiriş çıxacaq. Wireless debugging ekranında "Pair device with pairing code" seçin (pəncərə açıq qalsın), 6 rəqəmi bildiriş panelindəki sahəyə yazın.
  3/5 Yazıcı prosesi başlat
  4/5 WhatsApp üçün bildiriş girişi
  5/5 Avtostart (Xiaomi)
Hamısı ✔ olanda "Hazırdır" yazır. Bundan sonra hər gələn/gedən zəngdə (zəng çalan və ya yığılan anda) yazıcı proses özü hazırlanır, zəng açılanda yazı başlayır.
"Sınaq yazısı" və "Jurnal" düymələri eyni pəncərənin altındadır. Alınmasa Jurnal mətnini göndərin.

Tarixçə: hər zəng (cavabsız olanlar da) tarixi/saatı ilə yazılır. "Hamısı / Gələn / Gedən" filtri var. Silmək üçün qeydi uzun basın.

Yazılar: /sdcard/Android/media/az.zeng.yazici/ (WAV)
