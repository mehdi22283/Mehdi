# Mikrorayon Baza — Supabase qurulumu (addım-addım)

Supabase pulsuz onlayn bazadır. Tətbiq telefondakı dəyişiklikləri (redaktə, əlavə, silmə, ad dəyişmə, import, borc) buraya avtomatik yükləyir.

## 1. Hesab və layihə yaradın

1. Brauzerdə https://supabase.com saytını açın, **Start your project** düyməsinə toxunun.
2. GitHub və ya e-poçt ilə qeydiyyatdan keçin.
3. **New project** seçin.
4. **Name** sahəsinə istənilən ad yazın (məsələn: baza).
5. **Database Password** üçün güclü parol yazın və bir yerdə saxlayın (tətbiqə lazım deyil).
6. **Region** seçin (Avropadan biri, məsələn Frankfurt).
7. **Create new project** düyməsinə toxunun və 1–2 dəqiqə gözləyin.

## 2. Cədvəli yaradın

1. Sol menyuda **SQL Editor** bölməsini açın.
2. **New query** seçin.
3. Aşağıdakı kodu olduğu kimi yapışdırın və **Run** düyməsinə toxunun:

```sql
create table if not exists public.baza_sync (
    id text primary key,
    data jsonb not null,
    updated_at timestamptz not null default now()
);

alter table public.baza_sync enable row level security;

grant select, insert, update, delete
on table public.baza_sync to service_role;

do $$
begin
    alter publication supabase_realtime add table public.baza_sync;
exception when duplicate_object then null;
end $$;
```

4. "Success. No rows returned" yazısı çıxmalıdır.
5. Yoxlamaq üçün sol menyuda **Table Editor** bölməsində `baza_sync` cədvəlinin göründüyünü yoxlayın.

Tətbiqdə bu kodu **SQL-i kopyala** düyməsi ilə də götürə bilərsiniz.

## 3. Project URL-i tapın

1. Sol altda **Project Settings** (dişli işarəsi) bölməsini açın.
2. **Data API** (və ya **API**) səhifəsində **Project URL** sahəsini tapın.
3. Görünüşü belədir: `https://abcdefghijk.supabase.co`
4. Kopyalayın.

Qeyd: tətbiq `https://abcdefghijk.supabase.co/rest/v1/` və ya yalnız `abcdefghijk` yazılsa da düzgün başa düşür.

## 4. API açarını tapın

1. **Project Settings → API Keys** bölməsinə keçin.
2. **Secret keys** hissəsində `sb_secret_...` açarını **Copy** edin. Yoxdursa **Create new secret key** seçin.
3. Köhnə sistemdə: **Legacy API keys** bölməsində **service_role** açarını götürün.

Vacib:
- **publishable** (`sb_publishable_...`) və **anon** açarı bu tətbiqdə işləməyəcək, çünki cədvəl RLS ilə bağlıdır. Yalnız **secret** və ya **service_role** istifadə edin.
- Açarı kopyalayanda əvvəlində və sonunda boşluq qalmasın.

## 5. Tətbiqdə bağlayın

1. Mikrorayon Baza tətbiqində **☁️ Supabase** düyməsinə toxunun.
2. **Project URL** sahəsinə 3-cü addımdakı ünvanı yapışdırın.
3. Açar sahəsinə 4-cü addımdakı açarı yapışdırın.
4. **Bağlantını yoxla** düyməsinə toxunun. Tətbiq həm oxuma, həm də yazma yoxlayır.
5. "Bağlantı uğurludur" yazısı çıxsa, **Yadda saxla** düyməsinə toxunun.
6. **Dəyişiklik olanda avtomatik yüklə** seçimi aktiv qalsın.

## 6. Birinci dəfə istifadə

1. Əvvəlcə **Serverə yüklə (indi)** seçin. Telefondakı bazanız serverə gedir.
2. Boş serverdən **Serverdən endir** etməyin, çünki telefondakı dəyişikliklər silinə bilər.
3. Sonra dəyişikliklər 3 saniyə sonra özü yüklənəcək.
4. Düymənin yanında **✓ 14:32** görsəniz, sonuncu yükləmə uğurlu olub. **⚠** görsəniz, xəta var.
5. Başqa telefonda eyni URL və açarı daxil edib **Serverdən endir** seçin.

## 7. Xətalar və həlli

| Xəta | Səbəbi | Həlli |
|---|---|---|
| HTTP 401 / Invalid API key | Açar səhvdir və ya kopyalananda kəsilib | Açarı yenidən kopyalayın |
| HTTP 403 / permission denied | publishable/anon açar və ya grant yoxdur | Secret/service_role açarı qoyun, 2-ci addımdakı SQL-i yenidən işlədin |
| HTTP 404 / PGRST205 | `baza_sync` cədvəli yoxdur | 2-ci addımdakı SQL-i işlədin |
| Unable to resolve host | Project URL səhvdir və ya internet yoxdur | URL-i yoxlayın, interneti yoxlayın |
| Layihə cavab vermir | Pulsuz layihə uzun müddət istifadə olunmadıqda dayandırılır | Supabase panelində layihəni **Restore** edin |

## 8. Açılış yoxlaması, Realtime və layihənin canlı qalması

1. Tətbiq hər açılanda serverə kiçik sorğu göndərir. Başqa telefonda dəyişiklik olubsa, «Serverdə yeni dəyişiklik var, endirilsin?» sualı çıxır.
2. Tətbiq açıq olanda Supabase Realtime ilə bağlantı saxlanılır. Başqa telefonda edilən dəyişiklik bu telefona avtomatik endirilir.
3. Realtime üçün 2-ci addımdakı SQL-in sonundakı `alter publication` hissəsi lazımdır. SQL-i əvvəl işlətmisinizsə, yalnız həmin hissəni yenidən işlədin.
4. Realtime qoşulmasa belə tətbiq 20 saniyədən bir serverdəki dəyişikliyi yoxlayır, yəni sinxronizasiya yenə işləyir.
5. Açılışdakı sorğu layihəni aktiv saxlayır, beləliklə pulsuz layihə uzun müddət istifadəsizlikdən dayandırılmır.

## 9. Supabase-də bazaya baxmaq

1. Supabase panelində **Table Editor** bölməsini açın və `baza_sync` cədvəlini seçin.
2. `main` sətrində `data` xanasına toxunun, JSON açılır. Orada `edits`, `added_rows`, `deleted_rows`, `renames`, `imp_sheets`, `imp_rows` siyahıları görünür.
3. Daha rahat baxmaq üçün **SQL Editor** bölməsində `select updated_at, jsonb_pretty(data) from public.baza_sync where id = 'main';` sorğusunu işlədin.
4. Qeyd: serverdə bütün baza yox, yalnız telefonda edilmiş dəyişikliklər saxlanılır. Əsas baza APK-nın içindədir.

## 10. Təhlükəsizlik

`secret` və `service_role` açarları bütün qaydaları (RLS) keçir, yəni tam icazəlidir. Bu açar telefonda saxlanılır, ona görə yalnız şəxsi istifadə üçün münasibdir. APK-nı və açarı başqalarına verməyin, ictimai yerə yazmayın. Açar sızsa, Supabase panelində onu silib yenisini yaradın. Çoxlu istifadəçi üçün aralıq server və autentifikasiya qurmaq lazımdır.
