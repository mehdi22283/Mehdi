package com.mehdi.keymapper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

import java.util.concurrent.atomic.AtomicBoolean;

public class KeyMapperAccessibilityService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());

    private volatile String foregroundPackage = "";

    private final KeyState button5 = new KeyState(KeyEvent.KEYCODE_BUTTON_5);
    private final KeyState home = new KeyState(KeyEvent.KEYCODE_HOME);

    private final AtomicBoolean suppressInjectedHomeDown = new AtomicBoolean(false);
    private final AtomicBoolean suppressInjectedHomeUp = new AtomicBoolean(false);
    private MappingStore mappingStore;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            info.notificationTimeout = 0;
            setServiceInfo(info);
        }
        KeyInjectorClient.init(this);
        mappingStore = new MappingStore(this);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            CharSequence pkg = event.getPackageName();
            if (pkg != null && pkg.length() > 0) {
                foregroundPackage = pkg.toString();
            }
        }
    }

    @Override public void onInterrupt() {}

    @Override protected boolean onKeyEvent(KeyEvent event) {
        if (event == null) return false;

        final int code = event.getKeyCode();
        final int action = event.getAction();

        // Our own injected HOME must be passed through and not recursively intercepted.
        if (code == KeyEvent.KEYCODE_HOME) {
            if (action == KeyEvent.ACTION_DOWN && suppressInjectedHomeDown.compareAndSet(true, false)) return false;
            if (action == KeyEvent.ACTION_UP && suppressInjectedHomeUp.compareAndSet(true, false)) return false;
        }

        // Special long-press functions remain fixed, while normal mappings are editable.
        if (code == KeyEvent.KEYCODE_BUTTON_5) return handleButton5(event);
        if (code == KeyEvent.KEYCODE_HOME) return handleHome(event);
        MappingStore.Mapping found = null;
        if (mappingStore != null) {
            for (MappingStore.Mapping m : mappingStore.get()) if (m.enabled && m.source == code) { found=m; break; }
        }
        if (found != null) return handleMappedContinuous(event, found.target);
        return false;
    }

    private boolean handleMappedContinuous(KeyEvent original, int targetCode) {
        // The event is reproduced with the same downTime/eventTime/repeat count,
        // so short taps and the platform's native long/repeat behavior remain intact.
        KeyEvent mapped = cloneWithKeyCode(original, targetCode, original.getAction(), original.getFlags());
        return inject(mapped);
    }

    private boolean handleButton5(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (button5.down.compareAndSet(false, true)) {
                button5.downTime = e.getDownTime();
                button5.longTriggered.set(false);
                button5.originalDeviceId = e.getDeviceId();
                // Send CENTER down immediately: no tap delay.
                inject(cloneWithKeyCode(e, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.ACTION_DOWN, e.getFlags()));
                scheduleLongPress(button5, () -> {
                    if (!button5.down.get() || button5.longTriggered.get()) return;
                    button5.longTriggered.set(true);
                    // Cancel the already-sent CENTER down so an OK click is not completed.
                    KeyEvent canceledUp = makeSyntheticUp(
                            e, KeyEvent.KEYCODE_DPAD_CENTER,
                            KeyEvent.FLAG_CANCELED | KeyEvent.FLAG_CANCELED_LONG_PRESS);
                    inject(canceledUp);
                    launchOttPlayer();
                });
            }
            return true;
        }
        if (e.getAction() == KeyEvent.ACTION_UP) {
            if (button5.down.compareAndSet(true, false)) {
                handler.removeCallbacks(button5.longRunnable);
                if (!button5.longTriggered.get()) {
                    inject(cloneWithKeyCode(e, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.ACTION_UP, e.getFlags()));
                }
            }
            return true;
        }
        // Ignore hardware auto-repeat for BUTTON_5 while we manage the long press ourselves.
        return true;
    }

    private boolean handleHome(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (home.down.compareAndSet(false, true)) {
                home.downTime = e.getDownTime();
                home.longTriggered.set(false);
                home.originalDeviceId = e.getDeviceId();
                home.targetPackage = foregroundPackage;

                // HOME is injected immediately, preserving normal remote feel.
                suppressInjectedHomeDown.set(true);
                inject(cloneWithKeyCode(e, KeyEvent.KEYCODE_HOME, KeyEvent.ACTION_DOWN, e.getFlags()));

                scheduleLongPress(home, () -> {
                    if (!home.down.get() || home.longTriggered.get()) return;
                    home.longTriggered.set(true);
                    suppressInjectedHomeUp.set(true);
                    KeyEvent canceledUp = makeSyntheticUp(
                            e, KeyEvent.KEYCODE_HOME,
                            KeyEvent.FLAG_CANCELED | KeyEvent.FLAG_CANCELED_LONG_PRESS);
                    inject(canceledUp);
                    forceStop(home.targetPackage);
                });
            }
            return true;
        }

        if (e.getAction() == KeyEvent.ACTION_UP) {
            if (home.down.compareAndSet(true, false)) {
                handler.removeCallbacks(home.longRunnable);
                if (!home.longTriggered.get()) {
                    suppressInjectedHomeUp.set(true);
                    inject(cloneWithKeyCode(e, KeyEvent.KEYCODE_HOME, KeyEvent.ACTION_UP, e.getFlags()));
                }
            }
            return true;
        }
        return true;
    }

    private void scheduleLongPress(KeyState state, Runnable action) {
        state.longRunnable = action;
        handler.postDelayed(action, Config.LONG_PRESS_MS);
    }

    private void launchOttPlayer() {
        // Use privileged shell launch to avoid background-activity-start restrictions.
        String cmd = "am start --user 0 -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p " + Config.OTT_PACKAGE;
        KeyInjectorClient.execAsync(cmd);
    }

    private void forceStop(String packageName) {
        if (packageName == null || packageName.isEmpty()) return;
        if (Config.PACKAGE_NAME.equals(packageName)) return;
        String safe = packageName.replace("'", "");
        KeyInjectorClient.execAsync("am force-stop '" + safe + "'");
    }

    private boolean inject(KeyEvent event) {
        if (!KeyInjectorClient.isAvailable()) {
            return false;
        }
        return KeyInjectorClient.inject(event);
    }

    private static KeyEvent cloneWithKeyCode(KeyEvent src, int keyCode, int action, int flags) {
        return new KeyEvent(
                src.getDownTime(),
                src.getEventTime(),
                action,
                keyCode,
                src.getRepeatCount(),
                src.getMetaState(),
                src.getDeviceId(),
                src.getScanCode(),
                flags,
                src.getSource());
    }

    private static KeyEvent makeSyntheticUp(KeyEvent source, int code, int flags) {
        long now = android.os.SystemClock.uptimeMillis();
        return new KeyEvent(
                source.getDownTime(), now,
                KeyEvent.ACTION_UP,
                code,
                0,
                source.getMetaState(),
                source.getDeviceId(),
                source.getScanCode(),
                flags,
                source.getSource());
    }

    private static final class KeyState {
        final int keyCode;
        final AtomicBoolean down = new AtomicBoolean(false);
        final AtomicBoolean longTriggered = new AtomicBoolean(false);
        volatile long downTime;
        volatile int originalDeviceId;
        volatile String targetPackage = "";
        volatile Runnable longRunnable;

        KeyState(int keyCode) { this.keyCode = keyCode; }
    }
}
