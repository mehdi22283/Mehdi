KeyMapperTV
===========
1) Tetbiqi GitHub Actions ile qurun (build.yml) ve app-debug.apk fayli goturun.
2) TV-de "ADB debugging" (sebeke ADB, port 5555) aciq olmalidir.
   Port 5555 baglidirsa PC-den bir defe: adb tcpip 5555
3) Tetbiqi TV-de acin -> "ADB ile qosul" (ilk defe TV-de "Always allow" secin).
   Qosulanda elcatimliliq xidmeti ADB ile ozu aktiv olur (ayarlara girmek lazim deyil),
   suretli duyme gonderici (Injector) TV-de avtomatik baslayir.
4) Duymeleri tetbiqin daxilinde elave/redakte/sil ede bilersiniz.
