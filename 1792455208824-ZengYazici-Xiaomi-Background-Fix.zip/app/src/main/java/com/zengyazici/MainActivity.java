package com.zengyazici;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ComponentName;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int BG = 0xFF090D18, CARD = 0xFF131A2B, CARD_ALT = 0xFF192238,
            BLUE = 0xFF8B5CF6, GREEN = 0xFF2DD4BF, GRAY = 0xFF9AA8C7, TEXT = 0xFFF2F5FF;

    TextView tvStatus;
    TextView[] fb = new TextView[3];
    ListView lv;
    Adapter ad;
    List<Db.Item> all = new ArrayList<>(), shown = new ArrayList<>();
    int filter = 0, lastCount = -1;
    MediaPlayer mp;
    String playing;
    boolean dragging;
    SharedPreferences cfg;
    final Handler h = new Handler(Looper.getMainLooper());

    final Runnable tick = new Runnable() {
        @Override public void run() {
            refreshStatus();
            if (mp != null && !dragging) ad.notifyDataSetChanged();
            if (Db.all(MainActivity.this).size() != lastCount) reload();
            h.postDelayed(this, 700);
        }
    };

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    EditText field(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setHintTextColor(GRAY); e.setTextColor(TEXT);
        e.setInputType(type); e.setSingleLine(true); e.setTextSize(14);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD_ALT); bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), 0xFF29334D);
        e.setBackground(bg);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        return e;
    }

    Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextSize(13); b.setTextColor(TEXT);
        b.setOnClickListener(l); b.setMinHeight(dp(46)); b.setElevation(dp(1));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD_ALT); bg.setCornerRadius(dp(13));
        bg.setStroke(dp(1), 0xFF29334D);
        b.setBackground(bg);
        return b;
    }

    LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    LinearLayout.LayoutParams w1() { return new LinearLayout.LayoutParams(0, -2, 1f); }

    int num(EditText e) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception x) { return 0; }
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        cfg = getSharedPreferences("cfg", 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(16), dp(18), dp(16), dp(10));

        LinearLayout header = row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(logo, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(12), 0, 0, 0);
        TextView title = new TextView(this);
        title.setText("Zəng Yazıcı"); title.setTextColor(TEXT); title.setTextSize(23);
        title.setTypeface(null, Typeface.BOLD);
        brand.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Zəng qeydləri · Arxa plan xidməti");
        subtitle.setTextColor(GRAY); subtitle.setTextSize(12);
        brand.addView(subtitle);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(header);

        tvStatus = new TextView(this);
        tvStatus.setTextSize(13); tvStatus.setTextColor(TEXT);
        tvStatus.setPadding(dp(12), dp(11), dp(12), dp(11));
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(14); statusLp.bottomMargin = dp(10);
        GradientDrawable statusBg = new GradientDrawable();
        statusBg.setColor(CARD); statusBg.setCornerRadius(dp(14));
        statusBg.setStroke(dp(1), 0xFF222D45);
        tvStatus.setBackground(statusBg);
        root.addView(tvStatus, statusLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable cg = new GradientDrawable();
        cg.setColor(CARD); cg.setCornerRadius(dp(17));
        cg.setStroke(dp(1), 0xFF222D45);
        card.setBackground(cg);

        TextView menuCaption = new TextView(this);
        menuCaption.setText("İDARƏETMƏ"); menuCaption.setTextColor(GRAY);
        menuCaption.setTextSize(10); menuCaption.setTypeface(null, Typeface.BOLD);
        menuCaption.setPadding(dp(8), dp(2), dp(8), dp(4));
        card.addView(menuCaption);
        card.addView(btn("⚙   Parametrlər və fon qoruması", v -> showMenu()));
        root.addView(card);

        LinearLayout fr = row();
        fr.setPadding(0, dp(10), 0, dp(6));
        String[] names = {"Hamısı", "Gələn", "Gedən"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(names[i]); t.setGravity(Gravity.CENTER); t.setTextSize(14);
            t.setPadding(0, dp(8), 0, dp(8));
            t.setOnClickListener(v -> setFilter(idx));
            LinearLayout.LayoutParams lp = w1();
            lp.setMargins(dp(3), 0, dp(3), 0);
            fr.addView(t, lp);
            fb[i] = t;
        }
        root.addView(fr);

        lv = new ListView(this);
        lv.setDividerHeight(0);
        lv.setBackgroundColor(Color.TRANSPARENT);
        lv.setCacheColorHint(Color.TRANSPARENT);
        lv.setSelector(android.R.color.transparent);
        ad = new Adapter();
        lv.setAdapter(ad);
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        setFilter(0);
        new Thread(() -> {
            try { AdbMgr.get(this); } catch (Throwable e) { RecService.log("Açar: " + e); }
        }).start();
        askPerms();
        if (!RecService.running) startSvc();
        h.post(tick);
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacks(tick);
        stopPlay();
        super.onDestroy();
    }

    // ---------- əməliyyatlar ----------
    void askPerms() {
        List<String> p = new ArrayList<>(Arrays.asList(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG));
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(p.toArray(new String[0]), 1);
    }

    void setStatus(String t) { runOnUiThread(() -> { tvStatus.setText(t); tvStatus.setTextColor(Color.WHITE); }); }

    void doPair() {
        startSvc();
        PairHelper.start(this);
        setStatus("Bildiriş göndərildi. Ayarlar → Developer options → Wireless debugging → «Pair device with pairing code» açın və kodu bildirişdəki xanaya yazın.");
    }

    void doConnect() {
        setStatus("Qoşulur…");
        new Thread(() -> {
            try {
                Conn.ensure(this);
                runOnUiThread(this::startSvc);
            } catch (Throwable e) {
                RecService.log("connect: " + e);
                setStatus("Qoşulmadı: " + e.getMessage());
            }
        }).start();
    }

    void startSvc() {
        cfg.edit().putBoolean("autostart", true).apply();
        startForegroundService(new Intent(this, RecService.class));
    }

    void showMenu() {
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(8), dp(16), dp(8));
        String[] names = {"Cütləşdir (kod bildirişdən)", "Qoşul", "İcazələr", "Bildiriş girişi", "Əlçatımlılıq (aktiv et)", "Batareya optimizasiyası", "Xiaomi fon qoruması", "Tətbiq məlumatları", "Log"};
        final Runnable[] acts = {
                this::doPair,
                this::doConnect,
                this::askPerms,
                () -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)),
                () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)),
                () -> startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))),
                this::showBackgroundGuide,
                this::openAppDetails,
                this::showLog
        };
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            Button item = btn(names[i], v -> { dlg[0].dismiss(); acts[idx].run(); });
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-1, -2);
            itemLp.setMargins(0, dp(3), 0, dp(3));
            l.addView(item, itemLp);
        }
        dlg[0] = new AlertDialog.Builder(this).setTitle("Əməliyyatlar").setView(l).setNegativeButton("Bağla", null).create();
        dlg[0].show();
    }


    void showBackgroundGuide() {
        new AlertDialog.Builder(this)
                .setTitle("Xiaomi — arxa planda işləmə")
                .setMessage("Tətbiqin son proqramlar siyahısından bağlanandan sonra da işləməsi üçün Xiaomi/HyperOS ayarlarında bunları yoxlayın:\n\n"
                        + "1. Avtomatik başlatma — aktiv edin.\n"
                        + "2. Batareya qoruyucusu — Məhdudiyyət yoxdur seçin.\n"
                        + "3. Son proqramlarda Zəng Yazıcı kartını uzun basıb kilid işarəsi varsa aktiv edin.\n"
                        + "4. Tətbiqi ilk dəfə açın, telefon və bildiriş icazələrini verin; daimi xidmət bildirişi görünməlidir.\n\n"
                        + "Son proqramlardan silinmə zamanı xidmət saxlanılır və ehtiyat bərpa planı qurulur. Xiaomi bəzi versiyalarda bunu yenə məhdudlaşdıra bilər. Android-in Məcburi dayandırma (Force stop) əmri xidməti dayandırır; bu rejimdən tətbiq özü çıxa bilməz.")
                .setPositiveButton("Avtomatik başlatma", (d, w) -> openXiaomiAutostart())
                .setNeutralButton("Tətbiq məlumatları", (d, w) -> openAppDetails())
                .setNegativeButton("Bağla", null)
                .show();
    }

    void openXiaomiAutostart() {
        try {
            Intent i = new Intent();
            i.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable e) {
            Toast.makeText(this, "Avtomatik başlatma səhifəsi açılmadı. Tətbiq məlumatlarından batareya və autostart ayarlarını açın.", Toast.LENGTH_LONG).show();
            openAppDetails();
        }
    }

    void openAppDetails() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
        } catch (Throwable e) {
            Toast.makeText(this, "Tətbiq ayarları açıla bilmədi", Toast.LENGTH_SHORT).show();
        }
    }

    void refreshStatus() {
        boolean c = false;
        try { AdbMgr m = AdbMgr.peek(); c = m != null && m.isConnected(); } catch (Throwable e) { }
        tvStatus.setText("Xidmət: " + (RecService.running ? "işləyir" : "dayanıb") + "  ·  ADB: " + (c ? "qoşulub (" + Conn.mode + ")" : "qoşulmayıb"));
        tvStatus.setTextColor(c && RecService.running ? GREEN : 0xFFFF7043);
    }

    void showLog() {
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        synchronized (RecService.LOG) { t.setText(RecService.LOG.length() == 0 ? "(boşdur)" : RecService.LOG.toString()); }
        t.setTextIsSelectable(true); t.setTextSize(11); t.setPadding(dp(12), dp(8), dp(12), dp(8));
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("Log").setView(sv).setPositiveButton("Bağla", null).show();
    }

    // ---------- filter və siyahı ----------
    void setFilter(int f) {
        filter = f;
        for (int i = 0; i < 3; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(18));
            g.setColor(i == f ? (i == 1 ? GREEN : i == 2 ? BLUE : 0xFF616161) : CARD);
            fb[i].setBackground(g);
            fb[i].setTextColor(Color.WHITE);
        }
        applyFilter();
    }

    void reload() {
        all = Db.all(this);
        lastCount = all.size();
        applyFilter();
    }

    void applyFilter() {
        shown = new ArrayList<>();
        for (Db.Item it : all) {
            if (filter == 0 || (filter == 1 && "in".equals(it.dir)) || (filter == 2 && "out".equals(it.dir))) shown.add(it);
        }
        if (ad != null) ad.notifyDataSetChanged();
    }

    // ---------- pleyer ----------
    void stopPlay() {
        if (mp != null) { try { mp.release(); } catch (Exception e) { } mp = null; }
        playing = null;
    }

    void toggle(Db.Item it) {
        try {
            if (it.path.equals(playing) && mp != null) {
                if (mp.isPlaying()) mp.pause(); else mp.start();
            } else {
                stopPlay();
                mp = new MediaPlayer();
                mp.setDataSource(it.path);
                mp.prepare();
                mp.start();
                playing = it.path;
                mp.setOnCompletionListener(m -> { stopPlay(); ad.notifyDataSetChanged(); });
            }
        } catch (Exception e) {
            Toast.makeText(this, "Oxuna bilmədi: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        ad.notifyDataSetChanged();
    }

    static String fmt(int ms) {
        int s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    class Adapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int p) { return shown.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int p, View cv, ViewGroup parent) {
            final Db.Item it = shown.get(p);
            final boolean out = "out".equals(it.dir);
            final boolean cur = it.path.equals(playing) && mp != null;

            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(10), dp(10), dp(10));
            GradientDrawable itemBg = new GradientDrawable();
            itemBg.setColor(CARD); itemBg.setCornerRadius(dp(16));
            itemBg.setStroke(dp(1), 0xFF202A42);
            row.setBackground(itemBg);

            TextView ic = new TextView(MainActivity.this);
            ic.setText(out ? "↗" : "↙"); ic.setTextColor(TEXT); ic.setTextSize(20); ic.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL); g.setColor(out ? BLUE : GREEN);
            ic.setBackground(g);
            row.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));

            LinearLayout col = new LinearLayout(MainActivity.this);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
            cl.leftMargin = dp(12);
            row.addView(col, cl);

            TextView t1 = new TextView(MainActivity.this);
            t1.setText(it.num); t1.setTextColor(Color.WHITE); t1.setTextSize(16); t1.setTypeface(null, Typeface.BOLD);
            col.addView(t1);

            TextView t2 = new TextView(MainActivity.this);
            t2.setText(it.app + " · " + new SimpleDateFormat("dd.MM HH:mm", Locale.US).format(new Date(it.ts)));
            t2.setTextColor(GRAY); t2.setTextSize(12);
            col.addView(t2);

            LinearLayout bar = new LinearLayout(MainActivity.this);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            ImageButton pb = new ImageButton(MainActivity.this);
            pb.setBackgroundColor(0);
            pb.setImageResource(cur && mp.isPlaying() ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play);
            pb.setOnClickListener(v -> toggle(it));
            bar.addView(pb, new LinearLayout.LayoutParams(dp(40), dp(40)));

            SeekBar sb = new SeekBar(MainActivity.this);
            int total = cur ? mp.getDuration() : it.dur * 1000;
            sb.setMax(Math.max(total, 1));
            sb.setProgress(cur ? mp.getCurrentPosition() : 0);
            sb.setEnabled(cur);
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean u) { }
                @Override public void onStartTrackingTouch(SeekBar s) { dragging = true; }
                @Override public void onStopTrackingTouch(SeekBar s) {
                    if (mp != null && it.path.equals(playing)) mp.seekTo(s.getProgress());
                    dragging = false;
                }
            });
            bar.addView(sb, new LinearLayout.LayoutParams(0, -2, 1f));

            TextView tt = new TextView(MainActivity.this);
            tt.setText((cur ? fmt(mp.getCurrentPosition()) : "0:00") + " / " + fmt(total));
            tt.setTextColor(GRAY); tt.setTextSize(11);
            bar.addView(tt);
            col.addView(bar);

            row.setOnLongClickListener(v -> {
                new AlertDialog.Builder(MainActivity.this).setMessage("Bu yazı silinsin?")
                        .setPositiveButton("Sil", (d, w) -> {
                            if (it.path.equals(playing)) stopPlay();
                            new File(it.path).delete();
                            Db.remove(MainActivity.this, it);
                            reload();
                        }).setNegativeButton("Ləğv et", null).show();
                return true;
            });
            return row;
        }
    }
}
