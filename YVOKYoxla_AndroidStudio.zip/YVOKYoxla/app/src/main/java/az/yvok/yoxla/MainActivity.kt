package az.yvok.yoxla

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.util.Locale
import java.util.regex.Pattern

class MainActivity : Activity() {
    companion object {
        private const val PORTAL_URL = "https://gpp.yelo.az/search-to-pay/db6ed060-63f2-4085-88eb-c2f8fdb05b40"
        private const val PREFIX = "10011"
        private const val BG = 0xFF080D18.toInt()
        private const val CARD = 0xFF101A2B.toInt()
        private const val BLUE = 0xFF398BFF.toInt()
        private const val WHITE = 0xFFF4F7FC.toInt()
        private const val MUTED = 0xFF9EABC0.toInt()
    }

    private lateinit var suffixInput: EditText
    private lateinit var statusText: TextView
    private lateinit var payerValue: TextView
    private lateinit var yvokValue: TextView
    private lateinit var amountValue: TextView
    private lateinit var searchButton: Button
    private lateinit var webView: WebView

    @Volatile private var portalLoaded = false
    @Volatile private var portalLoadFailed = false
    private var pendingCode = ""
    private var lastSubmittedCode = ""
    private var pageDispatchCount = 0
    private var lookupGeneration = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = 0
        buildUi()
        configureWebView()
        webView.loadUrl(PORTAL_URL)
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(BG)
            fitsSystemWindows = true
        }
        root.addView(webViewPlaceholder(), FrameLayout.LayoutParams(-1, -1))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(20), dp(18), dp(20), dp(18))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content, ScrollView.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val mark = TextView(this).apply {
            text = "Y"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = shape(BLUE, BLUE, 18)
        }
        brandRow.addView(mark, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titles.addView(text("YVÖK Yoxla", 23f, WHITE, true))
        titles.addView(text("Yelo portalında borc məlumatı", 13f, MUTED, false).apply {
            setPadding(0, dp(3), 0, 0)
        })
        brandRow.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(brandRow)

        val intro = text("7 rəqəmi daxil edin. Son rəqəm yazılan kimi axtarış avtomatik başlayacaq.", 14f, MUTED, false)
        intro.setPadding(0, dp(22), 0, dp(14))
        content.addView(intro)

        val inputCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(CARD, 0xFF243550.toInt(), 18)
            setPadding(dp(16), dp(17), dp(16), dp(17))
        }
        inputCard.addView(text("YVÖK kodu", 14f, WHITE, true))
        val codeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(4))
        }
        val prefixView = TextView(this).apply {
            text = PREFIX
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(WHITE)
            gravity = Gravity.CENTER
            background = shape(0xFF172844.toInt(), BLUE, 12)
        }
        codeRow.addView(prefixView, LinearLayout.LayoutParams(dp(94), dp(55)))
        suffixInput = EditText(this).apply {
            textSize = 20f
            setTextColor(WHITE)
            setHintTextColor(0xFF71809A.toInt())
            hint = "7 rəqəm"
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(
                InputFilter.LengthFilter(7),
                InputFilter { source, start, end, _, _, _ ->
                    val inserted = source.subSequence(start, end)
                    if (inserted.all { it in '0'..'9' }) null else ""
                }
            )
            singleLine = true
            background = shape(0xFF0A1220.toInt(), 0xFF30425F.toInt(), 12)
            setPadding(dp(15), 0, dp(10), 0)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        }
        val inputParams = LinearLayout.LayoutParams(0, dp(55), 1f).apply {
            marginStart = dp(10)
        }
        codeRow.addView(suffixInput, inputParams)
        inputCard.addView(codeRow)
        inputCard.addView(text("Tam kod: 10011 + daxil etdiyiniz 7 rəqəm", 12f, MUTED, false).apply {
            setPadding(0, dp(8), 0, 0)
        })
        content.addView(inputCard)

        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shape(0xFF0C1728.toInt(), 0xFF1C3554.toInt(), 14)
            setPadding(dp(14), dp(13), dp(14), dp(13))
        }
        val statusDot = TextView(this).apply {
            text = "●"
            textSize = 13f
            setTextColor(BLUE)
        }
        statusCard.addView(statusDot)
        statusText = text("Yelo portalına qoşulur…", 13f, MUTED, false).apply {
            setPadding(dp(9), 0, 0, 0)
        }
        statusCard.addView(statusText, LinearLayout.LayoutParams(0, -2, 1f))
        val statusParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(13)
        }
        content.addView(statusCard, statusParams)

        val resultsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(CARD, 0xFF243550.toInt(), 18)
            setPadding(dp(17), dp(18), dp(17), dp(18))
        }
        val resultHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        resultHead.addView(text("Axtarış nəticəsi", 17f, WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        resultHead.addView(text("AZN", 12f, BLUE, true))
        resultsCard.addView(resultHead)
        val divider = View(this).apply { setBackgroundColor(0xFF26364F.toInt()) }
        resultsCard.addView(divider, LinearLayout.LayoutParams(-1, dp(1)).apply {
            topMargin = dp(14)
            bottomMargin = dp(4)
        })

        payerValue = addResultRow(resultsCard, "Ödəyən", "—")
        yvokValue = addResultRow(resultsCard, "YVÖK", "—")
        val amountRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(14), 0, dp(4))
        }
        amountRow.addView(text("Məbləğ (AZN)", 13f, MUTED, false))
        amountValue = text("—", 25f, BLUE, true).apply {
            setPadding(0, dp(5), 0, 0)
        }
        amountRow.addView(amountValue)
        resultsCard.addView(amountRow)
        val resultParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(16)
        }
        content.addView(resultsCard, resultParams)

        searchButton = Button(this).apply {
            text = "Yenidən axtar"
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = shape(BLUE, BLUE, 14)
            setPadding(dp(12), dp(4), dp(12), dp(4))
            setOnClickListener {
                val suffix = suffixInput.text?.toString().orEmpty()
                if (suffix.length == 7) {
                    startLookup(PREFIX + suffix, true)
                } else {
                    statusText.text = "Davam etmək üçün 7 rəqəm daxil edin."
                    suffixInput.requestFocus()
                }
            }
        }
        content.addView(searchButton, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(16)
        })

        content.addView(text("Məlumatlar Yelo Bank portalından oxunur. Tətbiq ödəniş etmir.", 12f, MUTED, false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(18), dp(5), dp(3))
        })
        content.addView(text("gpp.yelo.az", 12f, 0xFF6D86A9.toInt(), false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, dp(12))
        })

        setContentView(root)

        suffixInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val suffix = s?.toString().orEmpty()
                if (suffix.length == 7) {
                    val code = PREFIX + suffix
                    if (code != lastSubmittedCode || before < 7) startLookup(code, code == lastSubmittedCode)
                } else if (suffix.isEmpty()) {
                    lastSubmittedCode = ""
                    pendingCode = ""
                    payerValue.text = "—"
                    yvokValue.text = "—"
                    amountValue.text = "—"
                    statusText.text = if (portalLoaded) "7 rəqəm daxil edin." else "Yelo portalına qoşulur…"
                }
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun webViewPlaceholder(): View {
        webView = WebView(this).apply {
            visibility = View.INVISIBLE
            overScrollMode = View.OVER_SCROLL_NEVER
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        return webView
    }

    private fun addResultRow(parent: LinearLayout, label: String, initial: String): TextView {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(13), 0, dp(4))
        }
        row.addView(text(label, 13f, MUTED, false))
        val value = text(initial, 15f, WHITE, true).apply {
            setPadding(0, dp(5), 0, 0)
        }
        row.addView(value)
        parent.addView(row)
        return value
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = true
    }

    private fun shape(fill: Int, stroke: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = false
            displayZoomControls = false
            userAgentString = userAgentString + " YVOKYoxla/1.0"
        }
        webView.addJavascriptInterface(PortalBridge(), "AndroidBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val host = uri.host.orEmpty().lowercase(Locale.ROOT)
                if (host == "yelo.az" || host.endsWith(".yelo.az")) return false
                if (request.isForMainFrame) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (_: Exception) {
                        runOnUiThread { statusText.text = "Portal səhifəsini açmaq mümkün olmadı." }
                    }
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                portalLoaded = false
                portalLoadFailed = false
                runOnUiThread {
                    if (pendingCode.isNotEmpty()) statusText.text = "Yelo portalının səhifəsi açılır…"
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                portalLoaded = true
                portalLoadFailed = false
                view?.evaluateJavascript(portalScript(), null)
                runOnUiThread {
                    if (pendingCode.isEmpty()) statusText.text = "7 rəqəm daxil edin."
                }
                if (pendingCode.isNotEmpty() && pageDispatchCount < 2) {
                    pageDispatchCount++
                    dispatchLookup(pendingCode)
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    portalLoadFailed = true
                    runOnUiThread {
                        statusText.text = "Yelo portalına qoşulmaq olmadı. İnterneti yoxlayın və yenidən sınayın."
                    }
                }
            }
        }
        webView.setDownloadListener { _, _, _, _, _ ->
            runOnUiThread { statusText.text = "Portal fayl yükləməsi istədi; bu tətbiq yalnız məlumat axtarır." }
        }
    }

    private fun startLookup(code: String, force: Boolean) {
        if (!force && code == lastSubmittedCode) return
        pendingCode = code
        lastSubmittedCode = code
        pageDispatchCount = 0
        lookupGeneration++
        payerValue.text = "Axtarılır…"
        yvokValue.text = code
        amountValue.text = "—"
        statusText.text = if (portalLoaded) "YVÖK saytda axtarılır…" else "Portal açılır, axtarış başlayacaq…"
        try {
            val manager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            manager.hideSoftInputFromWindow(suffixInput.windowToken, 0)
        } catch (_: Exception) { }
        if (portalLoaded) {
            dispatchLookup(code)
        } else if (portalLoadFailed) {
            portalLoadFailed = false
            pageDispatchCount = 0
            webView.loadUrl(PORTAL_URL)
        }
    }

    private fun dispatchLookup(code: String) {
        if (!portalLoaded) return
        val safeCode = JSONObject.quote(code)
        webView.post {
            webView.evaluateJavascript("if (window.nativeYvokLookup) { window.nativeYvokLookup($safeCode); }", null)
        }
    }

    private inner class PortalBridge {
        @JavascriptInterface
        fun onPortalStatus(message: String) {
            runOnUiThread {
                if (pendingCode.isNotEmpty() && message.isNotBlank()) statusText.text = message
            }
        }

        @JavascriptInterface
        fun onPortalResult(jsonText: String) {
            runOnUiThread {
                try {
                    val json = JSONObject(jsonText)
                    val name = json.optString("name", "").trim()
                    val code = json.optString("yvok", "").trim().ifBlank { pendingCode }
                    val amount = json.optString("amount", "").trim()
                    if (name.isNotBlank() && amount.isNotBlank()) {
                        payerValue.text = name
                        yvokValue.text = code
                        amountValue.text = normalizeAmount(amount)
                        statusText.text = "Axtarış tamamlandı."
                        pendingCode = ""
                        pageDispatchCount = 0
                    } else {
                        val message = json.optString("message", "Nəticədə tələb olunan məlumatların hamısı tapılmadı.")
                        statusText.text = message
                        if (json.optBoolean("terminal", false)) pendingCode = ""
                    }
                } catch (_: Exception) {
                    statusText.text = "Sayt nəticəsini oxumaq mümkün olmadı. Yenidən sınayın."
                }
            }
        }

        @JavascriptInterface
        fun onPortalError(message: String) {
            runOnUiThread {
                statusText.text = message.ifBlank { "Saytda axtarış alınmadı. Yenidən sınayın." }
            }
        }
    }

    private fun normalizeAmount(raw: String): String {
        val trimmed = raw.replace("\u00A0", " ").replace('−', '-').trim()
        val match = Pattern.compile("[-+]?\\d+(?:[.,]\\d+)?").matcher(trimmed)
        if (!match.find()) return trimmed.ifBlank { "—" }
        val number = match.group().replace(',', '.').toDoubleOrNull() ?: return trimmed
        val normalized = if (number < 0.0) 0.0 else number
        return String.format(Locale.US, "%.2f", normalized)
    }

    private fun portalScript(): String = """
        (function() {
          if (window.__yvokHelperInstalled) return;
          window.__yvokHelperInstalled = true;
          function tellStatus(s) { try { if (window.AndroidBridge) AndroidBridge.onPortalStatus(String(s)); } catch(e) {} }
          function tellError(s) { try { if (window.AndroidBridge) AndroidBridge.onPortalError(String(s)); } catch(e) {} }
          function clean(s) { return (s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim(); }
          function visible(el) { if (!el) return false; const r=el.getBoundingClientRect(); const st=getComputedStyle(el); return r.width>0 && r.height>0 && st.display!=='none' && st.visibility!=='hidden'; }
          function labelRegex() { return /^(ödəyən|odəyən|yvök|yvok|məbləğ\s*\(\s*azn\s*\)|mebleg\s*\(\s*azn\s*\))\s*:?$/i; }
          function fieldValueNearLabel(labelRe) {
            const labels = Array.from(document.querySelectorAll('label,span,div,p,td,th,strong,b,dt,dd,small,legend'));
            for (const el of labels) {
              const t = clean(el.innerText || el.textContent);
              if (!t || t.length > 90 || !labelRe.test(t.replace(/:$/, '').trim())) continue;
              const explicitFor = el.getAttribute('for');
              if (explicitFor) { const linked=document.getElementById(explicitFor); if (linked && 'value' in linked && clean(linked.value)) return clean(linked.value); }
              let sib=el.nextElementSibling;
              if (sib) {
                if ('value' in sib && clean(sib.value)) return clean(sib.value);
                const st=clean(sib.innerText || sib.textContent);
                if (st && !labelRegex().test(st)) return st;
              }
              let parent=el;
              for (let level=0; level<4 && parent; level++, parent=parent.parentElement) {
                const controls=Array.from(parent.querySelectorAll('input,textarea,select')).filter(visible);
                for (const c of controls) {
                  const v=clean(c.value || c.options?.[c.selectedIndex]?.text || '');
                  if (v && !labelRe.test(v)) return v;
                }
                const lines=(parent.innerText || '').split(/\r?\n/).map(clean).filter(Boolean);
                const idx=lines.findIndex(line => labelRe.test(line.replace(/:$/, '').trim()));
                if (idx>=0 && lines[idx+1] && !labelRegex().test(lines[idx+1])) return lines[idx+1];
                const txt=clean(parent.innerText || '');
                const compact=txt.match(new RegExp('(?:ödəyən|odəyən|yvök|yvok|məbləğ\\s*\\(\\s*azn\\s*\\))\\s*:?\\s*([^\\n]{1,100})','i'));
                if (compact && clean(compact[1]) && !labelRegex().test(clean(compact[1]))) return clean(compact[1]);
              }
            }
            return '';
          }
          function lineValue(labels) {
            const lines=(document.body?.innerText || '').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
            const labelRe=new RegExp('^\\s*(?:'+labels+')\\s*:?\\s*(.*?)\\s*$','i');
            for (let i=0;i<lines.length;i++) {
              const m=lines[i].match(labelRe);
              if (m) {
                const inline=clean(m[1]);
                if (inline && !labelRegex().test(inline)) return inline;
                if (lines[i+1] && !labelRegex().test(lines[i+1]) && !/^axtar(ış)?$/i.test(lines[i+1])) return clean(lines[i+1]);
              }
            }
            return '';
          }
          function extractResult() {
            const name = fieldValueNearLabel(/^(ödəyən|odəyən)\s*:?$/i) || lineValue('ödəyən|odəyən');
            const yvok = fieldValueNearLabel(/^yv[oö]k\s*:?$/i) || lineValue('yv[oö]k|yvok');
            let amount = fieldValueNearLabel(/^məbləğ\s*\(\s*azn\s*\)\s*:?$/i) || fieldValueNearLabel(/^mebleg\s*\(\s*azn\s*\)\s*:?$/i) || lineValue('məbləğ\\s*\\(\\s*azn\\s*\\)|mebleg\\s*\\(\\s*azn\\s*\\)');
            if (!amount) {
              const inputs=Array.from(document.querySelectorAll('input,textarea')).filter(visible);
              for (const input of inputs) {
                const hint=clean([input.name,input.id,input.placeholder,input.getAttribute('aria-label')].join(' '));
                const near=clean(input.parentElement?.parentElement?.innerText || input.parentElement?.innerText || '');
                if (/məbləğ|mebleg|amount/i.test(hint+' '+near) && clean(input.value)) { amount=clean(input.value); break; }
              }
            }
            return {name:name, yvok:yvok, amount:amount};
          }
          function reportIfReady(code, previousSignature) {
            const r=extractResult();
            const signature=JSON.stringify(r);
            const codeDigits=String(code || '').replace(/\D/g, '');
            const resultDigits=String(r.yvok || '').replace(/\D/g, '');
            const matchesCode=resultDigits && codeDigits && resultDigits.indexOf(codeDigits)>=0;
            const changedWithoutYvok=!resultDigits && signature!==previousSignature;
            if (r.name && r.amount && (matchesCode || changedWithoutYvok)) {
              try { AndroidBridge.onPortalResult(JSON.stringify(r)); } catch(e) {}
              window.__yvokSearchActive=false;
              return true;
            }
            const body=clean(document.body?.innerText || '').toLowerCase();
            if (/məlumat tapılmadı|melumat tapilmadi|nəticə tapılmadı|netice tapilmadi|uyğun nəticə yoxdur|uygun netice yoxdur/.test(body)) {
              try { AndroidBridge.onPortalResult(JSON.stringify({message:'YVÖK üzrə məlumat tapılmadı.',terminal:true})); } catch(e) {}
              window.__yvokSearchActive=false;
              return true;
            }
            return false;
          }
          window.nativeYvokLookup = function(code) {
            tellStatus('YVÖK saytda axtarılır…');
            const previousSignature=JSON.stringify(extractResult());
            const allInputs=Array.from(document.querySelectorAll('input:not([type=hidden]),textarea')).filter(el => visible(el) && !el.disabled && el.type!=='submit' && el.type!=='button');
            const related=(el)=>clean([el.name,el.id,el.placeholder,el.getAttribute('aria-label'),el.labels ? Array.from(el.labels).map(x=>x.innerText).join(' ') : '',el.parentElement?.innerText || '',el.parentElement?.parentElement?.innerText || ''].join(' '));
            let input=allInputs.find(el => /yv[oö]k|vergi.?kod|voen|v[oö]en|identifikator/i.test(related(el)));
            if (!input && allInputs.length===1) input=allInputs[0];
            if (!input && allInputs.length>1) input=allInputs.find(el => /text|number|tel/i.test(el.type || 'text'));
            if (!input) {
              const existing=extractResult();
              const existingDigits=String(existing.yvok || '').replace(/\D/g, '');
              const wantedDigits=String(code || '').replace(/\D/g, '');
              if (existing.name && existing.amount && existingDigits && existingDigits.indexOf(wantedDigits)>=0) {
                try { AndroidBridge.onPortalResult(JSON.stringify(existing)); } catch(e) {}
                return;
              }
              tellStatus('Saytda YVÖK xanası tapılmadı. Portalın yüklənməsini yoxlayın.');
              tellError('Saytda YVÖK xanası tapılmadı.');
              return;
            }
            try {
              const proto=Object.getPrototypeOf(input);
              const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;
              if (setter) setter.call(input, code); else input.value=code;
              input.dispatchEvent(new Event('input',{bubbles:true}));
              input.dispatchEvent(new Event('change',{bubbles:true}));
              input.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'Enter'}));
            } catch(e) { input.value=code; }
            const searchButtons=Array.from(document.querySelectorAll('button,input[type=submit],[role=button],a')).filter(visible);
            let button=searchButtons.find(el => /^(axtarış|axtar|search|find)$/i.test(clean(el.innerText || el.value || el.getAttribute('aria-label') || el.title)));
            if (!button) button=searchButtons.find(el => /axtarış|axtar|search/i.test(clean(el.innerText || el.value || el.getAttribute('aria-label') || el.title)));
            tellStatus('YVÖK daxil edildi, axtarış göndərilir…');
            if (button) button.click();
            else if (input.form) {
              try { if (input.form.requestSubmit) input.form.requestSubmit(); else input.form.submit(); }
              catch(e) { tellError('Axtarış düyməsini basmaq mümkün olmadı.'); return; }
            } else {
              tellError('Saytda axtarış düyməsi tapılmadı.');
              return;
            }
            let ticks=0;
            window.__yvokSearchActive=true;
            window.__yvokActiveCode=code;
            window.__yvokPreviousSignature=previousSignature;
            if (window.__yvokPoll) clearInterval(window.__yvokPoll);
            window.__yvokPoll=setInterval(function() {
              ticks++;
              if (reportIfReady(code, previousSignature)) { clearInterval(window.__yvokPoll); window.__yvokPoll=null; }
              else if (ticks>35) {
                clearInterval(window.__yvokPoll); window.__yvokPoll=null;
                tellStatus('Cavab alınmadı. İnterneti yoxlayın və yenidən axtarın.');
              }
            },600);
          };
          try {
            const observer=new MutationObserver(function(){
              if (window.__yvokPoll && window.__yvokSearchActive) reportIfReady(window.__yvokActiveCode, window.__yvokPreviousSignature);
            });
            if (document.documentElement) observer.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
          } catch(e) {}
        })();
    """.trimIndent()

    override fun onDestroy() {
        try {
            webView.stopLoading()
            webView.removeJavascriptInterface("AndroidBridge")
            webView.destroy()
        } catch (_: Exception) { }
        super.onDestroy()
    }
}
