package com.example.callrec;

import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import java.io.*;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import org.spongycastle.asn1.x500.X500Name;
import org.spongycastle.cert.X509CertificateHolder;
import org.spongycastle.cert.jcajce.JcaX509CertificateConverter;
import org.spongycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.spongycastle.operator.ContentSigner;
import org.spongycastle.operator.jcajce.JcaContentSignerBuilder;

/** Açarlar fayla yazılır, beləcə cütləşdirmə bir dəfə kifayətdir. */
public class AdbConnectionManager extends AbsAdbConnectionManager {
    private static AdbConnectionManager INSTANCE;
    private PrivateKey mPrivateKey;
    private Certificate mCertificate;

    public static synchronized AdbConnectionManager getInstance(Context c) throws Exception {
        if (INSTANCE == null) INSTANCE = new AdbConnectionManager(c.getApplicationContext());
        return INSTANCE;
    }

    private AdbConnectionManager(Context c) throws Exception {
        setApi(Build.VERSION.SDK_INT);
        File kf = new File(c.getFilesDir(), "adb_key.pk8");
        File cf = new File(c.getFilesDir(), "adb_cert.der");
        if (kf.exists() && cf.exists()) {
            mPrivateKey = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(read(kf)));
            mCertificate = CertificateFactory.getInstance("X.509")
                    .generateCertificate(new ByteArrayInputStream(read(cf)));
            return;
        }
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        mPrivateKey = kp.getPrivate();

        X500Name name = new X500Name("CN=CallRec");
        Date notBefore = new Date(System.currentTimeMillis() - 86400000L);
        Date notAfter = new Date(System.currentTimeMillis() + 3650L * 86400000L);
        JcaX509v3CertificateBuilder b = new JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(System.currentTimeMillis()), notBefore, notAfter, name, kp.getPublic());
        ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").build(mPrivateKey);
        X509CertificateHolder holder = b.build(signer);
        X509Certificate cert = new JcaX509CertificateConverter().getCertificate(holder);
        mCertificate = cert;
        write(kf, mPrivateKey.getEncoded());
        write(cf, cert.getEncoded());
    }

    private static byte[] read(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[4096]; int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return o.toByteArray();
        }
    }
    private static void write(File f, byte[] d) throws IOException {
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(d); }
    }

    @NonNull @Override protected PrivateKey getPrivateKey() { return mPrivateKey; }
    @NonNull @Override protected Certificate getCertificate() { return mCertificate; }
    @NonNull @Override protected String getDeviceName() { return "CallRec"; }
}
