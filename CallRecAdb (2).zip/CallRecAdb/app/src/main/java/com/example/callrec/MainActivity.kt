package com.example.callrec

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val info = TextView(this).apply {
            setPadding(40, 40, 40, 20)
            text = "Zəng Yazıcı (özü-özünə ADB)\n\n" +
                "Bir dəfəlik quraşdırma (Wi-Fi lazımdır):\n" +
                "1) Developer options → Wireless debugging → aç\n" +
                "2) \"Başlat\" bas → \"Cütləşdirmə lazımdır\" bildirişi çıxacaq\n" +
                "3) Wireless debugging → \"Pair device with pairing code\" (pəncərəni bağlama)\n" +
                "4) Bildiriş pərdəsini aç, xanaya \"PORT KOD\" yaz (məs: 37215 123456), göndər\n" +
                "5) Tətbiq özü TCP 5555 rejiminə keçir — bundan sonra Wi-Fi olmadan da işləyir (yenidən başlayana qədər)."
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        setContentView(ScrollView(this).apply { addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(info)
            addView(btn("Developer options") { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) })
            addView(btn("Batareya optimallaşdırmasını söndür") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName"))) })
            addView(btn("Cütləşdirmə bildirişini göstər") { Notif.pairPrompt(this@MainActivity) })
            addView(btn("Başlat") {
                startForegroundService(Intent(this@MainActivity, RecorderService::class.java)) })
            addView(btn("Dayandır") {
                stopService(Intent(this@MainActivity, RecorderService::class.java))
                Thread { RecorderClient(this@MainActivity).quit() }.start() })
        }) })
        requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
    }
}
