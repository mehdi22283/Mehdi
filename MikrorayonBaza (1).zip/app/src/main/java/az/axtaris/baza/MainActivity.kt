package az.axtaris.baza

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.util.Locale

data class Card(val path: String, val title: String, val headers: List<String>, val cells: List<String>, val rowId: Long = -1L)

private const val TAX_URL = "https://e-belediyye.gov.az/tax-debts"
private const val WORKERS = 3

// ---- saytda YVÖK xanasını doldurub "Yoxla" düyməsinə basan skriptlər ----
private const val JS_FINDER = """
function vis(e){return !!(e&&(e.offsetWidth||e.offsetHeight||(e.getClientRects&&e.getClientRects().length)));}
function findForm(){
  var inp=null,btn=null;
  var inputs=document.querySelectorAll('input');
  for(var i=0;i<inputs.length;i++){var t=(inputs[i].type||'text').toLowerCase();
    if((t==='text'||t==='search'||t==='tel'||t==='')&&!inputs[i].disabled&&vis(inputs[i])){inp=inputs[i];break;}}
  var bs=document.querySelectorAll('button,input[type=submit],input[type=button],a');
  for(var j=0;j<bs.length;j++){var tx=((bs[j].innerText||bs[j].value||'')+'').replace(/\s+/g,' ').trim().toLowerCase();
    if(tx==='yoxla'&&vis(bs[j])){btn=bs[j];break;}}
  return {inp:inp,btn:btn};
}
"""
private const val JS_READY = "(function(){" + JS_FINDER +
    "var f=findForm();return JSON.stringify({ok:!!(f.inp&&f.btn),text:document.body?document.body.innerText:''});})()"
private const val JS_STATE = "(function(){return JSON.stringify({text:document.body?document.body.innerText:''});})()"

private fun jsFill(code: String): String = "(function(code){" + JS_FINDER +
    "var f=findForm();if(!f.inp||!f.btn)return 'noform';" +
    "var set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;" +
    "f.inp.focus();set.call(f.inp,code);" +
    "f.inp.dispatchEvent(new Event('input',{bubbles:true}));" +
    "f.inp.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true}));" +
    "f.inp.dispatchEvent(new Event('change',{bubbles:true}));" +
    "setTimeout(function(){f.btn.click();},150);return 'ok';})(" + JSONObject.quote(code) + ")"

class MainActivity : Activity() {

    private lateinit var db: SQLiteDatabase
    private lateinit var editsDb: SQLiteDatabase
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var mainSearch: SearchUi
    private lateinit var catSearch: SearchUi
    private lateinit var searchPanel: LinearLayout
    private lateinit var catPanel: LinearLayout
    private lateinit var btnSearch: Button
    private lateinit var btnCat: Button
    private lateinit var webHost: FrameLayout
    private var refresher: Refresher? = null

    // catalog state
    private lateinit var tvPath: TextView
    private lateinit var tvTotal: TextView
    private lateinit var catList: ListView
    private val cardAdapterCat by lazy { CardAdapter() }
    private var level = 0
    private var fileId = 0L
    private var streetId = 0L
    private var buildingId = 0L
    private var fileName = ""
    private var streetName = ""
    private var catIds = ArrayList<Long>()
    private var catNames = ArrayList<String>()
    private var catCounts = ArrayList<Int>()
    private var catBorc = ArrayList<Double>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = openDb()
        buildUi()
        showTab(true)
    }

    // ---------- database ----------
    private fun openDb(): SQLiteDatabase {
        // redaktələr və saytdan çəkilən məlumatlar ayrıca faylda da saxlanılır ki, baza yenilənəndə itməsin
        editsDb = openOrCreateDatabase("edits.db", MODE_PRIVATE, null)
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS edits(file TEXT, sheet TEXT, ord INTEGER, col INTEGER, value TEXT, PRIMARY KEY(file, sheet, ord, col))")
        val f = File(filesDir, "data.db")
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val ver = 4
        var fresh = false
        if (!f.exists() || prefs.getInt("dbver", 0) != ver) {
            assets.open("data.db").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            prefs.edit().putInt("dbver", ver).apply()
            fresh = true
        }
        val d = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READWRITE)
        if (fresh) replayEdits(d)
        return d
    }

    private fun replayEdits(d: SQLiteDatabase) {
        editsDb.rawQuery("SELECT file, sheet, ord, col, value FROM edits", null).use { c ->
            while (c.moveToNext()) {
                d.rawQuery(
                    "SELECT r.id, r.cells, b.headers FROM rows r JOIN buildings b ON b.id = r.building_id " +
                        "JOIN files f ON f.id = b.file_id WHERE f.name = ? AND b.sheet = ? AND r.ord = ?",
                    arrayOf(c.getString(0), c.getString(1), c.getInt(2).toString())
                ).use { r ->
                    if (r.moveToFirst()) {
                        val cells = jsonList(r.getString(1)).toMutableList()
                        val col = c.getInt(3)
                        while (cells.size <= col) cells.add("")
                        cells[col] = c.getString(4)
                        writeRow(d, r.getLong(0), cells, jsonList(r.getString(2)))
                    }
                }
            }
        }
    }

    private fun fold(s: String): String {
        var t = s.replace('İ', 'i').replace('I', 'ı').lowercase(Locale.ROOT)
        t = t.replace('ə', 'e').replace('ı', 'i').replace('ö', 'o').replace('ü', 'u')
            .replace('ş', 's').replace('ç', 'c').replace('ğ', 'g')
        return t.trim().replace(Regex("\\s+"), " ")
    }

    private fun jsonList(s: String): List<String> {
        val a = JSONArray(s); return List(a.length()) { a.getString(it) }
    }

    private fun colIdx(headers: List<String>, prefix: String) = headers.indexOfFirst { fold(it).startsWith(prefix) }

    /** Ad, Soyad, Atasının adı və Borc sütunları əl ilə redaktə olunmur (saytdan yenilənir) */
    private fun isReadOnly(h: String): Boolean {
        val f = fold(h)
        return f.startsWith("soyad") || f.startsWith("ad, soyad") || f.startsWith("ad,soyad") || f == "borc"
    }

    private fun nameIdx(headers: List<String>) = headers.indexOfFirst { isReadOnly(it) && fold(it) != "borc" }

    private fun parseNum(s: String): Double =
        s.replace("\u00A0", "").replace(" ", "").replace(',', '.').toDoubleOrNull() ?: 0.0

    private fun money(v: Double) = String.format(Locale.US, "%.2f", v)
    private fun totalText(borc: Double, count: Int) = "Ümumi Borc (${money(borc)}) / Ümumi Mənzil ($count)"

    private fun writeRow(d: SQLiteDatabase, id: Long, cells: List<String>, headers: List<String>) {
        d.execSQL("UPDATE rows SET cells = ? WHERE id = ?", arrayOf<Any>(JSONArray(cells).toString(), id))
        val mi = colIdx(headers, "menzil")
        if (mi >= 0 && mi < cells.size) d.execSQL("UPDATE rows SET menzil = ?, menzil_n = ? WHERE id = ?", arrayOf<Any>(cells[mi], fold(cells[mi]), id))
        val ni = colIdx(headers, "nomre")
        if (ni >= 0 && ni < cells.size) d.execSQL("UPDATE rows SET nomre_d = ? WHERE id = ?", arrayOf<Any>(cells[ni].filter { it.isDigit() }, id))
        val si = nameIdx(headers)
        if (si >= 0 && si < cells.size) {
            val toks = cells[si].trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            val so = toks.getOrElse(0) { "" }; val ad = toks.getOrElse(1) { "" }; val at = toks.drop(2).joinToString(" ")
            d.execSQL(
                "UPDATE rows SET soyad = ?, ad = ?, ata = ?, soyad_n = ?, ad_n = ?, ata_n = ? WHERE id = ?",
                arrayOf<Any>(so, ad, at, fold(so), fold(ad), fold(at), id)
            )
        }
        val bi = colIdx(headers, "borc")
        if (bi >= 0 && bi < cells.size) d.execSQL("UPDATE rows SET borc = ? WHERE id = ?", arrayOf<Any>(parseNum(cells[bi]), id))
    }

    private fun rowOf(vararg items: Pair<View, Float>): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            items.forEachIndexed { i, (v, w) ->
                addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w).apply {
                    if (i > 0) leftMargin = dp(6)
                })
            }
        }

    // ---------- əl ilə redaktə ----------
    private fun showEditDialog(card: Card, onSaved: (List<String>) -> Unit) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val inputs = arrayOfNulls<EditText>(card.headers.size)
        for (i in card.headers.indices) {
            val h = card.headers[i]
            val v = card.cells.getOrNull(i).orEmpty()
            val label = TextView(this)
            label.text = h; label.textSize = 12f; label.setTextColor(Color.GRAY); label.setPadding(0, dp(10), 0, 0)
            col.addView(label)
            if (isReadOnly(h)) {
                val t = TextView(this)
                t.text = (if (v.isEmpty()) "—" else v) + "   🔒"; t.textSize = 15f; t.setTextColor(Color.GRAY)
                col.addView(t)
            } else {
                val e = EditText(this)
                e.setText(v); e.textSize = 15f; e.isSingleLine = true
                inputs[i] = e
                col.addView(e)
            }
        }
        val sv = ScrollView(this)
        sv.setPadding(dp(20), dp(8), dp(20), 0)
        sv.addView(col)
        AlertDialog.Builder(this)
            .setTitle("Redaktə et")
            .setView(sv)
            .setPositiveButton("Yadda saxla") { _, _ -> saveEdit(card, inputs, onSaved) }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun saveEdit(card: Card, inputs: Array<EditText?>, onSaved: (List<String>) -> Unit) {
        val newCells = card.cells.toMutableList()
        while (newCells.size < card.headers.size) newCells.add("")
        db.rawQuery(
            "SELECT f.name, b.sheet, r.ord FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.id = ?", arrayOf(card.rowId.toString())
        ).use { c ->
            if (c.moveToFirst()) {
                val fname = c.getString(0); val sheet = c.getString(1); val ord = c.getInt(2)
                for (i in inputs.indices) {
                    val e = inputs[i] ?: continue
                    val nv = e.text.toString().trim()
                    if (nv != newCells[i]) {
                        newCells[i] = nv
                        editsDb.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", arrayOf<Any>(fname, sheet, ord, i, nv))
                    }
                }
            }
        }
        writeRow(db, card.rowId, newCells, card.headers)
        onSaved(newCells)
        Toast.makeText(this, "Yadda saxlanıldı", Toast.LENGTH_SHORT).show()
    }

    // =====================================================================
    //  Saytdan yeniləmə (Soyad, Ad, Atasının adı və Borc)
    // =====================================================================
    data class Job(val rowId: Long, val yvok: String)
    data class Parsed(val name: String?, val borc: String?, val notFound: Boolean, val raw: String)

    private fun validYvok(v: String): Boolean {
        val t = v.trim()
        return t.length == 12 && t.startsWith("10011") && t.none { it.isWhitespace() }
    }

    /** scopeSql/arg və ya ids əsasında yenilənəcək mənzilləri toplayıb (arxa planda) işə salır */
    private fun startRefresh(label: String, scopeSql: String?, arg: String?, ids: List<Long>?) {
        if (refresher != null) { Toast.makeText(this, "Yenilənmə artıq davam edir", Toast.LENGTH_SHORT).show(); return }
        Thread {
            val jobs = ArrayList<Job>()
            var noYvok = 0
            val sql: String; val args: Array<String>
            if (ids != null) {
                if (ids.isEmpty()) { sql = ""; args = emptyArray() }
                else {
                    sql = "SELECT r.id, r.cells, b.headers FROM rows r JOIN buildings b ON b.id = r.building_id WHERE r.id IN (" +
                        ids.joinToString(",") + ") ORDER BY b.file_id, b.ord, r.ord"
                    args = emptyArray()
                }
            } else {
                sql = "SELECT r.id, r.cells, b.headers FROM rows r JOIN buildings b ON b.id = r.building_id " +
                    (if (scopeSql != null) "WHERE $scopeSql " else "") + "ORDER BY b.file_id, b.ord, r.ord"
                args = if (arg != null) arrayOf(arg) else emptyArray()
            }
            if (sql.isNotEmpty()) {
                try {
                    db.rawQuery(sql, args).use { c ->
                        while (c.moveToNext()) {
                            val headers = jsonList(c.getString(2))
                            val yi = colIdx(headers, "yvok")
                            val cells = jsonList(c.getString(1))
                            val v = if (yi >= 0 && yi < cells.size) cells[yi].trim() else ""
                            if (validYvok(v)) jobs.add(Job(c.getLong(0), v)) else noYvok++
                        }
                    }
                } catch (e: Exception) { /* ignore */ }
            }
            runOnUiThread { confirmRefresh(label, jobs, noYvok) }
        }.start()
    }

    private fun confirmRefresh(label: String, jobs: List<Job>, noYvok: Int) {
        if (jobs.isEmpty()) {
            Toast.makeText(this, "Yenilənəcək YVÖK tapılmadı", Toast.LENGTH_LONG).show(); return
        }
        val go = { launchRefresh(jobs, noYvok) }
        if (jobs.size > 100) {
            val mins = Math.max(1, (jobs.size * 0.9 / 60).toInt())
            AlertDialog.Builder(this)
                .setTitle("Saytdan yenilə")
                .setMessage("$label\n${jobs.size} mənzil yenilənəcək (təxminən $mins dəq). Yenilənmə zamanı tətbiq açıq qalmalıdır.\n\nDavam edilsin?")
                .setPositiveButton("Bəli") { _, _ -> go() }
                .setNegativeButton("Xeyr", null)
                .show()
        } else go()
    }

    private fun launchRefresh(jobs: List<Job>, noYvok: Int) {
        val r = Refresher(ArrayList(jobs), noYvok)
        refresher = r
        r.start()
    }

    /** Saytın cavabından ad və borcu çıxarır */
    private fun parseResult(base: String, text: String): Parsed {
        val baseLines = base.lines().map { it.trim() }.toSet()
        val lines = text.lines().map { it.trim() }
            .filter { it.isNotEmpty() && it !in baseLines && !it.startsWith("Yoxlanılır") }
        val raw = lines.joinToString("\n")
        val ff = lines.map { fold(it) }

        // ---- borc ----
        val numRe = Regex("""-?\d+(?:[ \u00A0]\d{3})*(?:[.,]\d{1,2})?""")
        fun norm(s: String): String {
            val d = s.replace("\u00A0", "").replace(" ", "").replace(',', '.').toDoubleOrNull() ?: 0.0
            return if (d == Math.floor(d)) d.toLong().toString() else money(d)
        }
        // ---- saytın əsas nəticə formatı:
        // "10011MBM2046 / MUSTAFAYEV BARAT MEHDİ adına Binəqədi bələdiyyəsi üzrə olan vergi borcu: 0 manat." ----
        val joined = lines.joinToString(" ").replace(Regex("\\s+"), " ")
        val mainRe = Regex("""(\S+)\s*/\s*(.+?)\s+ad[ıiİI]na\s.*?borcu\s*:\s*(-?\d[\d\u00A0 ]*(?:[.,]\d{1,2})?)""", RegexOption.IGNORE_CASE)
        val mm = mainRe.find(joined)
        if (mm != null) {
            val fullName = mm.groupValues[2].replace(Regex("\\s+"), " ").trim()
            return Parsed(fullName.ifEmpty { null }, norm(mm.groupValues[3].trim()), false, raw)
        }

        var borc: String? = null
        for (i in lines.indices) {
            if (!ff[i].contains("borc")) continue
            val after = if (lines[i].contains(':')) lines[i].substringAfter(':') else lines[i]
            val m = numRe.find(after)
            if (m != null) { borc = norm(m.value); break }
            if (ff[i].contains("yoxdur") || ff[i].contains("olmayib") || ff[i].contains("qalmayib")) { borc = "0"; break }
            if (i + 1 < lines.size && lines[i + 1].length < 30) {
                val m2 = numRe.find(lines[i + 1])
                if (m2 != null) { borc = norm(m2.value); break }
            }
        }
        if (borc == null) {
            val m = Regex("""(\d+(?:[.,]\d{1,2})?)\s*(?:azn|₼|manat)""", RegexOption.IGNORE_CASE).find(raw)
            if (m != null) borc = norm(m.groupValues[1])
        }

        // ---- ad, soyad, atasının adı ----
        var name: String? = null
        var soyad: String? = null; var ad: String? = null; var ata: String? = null
        for (i in lines.indices) {
            val f = ff[i]
            if (f.contains("borc")) continue
            val label = f.substringBefore(':').trim()
            fun value(): String? {
                val v = if (lines[i].contains(':')) lines[i].substringAfter(':').trim() else ""
                if (v.isNotEmpty()) return v
                if (i + 1 < lines.size && !ff[i + 1].contains("borc")) return lines[i + 1]
                return null
            }
            when {
                label == "soyad" -> soyad = soyad ?: value()
                label == "ad" -> ad = ad ?: value()
                label.startsWith("ata") -> ata = ata ?: value()
                name == null && (label.startsWith("soyad") || label.startsWith("ad, soyad") || label.startsWith("ad soyad") ||
                    label.contains("vetendas") || label.contains("mulkiyyetci") || label.contains("sahibi") || label.contains("ad, ")) -> name = value()
            }
        }
        if (soyad != null || ad != null) {
            name = listOfNotNull(soyad, ad, ata).joinToString(" ")
        }
        if (name == null) {
            // etiketsiz: rəqəmsiz, ən azı 2 sözlü, hərflərdən ibarət ilk sətir
            for (i in lines.indices) {
                val l = lines[i]; val f = ff[i]
                if (f.contains("borc") || f.contains("tapilmadi") || f.contains("yoxdur") || f.contains("deyil") || f.contains("yvok")) continue
                if (l.any { it.isDigit() } || l.contains(':')) continue
                if (l.trim().split(Regex("\\s+")).size >= 2) { name = l.trim(); break }
            }
        }
        val notFound = borc == null && name == null &&
            (ff.any { it.contains("tapilmadi") || it.contains("movcud deyil") || it.contains("duzgun deyil") || it.contains("melumat yoxdur") })
        return Parsed(name?.replace(Regex("\\s+"), " ")?.trim(), borc, notFound, raw)
    }

    /** nəticəni bazaya yazır; redaktə/yeniləmə qeydi ayrıca faylda da saxlanılır */
    private fun applyFetched(rowId: Long, name: String?, borc: String?) {
        db.rawQuery(
            "SELECT r.cells, b.headers, f.name, b.sheet, r.ord FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.id = ?", arrayOf(rowId.toString())
        ).use { c ->
            if (!c.moveToFirst()) return
            val cells = jsonList(c.getString(0)).toMutableList()
            val headers = jsonList(c.getString(1))
            val fname = c.getString(2); val sheet = c.getString(3); val ord = c.getInt(4)
            while (cells.size < headers.size) cells.add("")
            var changed = false
            fun setCol(i: Int, v: String) {
                if (i >= 0 && i < cells.size && cells[i] != v) {
                    cells[i] = v
                    editsDb.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", arrayOf<Any>(fname, sheet, ord, i, v))
                    changed = true
                }
            }
            if (name != null) setCol(nameIdx(headers), name)
            if (borc != null) setCol(colIdx(headers, "borc"), borc)
            if (changed) writeRow(db, rowId, cells, headers)
        }
    }

    inner class Refresher(private val jobs: ArrayList<Job>, private val noYvok: Int) {
        private val total = jobs.size
        private var done = 0
        private var updated = 0
        private var notFound = 0
        private var failed = 0
        private var cancelled = false
        private var running = 0
        private var finished = false
        private var sample: String? = null
        private val workers = ArrayList<Worker>()
        private lateinit var dialog: AlertDialog
        private lateinit var tvStatus: TextView
        private lateinit var bar: ProgressBar

        fun start() {
            val box = LinearLayout(this@MainActivity)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(20), dp(16), dp(20), dp(4))
            tvStatus = TextView(this@MainActivity)
            tvStatus.text = "Sayta qoşulur…"; tvStatus.textSize = 15f
            bar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal)
            bar.max = total
            box.addView(tvStatus)
            box.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            dialog = AlertDialog.Builder(this@MainActivity)
                .setTitle("Saytdan yenilənir")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Dayandır", null)
                .create()
            dialog.show()
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                cancelled = true
                tvStatus.text = "Dayandırılır…"
            }
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            val n = Math.min(WORKERS, total)
            for (i in 0 until n) { val w = Worker(); workers.add(w); running++ }
            workers.forEach { it.next() }
        }

        private fun progress() {
            tvStatus.text = "Yenilənir: $done / $total   (tapıldı: $updated, tapılmadı: $notFound, xəta: $failed)"
            bar.progress = done
        }

        private fun workerFinished(w: Worker) {
            w.destroy()
            running--
            if (running <= 0 && !finished) finish()
        }

        private fun finish() {
            finished = true
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            try { dialog.dismiss() } catch (e: Exception) { }
            refresher = null
            val msg = "Yeniləndi: $updated, tapılmadı: $notFound, xəta: $failed" +
                (if (noYvok > 0) ", YVÖK-sü olmayan: $noYvok" else "") + (if (cancelled) " (dayandırıldı)" else "")
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
            afterRefresh()
            val s = sample
            if (s != null) {
                val tv = TextView(this@MainActivity)
                tv.text = s; tv.textSize = 13f; tv.setTextIsSelectable(true); tv.setPadding(dp(20), dp(12), dp(20), dp(4))
                val sv = ScrollView(this@MainActivity); sv.addView(tv)
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Saytın cavabı tam oxunmadı")
                    .setView(sv)
                    .setPositiveButton("Bağla", null)
                    .show()
            }
        }

        inner class Worker {
            private val wv = WebView(this@MainActivity)
            private var job: Job? = null
            private var attempt = 0
            private var token = 0
            private var base = ""
            private var last = ""
            private var stable = 0
            private var loading = false

            init {
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                wv.settings.blockNetworkImage = true
                wv.alpha = 0.01f
                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        if (job != null && loading) { loading = false; pollReady(token, 0) }
                    }
                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        if (request?.isForMainFrame == true && job != null && loading) { loading = false; failAttempt() }
                    }
                }
                webHost.addView(wv, FrameLayout.LayoutParams(dp(360), dp(640)))
            }

            fun destroy() {
                token++
                try { webHost.removeView(wv); wv.destroy() } catch (e: Exception) { }
            }

            fun next() {
                if (cancelled) { workerFinished(this); return }
                val j = jobs.removeFirstOrNull()
                if (j == null) { workerFinished(this); return }
                job = j; attempt = 0
                startAttempt()
            }

            private fun startAttempt() {
                attempt++
                token++
                val t = token
                loading = true
                stable = 0; last = ""
                wv.loadUrl(TAX_URL)
                ui.postDelayed({ if (t == token && loading) { loading = false; failAttempt() } }, 20000)
            }

            private fun parseJs(v: String?): JSONObject? {
                return try {
                    val s = JSONTokener(v ?: "null").nextValue() as? String ?: return null
                    JSONObject(s)
                } catch (e: Exception) { null }
            }

            private fun pollReady(t: Int, tries: Int) {
                if (t != token) return
                wv.evaluateJavascript(JS_READY) { v ->
                    if (t == token) {
                        val o = parseJs(v)
                        if (o != null && o.optBoolean("ok")) {
                            base = o.optString("text")
                            fill(t)
                        } else if (tries > 40) failAttempt()
                        else ui.postDelayed({ pollReady(t, tries + 1) }, 250)
                    }
                }
            }

            private fun fill(t: Int) {
                val j = job ?: return
                wv.evaluateJavascript(jsFill(j.yvok)) { r ->
                    if (t == token) {
                        if (r != null && r.contains("ok")) { stable = 0; last = ""; pollResult(t, 0) }
                        else failAttempt()
                    }
                }
            }

            private fun pollResult(t: Int, tries: Int) {
                if (t != token) return
                wv.evaluateJavascript(JS_STATE) { v ->
                    if (t == token) {
                        val text = parseJs(v)?.optString("text") ?: ""
                        val isLoading = text.contains("Yoxlanılır") && !base.contains("Yoxlanılır")
                        if (!isLoading && text.isNotEmpty() && text != base) {
                            if (text == last) stable++ else { last = text; stable = 0 }
                            if (stable >= 2) { complete(text); return@evaluateJavascript }
                        } else { stable = 0; last = "" }
                        if (tries > 45) failAttempt()
                        else ui.postDelayed({ pollResult(t, tries + 1) }, 300)
                    }
                }
            }

            private fun complete(text: String) {
                token++
                val j = job ?: return
                val p = parseResult(base, text)
                if (p.name == null && p.borc == null) {
                    if (p.notFound) notFound++
                    else {
                        failed++
                        if (sample == null) sample = "YVÖK: ${j.yvok}\n\n" + (if (p.raw.isEmpty()) "(yeni mətn yoxdur)" else p.raw)
                    }
                } else {
                    applyFetched(j.rowId, p.name, p.borc)
                    updated++
                    if ((p.name == null || p.borc == null) && sample == null) {
                        sample = "YVÖK: ${j.yvok}\nTapılan ad: ${p.name ?: "—"}\nTapılan borc: ${p.borc ?: "—"}\n\n" + p.raw
                    }
                }
                done++
                progress()
                next()
            }

            private fun failAttempt() {
                token++
                if (attempt < 3 && !cancelled) { startAttempt(); return }
                failed++; done++
                progress()
                next()
            }
        }
    }

    /** yeniləmədən sonra ekrandakı siyahıları təzələyir */
    private fun afterRefresh() {
        mainSearch.scheduleSearch()
        if (!catSearch.isEmpty()) catSearch.scheduleSearch()
        loadLevel(false)
    }

    private fun refreshRows(label: String, ids: List<Long>) = startRefresh(label, null, null, ids)

    private fun refreshScope(label: String, scopeSql: String?, arg: String?) = startRefresh(label, scopeSql, arg, null)

    private fun currentScopeLabel(): String = when (level) {
        0 -> "Bütün baza"
        1 -> fileName
        2 -> "$fileName › $streetName"
        else -> tvPath.text.toString()
    }

    private fun refreshCurrentSection() {
        when (level) {
            0 -> refreshScope(currentScopeLabel(), null, null)
            1 -> refreshScope(currentScopeLabel(), "b.file_id = ?", fileId.toString())
            2 -> refreshScope(currentScopeLabel(), "b.street_id = ?", streetId.toString())
            else -> refreshScope(currentScopeLabel(), "b.id = ?", buildingId.toString())
        }
    }

    // =====================================================================
    //  Axtarış bölməsi (həm "Axtarış" tabında, həm kataloqun hər səviyyəsində)
    // =====================================================================
    inner class SearchUi(
        private val scope: () -> Pair<String, String>?,
        private val onActive: (Boolean) -> Unit,
        private val onRefresh: () -> Unit
    ) {
        private val tokS = Any()
        private val tokG = Any()
        private var searchGen = 0
        private var sugGen = 0
        private var suppress = false
        private val adapter = CardAdapter()

        val etStreet: EditText = edit("Küçə adı", "street")
        val etMenzil: EditText = edit("Mənzil", "menzil")
        val etSoyad: EditText = edit("Soyad", "soyad")
        val etAd: EditText = edit("Ad", "ad")
        val etAta: EditText = edit("Atasının adı", "ata")
        val etNomre: EditText = edit("Nömrə", "nomre", InputType.TYPE_CLASS_PHONE)

        val form = LinearLayout(this@MainActivity)
        private val row2 = rowOf(etMenzil to 0.8f, etSoyad to 1.1f, etAd to 1f)
        private val row3 = rowOf(etAta to 1f, etNomre to 1f)
        private val sugBox = LinearLayout(this@MainActivity)
        val tvCount = TextView(this@MainActivity)
        val results = ListView(this@MainActivity)
        val resultsBox = LinearLayout(this@MainActivity)

        init {
            form.orientation = LinearLayout.VERTICAL
            form.setPadding(dp(8), dp(4), dp(8), dp(4))
            form.addView(etStreet, LinearLayout.LayoutParams(-1, -2))
            form.addView(row2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            form.addView(row3, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

            sugBox.orientation = LinearLayout.VERTICAL
            sugBox.visibility = View.GONE
            sugBox.elevation = dp(6).toFloat()
            sugBox.background = GradientDrawable().apply {
                setColor(Color.WHITE); setStroke(dp(1), Color.parseColor("#B0BEC5")); cornerRadius = dp(8).toFloat()
            }
            form.addView(sugBox, 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })

            val btnClear = Button(this@MainActivity)
            btnClear.text = "Təmizlə"
            btnClear.setOnClickListener { clear(); scheduleSearch() }
            form.addView(btnClear, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

            // Təmizlə düyməsinin altında: Yenilə
            val btnRefresh = Button(this@MainActivity)
            btnRefresh.text = "🔄  Yenilə"
            btnRefresh.setOnClickListener { hideSug(); onRefresh() }
            form.addView(btnRefresh, LinearLayout.LayoutParams(-1, -2))

            tvCount.textSize = 13f
            tvCount.setPadding(dp(12), dp(2), dp(12), dp(4))
            tvCount.setTextColor(Color.DKGRAY)
            results.divider = null
            results.adapter = adapter
            results.clipToPadding = false
            results.setPadding(dp(8), 0, dp(8), dp(8))
            results.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) hideSug(); false }
            resultsBox.orientation = LinearLayout.VERTICAL
            resultsBox.addView(tvCount)
            resultsBox.addView(results, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        fun shownRowIds(): List<Long> = adapter.rowIds()

        private fun edit(hint: String, key: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
            val e = EditText(this@MainActivity)
            e.hint = hint
            e.textSize = 14f
            e.isSingleLine = true
            e.inputType = type or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            e.imeOptions = EditorInfo.IME_ACTION_SEARCH
            e.setPadding(dp(8), dp(10), dp(8), dp(10))
            e.background = GradientDrawable().apply {
                setColor(Color.WHITE); setStroke(dp(1), Color.parseColor("#B0BEC5")); cornerRadius = dp(8).toFloat()
            }
            e.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (suppress) return
                    scheduleSearch(); scheduleSuggest(key)
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            e.setOnFocusChangeListener { _, has -> if (has) scheduleSuggest(key) }
            e.setOnEditorActionListener { v, _, _ ->
                hideSug()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(v.windowToken, 0)
                true
            }
            return e
        }

        private fun fieldOf(key: String): EditText = when (key) {
            "street" -> etStreet; "menzil" -> etMenzil; "soyad" -> etSoyad
            "ad" -> etAd; "ata" -> etAta; else -> etNomre
        }

        fun isEmpty(): Boolean =
            listOf(etStreet, etMenzil, etSoyad, etAd, etAta).all { fold(it.text.toString()).isEmpty() } &&
                etNomre.text.toString().none { it.isDigit() }

        fun clear() {
            suppress = true
            listOf(etStreet, etMenzil, etSoyad, etAd, etAta, etNomre).forEach { it.setText("") }
            suppress = false
            hideSug()
        }

        fun hideSug() {
            sugGen++
            sugBox.visibility = View.GONE
        }

        fun sugVisible() = sugBox.visibility == View.VISIBLE

        private fun buildWhere(exclude: String?, where: ArrayList<String>, args: ArrayList<String>) {
            scope()?.let { where.add(it.first); args.add(it.second) }
            if (exclude != "street") fold(etStreet.text.toString()).split(' ').filter { it.isNotEmpty() }
                .forEach { where.add("b.name_n LIKE ?"); args.add("%$it%") }
            val mz = fold(etMenzil.text.toString())
            if (exclude != "menzil" && mz.isNotEmpty()) { where.add("r.menzil_n = ?"); args.add(mz) }
            val so = fold(etSoyad.text.toString())
            if (exclude != "soyad" && so.isNotEmpty()) { where.add("r.soyad_n LIKE ?"); args.add("%$so%") }
            val ad = fold(etAd.text.toString())
            if (exclude != "ad" && ad.isNotEmpty()) { where.add("r.ad_n LIKE ?"); args.add("%$ad%") }
            val at = fold(etAta.text.toString())
            if (exclude != "ata" && at.isNotEmpty()) { where.add("r.ata_n LIKE ?"); args.add("%$at%") }
            val nr = etNomre.text.toString().filter { it.isDigit() }
            if (exclude != "nomre" && nr.isNotEmpty()) { where.add("r.nomre_d LIKE ?"); args.add("%$nr%") }
        }

        // ----- təkliflər -----
        private fun scheduleSuggest(key: String) {
            ui.removeCallbacksAndMessages(tokG)
            ui.postAtTime({ doSuggest(key) }, tokG, SystemClock.uptimeMillis() + 120)
        }

        private fun doSuggest(key: String) {
            val et = fieldOf(key)
            val q = fold(et.text.toString())
            if (key == "nomre" || q.isEmpty() || !et.hasFocus()) { hideSug(); return }
            val gen = ++sugGen
            Thread {
                val items = ArrayList<String>()
                try {
                    if (key == "street") {
                        val toks = q.split(' ').filter { it.isNotEmpty() }
                        val where = ArrayList<String>(); val args = ArrayList<String>()
                        scope()?.let { where.add(it.first); args.add(it.second) }
                        toks.forEach { where.add("b.name_n LIKE ?"); args.add("%$it%") }
                        val w = where.joinToString(" AND ")
                        db.rawQuery(
                            "SELECT DISTINCT s.name FROM streets s JOIN buildings b ON b.street_id = s.id WHERE $w ORDER BY s.name LIMIT 4",
                            args.toTypedArray()
                        ).use { c -> while (c.moveToNext()) items.add(c.getString(0)) }
                        db.rawQuery(
                            "SELECT DISTINCT b.name FROM buildings b WHERE $w ORDER BY b.file_id, b.ord LIMIT 10",
                            args.toTypedArray()
                        ).use { c -> while (c.moveToNext()) { val n = c.getString(0); if (n !in items) items.add(n) } }
                    } else {
                        val col = when (key) { "menzil" -> "r.menzil"; "soyad" -> "r.soyad"; "ad" -> "r.ad"; else -> "r.ata" }
                        val where = ArrayList<String>(); val args = ArrayList<String>()
                        buildWhere(key, where, args)
                        where.add("${col}_n LIKE ?"); args.add("$q%")
                        where.add("$col <> ''")
                        db.rawQuery(
                            "SELECT DISTINCT $col FROM rows r JOIN buildings b ON b.id = r.building_id WHERE " +
                                where.joinToString(" AND ") + " ORDER BY ${col}_n LIMIT 8", args.toTypedArray()
                        ).use { c -> while (c.moveToNext()) items.add(c.getString(0)) }
                    }
                } catch (e: Exception) { /* ignore */ }
                runOnUiThread { if (gen == sugGen) showSug(key, items) }
            }.start()
        }

        private fun showSug(key: String, items: List<String>) {
            if (items.isEmpty()) { sugBox.visibility = View.GONE; return }
            val anchor: View = when (key) { "street" -> etStreet; "menzil", "soyad", "ad" -> row2; else -> row3 }
            form.removeView(sugBox)
            form.addView(sugBox, form.indexOfChild(anchor) + 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
            sugBox.removeAllViews()
            items.forEachIndexed { idx, text ->
                val tv = TextView(this@MainActivity)
                tv.text = "🔍  $text"; tv.textSize = 15f; tv.setTextColor(Color.parseColor("#263238"))
                tv.setPadding(dp(12), dp(11), dp(12), dp(11))
                tv.setOnClickListener {
                    val f = fieldOf(key)
                    suppress = true
                    f.setText(items[idx])
                    f.setSelection(f.text.length)
                    suppress = false
                    hideSug(); scheduleSearch()
                }
                sugBox.addView(tv)
            }
            sugBox.visibility = View.VISIBLE
        }

        // ----- axtarış -----
        fun scheduleSearch() {
            onActive(!isEmpty())
            ui.removeCallbacksAndMessages(tokS)
            ui.postAtTime({ doSearch() }, tokS, SystemClock.uptimeMillis() + 250)
        }

        private fun doSearch() {
            if (isEmpty()) {
                adapter.set(emptyList()); tvCount.text = "Axtarmaq üçün yuxarıdakı xanalara yazın"; return
            }
            val gen = ++searchGen
            Thread {
                val where = ArrayList<String>(); val args = ArrayList<String>()
                buildWhere(null, where, args)
                val sql = "SELECT r.cells, b.headers, b.name, b.title, f.name, r.id FROM rows r " +
                    "JOIN buildings b ON b.id = r.building_id JOIN files f ON f.id = b.file_id " +
                    "WHERE " + where.joinToString(" AND ") + " ORDER BY f.ord, b.ord, r.ord LIMIT 201"
                val list = ArrayList<Card>()
                try {
                    db.rawQuery(sql, args.toTypedArray()).use { c ->
                        while (c.moveToNext()) {
                            list.add(Card(
                                path = c.getString(4) + "  ›  " + c.getString(2),
                                title = c.getString(3),
                                headers = jsonList(c.getString(1)),
                                cells = jsonList(c.getString(0)),
                                rowId = c.getLong(5)
                            ))
                        }
                    }
                } catch (e: Exception) { /* ignore */ }
                runOnUiThread {
                    if (gen == searchGen) {
                        val more = list.size > 200
                        val shown = if (more) list.subList(0, 200) else list
                        adapter.set(shown)
                        tvCount.text = if (shown.isEmpty()) "Nəticə tapılmadı"
                        else if (more) "İlk 200 nəticə göstərilir — axtarışı dəqiqləşdirin" else "${shown.size} nəticə"
                        results.setSelection(0)
                    }
                }
            }.start()
        }
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#ECEFF1"))
        }

        btnSearch = Button(this).apply { text = "Axtarış"; setOnClickListener { showTab(true) } }
        btnCat = Button(this).apply { text = "Kataloq"; setOnClickListener { showTab(false) } }
        root.addView(rowOf(btnSearch to 1f, btnCat to 1f), LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(24); leftMargin = dp(8); rightMargin = dp(8)
        })

        // ----- Axtarış tabı (bütün bazada) -----
        mainSearch = SearchUi(
            scope = { null },
            onActive = { },
            onRefresh = {
                val ids = mainSearch.shownRowIds()
                if (ids.isEmpty()) Toast.makeText(this, "Əvvəl axtarış edin", Toast.LENGTH_SHORT).show()
                else refreshRows("Axtarış nəticələri", ids)
            }
        )
        searchPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        searchPanel.addView(mainSearch.form)
        searchPanel.addView(mainSearch.resultsBox, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(searchPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        // ----- Kataloq tabı: başlıq + axtarış + siyahı -----
        catList = ListView(this)
        catSearch = SearchUi(
            scope = {
                when (level) {
                    1 -> Pair("b.file_id = ?", fileId.toString())
                    2 -> Pair("b.street_id = ?", streetId.toString())
                    3 -> Pair("b.id = ?", buildingId.toString())
                    else -> null
                }
            },
            onActive = { active ->
                catSearch.resultsBox.visibility = if (active) View.VISIBLE else View.GONE
                catList.visibility = if (active) View.GONE else View.VISIBLE
            },
            onRefresh = {
                // axtarış aktivdirsə — nəticələr, deyilsə — seçilmiş bölmə
                if (!catSearch.isEmpty()) {
                    val ids = catSearch.shownRowIds()
                    if (ids.isEmpty()) Toast.makeText(this, "Nəticə yoxdur", Toast.LENGTH_SHORT).show()
                    else refreshRows("Axtarış nəticələri (${currentScopeLabel()})", ids)
                } else refreshCurrentSection()
            }
        )
        catPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvPath = TextView(this).apply {
            textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#263238"))
        }
        tvTotal = TextView(this).apply {
            textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#1565C0"))
        }
        val btnHeaderRefresh = TextView(this).apply {
            text = "🔄"; textSize = 20f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { catSearch.hideSug(); refreshCurrentSection() }
        }
        val line2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(tvTotal, LinearLayout.LayoutParams(0, -2, 1f))
            addView(btnHeaderRefresh, LinearLayout.LayoutParams(-2, -2))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(4))
            addView(tvPath)
            addView(line2)
        }
        catPanel.addView(header)
        catPanel.addView(catSearch.form)
        val frame = FrameLayout(this)
        frame.addView(catList, FrameLayout.LayoutParams(-1, -1))
        catSearch.resultsBox.visibility = View.GONE
        frame.addView(catSearch.resultsBox, FrameLayout.LayoutParams(-1, -1))
        catPanel.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(catPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        catList.setOnItemClickListener { _, _, pos, _ ->
            if (level < 3) openChild(catIds[pos], catNames[pos])
        }

        setContentView(root)

        // saytdan yeniləmə üçün gizli WebView-lar bu konteynerdə işləyir (görünmür)
        webHost = FrameLayout(this)
        webHost.clipChildren = false
        addContentView(webHost, FrameLayout.LayoutParams(1, 1))

        loadLevel()
    }

    private fun showTab(search: Boolean) {
        searchPanel.visibility = if (search) View.VISIBLE else View.GONE
        catPanel.visibility = if (search) View.GONE else View.VISIBLE
        btnSearch.alpha = if (search) 1f else 0.55f
        btnCat.alpha = if (search) 0.55f else 1f
        if (search) { catSearch.hideSug(); mainSearch.scheduleSearch() } else { mainSearch.hideSug() }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (catPanel.visibility == View.VISIBLE) {
            if (catSearch.sugVisible()) { catSearch.hideSug(); return }
            if (!catSearch.isEmpty()) { catSearch.clear(); catSearch.scheduleSearch(); return }
            if (level > 0) { level--; loadLevel() } else showTab(true)
        } else {
            if (mainSearch.sugVisible()) { mainSearch.hideSug(); return }
            super.onBackPressed()
        }
    }

    // ---------- kataloq ----------
    private fun openChild(id: Long, label: String) {
        when (level) {
            0 -> { fileId = id; fileName = label }
            1 -> { streetId = id; streetName = label }
            2 -> { buildingId = id }
        }
        level++; loadLevel()
    }

    private fun refreshItem(pos: Int) {
        val id = catIds[pos]
        val label = catNames[pos]
        when (level) {
            0 -> refreshScope(label, "b.file_id = ?", id.toString())
            1 -> refreshScope("$fileName › $label", "b.street_id = ?", id.toString())
            else -> refreshScope("$streetName › $label", "b.id = ?", id.toString())
        }
    }

    private fun loadLevel(clearSearch: Boolean = true) {
        if (clearSearch) {
            catSearch.clear()
            catSearch.resultsBox.visibility = View.GONE
            catList.visibility = View.VISIBLE
        }
        catIds = ArrayList(); catNames = ArrayList(); catCounts = ArrayList(); catBorc = ArrayList()
        fun collect(c: android.database.Cursor) {
            while (c.moveToNext()) {
                catIds.add(c.getLong(0)); catNames.add(c.getString(1)); catCounts.add(c.getInt(2)); catBorc.add(c.getDouble(3))
            }
        }
        when (level) {
            0 -> {
                tvPath.text = "Əsas kateqoriya (fayl)"
                db.rawQuery(
                    "SELECT f.id, f.name, COUNT(r.id), COALESCE(SUM(r.borc),0) FROM files f JOIN buildings b ON b.file_id = f.id " +
                        "JOIN rows r ON r.building_id = b.id GROUP BY f.id ORDER BY f.ord", null
                ).use { collect(it) }
            }
            1 -> {
                tvPath.text = fileName
                db.rawQuery(
                    "SELECT s.id, s.name, COUNT(r.id), COALESCE(SUM(r.borc),0) FROM streets s JOIN buildings b ON b.street_id = s.id " +
                        "JOIN rows r ON r.building_id = b.id WHERE s.file_id = ? GROUP BY s.id ORDER BY s.ord",
                    arrayOf(fileId.toString())
                ).use { collect(it) }
            }
            2 -> {
                tvPath.text = "$fileName  ›  $streetName"
                db.rawQuery(
                    "SELECT b.id, b.name, COUNT(r.id), COALESCE(SUM(r.borc),0) FROM buildings b JOIN rows r ON r.building_id = b.id " +
                        "WHERE b.street_id = ? GROUP BY b.id ORDER BY b.ord",
                    arrayOf(streetId.toString())
                ).use { collect(it) }
            }
            3 -> {
                val cards = ArrayList<Card>()
                db.rawQuery("SELECT headers, name, title FROM buildings WHERE id=?", arrayOf(buildingId.toString())).use { b ->
                    if (b.moveToFirst()) {
                        val hdr = jsonList(b.getString(0)); val nm = b.getString(1); val title = b.getString(2)
                        tvPath.text = "$fileName  ›  $nm"
                        db.rawQuery("SELECT cells, id FROM rows WHERE building_id=? ORDER BY ord", arrayOf(buildingId.toString())).use { c ->
                            while (c.moveToNext()) cards.add(Card("", title, hdr, jsonList(c.getString(0)), c.getLong(1)))
                        }
                    }
                }
                var sum = 0.0
                db.rawQuery("SELECT COALESCE(SUM(borc),0) FROM rows WHERE building_id=?", arrayOf(buildingId.toString())).use { c ->
                    if (c.moveToFirst()) sum = c.getDouble(0)
                }
                tvTotal.text = totalText(sum, cards.size)
                cardAdapterCat.set(cards)
                catList.divider = null
                catList.adapter = cardAdapterCat
                catList.clipToPadding = false
                catList.setPadding(dp(8), 0, dp(8), dp(8))
                return
            }
        }
        tvTotal.text = totalText(catBorc.sum(), catCounts.sum())
        catList.divider = ColorDrawable(Color.parseColor("#CFD8DC"))
        catList.dividerHeight = 1
        catList.setPadding(0, 0, 0, 0)
        catList.adapter = CatAdapter()
    }

    /** Ad yuxarıda; altında "Ümumi Borc (…) / Ümumi Mənzil (…)" və sağda dairəvi ox (yenilə) */
    inner class CatAdapter : BaseAdapter() {
        override fun getCount() = catNames.size
        override fun getItem(position: Int) = catNames[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.VERTICAL
            row.setBackgroundColor(Color.WHITE)
            row.setPadding(dp(14), dp(10), dp(6), dp(8))
            val name = TextView(this@MainActivity)
            name.text = catNames[position]; name.textSize = 15f; name.typeface = Typeface.DEFAULT_BOLD
            name.setTextColor(Color.parseColor("#263238"))
            val info = TextView(this@MainActivity)
            info.text = totalText(catBorc[position], catCounts[position]); info.textSize = 13f
            info.setTextColor(Color.parseColor("#1565C0"))
            val ref = TextView(this@MainActivity)
            ref.text = "🔄"; ref.textSize = 20f; ref.gravity = Gravity.CENTER
            ref.setPadding(dp(12), dp(4), dp(12), dp(4))
            ref.isFocusable = false
            ref.setOnClickListener { refreshItem(position) }
            val line = LinearLayout(this@MainActivity)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(ref, LinearLayout.LayoutParams(-2, -2))
            row.addView(name)
            row.addView(line)
            return row
        }
    }

    // ---------- nəticə kartları ----------
    inner class CardAdapter : BaseAdapter() {
        private var items: MutableList<Card> = ArrayList()
        fun set(l: List<Card>) { items = ArrayList(l); notifyDataSetChanged() }
        fun rowIds(): List<Long> = items.map { it.rowId }.filter { it >= 0 }
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val c = items[position]
            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = dp(10).toFloat(); setStroke(dp(1), Color.parseColor("#CFD8DC"))
                }
            }
            if (c.path.isNotEmpty()) box.addView(TextView(this@MainActivity).apply {
                text = c.path; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#1565C0"))
            })
            if (c.title.isNotEmpty()) box.addView(TextView(this@MainActivity).apply {
                text = c.title; textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 0, 0, dp(4))
            })
            for (i in c.headers.indices) {
                val v = c.cells.getOrNull(i).orEmpty().ifEmpty { "—" }
                box.addView(TextView(this@MainActivity).apply {
                    text = "${c.headers[i]}: $v"; textSize = 14f; setTextColor(Color.parseColor("#263238"))
                    setTextIsSelectable(true)
                })
            }
            if (c.rowId >= 0) {
                val btnRef = TextView(this@MainActivity)
                btnRef.text = "🔄  Yenilə"; btnRef.textSize = 13f
                btnRef.setTextColor(Color.parseColor("#1565C0")); btnRef.setPadding(0, dp(10), 0, dp(2))
                btnRef.setOnClickListener { refreshRows("Bir mənzil", listOf(c.rowId)) }
                val btnEdit = TextView(this@MainActivity)
                btnEdit.text = "✏️  Redaktə et"; btnEdit.textSize = 13f; btnEdit.gravity = Gravity.END
                btnEdit.setTextColor(Color.parseColor("#1565C0")); btnEdit.setPadding(0, dp(10), 0, dp(2))
                btnEdit.setOnClickListener {
                    showEditDialog(c) { nc ->
                        if (position < items.size) items[position] = c.copy(cells = nc)
                        notifyDataSetChanged()
                    }
                }
                val btns = LinearLayout(this@MainActivity)
                btns.orientation = LinearLayout.HORIZONTAL
                btns.addView(btnRef, LinearLayout.LayoutParams(0, -2, 1f))
                btns.addView(btnEdit, LinearLayout.LayoutParams(0, -2, 1f))
                box.addView(btns, LinearLayout.LayoutParams(-1, -2))
            }
            val wrap = FrameLayout(this@MainActivity).apply {
                setPadding(0, dp(3), 0, dp(3)); layoutParams = AbsListView.LayoutParams(-1, -2)
            }
            wrap.addView(box, FrameLayout.LayoutParams(-1, -2))
            return wrap
        }
    }
}
