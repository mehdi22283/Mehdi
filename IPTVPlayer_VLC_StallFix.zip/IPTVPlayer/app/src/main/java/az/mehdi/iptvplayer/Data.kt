package az.mehdi.iptvplayer

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Channel(
    val number: Int, val name: String, val url: String, val group: String, val logo: String?,
    val tvgId: String? = null, val tvgName: String? = null
)

const val PLAYLIST_URL = "https://dl.dropboxusercontent.com/scl/fi/nzpruxp8yiymlemuvkqha/Mehdi222_Mehdi.m3u8?rlkey=gkrwkx3yqxo44gxkb4hi69vd7"
const val LOGO2_URL = "https://dl.dropboxusercontent.com/scl/fi/um0ttg46rhklgmjeq5wia/Logo.txt?rlkey=he9qojtmtruggsuenwr72l12a"
private const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) OTTPlayer/1.0"

fun fetchToFile(src: String, dest: File, timeout: Int = 15000) {
    val c = URL(src).openConnection() as HttpURLConnection
    c.connectTimeout = timeout
    c.readTimeout = timeout * 2
    c.instanceFollowRedirects = true
    c.setRequestProperty("User-Agent", UA)
    try {
        if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
        val tmp = File(dest.path + ".tmp")
        c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        if (dest.exists()) dest.delete()
        if (!tmp.renameTo(dest)) throw IOException("rename failed")
    } finally {
        c.disconnect()
    }
}

class Fetched(val notModified: Boolean, val etag: String?, val lastMod: String?)

/** ETag / Last-Modified ilə şərti endirmə: server 304 qaytarırsa fayl dəyişməyib (dest-ə toxunulmur). */
fun fetchConditional(src: String, dest: File, etag: String?, lastMod: String?, timeout: Int = 15000): Fetched {
    val c = URL(src).openConnection() as HttpURLConnection
    c.connectTimeout = timeout
    c.readTimeout = timeout * 2
    c.instanceFollowRedirects = true
    c.setRequestProperty("User-Agent", UA)
    if (!etag.isNullOrEmpty()) c.setRequestProperty("If-None-Match", etag)
    if (!lastMod.isNullOrEmpty()) c.setRequestProperty("If-Modified-Since", lastMod)
    try {
        val code = c.responseCode
        if (code == 304) return Fetched(true, etag, lastMod)
        if (code !in 200..299) throw IOException("HTTP $code")
        val expected = c.contentLengthLong
        if (dest.exists()) dest.delete()
        c.inputStream.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        // Yarımçıq endirmə qəbul edilmir
        if (expected > 0 && dest.length() != expected && c.contentEncoding == null) {
            dest.delete(); throw IOException("incomplete")
        }
        return Fetched(false, c.getHeaderField("ETag"), c.getHeaderField("Last-Modified"))
    } finally {
        c.disconnect()
    }
}

/** Hər açılışda çağırılır: playlisti yenidən endirir, uğurlu olarsa keşi yeniləyir. */
fun downloadPlaylist(cache: File): String {
    val fresh = File(cache.path + ".new")
    fetchToFile(PLAYLIST_URL, fresh, 20000)
    val text = fresh.readText()
    if (!text.contains("#EXTINF")) { fresh.delete(); throw IOException("Playlist boşdur") }
    if (cache.exists()) cache.delete()
    fresh.renameTo(cache)
    return text
}

fun parsePlaylist(text: String): List<Channel> {
    val res = ArrayList<Channel>()
    val attr = Regex("([\\w-]+)=\"([^\"]*)\"")
    var name: String? = null
    var group = "Digər"
    var logo: String? = null
    var tvgId: String? = null
    var tvgName: String? = null
    for (raw in text.lineSequence()) {
        val line = raw.trim()
        if (line.isEmpty()) continue
        if (line.startsWith("#EXTINF")) {
            val comma = line.lastIndexOf(',')
            name = if (comma >= 0) line.substring(comma + 1).trim() else ""
            val head = if (comma >= 0) line.substring(0, comma) else line
            val a = attr.findAll(head).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
            group = a["group-title"]?.takeIf { it.isNotBlank() } ?: "Digər"
            logo = a["tvg-logo"]?.takeIf { it.startsWith("http") }
            tvgId = a["tvg-id"]?.takeIf { it.isNotBlank() }
            tvgName = a["tvg-name"]?.takeIf { it.isNotBlank() }
        } else if (line.startsWith("#EXTGRP:")) {
            group = line.substringAfter(':').trim().ifEmpty { "Digər" }
        } else if (!line.startsWith("#")) {
            if (name != null) {
                res.add(Channel(res.size + 1, name.ifBlank { line }, line, group, logo, tvgId, tvgName))
            }
            name = null; group = "Digər"; logo = null; tvgId = null; tvgName = null
        }
    }
    return res
}
