package az.vakansiya

import android.content.Context
import java.util.Calendar

/** Saytlardakı elanları sayan və "Xüsusi Vakansiya" açar sözlərini axtaran JS skriptləri (həm Counter, həm CheckWorker istifadə edir). */
object Scan {
    // ay adları: azərbaycanca, qısaltma, ingiliscə, rusca
    private val months = arrayOf(
        "yanvar|yan|january|jan|января",
        "fevral|fev|february|feb|февраля",
        "mart|mar|march|марта",
        "aprel|apr|april|апреля",
        "may|мая",
        "iyun|iyn|june|jun|июня",
        "iyul|iyl|july|jul|июля",
        "avqust|avq|august|aug|августа",
        "sentyabr|sen|september|sep|сентября",
        "oktyabr|okt|october|oct|октября",
        "noyabr|noy|november|nov|ноября",
        "dekabr|dek|december|dec|декабря"
    )
    private val end = "\$"
    private val nb = "(^|[^0-9])"
    private val na = "([^0-9]|$end)"

    private fun datePat(c: Calendar): String {
        val d = c.get(Calendar.DAY_OF_MONTH)
        val m = c.get(Calendar.MONTH) + 1
        val y = c.get(Calendar.YEAR)
        val yy = y % 100
        val mn = months[m - 1]
        return listOf(
            "${nb}0?$d[./-]0?$m[./-]($y|$yy)$na",
            "$y[./-]0?$m[./-]0?$d$na",
            "${nb}0?$d[ .]*($mn)",
            "($mn)[ .]*0?$d$na"
        ).joinToString("|")
    }

    private val tw = "bu gün|bugün|bu gun|bugun|today|сегодня|indicə|az əvvəl|just now"
    private val yw = "dünən|dunen|yesterday|вчера|${nb}(1|bir)[ ]*(gün|gun)[ ]*(əvvəl|evvel|öncə)|1 day ago"
    private val hr = "([0-9]+|bir)[ ]*(saat|hour|hr|час)[a-zəöüçşğı.]*[ ]*(əvvəl|evvel|öncə|ago|назад)"
    private val mn = "([0-9]+)[ ]*(dəq|dəqiqə|min|мин)[a-zəöüçşğı.]*[ ]*(əvvəl|evvel|öncə|ago|назад)"

    /** Ümumi (və "diqqətli" kart əsaslı) sayma skripti. */
    fun js(ctx: Context, careful: Boolean): String {
        val cal = Calendar.getInstance()
        val td = datePat(cal)
        cal.add(Calendar.DAY_OF_MONTH, -1)
        val yd = datePat(cal)
        return """(function(){
var L=JSON.parse(${Links.js(careful)});
var careful=$careful;
${Keywords.js(ctx)}
var TW=new RegExp("$tw"),YW=new RegExp("$yw"),TD=new RegExp("$td"),YD=new RegExp("$yd"),HR=new RegExp("$hr"),MN=new RegExp("$mn");
var DL=/(son tarix|son müraciət tarixi|son müraciət|deadline|bitmə tarixi|valid until)[: ]*[0-9]{1,2}[ .\/-]+[a-zəıöüçşğ0-9]+([ .\/-]+[0-9]{2,4})?/g;
var now=new Date(),mins=now.getHours()*60+now.getMinutes();
function cls(x){x=x.toLowerCase().replace(/\u0307/g,'').replace(/\s+/g,' ').replace(DL,' ');
if(YW.test(x))return 2;if(TW.test(x))return 1;
var m=x.match(HR);if(m){var n=(m[1]=='bir')?1:parseInt(m[1]);return n*60>mins?2:1}
m=x.match(MN);if(m){return parseInt(m[1])>mins?2:1}
if(TD.test(x))return 1;if(YD.test(x))return 2;return 0}
function lineCount(){var lines=(document.body?document.body.innerText:'').split('\n'),t=0,y=0,p='';
for(var i=0;i<lines.length;i++){var l=lines[i].replace(/\s+/g,' ').trim().toLowerCase();if(l.length<3||l===p)continue;p=l;var r=cls(l);if(r==1)t++;else if(r==2)y++}
return [t,y]}
function cardCount(){
var A=[],hs=document.querySelectorAll('h1 a[href],h2 a[href],h3 a[href],h4 a[href]');
for(var i=0;i<hs.length;i++){if(hs[i].innerText.trim().length>3&&hs[i].href.indexOf('http')==0)A.push(hs[i])}
if(A.length<3){
 for(var pass=0;pass<2&&A.length<3;pass++){A=[];var all=document.querySelectorAll('a[href]'),sig={},c=[];
  for(var i=0;i<all.length;i++){var a=all[i],u;try{u=new URL(a.href)}catch(e){continue}
   if(u.origin!==location.origin)continue;var seg=u.pathname.split('/').filter(Boolean);
   if(seg.length<1)continue;if(pass==0?!/[0-9]{3,}/.test(u.pathname):seg.length<2)continue;
   if(a.innerText.trim().length<4)continue;sig[seg[0]]=(sig[seg[0]]||0)+1;c.push([seg[0],a])}
  var best='',bn=0;for(var k in sig){if(sig[k]>bn){bn=sig[k];best=k}}
  for(var i=0;i<c.length;i++){if(c[i][0]===best)A.push(c[i][1])}}}
var seen={},t=0,y=0,n=0;
function dh(el){var d={},m=0;for(var i=0;i<A.length;i++){if(el.contains(A[i])&&!d[A[i].href]){d[A[i].href]=1;m++}}return m}
for(var i=0;i<A.length;i++){var h=A[i].href;if(seen[h])continue;seen[h]=1;n++;
 var el=A[i],card=A[i];
 for(var k=0;k<8&&el.parentElement&&el.parentElement!==document.body;k++){el=el.parentElement;if(dh(el)>1)break;card=el}
 var r=cls(card.innerText||'');if(r==1){t++;var tt=titleOf(A[i],card),kk=kindOf(tt);if(kk>0)S.push({n:tt,h:h,k:kk})}else if(r==2)y++}
return [t,y,n]}
var res=null,cc=cardCount();
if(careful){res=cc;if(res[2]<3||res[0]+res[1]==0)res=null}
if(!res)res=lineCount();
return JSON.stringify({t:res[0],y:res[1],l:L,s:S});})()"""
    }

    /**
     * JobSite.az: siyahıda yerləşdirmə tarixi yoxdur (yalnız "Son Tarix" - bitmə tarixi görünür).
     * Ona görə ən yeni elanların öz səhifələri açılır və "Yerləşdirilib ..." tarixi oxunur.
     */
    fun detailJs(ctx: Context, url: String): String {
        fun arr(c: Calendar) = "[${c.get(Calendar.DAY_OF_MONTH)},${c.get(Calendar.MONTH) + 1},${c.get(Calendar.YEAR)}]"
        val c1 = Calendar.getInstance()
        val c2 = Calendar.getInstance(); c2.add(Calendar.DAY_OF_MONTH, -1)
        val staj = Store.stajFilter(url)
        return """(function(){
var L=JSON.parse(${Links.js(false)});
var T=${arr(c1)},Y=${arr(c2)};
var F=$staj;
${Keywords.js(ctx)}
var t0=Date.now(),DEADLINE=40000;
var MON=['yanvar','fevral','mart','aprel','may','iyun','iyul','avqust','sentyabr','oktyabr','noyabr','dekabr'];
function eq(d,m,y,Z){return d==Z[0]&&m==Z[1]&&y==Z[2]}
function norm(z){return z.replace(/\s+/g,' ').toLowerCase().replace(/\u0307/g,'').trim()}
var W='[^a-zəıöüçşğ]';
var TITLE=new RegExp('(^|'+W+')(staj|stajçı|stajyor|intern|internship)('+W+'|${'$'})|təcrübəçi|təcrübə proqram|təcrübə keçmə');
var HEAD=new RegExp('(^|'+W+')(stajçı|stajyor|internship)('+W+'|${'$'})|təcrübəçi|təcrübə proqram');
var DRE=/yerləşdirilib ([0-9]{1,2}) ([a-zəıöüçşğ]+) ([0-9]{4})/;
function idOf(u){var m=u.match(/-([0-9]+)${'$'}/);return m?parseInt(m[1]):0}
function abs(a){try{return new URL(a.getAttribute('href'),location.href).href.split('#')[0]}catch(e){return ''}}
function jobLinks(root){var out=[],a=root.querySelectorAll('a[href]');
 for(var i=0;i<a.length;i++){var h=abs(a[i]);if(h.indexOf('/vakansiya-is-elani/')<0||!/-[0-9]+${'$'}/.test(h))continue;out.push(h)}return out}
function pn(h){var m=h.match(/(?:[?&](?:page|p)=|\/page\/)([0-9]+)/);return m?parseInt(m[1]):0}
function pageLinks(root){var r=[],a=root.querySelectorAll('a[href]');
 for(var i=0;i<a.length;i++){var h=abs(a[i]);if(!h||h.indexOf(location.origin)!==0)continue;
  if(pn(h)>0&&r.indexOf(h)<0)r.push(h)}
 r.sort(function(x,y){return pn(x)-pn(y)});return r.slice(0,7)}
function get(h,n){return new Promise(function(res){var c=new AbortController(),tm=setTimeout(function(){c.abort()},10000);
 fetch(h,{credentials:'omit',signal:c.signal}).then(function(r){clearTimeout(tm);if(!r.ok)throw 0;return r.text()})
 .then(res,function(){clearTimeout(tm);if(n>0)res(get(h,n-1));else res(null)})})}
var all={},list=[];
function addLinks(a){a.forEach(function(h){if(!all[h]){all[h]=1;list.push(h)}})}
addLinks(jobLinks(document));
var keep=[],fetched=[],t=0,y=0,fails=[],fin=false;
function proc(h,html){
 fetched.push(h);
 var x=norm(html.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi,' ').replace(/<[^>]*>/g,' '));
 var hd=x.split(' təsvir ')[0];
 var m=hd.match(DRE)||x.match(DRE),isT=false,isY=false;
 if(m){var dd=parseInt(m[1]),mo=MON.indexOf(m[2])+1,yr=parseInt(m[3]);isT=eq(dd,mo,yr,T);isY=!isT&&eq(dd,mo,yr,Y)}
 if(isT&&!F){var rt='';try{var d0=new DOMParser().parseFromString(html,'text/html');var e0=d0.querySelector('h1');rt=((e0&&e0.textContent)||d0.title||'').replace(/\s+/g,' ').trim()}catch(er){}var kk=kindOf(rt);if(kk>0)S.push({n:rt,h:h,k:kk})}
 if(F){var ttl='';try{var d=new DOMParser().parseFromString(html,'text/html');var e=d.querySelector('h1');ttl=norm((e&&e.textContent)||d.title||'')}catch(er){}
  var hw=hd.substring(Math.max(0,hd.length-450));
  if(!(TITLE.test(ttl)||HEAD.test(hw)))return isT||isY}
 keep.push(h);
 if(isT)t++;else if(isY)y++;
 return isT||isY}
function send(){if(fin)return;fin=true;
 Bridge.done(JSON.stringify({t:t,y:y,l:F?keep:L.concat(list),s:S}))}
function retryFails(){
 if(!fails.length||Date.now()-t0>DEADLINE+8000)return send();
 var f=fails;fails=[];
 Promise.all(f.map(function(h){return get(h,2)})).then(function(arr){
  arr.forEach(function(html,k){if(html!==null)proc(f[k],html)});send()})}
function run(){
 list.sort(function(a,b){return idOf(b)-idOf(a)});list=list.slice(0,250);
 if(list.length==0)return;
 var i=0,quiet=0;
 function step(){
  if(i>=list.length||Date.now()-t0>DEADLINE||quiet>=2)return retryFails();
  var batch=list.slice(i,i+15);i+=15;
  Promise.all(batch.map(function(h){return get(h,2)})).then(function(arr){
   var hit=0;
   arr.forEach(function(html,k){if(html===null){fails.push(batch[k]);return}if(proc(batch[k],html))hit++});
   quiet=hit>0?0:quiet+1;step()})}
 step()}
var pls=pageLinks(document);
Promise.all(pls.map(function(h){return get(h,2).then(function(html){
 if(!html)return;try{addLinks(jobLinks(new DOMParser().parseFromString(html,'text/html')))}catch(e){}})})).then(run,run);
})()"""
    }
}
