package az.market.endirim

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Marketlərin Instagram postlarından SON 3-ü diskdə saxlanır (şəkillər + yazı + tarix),
 * internet olmayanda da açılır.
 *
 * Qovluq: filesDir/insta/<market>/  →  posts.json + <kod>_<n>.jpg
 * Yeni postlar gələndə köhnə (3-dən kənar) şəkillər silinir.
 */
object InstaSaved {
    const val KEEP = 3

    class Post(val code: String, val ts: Long, val caption: String, val video: Boolean, val files: List<String>)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val http = OkHttpClient()
    private val CODE = Regex("[A-Za-z0-9_-]{4,40}")

    fun dirOf(ctx: Context, market: String): File =
        File(File(ctx.filesDir, "insta"), market.lowercase().replace(Regex("[^a-z0-9]+"), "_"))

    fun load(ctx: Context, market: String): List<Post> {
        return try {
            val d = dirOf(ctx, market)
            val f = File(d, "posts.json")
            if (!f.exists()) return emptyList()
            val arr = JSONObject(f.readText()).getJSONArray("posts")
            val out = ArrayList<Post>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val fa = o.getJSONArray("files")
                val files = (0 until fa.length()).map { fa.getString(it) }.filter { File(d, it).exists() }
                if (files.isNotEmpty()) out.add(Post(o.getString("code"), o.optLong("ts"), o.optString("caption"), o.optBoolean("video"), files))
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun lastSync(ctx: Context, market: String): Long {
        return try {
            val f = File(dirOf(ctx, market), "posts.json")
            if (f.exists()) JSONObject(f.readText()).optLong("at") else 0L
        } catch (e: Exception) {
            0L
        }
    }

    /**
     * json: [{c: kod, t: unix-saniyə, x: yazı, v: video?, u: [şəkil linkləri]}]
     * Ən yeni 3 post götürülür. Uğursuz olarsa əvvəlki saxlanmışlar toxunulmaz qalır.
     * done(n): saxlanmış post sayı (0 = dəyişiklik olmadı).
     */
    fun save(ctx: Context, market: String, json: String, done: (Int) -> Unit) {
        val app = ctx.applicationContext
        scope.launch {
            var n = 0
            try {
                val arr = JSONArray(json)
                val items = (0 until arr.length()).map { arr.getJSONObject(it) }
                    .filter { CODE.matches(it.optString("c")) }
                    .sortedByDescending { it.optLong("t") }
                    .take(KEEP)
                val d = dirOf(app, market)
                d.mkdirs()
                val old = load(app, market).associateBy { it.code }
                val result = ArrayList<Post>()
                for (o in items) {
                    val code = o.getString("c")
                    val prev = old[code]
                    if (prev != null) {
                        result.add(prev)
                        continue
                    }
                    val urls = o.getJSONArray("u")
                    val names = ArrayList<String>()
                    for (i in 0 until urls.length()) {
                        val name = code + "_" + i + ".jpg"
                        if (download(urls.getString(i), File(d, name))) names.add(name)
                    }
                    if (names.isNotEmpty()) {
                        result.add(Post(code, o.optLong("t"), o.optString("x"), o.optBoolean("v"), names))
                    }
                }
                if (result.isNotEmpty()) {
                    write(d, result)
                    val keep = result.flatMap { it.files }.toSet() + "posts.json"
                    d.listFiles()?.forEach { if (it.name !in keep) it.delete() }
                    n = result.size
                }
            } catch (e: Exception) {
            }
            done(n)
        }
    }

    private fun write(d: File, posts: List<Post>) {
        val arr = JSONArray()
        for (p in posts) {
            arr.put(JSONObject().apply {
                put("code", p.code)
                put("ts", p.ts)
                put("caption", p.caption)
                put("video", p.video)
                put("files", JSONArray(p.files))
            })
        }
        val root = JSONObject().put("at", System.currentTimeMillis()).put("posts", arr)
        val f = File(d, "posts.json")
        val tmp = File(f.path + ".part")
        tmp.writeText(root.toString())
        tmp.renameTo(f)
    }

    /** Yalnız Instagram CDN-dən (https) endirir. */
    private fun download(url: String, f: File): Boolean {
        try {
            val u = url.toHttpUrlOrNull() ?: return false
            val h = u.host
            if (!u.isHttps || !(h.endsWith("cdninstagram.com") || h.endsWith("fbcdn.net"))) return false
            val req = Request.Builder().url(u).header("User-Agent", Insta.UA).build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return false
                val body = r.body ?: return false
                val tmp = File(f.path + ".part")
                body.byteStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                if (tmp.length() == 0L) {
                    tmp.delete()
                    return false
                }
                return tmp.renameTo(f)
            }
        } catch (e: Exception) {
            return false
        }
        @Suppress("UNREACHABLE_CODE")
        return false
    }
}
