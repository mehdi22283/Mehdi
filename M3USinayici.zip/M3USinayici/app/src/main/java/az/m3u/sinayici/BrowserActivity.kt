package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.*
import android.widget.Toast
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.File
import java.util.concurrent.Executors
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Daxili qaranlıq brauzer (Ottplayer və GitHub axtarışı üçün).
 * - Endirilən M3U fayl filesDir/playlist<N>.m3u kimi saxlanılır (Ottplayer: 1, GitHub: 2).
 * - Media linkinə (m3u8, ts, mp4 …) toxunduqda və ya linkə uzun basdıqda link tətbiqin playerində açılır.
 */
class BrowserActivity : Activity() {
    private lateinit var web: WebView
    private var listNo = 1
    private var ghToken = ""
    private val pool = Executors.newFixedThreadPool(4)
    private var touchX = 0f
    private var touchY = 0f

    private val mediaExt = setOf("m3u8", "m3u", "ts", "mp4", "mkv", "mpd", "flv", "avi", "mov", "webm",
        "mp3", "aac", "m4a", "m4v", "3gp", "mpg", "mpeg")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        listNo = intent.getIntExtra("list", 1)
        ghToken = intent.getStringExtra("token") ?: ""
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; javaScriptCanOpenWindowsAutomatically = true }
        enableDark()
        CookieManager.getInstance().setAcceptCookie(true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = handleLink(r.url.toString())
            override fun onPageFinished(v: WebView, url: String?) {
                super.onPageFinished(v, url)
                if (url != null && Uri.parse(url).host?.endsWith("github.com") == true) v.evaluateJavascript(MARK_JS, null)
            }
        }
        web.addJavascriptInterface(object {
            /** GitHub (Turbo) səhifələrində klikləri tutmaq üçün: true qaytarsa link brauzerdə açılmır, native işlənir. */
            @JavascriptInterface fun link(url: String): Boolean {
                if (!intercepts(url)) return false
                runOnUiThread { handleLink(url) }
                return true
            }
            @JavascriptInterface fun check(id: Int, url: String) {
                pool.execute {
                    val r = try { Net.probe(url, "{}") } catch (e: Exception) { "dead" }
                    runOnUiThread { web.evaluateJavascript("window.__m3uStat&&__m3uStat($id,'$r')", null) }
                }
            }
        }, "M3UProbe")
        web.setOnTouchListener { _, e ->
            if (e.action == android.view.MotionEvent.ACTION_DOWN) { touchX = e.x; touchY = e.y }
            false
        }
        web.setOnLongClickListener {
            val hit = web.hitTestResult
            val link = hit.extra
            if ((hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                && link != null && link.startsWith("http")) {
                askPlay(link)
                true
            } else {
                // GitHub axtarış nəticələrində linklər sadə mətndir: toxunulan yerdəki linki tapır
                findUrlAtTouch()
                false
            }
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun saveBase64(s: String) = save(Base64.decode(s, Base64.DEFAULT))
        }, "NativeSave")
        web.setDownloadListener { url, ua, _, _, _ ->
            Toast.makeText(this, "Yüklənir...", Toast.LENGTH_SHORT).show()
            when {
                url.startsWith("blob:") -> web.evaluateJavascript(
                    "fetch('$url').then(r=>r.blob()).then(b=>{var f=new FileReader();f.onload=function(){NativeSave.saveBase64(f.result.split(',')[1]);};f.readAsDataURL(b);});", null)
                url.startsWith("data:") -> save(Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT))
                else -> Thread {
                    try {
                        val c = URL(url).openConnection() as HttpURLConnection
                        c.setRequestProperty("User-Agent", ua)
                        CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                        save(c.inputStream.readBytes())
                    } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() } }
                }.start()
            }
        }
        web.loadUrl(intent.getStringExtra("url") ?: "https://ottplayer.tv/playlist/original")
    }


    private fun askPlay(link: String) {
        AlertDialog.Builder(this).setTitle(link.take(80))
            .setItems(arrayOf("▶ Playerdə aç")) { _, _ -> playStream(link) }.show()
    }

    /** Uzun basılan yerdəki mətndən http(s) linkini çıxarır (GitHub kod axtarışı nəticələri link deyil, mətndir). */
    private fun findUrlAtTouch() {
        @Suppress("DEPRECATION")
        var sc = web.scale
        if (sc <= 0f) sc = resources.displayMetrics.density
        val x = touchX / sc; val y = touchY / sc
        val js = """
(function(x,y){
  try{
    var r=document.caretRangeFromPoint?document.caretRangeFromPoint(x,y):null; if(!r) return '';
    var n=r.startContainer, o=r.startOffset;
    var el=n.nodeType===3?n.parentElement:n, root=el;
    for(var i=0;i<8&&el;i++){ if((el.textContent||'').indexOf('http')>=0){ root=el; break; } el=el.parentElement; }
    if(!root) return '';
    var tw=document.createTreeWalker(root,NodeFilter.SHOW_TEXT), pos=0, caret=-1, t;
    while((t=tw.nextNode())){ if(t===n){ caret=pos+o; } pos+=t.nodeValue.length; }
    var text=root.textContent||'';
    var re=/https?:\/\/[^\s"'<>`\\]+/g, m, best='', bd=1e9;
    while((m=re.exec(text))){
      var u=m[0].replace(/[),.;\]}]+$/,''), s=m.index, e=s+u.length;
      var d=(caret>=s&&caret<=e)?0:Math.min(Math.abs(caret-s),Math.abs(caret-e));
      if(d<bd){ bd=d; best=u; }
    }
    return bd<=200?best:'';
  }catch(e){ return ''; }
})($x,$y)
"""
        web.evaluateJavascript(js) { v ->
            val u = try { org.json.JSONTokener(v ?: "").nextValue() as? String } catch (e: Exception) { null }
            if (!u.isNullOrEmpty() && u.startsWith("http")) askPlay(u)
        }
    }

    private fun enableDark() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, true)
        } else if (Build.VERSION.SDK_INT >= 29) {
            @Suppress("DEPRECATION")
            web.settings.forceDark = WebSettings.FORCE_DARK_ON
        }
    }

    /** Bu link native işlənməlidirmi (repo / media / GitHub-dakı M3U faylı)? */
    private fun intercepts(raw: String): Boolean {
        val u = Uri.parse(raw)
        if (u.scheme != "http" && u.scheme != "https") return false
        if (isRepoLink(u)) return true
        val ext = (u.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        if (ext !in mediaExt) return false
        if (u.host == "github.com") {
            val seg = u.pathSegments
            return (ext == "m3u" || ext == "m3u8") && seg.size >= 5 && seg[2] == "blob"
        }
        return true
    }

    /** true qaytarsa naviqasiya brauzerdə baş vermir (link ya playerdə açılır, ya da playlist kimi yadda saxlanılır). */
    private fun handleLink(raw: String): Boolean {
        val u = Uri.parse(raw)
        if (u.scheme != "http" && u.scheme != "https") return false
        if (isRepoLink(u)) { testRepo(u.pathSegments[0], u.pathSegments[1]); return true }
        val ext = (u.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        if (ext !in mediaExt) return false
        var url = raw
        if (u.host == "github.com") {
            val seg = u.pathSegments
            if (ext != "m3u" && ext != "m3u8") return false
            if (seg.size >= 5 && seg[2] == "blob") url = "https://raw.githubusercontent.com/${seg[0]}/${seg[1]}/${seg.drop(3).joinToString("/")}"
            else return false
        }
        if (ext == "m3u" || ext == "m3u8") {
            // kanal siyahısıdır, yoxsa canlı yayım (HLS)?
            Toast.makeText(this, "Yoxlanılır...", Toast.LENGTH_SHORT).show()
            val target = url
            Thread {
                var bytes: ByteArray? = null
                try {
                    val t = Net.Target(target, mapOf("User-Agent" to "VLC/3.0.20 LibVLC/3.0.20"), "brauzer")
                    val c = Net.connect(t, null, 10000)
                    bytes = c.inputStream.use { it.readBytes() }
                    c.disconnect()
                } catch (e: Exception) { }
                val text = bytes?.let { String(it, Charsets.UTF_8) } ?: ""
                val isList = bytes != null && text.contains("#EXTINF") && !text.contains("#EXT-X-")
                runOnUiThread { if (isList) save(bytes!!) else playStream(target) }
            }.start()
        } else playStream(url)
        return true
    }

    private fun playStream(url: String) {
        val name = Uri.decode(Uri.parse(url).lastPathSegment ?: url)
        PlayQueue.items = listOf(QItem(name, url, "{}")); PlayQueue.index = 0
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun save(bytes: ByteArray) {
        val t = String(bytes, Charsets.UTF_8)
        runOnUiThread {
            if (!t.contains("#EXTINF") && !t.contains("#EXTM3U")) {
                Toast.makeText(this, "Endirilən fayl M3U deyil", Toast.LENGTH_LONG).show(); return@runOnUiThread
            }
            File(filesDir, "playlist$listNo.m3u").writeText(t)
            setResult(RESULT_OK, Intent().putExtra("list", listNo)); finish()
        }
    }

    // ---------- GitHub repo: M3U fayllarını tap, 2-ci playlistdə yoxla ----------
    private val reserved = setOf("search", "settings", "orgs", "topics", "marketplace", "features", "login", "signup",
        "explore", "notifications", "sponsors", "collections", "trending", "pricing", "about", "contact", "issues", "pulls",
        "codespaces", "new", "join", "site", "enterprise", "readme", "security", "apps", "users", "organizations")

    private fun isRepoLink(u: Uri): Boolean {
        if (u.host != "github.com") return false
        val seg = u.pathSegments
        return seg.size == 2 && seg[0].lowercase() !in reserved
    }

    private fun gh(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "M3USinayici")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        if (ghToken.isNotEmpty()) c.setRequestProperty("Authorization", "token $ghToken")
        return c
    }

    private fun encSeg(p: String) = p.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    private fun testRepo(owner: String, repo: String) {
        Toast.makeText(this, "$owner/$repo yoxlanılır...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val c = gh("https://api.github.com/repos/$owner/$repo/git/trees/HEAD?recursive=1")
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                c.disconnect()
                val j = JSONObject(txt)
                if (code !in 200..299) throw java.io.IOException(j.optString("message", "GitHub xətası (HTTP $code)"))
                val tree = j.getJSONArray("tree")
                val files = ArrayList<String>()
                for (i in 0 until tree.length()) {
                    val o = tree.getJSONObject(i)
                    val path = o.getString("path")
                    val low = path.lowercase()
                    if (o.getString("type") == "blob" && (low.endsWith(".m3u") || low.endsWith(".m3u8")) && o.optLong("size", 0) < 30L * 1024 * 1024) files.add(path)
                }
                files.sort()
                runOnUiThread {
                    when {
                        files.isEmpty() -> Toast.makeText(this, "Bu repoda M3U fayl tapılmadı", Toast.LENGTH_LONG).show()
                        files.size == 1 -> loadRepoFile(owner, repo, files[0])
                        else -> AlertDialog.Builder(this).setTitle("$owner/$repo — fayl seçin")
                            .setItems(files.take(60).toTypedArray()) { _, w -> loadRepoFile(owner, repo, files[w]) }.show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Repo xətası: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun loadRepoFile(owner: String, repo: String, path: String) {
        Toast.makeText(this, "Yüklənir: $path", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val c = URL("https://raw.githubusercontent.com/$owner/$repo/HEAD/${encSeg(path)}").openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 60000
                c.setRequestProperty("User-Agent", "M3USinayici")
                val bytes = c.inputStream.use { it.readBytes() }
                c.disconnect()
                val t = String(bytes, Charsets.UTF_8)
                if (!t.contains("#EXTINF")) runOnUiThread { Toast.makeText(this, "Bu fayl kanal siyahısı deyil", Toast.LENGTH_LONG).show() }
                else save(bytes)
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Yükləmə xətası: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    override fun onDestroy() { pool.shutdownNow(); super.onDestroy() }

    companion object {
        /** GitHub səhifəsində mətn şəklindəki linklərin yanına 🟢/🔴 qoyur (yoxlama native aparılır). */
        val MARK_JS = """(function(){
if(window.__m3uInit){ if(window.__m3uScan) window.__m3uScan(); return; }
window.__m3uInit=true;
var state={}, ids={}, nid=0, total=0, MAX=200;
var skipHost=/(^|\.)(github\.com|githubusercontent\.com|githubassets\.com|githubapp\.com)#SP#/i;
var media=/\.(m3u8?|ts|mp4|mkv|mpd|flv|avi|mov|webm|mp3|aac|m4a|m4v|3gp|mpg|mpeg)#SP#/i;
var re=/https?:\/\/[^\s"'<>`\\]+/g;
function cleanEnd(u){ return u.replace(/[),.;\]}]+#SP#/,''); }
function good(u){ try{ var x=new URL(u.split('|')[0]); if(skipHost.test(x.hostname)) return false;
  var p=x.pathname; return !!x.port || media.test(p) || p.split('/').filter(Boolean).length>=2; }catch(e){ return false; } }
function paint(sp,st){ sp.textContent = st==='ok' ? ' 🟢' : st==='dead' ? ' 🔴' : ' ⏳'; }
window.__m3uStat=function(id,st){
  var u=ids[id]; if(!u) return; state[u]=st;
  var all=document.querySelectorAll('span.m3u-st');
  for(var i=0;i<all.length;i++){ if(all[i].getAttribute('data-url')===u) paint(all[i],st); }
};
function mark(u){
  var sp=document.createElement('span'); sp.className='m3u-st'; sp.setAttribute('data-url',u);
  sp.style.cssText='user-select:none;-webkit-user-select:none';
  if(state[u]===undefined){ state[u]='pending'; var id=++nid; ids[id]=u; try{ M3UProbe.check(id,u); }catch(e){} }
  paint(sp, state[u]==='pending' ? '' : state[u]);
  return sp;
}
function processNode(node){
  var text=node.nodeValue, m, found=[]; re.lastIndex=0;
  while((m=re.exec(text))){ var u=cleanEnd(m[0]); if(good(u)) found.push({u:u,end:m.index+u.length}); }
  for(var i=found.length-1;i>=0;i--){
    if(total>=MAX) return;
    var f=found[i], par=node.parentNode; if(!par) return;
    if(f.end>=node.nodeValue.length){
      var nx=node.nextSibling; if(nx && nx.nodeType===1 && nx.className==='m3u-st') continue;
      par.insertBefore(mark(f.u), node.nextSibling);
    } else {
      var rest=node.splitText(f.end); par.insertBefore(mark(f.u), rest);
    }
    total++;
  }
}
function scan(){
  if(total>=MAX || !document.body) return;
  var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode:function(n){
    var p=n.parentNode; if(!p) return 2; var t=p.nodeName;
    if(t==='SCRIPT'||t==='STYLE'||t==='TEXTAREA'||t==='NOSCRIPT') return 2;
    if(p.className==='m3u-st') return 2; return 1; }});
  var nodes=[], n; while((n=w.nextNode())){ if(n.nodeValue.indexOf('http')>=0) nodes.push(n); }
  nodes.forEach(processNode);
}
window.__m3uScan=scan;
document.addEventListener('click',function(e){
  var a=e.target&&e.target.closest?e.target.closest('a[href]'):null; if(!a||!a.href) return;
  try{ if(M3UProbe.link(a.href)){ e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); } }catch(x){}
},true);
var timer=null;
new MutationObserver(function(){ clearTimeout(timer); timer=setTimeout(scan,700); }).observe(document.body,{childList:true,subtree:true});
scan();
})();""".replace("#SP#", "$")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
