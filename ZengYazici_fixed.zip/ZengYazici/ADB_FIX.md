# Zəng Yazıcı — WhatsApp səs yazısı üçün düzəliş

## Nə dəyişdirildi

1. WhatsApp/VoIP zəngində yazıcı artıq təkcə `CAMCORDER` (audio source 5) mikrofon mənbəyini sınamır. Əvvəl `VOICE_DOWNLINK` (3), `VOICE_CALL` (4) və `REMOTE_SUBMIX` (8) mənbələrini mikrofonla birlikdə yoxlayır; bunlar işləməsə `VOICE_COMMUNICATION` (7), `VOICE_RECOGNITION` (6), `MIC` (1) və əvvəlki `CAMCORDER` ehtiyat variantına keçir.
2. WhatsApp/VoIP zəngi zamanı dinamik üçün başlanğıc ayarı aktivdir. Qulaqlıq/Bluetooth qulaqlıq qoşuludursa proqram dinamiki məcburi açmır; zəng bitəndə əvvəlki dinamik vəziyyəti bərpa olunur. Tətbiqin menyusundan funksiyanı söndürmək mümkündür.

## ADB ilə mövcud tətbiqin icazələrini yoxlamaq

Skript `127.0.0.1:5555` ünvanına `adb connect` ilə qoşulur və bütün əmrləri həmin ADB hədəfinə yönləndirir. Bu yalnız o halda işləyir ki, lokal cihaz/emulyator TCP ADB bağlantısını 5555 portunda dinləsin. Əvvəl `adb connect 127.0.0.1:5555` və `adb devices -l` ilə yoxlayın. Windows-da `ADB_FIX_WINDOWS.bat`, Linux/macOS-da `ADB_FIX.sh` faylını işə salın.

ADB əmrləri (skript bunları `adb -s 127.0.0.1:5555` hədəfi ilə icra edir):

```sh
adb shell pm grant com.zengyazici android.permission.RECORD_AUDIO
adb shell pm grant com.zengyazici android.permission.READ_PHONE_STATE
adb shell pm grant com.zengyazici android.permission.READ_CALL_LOG
adb shell pm grant com.zengyazici android.permission.POST_NOTIFICATIONS
adb shell appops set com.zengyazici RECORD_AUDIO allow
adb shell appops set com.zengyazici SYSTEM_ALERT_WINDOW allow
adb shell appops set com.zengyazici RUN_IN_BACKGROUND allow
adb shell appops set com.zengyazici RUN_ANY_IN_BACKGROUND allow
adb shell dumpsys deviceidle whitelist +com.zengyazici
adb shell cmd notification allow_listener com.zengyazici/com.zengyazici.WaListener
adb shell am force-stop com.zengyazici
adb shell monkey -p com.zengyazici 1
```

`POST_NOTIFICATIONS` Android 13-dən köhnə sistemlərdə xəta verə bilər; bu əmri həmin sistemlərdə ötürmək olar.

## Dəyişdirilmiş tətbiqi qurmaq

Bu arxiv **Android Studio layihəsinin mənbə kodudur, APK deyil**. Layihəni Android Studio-da açın və `Build > Build APK(s)` seçin. Sonra yaranan `app-debug.apk` faylını belə quraşdırın:

```sh
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Əgər `INSTALL_FAILED_UPDATE_INCOMPATIBLE` çıxarsa, imza uyğun gəlmir. Tətbiqi silmədən əvvəl qeydləri `Music/ZengYazici` qovluğuna ixrac edib yedəkləyin; sonra köhnə tətbiqi silib yeni APK-nı quraşdırmaq lazım gələ bilər.

## Vacib məhdudiyyət

`VOICE_CALL`, `VOICE_DOWNLINK` və `REMOTE_SUBMIX` bəzi Android/istehsalçı versiyalarında sistem səviyyəsində qorunur. Bu mənbələr ADB shell kontekstində belə əlçatan deyilsə, adi ADB icazə əmrləri onları aça bilməz. Android-in `CAPTURE_AUDIO_OUTPUT` icazəsi adi üçüncü tərəf tətbiqlərinə verilən icazə deyil. Belə cihazda dinamik açıq olanda mikrofonla akustik yazı işləyə bilər, lakin qulaqcıq/Bluetooth ilə qarşı tərəfin səsi yazılmaya bilər.

Sınaq üçün əvvəl bir sınaq WhatsApp zəngi edin, sonra tətbiqdə `Menyu → Log` bölməsinə baxın. `Secilen plan: ...` və `menbe-peak:` sətirləri hansı audio mənbəyinin faktiki səs aldığını göstərir.

## Son dəyişiklik: mikrofon + kamera mikrofonu

WhatsApp/internet zəngində plan artıq `!1+5*1.5` ilə başlayır: səsiniz telefonun mikrofonundan (mənbə 1), qarşı tərəfin səsi dinamikdən kamera mikrofonundan (mənbə 5) alınır və iki axın bir fayla qarışdırılır. Dinamik zəng boyu açıq saxlanır və zəng səsi 90%-ə qaldırılır (qulaqlıq qoşuludursa toxunulmur). Alınmasa ehtiyat planlar: `1+5*2`, `7+5*1.5`, `1`, `5*4`, `5`. Log-da `menbe-peak: 1=… 5=…` sətrində hər iki mənbənin səs tutub-tutmadığı görünür.

## Exo düzəlişi (adi telefon zəngi)

Telefon zəngində plan sırası `4;3+2;3+1;7;1` oldu: qarşı tərəf (3) ilə mikrofonun (1) əvəzinə əvvəlcə qarşı tərəf ilə gedən səs axını (2) qarışdırılır, çünki bu axında akustik sızma yoxdur. Mikrofonla qarışdırma ehtiyat qalır; orada qarşı tərəf danışanda və mikrofon ondan zəif olanda (sızma) mikrofon 10%-ə salınır. WhatsApp planı (`!1+5`) bu qaydadan istisnadır.
