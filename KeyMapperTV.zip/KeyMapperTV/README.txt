1) Build APK (Android Studio veya GitHub Actions)
2) adb connect 192.168.31.220:5555
   adb install -r app-debug.apk
3) TV-de "Key Mapper TV" tetbiqini bir defe acin (yalniz servisi baslad0131r).
4) Ilk qosulmada ADB icazesi cixsa: "Always allow".
