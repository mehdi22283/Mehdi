# IPTV Player — kanal keçidi və yayım sabitliyi

- Əsas pleyer Media3 ExoPlayer-dir; axın açılmadıqda VLC (libVLC 3.6.0) ehtiyat pleyer kimi sınanır.
- Kanal seçilən kimi köhnə VLC hadisələri kanal nəsli ilə etibarsızlaşdırılır. VLC hadisəsi UI növbəsinə göndərilməzdən əvvəl kanal nəsli tutulur ki, gecikmiş hadisə yeni kanalı dəyişməsin.
- Kanal dəyişərkən qara örtük köhnə SurfaceView kadrını gizlədir. Örtük yalnız yeni pleyer real oynatma vəziyyətinə keçəndə götürülür; uğursuz yayımda köhnə donmuş kadr əvəzinə xəta göstərilir.
- VLC media yaratma, dəyişmə, təmizləmə və playback əmrləri ardıcıl arxa plan növbəsində icra olunur. Köhnə Exo keçidinin gecikmiş təmizləmə əmri yeni VLC axınını silə bilməz.
- VLC `Playing` hadisəsindən sonra `TimeChanged` və `PositionChanged` irəliləyişi də izlənir. 18 saniyə ərzində media vaxtı/posisiyası irəliləməzsə yayım bir dəfə yenidən başladılır; uğursuz cəhddən sonra mənbə təmizlənir və xəta göstərilir.
- VLC `Buffering`, `EncounteredError` və `EndReached` hadisələri izlənir. İlkin açılışda 10 saniyəlik nəzarət, davam edən yayımda isə ayrıca irəliləyiş nəzarəti var.
- ExoPlayer-in ilkin açılış vaxtı 5 saniyə, HTTP bağlantı/oxuma vaxtları 5/8 saniyədir.
- Bufer dəyərləri: Exo min 10 saniyə, max 20 saniyə, ilkin 2 saniyə, rebufer 4 saniyə; VLC network-caching 3 saniyə, live-caching 2.5 saniyədir.
- IPTV mənbəsi, kodek və cihaz davranışı fərqli olduğuna görə real yayım sınağı mütləqdir. Bu iş mühitində Android SDK/Gradle olmadığı üçün APK kompilyasiyası və canlı kanal sınağı aparılmayıb.


Yenilənmə: Media3/ExoPlayer 1.11.1 istifadə olunur. Əsas və yeganə avtomatik playback yolu ExoPlayer-dir; səs kodeki, xəta, STATE_ENDED və açılış vaxtı bitməsi VLC-yə avtomatik keçid yaratmır. ExoPlayer açılış gözləməsi 15 saniyədir.
