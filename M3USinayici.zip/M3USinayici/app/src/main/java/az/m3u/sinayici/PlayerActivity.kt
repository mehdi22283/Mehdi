package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.*
import androidx.media3.common.*
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.LoadEventInfo
import androidx.media3.exoplayer.source.MediaLoadData
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.net.HttpURLConnection
import java.net.URL

/** Tam ExoPlayer: keyfiyyət, sürət, səs, altyazı, görünüş + statistika (ölçü, bitrate, gecikmə, endirmə sürəti, bufer). */
class PlayerActivity : Activity() {
    private lateinit var player: ExoPlayer
    private lateinit var pv: PlayerView
    private lateinit var statsTv: TextView
    private lateinit var bar: HorizontalScrollView
    private val h = Handler(Looper.getMainLooper())
    private var url = ""; private var latency = -1L; private var speedBps = -1L; private var prevAhead = -1L
    private var alive = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val ds = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) ExoPlayer").setConnectTimeoutMs(10000).setReadTimeoutMs(10000)
        player = ExoPlayer.Builder(this).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build()
        pv = PlayerView(this).apply { player = this@PlayerActivity.player; setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS) }
        statsTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; setBackgroundColor(0x99000000.toInt()); setPadding(14, 6, 14, 6) }
        bar = HorizontalScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(btn("🔲 Keyfiyyət") { pick(C.TRACK_TYPE_VIDEO, "Keyfiyyət (resolution)") })
                addView(btn("⏩ Sürət") { pickSpeed() })
                addView(btn("🔊 Səs") { pick(C.TRACK_TYPE_AUDIO, "Səs yolu") })
                addView(btn("💬 Altyazı") { pick(C.TRACK_TYPE_TEXT, "Altyazı") })
                addView(btn("🖼 Görünüş") { cycleResize() })
                addView(btn("🔄 Yenilə") { start(url) })
            })
        }
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { bar.visibility = if (it == View.VISIBLE) View.VISIBLE else View.GONE })
        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(statsTv); addView(bar) }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(pv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(top, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.START))
        })
        player.addListener(object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                statsTv.text = "❌ Xəta: ${e.errorCodeName}"
                h.postDelayed({ if (alive) player.prepare() }, 4000)
            }
        })
        player.addAnalyticsListener(object : AnalyticsListener {
            override fun onLoadCompleted(t: AnalyticsListener.EventTime, i: LoadEventInfo, d: MediaLoadData) {
                if (i.loadDurationMs > 0) speedBps = i.bytesLoaded * 8000 / i.loadDurationMs
            }
        })
        start(intent.getStringExtra("url") ?: ""); tick(); probeLoop()
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); intent = i; start(i.getStringExtra("url") ?: "") }

    private fun start(u: String) {
        url = u; prevAhead = -1; latency = -1; speedBps = -1
        player.setMediaItem(MediaItem.fromUri(u)); player.prepare(); player.playWhenReady = true
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; textSize = 11f; isAllCaps = false; setOnClickListener { f() } }

    private fun fmt(bps: Long) = when {
        bps <= 0 -> "naməlum"; bps >= 1_000_000 -> "%.2f Mbps".format(bps / 1e6); else -> "${bps / 1000} kbps"
    }

    private fun tick() {
        if (!alive) return
        val f = player.videoFormat
        val res = if (f != null && f.width > 0) "${f.width}×${f.height}" else "naməlum"
        val br = f?.let { if (it.bitrate > 0) it.bitrate else it.averageBitrate }?.toLong() ?: -1L
        val ahead = player.totalBufferedDuration
        val lab = when {
            player.playbackState != Player.STATE_READY || ahead <= 100 -> "🔴"
            ahead < 2000 -> "🟠"
            prevAhead >= 0 && ahead - prevAhead < -200 -> "🟡"
            else -> "🟢"
        }
        prevAhead = ahead
        statsTv.text = "🔲 $res  ⚡ ${fmt(br)}  🛰 ${if (latency >= 0) "$latency ms" else "naməlum"}  ⬇ ${fmt(speedBps)}  🪣 $lab  ⏩ ${player.playbackParameters.speed}x"
        h.postDelayed({ tick() }, 1000)
    }

    /** İlk bayta qədər gecikmə (HTML-dəki measureNetworkOnce kimi), hər 6 saniyədə bir. */
    private fun probeLoop() {
        if (!alive) return
        Thread {
            try {
                val t = System.nanoTime()
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000; c.setRequestProperty("Range", "bytes=0-0")
                c.inputStream.read(); latency = (System.nanoTime() - t) / 1_000_000; c.disconnect()
            } catch (e: Exception) {}
        }.start()
        h.postDelayed({ probeLoop() }, 6000)
    }

    private fun pick(type: Int, title: String) {
        val names = mutableListOf(if (type == C.TRACK_TYPE_TEXT) "Söndür" else "Avto")
        val refs = mutableListOf<Pair<TrackGroup, Int>>()
        for (g in player.currentTracks.groups) if (g.type == type) for (i in 0 until g.length) {
            if (!g.isTrackSupported(i)) continue
            val f = g.getTrackFormat(i)
            names.add(when (type) {
                C.TRACK_TYPE_VIDEO -> "${f.height}p" + if (f.bitrate > 0) "  ${f.bitrate / 1000} kbps" else ""
                else -> (f.label ?: f.language ?: "Yol ${refs.size + 1}") + if (f.channelCount > 0) "  ${f.channelCount}ch" else ""
            })
            refs.add(g.mediaTrackGroup to i)
        }
        AlertDialog.Builder(this).setTitle(title).setItems(names.toTypedArray()) { _, w ->
            val b = player.trackSelectionParameters.buildUpon().clearOverridesOfType(type)
            if (w == 0) b.setTrackTypeDisabled(type, type == C.TRACK_TYPE_TEXT)
            else { b.setTrackTypeDisabled(type, false); b.setOverrideForType(TrackSelectionOverride(refs[w - 1].first, refs[w - 1].second)) }
            player.trackSelectionParameters = b.build()
        }.show()
    }

    private fun pickSpeed() {
        val v = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        AlertDialog.Builder(this).setTitle("Sürət").setItems(v.map { "${it}x" }.toTypedArray()) { _, w -> player.setPlaybackSpeed(v[w]) }.show()
    }

    private fun cycleResize() {
        val m = intArrayOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM)
        val n = (m.indexOf(pv.resizeMode) + 1) % m.size
        pv.resizeMode = m[n]
        Toast.makeText(this, listOf("Sığdır", "Uzat", "Yaxınlaşdır")[n], Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() { alive = false; h.removeCallbacksAndMessages(null); player.release(); super.onDestroy() }
}
