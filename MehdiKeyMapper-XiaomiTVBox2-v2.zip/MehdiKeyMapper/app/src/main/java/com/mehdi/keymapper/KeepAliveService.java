package com.mehdi.keymapper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

public class KeepAliveService extends Service {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            AccessibilityState.ensureEnabled(KeepAliveService.this);
            KeyInjectorClient.init(KeepAliveService.this);
            handler.postDelayed(this, 10000L);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification notification = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(
                        Config.NOTIFICATION_ID,
                        notification,
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(Config.NOTIFICATION_ID, notification);
            }
        } catch (Throwable ignored) {
            startForeground(Config.NOTIFICATION_ID, notification);
        }
        KeyInjectorClient.init(this);
        handler.post(watchdog);
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, Config.NOTIFICATION_CHANNEL)
                .setSmallIcon(com.mehdi.keymapper.R.drawable.ic_key_mapper)
                .setContentTitle("Mehdi Key Mapper")
                .setContentText("Key mapping service is active")
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(pi)
                .setShowWhen(false)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            NotificationChannel c = new NotificationChannel(
                    Config.NOTIFICATION_CHANNEL,
                    "Key Mapper service",
                    NotificationManager.IMPORTANCE_LOW);
            c.setSound(null, null);
            c.setShowBadge(false);
            nm.createNotificationChannel(c);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
