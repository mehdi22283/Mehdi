package az.videoyabax.tv

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import java.io.IOException

/** Hazırda aktiv olan video sessiyası (telefondan gələn axın). */
object StreamSessionHolder {
    @Volatile
    var current: StreamBuffer? = null
}

/**
 * ExoPlayer üçün xüsusi məlumat mənbəyi.
 * Faylı nə diskdən, nə də şəbəkədən oxumur — birbaşa telefonun göndərdiyi
 * RAM buferindən oxuyur. Beləliklə video TV-yə yazılmadan anlıq oynanılır.
 */
@UnstableApi
class StreamDataSource : BaseDataSource(/* isNetwork = */ true) {

    private var uri: Uri? = null
    private var session: StreamBuffer? = null
    private var basePosition = 0L
    private var readPosition = 0L
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        val s = StreamSessionHolder.current
            ?: throw IOException("Aktiv video sessiyası yoxdur")
        uri = dataSpec.uri
        session = s
        basePosition = dataSpec.position
        readPosition = 0L
        opened = true
        transferStarted(dataSpec)
        return if (dataSpec.length != C.LENGTH_UNSET.toLong()) dataSpec.length else C.LENGTH_UNSET.toLong()
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        val s = session ?: throw IOException("Sessiya mövcud deyil")
        val read = s.read(basePosition + readPosition, buffer, offset, length)
        if (read > 0) {
            readPosition += read
            bytesTransferred(read.toLong())
        }
        return read
    }

    override fun close() {
        if (opened) {
            opened = false
            transferEnded()
        }
        session = null
    }

    override fun getUri(): Uri? = uri

    override fun getReadPosition(): Long = if (opened) readPosition else 0L
}

/** ExoPlayer üçün mənbə fabriki. */
@UnstableApi
class StreamDataSourceFactory : DataSource.Factory {
    override fun createDataSource(): DataSource = StreamDataSource()
}
