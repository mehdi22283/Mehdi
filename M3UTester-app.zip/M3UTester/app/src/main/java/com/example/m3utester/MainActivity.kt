package com.example.m3utester

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private var list = mutableListOf<Ch>()
    private var shown = listOf<Int>()      // göstərilən kanalların ƏSAS siyahıdakı indeksləri
    private var onlyBad = false
    private var since = 0L
    private val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
    private lateinit var status: TextView
    private lateinit var head1: TextView
    private lateinit var head2: TextView
    private lateinit var head3: TextView
    private lateinit var filterBtn: Button
    private lateinit var adapter: BaseAdapter

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val text = contentResolver.openInputStream(uri)!!.bufferedReader().readText()
        val prev = list.associate { it.url to it.ok }
        list = parseM3u(text).onEach { it.ok = prev[it.url] }
        Store.save(this, list)
        refreshView()
        runTest()
    }

    private val browser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) { list = Store.load(this); refreshView(); runTest() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33)
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.POST_NOTIFICATIONS)

        val sp = getSharedPreferences("m3u", 0)
        val now = System.currentTimeMillis()
        since = b?.getLong("since") ?: sp.getLong("last", now)
        sp.edit().putLong("last", now).apply()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val ott = Button(this).apply {
            text = "OTT Player-ə daxil ol"
            setOnClickListener { browser.launch(Intent(this@MainActivity, BrowserActivity::class.java)) }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); setBackgroundColor(0x22888888)
        }
        head1 = TextView(this)
        head2 = TextView(this).apply { textSize = 17f }
        head3 = TextView(this).apply { maxLines = 3; ellipsize = TextUtils.TruncateAt.END }
        box.addView(head1); box.addView(head2); box.addView(head3)

        val load = Button(this).apply { text = "M3U yüklə"; setOnClickListener { picker.launch(arrayOf("*/*")) } }
        filterBtn = Button(this).apply {
            setOnClickListener { onlyBad = !onlyBad; refreshView() }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(load, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(filterBtn, LinearLayout.LayoutParams(0, -2, 1f))

        status = TextView(this).apply { setPadding(0, 12, 0, 12) }
        val lv = ListView(this)
        root.addView(ott); root.addView(box); root.addView(row); root.addView(status)
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        list = Store.load(this)
        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int) = list[shown[p]]
            override fun getItemId(p: Int) = shown[p].toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
                val i = shown[p]
                val c = list[i]
                val icon = when (c.ok) { true -> "🟢"; false -> "🔴"; null -> "⏳" }
                return (v as? TextView ?: TextView(this@MainActivity).apply { textSize = 16f; setPadding(8, 20, 8, 20) })
                    .also { it.text = "${i + 1}. $icon  ${c.name}" }
            }
        }
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, p, _ ->
            val i = shown[p]
            startActivity(Intent(this, PlayerActivity::class.java)
                .putExtra("n", list[i].name).putExtra("u", list[i].url).putExtra("i", i + 1))
        }
        refreshView()
        updateSummary()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "check", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<CheckWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); o.putLong("since", since) }

    private fun runTest() = lifecycleScope.launch {
        val old = list.map { it.ok }
        list.forEach { it.ok = null }
        refreshView()
        var k = 0
        testAll(list) { if (++k % 10 == 0) refreshView() }
        History.add(this@MainActivity, diff(old, list))
        Store.save(this@MainActivity, list)
        refreshView()
        updateSummary()
    }

    private fun refreshView() {
        shown = list.indices.filter { !onlyBad || list[it].ok == false }
        adapter.notifyDataSetChanged()
        val bad = list.count { it.ok == false }
        filterBtn.text = if (onlyBad) "Hamısı (${list.size})" else "🔴 İşləməyənlər ($bad)"
        status.text = "🟢 ${list.count { it.ok == true }}   🔴 $bad   ⏳ ${list.count { it.ok == null }}"
    }

    private fun updateSummary() {
        val changed = History.load(this).filter { it.t >= since }.groupBy { it.url }.values.mapNotNull { g ->
            val f = g.minBy { it.t }; val l = g.maxBy { it.t }
            if (l.ok == f.ok) l else null   // başlanğıc vəziyyətdən fərqli qalanlar
        }
        head1.text = "Son girişdən bəri (${fmt.format(Date(since))})"
        head2.text = "🔴 ${changed.count { !it.ok }} xarab oldu    🟢 ${changed.count { it.ok }} düzəldi"
        head3.text = changed.joinToString(", ") { (if (it.ok) "🟢 " else "🔴 ") + it.name }
        head3.visibility = if (changed.isEmpty()) View.GONE else View.VISIBLE
    }
}
