package az.zengyazici;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int BLUE = 0xFF1E6FE0, GREEN = 0xFF2E9E4F;

    static class Holder { SeekBar sb; ImageButton btn; TextView time; File f; int dur; }

    LinearLayout list;
    TextView status;
    MediaPlayer mp;
    Holder cur;
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable tick = new Runnable() {
        @Override public void run() {
            try {
                if (mp != null && cur != null && mp.isPlaying()) {
                    int p = mp.getCurrentPosition();
                    cur.sb.setProgress(p);
                    cur.time.setText(fmt(p) + " / " + fmt(cur.dur));
                    h.postDelayed(this, 300);
                }
            } catch (Exception e) { }
        }
    };

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    static String fmt(int ms) { int s = ms / 1000; return String.format(Locale.US, "%d:%02d", s / 60, s % 60); }
    boolean has(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }
    boolean enabled(String key) {
        String s = Settings.Secure.getString(getContentResolver(), key);
        return s != null && s.contains(getPackageName());
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("Zəng yazıcı");
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.BLACK);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(14);
        status.setTextColor(0xFF333333);
        status.setPadding(0, dp(8), 0, dp(8));
        root.addView(status);

        root.addView(btn("İcazələri ver", v -> requestPermissions(new String[]{
                Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CALL_LOG, Manifest.permission.PROCESS_OUTGOING_CALLS,
                Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS}, 1)));
        root.addView(btn("WhatsApp üçün bildiriş girişini aç", v ->
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))));
        root.addView(btn("Əlçatanlıq xidmətini aç", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(btn("Başqa tətbiqlərin üstündə göstər (popup)", v ->
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))));

        TextView sl = new TextView(this);
        sl.setText("Səs mənbəyi (Xiaomi-də qarşı tərəf eşidilmirsə növbə ilə sınayın):");
        sl.setTextSize(13);
        sl.setTextColor(0xFF333333);
        sl.setPadding(0, dp(12), 0, 0);
        root.addView(sl);
        final String[] names = {"Avto", "VOICE_CALL (4)", "VOICE_COMMUNICATION (7)", "VOICE_RECOGNITION (6)", "MIC (1)", "UNPROCESSED (9)", "CAMCORDER (5)"};
        final int[] vals = {0, 4, 7, 6, 1, 9, 5};
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        int saved = getSharedPreferences("cfg", MODE_PRIVATE).getInt("src", 0);
        for (int k = 0; k < vals.length; k++) if (vals[k] == saved) sp.setSelection(k);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                getSharedPreferences("cfg", MODE_PRIVATE).edit().putInt("src", vals[pos]).apply();
            }
            @Override public void onNothingSelected(AdapterView<?> a) { }
        });
        root.addView(sp);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(12), 0, 0);
        root.addView(list);
        setContentView(sv);
    }

    Button btn(String t, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(t);
        x.setAllCaps(false);
        x.setOnClickListener(l);
        return x;
    }

    @Override protected void onResume() { super.onResume(); refresh(); }
    @Override protected void onPause() { super.onPause(); stopPlayer(); }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { refresh(); }

    void refresh() {
        stopPlayer();
        status.setText((has(Manifest.permission.RECORD_AUDIO) && has(Manifest.permission.READ_PHONE_STATE) ? "✓" : "✗") + " Mikrofon / telefon icazələri\n"
                + (enabled("enabled_notification_listeners") ? "✓" : "✗") + " WhatsApp bildiriş girişi\n"
                + (enabled("enabled_accessibility_services") ? "✓" : "✗") + " Əlçatanlıq xidməti\n"
                + (Settings.canDrawOverlays(this) ? "✓" : "✗") + " Popup (başqa tətbiqlərin üstündə)");
        list.removeAllViews();
        File d = getExternalFilesDir("calls");
        File[] fs = d == null ? null : d.listFiles((dir, n) -> n.endsWith(".m4a"));
        if (fs == null || fs.length == 0) {
            TextView e = new TextView(this);
            e.setText("Hələ yazı yoxdur.");
            e.setTextColor(0xFF777777);
            list.addView(e);
            return;
        }
        Arrays.sort(fs, (a, c) -> c.getName().compareTo(a.getName()));
        for (File f : fs) {
            View r = row(f);
            if (r != null) list.addView(r);
        }
    }

    String lookupName(String num) {
        if (num.equals("-") || !has(Manifest.permission.READ_CONTACTS)) return null;
        try (Cursor c = getContentResolver().query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
                new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception e) { }
        return null;
    }

    GradientDrawable bg(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    View row(final File f) {
        String[] p = f.getName().replace(".m4a", "").split("__", -1);
        if (p.length < 4) return null;
        long ts;
        try { ts = Long.parseLong(p[0]); } catch (Exception e) { return null; }
        boolean wa = p[1].equals("wa"), in = p[2].equals("in");
        String num = p[3];
        String srcId = p.length > 4 ? p[4] : "";
        String contact = lookupName(num);
        String name = num.equals("-") ? "Naməlum nömrə" : (contact != null ? contact : num);

        int dur = 0;
        try {
            MediaMetadataRetriever mr = new MediaMetadataRetriever();
            mr.setDataSource(f.getAbsolutePath());
            dur = Integer.parseInt(mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            mr.release();
        } catch (Exception e) { }

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(8));
        card.setBackground(bg(0xFFF2F4F7, 16));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(10);
        card.setLayoutParams(cp);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView ic = new ImageView(this);
        ic.setImageResource(in ? R.drawable.ic_call_received : R.drawable.ic_call_made);
        GradientDrawable oval = new GradientDrawable();
        oval.setShape(GradientDrawable.OVAL);
        oval.setColor(in ? GREEN : BLUE);
        ic.setBackground(oval);
        ic.setPadding(dp(8), dp(8), dp(8), dp(8));
        top.addView(ic, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams mp1 = new LinearLayout.LayoutParams(0, -2, 1f);
        mp1.leftMargin = dp(12);
        top.addView(mid, mp1);

        LinearLayout l1 = new LinearLayout(this);
        l1.setGravity(Gravity.CENTER_VERTICAL);
        TextView tn = new TextView(this);
        tn.setText(name);
        tn.setTextSize(16);
        tn.setTypeface(null, Typeface.BOLD);
        tn.setTextColor(Color.BLACK);
        tn.setSingleLine(true);
        l1.addView(tn, new LinearLayout.LayoutParams(-2, -2));
        TextView chip = new TextView(this);
        chip.setText(wa ? "WhatsApp" : "Telefon");
        chip.setTextSize(11);
        chip.setTextColor(Color.WHITE);
        chip.setBackground(bg(wa ? 0xFF25D366 : 0xFF607D8B, 10));
        chip.setPadding(dp(8), dp(2), dp(8), dp(2));
        LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(-2, -2);
        chp.leftMargin = dp(8);
        l1.addView(chip, chp);
        mid.addView(l1);

        TextView sub = new TextView(this);
        sub.setText(new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(new Date(ts))
                + "  ·  " + (in ? "Gələn" : "Gedən") + "  ·  " + fmt(dur) + (srcId.isEmpty() ? "" : "  ·  mənbə " + srcId));
        sub.setTextSize(12);
        sub.setTextColor(0xFF666666);
        mid.addView(sub);

        TextView del = new TextView(this);
        del.setText("✕");
        del.setTextSize(18);
        del.setTextColor(0xFF999999);
        del.setPadding(dp(10), dp(4), dp(4), dp(4));
        del.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("Bu yazı silinsin?")
                .setPositiveButton("Sil", (d, w) -> { stopPlayer(); f.delete(); refresh(); })
                .setNegativeButton("Ləğv et", null).show());
        top.addView(del);
        card.addView(top);

        final Holder hd = new Holder();
        hd.f = f; hd.dur = dur;
        LinearLayout pl = new LinearLayout(this);
        pl.setGravity(Gravity.CENTER_VERTICAL);
        hd.btn = new ImageButton(this);
        hd.btn.setImageResource(android.R.drawable.ic_media_play);
        hd.btn.setBackground(null);
        hd.btn.setColorFilter(in ? GREEN : BLUE);
        hd.btn.setOnClickListener(v -> toggle(hd));
        pl.addView(hd.btn, new LinearLayout.LayoutParams(dp(44), dp(44)));
        hd.sb = new SeekBar(this);
        hd.sb.setMax(Math.max(dur, 1));
        hd.sb.getProgressDrawable().setTint(in ? GREEN : BLUE);
        hd.sb.getThumb().setTint(in ? GREEN : BLUE);
        hd.sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                if (user && cur == hd && mp != null) { mp.seekTo(v); hd.time.setText(fmt(v) + " / " + fmt(hd.dur)); }
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        pl.addView(hd.sb, new LinearLayout.LayoutParams(0, -2, 1f));
        hd.time = new TextView(this);
        hd.time.setText("0:00 / " + fmt(dur));
        hd.time.setTextSize(11);
        hd.time.setTextColor(0xFF666666);
        pl.addView(hd.time);
        card.addView(pl);
        return card;
    }

    void toggle(Holder x) {
        if (cur == x && mp != null) {
            if (mp.isPlaying()) { mp.pause(); x.btn.setImageResource(android.R.drawable.ic_media_play); }
            else { mp.start(); x.btn.setImageResource(android.R.drawable.ic_media_pause); h.post(tick); }
            return;
        }
        stopPlayer();
        try {
            mp = new MediaPlayer();
            mp.setDataSource(x.f.getAbsolutePath());
            mp.prepare();
            x.dur = mp.getDuration();
            x.sb.setMax(x.dur);
            mp.setOnCompletionListener(m -> {
                x.btn.setImageResource(android.R.drawable.ic_media_play);
                x.sb.setProgress(0);
                x.time.setText("0:00 / " + fmt(x.dur));
            });
            cur = x;
            mp.start();
            x.btn.setImageResource(android.R.drawable.ic_media_pause);
            h.post(tick);
        } catch (Exception e) {
            Toast.makeText(this, "Fayl açılmadı", Toast.LENGTH_SHORT).show();
            stopPlayer();
        }
    }

    void stopPlayer() {
        h.removeCallbacks(tick);
        if (mp != null) { try { mp.release(); } catch (Exception e) { } mp = null; }
        if (cur != null) {
            cur.btn.setImageResource(android.R.drawable.ic_media_play);
            cur.sb.setProgress(0);
            cur.time.setText("0:00 / " + fmt(cur.dur));
            cur = null;
        }
    }
}
