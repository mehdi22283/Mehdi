package az.axtaris.baza

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Xml
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import org.xmlpull.v1.XmlPullParser
import java.io.*
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class Card(val path: String, val title: String, val headers: List<String>, val cells: List<String>, val rowId: Long = -1L, val bname: String = "", val skey: String = "")

/** WhatsApp (yaşıl) və Mesaj (mavi) ikonları — kodla çəkilir */
private class IconView(ctx: Context, private val whatsapp: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var sent = false
    override fun onDraw(c: Canvas) {
        val s = Math.min(width, height).toFloat() / 100f
        c.save()
        c.scale(s, s)
        if (whatsapp) {
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#25D366")
            c.drawCircle(50f, 50f, 50f, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = 6f
            c.drawCircle(50f, 48f, 26f, p)
            p.style = Paint.Style.FILL
            val tail = Path()
            tail.moveTo(22f, 80f); tail.lineTo(28f, 58f); tail.lineTo(43f, 71f); tail.close()
            c.drawPath(tail, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.strokeCap = Paint.Cap.ROUND
            val h = Path()
            h.moveTo(41f, 38f); h.cubicTo(39f, 52f, 48f, 60f, 61f, 59f)
            c.drawPath(h, p)
            p.style = Paint.Style.FILL
            c.drawCircle(41f, 38f, 5f, p); c.drawCircle(61f, 59f, 5f, p)
        } else {
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#1E88E5")
            c.drawCircle(50f, 50f, 50f, p)
            p.color = Color.WHITE
            c.drawRoundRect(RectF(22f, 28f, 78f, 64f), 11f, 11f, p)
            val tail = Path()
            tail.moveTo(34f, 62f); tail.lineTo(31f, 77f); tail.lineTo(49f, 64f); tail.close()
            c.drawPath(tail, p)
            p.color = Color.parseColor("#1E88E5")
            c.drawCircle(37f, 46f, 4.5f, p); c.drawCircle(50f, 46f, 4.5f, p); c.drawCircle(63f, 46f, 4.5f, p)
        }
        if (sent) {
            // "göndərildi" işarəsi: yaşıl dairə içində ağ ✓
            p.style = Paint.Style.FILL; p.color = Color.WHITE
            c.drawCircle(80f, 20f, 21f, p)
            p.color = Color.parseColor("#2E7D32")
            c.drawCircle(80f, 20f, 17f, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = 5f; p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            val ck = Path()
            ck.moveTo(71f, 21f); ck.lineTo(77f, 27f); ck.lineTo(89f, 13f)
            c.drawPath(ck, p)
        }
        c.restore()
    }
}

private const val TAX_URL = "https://e-belediyye.gov.az/tax-debts"
private const val WORKERS = 3

// ---- saytda YVÖK xanasını doldurub "Yoxla" düyməsinə basan skriptlər ----
private const val JS_FINDER = """
function vis(e){return !!(e&&(e.offsetWidth||e.offsetHeight||(e.getClientRects&&e.getClientRects().length)));}
function findForm(){
  var inp=null,btn=null;
  var inputs=document.querySelectorAll('input');
  for(var i=0;i<inputs.length;i++){var t=(inputs[i].type||'text').toLowerCase();
    if((t==='text'||t==='search'||t==='tel'||t==='')&&!inputs[i].disabled&&vis(inputs[i])){inp=inputs[i];break;}}
  var bs=document.querySelectorAll('button,input[type=submit],input[type=button],a');
  for(var j=0;j<bs.length;j++){var tx=((bs[j].innerText||bs[j].value||'')+'').replace(/\s+/g,' ').trim().toLowerCase();
    if(tx==='yoxla'&&vis(bs[j])){btn=bs[j];break;}}
  return {inp:inp,btn:btn};
}
"""
private const val JS_READY = "(function(){" + JS_FINDER +
    "var f=findForm();return JSON.stringify({ok:!!(f.inp&&f.btn),text:document.body?document.body.innerText:''});})()"
private const val JS_STATE = "(function(){return JSON.stringify({text:document.body?document.body.innerText:''});})()"

private fun jsFill(code: String): String = "(function(code){" + JS_FINDER +
    "var f=findForm();if(!f.inp||!f.btn)return 'noform';" +
    "var set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;" +
    "f.inp.focus();set.call(f.inp,code);" +
    "f.inp.dispatchEvent(new Event('input',{bubbles:true}));" +
    "f.inp.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true}));" +
    "f.inp.dispatchEvent(new Event('change',{bubbles:true}));" +
    "setTimeout(function(){f.btn.click();},150);return 'ok';})(" + JSONObject.quote(code) + ")"

class MainActivity : Activity() {

    private lateinit var db: SQLiteDatabase
    private lateinit var editsDb: SQLiteDatabase
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var mainSearch: SearchUi
    private lateinit var catSearch: SearchUi
    private lateinit var searchPanel: LinearLayout
    private lateinit var catPanel: LinearLayout
    private lateinit var btnSearch: Button
    private lateinit var btnCat: Button
    private lateinit var webHost: FrameLayout
    private var refresher: Refresher? = null

    // catalog state
    private lateinit var tvPath: TextView
    private lateinit var tvTotal: TextView
    private lateinit var catList: ListView
    private val cardAdapterCat by lazy { CardAdapter() }
    private var level = 0
    private var fileId = 0L
    private var streetId = 0L
    private var buildingId = 0L
    private var fileName = ""
    private var streetName = ""
    private var catIds = ArrayList<Long>()
    private var catNames = ArrayList<String>()
    private var catCounts = ArrayList<Int>()
    private var catBorc = ArrayList<Double>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = openDb()
        buildUi()
        showTab(true)
    }

    // ---------- database ----------
    private fun openDb(): SQLiteDatabase {
        // redaktələr və saytdan çəkilən məlumatlar ayrıca faylda da saxlanılır ki, baza yenilənəndə itməsin
        editsDb = openOrCreateDatabase("edits.db", MODE_PRIVATE, null)
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS edits(file TEXT, sheet TEXT, ord INTEGER, col INTEGER, value TEXT, PRIMARY KEY(file, sheet, ord, col))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS imp_sheets(file TEXT, sheet TEXT, title TEXT, headers TEXT, PRIMARY KEY(file, sheet))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS imp_rows(file TEXT, sheet TEXT, ord INTEGER, cells TEXT, PRIMARY KEY(file, sheet, ord))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS renames(kind TEXT, a TEXT, b TEXT, value TEXT, PRIMARY KEY(kind, a, b))")
        editsDb.execSQL("CREATE TABLE IF NOT EXISTS sent(skey TEXT, kind TEXT, PRIMARY KEY(skey, kind))")
        editsDb.rawQuery("SELECT skey, kind FROM sent", null).use { c -> while (c.moveToNext()) sentSet.add(c.getString(0) + "|" + c.getString(1)) }
        val f = File(filesDir, "data.db")
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val ver = 6
        var fresh = false
        if (!f.exists() || prefs.getInt("dbver", 0) != ver) {
            assets.open("data.db").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            prefs.edit().putInt("dbver", ver).apply()
            fresh = true
        }
        val d = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READWRITE)
        var hasDisp = false
        d.rawQuery("PRAGMA table_info(files)", null).use { c -> while (c.moveToNext()) if (c.getString(1) == "disp") hasDisp = true }
        if (!hasDisp) d.execSQL("ALTER TABLE files ADD COLUMN disp TEXT")
        if (fresh) { replayImports(d); replayEdits(d); replayRenames(d) }
        return d
    }

    private fun replayEdits(d: SQLiteDatabase) {
        editsDb.rawQuery("SELECT file, sheet, ord, col, value FROM edits", null).use { c ->
            while (c.moveToNext()) {
                d.rawQuery(
                    "SELECT r.id, r.cells, b.headers FROM rows r JOIN buildings b ON b.id = r.building_id " +
                        "JOIN files f ON f.id = b.file_id WHERE f.name = ? AND b.sheet = ? AND r.ord = ?",
                    arrayOf(c.getString(0), c.getString(1), c.getInt(2).toString())
                ).use { r ->
                    if (r.moveToFirst()) {
                        val cells = jsonList(r.getString(1)).toMutableList()
                        val col = c.getInt(3)
                        while (cells.size <= col) cells.add("")
                        cells[col] = c.getString(4)
                        writeRow(d, r.getLong(0), cells, jsonList(r.getString(2)))
                    }
                }
            }
        }
    }

    private fun fold(s: String): String {
        var t = s.replace('İ', 'i').replace('I', 'ı').lowercase(Locale.ROOT)
        t = t.replace('ə', 'e').replace('ı', 'i').replace('ö', 'o').replace('ü', 'u')
            .replace('ş', 's').replace('ç', 'c').replace('ğ', 'g')
        return t.trim().replace(Regex("\\s+"), " ")
    }

    private fun jsonList(s: String): List<String> {
        val a = JSONArray(s); return List(a.length()) { a.getString(it) }
    }

    private fun colIdx(headers: List<String>, prefix: String) = headers.indexOfFirst { fold(it).startsWith(prefix) }

    /** Ad, Soyad, Atasının adı və Borc sütunları əl ilə redaktə olunmur (saytdan yenilənir) */
    private fun isReadOnly(h: String): Boolean {
        val f = fold(h)
        return f.startsWith("soyad") || f.startsWith("ad, soyad") || f.startsWith("ad,soyad") || f == "borc"
    }

    private fun nameIdx(headers: List<String>) = headers.indexOfFirst { isReadOnly(it) && fold(it) != "borc" }

    private fun parseNum(s: String): Double =
        s.replace("\u00A0", "").replace(" ", "").replace(',', '.').toDoubleOrNull() ?: 0.0

    private fun money(v: Double) = String.format(Locale.US, "%.2f", v)
    private fun totalText(borc: Double, count: Int) = "Ümumi Borc (${money(borc)}) / Ümumi Mənzil ($count)"

    private fun writeRow(d: SQLiteDatabase, id: Long, cells: List<String>, headers: List<String>) {
        d.execSQL("UPDATE rows SET cells = ? WHERE id = ?", arrayOf<Any>(JSONArray(cells).toString(), id))
        val mi = colIdx(headers, "menzil")
        if (mi >= 0 && mi < cells.size) d.execSQL("UPDATE rows SET menzil = ?, menzil_n = ? WHERE id = ?", arrayOf<Any>(cells[mi], fold(cells[mi]), id))
        val ni = colIdx(headers, "nomre")
        if (ni >= 0 && ni < cells.size) d.execSQL("UPDATE rows SET nomre_d = ? WHERE id = ?", arrayOf<Any>(cells[ni].filter { it.isDigit() }, id))
        val si = nameIdx(headers)
        if (si >= 0 && si < cells.size) {
            val toks = cells[si].trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            val so = toks.getOrElse(0) { "" }; val ad = toks.getOrElse(1) { "" }; val at = toks.drop(2).joinToString(" ")
            d.execSQL(
                "UPDATE rows SET soyad = ?, ad = ?, ata = ?, soyad_n = ?, ad_n = ?, ata_n = ? WHERE id = ?",
                arrayOf<Any>(so, ad, at, fold(so), fold(ad), fold(at), id)
            )
        }
        val bi = colIdx(headers, "borc")
        if (bi >= 0 && bi < cells.size) d.execSQL("UPDATE rows SET borc = ? WHERE id = ?", arrayOf<Any>(parseNum(cells[bi]), id))
    }

    private fun rowOf(vararg items: Pair<View, Float>): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            items.forEachIndexed { i, (v, w) ->
                addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w).apply {
                    if (i > 0) leftMargin = dp(6)
                })
            }
        }

    // ---------- əl ilə redaktə ----------
    private fun showEditDialog(card: Card, onSaved: (List<String>) -> Unit) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val inputs = arrayOfNulls<EditText>(card.headers.size)
        for (i in card.headers.indices) {
            val h = card.headers[i]
            val v = card.cells.getOrNull(i).orEmpty()
            val label = TextView(this)
            label.text = h; label.textSize = 12f; label.setTextColor(Color.GRAY); label.setPadding(0, dp(10), 0, 0)
            col.addView(label)
            if (isReadOnly(h)) {
                val t = TextView(this)
                t.text = (if (v.isEmpty()) "—" else v) + "   🔒"; t.textSize = 15f; t.setTextColor(Color.GRAY)
                col.addView(t)
            } else {
                val e = EditText(this)
                e.setText(v); e.textSize = 15f; e.isSingleLine = true
                inputs[i] = e
                col.addView(e)
            }
        }
        val sv = ScrollView(this)
        sv.setPadding(dp(20), dp(8), dp(20), 0)
        sv.addView(col)
        AlertDialog.Builder(this)
            .setTitle("Redaktə et")
            .setView(sv)
            .setPositiveButton("Yadda saxla") { _, _ -> saveEdit(card, inputs, onSaved) }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun saveEdit(card: Card, inputs: Array<EditText?>, onSaved: (List<String>) -> Unit) {
        val newCells = card.cells.toMutableList()
        while (newCells.size < card.headers.size) newCells.add("")
        db.rawQuery(
            "SELECT f.name, b.sheet, r.ord FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.id = ?", arrayOf(card.rowId.toString())
        ).use { c ->
            if (c.moveToFirst()) {
                val fname = c.getString(0); val sheet = c.getString(1); val ord = c.getInt(2)
                for (i in inputs.indices) {
                    val e = inputs[i] ?: continue
                    val nv = e.text.toString().trim()
                    if (nv != newCells[i]) {
                        newCells[i] = nv
                        editsDb.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", arrayOf<Any>(fname, sheet, ord, i, nv))
                    }
                }
            }
        }
        writeRow(db, card.rowId, newCells, card.headers)
        onSaved(newCells)
        Toast.makeText(this, "Yadda saxlanıldı", Toast.LENGTH_SHORT).show()
    }

    // =====================================================================
    //  Saytdan yeniləmə (Soyad, Ad, Atasının adı və Borc)
    // =====================================================================
    data class Job(val rowId: Long, val yvok: String)
    data class Parsed(val name: String?, val borc: String?, val notFound: Boolean, val raw: String)

    private fun validYvok(v: String): Boolean {
        val t = v.trim()
        return t.length == 12 && t.startsWith("10011") && t.none { it.isWhitespace() }
    }

    /** scopeSql/arg və ya ids əsasında yenilənəcək mənzilləri toplayıb (arxa planda) işə salır */
    private fun startRefresh(label: String, scopeSql: String?, arg: String?, ids: List<Long>?) {
        if (refresher != null) { Toast.makeText(this, "Yenilənmə artıq davam edir", Toast.LENGTH_SHORT).show(); return }
        Thread {
            val jobs = ArrayList<Job>()
            var noYvok = 0
            val sql: String; val args: Array<String>
            if (ids != null) {
                if (ids.isEmpty()) { sql = ""; args = emptyArray() }
                else {
                    sql = "SELECT r.id, r.cells, b.headers FROM rows r JOIN buildings b ON b.id = r.building_id WHERE r.id IN (" +
                        ids.joinToString(",") + ") ORDER BY b.file_id, b.ord, r.ord"
                    args = emptyArray()
                }
            } else {
                sql = "SELECT r.id, r.cells, b.headers FROM rows r JOIN buildings b ON b.id = r.building_id " +
                    (if (scopeSql != null) "WHERE $scopeSql " else "") + "ORDER BY b.file_id, b.ord, r.ord"
                args = if (arg != null) arrayOf(arg) else emptyArray()
            }
            if (sql.isNotEmpty()) {
                try {
                    db.rawQuery(sql, args).use { c ->
                        while (c.moveToNext()) {
                            val headers = jsonList(c.getString(2))
                            val yi = colIdx(headers, "yvok")
                            val cells = jsonList(c.getString(1))
                            val v = if (yi >= 0 && yi < cells.size) cells[yi].trim() else ""
                            if (validYvok(v)) jobs.add(Job(c.getLong(0), v)) else noYvok++
                        }
                    }
                } catch (e: Exception) { /* ignore */ }
            }
            runOnUiThread { confirmRefresh(label, jobs, noYvok) }
        }.start()
    }

    private fun confirmRefresh(label: String, jobs: List<Job>, noYvok: Int) {
        if (jobs.isEmpty()) {
            Toast.makeText(this, "Yenilənəcək YVÖK tapılmadı", Toast.LENGTH_LONG).show(); return
        }
        val go = { launchRefresh(jobs, noYvok) }
        if (jobs.size > 100) {
            val mins = Math.max(1, (jobs.size * 0.9 / 60).toInt())
            AlertDialog.Builder(this)
                .setTitle("Saytdan yenilə")
                .setMessage("$label\n${jobs.size} mənzil yenilənəcək (təxminən $mins dəq). Yenilənmə zamanı tətbiq açıq qalmalıdır.\n\nDavam edilsin?")
                .setPositiveButton("Bəli") { _, _ -> go() }
                .setNegativeButton("Xeyr", null)
                .show()
        } else go()
    }

    private fun launchRefresh(jobs: List<Job>, noYvok: Int) {
        val r = Refresher(ArrayList(jobs), noYvok)
        refresher = r
        r.start()
    }

    /** Saytın cavabından ad və borcu çıxarır */
    private fun parseResult(base: String, text: String): Parsed {
        val baseLines = base.lines().map { it.trim() }.toSet()
        val lines = text.lines().map { it.trim() }
            .filter { it.isNotEmpty() && it !in baseLines && !it.startsWith("Yoxlanılır") }
        val raw = lines.joinToString("\n")
        val ff = lines.map { fold(it) }

        // ---- borc ----
        val numRe = Regex("""-?\d+(?:[ \u00A0]\d{3})*(?:[.,]\d{1,2})?""")
        fun norm(s: String): String {
            val d = s.replace("\u00A0", "").replace(" ", "").replace(',', '.').toDoubleOrNull() ?: 0.0
            return if (d == Math.floor(d)) d.toLong().toString() else money(d)
        }
        // ---- saytın əsas nəticə formatı:
        // "10011MBM2046 / MUSTAFAYEV BARAT MEHDİ adına Binəqədi bələdiyyəsi üzrə olan vergi borcu: 0 manat." ----
        val joined = lines.joinToString(" ").replace(Regex("\\s+"), " ")
        val mainRe = Regex("""(\S+)\s*/\s*(.+?)\s+ad[ıiİI]na\s.*?borcu\s*:\s*(-?\d[\d\u00A0 ]*(?:[.,]\d{1,2})?)""", RegexOption.IGNORE_CASE)
        val mm = mainRe.find(joined)
        if (mm != null) {
            val fullName = mm.groupValues[2].replace(Regex("\\s+"), " ").trim()
            return Parsed(fullName.ifEmpty { null }, norm(mm.groupValues[3].trim()), false, raw)
        }

        var borc: String? = null
        for (i in lines.indices) {
            if (!ff[i].contains("borc")) continue
            val after = if (lines[i].contains(':')) lines[i].substringAfter(':') else lines[i]
            val m = numRe.find(after)
            if (m != null) { borc = norm(m.value); break }
            if (ff[i].contains("yoxdur") || ff[i].contains("olmayib") || ff[i].contains("qalmayib")) { borc = "0"; break }
            if (i + 1 < lines.size && lines[i + 1].length < 30) {
                val m2 = numRe.find(lines[i + 1])
                if (m2 != null) { borc = norm(m2.value); break }
            }
        }
        if (borc == null) {
            val m = Regex("""(\d+(?:[.,]\d{1,2})?)\s*(?:azn|₼|manat)""", RegexOption.IGNORE_CASE).find(raw)
            if (m != null) borc = norm(m.groupValues[1])
        }

        // ---- ad, soyad, atasının adı ----
        var name: String? = null
        var soyad: String? = null; var ad: String? = null; var ata: String? = null
        for (i in lines.indices) {
            val f = ff[i]
            if (f.contains("borc")) continue
            val label = f.substringBefore(':').trim()
            fun value(): String? {
                val v = if (lines[i].contains(':')) lines[i].substringAfter(':').trim() else ""
                if (v.isNotEmpty()) return v
                if (i + 1 < lines.size && !ff[i + 1].contains("borc")) return lines[i + 1]
                return null
            }
            when {
                label == "soyad" -> soyad = soyad ?: value()
                label == "ad" -> ad = ad ?: value()
                label.startsWith("ata") -> ata = ata ?: value()
                name == null && (label.startsWith("soyad") || label.startsWith("ad, soyad") || label.startsWith("ad soyad") ||
                    label.contains("vetendas") || label.contains("mulkiyyetci") || label.contains("sahibi") || label.contains("ad, ")) -> name = value()
            }
        }
        if (soyad != null || ad != null) {
            name = listOfNotNull(soyad, ad, ata).joinToString(" ")
        }
        if (name == null) {
            // etiketsiz: rəqəmsiz, ən azı 2 sözlü, hərflərdən ibarət ilk sətir
            for (i in lines.indices) {
                val l = lines[i]; val f = ff[i]
                if (f.contains("borc") || f.contains("tapilmadi") || f.contains("yoxdur") || f.contains("deyil") || f.contains("yvok")) continue
                if (l.any { it.isDigit() } || l.contains(':')) continue
                if (l.trim().split(Regex("\\s+")).size >= 2) { name = l.trim(); break }
            }
        }
        val notFound = borc == null && name == null &&
            (ff.any { it.contains("tapilmadi") || it.contains("movcud deyil") || it.contains("duzgun deyil") || it.contains("melumat yoxdur") })
        return Parsed(name?.replace(Regex("\\s+"), " ")?.trim(), borc, notFound, raw)
    }

    /** nəticəni bazaya yazır; redaktə/yeniləmə qeydi ayrıca faylda da saxlanılır */
    private fun applyFetched(rowId: Long, name: String?, borc: String?) {
        db.rawQuery(
            "SELECT r.cells, b.headers, f.name, b.sheet, r.ord FROM rows r JOIN buildings b ON b.id = r.building_id " +
                "JOIN files f ON f.id = b.file_id WHERE r.id = ?", arrayOf(rowId.toString())
        ).use { c ->
            if (!c.moveToFirst()) return
            val cells = jsonList(c.getString(0)).toMutableList()
            val headers = jsonList(c.getString(1))
            val fname = c.getString(2); val sheet = c.getString(3); val ord = c.getInt(4)
            while (cells.size < headers.size) cells.add("")
            var changed = false
            fun setCol(i: Int, v: String) {
                if (i >= 0 && i < cells.size && cells[i] != v) {
                    cells[i] = v
                    editsDb.execSQL("INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?)", arrayOf<Any>(fname, sheet, ord, i, v))
                    changed = true
                }
            }
            if (name != null) setCol(nameIdx(headers), name)
            if (borc != null) setCol(colIdx(headers, "borc"), borc)
            if (changed) writeRow(db, rowId, cells, headers)
        }
    }

    inner class Refresher(private val jobs: ArrayList<Job>, private val noYvok: Int) {
        private val total = jobs.size
        private var done = 0
        private var updated = 0
        private var notFound = 0
        private var failed = 0
        private var cancelled = false
        private var running = 0
        private var finished = false
        private var sample: String? = null
        private val workers = ArrayList<Worker>()
        private lateinit var dialog: AlertDialog
        private lateinit var tvStatus: TextView
        private lateinit var bar: ProgressBar

        fun start() {
            val box = LinearLayout(this@MainActivity)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(20), dp(16), dp(20), dp(4))
            tvStatus = TextView(this@MainActivity)
            tvStatus.text = "Sayta qoşulur…"; tvStatus.textSize = 15f
            bar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal)
            bar.max = total
            box.addView(tvStatus)
            box.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            dialog = AlertDialog.Builder(this@MainActivity)
                .setTitle("Saytdan yenilənir")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Dayandır", null)
                .create()
            dialog.show()
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                cancelled = true
                tvStatus.text = "Dayandırılır…"
            }
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            val n = Math.min(WORKERS, total)
            for (i in 0 until n) { val w = Worker(); workers.add(w); running++ }
            workers.forEach { it.next() }
        }

        private fun progress() {
            tvStatus.text = "Yenilənir: $done / $total   (tapıldı: $updated, tapılmadı: $notFound, xəta: $failed)"
            bar.progress = done
        }

        private fun workerFinished(w: Worker) {
            w.destroy()
            running--
            if (running <= 0 && !finished) finish()
        }

        private fun finish() {
            finished = true
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            try { dialog.dismiss() } catch (e: Exception) { }
            refresher = null
            val msg = "Yeniləndi: $updated, tapılmadı: $notFound, xəta: $failed" +
                (if (noYvok > 0) ", YVÖK-sü olmayan: $noYvok" else "") + (if (cancelled) " (dayandırıldı)" else "")
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
            afterRefresh()
            val s = sample
            if (s != null) {
                val tv = TextView(this@MainActivity)
                tv.text = s; tv.textSize = 13f; tv.setTextIsSelectable(true); tv.setPadding(dp(20), dp(12), dp(20), dp(4))
                val sv = ScrollView(this@MainActivity); sv.addView(tv)
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Saytın cavabı tam oxunmadı")
                    .setView(sv)
                    .setPositiveButton("Bağla", null)
                    .show()
            }
        }

        inner class Worker {
            private val wv = WebView(this@MainActivity)
            private var job: Job? = null
            private var attempt = 0
            private var token = 0
            private var base = ""
            private var last = ""
            private var stable = 0
            private var loading = false

            init {
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                wv.settings.blockNetworkImage = true
                wv.alpha = 0.01f
                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        if (job != null && loading) { loading = false; pollReady(token, 0) }
                    }
                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        if (request?.isForMainFrame == true && job != null && loading) { loading = false; failAttempt() }
                    }
                }
                webHost.addView(wv, FrameLayout.LayoutParams(dp(360), dp(640)))
            }

            fun destroy() {
                token++
                try { webHost.removeView(wv); wv.destroy() } catch (e: Exception) { }
            }

            fun next() {
                if (cancelled) { workerFinished(this); return }
                val j = jobs.removeFirstOrNull()
                if (j == null) { workerFinished(this); return }
                job = j; attempt = 0
                startAttempt()
            }

            private fun startAttempt() {
                attempt++
                token++
                val t = token
                loading = true
                stable = 0; last = ""
                wv.loadUrl(TAX_URL)
                ui.postDelayed({ if (t == token && loading) { loading = false; failAttempt() } }, 20000)
            }

            private fun parseJs(v: String?): JSONObject? {
                return try {
                    val s = JSONTokener(v ?: "null").nextValue() as? String ?: return null
                    JSONObject(s)
                } catch (e: Exception) { null }
            }

            private fun pollReady(t: Int, tries: Int) {
                if (t != token) return
                wv.evaluateJavascript(JS_READY) { v ->
                    if (t == token) {
                        val o = parseJs(v)
                        if (o != null && o.optBoolean("ok")) {
                            base = o.optString("text")
                            fill(t)
                        } else if (tries > 40) failAttempt()
                        else ui.postDelayed({ pollReady(t, tries + 1) }, 250)
                    }
                }
            }

            private fun fill(t: Int) {
                val j = job ?: return
                wv.evaluateJavascript(jsFill(j.yvok)) { r ->
                    if (t == token) {
                        if (r != null && r.contains("ok")) { stable = 0; last = ""; pollResult(t, 0) }
                        else failAttempt()
                    }
                }
            }

            private fun pollResult(t: Int, tries: Int) {
                if (t != token) return
                wv.evaluateJavascript(JS_STATE) { v ->
                    if (t == token) {
                        val text = parseJs(v)?.optString("text") ?: ""
                        val isLoading = text.contains("Yoxlanılır") && !base.contains("Yoxlanılır")
                        if (!isLoading && text.isNotEmpty() && text != base) {
                            if (text == last) stable++ else { last = text; stable = 0 }
                            if (stable >= 2) { complete(text); return@evaluateJavascript }
                        } else { stable = 0; last = "" }
                        if (tries > 45) failAttempt()
                        else ui.postDelayed({ pollResult(t, tries + 1) }, 300)
                    }
                }
            }

            private fun complete(text: String) {
                token++
                val j = job ?: return
                val p = parseResult(base, text)
                if (p.name == null && p.borc == null) {
                    if (p.notFound) notFound++
                    else {
                        failed++
                        if (sample == null) sample = "YVÖK: ${j.yvok}\n\n" + (if (p.raw.isEmpty()) "(yeni mətn yoxdur)" else p.raw)
                    }
                } else {
                    applyFetched(j.rowId, p.name, p.borc)
                    updated++
                    if ((p.name == null || p.borc == null) && sample == null) {
                        sample = "YVÖK: ${j.yvok}\nTapılan ad: ${p.name ?: "—"}\nTapılan borc: ${p.borc ?: "—"}\n\n" + p.raw
                    }
                }
                done++
                progress()
                next()
            }

            private fun failAttempt() {
                token++
                if (attempt < 3 && !cancelled) { startAttempt(); return }
                failed++; done++
                progress()
                next()
            }
        }
    }

    /** yeniləmədən sonra ekrandakı siyahıları təzələyir */
    private fun afterRefresh() {
        mainSearch.scheduleSearch(true)
        if (!catSearch.isEmpty()) catSearch.scheduleSearch(true)
        loadLevel(false, true)
    }

    private fun refreshRows(label: String, ids: List<Long>) = startRefresh(label, null, null, ids)

    private fun refreshScope(label: String, scopeSql: String?, arg: String?) = startRefresh(label, scopeSql, arg, null)

    private fun currentScopeLabel(): String = when (level) {
        0 -> "Bütün baza"
        1 -> fileName
        2 -> "$fileName › $streetName"
        else -> tvPath.text.toString()
    }

    private fun refreshCurrentSection() {
        when (level) {
            0 -> refreshScope(currentScopeLabel(), null, null)
            1 -> refreshScope(currentScopeLabel(), "b.file_id = ?", fileId.toString())
            2 -> refreshScope(currentScopeLabel(), "b.street_id = ?", streetId.toString())
            else -> refreshScope(currentScopeLabel(), "b.id = ?", buildingId.toString())
        }
    }

    // =====================================================================
    //  Axtarış bölməsi (həm "Axtarış" tabında, həm kataloqun hər səviyyəsində)
    // =====================================================================
    inner class SearchUi(
        private val scope: () -> Pair<String, String>?,
        private val onActive: (Boolean) -> Unit,
        private val onRefresh: () -> Unit,
        private val barInResults: Boolean = true,
        private val onSort: () -> Unit = {}
    ) {
        private val tokS = Any()
        private val tokG = Any()
        private var searchGen = 0
        private var sugGen = 0
        private var suppress = false
        private val adapter = CardAdapter()

        val etStreet: EditText = edit("Küçə adı", "street")
        val etMenzil: EditText = edit("Mənzil", "menzil")
        val etSoyad: EditText = edit("Soyad", "soyad")
        val etAd: EditText = edit("Ad", "ad")
        val etAta: EditText = edit("Atasının adı", "ata")
        val etNomre: EditText = edit("Nömrə", "nomre", InputType.TYPE_CLASS_PHONE)
        val etYvok: EditText = edit("YVÖK", "yvok")

        val form = LinearLayout(this@MainActivity)
        private val row2 = rowOf(etMenzil to 0.8f, etSoyad to 1.1f, etAd to 1f)
        private val row3 = rowOf(etAta to 1f, etNomre to 1f)
        private val sugBox = LinearLayout(this@MainActivity)
        val tvCount = TextView(this@MainActivity)
        private val btnToggle = Button(this@MainActivity)
        val spSort = Spinner(this@MainActivity)
        private var lastSort = 0
        val results = ListView(this@MainActivity)
        val resultsBox = LinearLayout(this@MainActivity)
        /** "Axtarışı gizlət" düyməsi + Filter sətri */
        val bar = LinearLayout(this@MainActivity)

        init {
            bar.orientation = LinearLayout.VERTICAL
            form.orientation = LinearLayout.VERTICAL
            form.setPadding(dp(8), dp(4), dp(8), dp(4))
            form.addView(etStreet, LinearLayout.LayoutParams(-1, -2))
            form.addView(row2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            form.addView(row3, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            form.addView(etYvok, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

            sugBox.orientation = LinearLayout.VERTICAL
            sugBox.visibility = View.GONE
            sugBox.elevation = dp(6).toFloat()
            sugBox.background = GradientDrawable().apply {
                setColor(Color.WHITE); setStroke(dp(1), Color.parseColor("#B0BEC5")); cornerRadius = dp(8).toFloat()
            }
            form.addView(sugBox, 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })

            val btnClear = Button(this@MainActivity)
            btnClear.text = "Təmizlə"
            btnClear.setOnClickListener { clear(); scheduleSearch() }
            form.addView(btnClear, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

            // Təmizlə düyməsinin altında: Yenilə
            val btnRefresh = Button(this@MainActivity)
            btnRefresh.text = "🔄  Yenilə"
            btnRefresh.setOnClickListener { hideSug(); onRefresh() }
            form.addView(btnRefresh, LinearLayout.LayoutParams(-1, -2))

            tvCount.textSize = 13f
            tvCount.setPadding(dp(12), dp(2), dp(12), dp(4))
            tvCount.setTextColor(Color.DKGRAY)
            results.divider = null
            results.adapter = adapter
            results.clipToPadding = false
            results.setPadding(dp(8), 0, dp(8), dp(8))
            results.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) hideSug(); false }
            resultsBox.orientation = LinearLayout.VERTICAL
            btnToggle.text = "🔼 Axtarışı gizlət"
            btnToggle.textSize = 13f
            btnToggle.isAllCaps = false
            btnToggle.setOnClickListener { setFormHidden(form.visibility == View.VISIBLE) }
            val hdr = LinearLayout(this@MainActivity)
            hdr.orientation = LinearLayout.HORIZONTAL
            hdr.gravity = Gravity.CENTER_VERTICAL
            hdr.addView(tvCount, LinearLayout.LayoutParams(0, -2, 1f))
            hdr.addView(btnToggle, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
            bar.addView(hdr, LinearLayout.LayoutParams(-1, -2))

            // Filter bölməsi
            val sortAdapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item,
                listOf("Standart sıra", "Borc: ən çoxdan ən aza ↓"))
            sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spSort.adapter = sortAdapter
            spSort.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position != lastSort) { lastSort = position; if (!barInResults && isEmpty()) onSort() else scheduleSearch() }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
            val filterRow = LinearLayout(this@MainActivity)
            filterRow.orientation = LinearLayout.HORIZONTAL
            filterRow.gravity = Gravity.CENTER_VERTICAL
            filterRow.setPadding(dp(12), 0, dp(8), dp(2))
            filterRow.addView(TextView(this@MainActivity).apply {
                text = "🔽 Filter:"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#263238"))
            })
            filterRow.addView(spSort, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
            bar.addView(filterRow, LinearLayout.LayoutParams(-1, -2))
            if (barInResults) resultsBox.addView(bar, LinearLayout.LayoutParams(-1, -2))
            resultsBox.addView(results, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        fun sortDesc(): Boolean = spSort.selectedItemPosition == 1

        fun shownRowIds(): List<Long> = adapter.rowIds()

        fun refreshView() = adapter.notifyDataSetChanged()

        private fun edit(hint: String, key: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
            val e = EditText(this@MainActivity)
            e.hint = hint
            e.textSize = 14f
            e.isSingleLine = true
            e.inputType = type or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            e.imeOptions = EditorInfo.IME_ACTION_SEARCH
            e.setPadding(dp(8), dp(10), dp(8), dp(10))
            e.background = GradientDrawable().apply {
                setColor(Color.WHITE); setStroke(dp(1), Color.parseColor("#B0BEC5")); cornerRadius = dp(8).toFloat()
            }
            e.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (suppress) return
                    scheduleSearch(); scheduleSuggest(key)
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            e.setOnFocusChangeListener { _, has -> if (has) scheduleSuggest(key) }
            e.setOnEditorActionListener { v, _, _ ->
                hideSug()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(v.windowToken, 0)
                true
            }
            return e
        }

        private fun fieldOf(key: String): EditText = when (key) {
            "street" -> etStreet; "menzil" -> etMenzil; "soyad" -> etSoyad
            "ad" -> etAd; "ata" -> etAta; "yvok" -> etYvok; else -> etNomre
        }

        fun isEmpty(): Boolean =
            listOf(etStreet, etMenzil, etSoyad, etAd, etAta).all { fold(it.text.toString()).isEmpty() } &&
                yvokText().isEmpty() &&
                etNomre.text.toString().none { it.isDigit() }

        private fun yvokText(): String = etYvok.text.toString().filter { it.isLetterOrDigit() }

        fun setFormHidden(h: Boolean) {
            form.visibility = if (h) View.GONE else View.VISIBLE
            btnToggle.text = if (h) "🔽 Axtarışı göstər" else "🔼 Axtarışı gizlət"
            if (h) hideSug()
        }

        fun clear() {
            setFormHidden(false)
            suppress = true
            listOf(etStreet, etMenzil, etSoyad, etAd, etAta, etNomre, etYvok).forEach { it.setText("") }
            suppress = false
            hideSug()
        }

        fun hideSug() {
            sugGen++
            sugBox.visibility = View.GONE
        }

        fun sugVisible() = sugBox.visibility == View.VISIBLE

        private fun buildWhere(exclude: String?, where: ArrayList<String>, args: ArrayList<String>) {
            scope()?.let { where.add(it.first); args.add(it.second) }
            if (exclude != "street") fold(etStreet.text.toString()).split(' ').filter { it.isNotEmpty() }
                .forEach { where.add("b.name_n LIKE ?"); args.add("%$it%") }
            val mz = fold(etMenzil.text.toString())
            if (exclude != "menzil" && mz.isNotEmpty()) { where.add("r.menzil_n = ?"); args.add(mz) }
            val so = fold(etSoyad.text.toString())
            if (exclude != "soyad" && so.isNotEmpty()) { where.add("r.soyad_n LIKE ?"); args.add("%$so%") }
            val ad = fold(etAd.text.toString())
            if (exclude != "ad" && ad.isNotEmpty()) { where.add("r.ad_n LIKE ?"); args.add("%$ad%") }
            val at = fold(etAta.text.toString())
            if (exclude != "ata" && at.isNotEmpty()) { where.add("r.ata_n LIKE ?"); args.add("%$at%") }
            val yv = yvokText()
            if (exclude != "yvok" && yv.isNotEmpty()) { where.add("r.cells LIKE ?"); args.add("%$yv%") }
            val nr = etNomre.text.toString().filter { it.isDigit() }
            if (exclude != "nomre" && nr.isNotEmpty()) { where.add("r.nomre_d LIKE ?"); args.add("%$nr%") }
        }

        // ----- təkliflər -----
        private fun scheduleSuggest(key: String) {
            ui.removeCallbacksAndMessages(tokG)
            ui.postAtTime({ doSuggest(key) }, tokG, SystemClock.uptimeMillis() + 120)
        }

        private fun doSuggest(key: String) {
            val et = fieldOf(key)
            val q = fold(et.text.toString())
            if (key == "nomre" || key == "yvok" || q.isEmpty() || !et.hasFocus()) { hideSug(); return }
            val gen = ++sugGen
            Thread {
                val items = ArrayList<String>()
                try {
                    if (key == "street") {
                        val toks = q.split(' ').filter { it.isNotEmpty() }
                        val where = ArrayList<String>(); val args = ArrayList<String>()
                        scope()?.let { where.add(it.first); args.add(it.second) }
                        toks.forEach { where.add("b.name_n LIKE ?"); args.add("%$it%") }
                        val w = where.joinToString(" AND ")
                        db.rawQuery(
                            "SELECT DISTINCT s.name FROM streets s JOIN buildings b ON b.street_id = s.id WHERE $w ORDER BY s.name LIMIT 4",
                            args.toTypedArray()
                        ).use { c -> while (c.moveToNext()) items.add(c.getString(0)) }
                        db.rawQuery(
                            "SELECT DISTINCT b.name FROM buildings b WHERE $w ORDER BY b.file_id, b.ord LIMIT 10",
                            args.toTypedArray()
                        ).use { c -> while (c.moveToNext()) { val n = c.getString(0); if (n !in items) items.add(n) } }
                    } else {
                        val col = when (key) { "menzil" -> "r.menzil"; "soyad" -> "r.soyad"; "ad" -> "r.ad"; else -> "r.ata" }
                        val where = ArrayList<String>(); val args = ArrayList<String>()
                        buildWhere(key, where, args)
                        where.add("${col}_n LIKE ?"); args.add("$q%")
                        where.add("$col <> ''")
                        db.rawQuery(
                            "SELECT DISTINCT $col FROM rows r JOIN buildings b ON b.id = r.building_id WHERE " +
                                where.joinToString(" AND ") + " ORDER BY ${col}_n LIMIT 8", args.toTypedArray()
                        ).use { c -> while (c.moveToNext()) items.add(c.getString(0)) }
                    }
                } catch (e: Exception) { /* ignore */ }
                runOnUiThread { if (gen == sugGen) showSug(key, items) }
            }.start()
        }

        private fun showSug(key: String, items: List<String>) {
            if (items.isEmpty()) { sugBox.visibility = View.GONE; return }
            val anchor: View = when (key) { "street" -> etStreet; "menzil", "soyad", "ad" -> row2; else -> row3 }
            form.removeView(sugBox)
            form.addView(sugBox, form.indexOfChild(anchor) + 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
            sugBox.removeAllViews()
            items.forEachIndexed { idx, text ->
                val tv = TextView(this@MainActivity)
                tv.text = "🔍  $text"; tv.textSize = 15f; tv.setTextColor(Color.parseColor("#263238"))
                tv.setPadding(dp(12), dp(11), dp(12), dp(11))
                tv.setOnClickListener {
                    val f = fieldOf(key)
                    suppress = true
                    f.setText(items[idx])
                    f.setSelection(f.text.length)
                    suppress = false
                    hideSug(); scheduleSearch()
                }
                sugBox.addView(tv)
            }
            sugBox.visibility = View.VISIBLE
        }

        // ----- axtarış -----
        private var keepScroll = false

        fun scheduleSearch(keep: Boolean = false) {
            if (keep) keepScroll = true
            onActive(!isEmpty())
            ui.removeCallbacksAndMessages(tokS)
            ui.postAtTime({ doSearch() }, tokS, SystemClock.uptimeMillis() + 250)
        }

        private fun doSearch() {
            if (isEmpty()) {
                adapter.set(emptyList()); tvCount.text = if (barInResults) "Axtarmaq üçün yuxarıdakı xanalara yazın" else ""; return
            }
            val gen = ++searchGen
            val desc = spSort.selectedItemPosition == 1
            val keep = keepScroll
            keepScroll = false
            val keepPos = results.firstVisiblePosition
            val keepTop = results.getChildAt(0)?.top ?: 0
            Thread {
                val where = ArrayList<String>(); val args = ArrayList<String>()
                buildWhere(null, where, args)
                val sql = "SELECT r.cells, b.headers, b.name, b.title, COALESCE(NULLIF(f.disp, ''), f.name), r.id, f.name, b.sheet, r.ord FROM rows r " +
                    "JOIN buildings b ON b.id = r.building_id JOIN files f ON f.id = b.file_id " +
                    "WHERE " + where.joinToString(" AND ") + " ORDER BY " + (if (desc) "r.borc DESC, " else "") + "f.ord, b.ord, r.ord LIMIT 201"
                val list = ArrayList<Card>()
                try {
                    db.rawQuery(sql, args.toTypedArray()).use { c ->
                        while (c.moveToNext()) {
                            list.add(Card(
                                path = c.getString(4) + "  ›  " + c.getString(2),
                                title = c.getString(3),
                                headers = jsonList(c.getString(1)),
                                cells = jsonList(c.getString(0)),
                                rowId = c.getLong(5),
                                bname = c.getString(2),
                                skey = c.getString(6) + "|" + c.getString(7) + "|" + c.getInt(8)
                            ))
                        }
                    }
                } catch (e: Exception) { /* ignore */ }
                runOnUiThread {
                    if (gen == searchGen) {
                        val more = list.size > 200
                        val shown = if (more) list.subList(0, 200) else list
                        adapter.set(shown)
                        tvCount.text = if (shown.isEmpty()) "Nəticə tapılmadı"
                        else if (more) "İlk 200 nəticə göstərilir — axtarışı dəqiqləşdirin" else "${shown.size} nəticə"
                        if (keep) results.setSelectionFromTop(keepPos, keepTop) else results.setSelection(0)
                    }
                }
            }.start()
        }
    }

    // =====================================================================
    //  Mesaj göndərmə (WhatsApp / SMS) və kataloq adlarının redaktəsi
    // =====================================================================
    private fun cellOf(c: Card, prefix: String): String {
        val i = colIdx(c.headers, prefix)
        return if (i >= 0) c.cells.getOrNull(i).orEmpty().trim() else ""
    }

    private fun nameOf(c: Card): String {
        val i = nameIdx(c.headers)
        return if (i >= 0) c.cells.getOrNull(i).orEmpty().trim().replace(Regex("\\s+"), " ") else ""
    }

    private fun unitLine(c: Card): String =
        (if (c.bname.isNotEmpty()) c.bname + " " else "") + "mənzil " + cellOf(c, "menzil")

    private fun waText(c: Card): String {
        val y = cellOf(c, "yvok")
        val borc = cellOf(c, "borc").ifEmpty { "0" }
        return listOf(
            "Binəqədi rayon Binəqədi bələdiyyəsi",
            "Əmlak vergisi",
            "",
            "Borc: $borc AZN",
            "YVÖK:$y",
            nameOf(c),
            unitLine(c),
            "",
            "Ödəniş növləri:",
            "𝟭.Birbank və ABB tətbiqləri",
            "- Ödənişlər",
            "- Dövlət(Hökümət)",
            "- Bələdiyyələr",
            "- YVÖK daxil edin",
            "- $y",
            "- Davam Etmək",
            "",
            "𝟮.MilliÖn,Mpay,ExpressPay Ödəniş Terminalları",
            "- Dövlət Ödənişləri",
            "- Bələdiyyələr",
            "- YVÖK",
            "- $y",
            "- İrəli"
        ).joinToString("\n")
    }

    /** SMS yalnız latın hərfləri ilə: ə→e, ı→i, ö→o, ü→u, ş→s, ç→c, ğ→g və s. */
    private fun latin(s: String): String {
        val m = java.text.Normalizer.normalize(
            s.replace('Ə', 'E').replace('ə', 'e').replace('İ', 'I').replace('ı', 'i'),
            java.text.Normalizer.Form.NFD
        )
        val sb = StringBuilder()
        for (ch in m) if (ch == '\n' || ch.code in 32..126) sb.append(ch)
        return sb.toString()
    }

    private fun smsText(c: Card): String {
        val y = cellOf(c, "yvok")
        val borc = cellOf(c, "borc").ifEmpty { "0" }
        return latin(
            "Bineqedi belediyyesi Emlak vergisi\n" +
                "Borc: $borc AZN\n" +
                "YVÖK:$y\n" +
                nameOf(c) + "\n" +
                unitLine(c) + "\n" +
                "Elaqe:0775668875 Barat m"
        )
    }

    private fun intlNumber(d: String): String? = when {
        d.startsWith("994") && d.length == 12 -> d
        d.length == 10 && d.startsWith("0") -> "994" + d.substring(1)
        d.length == 9 -> "994$d"
        else -> null
    }

    private fun sendMsg(c: Card, whatsapp: Boolean) {
        val raw = cellOf(c, "nomre")
        val nums = raw.split(Regex("[\\n;,/|]+")).map { p -> p.filter { it.isDigit() } }
            .mapNotNull { intlNumber(it) }.distinct()
        if (nums.isEmpty()) {
            Toast.makeText(this, if (raw.isBlank()) "Nömrə yoxdur" else "Nömrə düzgün deyil: $raw", Toast.LENGTH_LONG).show()
            return
        }
        if (nums.size == 1) launchMsg(nums[0], c, whatsapp)
        else AlertDialog.Builder(this).setTitle("Nömrəni seçin")
            .setItems(nums.map { "+$it" }.toTypedArray()) { _, i -> launchMsg(nums[i], c, whatsapp) }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun refreshCards() {
        mainSearch.refreshView(); catSearch.refreshView(); cardAdapterCat.notifyDataSetChanged()
    }

    private fun markSent(c: Card, whatsapp: Boolean) {
        if (c.skey.isEmpty()) return
        val kind = if (whatsapp) "wa" else "sms"
        if (sentSet.add(c.skey + "|" + kind)) editsDb.execSQL("INSERT OR REPLACE INTO sent VALUES(?, ?)", arrayOf<Any>(c.skey, kind))
        refreshCards()
    }

    private fun unmarkSent(c: Card, whatsapp: Boolean) {
        val kind = if (whatsapp) "wa" else "sms"
        if (sentSet.remove(c.skey + "|" + kind)) {
            editsDb.execSQL("DELETE FROM sent WHERE skey = ? AND kind = ?", arrayOf<Any>(c.skey, kind))
            Toast.makeText(this, "Göndərildi işarəsi silindi", Toast.LENGTH_SHORT).show()
            refreshCards()
        }
    }

    private fun launchMsg(num: String, c: Card, whatsapp: Boolean) {
        try {
            if (whatsapp) {
                val text = java.net.URLEncoder.encode(waText(c), "UTF-8").replace("+", "%20")
                val uri = Uri.parse("https://wa.me/$num?text=$text")
                var done = false
                for (pkg in arrayOf("com.whatsapp", "com.whatsapp.w4b")) {
                    try {
                        val it = Intent(Intent.ACTION_VIEW, uri)
                        it.setPackage(pkg)
                        startActivity(it)
                        done = true
                        break
                    } catch (e: Exception) { }
                }
                if (!done) startActivity(Intent(Intent.ACTION_VIEW, uri))
            } else {
                val it = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:+$num"))
                it.putExtra("sms_body", smsText(c))
                startActivity(it)
            }
            markSent(c, whatsapp)
        } catch (e: Exception) {
            Toast.makeText(this, "Tətbiq açıla bilmədi", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- kataloq adlarının redaktəsi ----------
    private fun fileKeyName(fid: Long): String {
        var n = ""
        db.rawQuery("SELECT name FROM files WHERE id = ?", arrayOf(fid.toString())).use { if (it.moveToFirst()) n = it.getString(0) }
        return n
    }

    private fun showRenameDialog(pos: Int) {
        val et = EditText(this)
        et.setText(catNames[pos]); et.isSingleLine = true; et.setSelection(et.text.length)
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        AlertDialog.Builder(this).setTitle("Adı dəyiş").setView(box)
            .setPositiveButton("Yadda saxla") { _, _ ->
                val nv = et.text.toString().trim()
                if (nv.isNotEmpty() && nv != catNames[pos]) renameCatItem(pos, nv)
            }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun renameCatItem(pos: Int, nv: String) {
        val id = catIds[pos]
        val cur = catNames[pos]
        when (level) {
            0 -> {
                val key = fileKeyName(id)
                if (nv == key) {
                    db.execSQL("UPDATE files SET disp = NULL WHERE id = ?", arrayOf<Any>(id))
                    editsDb.execSQL("DELETE FROM renames WHERE kind = 'f' AND a = ? AND b = ''", arrayOf<Any>(key))
                } else {
                    db.execSQL("UPDATE files SET disp = ? WHERE id = ?", arrayOf<Any>(nv, id))
                    editsDb.execSQL("INSERT OR REPLACE INTO renames VALUES('f', ?, '', ?)", arrayOf<Any>(key, nv))
                }
            }
            1 -> {
                val fk = fileKeyName(fileId)
                var orig = cur
                editsDb.rawQuery("SELECT b FROM renames WHERE kind = 's' AND a = ? AND value = ?", arrayOf(fk, cur)).use {
                    if (it.moveToFirst()) orig = it.getString(0)
                }
                db.execSQL("UPDATE streets SET name = ?, name_n = ? WHERE id = ?", arrayOf<Any>(nv, fold(nv), id))
                if (nv == orig) editsDb.execSQL("DELETE FROM renames WHERE kind = 's' AND a = ? AND b = ?", arrayOf<Any>(fk, orig))
                else editsDb.execSQL("INSERT OR REPLACE INTO renames VALUES('s', ?, ?, ?)", arrayOf<Any>(fk, orig, nv))
            }
            else -> {
                val fk = fileKeyName(fileId)
                var sheet = ""
                var title = ""
                db.rawQuery("SELECT sheet, title FROM buildings WHERE id = ?", arrayOf(id.toString())).use {
                    if (it.moveToFirst()) { sheet = it.getString(0) ?: ""; title = it.getString(1) ?: "" }
                }
                db.execSQL("UPDATE buildings SET name = ?, name_n = ? WHERE id = ?", arrayOf<Any>(nv, fold("$nv $title"), id))
                editsDb.execSQL("INSERT OR REPLACE INTO renames VALUES('b', ?, ?, ?)", arrayOf<Any>(fk, sheet, nv))
            }
        }
        loadLevel(false, true)
    }

    private fun replayRenames(d: SQLiteDatabase) {
        val l = ArrayList<Array<String>>()
        editsDb.rawQuery("SELECT kind, a, b, value FROM renames", null).use { c ->
            while (c.moveToNext()) l.add(arrayOf(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getString(3)))
        }
        for (r in l) {
            try {
                when (r[0]) {
                    "f" -> d.execSQL("UPDATE files SET disp = ? WHERE name = ?", arrayOf<Any>(r[3], r[1]))
                    "s" -> d.execSQL(
                        "UPDATE streets SET name = ?, name_n = ? WHERE name = ? AND file_id = (SELECT id FROM files WHERE name = ?)",
                        arrayOf<Any>(r[3], fold(r[3]), r[2], r[1])
                    )
                    "b" -> {
                        var bid = -1L
                        var title = ""
                        d.rawQuery(
                            "SELECT id, title FROM buildings WHERE sheet = ? AND file_id = (SELECT id FROM files WHERE name = ?)",
                            arrayOf(r[2], r[1])
                        ).use { if (it.moveToFirst()) { bid = it.getLong(0); title = it.getString(1) ?: "" } }
                        if (bid >= 0) d.execSQL(
                            "UPDATE buildings SET name = ?, name_n = ? WHERE id = ?",
                            arrayOf<Any>(r[3], fold(r[3] + " " + title), bid)
                        )
                    }
                }
            } catch (e: Exception) { }
        }
    }

    // =====================================================================
    //  Excel export / import
    // =====================================================================
    private val RC_EXPORT = 201
    private val RC_EXPORT_DIR = 202
    private val RC_IMPORT = 203
    private val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    private var pendingExport: Pair<Long, String>? = null
    private val sentSet = HashSet<String>()

    private class ImpSheet(val name: String, val title: String, val headers: List<String>, val rows: List<List<String>>)

    private fun filesList(): List<Pair<Long, String>> {
        val l = ArrayList<Pair<Long, String>>()
        db.rawQuery("SELECT id, name FROM files ORDER BY ord", null).use { c -> while (c.moveToNext()) l.add(Pair(c.getLong(0), c.getString(1))) }
        return l
    }

    private fun safeName(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()

    private fun busyDialog(title: String): AlertDialog {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(20), dp(16), dp(20), dp(16))
        box.addView(ProgressBar(this))
        box.addView(TextView(this).apply { text = "  Gözləyin…"; textSize = 15f })
        val d = AlertDialog.Builder(this).setTitle(title).setView(box).setCancelable(false).create()
        d.show()
        return d
    }

    private fun showExcelMenu() {
        AlertDialog.Builder(this).setTitle("Excel")
            .setItems(arrayOf("📤  Export (bazanı Excel-ə çıxar)", "📥  Import (Excel-dən bazaya yüklə)")) { _, which ->
                if (which == 0) chooseExport() else pickImport()
            }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun chooseExport() {
        val files = filesList()
        val items = files.map { it.second }.toMutableList()
        items.add("Hamısı (qovluğa, hər baza ayrı fayl)")
        AlertDialog.Builder(this).setTitle("Hansı baza export edilsin?")
            .setItems(items.toTypedArray()) { _, i ->
                if (i < files.size) {
                    pendingExport = files[i]
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    intent.type = XLSX_MIME
                    intent.putExtra(Intent.EXTRA_TITLE, safeName(files[i].second) + ".xlsx")
                    startActivityForResult(intent, RC_EXPORT)
                } else {
                    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), RC_EXPORT_DIR)
                }
            }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun pickImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        intent.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(XLSX_MIME, "application/octet-stream"))
        startActivityForResult(intent, RC_IMPORT)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            RC_EXPORT -> { val p = pendingExport; if (p != null) runExport(listOf(p), uri, false) }
            RC_EXPORT_DIR -> runExport(filesList(), uri, true)
            RC_IMPORT -> startImport(uri)
        }
    }

    // ---------- export ----------
    private fun runExport(files: List<Pair<Long, String>>, uri: Uri, tree: Boolean) {
        val dlg = busyDialog("Export edilir…")
        Thread {
            var sheets = 0
            var rowsN = 0
            var err: String? = null
            try {
                for (f in files) {
                    val target: Uri = if (tree) {
                        val parent = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
                        DocumentsContract.createDocument(contentResolver, parent, XLSX_MIME, safeName(f.second) + ".xlsx")
                            ?: throw IOException("Fayl yaradıla bilmədi")
                    } else uri
                    val os = contentResolver.openOutputStream(target) ?: throw IOException("Fayl açıla bilmədi")
                    val r = writeXlsx(f.first, os)
                    sheets += r.first
                    rowsN += r.second
                }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                try { dlg.dismiss() } catch (e: Exception) { }
                val msg = if (err != null) "Xəta: $err" else "Export tamamlandı: ${files.size} fayl, $sheets vərəq, $rowsN sətir"
                AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Bağla", null).show()
            }
        }.start()
    }

    private fun xmlEsc(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (ch in s) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch.code < 32 && ch != '\n' && ch != '\t' && ch != '\r' -> { }
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun colName(i: Int): String {
        var n = i
        val sb = StringBuilder()
        do { sb.insert(0, ('A' + n % 26)); n = n / 26 - 1 } while (n >= 0)
        return sb.toString()
    }

    private fun uniqueSheetName(raw: String, used: HashSet<String>): String {
        var base = raw.replace(Regex("[\\\\/*?:\\[\\]]"), "_").trim()
        if (base.isEmpty()) base = "Sheet"
        base = base.take(31)
        var name = base
        var n = 2
        while (!used.add(name.lowercase(Locale.ROOT))) {
            val suf = " ($n)"
            name = base.take(31 - suf.length) + suf
            n++
        }
        return name
    }

    private val numRe2 = Regex("^-?\\d+(\\.\\d+)?$")

    private fun writeRowXml(w: Writer, r: Int, cells: List<String>, bold: Boolean, numCol: Int) {
        w.write("<row r=\"$r\">")
        for (i in cells.indices) {
            val v = cells[i]
            if (v.isEmpty()) continue
            val ref = colName(i) + r
            val nv = v.replace(',', '.').trim()
            if (i == numCol && numRe2.matches(nv)) {
                w.write("<c r=\"$ref\"><v>$nv</v></c>")
            } else {
                w.write("<c r=\"$ref\" t=\"inlineStr\"" + (if (bold) " s=\"1\"" else "") +
                    "><is><t xml:space=\"preserve\">" + xmlEsc(v) + "</t></is></c>")
            }
        }
        w.write("</row>")
    }

    /** Bir bazanı (fayl) .xlsx kimi yazır: hər bina ayrıca vərəq. (vərəq sayı, sətir sayı) qaytarır */
    private fun writeXlsx(fileId: Long, out: OutputStream): Pair<Int, Int> {
        class B(val id: Long, val sheet: String, val title: String, val headers: List<String>)
        val bs = ArrayList<B>()
        db.rawQuery("SELECT id, name, sheet, title, headers FROM buildings WHERE file_id = ? ORDER BY ord", arrayOf(fileId.toString())).use { c ->
            while (c.moveToNext()) {
                val sh = c.getString(2)
                bs.add(B(c.getLong(0), if (sh.isNullOrBlank()) c.getString(1) else sh, c.getString(3) ?: "", jsonList(c.getString(4))))
            }
        }
        if (bs.isEmpty()) { out.close(); return Pair(0, 0) }
        val used = HashSet<String>()
        val names = bs.map { uniqueSheetName(it.sheet, used) }
        val ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        val rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        var totalRows = 0
        ZipOutputStream(BufferedOutputStream(out)).use { z ->
            fun put(name: String, text: String) {
                z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry()
            }
            val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            val ct = StringBuilder(head)
            ct.append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
            ct.append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
            ct.append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
            ct.append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
            ct.append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>")
            for (i in bs.indices) ct.append("<Override PartName=\"/xl/worksheets/sheet${i + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
            ct.append("</Types>")
            put("[Content_Types].xml", ct.toString())
            put("_rels/.rels", head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"$rel/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            val wb = StringBuilder(head)
            wb.append("<workbook xmlns=\"$ns\" xmlns:r=\"$rel\"><sheets>")
            for (i in bs.indices) wb.append("<sheet name=\"${xmlEsc(names[i])}\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>")
            wb.append("</sheets></workbook>")
            put("xl/workbook.xml", wb.toString())
            val wr = StringBuilder(head)
            wr.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
            for (i in bs.indices) wr.append("<Relationship Id=\"rId${i + 1}\" Type=\"$rel/worksheet\" Target=\"worksheets/sheet${i + 1}.xml\"/>")
            wr.append("<Relationship Id=\"rId${bs.size + 1}\" Type=\"$rel/styles\" Target=\"styles.xml\"/></Relationships>")
            put("xl/_rels/workbook.xml.rels", wr.toString())
            put("xl/styles.xml", head + "<styleSheet xmlns=\"$ns\">" +
                "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs></styleSheet>")
            for ((i, b) in bs.withIndex()) {
                z.putNextEntry(ZipEntry("xl/worksheets/sheet${i + 1}.xml"))
                val w = BufferedWriter(OutputStreamWriter(z, Charsets.UTF_8))
                w.write(head)
                w.write("<worksheet xmlns=\"$ns\"><cols>")
                val nameCol = nameIdx(b.headers)
                for (k in 0 until Math.max(b.headers.size, 1)) {
                    w.write("<col min=\"${k + 1}\" max=\"${k + 1}\" width=\"${if (k == nameCol) 38 else 16}\" customWidth=\"1\"/>")
                }
                w.write("</cols><sheetData>")
                var r = 1
                if (b.title.isNotBlank()) writeRowXml(w, r++, listOf(b.title), true, -1)
                writeRowXml(w, r++, b.headers, true, -1)
                val borcCol = colIdx(b.headers, "borc")
                db.rawQuery("SELECT cells FROM rows WHERE building_id = ? ORDER BY ord", arrayOf(b.id.toString())).use { c ->
                    while (c.moveToNext()) {
                        writeRowXml(w, r++, jsonList(c.getString(0)), false, borcCol)
                        totalRows++
                    }
                }
                w.write("</sheetData></worksheet>")
                w.flush()
                z.closeEntry()
            }
        }
        return Pair(bs.size, totalRows)
    }

    // ---------- import ----------
    private fun colIndex(ref: String): Int {
        var idx = 0
        var any = false
        for (ch in ref) {
            if (ch.isLetter()) { idx = idx * 26 + (ch.uppercaseChar() - 'A' + 1); any = true } else break
        }
        return if (any) idx - 1 else -1
    }

    private fun numText(v: String?): String {
        if (v == null) return ""
        val d = v.trim().toDoubleOrNull() ?: return v
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        return try {
            java.math.BigDecimal(v.trim()).setScale(2, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
        } catch (e: Exception) { v }
    }

    private fun xmlParser(bytes: ByteArray): XmlPullParser {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(bytes), null)
        return p
    }

    private fun parseShared(bytes: ByteArray): List<String> {
        val res = ArrayList<String>()
        val p = xmlParser(bytes)
        val sb = StringBuilder()
        var inSi = false
        var rph = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfter(':')) {
                    "si" -> { inSi = true; sb.setLength(0) }
                    "rPh" -> rph++
                    "t" -> if (inSi && rph == 0) sb.append(p.nextText())
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name.substringAfter(':')) {
                    "rPh" -> rph--
                    "si" -> { res.add(sb.toString()); inSi = false }
                }
            }
            ev = p.next()
        }
        return res
    }

    private fun parseSheetXml(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = xmlParser(bytes)
        var cur: ArrayList<String>? = null
        var col = 0
        var type: String? = null
        var v: String? = null
        var open = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfter(':')) {
                    "row" -> cur = ArrayList()
                    "c" -> { type = p.getAttributeValue(null, "t"); col = colIndex(p.getAttributeValue(null, "r") ?: ""); v = null; open = true }
                    "v" -> if (open) v = p.nextText()
                    "t" -> if (open && type == "inlineStr") v = (v ?: "") + p.nextText()
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name.substringAfter(':')) {
                    "c" -> {
                        val r = cur
                        if (r != null) {
                            val s = when (type) {
                                "s" -> shared.getOrElse(v?.trim()?.toIntOrNull() ?: -1) { "" }
                                "inlineStr", "str" -> v ?: ""
                                "b" -> if (v?.trim() == "1") "TRUE" else "FALSE"
                                "e" -> ""
                                else -> numText(v)
                            }
                            if (col < 0) col = r.size
                            while (r.size <= col) r.add("")
                            r[col] = s
                        }
                        open = false
                    }
                    "row" -> { cur?.let { rows.add(it) }; cur = null }
                }
            }
            ev = p.next()
        }
        return rows
    }

    /** .xlsx faylını oxuyur: (vərəq adı, sətirlər) siyahısı */
    private fun readXlsx(input: InputStream): List<Pair<String, List<List<String>>>> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(BufferedInputStream(input)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val n = e.name
                if (n == "xl/workbook.xml" || n == "xl/_rels/workbook.xml.rels" || n == "xl/sharedStrings.xml" ||
                    (n.startsWith("xl/worksheets/") && n.endsWith(".xml"))) files[n] = z.readBytes()
                e = z.nextEntry
            }
        }
        val wbBytes = files["xl/workbook.xml"] ?: throw IOException("Bu fayl .xlsx deyil")
        val rels = HashMap<String, String>()
        files["xl/_rels/workbook.xml.rels"]?.let { b ->
            val p = xmlParser(b)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name.substringAfter(':') == "Relationship") {
                    val id = p.getAttributeValue(null, "Id"); val t = p.getAttributeValue(null, "Target")
                    if (id != null && t != null) rels[id] = t
                }
                ev = p.next()
            }
        }
        val shared = files["xl/sharedStrings.xml"]?.let { parseShared(it) } ?: emptyList()
        val res = ArrayList<Pair<String, List<List<String>>>>()
        val p = xmlParser(wbBytes)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && p.name.substringAfter(':') == "sheet") {
                val name = p.getAttributeValue(null, "name") ?: "Sheet"
                var rid: String? = null
                for (i in 0 until p.attributeCount) if (p.getAttributeName(i).substringAfter(':') == "id") rid = p.getAttributeValue(i)
                var target = rels[rid ?: ""]
                if (target != null) {
                    target = target.trimStart('/')
                    if (!target.startsWith("xl/")) target = "xl/$target"
                    val bytes = files[target]
                    if (bytes != null) res.add(Pair(name, parseSheetXml(bytes, shared)))
                }
            }
            ev = p.next()
        }
        return res
    }

    /** vərəqlərdən başlıq sətri ("Mənzil ...") olanları ImpSheet-ə çevirir; (siyahı, keçilən sayı) */
    private fun parseImport(raw: List<Pair<String, List<List<String>>>>): Pair<List<ImpSheet>, Int> {
        val out = ArrayList<ImpSheet>()
        var skipped = 0
        for ((name, rows) in raw) {
            var h = -1
            for (i in 0 until Math.min(rows.size, 15)) if (rows[i].any { fold(it).startsWith("menzil") }) { h = i; break }
            if (h < 0) { skipped++; continue }
            val headers = ArrayList(rows[h].map { it.trim() })
            while (headers.isNotEmpty() && headers.last().isEmpty()) headers.removeAt(headers.size - 1)
            if (headers.size < 2) { skipped++; continue }
            var title = ""
            for (i in h - 1 downTo 0) {
                val t = rows[i].firstOrNull { it.isNotBlank() }
                if (t != null) { title = t.trim(); break }
            }
            val data = ArrayList<List<String>>()
            for (i in h + 1 until rows.size) {
                val r = rows[i]
                if (r.all { it.isBlank() }) continue
                data.add(List(headers.size) { k -> r.getOrNull(k)?.trim() ?: "" })
            }
            out.add(ImpSheet(name, title, headers, data))
        }
        return Pair(out, skipped)
    }

    private fun startImport(uri: Uri) {
        var disp = "import"
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) disp = c.getString(0) ?: disp
            }
        } catch (e: Exception) { }
        val base = disp.replace(Regex("\\.xlsx$", RegexOption.IGNORE_CASE), "").trim()
        val dlg = busyDialog("Fayl oxunur…")
        Thread {
            var parsed: Pair<List<ImpSheet>, Int>? = null
            var err: String? = null
            try {
                val ins = contentResolver.openInputStream(uri)
                if (ins == null) err = "Fayl açıla bilmədi"
                else ins.use { parsed = parseImport(readXlsx(it)) }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                try { dlg.dismiss() } catch (e: Exception) { }
                val pr = parsed
                if (err != null || pr == null) {
                    AlertDialog.Builder(this).setMessage("Xəta: ${err ?: "oxunmadı"}").setPositiveButton("Bağla", null).show()
                } else if (pr.first.isEmpty()) {
                    AlertDialog.Builder(this)
                        .setMessage("Uyğun vərəq tapılmadı. Hər vərəqdə başlıq sətri olmalıdır (məs. \"Mənzil\", \"Soyad, Ad, Atasının adı\", \"YVÖK\", \"Borc\"…).")
                        .setPositiveButton("Bağla", null).show()
                } else chooseImportTarget(base, pr.first, pr.second)
            }
        }.start()
    }

    private fun chooseImportTarget(base: String, list: List<ImpSheet>, skipped: Int) {
        val files = filesList()
        val match = files.firstOrNull { fold(it.second) == fold(base) }
        if (match != null) { confirmImport(match.second, list, skipped); return }
        val items = files.map { it.second }.toMutableList()
        items.add("➕  Yeni baza: $base")
        AlertDialog.Builder(this).setTitle("Hansı bazaya import edilsin?")
            .setItems(items.toTypedArray()) { _, i ->
                confirmImport(if (i < files.size) files[i].second else base, list, skipped)
            }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun confirmImport(fileName: String, list: List<ImpSheet>, skipped: Int) {
        val rowsN = list.sumOf { it.rows.size }
        val msg = "«$fileName» bazasına ${list.size} vərəq, $rowsN sətir import ediləcək.\n\n" +
            "Eyni adlı vərəqlərin (binaların) məlumatı əvəz olunacaq. Yeni adlı vərəqlər «İMPORT» küçəsi altında əlavə olunacaq." +
            (if (skipped > 0) "\n\nBaşlıq sətri tapılmadığı üçün keçilən vərəq: $skipped" else "")
        AlertDialog.Builder(this).setTitle("Import").setMessage(msg)
            .setPositiveButton("Davam et") { _, _ -> doImport(fileName, list) }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun doImport(fileName: String, list: List<ImpSheet>) {
        val dlg = busyDialog("Import edilir…")
        Thread {
            var err: String? = null
            var n = 0
            var rowsN = 0
            try {
                for (s in list) {
                    saveImportRecord(fileName, s)
                    applyImportedSheet(db, fileName, s)
                    n++; rowsN += s.rows.size
                }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                try { dlg.dismiss() } catch (e: Exception) { }
                val msg = if (err != null) "Xəta ($n vərəq yazıldı): $err" else "Import tamamlandı: $n vərəq, $rowsN sətir"
                AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Bağla", null).show()
                afterRefresh()
            }
        }.start()
    }

    /** import edilən vərəq ayrıca faylda da saxlanılır ki, baza yenilənəndə itməsin */
    private fun saveImportRecord(fileName: String, s: ImpSheet) {
        editsDb.beginTransaction()
        try {
            editsDb.execSQL("INSERT OR REPLACE INTO imp_sheets VALUES(?,?,?,?)",
                arrayOf<Any>(fileName, s.name, s.title, JSONArray(s.headers).toString()))
            editsDb.execSQL("DELETE FROM imp_rows WHERE file = ? AND sheet = ?", arrayOf<Any>(fileName, s.name))
            s.rows.forEachIndexed { i, r ->
                editsDb.execSQL("INSERT INTO imp_rows VALUES(?,?,?,?)", arrayOf<Any>(fileName, s.name, i + 1, JSONArray(r).toString()))
            }
            editsDb.execSQL("DELETE FROM edits WHERE file = ? AND sheet = ?", arrayOf<Any>(fileName, s.name))
            editsDb.setTransactionSuccessful()
        } finally {
            editsDb.endTransaction()
        }
    }

    private fun replayImports(d: SQLiteDatabase) {
        val sheets = ArrayList<Array<String>>()
        editsDb.rawQuery("SELECT file, sheet, title, headers FROM imp_sheets", null).use { c ->
            while (c.moveToNext()) sheets.add(arrayOf(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getString(3)))
        }
        for (s in sheets) {
            val rows = ArrayList<List<String>>()
            editsDb.rawQuery("SELECT cells FROM imp_rows WHERE file = ? AND sheet = ? ORDER BY ord", arrayOf(s[0], s[1])).use { c ->
                while (c.moveToNext()) rows.add(jsonList(c.getString(0)))
            }
            try { applyImportedSheet(d, s[0], ImpSheet(s[1], s[2], jsonList(s[3]), rows)) } catch (e: Exception) { }
        }
    }

    /** vərəqi bazaya yazır: eyni adlı bina varsa sətirləri əvəz edir, yoxdursa "İMPORT" küçəsi altında yeni bina yaradır */
    private fun applyImportedSheet(d: SQLiteDatabase, fileName: String, s: ImpSheet) {
        d.beginTransaction()
        try {
            var fileId = -1L
            d.rawQuery("SELECT id FROM files WHERE name = ?", arrayOf(fileName)).use { if (it.moveToFirst()) fileId = it.getLong(0) }
            if (fileId < 0) {
                var ord = 0
                d.rawQuery("SELECT COALESCE(MAX(ord), -1) + 1 FROM files", null).use { if (it.moveToFirst()) ord = it.getInt(0) }
                val cv = ContentValues()
                cv.put("name", fileName); cv.put("ord", ord)
                fileId = d.insert("files", null, cv)
            }
            var bId = -1L
            d.rawQuery("SELECT id FROM buildings WHERE file_id = ? AND sheet = ?", arrayOf(fileId.toString(), s.name)).use {
                if (it.moveToFirst()) bId = it.getLong(0)
            }
            val hdrJson = JSONArray(s.headers).toString()
            if (bId >= 0) {
                d.execSQL("DELETE FROM rows WHERE building_id = ?", arrayOf<Any>(bId))
                d.execSQL("UPDATE buildings SET headers = ? WHERE id = ?", arrayOf<Any>(hdrJson, bId))
                if (s.title.isNotEmpty()) d.execSQL("UPDATE buildings SET title = ? WHERE id = ?", arrayOf<Any>(s.title, bId))
            } else {
                var sId = -1L
                d.rawQuery("SELECT id FROM streets WHERE file_id = ? AND name = ?", arrayOf(fileId.toString(), "İMPORT")).use {
                    if (it.moveToFirst()) sId = it.getLong(0)
                }
                if (sId < 0) {
                    var ord = 0
                    d.rawQuery("SELECT COALESCE(MAX(ord), 0) + 1 FROM streets WHERE file_id = ?", arrayOf(fileId.toString())).use {
                        if (it.moveToFirst()) ord = it.getInt(0)
                    }
                    val cv = ContentValues()
                    cv.put("file_id", fileId); cv.put("name", "İMPORT"); cv.put("name_n", "import"); cv.put("ord", ord)
                    sId = d.insert("streets", null, cv)
                }
                var bord = 0
                d.rawQuery("SELECT COALESCE(MAX(ord), 0) + 1 FROM buildings WHERE file_id = ?", arrayOf(fileId.toString())).use {
                    if (it.moveToFirst()) bord = it.getInt(0)
                }
                val cv = ContentValues()
                cv.put("street_id", sId); cv.put("file_id", fileId); cv.put("name", s.name); cv.put("name_n", fold(s.name))
                cv.put("title", s.title); cv.put("sheet", s.name); cv.put("headers", hdrJson); cv.put("ord", bord)
                bId = d.insert("buildings", null, cv)
            }
            s.rows.forEachIndexed { i, cells ->
                val cv = ContentValues()
                cv.put("building_id", bId); cv.put("ord", i + 1)
                cv.put("menzil", ""); cv.put("soyad", ""); cv.put("ad", ""); cv.put("ata", "")
                cv.put("menzil_n", ""); cv.put("soyad_n", ""); cv.put("ad_n", ""); cv.put("ata_n", "")
                cv.put("nomre_d", ""); cv.put("cells", JSONArray(cells).toString()); cv.put("borc", 0.0)
                val id = d.insert("rows", null, cv)
                writeRow(d, id, cells, s.headers)
            }
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#ECEFF1"))
        }

        btnSearch = Button(this).apply { text = "Axtarış"; setOnClickListener { showTab(true) } }
        btnCat = Button(this).apply { text = "Kataloq"; setOnClickListener { showTab(false) } }
        val btnExcel = Button(this).apply { text = "📊 Excel"; setOnClickListener { showExcelMenu() } }
        root.addView(rowOf(btnSearch to 1f, btnCat to 1f, btnExcel to 1f), LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(24); leftMargin = dp(8); rightMargin = dp(8)
        })

        // ----- Axtarış tabı (bütün bazada) -----
        mainSearch = SearchUi(
            scope = { null },
            onActive = { },
            onRefresh = {
                val ids = mainSearch.shownRowIds()
                if (ids.isEmpty()) Toast.makeText(this, "Əvvəl axtarış edin", Toast.LENGTH_SHORT).show()
                else refreshRows("Axtarış nəticələri", ids)
            }
        )
        searchPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        searchPanel.addView(mainSearch.form)
        searchPanel.addView(mainSearch.resultsBox, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(searchPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        // ----- Kataloq tabı: başlıq + axtarış + siyahı -----
        catList = ListView(this)
        catSearch = SearchUi(
            scope = {
                when (level) {
                    1 -> Pair("b.file_id = ?", fileId.toString())
                    2 -> Pair("b.street_id = ?", streetId.toString())
                    3 -> Pair("b.id = ?", buildingId.toString())
                    else -> null
                }
            },
            onActive = { active ->
                catSearch.resultsBox.visibility = if (active) View.VISIBLE else View.GONE
                catList.visibility = if (active) View.GONE else View.VISIBLE
            },
            onRefresh = {
                // axtarış aktivdirsə — nəticələr, deyilsə — seçilmiş bölmə
                if (!catSearch.isEmpty()) {
                    val ids = catSearch.shownRowIds()
                    if (ids.isEmpty()) Toast.makeText(this, "Nəticə yoxdur", Toast.LENGTH_SHORT).show()
                    else refreshRows("Axtarış nəticələri (${currentScopeLabel()})", ids)
                } else refreshCurrentSection()
            },
            barInResults = false,
            onSort = { loadLevel(false) }
        )
        catPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvPath = TextView(this).apply {
            textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#263238"))
        }
        tvTotal = TextView(this).apply {
            textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#1565C0"))
        }
        val btnHeaderRefresh = TextView(this).apply {
            text = "🔄"; textSize = 20f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { catSearch.hideSug(); refreshCurrentSection() }
        }
        val line2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(tvTotal, LinearLayout.LayoutParams(0, -2, 1f))
            addView(btnHeaderRefresh, LinearLayout.LayoutParams(-2, -2))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(4))
            addView(tvPath)
            addView(line2)
        }
        catPanel.addView(header)
        catPanel.addView(catSearch.form)
        catPanel.addView(catSearch.bar, LinearLayout.LayoutParams(-1, -2))
        val frame = FrameLayout(this)
        frame.addView(catList, FrameLayout.LayoutParams(-1, -1))
        catSearch.resultsBox.visibility = View.GONE
        frame.addView(catSearch.resultsBox, FrameLayout.LayoutParams(-1, -1))
        catPanel.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(catPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        catList.setOnItemClickListener { _, _, pos, _ ->
            if (level < 3) openChild(catIds[pos], catNames[pos])
        }

        setContentView(root)

        // saytdan yeniləmə üçün gizli WebView-lar bu konteynerdə işləyir (görünmür)
        webHost = FrameLayout(this)
        webHost.clipChildren = false
        addContentView(webHost, FrameLayout.LayoutParams(1, 1))

        loadLevel()
    }

    private fun showTab(search: Boolean) {
        searchPanel.visibility = if (search) View.VISIBLE else View.GONE
        catPanel.visibility = if (search) View.GONE else View.VISIBLE
        btnSearch.alpha = if (search) 1f else 0.55f
        btnCat.alpha = if (search) 0.55f else 1f
        if (search) { catSearch.hideSug(); mainSearch.scheduleSearch() } else { mainSearch.hideSug() }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (catPanel.visibility == View.VISIBLE) {
            if (catSearch.sugVisible()) { catSearch.hideSug(); return }
            if (!catSearch.isEmpty()) { catSearch.clear(); catSearch.scheduleSearch(); return }
            if (level > 0) { level--; loadLevel() } else showTab(true)
        } else {
            if (mainSearch.sugVisible()) { mainSearch.hideSug(); return }
            super.onBackPressed()
        }
    }

    // ---------- kataloq ----------
    private fun openChild(id: Long, label: String) {
        when (level) {
            0 -> { fileId = id; fileName = label }
            1 -> { streetId = id; streetName = label }
            2 -> { buildingId = id }
        }
        level++; loadLevel()
    }

    private fun refreshItem(pos: Int) {
        val id = catIds[pos]
        val label = catNames[pos]
        when (level) {
            0 -> refreshScope(label, "b.file_id = ?", id.toString())
            1 -> refreshScope("$fileName › $label", "b.street_id = ?", id.toString())
            else -> refreshScope("$streetName › $label", "b.id = ?", id.toString())
        }
    }

    private fun loadLevel(clearSearch: Boolean = true, keepScroll: Boolean = false) {
        val keepPos = if (keepScroll) catList.firstVisiblePosition else 0
        val keepTop = if (keepScroll) (catList.getChildAt(0)?.top ?: 0) else 0
        if (clearSearch) {
            catSearch.clear()
            catSearch.resultsBox.visibility = View.GONE
            catList.visibility = View.VISIBLE
        }
        catIds = ArrayList(); catNames = ArrayList(); catCounts = ArrayList(); catBorc = ArrayList()
        val desc = catSearch.sortDesc()
        val sumOrd = if (desc) "COALESCE(SUM(r.borc),0) DESC, " else ""
        fun collect(c: android.database.Cursor) {
            while (c.moveToNext()) {
                catIds.add(c.getLong(0)); catNames.add(c.getString(1)); catCounts.add(c.getInt(2)); catBorc.add(c.getDouble(3))
            }
        }
        when (level) {
            0 -> {
                tvPath.text = "Əsas kateqoriya (fayl)"
                db.rawQuery(
                    "SELECT f.id, COALESCE(NULLIF(f.disp, ''), f.name), COUNT(r.id), COALESCE(SUM(r.borc),0) FROM files f JOIN buildings b ON b.file_id = f.id " +
                        "JOIN rows r ON r.building_id = b.id GROUP BY f.id ORDER BY ${sumOrd}f.ord", null
                ).use { collect(it) }
            }
            1 -> {
                tvPath.text = fileName
                db.rawQuery(
                    "SELECT s.id, s.name, COUNT(r.id), COALESCE(SUM(r.borc),0) FROM streets s JOIN buildings b ON b.street_id = s.id " +
                        "JOIN rows r ON r.building_id = b.id WHERE s.file_id = ? GROUP BY s.id ORDER BY ${sumOrd}s.ord",
                    arrayOf(fileId.toString())
                ).use { collect(it) }
            }
            2 -> {
                tvPath.text = "$fileName  ›  $streetName"
                db.rawQuery(
                    "SELECT b.id, b.name, COUNT(r.id), COALESCE(SUM(r.borc),0) FROM buildings b JOIN rows r ON r.building_id = b.id " +
                        "WHERE b.street_id = ? GROUP BY b.id ORDER BY ${sumOrd}b.ord",
                    arrayOf(streetId.toString())
                ).use { collect(it) }
            }
            3 -> {
                val cards = ArrayList<Card>()
                db.rawQuery("SELECT headers, name, title, sheet FROM buildings WHERE id=?", arrayOf(buildingId.toString())).use { b ->
                    if (b.moveToFirst()) {
                        val hdr = jsonList(b.getString(0)); val nm = b.getString(1); val title = b.getString(2); val sheet = b.getString(3) ?: ""; val fk = fileKeyName(fileId)
                        tvPath.text = "$fileName  ›  $nm"
                        db.rawQuery("SELECT cells, id, ord FROM rows WHERE building_id=? ORDER BY ${if (desc) "borc DESC, " else ""}ord", arrayOf(buildingId.toString())).use { c ->
                            while (c.moveToNext()) cards.add(Card("", title, hdr, jsonList(c.getString(0)), c.getLong(1), nm, "$fk|$sheet|${c.getInt(2)}"))
                        }
                    }
                }
                var sum = 0.0
                db.rawQuery("SELECT COALESCE(SUM(borc),0) FROM rows WHERE building_id=?", arrayOf(buildingId.toString())).use { c ->
                    if (c.moveToFirst()) sum = c.getDouble(0)
                }
                tvTotal.text = totalText(sum, cards.size)
                cardAdapterCat.set(cards)
                catList.divider = null
                catList.adapter = cardAdapterCat
                catList.clipToPadding = false
                catList.setPadding(dp(8), 0, dp(8), dp(8))
                if (keepScroll) catList.setSelectionFromTop(keepPos, keepTop)
                return
            }
        }
        tvTotal.text = totalText(catBorc.sum(), catCounts.sum())
        catList.divider = ColorDrawable(Color.parseColor("#CFD8DC"))
        catList.dividerHeight = 1
        catList.setPadding(0, 0, 0, 0)
        catList.adapter = CatAdapter()
        if (keepScroll) catList.setSelectionFromTop(keepPos, keepTop)
    }

    /** Ad yuxarıda; altında "Ümumi Borc (…) / Ümumi Mənzil (…)" və sağda dairəvi ox (yenilə) */
    inner class CatAdapter : BaseAdapter() {
        override fun getCount() = catNames.size
        override fun getItem(position: Int) = catNames[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.VERTICAL
            row.setBackgroundColor(Color.WHITE)
            row.setPadding(dp(14), dp(10), dp(6), dp(8))
            val name = TextView(this@MainActivity)
            name.text = catNames[position]; name.textSize = 15f; name.typeface = Typeface.DEFAULT_BOLD
            name.setTextColor(Color.parseColor("#263238"))
            val info = TextView(this@MainActivity)
            info.text = totalText(catBorc[position], catCounts[position]); info.textSize = 13f
            info.setTextColor(Color.parseColor("#1565C0"))
            val ref = TextView(this@MainActivity)
            ref.text = "🔄"; ref.textSize = 20f; ref.gravity = Gravity.CENTER
            ref.setPadding(dp(12), dp(4), dp(12), dp(4))
            ref.isFocusable = false
            ref.setOnClickListener { refreshItem(position) }
            val line = LinearLayout(this@MainActivity)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val edt = TextView(this@MainActivity)
            edt.text = "✏️"; edt.textSize = 20f; edt.gravity = Gravity.CENTER
            edt.setPadding(dp(12), dp(4), dp(12), dp(4))
            edt.isFocusable = false
            edt.setOnClickListener { showRenameDialog(position) }
            line.addView(edt, LinearLayout.LayoutParams(-2, -2))
            line.addView(ref, LinearLayout.LayoutParams(-2, -2))
            row.addView(name)
            row.addView(line)
            return row
        }
    }

    // ---------- nəticə kartları ----------
    inner class CardAdapter : BaseAdapter() {
        private var items: MutableList<Card> = ArrayList()
        fun set(l: List<Card>) { items = ArrayList(l); notifyDataSetChanged() }
        fun rowIds(): List<Long> = items.map { it.rowId }.filter { it >= 0 }
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val c = items[position]
            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = dp(10).toFloat(); setStroke(dp(1), Color.parseColor("#CFD8DC"))
                }
            }
            if (c.path.isNotEmpty()) box.addView(TextView(this@MainActivity).apply {
                text = c.path; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#1565C0"))
            })
            if (c.title.isNotEmpty()) box.addView(TextView(this@MainActivity).apply {
                text = c.title; textSize = 13f; setTextColor(Color.GRAY); setPadding(0, 0, 0, dp(4))
            })
            val body = LinearLayout(this@MainActivity)
            body.orientation = LinearLayout.HORIZONTAL
            val col = LinearLayout(this@MainActivity)
            col.orientation = LinearLayout.VERTICAL
            for (i in c.headers.indices) {
                val v = c.cells.getOrNull(i).orEmpty().ifEmpty { "—" }
                col.addView(TextView(this@MainActivity).apply {
                    text = "${c.headers[i]}: $v"; textSize = 16f; setTextColor(Color.parseColor("#263238"))
                    setTextIsSelectable(true)
                })
            }
            body.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (c.rowId >= 0) {
                val ic = LinearLayout(this@MainActivity)
                ic.orientation = LinearLayout.VERTICAL
                ic.gravity = Gravity.CENTER_VERTICAL
                val smsIcon = IconView(this@MainActivity, false)
                smsIcon.contentDescription = "Mesaj"
                smsIcon.sent = sentSet.contains(c.skey + "|sms")
                smsIcon.setOnClickListener { sendMsg(c, false) }
                smsIcon.setOnLongClickListener { unmarkSent(c, false); true }
                val waIcon = IconView(this@MainActivity, true)
                waIcon.contentDescription = "WhatsApp"
                waIcon.sent = sentSet.contains(c.skey + "|wa")
                waIcon.setOnClickListener { sendMsg(c, true) }
                waIcon.setOnLongClickListener { unmarkSent(c, true); true }
                ic.addView(smsIcon, LinearLayout.LayoutParams(dp(52), dp(52)).apply { bottomMargin = dp(14) })
                ic.addView(waIcon, LinearLayout.LayoutParams(dp(52), dp(52)))
                body.addView(ic, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(10); gravity = Gravity.CENTER_VERTICAL })
            }
            box.addView(body, LinearLayout.LayoutParams(-1, -2))
            if (c.rowId >= 0) {
                val btnRef = TextView(this@MainActivity)
                btnRef.text = "🔄  Yenilə"; btnRef.textSize = 18f; btnRef.typeface = Typeface.DEFAULT_BOLD
                btnRef.setTextColor(Color.parseColor("#1565C0")); btnRef.setPadding(0, dp(12), 0, dp(6))
                btnRef.setOnClickListener { refreshRows("Bir mənzil", listOf(c.rowId)) }
                val btnEdit = TextView(this@MainActivity)
                btnEdit.text = "✏️  Redaktə et"; btnEdit.textSize = 18f; btnEdit.typeface = Typeface.DEFAULT_BOLD; btnEdit.gravity = Gravity.END
                btnEdit.setTextColor(Color.parseColor("#1565C0")); btnEdit.setPadding(0, dp(12), 0, dp(6))
                btnEdit.setOnClickListener {
                    showEditDialog(c) { nc ->
                        if (position < items.size) items[position] = c.copy(cells = nc)
                        notifyDataSetChanged()
                    }
                }
                val btns = LinearLayout(this@MainActivity)
                btns.orientation = LinearLayout.HORIZONTAL
                btns.gravity = Gravity.CENTER_VERTICAL
                btns.addView(btnRef, LinearLayout.LayoutParams(0, -2, 1f))
                btns.addView(btnEdit, LinearLayout.LayoutParams(0, -2, 1f))
                box.addView(btns, LinearLayout.LayoutParams(-1, -2))
            }
            val wrap = FrameLayout(this@MainActivity).apply {
                setPadding(0, dp(3), 0, dp(3)); layoutParams = AbsListView.LayoutParams(-1, -2)
            }
            wrap.addView(box, FrameLayout.LayoutParams(-1, -2))
            return wrap
        }
    }
}
