package az.yvok.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String EBEL_URL = "https://e-belediyye.gov.az/tax-debts";
    private static final Pattern CODE = Pattern.compile("^10011[A-Z0-9]{7}$");
    private static final Pattern NAME_OK = Pattern.compile("^[\\p{L}\\s.'\\-]{3,100}$");
    private static final Pattern DEBT_OK = Pattern.compile("^(\\d{1,9}(\\.\\d{1,2})?)?$");
    private static final int REQ_OCR = 7001;
    private static final int CV_MAX = 33;   // gündəlik Cloud Vision sorğu limiti (sayğac)
    // OCR səhvlərinə tolerant: 1/I/L/| və 0/O/Q/D qarışıqlığı "10011" prefiksində düzəldilir,
    // sonrakı 7 simvol isə mövqeyə görə normallaşdırılır (bax: fixOcrTail)
    private static final Pattern OCR_CODE = Pattern.compile("[1IL|!][0OQD][0OQD][1IL|!][1IL|!]([A-Z0-9|!]{7})");
    private static final int MAX_JOBS_PER_VIEW = 10;   // bu qədər sorğudan sonra gizli WebView təzələnir (yavaşlama yığılmasın)
    private static final int LOAD_LIMIT_MS = 2000;     // sorğu göndəriləndən sonra maksimum gözləmə: nəticə gəlməsə "Məlumat tapılmadı"
    private static final int PAGE_GUARD_MS = 20000;    // səhifənin özü açılmasa ümumi qoruyucu
    private static final int MAX_WORKERS = 6;   // toplu yoxlama üçün paralel gizli səhifə sayı

    private static class Job {
        final String code;          // hazırda yoxlanılan kod (O/Q variantı ola bilər)
        final String orig;          // istifadəçinin siyahısındakı ilkin kod
        final boolean batch;
        ArrayDeque<String> variants = null;   // yoxlanılmamış O/Q/I variantları (ilk "tapılmadı"dan sonra qurulur)
        Job(String code, boolean batch) { this.code = code; this.orig = code; this.batch = batch; }
        Job(String code, Job from) { this.code = code; this.orig = from.orig; this.batch = from.batch; this.variants = from.variants; }
    }

    // Hər Worker = e-belediyye.gov.az açıq olan bir gizli WebView (ui-nin ARXASINDA işləyir)
    private class Worker {
        WebView wv;                       // köhnələndə yenisi ilə əvəz olunur
        int jobs = 0;                     // bu WebView neçə sorğu emal edib
        boolean loaded = false;
        String pending = null;
        Job current = null;
        final Runnable watchdog = () -> onWatchdog(this);
    }

    private FrameLayout root;
    private WebView ui;
    private String injectJs;
    private Worker single;                                   // yalnız YVÖK xanası (mesaj göndərmə) üçün
    private final ArrayList<Worker> pool = new ArrayList<>(); // yalnız toplu yoxlama üçün
    private final ArrayDeque<Job> batchJobs = new ArrayDeque<>();
    private Uri cameraUri = null;
    private String ocrEngine = "mlkit";   // "mlkit" və ya "cloud"
    private String cvKey = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        injectJs = readAsset("inject.js");
        clearOcrCache();                      // əvvəlki sessiyadan qalan kamera şəkilləri

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ui = new WebView(this);
        ui.setBackgroundColor(Color.BLACK);
        ui.setFocusable(true);
        ui.setFocusableInTouchMode(true);
        root.addView(ui, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        setupCommon(ui);

        // ---- Yuxarı: öz səhifəmiz (assets/index.html) ----
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        ui.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                ui.requestFocus();
                ui.evaluateJavascript("document.getElementById('phone-input').focus();", null);
                ui.postDelayed(() -> {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(ui, InputMethodManager.SHOW_IMPLICIT);
                }, 350);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {                                   // whatsapp:// və xarici linklər
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Tətbiq tapılmadı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        ui.addJavascriptInterface(new Object() {
            // YVÖK xanası (mesaj göndərmə): yalnız öz gizli səhifəsini sıfırlayır
            @JavascriptInterface
            public void reset() {
                runOnUiThread(() -> recycle(single));
            }

            @JavascriptInterface
            public void fill(String code) {
                final String v = "10011" + (code == null ? "" : code.toUpperCase());
                if (!CODE.matcher(v).matches()) return;
                runOnUiThread(() -> {
                    if (single.current != null) recycle(single);   // əvvəlki sorğunu ləğv et
                    status("loading");
                    start(single, new Job(v, false));
                });
            }

            // Toplu yoxlama səhifələrini əvvəlcədən hazırla ("Şəkildən oxu" basılanda)
            @JavascriptInterface
            public void warm() {
                runOnUiThread(() -> { while (pool.size() < MAX_WORKERS) createWorker(true); });
            }

            // Toplu yoxlama: vergüllə ayrılmış tam kodlar (10011XXXXXXX)
            @JavascriptInterface
            public void batch(String csv) {
                if (csv == null) return;
                final String[] parts = csv.split(",");
                runOnUiThread(() -> {
                    for (String c : parts) {
                        c = c.trim().toUpperCase();
                        if (!CODE.matcher(c).matches()) continue;
                        boolean dup = false;
                        for (Worker w : pool) {
                            if (w.current != null && (w.current.code.equals(c) || w.current.orig.equals(c))) { dup = true; break; }
                        }
                        if (!dup) for (Job j : batchJobs) if (j.code.equals(c)) { dup = true; break; }
                        if (!dup) batchJobs.addLast(new Job(c, true));
                    }
                    pumpBatch();
                });
            }

            // Şəkildən kod oxu: kamera və ya qalereya
            @JavascriptInterface
            public void ocr(String engine, String key) {
                final String eng = "cloud".equals(engine) ? "cloud" : "mlkit";
                final String k = key == null ? "" : key.trim();
                runOnUiThread(() -> {
                    ocrEngine = eng;
                    cvKey = k;
                    if ("cloud".equals(eng) && cvLeft() <= 0) {
                        toast("Cloud Vision limiti bitib (0/" + CV_MAX + "), ML Kit ilə oxunacaq");
                        ocrEngine = "mlkit";
                    }
                    openOcrChooser();
                });
            }

            // Qalan Cloud Vision sorğu sayı
            @JavascriptInterface
            public int cvLeft() {
                return MainActivity.this.cvLeft();
            }

            @JavascriptInterface
            public void batchStop() {
                runOnUiThread(() -> {
                    batchJobs.clear();
                    for (Worker w : pool) if (w.current != null) recycle(w);
                });
            }
        }, "Android");
        ui.loadUrl("https://" + HOST + "/assets/index.html");

        // ---- Aşağı: e-belediyye.gov.az (gizli WebView-lar) ----
        single = createWorker(false);
    }

    // ---------------- OCR ----------------
    private void openOcrChooser() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        Intent chooser = Intent.createChooser(pick, "Şəkil seçin");
        cameraUri = null;
        try {
            File dir = new File(getCacheDir(), "ocr");
            dir.mkdirs();
            File f = new File(dir, "cam_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("", cameraUri));
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        } catch (Exception e) {
            cameraUri = null;   // kamera olmasa yalnız qalereya
        }
        try {
            startActivityForResult(chooser, REQ_OCR);
        } catch (Exception e) {
            toast("Şəkil seçmək mümkün olmadı");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_OCR) return;
        if (res != RESULT_OK) { clearOcrCache(); return; }
        ArrayList<Uri> uris = new ArrayList<>();
        if (data != null && data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) uris.add(u);
            }
        } else if (data != null && data.getData() != null) {
            uris.add(data.getData());
        } else if (cameraUri != null) {
            uris.add(cameraUri);      // kamera çəkilişi
        }
        if (uris.isEmpty()) return;
        runOcr(uris);
    }

    // Hər şəkil əvvəlcə "sənəd skan" effektinə çevrilir (DocEnhance), sonra oxunur.
    // Effektli şəkildə kod tapılmasa, orijinal şəkil də yoxlanılır.
    // Şəkillər PARALEL oxunur (sürət üçün), nəticələr seçilmə sırasına görə birləşdirilir
    private void runOcr(ArrayList<Uri> uris) {
        toast("Şəkil oxunur…");
        final TextRecognizer rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        final int n = uris.size();
        final ArrayList<LinkedHashSet<String>> res = new ArrayList<>();
        for (int i = 0; i < n; i++) res.add(null);
        final int[] left = {n};
        final boolean cloud = "cloud".equals(ocrEngine) && !cvKey.isEmpty();
        final int avail = cloud ? cvLeft() : 0;      // qalan limit qədər şəkil Cloud Vision ilə, artığı ML Kit ilə
        if (cloud && n > avail) toast("Limit çatmır: ilk " + avail + " şəkil Cloud Vision, qalanı ML Kit ilə oxunur");
        for (int i = 0; i < n; i++) {
            final int idx = i;
            final Uri uri = uris.get(i);
            if (cloud && i < avail) {
                new Thread(() -> cloudOcr(rec, uri, idx, res, left)).start();
                continue;
            }
            new Thread(() -> {
                Bitmap enh = null;
                try { enh = DocEnhance.enhance(DocEnhance.load(MainActivity.this, uri)); }
                catch (Throwable ignored) { }
                final Bitmap fb = enh;
                runOnUiThread(() -> ocrEnhanced(rec, uri, fb, idx, res, left));
            }).start();
        }
    }

    // ---------------- Cloud Vision ----------------
    private SharedPreferences cvPrefs() { return getSharedPreferences("cv", MODE_PRIVATE); }

    private static String today() { return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()); }

    // Qalan sorğu sayı: hər gün yenidən CV_MAX olur
    private synchronized int cvLeft() {
        SharedPreferences p = cvPrefs();
        if (!today().equals(p.getString("day", ""))) {
            p.edit().putString("day", today()).putInt("used", 0).apply();
            return CV_MAX;
        }
        return Math.max(0, CV_MAX - p.getInt("used", 0));
    }

    private synchronized void cvSetUsed(int used) {
        cvPrefs().edit().putString("day", today()).putInt("used", Math.max(0, Math.min(CV_MAX, used))).apply();
        final int left = cvLeft();
        runOnUiThread(() -> ui.evaluateJavascript("window.setCvLeft(" + left + ");", null));
    }

    private synchronized void cvUsedOne() { cvSetUsed(CV_MAX - cvLeft() + 1); }

    // Bir şəkil = bir Cloud Vision sorğusu (DOCUMENT_TEXT_DETECTION). Xəta olarsa ML Kit-ə keçilir.
    private void cloudOcr(final TextRecognizer rec, final Uri uri, final int idx,
                          final ArrayList<LinkedHashSet<String>> res, final int[] left) {
        final LinkedHashSet<String> found = new LinkedHashSet<>();
        String err = null;
        try {
            Bitmap bmp = DocEnhance.load(this, uri);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, bos);
            bmp.recycle();
            String b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);

            JSONObject image = new JSONObject().put("content", b64);
            JSONObject feat = new JSONObject().put("type", "DOCUMENT_TEXT_DETECTION");
            JSONObject req = new JSONObject().put("image", image).put("features", new JSONArray().put(feat));
            byte[] body = new JSONObject().put("requests", new JSONArray().put(req)).toString().getBytes("UTF-8");

            URL url = new URL("https://vision.googleapis.com/v1/images:annotate?key=" + URLEncoder.encode(cvKey, "UTF-8"));
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            try (OutputStream os = c.getOutputStream()) { os.write(body); }
            int code = c.getResponseCode();
            InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream rb = new ByteArrayOutputStream();
            if (is != null) {
                byte[] buf = new byte[8192];
                int r;
                while ((r = is.read(buf)) > 0) rb.write(buf, 0, r);
                is.close();
            }
            String txt = rb.toString("UTF-8");
            if (code == 200) {
                cvUsedOne();
                JSONObject first = new JSONObject(txt).getJSONArray("responses").getJSONObject(0);
                if (first.has("error")) {
                    err = first.getJSONObject("error").optString("message", "Cloud Vision xətası");
                } else {
                    JSONObject fta = first.optJSONObject("fullTextAnnotation");
                    String text = fta == null ? "" : fta.optString("text", "");
                    for (String line : text.split("\n")) {
                        String u = line.toUpperCase();
                        int before = found.size();
                        addMatches(u, found);
                        if (found.size() == before) addMatches(u.replaceAll("\\s+", ""), found);
                    }
                }
            } else {
                String msg = "";
                try { msg = new JSONObject(txt).getJSONObject("error").optString("message", ""); } catch (Exception ignored) { }
                if (code == 429) { cvSetUsed(CV_MAX); err = "Google Cloud Vision limiti dolub"; }
                else if (code == 400 && msg.toLowerCase(Locale.ROOT).contains("api key")) err = "Cloud Vision API açarı yanlışdır";
                else if (code == 403) err = "Cloud Vision API açarı icazəsizdir və ya Cloud Vision API aktiv deyil";
                else err = "Cloud Vision xətası (" + code + ")" + (msg.isEmpty() ? "" : ": " + msg);
            }
        } catch (Throwable t) {
            err = "Cloud Vision-a qoşulmaq mümkün olmadı";
        }
        final String e = err;
        runOnUiThread(() -> {
            if (e != null) {
                toast(e);
                if (found.isEmpty()) { ocrEnhancedFallback(rec, uri, idx, res, left); return; }   // xəta + nəticə yoxdur: ML Kit
            }
            ocrImgDone(rec, found, idx, res, left);
        });
    }

    // Cloud Vision alınmayanda həmin şəkil ML Kit ilə oxunur
    private void ocrEnhancedFallback(final TextRecognizer rec, final Uri uri, final int idx,
                                     final ArrayList<LinkedHashSet<String>> res, final int[] left) {
        new Thread(() -> {
            Bitmap enh = null;
            try { enh = DocEnhance.enhance(DocEnhance.load(MainActivity.this, uri)); }
            catch (Throwable ignored) { }
            final Bitmap fb = enh;
            runOnUiThread(() -> ocrEnhanced(rec, uri, fb, idx, res, left));
        }).start();
    }

    private void ocrEnhanced(final TextRecognizer rec, final Uri uri, Bitmap enh, final int idx,
                             final ArrayList<LinkedHashSet<String>> res, final int[] left) {
        if (enh == null) { ocrOriginal(rec, uri, idx, res, left); return; }
        rec.process(InputImage.fromBitmap(enh, 0))
                .addOnSuccessListener(t -> {
                    LinkedHashSet<String> s = new LinkedHashSet<>();
                    collectCodes(t, s);
                    if (s.isEmpty()) ocrOriginal(rec, uri, idx, res, left);
                    else ocrImgDone(rec, s, idx, res, left);
                })
                .addOnFailureListener(e -> ocrOriginal(rec, uri, idx, res, left));
    }

    private void ocrOriginal(final TextRecognizer rec, Uri uri, final int idx,
                             final ArrayList<LinkedHashSet<String>> res, final int[] left) {
        try {
            InputImage img = InputImage.fromFilePath(this, uri);
            rec.process(img)
                    .addOnSuccessListener(t -> {
                        LinkedHashSet<String> s = new LinkedHashSet<>();
                        collectCodes(t, s);
                        ocrImgDone(rec, s, idx, res, left);
                    })
                    .addOnFailureListener(e -> ocrImgDone(rec, new LinkedHashSet<>(), idx, res, left));
        } catch (Exception e) {
            ocrImgDone(rec, new LinkedHashSet<>(), idx, res, left);
        }
    }

    private void ocrImgDone(TextRecognizer rec, LinkedHashSet<String> s, int idx,
                            ArrayList<LinkedHashSet<String>> res, int[] left) {
        res.set(idx, s);
        if (--left[0] > 0) return;
        LinkedHashSet<String> found = new LinkedHashSet<>();
        for (LinkedHashSet<String> x : res) if (x != null) found.addAll(x);   // indeks sırası = seçilmə sırası
        ocrFinish(rec, found);
    }

    // Kameradan çəkilən müvəqqəti şəkillər (cache/ocr) oxunandan sonra silinir.
    // Qalereyadan seçilən şəkillərə toxunulmur.
    private void clearOcrCache() {
        try {
            File[] fs = new File(getCacheDir(), "ocr").listFiles();
            if (fs != null) for (File f : fs) f.delete();
        } catch (Exception ignored) { }
        cameraUri = null;
    }

    private void ocrFinish(TextRecognizer rec, LinkedHashSet<String> found) {
        rec.close();
        clearOcrCache();
        if (found.isEmpty()) {
            toast("Şəkildə kod tapılmadı");
            return;
        }
        ui.evaluateJavascript("window.addOcrCodes(" + JSONObject.quote(String.join("\n", found)) + ");", null);
    }

    // ML Kit blokları öz "ağlına" görə düzür. Ona görə bütün sətirləri götürüb şəkildəki
    // mövqeyinə görə düzürük: yuxarıdan aşağı, eyni cərgədə soldan sağa.
    private void collectCodes(Text t, LinkedHashSet<String> out) {
        if (t == null) return;
        ArrayList<Text.Line> lines = new ArrayList<>();
        for (Text.TextBlock b : t.getTextBlocks()) lines.addAll(b.getLines());
        Collections.sort(lines, (x, y) -> Float.compare(centerY(x), centerY(y)));

        ArrayList<ArrayList<Text.Line>> rows = new ArrayList<>();
        float rowY = 0, rowH = 0;
        for (Text.Line ln : lines) {
            Rect r = ln.getBoundingBox();
            float h = r == null ? 1 : Math.max(1, r.height());
            float cy = centerY(ln);
            if (!rows.isEmpty() && Math.abs(cy - rowY) < 0.5f * Math.max(rowH, h)) {
                ArrayList<Text.Line> row = rows.get(rows.size() - 1);
                row.add(ln);
                rowY = (rowY * (row.size() - 1) + cy) / row.size();
            } else {
                ArrayList<Text.Line> row = new ArrayList<>();
                row.add(ln);
                rows.add(row);
                rowY = cy;
                rowH = h;
            }
        }
        for (ArrayList<Text.Line> row : rows) {
            Collections.sort(row, (x, y) -> Integer.compare(left(x), left(y)));
            for (Text.Line ln : row) {
                String line = ln.getText().toUpperCase();
                int before = out.size();
                addMatches(line, out);
                if (out.size() == before) addMatches(line.replaceAll("\\s+", ""), out);
            }
        }
    }

    private static float centerY(Text.Line l) {
        Rect r = l.getBoundingBox();
        return r == null ? 0 : r.centerY();
    }

    private static int left(Text.Line l) {
        Rect r = l.getBoundingBox();
        return r == null ? 0 : r.left;
    }

    private void addMatches(String s, LinkedHashSet<String> out) {
        java.util.regex.Matcher m = OCR_CODE.matcher(s);
        while (m.find()) out.add("10011" + fixOcrTail(m.group(1)));
    }

    // Koddakı 7 simvolun qaydası: 6-8-ci simvollar (tail[0..2]) hərf, 9-12-ci simvollar (tail[3..6]) rəqəmdir.
    // Hərf yerində: 0 -> O, 1/|/! -> I   (O, Q və digər hərflər olduğu kimi qalır)
    // Rəqəm yerində: O/Q/D -> 0, I/L/|/! -> 1, S -> 5
    private static String fixOcrTail(String t) {
        StringBuilder sb = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (i < 3) {
                if (c == '0') c = 'O';
                else if (c == '1' || c == '|' || c == '!') c = 'I';
            } else {
                if (c == 'O' || c == 'Q' || c == 'D') c = '0';
                else if (c == 'I' || c == 'L' || c == '|' || c == '!') c = '1';
                else if (c == 'S') c = '5';
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private Worker createWorker(boolean batch) {
        final Worker w = new Worker();
        if (batch) pool.add(w);
        attachWebView(w);
        return w;
    }

    private void attachWebView(final Worker w) {
        final WebView wv = new WebView(this);
        wv.setBackgroundColor(Color.WHITE);
        wv.setFocusable(false);                       // klaviaturanı/fokusu oğurlamasın
        wv.setFocusableInTouchMode(false);
        // ui-nin ARXASINA (index 0) əlavə olunur: tam ölçüdə layout alır, amma görünmür
        root.addView(wv, 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setupCommon(wv);
        wv.getSettings().setLoadsImagesAutomatically(false);   // gizli səhifədə şəkil lazım deyil: daha tez açılır
        wv.getSettings().setBlockNetworkImage(true);
        w.wv = wv;
        w.loaded = false;
        wv.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void result(final String code, final String name, final String debt) {
                runOnUiThread(() -> { if (w.wv == wv) onEbelResult(w, code, name, debt); });
            }

            @JavascriptInterface
            public void fail(final String code, final String reason) {
                runOnUiThread(() -> { if (w.wv == wv) onEbelFail(w, code, reason); });
            }
        }, "AndroidEbel");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                if (w.wv == wv) w.loaded = false;     // yeni yükləmə başlayıb: köhnə "hazırdır" siqnalı keçərsiz
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (w.wv != wv) return;
                v.clearHistory();                      // hər təzələmə tarixçəni şişirtməsin
                w.loaded = true;
                if (w.pending != null) {
                    String p = w.pending;
                    w.pending = null;
                    runFill(w, p);
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                // Əsas səhifə yüklənmədisə 45 san gözləmədən tez təkrar yüklə
                if (w.wv != wv || r == null || !r.isForMainFrame()) return;
                v.postDelayed(() -> { if (w.wv == wv && !w.loaded) wv.loadUrl(EBEL_URL); }, 1500);
            }
        });
        wv.loadUrl(EBEL_URL);
    }

    // Köhnə WebView tam məhv edilir, yenisi açılır (uzun işləyəndə yaddaş və yavaşlıq yığılmasın)
    private void rebuild(Worker w) {
        WebView old = w.wv;
        old.removeCallbacks(w.watchdog);
        w.wv = null;
        old.stopLoading();
        old.setWebViewClient(new WebViewClient());
        root.removeView(old);
        old.destroy();
        w.jobs = 0;
        w.current = null;
        w.pending = null;
        attachWebView(w);
    }

    // Səhifəni təzədən yüklə: hər kod TƏMİZ səhifədə yoxlanılır, əvvəlki sorğunun vəziyyəti qalmır
    private void recycle(Worker w) {
        if (w.current != null && ++w.jobs >= MAX_JOBS_PER_VIEW) { rebuild(w); return; }
        w.wv.removeCallbacks(w.watchdog);
        w.current = null;
        w.pending = null;
        w.loaded = false;
        w.wv.stopLoading();
        w.wv.loadUrl(EBEL_URL);
    }

    private void start(Worker w, Job j) {
        w.current = j;
        w.wv.removeCallbacks(w.watchdog);
        if (w.loaded) {
            runFill(w, j.code);                          // 5 san sayğacı runFill-də başlayır
        } else {
            w.pending = j.code;                          // səhifə hələ açılır: sayğac açılandan sonra başlayacaq
            w.wv.postDelayed(w.watchdog, PAGE_GUARD_MS);
        }
    }

    private Worker pickBatchWorker() {
        for (Worker w : pool) if (w.current == null && w.loaded) return w;
        for (Worker w : pool) if (w.current == null) return w;
        if (pool.size() < MAX_WORKERS) return createWorker(true);
        return null;
    }

    private void pumpBatch() {
        while (!batchJobs.isEmpty()) {
            Worker w = pickBatchWorker();
            if (w == null) return;
            start(w, batchJobs.pollFirst());
        }
    }

    private void runFill(Worker w, String value) {
        w.wv.removeCallbacks(w.watchdog);
        w.wv.postDelayed(w.watchdog, LOAD_LIMIT_MS);     // sorğu göndərildi: 2 saniyədə nəticə gəlməsə "Məlumat tapılmadı"
        w.wv.evaluateJavascript(injectJs + ";window.__yvokRun('" + value + "');", null);
    }

    private void onEbelResult(Worker w, String code, String name, String debt) {
        Job j = w.current;
        if (j == null || code == null || !j.code.equals(code)) return;   // köhnə/yad nəticə
        final String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        final String d = debt == null ? "" : debt.trim();
        recycle(w);
        if (!NAME_OK.matcher(n).matches() || !DEBT_OK.matcher(d).matches()) {
            failJob(j, "Məlumat formatı tanınmadı");
        } else if (j.batch) {
            ui.evaluateJavascript("window.setBatchResult(" + JSONObject.quote(j.orig) + ","
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + "," + JSONObject.quote(j.code) + ");", null);
        } else {
            ui.evaluateJavascript("window.setEbelStatus('ok');window.setEbelResult("
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
            if (d.isEmpty()) toast("Borc məbləği tapılmadı");
        }
        if (j.batch) pumpBatch();
    }

    private void onEbelFail(Worker w, String code, String reason) {
        Job j = w.current;
        if (j == null || (code != null && !j.code.equals(code))) return;
        handleFail(w, j, "Məlumat tapılmadı");
    }

    private void onWatchdog(Worker w) {
        Job j = w.current;
        if (j == null) return;
        handleFail(w, j, "Məlumat tapılmadı");
    }

    private void handleFail(Worker w, Job j, String msg) {
        // Nəticə gəlməyibsə (kod yanlışdır) qarışan simvol variantları yoxlanılır (0/O/Q, 1/I, 9-12-ci simvollarda 5/S).
        // Nəticə gəlibsə koda toxunulmur. "Sayt cavab vermədi" mesajı yoxdur: bütün uğursuzluqlar "Məlumat tapılmadı"dır.
        if (j.batch) {
            if (j.variants == null) j.variants = buildVariants(j.orig);
            String next = j.variants.pollFirst();
            if (next != null) {
                recycle(w);
                start(w, new Job(next, j));
                return;
            }
        }
        recycle(w);
        failJob(j, msg);                      // təkrar yoxlama yoxdur: 5 saniyədən çox gözlətmə
        if (j.batch) pumpBatch();
    }

    // Qarışan simvol qrupları: {0,O,Q,D} və {1,I,L} (6-12-ci simvollar), {5,S} (yalnız 8-12-ci simvollar). Koddakı 6-12-ci simvolların (indeks 5..11) hər biri
    // öz qrupunun istənilən üzvü ilə əvəz oluna bilər (hər iki istiqamətdə: O->0, 0->O, 0<->D, I->1, 1->I, 1<->L, O<->Q ...).
    // Variantlar az dəyişiklikdən çoxuna doğru sıralanır və MAX_VARIANTS ilə məhdudlaşdırılır.
    private static final int MAX_VARIANTS = 40;

    private static String confusableGroup(char c, int i) {
        if (c == '0' || c == 'O' || c == 'Q' || c == 'D') return "0OQD";
        if (c == '1' || c == 'I' || c == 'L') return "1IL";
        if (i >= 7 && (c == '5' || c == 'S')) return "5S";   // 8-12-ci simvollarda 5<->S qarışır
        return null;
    }

    private static ArrayDeque<String> buildVariants(String code) {
        ArrayList<Integer> pos = new ArrayList<>();
        for (int i = 5; i < code.length(); i++) if (confusableGroup(code.charAt(i), i) != null) pos.add(i);
        int n = pos.size();
        ArrayList<String> list = new ArrayList<>();
        ArrayList<int[]> meta = new ArrayList<>();
        int[] idx = new int[n];                       // hər mövqedə qrupdan seçilən üzvün nömrəsi
        while (true) {
            char[] cs = code.toCharArray();
            int d = 0;
            for (int b = 0; b < n; b++) {
                int i = pos.get(b);
                char nc = confusableGroup(code.charAt(i), i).charAt(idx[b]);
                if (cs[i] != nc) { cs[i] = nc; d++; }
            }
            if (d > 0) {
                list.add(new String(cs));
                meta.add(new int[]{d, list.size() - 1});
            }
            int b = 0;                                // sayğacı bir artır (qarışıq say sistemi)
            while (b < n) {
                if (++idx[b] < confusableGroup(code.charAt(pos.get(b)), pos.get(b)).length()) break;
                idx[b++] = 0;
            }
            if (b == n) break;
        }
        Collections.sort(meta, (p, q) -> p[0] != q[0] ? Integer.compare(p[0], q[0]) : Integer.compare(p[1], q[1]));
        ArrayDeque<String> out = new ArrayDeque<>();
        for (int[] m : meta) { if (out.size() >= MAX_VARIANTS) break; out.add(list.get(m[1])); }
        return out;
    }

    private void failJob(Job j, String msg) {
        if (j.batch) {
            ui.evaluateJavascript("window.setBatchFail(" + JSONObject.quote(j.orig) + ","
                    + JSONObject.quote(msg) + ");", null);
        } else {
            status("fail");
            toast(msg);
        }
    }

    private void setupCommon(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("OK", (d, x) -> res.confirm())
                        .setOnCancelListener(d -> res.confirm()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("Bəli", (d, x) -> res.confirm())
                        .setNegativeButton("Xeyr", (d, x) -> res.cancel())
                        .setOnCancelListener(d -> res.cancel()).show();
                return true;
            }
        });
    }

    private void status(final String st) {
        runOnUiThread(() -> ui.evaluateJavascript("window.setEbelStatus('" + st + "');", null));
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
