# Pleyer (VlcEngine.kt) — necə işləyir

- Yeganə mühərrik libVLC-dir (3.6.0). Bütün video məntiqi `VlcEngine.kt`-dədir, `MainActivity` yalnız 4 callback alır.
- Bütün native əmrlər (stop / media / play / pause / aspect) tək `vlc-engine` thread-ində ardıcıl icra olunur.
- Hər açılış yeni token alır; köhnə kanalın gec gələn hadisələri atılır.
- Kanal tez dəyişəndə gözləyən köhnə açılışlar silinir, yalnız SON kanal açılır (180 ms debounce).
- Açılış ardıcıllığı: stop() → yeni Media → setMedia → media.release() → play().
- attach/detachViews yalnız UI thread-ində, stop() bitdikdən sonra (onStart / onStop).
- Xəta, yayımın bitməsi, 15 s açılmama və ya 15 s donma halında 2 dəfə avtomatik yenidən qoşulur, sonra xəta mesajı göstərilir.
- Bufer: network-caching 3000 ms, live-caching 2500 ms (80 Mbit üçün).
- Video ekrana setAspectRatio("W:H") ilə uzadılır; reflection və track sorğusu yoxdur.
