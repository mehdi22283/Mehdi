package az.yvok.app;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends Activity {

    private static final String URL = "https://e-belediyye.gov.az/tax-debts";
    private static final String PREFIX = "10011";

    private WebView web;
    private String lastSent = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        EditText box = new EditText(this);
        box.setHint("YVÖK DAXİL EDİN");
        box.setSingleLine(true);
        box.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        box.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7)});
        int p = (int) (12 * getResources().getDisplayMetrics().density);
        box.setPadding(p, p, p, p);
        root.addView(box, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        root.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        web.loadUrl(URL);

        box.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence c, int a, int b, int d) {}
            public void onTextChanged(CharSequence c, int a, int b, int d) {}
            public void afterTextChanged(Editable e) {
                String v = e.toString().trim().toUpperCase();
                if (v.length() == 7 && !v.equals(lastSent)) {
                    lastSent = v;
                    fillAndSubmit(PREFIX + v);
                } else if (v.length() < 7) {
                    lastSent = "";
                }
            }
        });
    }

    private void fillAndSubmit(String value) {
        String js = "(function(val){"
            + "var n=0,t=setInterval(function(){n++;"
            + "var ins=[].slice.call(document.querySelectorAll('input')).filter(function(i){"
            + "return ['hidden','checkbox','radio','button','submit'].indexOf(i.type)<0&&i.offsetParent!==null;});"
            + "var inp=ins.filter(function(i){return /yv[öo]k|v[öo]en/i.test((i.placeholder||'')+(i.name||'')+(i.id||''));})[0]||ins[0];"
            + "var btn=[].slice.call(document.querySelectorAll('button,input[type=submit],a,div[role=button]'))"
            + ".filter(function(x){return /yoxla/i.test(x.innerText||x.value||'');})[0];"
            + "if(inp&&btn){clearInterval(t);inp.focus();"
            + "Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(inp,val);"
            + "inp.dispatchEvent(new Event('input',{bubbles:true}));"
            + "inp.dispatchEvent(new Event('change',{bubbles:true}));"
            + "setTimeout(function(){btn.click();},400);}"
            + "if(n>40)clearInterval(t);},500);})('" + value + "');";
        web.evaluateJavascript(js, null);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
