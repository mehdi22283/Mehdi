package az.mehdi.callrec

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class SetupActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_setup)
        val pkg = packageName
        val cmds = listOf(
            "adb pair IP:PAIR_PORT",
            "adb connect IP:PORT",
            "adb shell pm grant $pkg android.permission.RECORD_AUDIO",
            "adb shell pm grant $pkg android.permission.READ_PHONE_STATE",
            "adb shell pm grant $pkg android.permission.READ_CALL_LOG",
            "adb shell pm grant $pkg android.permission.POST_NOTIFICATIONS",
            "adb shell pm grant $pkg android.permission.WRITE_SECURE_SETTINGS",
            "adb shell appops set $pkg RUN_IN_BACKGROUND allow",
            "adb shell dumpsys deviceidle whitelist +$pkg"
        ).joinToString("\n")
        findViewById<TextView>(R.id.steps).text =
            "1) Parametrlər → Developer options → Wireless debugging aç.\n" +
            "   (Xiaomi: 'USB debugging (Security settings)' də aç.)\n" +
            "2) 'Pair device with pairing code' ilə IP, port və kodu gör.\n" +
            "3) Kompüterdən və ya telefondakı Termux-dan (pkg install android-tools) aşağıdakı əmrləri işlət.\n" +
            "4) Sonra aşağıdakı düymə ilə WhatsApp izləməni aktiv et."
        findViewById<TextView>(R.id.cmds).text = cmds
        findViewById<Button>(R.id.copy).setOnClickListener {
            getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("adb", cmds))
            Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.dev).setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        }
        findViewById<Button>(R.id.bat).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$pkg")))
            } catch (e: Exception) { }
        }
        findViewById<Button>(R.id.acc).setOnClickListener {
            try {
                val comp = "$pkg/$pkg.WaService"
                val cur = Settings.Secure.getString(contentResolver, "enabled_accessibility_services") ?: ""
                if (!cur.contains(comp))
                    Settings.Secure.putString(contentResolver, "enabled_accessibility_services",
                        if (cur.isEmpty()) comp else "$cur:$comp")
                Settings.Secure.putString(contentResolver, "accessibility_enabled", "1")
                Toast.makeText(this, "Aktiv edildi ✅", Toast.LENGTH_SHORT).show()
            } catch (e: SecurityException) {
                Toast.makeText(this, "Əvvəl adb ilə WRITE_SECURE_SETTINGS ver", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }
}
