package az.market.endirim

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Skan edilmiş məhsullar (jurnal linki → məhsullar). Diskdə products.json faylında saxlanır. */
object ProductStore {
    private const val VERSION = 8   // 8: ad + kateqoriya + qiymət ("p") + köhnə qiymət ("o"); 6 və 7 oxunur, amma qiymət üçün bir dəfə yenidən skan olunur
    @Volatile var needsRewrite = false
    private val map = LinkedHashMap<String, List<Product>>()
    private val marketOf = HashMap<String, String>()
    private val sigs = HashMap<String, String>()
    private val legacy = HashSet<String>()    // qiymətsiz köhnə formatdan gələn jurnallar — qiymət üçün yenidən skan olunmalıdır

    private val writeLock = Mutex()   // eyni vaxtda iki yazma products.json.part faylını korlamasın

    private fun file(ctx: Context) = File(ctx.filesDir, "products.json")

    @Synchronized
    fun load(ctx: Context): List<Product> {
        map.clear()
        marketOf.clear()
        sigs.clear()
        legacy.clear()
        needsRewrite = false
        try {
            val f = file(ctx)
            if (f.exists()) {
                val root = JSONObject(f.readText())
                val v = root.optInt("v")
                if (v == VERSION || v == 7 || v == 6) {
                    val migrate = v == 6          // yalnız v6 adları yeni yazılış qaydaları ilə düzəldilir
                    val cats = root.getJSONObject("catalogs")
                    for (url in cats.keys()) {
                        val o = cats.getJSONObject(url)
                        val market = o.getString("market")
                        val arr = o.getJSONArray("items")
                        val list = ArrayList<Product>(arr.length())
                        val seen = HashSet<String>()
                        for (i in 0 until arr.length()) {
                            val it = arr.getJSONObject(i)
                            val raw = it.getString("n")
                            // köhnə (v6) adlar yeni yazılış qaydaları ilə bir dəfə düzəldilir və kateqoriya təyin olunur
                            val name = if (migrate) AzText.fix(raw) else raw
                            val cat = if (migrate || !it.has("c")) Categorizer.classify(name) else it.getString("c")
                            val p = Product(
                                name, market, url, it.optInt("pg", 1), cat,
                                it.optString("p", "").ifEmpty { null }, it.optString("o", "").ifEmpty { null }
                            )
                            if (seen.add(p.key)) list.add(p)
                        }
                        map[url] = list
                        marketOf[url] = market
                        if (v == VERSION && !o.optBoolean("lg", false)) {
                            if (!o.isNull("sig") && o.has("sig")) sigs[url] = o.getString("sig")
                        } else legacy.add(url)     // köhnə nəticədə qiymət yoxdur — jurnal yenidən skan olunacaq (işarə diskdə saxlanır)
                    }
                    if (v != VERSION) needsRewrite = true
                }
            }
        } catch (e: Exception) {
            map.clear()
        }
        return all()
    }

    /** Köhnə formatdan köçürülən nəticələri yeni formatda diskə yazır. */
    suspend fun rewriteIfNeeded(ctx: Context) {
        if (needsRewrite) {
            needsRewrite = false
            save(ctx)
        }
    }

    @Synchronized
    fun all(): List<Product> = map.values.flatten()

    @Synchronized
    fun scannedUrls(): Set<String> = map.keys.toSet()

    @Synchronized
    fun sigOf(url: String): String? = sigs[url]

    /** Qiymət əlavə olunmazdan əvvəl skan edilmiş jurnal — yenidən skan lazımdır. */
    @Synchronized
    fun needsPriceScan(url: String): Boolean = url in legacy

    suspend fun put(ctx: Context, url: String, market: String, items: List<Product>, sig: String?) {
        synchronized(this) {
            map[url] = items
            legacy.remove(url)
            marketOf[url] = market
            if (sig != null) sigs[url] = sig else sigs.remove(url)
        }
        save(ctx)
    }

    /** Jurnal dəyişəndə köhnə skan nəticəsi atılır (yenidən skan olunacaq). */
    suspend fun forget(ctx: Context, url: String) {
        val had = synchronized(this) { sigs.remove(url); marketOf.remove(url); map.remove(url) != null }
        if (had) save(ctx)
    }

    /** Siyahıda olmayan köhnə jurnalların məhsulları silinir. */
    suspend fun cleanup(ctx: Context, keepUrls: Set<String>) {
        val changed = synchronized(this) { map.keys.retainAll(keepUrls) }
        if (changed) save(ctx)
    }

    private suspend fun save(ctx: Context) = withContext(Dispatchers.IO) {
        writeLock.withLock {
            try {
                // snapshot kilidin içində alınır — sonuncu yazan həmişə ən yeni vəziyyəti yazır
                val snapshot = synchronized(this@ProductStore) { LinkedHashMap(map) }
                val markets = synchronized(this@ProductStore) { HashMap(marketOf) }
                val sigSnap = synchronized(this@ProductStore) { HashMap(sigs) }
                val legacySnap = synchronized(this@ProductStore) { HashSet(legacy) }
                val cats = JSONObject()
                for ((url, list) in snapshot) {
                    val arr = JSONArray()
                    for (p in list) arr.put(JSONObject().apply {
                        put("n", p.name)
                        put("c", p.cat)
                        put("pg", p.page)
                        if (p.price != null) put("p", p.price)
                        if (p.old != null) put("o", p.old)
                    })
                    cats.put(url, JSONObject().put("market", markets[url] ?: "").put("sig", sigSnap[url] ?: JSONObject.NULL).put("lg", url in legacySnap).put("items", arr))
                }
                val f = file(ctx)
                val tmp = File(f.path + ".part")
                tmp.writeText(JSONObject().put("v", VERSION).put("catalogs", cats).toString())
                if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
            } catch (e: Exception) {
            }
        }
    }
}
