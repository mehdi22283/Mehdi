package az.market.endirim

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Son uğurlu nəticələri diskdə saxlayır — offline açılanda göstərilir. */
object Store {
    private fun file(ctx: Context) = File(ctx.filesDir, "results.json")

    fun save(ctx: Context, data: Map<String, List<Catalog>>) {
        try {
            val root = JSONObject()
            for ((m, cats) in data) {
                val arr = JSONArray()
                for (c in cats) {
                    arr.put(JSONObject().apply {
                        put("market", c.market)
                        put("title", c.title)
                        put("date", c.date ?: JSONObject.NULL)
                        put("kind", c.kind.name)
                        put("urls", JSONArray(c.urls))
                        put("note", c.note ?: JSONObject.NULL)
                    })
                }
                root.put(m, arr)
            }
            val f = file(ctx)
            val tmp = File(f.path + ".part")
            tmp.writeText(root.toString())
            tmp.renameTo(f)
        } catch (e: Exception) {
        }
    }

    fun load(ctx: Context): Map<String, List<Catalog>> {
        val out = HashMap<String, List<Catalog>>()
        try {
            val f = file(ctx)
            if (!f.exists()) return out
            val root = JSONObject(f.readText())
            for (m in root.keys()) {
                val arr = root.getJSONArray(m)
                val list = ArrayList<Catalog>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val u = o.getJSONArray("urls")
                    list.add(
                        Catalog(
                            o.getString("market"), o.getString("title"),
                            if (o.isNull("date")) null else o.getString("date"),
                            Kind.valueOf(o.getString("kind")),
                            (0 until u.length()).map { u.getString(it) },
                            if (o.isNull("note")) null else o.getString("note")
                        )
                    )
                }
                out[m] = list
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }
}
