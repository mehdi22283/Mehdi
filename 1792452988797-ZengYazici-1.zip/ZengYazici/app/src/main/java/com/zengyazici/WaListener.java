package com.zengyazici;

import android.app.Notification;
import android.content.Intent;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** WhatsApp zəng bildirişlərini izləyib yazını başladır/dayandırır. */
public class WaListener extends NotificationListenerService {
    private static boolean incoming;
    private static String name = "";
    private static String key;

    private boolean isWa(StatusBarNotification s) {
        String p = s.getPackageName();
        return "com.whatsapp".equals(p) || "com.whatsapp.w4b".equals(p);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (!isWa(sbn)) return;
        Notification n = sbn.getNotification();
        if (!Notification.CATEGORY_CALL.equals(n.category)) return;
        CharSequence t = n.extras.getCharSequence(Notification.EXTRA_TITLE);
        String title = t == null ? "" : t.toString();
        boolean ringing = n.actions != null && n.actions.length >= 2;
        if (ringing) {
            incoming = true;
            name = title;
            return;
        }
        if (key == null) {
            key = sbn.getKey();
            send(RecService.A_WA_ON, incoming ? "in" : "out", title.isEmpty() ? name : title);
            incoming = false;
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        if (!isWa(sbn)) return;
        if (key != null && key.equals(sbn.getKey())) {
            key = null;
            send(RecService.A_WA_OFF, "", "");
        } else if (key == null) {
            incoming = false;
        }
    }

    private void send(String action, String dir, String nm) {
        if (!RecService.running) return;
        try {
            Intent i = new Intent(this, RecService.class).setAction(action);
            i.putExtra("dir", dir);
            i.putExtra("name", nm);
            startService(i);
        } catch (Throwable e) {
            RecService.log("WA: " + e);
        }
    }
}
