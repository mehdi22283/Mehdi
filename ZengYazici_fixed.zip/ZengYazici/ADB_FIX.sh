#!/usr/bin/env sh
set -eu
ADB_TARGET="127.0.0.1:5555"
echo "Lokal ADB cihazina qosulunur: $ADB_TARGET"
adb connect "$ADB_TARGET"
adb -s "$ADB_TARGET" get-state >/dev/null
echo 'Zəng Yazıcı icazələri verilir...'
adb -s "$ADB_TARGET" shell pm grant com.zengyazici android.permission.RECORD_AUDIO
adb -s "$ADB_TARGET" shell pm grant com.zengyazici android.permission.READ_PHONE_STATE
adb -s "$ADB_TARGET" shell pm grant com.zengyazici android.permission.READ_CALL_LOG
adb -s "$ADB_TARGET" shell pm grant com.zengyazici android.permission.POST_NOTIFICATIONS || true
adb -s "$ADB_TARGET" shell appops set com.zengyazici RECORD_AUDIO allow
adb -s "$ADB_TARGET" shell appops set com.zengyazici SYSTEM_ALERT_WINDOW allow
adb -s "$ADB_TARGET" shell appops set com.zengyazici RUN_IN_BACKGROUND allow
adb -s "$ADB_TARGET" shell appops set com.zengyazici RUN_ANY_IN_BACKGROUND allow
adb -s "$ADB_TARGET" shell dumpsys deviceidle whitelist +com.zengyazici
adb -s "$ADB_TARGET" shell cmd notification allow_listener com.zengyazici/com.zengyazici.WaListener || true
adb -s "$ADB_TARGET" shell am force-stop com.zengyazici
adb -s "$ADB_TARGET" shell monkey -p com.zengyazici 1
echo 'Bitdi. WhatsApp-da sınaq zəngi edin, sonra tətbiqdə Menyu > Log bölməsinə baxın.'
