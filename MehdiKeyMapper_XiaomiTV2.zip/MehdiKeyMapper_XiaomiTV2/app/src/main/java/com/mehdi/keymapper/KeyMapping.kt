package com.mehdi.keymapper

import java.util.UUID

enum class ActionType {
    KEY_REMAP,
    LAUNCH_APP,
    FORCE_STOP_CURRENT_APP
}

data class KeyMapping(
    val id: String = UUID.randomUUID().toString(),
    var triggerKeyCode: Int,
    var isLongPress: Boolean = false,
    var targetKeyCode: Int = 0,
    var targetPackage: String? = null,
    var actionType: ActionType = ActionType.KEY_REMAP,
    var label: String = ""
)
