package az.zengyazici;

import android.accessibilityservice.AccessibilityService;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;

/**
 * 1) Android 10+ cihazlarda mikrofonun fonda yazıya icazə verməsinə kömək edir.
 * 2) Zəng zamanı telefon tətbiqinin ekranında "Yaz/Record" düyməsini avtomatik basır
 *    (Xiaomi-nin daxili yazıcısı hər iki tərəfi yazır).
 */
public class CallAccessService extends AccessibilityService {
    public static volatile boolean inCall = false, clicked = false;
    static final String[] KEYS = {"record", "yazma", "yazmağa", "zəng yaz", "zeng yaz", "запис", "kayıt", "kaydet"};
    static final String[] STOP = {"stop", "dayan", "saxla", "durdur", "стоп"};
    long last = 0;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (!inCall || clicked) return;
        CharSequence pk = e.getPackageName();
        if (pk == null || pk.toString().startsWith("com.whatsapp") || pk.toString().equals(getPackageName())) return;
        long now = SystemClock.elapsedRealtime();
        if (now - last < 400) return;
        last = now;
        if (!getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("xclick", true)) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            AccessibilityNodeInfo t = find(root, 0);
            if (t != null) {
                AccessibilityNodeInfo c = t;
                while (c != null && !c.isClickable()) c = c.getParent();
                if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) clicked = true;
            }
        } catch (Exception x) { }
    }

    AccessibilityNodeInfo find(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 25) return null;
        String s = ((n.getText() == null ? "" : n.getText()) + " "
                + (n.getContentDescription() == null ? "" : n.getContentDescription()) + " "
                + (n.getViewIdResourceName() == null ? "" : n.getViewIdResourceName())).toLowerCase(Locale.ROOT);
        boolean stop = false;
        for (String k : STOP) if (s.contains(k)) stop = true;
        if (!stop) for (String k : KEYS) if (s.contains(k)) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = find(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    @Override public void onInterrupt() { }
}
