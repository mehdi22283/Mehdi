package az.m3u.sinayici

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** Endirilən fayllar jurnalı: bütün brauzer rejimlərində eyni siyahı. Aktiv endirmələr yaddaşda, bitənlər SharedPreferences-də. */
object DlLog {
    class Item(val name: String, val uri: String, val size: Long, val time: Long)

    private const val PREF = "dllog"
    private const val KEY = "items"
    private const val MAX = 200

    /** Gedən endirmələr: bildiriş id → "ad — faiz". */
    val active = ConcurrentHashMap<Int, String>()

    @Synchronized fun add(ctx: Context, name: String, uri: String, size: Long) {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = try { JSONArray(sp.getString(KEY, "[]")) } catch (e: Exception) { JSONArray() }
        val out = JSONArray()
        out.put(JSONObject().put("n", name).put("u", uri).put("s", size).put("t", System.currentTimeMillis()))
        for (i in 0 until minOf(arr.length(), MAX - 1)) out.put(arr.get(i))
        sp.edit().putString(KEY, out.toString()).apply()
    }

    @Synchronized fun list(ctx: Context): List<Item> {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = try { JSONArray(sp.getString(KEY, "[]")) } catch (e: Exception) { return emptyList() }
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { Item(it.optString("n"), it.optString("u"), it.optLong("s"), it.optLong("t")) }
        }
    }

    @Synchronized fun remove(ctx: Context, time: Long) {
        val keep = list(ctx).filter { it.time != time }
        val out = JSONArray()
        keep.forEach { out.put(JSONObject().put("n", it.name).put("u", it.uri).put("s", it.size).put("t", it.time)) }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, out.toString()).apply()
    }

    @Synchronized fun clear(ctx: Context) { ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply() }
}
