package az.callrec

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.os.*
import android.provider.CallLog
import android.telephony.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File

class RecorderService : Service() {
    companion object {
        var inst: RecorderService? = null
        fun dir(c: Context): File = (c.getExternalFilesDir("recordings") ?: c.filesDir).also { it.mkdirs() }
    }

    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var app = "Telefon"
    private var direction = "out"
    private var prev = TelephonyManager.CALL_STATE_IDLE
    private val h = Handler(Looper.getMainLooper())
    private lateinit var am: AudioManager
    private var cb: Any? = null
    private var idlePolls = 0

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        inst = this
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Zəng yazıcı", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "rec").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Zəng yazıcı aktivdir").setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        registerCalls()
    }

    @Suppress("DEPRECATION")
    private fun registerCalls() {
        val tm = getSystemService(TelephonyManager::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val c = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) = onState(state)
                }
                cb = c; tm.registerTelephonyCallback(mainExecutor, c)
            } else {
                val l = object : PhoneStateListener() {
                    override fun onCallStateChanged(state: Int, n: String?) = onState(state)
                }
                cb = l; tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
            }
        } catch (e: SecurityException) { }
    }

    private fun onState(s: Int) {
        if (s == prev) return
        when (s) {
            TelephonyManager.CALL_STATE_RINGING -> direction = "in"
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                if (prev != TelephonyManager.CALL_STATE_RINGING) direction = "out"
                startRec("Telefon", direction, "")
            }
            TelephonyManager.CALL_STATE_IDLE -> if (app == "Telefon") stopRec()
        }
        prev = s
    }

    fun startRec(a: String, d: String, label: String) {
        if (rec != null) return
        app = a; direction = d
        val name = "${System.currentTimeMillis()}__${a}__${d}__${clean(label.ifEmpty { "Naməlum" })}.m4a"
        val f = File(dir(this), name)
        val speaker = getSharedPreferences("s", 0).getBoolean("speaker", true)
        if (speaker) { try { am.isSpeakerphoneOn = true } catch (e: Exception) { } }
        // VOICE_CALL (hər iki tərəf) mümkün olmasa, VOICE_RECOGNITION / MIC ilə davam edir
        val sources = intArrayOf(MediaRecorder.AudioSource.VOICE_CALL, MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)
        for (src in sources) {
            try {
                val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
                r.setAudioSource(src)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioEncodingBitRate(96000); r.setAudioSamplingRate(44100)
                r.setOutputFile(f.absolutePath)
                r.prepare(); r.start()
                rec = r; file = f
                break
            } catch (e: Exception) { f.delete() }
        }
        if (rec != null && a == "WhatsApp") { idlePolls = 0; h.postDelayed(poll, 3000) }
    }

    private val poll = object : Runnable {
        override fun run() {
            if (rec == null || app != "WhatsApp") return
            idlePolls = if (am.mode == AudioManager.MODE_NORMAL) idlePolls + 1 else 0
            if (idlePolls >= 2) stopRec() else h.postDelayed(this, 2000)
        }
    }

    fun stopRec() {
        val r = rec ?: return
        val f = file; rec = null; file = null
        h.removeCallbacks(poll)
        try { r.stop() } catch (e: Exception) { f?.delete() }
        r.release()
        try { am.isSpeakerphoneOn = false } catch (e: Exception) { }
        if (app == "Telefon" && f != null && f.exists()) Thread { fixNumber(f) }.start()
    }

    private fun fixNumber(f: File) {
        Thread.sleep(1800)
        try {
            contentResolver.query(CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE),
                null, null, CallLog.Calls.DATE + " DESC")?.use {
                if (it.moveToFirst()) {
                    val num = it.getString(0) ?: ""
                    val label = clean(it.getString(1)?.takeIf { n -> n.isNotBlank() } ?: num.ifEmpty { "Gizli nömrə" })
                    val d = if (it.getInt(2) == CallLog.Calls.OUTGOING_TYPE) "out" else "in"
                    val p = f.name.split("__")
                    f.renameTo(File(f.parentFile, "${p[0]}__Telefon__${d}__$label.m4a"))
                }
            }
        } catch (e: Exception) { }
    }

    private fun clean(s: String) = s.replace(Regex("[/\\\\:*?\"<>|]"), "").replace("__", "_").take(60)

    override fun onDestroy() { stopRec(); inst = null; super.onDestroy() }
}
