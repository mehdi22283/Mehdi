package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.*
import android.widget.Toast
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Daxili qaranlıq brauzer (Ottplayer və GitHub axtarışı üçün).
 * - Endirilən M3U fayl filesDir/playlist1.m3u kimi saxlanılır.
 * - Media linkinə (m3u8, ts, mp4 …) toxunduqda və ya linkə uzun basdıqda link tətbiqin playerində açılır.
 */
class BrowserActivity : Activity() {
    private lateinit var web: WebView

    private val mediaExt = setOf("m3u8", "m3u", "ts", "mp4", "mkv", "mpd", "flv", "avi", "mov", "webm",
        "mp3", "aac", "m4a", "m4v", "3gp", "mpg", "mpeg")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; javaScriptCanOpenWindowsAutomatically = true }
        enableDark()
        CookieManager.getInstance().setAcceptCookie(true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = handleLink(r.url.toString())
        }
        web.setOnLongClickListener {
            val hit = web.hitTestResult
            val link = hit.extra
            if ((hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                && link != null && link.startsWith("http")) {
                AlertDialog.Builder(this).setTitle(link.take(80))
                    .setItems(arrayOf("▶ Playerdə aç", "🌐 Brauzerdə aç")) { _, w ->
                        if (w == 0) playStream(link) else web.loadUrl(link)
                    }.show()
                true
            } else false
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun saveBase64(s: String) = save(Base64.decode(s, Base64.DEFAULT))
        }, "NativeSave")
        web.setDownloadListener { url, ua, _, _, _ ->
            Toast.makeText(this, "Yüklənir...", Toast.LENGTH_SHORT).show()
            when {
                url.startsWith("blob:") -> web.evaluateJavascript(
                    "fetch('$url').then(r=>r.blob()).then(b=>{var f=new FileReader();f.onload=function(){NativeSave.saveBase64(f.result.split(',')[1]);};f.readAsDataURL(b);});", null)
                url.startsWith("data:") -> save(Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT))
                else -> Thread {
                    try {
                        val c = URL(url).openConnection() as HttpURLConnection
                        c.setRequestProperty("User-Agent", ua)
                        CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                        save(c.inputStream.readBytes())
                    } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() } }
                }.start()
            }
        }
        web.loadUrl(intent.getStringExtra("url") ?: "https://ottplayer.tv/playlist/original")
    }

    private fun enableDark() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, true)
        } else if (Build.VERSION.SDK_INT >= 29) {
            @Suppress("DEPRECATION")
            web.settings.forceDark = WebSettings.FORCE_DARK_ON
        }
    }

    /** true qaytarsa naviqasiya brauzerdə baş vermir (link ya playerdə açılır, ya da playlist kimi yadda saxlanılır). */
    private fun handleLink(raw: String): Boolean {
        val u = Uri.parse(raw)
        if (u.scheme != "http" && u.scheme != "https") return false
        val ext = (u.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        if (ext !in mediaExt) return false
        var url = raw
        if (u.host == "github.com") {
            val seg = u.pathSegments
            if (ext != "m3u" && ext != "m3u8") return false
            if (seg.size >= 5 && seg[2] == "blob") url = "https://raw.githubusercontent.com/${seg[0]}/${seg[1]}/${seg.drop(3).joinToString("/")}"
            else return false
        }
        if (ext == "m3u" || ext == "m3u8") {
            // kanal siyahısıdır, yoxsa canlı yayım (HLS)?
            Toast.makeText(this, "Yoxlanılır...", Toast.LENGTH_SHORT).show()
            val target = url
            Thread {
                var bytes: ByteArray? = null
                try {
                    val t = Net.Target(target, mapOf("User-Agent" to "VLC/3.0.20 LibVLC/3.0.20"), "brauzer")
                    val c = Net.connect(t, null, 10000)
                    bytes = c.inputStream.use { it.readBytes() }
                    c.disconnect()
                } catch (e: Exception) { }
                val text = bytes?.let { String(it, Charsets.UTF_8) } ?: ""
                val isList = bytes != null && text.contains("#EXTINF") && !text.contains("#EXT-X-")
                runOnUiThread { if (isList) save(bytes!!) else playStream(target) }
            }.start()
        } else playStream(url)
        return true
    }

    private fun playStream(url: String) {
        val name = Uri.decode(Uri.parse(url).lastPathSegment ?: url)
        PlayQueue.items = listOf(QItem(name, url, "{}")); PlayQueue.index = 0
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun save(bytes: ByteArray) {
        val t = String(bytes, Charsets.UTF_8)
        runOnUiThread {
            if (!t.contains("#EXTINF") && !t.contains("#EXTM3U")) {
                Toast.makeText(this, "Endirilən fayl M3U deyil", Toast.LENGTH_LONG).show(); return@runOnUiThread
            }
            File(filesDir, "playlist1.m3u").writeText(t)
            setResult(RESULT_OK); finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
