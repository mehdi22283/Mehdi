plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "az.m3u.sinayici"
    compileSdk = 34
    defaultConfig { applicationId = "az.m3u.sinayici"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0"; ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17"; freeCompilerArgs += "-opt-in=androidx.media3.common.util.UnstableApi" }
    lint { abortOnError = false }
}
dependencies {
    val m = "1.3.1"
    implementation("androidx.media3:media3-exoplayer:$m")
    implementation("androidx.media3:media3-exoplayer-hls:$m")
    implementation("androidx.media3:media3-exoplayer-dash:$m")
    implementation("androidx.media3:media3-ui:$m")
    implementation("org.videolan.android:libvlc-all:3.6.0")
}
