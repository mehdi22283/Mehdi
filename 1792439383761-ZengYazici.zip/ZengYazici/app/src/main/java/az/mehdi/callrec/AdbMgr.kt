package az.mehdi.callrec

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import sun.security.x509.AlgorithmId
import sun.security.x509.CertificateAlgorithmId
import sun.security.x509.CertificateExtensions
import sun.security.x509.CertificateIssuerName
import sun.security.x509.CertificateSerialNumber
import sun.security.x509.CertificateSubjectName
import sun.security.x509.CertificateValidity
import sun.security.x509.CertificateVersion
import sun.security.x509.CertificateX509Key
import sun.security.x509.KeyIdentifier
import sun.security.x509.PrivateKeyUsageExtension
import sun.security.x509.SubjectKeyIdentifierExtension
import sun.security.x509.X500Name
import sun.security.x509.X509CertImpl
import sun.security.x509.X509CertInfo
import java.io.ByteArrayInputStream
import java.io.File
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.Random

class AdbMgr private constructor(ctx: Context) : AbsAdbConnectionManager() {
    private val priv: PrivateKey
    private val cert: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val kf = File(ctx.filesDir, "adb_key.der")
        val cf = File(ctx.filesDir, "adb_cert.der")
        var p: PrivateKey? = null
        var c: Certificate? = null
        try {
            if (kf.exists() && cf.exists()) {
                p = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
                c = CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(cf.readBytes()))
            }
        } catch (e: Exception) { p = null; c = null }
        if (p == null || c == null) {
            val g = KeyPairGenerator.getInstance("RSA")
            g.initialize(2048, SecureRandom())
            val kp = g.generateKeyPair()
            val pub = kp.public
            p = kp.private
            val subject = "CN=ZengYazici"
            val alg = "SHA512withRSA"
            val notBefore = Date()
            val notAfter = Date(System.currentTimeMillis() + 3650L * 86400000L)
            val ext = CertificateExtensions()
            ext.set("SubjectKeyIdentifier", SubjectKeyIdentifierExtension(KeyIdentifier(pub).identifier))
            val name = X500Name(subject)
            ext.set("PrivateKeyUsage", PrivateKeyUsageExtension(notBefore, notAfter))
            val info = X509CertInfo()
            info.set("version", CertificateVersion(2))
            info.set("serialNumber", CertificateSerialNumber(Random().nextInt() and Int.MAX_VALUE))
            info.set("algorithmID", CertificateAlgorithmId(AlgorithmId.get(alg)))
            info.set("subject", CertificateSubjectName(name))
            info.set("key", CertificateX509Key(pub))
            info.set("validity", CertificateValidity(notBefore, notAfter))
            info.set("issuer", CertificateIssuerName(name))
            info.set("extensions", ext)
            val impl = X509CertImpl(info)
            impl.sign(p, alg)
            c = impl
            kf.writeBytes(p!!.encoded)
            cf.writeBytes(impl.encoded)
        }
        priv = p!!
        cert = c!!
    }

    override fun getPrivateKey(): PrivateKey = priv
    override fun getCertificate(): Certificate = cert
    override fun getDeviceName(): String = "ZengYazici"

    companion object {
        @Volatile private var inst: AdbMgr? = null
        fun get(ctx: Context): AdbMgr = inst ?: synchronized(this) {
            inst ?: AdbMgr(ctx.applicationContext).also { inst = it }
        }
    }
}
