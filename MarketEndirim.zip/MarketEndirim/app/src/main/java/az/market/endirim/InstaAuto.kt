package az.market.endirim

import android.view.View
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Ana ekranın sağ üst Instagram düyməsinə basılanda başlayır: bu gün hələ yenilənməyən marketlərin
 * son 15 postunun şəkillərini (video yoxdur) offline yükləyir. Gizli WebView istifadə olunur.
 */
object InstaAuto {
    private var job: Job? = null

    /** Mini brauzer açıq olanda irəliləyişi oradan da göstərmək üçün. */
    var listener: ((String) -> Unit)? = null

    fun start(act: AppCompatActivity, onStatus: (String) -> Unit) {
        val app = act.applicationContext
        fun report(s: String) {
            onStatus(s)
            listener?.invoke(s)
        }
        if (job?.isActive == true) {
            report("Instagram şəkilləri artıq yüklənir…")
            return
        }
        InstaSaver.cleanupLegacy(app)
        val todo = InstaSaver.users().filter { !InstaSaver.doneToday(app, it.second) }
        if (todo.isEmpty()) {
            report("Instagram şəkilləri bu gün artıq yenilənib")
            return
        }
        if (!Store.online(app)) {
            report("İnternet yoxdur — Instagram şəkilləri yüklənmir")
            return
        }
        if (InstaSaver.needLogin(app) && !InstaSaver.loggedIn()) {
            report("Instagram giriş tələb edir — mini brauzerdə daxil olun, sonra yenidən Instagram düyməsinə basın")
            return
        }
        job = act.lifecycleScope.launch {
            if (!InstaSaver.lock.tryLock()) return@launch
            val web = WebView(app)
            try {
                web.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    userAgentString = InstaSaver.UA
                    mediaPlaybackRequiresUserGesture = true
                }
                CookieManager.getInstance().setAcceptCookie(true)
                // ekransız WebView-un ölçüsü olmalıdır, yoxsa sürüşdürmə post yükləmir
                web.measure(View.MeasureSpec.makeMeasureSpec(1080, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(1920, View.MeasureSpec.EXACTLY))
                web.layout(0, 0, 1080, 1920)
                val saver = InstaSaver(app, web)
                web.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        saver.pageDone?.complete(Unit)
                    }

                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                        InstaSaver.blockVideo(request) ?: super.shouldInterceptRequest(view, request)
                }
                var ok = 0
                var failed = 0
                var login = false
                for ((i, p) in todo.withIndex()) {
                    val r = saver.saveUser(p.second) { report("Instagram ${i + 1}/${todo.size} ${p.first}: $it") }
                    when (r) {
                        InstaSaver.Res.OK -> ok++
                        InstaSaver.Res.FAILED -> failed++
                        InstaSaver.Res.LOGIN -> login = true
                    }
                    if (login) break
                }
                CookieManager.getInstance().flush()
                report(
                    if (login) "Instagram giriş tələb edir — mini brauzerdə daxil olun, sonra yenidən Instagram düyməsinə basın ($ok market yükləndi)"
                    else "Instagram şəkilləri yükləndi: $ok market" + if (failed > 0) ", $failed uğursuz" else ""
                )
            } finally {
                InstaSaver.lock.unlock()
                (web.parent as? android.view.ViewGroup)?.removeView(web)
                web.destroy()
            }
        }
    }
}
