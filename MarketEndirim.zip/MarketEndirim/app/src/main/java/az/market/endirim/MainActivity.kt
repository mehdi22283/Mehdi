package az.market.endirim

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.view.View
import android.net.ConnectivityManager
import android.net.Network
import android.widget.Button
import androidx.activity.OnBackPressedCallback
import android.widget.EditText
import android.text.Editable
import android.text.TextWatcher
import android.text.style.StrikethroughSpan
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import kotlinx.coroutines.delay
import java.util.Locale
import okhttp3.OkHttpClient
import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.recyclerview.widget.DiffUtil
import androidx.viewpager2.widget.ViewPager2
import kotlinx.coroutines.CoroutineScope
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette
import coil.Coil
import coil.ImageLoader
import coil.decode.SvgDecoder
import coil.load
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

class MainActivity : AppCompatActivity() {

    private companion object {
        const val PER_MARKET = 4   // bağlı kateqoriyada hər marketdən göstərilən məhsul sayı
    }

    private class Src(val name: String, val fn: suspend () -> List<Catalog>)

    private val order = listOf("Bravo Market", "Araz Market", "Al Market", "Rahat Market", "Tamstore", "Bolmart")
    /** Jurnal mənbəyi olan marketlər (Bolmart-da yalnız başlıq + sosial linklər qalır). */
    private val withSource = setOf("Bravo Market", "Araz Market", "Al Market", "Rahat Market", "Tamstore")
    private val results = HashMap<String, MarketResult>()
    private lateinit var adapter: CatalogAdapter
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var status: TextView
    private var loadJob: Job? = null
    private val expanded = LinkedHashSet<String>()
    private val cached = HashMap<String, List<Catalog>>()
    private val offline = HashSet<String>()
    private var thumbTick = 0
    private lateinit var search: EditText
    private lateinit var scanStatus: TextView
    private var products: List<Product> = emptyList()
    private var query = ""
    private val expandedCats = HashSet<String>()
    private var scanJob: Job? = null
    private var scanning = false
    private var rescanNeeded = false
    private var searchFocused = false
    private var searchJob: Job? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brand.init(applicationContext)
        Insta.purgeSaved(applicationContext)   // köhnə offline Instagram şəkilləri silinir
        // şəkillər diskdə 30 gün saxlanır ki, offline də açılsın
        val http = OkHttpClient.Builder().addNetworkInterceptor { chain ->
            chain.proceed(chain.request()).newBuilder()
                .removeHeader("Pragma").header("Cache-Control", "public, max-age=2592000").build()
        }.build()
        Coil.setImageLoader(ImageLoader.Builder(this).okHttpClient(http).components { add(SvgDecoder.Factory()) }.build())
        cached.putAll(Store.load(applicationContext))
        setContentView(R.layout.activity_main)
        swipe = findViewById(R.id.swipe)
        status = findViewById(R.id.status)
        adapter = CatalogAdapter(
            scope = lifecycleScope,
            onToggle = { c ->
                if (!expanded.remove(c.urls[0])) expanded.add(c.urls[0])
                render()
            },
            onFull = { c ->
                startActivity(Intent(this, ViewerActivity::class.java).putExtra("catalog", c))
            },
            onProduct = { p -> openProduct(p) },
            onCat = { name ->
                if (!expandedCats.remove(name)) expandedCats.add(name)
                render()
            },
            onInsta = { startActivity(Intent(this, InstaBrowserActivity::class.java)) },
            onAll = {
                val urls = results.values.flatMap { it.catalogs }.map { it.urls[0] }
                if (urls.isNotEmpty() && expanded.containsAll(urls)) expanded.clear() else expanded.addAll(urls)
                render()
            }
        )
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        swipe.setOnRefreshListener { load() }
        swipe.setProgressBackgroundColorSchemeColor(0xFF1A1A1A.toInt())
        swipe.setColorSchemeColors(0xFFE53935.toInt())
        // məhsul axtarışı: qutuya toxunanda jurnallar skan edilir
        products = ProductStore.load(applicationContext)
        search = findViewById(R.id.search)
        scanStatus = findViewById(R.id.scanStatus)
        search.setOnFocusChangeListener { _, has ->
            searchFocused = has
            render()
            list.post { list.scrollToPosition(0) }      // həmişə ən başdan göstər
            if (has) startScan()      // avtomatik skan alınmayıbsa (məs. internet yox idi) yenidən cəhd
        }
        // toxunuşdan əvvəl artıq açıq idisə, təkrar toxunuş axtarışı bağlayır
        var focusedBeforeTouch = false
        search.setOnTouchListener { _, ev ->
            if (ev.action == android.view.MotionEvent.ACTION_DOWN) focusedBeforeTouch = search.hasFocus()
            false
        }
        search.setOnClickListener { if (focusedBeforeTouch) closeSearch() else startScan() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (searchFocused) {
                    closeSearch()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                searchJob?.cancel()
                searchJob = lifecycleScope.launch {
                    delay(200)
                    render()
                }
            }
        })
        search.setOnEditorActionListener { v, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
                true
            } else false
        }
        // internet qayıdanda avtomatik yenilə
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        netCb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread { if (offline.isNotEmpty()) load() }
            }
        }
        try { cm.registerDefaultNetworkCallback(netCb!!) } catch (e: Exception) { netCb = null }
        // logolar bir dəfə yüklənib yaddaşa yazılır — sonra offline işləyir
        lifecycleScope.launch { Brand.logos.keys.forEach { Brand.ensureLogo(applicationContext, it) } }
        load()
    }

    /** Məhsul axtarışını bağlayır: klaviatura gizlənir, yalnız jurnallar görünür. */
    private fun closeSearch() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
        findViewById<View>(R.id.root).requestFocus()
    }

    override fun onDestroy() {
        netCb?.let { try { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } catch (e: Exception) {} }
        adapter.releaseAll()
        super.onDestroy()
    }

    private fun load() {
        loadJob?.cancel()
        results.clear()
        offline.clear()
        // əvvəlki nəticələr dərhal göstərilir, yenisi gələndə əvəz olunur
        for ((m, cats) in cached) if (cats.isNotEmpty()) results[m] = MarketResult(m, cats, null)
        render()
        swipe.isRefreshing = true
        status.text = if (Store.online(applicationContext)) "Jurnallar yenilənir…" else "Oflayn — son nəticələr göstərilir"
        loadJob = lifecycleScope.launch {
            val sources = listOf(
                Src("Bravo Market") { Sources.bravo() },
                Src("Araz Market") { Sources.araz() },
                Src("Al Market") { Sources.al() },
                Src("Rahat Market") { Sources.rahat() },
                Src("Tamstore") { Sources.tamstore() }
            )
            sources.map { s ->
                async {
                    val old = cached[s.name] ?: emptyList()
                    val r = try {
                        // tarixi əvvəlki nəticədən saxla (OCR təkrarlanmasın)
                        val fresh = s.fn().map { c ->
                            if (c.date != null) c else c.copy(date = old.firstOrNull { it.urls[0] == c.urls[0] }?.date)
                        }
                        cached[s.name] = fresh
                        offline.remove(s.name)
                        MarketResult(s.name, fresh, null)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        if (old.isNotEmpty()) {
                            offline.add(s.name)   // yeniləmək alınmadı — son nəticə qalır
                            MarketResult(s.name, old, null)
                        } else MarketResult(s.name, emptyList(), e.message ?: e.javaClass.simpleName)
                    }
                    results[s.name] = r
                    persist()
                    render()
                }
            }.awaitAll()
            swipe.isRefreshing = false
            if (offline.isNotEmpty()) status.text = "Oflayn — son yadda saxlanan nəticələr göstərilir"
            launch { fillBravoDate() }
            downloadPdfs()
            startScan()    // jurnallar hazır — məhsulları avtomatik skan et (yeni/dəyişən jurnallar üçün)
        }
    }

    /** Tətbiqə girəndə bütün PDF-ləri endirir; tarixi olmayanlar üçün OCR edir. */
    private suspend fun downloadPdfs() {
        val allPdfCats = results.values.flatMap { it.catalogs }.filter { it.kind == Kind.PDF }
        // müddəti bitmiş PDF-lər yüklənmir (əvvəl yüklənmişsə silinir)
        Downloader.setExpired(allPdfCats.filter { c -> c.date?.let { DateUtil.info(it).state == 4 } == true }.map { it.urls[0] })
        val pdfs = allPdfCats.map { it.urls[0] }.distinct().filter { !Downloader.isExpired(it) }
        if (pdfs.isEmpty()) {
            Downloader.cleanup(applicationContext, pdfs)
            status.text = ""
            return
        }
        var done = 0
        var failed = 0
        status.text = "PDF-lər yüklənir (0/${pdfs.size})"
        val sem = Semaphore(3)
        coroutineScope {
            pdfs.map { url ->
                async {
                    sem.withPermit {
                        try {
                            // eyni linkdə PDF dəyişibsə köhnəsi silinir, yenisi yüklənir və yenidən skan olunur
                            if (Store.online(applicationContext) && Downloader.refreshIfChanged(applicationContext, url)) onPdfChanged(url)
                            val f = Downloader.ensure(applicationContext, url)
                            fillDateByOcr(url, f)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            failed++
                        }
                    }
                    done++
                    status.text = "PDF-lər yüklənir ($done/${pdfs.size})"
                }
            }.awaitAll()
        }
        Downloader.cleanup(applicationContext, pdfs)
        Thumbs.cleanup(applicationContext, results.values.flatMap { it.catalogs }.map { it.urls[0] })
        status.text = if (offline.isNotEmpty()) "Oflayn — son yadda saxlanan nəticələr göstərilir"
        else "PDF-lər yükləndi" + if (failed > 0) " ($failed uğursuz)" else ""
    }

    private fun onPdfChanged(url: String) {
        products = ProductStore.all()
        val entry = results.entries.firstOrNull { e -> e.value.catalogs.any { it.urls[0] == url } }
        if (entry != null && entry.key == "Tamstore") {
            // Tamstore-un tarixi OCR ilə oxunur — köhnə tarix atılır
            results[entry.key] = entry.value.copy(catalogs = entry.value.catalogs.map { if (it.urls[0] == url) it.copy(date = null) else it })
        }
        thumbTick++
        render()
    }

    private suspend fun fillDateByOcr(url: String, f: java.io.File) {
        val entry = results.entries.firstOrNull { e -> e.value.catalogs.any { it.urls[0] == url && it.date == null } } ?: return
        val market = entry.key
        val d = Ocr.pdfDate(applicationContext, f)
        if (d != null && DateUtil.info(d).state == 4) Downloader.markExpired(applicationContext, url)   // OCR ilə tapılan tarix bitibsə fayl silinir
        val isTam = market == "Tamstore"
        if (d == null && !isTam) return
        val cur = results[market] ?: return
        results[market] = cur.copy(
            catalogs = if (d == null) cur.catalogs.filter { it.urls[0] != url }   // Tamstore: tarixi tapılmayanlar silinir
            else cur.catalogs.map { if (it.urls[0] == url) it.copy(date = d) else it }
        )
        persist()
        render()
    }

    /** Bravo: tarix slaydın içindədir; səhifəni gizli WebView-da açıb ekran görüntüsündən OCR ilə oxuyur. */
    private suspend fun fillBravoDate() {
        val r = results["Bravo Market"] ?: return
        val c = r.catalogs.firstOrNull { it.kind == Kind.WEB && (it.date == null || !Thumbs.exists(applicationContext, it.urls[0])) } ?: return
        val d = try {
            BravoDate.read(this, c.urls[0])
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        } ?: return
        val cur = results["Bravo Market"] ?: return
        results["Bravo Market"] = cur.copy(catalogs = cur.catalogs.map { if (it.urls[0] == c.urls[0]) it.copy(date = d) else it })
        persist()
        thumbTick++   // miniatür hazırdır — zolağı yenilə
        render()
    }

    /** Tarixlər də daxil olmaqla cari nəticələri diskə yazır. */
    private fun persist() {
        for ((m, r) in results) if (r.error == null && r.catalogs.isNotEmpty()) cached[m] = r.catalogs
        Store.save(applicationContext, cached)
    }

    /** Başlıqda göstəriləcək tarix: bitməyənlərdən ən gec bitəni (hamısı bitibsə ən son bitəni). */
    private fun headerDate(cats: List<Catalog>): String? {
        val dated = cats.mapNotNull { c -> c.date?.let { it to DateUtil.info(it) } }
        if (dated.isEmpty()) return null
        val pool = dated.filter { it.second.state != 4 }.ifEmpty { dated }
        return pool.maxByOrNull { it.second.endMs }?.first
    }

    private fun render() {
        val rows = ArrayList<Row>()
        rows.addAll(productRows())
        if (searchFocused) {          // axtarış açıqdırsa yalnız məhsul kateqoriyaları görünür
            adapter.submit(rows)
            return
        }
        val allUrls = results.values.flatMap { it.catalogs }.map { it.urls[0] }
        rows.add(
            Row(
                Row.TITLE, "", "Endirim jurnalları", null,
                if (allUrls.isEmpty()) null else if (expanded.containsAll(allUrls)) "Hamısını bağla" else "Hamısını aç",
                null
            )
        )
        for (name in order) {
            val r = results[name]
            val cats = r?.catalogs ?: emptyList()
            // market başlığı (logo + ad); tarix adın yanında: bir neçə jurnal olanda ən aktual olanın tarixi
            rows.add(Row(Row.HEADER, name, name, if (r != null && r.error == null) headerDate(cats) else null, null, null))
            when {
                name !in withSource -> Unit   // Bolmart: başlığın altında heç nə göstərilmir
                r == null -> rows.add(Row(Row.ITEM, name, "Yüklənir…", null, null, null))
                r.error != null -> rows.add(Row(Row.ITEM, name, "Yüklənmədi", null, r.error, null))
                cats.isEmpty() -> rows.add(Row(Row.ITEM, name, "Jurnal tapılmadı", null, null, null))
                else -> {
                    // yazı siyahısı əvəzinə miniatür zolağı
                    rows.add(
                        Row(
                            Row.STRIP, name, name, null, null, null,
                            catalogs = cats,
                            selected = cats.map { it.urls[0] }.filter { it in expanded }.toSet(),
                            tick = thumbTick
                        )
                    )
                    cats.forEach { c ->
                        if (c.urls[0] in expanded) rows.add(Row(Row.VIEWER, name, c.title, null, null, c))
                    }
                }
            }
        }
        adapter.submit(rows)
    }

    // ---------------- məhsul axtarışı və skan ----------------

    private fun setScan(text: String) {
        scanStatus.text = text
        scanStatus.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    /** Axtarış sözünə uyğun məhsullar: kateqoriya → market → məhsul. Yalnız qutuya toxunulanda göstərilir. */
    private fun productRows(): List<Row> {
        if (!searchFocused) return emptyList()
        val tokens = Categorizer.norm(query).split(Regex("\\s+")).filter { it.isNotEmpty() }
        val searching = tokens.isNotEmpty()
        val src = if (!searching) products else products.filter { p -> tokens.all { p.key.contains(it) || p.catKey.contains(it) } }
        if (src.isEmpty()) {
            val msg = when {
                searching && scanning -> "“${query.trim()}” hələ tapılmadı — skan davam edir…"
                searching -> "“${query.trim()}” tapılmadı"
                scanning -> "Məhsullar skan edilir…"
                else -> "Hələ məhsul yoxdur — jurnallar yükləndikdən sonra avtomatik skan olunacaq."
            }
            return listOf(Row(Row.HINT, "", msg, null, null, null))
        }
        val rows = ArrayList<Row>()
        val grouped = src.groupBy { it.cat }
        for (cat in Categorizer.ORDER) {
            val list = grouped[cat] ?: continue
            val open = searching || cat in expandedCats
            val byMarket = list.groupBy { it.market }
            val groups = ArrayList<MarketGroup>()
            var overflow = false
            for (m in order) {
                val ps = byMarket[m] ?: continue
                val sorted = if (searching) ps.sortedBy { it.price } else ps.sortedBy { it.display.lowercase(Locale.ROOT) }
                if (ps.size > PER_MARKET) overflow = true
                groups.add(MarketGroup(m, sorted.take(if (open) 100 else PER_MARKET), ps.size))
            }
            rows.add(Row(Row.PCAT, "", cat, null, null, null, cat = ProductCat(cat, groups, list.size, open, !searching && overflow)))
        }
        return rows
    }

    /** Məhsulun tapıldığı jurnalı həmin səhifədə açır. */
    private fun openProduct(p: Product) {
        val c = results.values.flatMap { it.catalogs }.firstOrNull { it.urls[0] == p.catalogUrl } ?: return
        startActivity(
            Intent(this, ViewerActivity::class.java)
                .putExtra("catalog", c)
                .putExtra("page", p.page - 1)
                .putExtra("product", p.display)
        )
    }

    /** Hələ skan edilməmiş və ya dəyişmiş jurnalları OCR ilə oxuyur (nəticələr yadda qalır). */
    private fun startScan() {
        if (scanning) {
            rescanNeeded = true
            return
        }
        val cats = results.values.flatMap { it.catalogs }.distinctBy { it.urls[0] }
        if (cats.isEmpty()) return
        val done = ProductStore.scannedUrls()
        val todo = cats.filter { c ->
            val u = c.urls[0]
            !(c.kind == Kind.PDF && Downloader.isExpired(u)) &&
            u !in done || ProductScanner.sigFor(applicationContext, c).let { it != null && it != ProductStore.sigOf(u) }
        }
        if (todo.isEmpty()) {
            setScan("")
            return
        }
        scanning = true
        scanJob = lifecycleScope.launch {
            var failed = 0
            try {
                render()
                for ((i, c) in todo.withIndex()) {
                    val tag = "${c.market} (${i + 1}/${todo.size})"
                    setScan("Məhsullar skan edilir: $tag")
                    try {
                        val list = ProductScanner.scan(this@MainActivity, c) { p, n ->
                            setScan("Məhsullar skan edilir: $tag · səhifə $p" + if (n > 0) "/$n" else "")
                        }
                        if (c.kind == Kind.WEB && list.isEmpty()) {
                            failed++    // flipbook oxunmadı — növbəti dəfə yenidən cəhd olunsun
                        } else {
                            ProductStore.put(applicationContext, c.urls[0], c.market, list, ProductScanner.sigFor(applicationContext, c))
                            products = ProductStore.all()
                            render()
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        failed++
                    }
                }
                ProductStore.cleanup(applicationContext, results.values.flatMap { it.catalogs }.map { it.urls[0] }.toSet())
                products = ProductStore.all()
                setScan(if (failed > 0) "Skan: $failed jurnal oxunmadı" else "")
            } finally {
                scanning = false
                render()
            }
            if (rescanNeeded) {
                rescanNeeded = false
                startScan()
            }
        }
    }
}

class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
    val card: com.google.android.material.card.MaterialCardView = v.findViewById(R.id.headerCard)
    val logo: android.widget.ImageView = v.findViewById(R.id.logo)
    val letter: TextView = v.findViewById(R.id.logoLetter)
    val name: TextView = v.findViewById(R.id.hName)
    val date: TextView = v.findViewById(R.id.hDate)
    val socials: android.widget.LinearLayout = v.findViewById(R.id.socials)
    var boundMarket: String = ""
}

class ItemVH(v: View) : RecyclerView.ViewHolder(v) {
    val title: TextView = v.findViewById(R.id.tvTitle)
    val sub: TextView = v.findViewById(R.id.tvSub)
    val dateRow: View = v.findViewById(R.id.dateRow)
    val date: TextView = v.findViewById(R.id.tvDate)
    val status: TextView = v.findViewById(R.id.tvStatus)
}

/** Başlığın altında açılan slayd: şəkil / PDF səhifələri / veb-jurnal. */
class ViewerVH(v: View) : RecyclerView.ViewHolder(v) {
    val box: View = v.findViewById(R.id.viewerBox)
    val pager: ViewPager2 = v.findViewById(R.id.vPager)
    val web: WebView = v.findViewById(R.id.vWeb)
    val progress: ProgressBar = v.findViewById(R.id.vProgress)
    val counter: TextView = v.findViewById(R.id.vCounter)
    val full: TextView = v.findViewById(R.id.vFull)
    var pdf: PdfAdapter? = null
    var job: Job? = null
    var pageCb: ViewPager2.OnPageChangeCallback? = null

    fun release() {
        job?.cancel()
        job = null
        pageCb?.let { pager.unregisterOnPageChangeCallback(it) }
        pageCb = null
        pager.adapter = null
        pdf?.close()
        pdf = null
        web.stopLoading()
        web.loadUrl("about:blank")
        web.visibility = View.GONE
        pager.visibility = View.VISIBLE
        progress.visibility = View.GONE
    }
}

class ProductCatVH(v: View) : RecyclerView.ViewHolder(v) {
    val title: TextView = v.findViewById(R.id.pcTitle)
    val list: android.widget.LinearLayout = v.findViewById(R.id.pcList)
    val more: TextView = v.findViewById(R.id.pcMore)
}

class HintVH(v: View) : RecyclerView.ViewHolder(v) {
    val text: TextView = v.findViewById(R.id.hintText)
}

class TitleVH(v: View) : RecyclerView.ViewHolder(v) {
    val insta: Button = v.findViewById(R.id.btnInsta)
    val all: Button = v.findViewById(R.id.btnAll)
}

class StripVH(v: View) : RecyclerView.ViewHolder(v) {
    val list: RecyclerView = v.findViewById(R.id.thumbs)
    lateinit var adapter: ThumbAdapter
}

class ThumbVH(v: View) : RecyclerView.ViewHolder(v) {
    val card: com.google.android.material.card.MaterialCardView = v.findViewById(R.id.thumbCard)
    val img: android.widget.ImageView = v.findViewById(R.id.thumbImg)
    val badge: View = v.findViewById(R.id.badge)
    val date: TextView = v.findViewById(R.id.bDate)
    val status: TextView = v.findViewById(R.id.bStatus)
    var job: Job? = null
    var boundUrl: String = ""
}

/** Bir marketin jurnallarının miniatürləri (üfüqi zolaq). */
class ThumbAdapter(
    private val scope: CoroutineScope,
    private val onClick: (Catalog) -> Unit
) : RecyclerView.Adapter<ThumbVH>() {
    private var items: List<Catalog> = emptyList()
    private var selected: Set<String> = emptySet()

    fun submit(list: List<Catalog>, sel: Set<String>) {
        items = list
        selected = sel
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ThumbVH(LayoutInflater.from(parent.context).inflate(R.layout.item_thumb, parent, false))

    override fun onViewRecycled(holder: ThumbVH) {
        holder.job?.cancel()
        holder.job = null
    }

    override fun onBindViewHolder(h: ThumbVH, position: Int) {
        val c = items[position]
        val ctx = h.itemView.context
        val dens = ctx.resources.displayMetrics.density
        h.job?.cancel()
        h.boundUrl = c.urls[0]
        val sel = c.urls[0] in selected
        h.card.strokeColor = if (sel) ctx.getColor(R.color.accent) else ctx.getColor(R.color.amoled_stroke)
        h.card.strokeWidth = ((if (sel) 3 else 1) * dens).toInt()
        h.itemView.setOnClickListener { onClick(c) }

        // tarix nişanı: tarix + rəngli status
        val d = c.date
        if (d != null) {
            val info = DateUtil.info(d)
            h.badge.visibility = View.VISIBLE
            h.date.text = info.label
            h.status.text = info.status ?: ""
            h.status.setTextColor(DateUtil.stateColor(info.state))
            h.status.visibility = if (info.status == null) View.GONE else View.VISIBLE
        } else {
            h.badge.visibility = View.GONE
        }

        // miniatür
        h.img.scaleType = android.widget.ImageView.ScaleType.CENTER
        h.img.setImageResource(R.drawable.ic_catalog)
        fun show(src: Any) {
            h.img.load(src) {
                crossfade(true)
                listener(onSuccess = { _, _ -> h.img.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP })
            }
        }
        when (c.kind) {
            Kind.IMAGES -> show(c.urls[0])
            else -> h.job = scope.launch {
                val f = Thumbs.get(ctx.applicationContext, c)
                if (f != null && h.boundUrl == c.urls[0]) show(f)
            }
        }
    }
}

class CatalogAdapter(
    private val scope: CoroutineScope,
    private val onToggle: (Catalog) -> Unit,
    private val onFull: (Catalog) -> Unit,
    private val onProduct: (Product) -> Unit,
    private val onCat: (String) -> Unit,
    private val onInsta: () -> Unit,
    private val onAll: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var rows: List<Row> = emptyList()
    private val viewers = HashSet<ViewerVH>()

    private fun key(r: Row) = when (r.type) {
        Row.HEADER -> "h|" + r.market
        Row.STRIP -> "s|" + r.market
        Row.ITEM -> "i|" + r.market + "|" + (r.catalog?.urls?.get(0) ?: r.title)
        Row.PCAT -> "pc|" + r.title
        Row.HINT -> "ph"
        Row.TITLE -> "t"
        else -> "v|" + r.market + "|" + (r.catalog?.urls?.get(0) ?: "")
    }

    fun submit(r: List<Row>) {
        val old = rows
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = r.size
            override fun areItemsTheSame(a: Int, b: Int) = key(old[a]) == key(r[b])
            // slayd sətri tarix dəyişəndə yenidən qurulmasın (səhifə sıfırlanmasın)
            override fun areContentsTheSame(a: Int, b: Int) =
                if (old[a].type == Row.VIEWER) true else old[a] == r[b]
        })
        rows = r
        diff.dispatchUpdatesTo(this)
    }

    fun releaseAll() {
        viewers.toList().forEach { it.release() }
        viewers.clear()
    }

    override fun getItemViewType(position: Int) = rows[position].type
    override fun getItemCount() = rows.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return when (viewType) {
            Row.HEADER -> HeaderVH(inf.inflate(R.layout.item_header, parent, false))
            Row.VIEWER -> ViewerVH(inf.inflate(R.layout.item_viewer, parent, false))
            Row.PCAT -> ProductCatVH(inf.inflate(R.layout.item_product_cat, parent, false))
            Row.HINT -> HintVH(inf.inflate(R.layout.item_hint, parent, false))
            Row.TITLE -> TitleVH(inf.inflate(R.layout.item_title, parent, false))
            Row.STRIP -> StripVH(inf.inflate(R.layout.item_strip, parent, false)).also { vh ->
                vh.list.layoutManager = LinearLayoutManager(parent.context, LinearLayoutManager.HORIZONTAL, false)
                vh.adapter = ThumbAdapter(scope, onToggle)
                vh.list.adapter = vh.adapter
            }
            else -> ItemVH(inf.inflate(R.layout.item_catalog, parent, false))
        }
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
        val row = rows[position]
        when (h) {
            is HeaderVH -> bindHeader(h, row)
            is ItemVH -> bindItem(h, row)
            is ViewerVH -> bindViewer(h, row)
            is StripVH -> h.adapter.submit(row.catalogs, row.selected)
            is ProductCatVH -> bindProductCat(h, row)
            is HintVH -> h.text.text = row.title
            is TitleVH -> {
                h.insta.setOnClickListener { onInsta() }
                h.all.setOnClickListener { onAll() }
                h.all.visibility = if (row.sub == null) View.GONE else View.VISIBLE
                h.all.text = row.sub ?: ""
            }
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        if (holder is ViewerVH) {
            holder.release()
            viewers.remove(holder)
        }
    }

    private fun dp(v: View, n: Int) = (n * v.resources.displayMetrics.density).toInt()

    private fun pill(v: View, bg: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(v, 20).toFloat()
            setColor(bg)
        }

    private fun fmtPrice(v: Double) = String.format(Locale.US, "%.2f", v)

    /** Kateqoriya kartı: market nişanı + hər məhsul üçün sətir (ad solda, qiymət sağda). Toxunuş → jurnalın səhifəsi. */
    private fun bindProductCat(h: ProductCatVH, row: Row) {
        val cat = row.cat ?: return
        val ctx = h.itemView.context
        val accent = ctx.getColor(R.color.accent)
        h.title.text = cat.name + "  ·  " + cat.total
        h.list.removeAllViews()
        val rip = android.util.TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, rip, true)
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        for (g in cat.groups) {
            val col = Brand.colorOf(g.market)
            val head = TextView(ctx).apply {
                text = g.market + "  ·  " + g.total
                textSize = 13f
                setTypeface(null, Typeface.BOLD)
                setTextColor(if (ColorUtils.calculateLuminance(col) > 0.5) Color.BLACK else Color.WHITE)
                background = pill(this, col)
                setPadding(dp(this, 12), dp(this, 4), dp(this, 12), dp(this, 4))
            }
            h.list.addView(head, android.widget.LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(h.itemView, 10); bottomMargin = dp(h.itemView, 2) })

            for (p in g.items) {
                val line = android.widget.LinearLayout(ctx).apply {
                    orientation = android.widget.LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    isClickable = true
                    isFocusable = true
                    if (rip.resourceId != 0) background = ctx.getDrawable(rip.resourceId)
                    setPadding(dp(this, 2), dp(this, 9), dp(this, 2), dp(this, 9))
                    setOnClickListener { onProduct(p) }
                }
                val name = TextView(ctx).apply {
                    text = p.display
                    textSize = 15f
                    setTextColor(Color.WHITE)
                }
                line.addView(name, android.widget.LinearLayout.LayoutParams(0, wrap, 1f))
                val box = android.widget.LinearLayout(ctx).apply {
                    orientation = android.widget.LinearLayout.VERTICAL
                    gravity = android.view.Gravity.END
                }
                box.addView(TextView(ctx).apply {
                    text = fmtPrice(p.price) + " ₼"
                    textSize = 16f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(0xFF4CAF50.toInt())          // yeni qiymət — yaşıl
                })
                p.oldPrice?.let { o ->
                    box.addView(TextView(ctx).apply {
                        text = SpannableStringBuilder(fmtPrice(o) + " ₼").also { it.setSpan(StrikethroughSpan(), 0, it.length, 0) }
                        textSize = 13f
                        setTextColor(0xFFFF5252.toInt())          // köhnə qiymət — qırmızı, üstündən xətt
                    })
                }
                line.addView(box, android.widget.LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(h.itemView, 12) })
                h.list.addView(line, android.widget.LinearLayout.LayoutParams(match, wrap))
                h.list.addView(View(ctx).apply { setBackgroundColor(0xFF1F1F1F.toInt()) }, android.widget.LinearLayout.LayoutParams(match, 1))
            }
        }
        h.more.visibility = if (cat.canToggle) View.VISIBLE else View.GONE
        h.more.text = if (cat.expanded) "Daha az göstər" else "Hamısını göstər (${cat.total})"
        h.more.setOnClickListener { onCat(cat.name) }
        h.itemView.setOnClickListener(null)
        h.itemView.isClickable = false
    }

    private fun bindItem(h: ItemVH, row: Row) {
        val sb = SpannableStringBuilder(row.title)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, 0)
        h.title.text = sb
        val d = row.date
        if (d != null) {
            // oxunaqlı tarix "həbi" + rəngli status (aktiv / bitir / başlayır / bitib)
            val info = DateUtil.info(d)
            val col = DateUtil.stateColor(info.state)
            h.dateRow.visibility = View.VISIBLE
            h.date.text = "\uD83D\uDCC5  " + info.label
            h.date.setTextColor(col)
            h.date.background = pill(h.date, ColorUtils.setAlphaComponent(col, 0x2A))
            h.status.text = info.status ?: ""
            h.status.setTextColor(col)
            h.status.visibility = if (info.status == null) View.GONE else View.VISIBLE
        } else {
            h.dateRow.visibility = View.GONE
        }
        h.sub.text = row.sub ?: ""
        h.sub.visibility = if (row.sub == null) View.GONE else View.VISIBLE
        val c = row.catalog
        h.itemView.setOnClickListener { if (c != null) onToggle(c) }
        h.itemView.isClickable = c != null
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun bindViewer(h: ViewerVH, row: Row) {
        val c = row.catalog ?: return
        h.release()
        viewers.add(h)
        val ctx = h.itemView.context
        h.box.layoutParams = h.box.layoutParams.also {
            it.height = (ctx.resources.displayMetrics.heightPixels * 0.72f).toInt()
        }
        h.full.setOnClickListener { onFull(c) }

        fun setPages(a: RecyclerView.Adapter<*>) {
            h.pager.adapter = a
            h.counter.text = "1/${a.itemCount}"
            val cb = object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    h.counter.text = "${position + 1}/${a.itemCount}"
                }
            }
            h.pageCb = cb
            h.pager.registerOnPageChangeCallback(cb)
        }

        when (c.kind) {
            Kind.IMAGES -> {
                h.web.visibility = View.GONE
                setPages(ImageAdapter(c.urls))
            }
            Kind.WEB -> {
                h.pager.visibility = View.GONE
                h.counter.text = ""
                h.web.visibility = View.VISIBLE
                h.web.settings.javaScriptEnabled = true
                h.web.settings.domStorageEnabled = true
                h.web.settings.cacheMode =
                    if (Store.online(ctx)) WebSettings.LOAD_DEFAULT else WebSettings.LOAD_CACHE_ELSE_NETWORK
                h.web.webViewClient = WebViewClient()
                // flipbook-un üfüqi sürüşdürməsi siyahı tərəfindən kəsilməsin
                h.web.setOnTouchListener { v, _ ->
                    v.parent.requestDisallowInterceptTouchEvent(true)
                    false
                }
                h.web.loadUrl(c.urls[0])
            }
            Kind.PDF -> {
                h.web.visibility = View.GONE
                h.counter.text = ""
                h.progress.visibility = View.VISIBLE
                h.job = scope.launch {
                    try {
                        val f = Downloader.ensure(ctx.applicationContext, c.urls[0])
                        val w = (ctx.resources.displayMetrics.widthPixels * 1.5f).toInt()
                        val a = PdfAdapter(f, w, scope)
                        h.pdf = a
                        setPages(a)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        h.counter.text = if (Downloader.isExpired(c.urls[0])) "Müddəti bitib" else "PDF açılmadı"
                    } finally {
                        h.progress.visibility = View.GONE
                    }
                }
            }
        }
    }

    private fun bindHeader(h: HeaderVH, row: Row) {
        val ctx = h.itemView.context
        val market = row.market
        h.boundMarket = market
        h.letter.text = market.take(1)
        h.letter.visibility = View.VISIBLE
        h.name.text = market
        applyColor(h, Brand.colorOf(market))
        bindHeaderDate(h, row.date)
        bindSocials(h, market)

        // 1) tətbiqin içindəki logo, 2) yaddaşdakı (offline) logo, 3) şəbəkə (ilk dəfə)
        val res = Brand.bundledRes(ctx, market)
        val cached = if (res == 0) Brand.cachedFile(ctx, market) else null
        val src: Any = when {
            res != 0 -> res
            cached != null -> cached
            else -> Brand.logos[market] ?: return
        }
        h.logo.load(src) {
            allowHardware(false)
            listener(onSuccess = { _, result ->
                h.letter.visibility = View.GONE
                if (!Brand.hasColor(market)) {
                    val bmp = (result.drawable as? BitmapDrawable)?.bitmap
                    if (bmp != null) {
                        Palette.from(bmp).generate { p ->
                            val c = Brand.pick(p)
                            if (c != null) {
                                Brand.saveColor(market, c)
                                if (h.boundMarket == market) applyColor(h, c)
                            }
                        }
                    }
                }
            })
        }
    }

    /** Başlıqdakı tarix: ağ həb içində iri tarix + rəngli status. */
    private fun bindHeaderDate(h: HeaderVH, raw: String?) {
        if (raw == null) {
            h.date.visibility = View.GONE
            return
        }
        val info = DateUtil.info(raw)
        val sb = SpannableStringBuilder(info.label)
        sb.setSpan(ForegroundColorSpan(0xFF212121.toInt()), 0, sb.length, 0)
        if (info.status != null) {
            val st = sb.length + 1
            sb.append("\n").append(info.status)
            sb.setSpan(ForegroundColorSpan(DateUtil.stateColor(info.state)), st, sb.length, 0)
            sb.setSpan(android.text.style.RelativeSizeSpan(0.85f), st, sb.length, 0)
        }
        h.date.text = sb
        h.date.background = pill(h.date, Color.WHITE)
        h.date.visibility = View.VISIBLE
    }

    /** Adın altında yalnız Instagram və WhatsApp loqoları. */
    private fun bindSocials(h: HeaderVH, market: String) {
        h.socials.removeAllViews()
        val soc = Brand.socials[market]
        if (soc == null) {
            h.socials.visibility = View.GONE
            return
        }
        h.socials.visibility = View.VISIBLE
        val size = dp(h.itemView, 32)
        val gap = dp(h.itemView, 8)
        fun add(icon: Int, desc: String, url: String, insta: Boolean) {
            val v = android.widget.ImageView(h.itemView.context).apply {
                setImageResource(icon)
                contentDescription = desc
                val pad = dp(this, 3)
                setPadding(pad, pad, pad, pad)
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(Color.WHITE)
                }
                layoutParams = android.widget.LinearLayout.LayoutParams(size, size).apply { marginEnd = gap }
                setOnClickListener {
                    if (insta) {
                        Insta.open(context, url)   // com.insta* tətbiqi ilə (əvvəlki qayda)
                    } else {
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Link açılmadı", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            h.socials.addView(v)
        }
        soc.instagram?.let { add(R.drawable.ic_instagram, "Instagram", "https://www.instagram.com/$it/", true) }
        soc.whatsapp?.let { add(R.drawable.ic_whatsapp, "WhatsApp", it, false) }
    }

    private fun applyColor(h: HeaderVH, color: Int) {
        h.card.setCardBackgroundColor(color)
        val fg = if (ColorUtils.calculateLuminance(color) > 0.5) Color.BLACK else Color.WHITE
        h.name.setTextColor(fg)
    }
}
