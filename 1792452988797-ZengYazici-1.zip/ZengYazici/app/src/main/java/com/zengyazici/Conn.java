package com.zengyazici;

import android.content.Context;
import android.content.SharedPreferences;
import io.github.muntashirakon.adb.AdbStream;

/**
 * Qoşulma ardıcıllığı:
 * 1) 127.0.0.1:5555 (lokal, Wi-Fi-dan asılı deyil)
 * 2) Wireless debugging (mDNS ilə cari port, sonra saxlanmış IP/port)
 * Wireless ilə qoşulandan sonra adbd-yə "tcpip:5555" göndərilir və tətbiq lokal rejimə keçir.
 */
public class Conn {
    public static volatile String mode = "";

    private static void sleep(long ms) { try { Thread.sleep(ms); } catch (Exception e) { } }

    private static boolean local(AdbMgr m) {
        try { m.connect("127.0.0.1", 5555); } catch (Throwable e) { RecService.log("lokal 5555: " + e); }
        boolean ok = m.isConnected();
        if (ok) mode = "lokal";
        return ok;
    }

    /** Wireless qoşulu olanda adbd-ni TCP 5555 rejiminə keçirib lokala qoşulur. */
    private static void upgrade(AdbMgr m) {
        try {
            AdbStream s = m.openStream("tcpip:5555");
            sleep(500);
            try { s.close(); } catch (Throwable e) { }
        } catch (Throwable e) {
            RecService.log("tcpip: " + e);
        }
        sleep(3000);
        try { m.disconnect(); } catch (Throwable e) { }
        for (int i = 0; i < 3; i++) {
            if (local(m)) { RecService.log("Lokal ADB aktiv (127.0.0.1:5555) — Wi-Fi lazım deyil"); return; }
            sleep(1500);
        }
        RecService.log("Lokal rejim alınmadı; Wireless istifadə olunacaq");
    }

    public static synchronized void ensure(Context c) throws Exception {
        AdbMgr m = AdbMgr.get(c);
        if (m.isConnected()) return;
        SharedPreferences p = c.getSharedPreferences("cfg", 0);

        if (local(m)) return;

        String[] f = Nsd.findOnce(c, "_adb-tls-connect._tcp", 4000);
        if (f != null) {
            int fp = Integer.parseInt(f[1]);
            String h0 = f[0].contains(":") ? "127.0.0.1" : f[0];
            for (String host : new String[]{h0, "127.0.0.1"}) {
                try { m.connect(host, fp); } catch (Throwable e) { RecService.log("connect " + host + ":" + fp + " — " + e); }
                if (m.isConnected()) {
                    SharedPreferences.Editor ed = p.edit().putInt("port", fp);
                    if (host.contains(".") && !host.equals("127.0.0.1")) ed.putString("ip", host);
                    ed.apply();
                    mode = "wireless";
                    upgrade(m);
                    if (!m.isConnected()) reconnectWireless(c, m, host, fp);
                    if (m.isConnected()) return;
                    throw new Exception("ADB qoşulmadı");
                }
            }
        } else {
            RecService.log("mDNS: Wireless debugging xidməti tapılmadı");
        }

        String ip = p.getString("ip", "");
        int port = p.getInt("port", 0);
        if (!ip.isEmpty() && port > 0) {
            try { m.connect(ip, port); } catch (Throwable e) { RecService.log("connect " + ip + ":" + port + " — " + e); }
            if (m.isConnected()) {
                mode = "wireless";
                upgrade(m);
                if (!m.isConnected()) reconnectWireless(c, m, ip, port);
                if (m.isConnected()) return;
            }
        }
        throw new Exception("ADB qoşulmadı. Wi-Fi qoşulu, Wireless debugging açıq və cütləşmə edilmiş olmalıdır (lokal rejim üçün bir dəfə).");
    }

    private static void reconnectWireless(Context c, AdbMgr m, String host, int port) {
        String[] f = Nsd.findOnce(c, "_adb-tls-connect._tcp", 3000);
        try {
            if (f != null) m.connect(host, Integer.parseInt(f[1]));
            else m.connect(host, port);
            if (m.isConnected()) mode = "wireless";
        } catch (Throwable e) {
            RecService.log("yenidən wireless: " + e);
        }
    }
}
