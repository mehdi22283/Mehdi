package az.market.endirim

import java.util.Locale

/**
 * OCR-dan gələn məhsul adlarını düzəldir:
 *  1) kirill ↔ latın "oxşar" hərflərin qarışması (məs. latın "o" kirill sözün içində) — söz üzrə vahid əlifbaya salınır;
 *  2) "ə" hərfinin "9", "ә", "э" kimi oxunması; sözün içindəki "0" → "o";
 *  3) BÜTÖV BÖYÜK HƏRFLİ adlar düzgün kiçildilir (İ/I Azərbaycan qaydası ilə);
 *  4) ən çox işlənən sözlərin ə, ı, ö, ü, ş, ç, ğ hərfləri itibsə bərpa olunur (sud → süd, cay → çay).
 */
object AzText {
    val AZ: Locale = Locale.forLanguageTag("az-AZ")

    private const val SPECIAL = "əƏıİöÖüÜşŞçÇğĞ"

    /** Kirill əlifbalı Azərbaycan hərfləri → latın. */
    private val PRE = mapOf(
        'ә' to 'ə', 'Ә' to 'Ə', 'ө' to 'ö', 'Ө' to 'Ö', 'ү' to 'ü', 'Ү' to 'Ü',
        'ғ' to 'ğ', 'Ғ' to 'Ğ', 'һ' to 'h', 'Һ' to 'H', 'ј' to 'j', 'Ј' to 'J', 'ҹ' to 'c', 'Ҹ' to 'C'
    )

    private val CYR2LAT = mapOf(
        'А' to 'A', 'а' to 'a', 'В' to 'B', 'Е' to 'E', 'е' to 'e', 'К' to 'K', 'к' to 'k', 'М' to 'M',
        'Н' to 'H', 'О' to 'O', 'о' to 'o', 'Р' to 'P', 'р' to 'p', 'С' to 'C', 'с' to 'c', 'Т' to 'T',
        'у' to 'y', 'Х' to 'X', 'х' to 'x', 'І' to 'I', 'і' to 'i', 'Ѕ' to 'S', 'ѕ' to 's', 'Э' to 'Ə', 'э' to 'ə'
    )

    private val LAT2CYR = mapOf(
        'A' to 'А', 'a' to 'а', 'B' to 'В', 'E' to 'Е', 'e' to 'е', 'K' to 'К', 'k' to 'к', 'M' to 'М',
        'H' to 'Н', 'O' to 'О', 'o' to 'о', 'P' to 'Р', 'p' to 'р', 'C' to 'С', 'c' to 'с', 'T' to 'Т',
        'y' to 'у', 'X' to 'Х', 'x' to 'х'
    )

    /** Düzgün yazılış (kiçik hərflə). Açar — Categorizer.norm(söz). */
    private val LEX: Map<String, String> by lazy {
        val words = listOf(
            "süd", "qatıq", "çörək", "çay", "qəhvə", "şəkər", "günəbaxan", "kərə", "yağ", "şokolad", "şirniyyat",
            "şirə", "çərəz", "fındıq", "düyü", "mərcimək", "sirkə", "ketçup", "mürəbbə", "qənd", "meyvə", "tərəvəz",
            "soğan", "sarımsaq", "kələm", "yerkökü", "bibər", "badımcan", "qarpız", "üzüm", "ərik", "alça", "portağal",
            "balıq", "qızılbalıq", "içki", "içəcək", "qazlı", "qazsız", "sərinləşdirici", "təmizlik", "şampun",
            "dəsmal", "kağız", "fırça", "uşaq", "körpə", "ərzaq", "ədəd", "şüşə", "çanta", "doğranmış", "qovrulmuş",
            "dondurulmuş", "bişmiş", "hazır", "təzə", "təbii", "yaşıl", "qırmızı", "sarı", "şirin", "acı", "qurudulmuş",
            "çiy", "qəlyan", "çəkməsi", "mətbəx", "bağça", "qoruyucu", "təbaşir", "ləzzət", "ləzzətli", "şəffaf",
            "çəhrayı", "göy", "göyərti", "gilas", "kərəviz", "mayonezli", "xörək", "yeməyi", "ətirli", "dəniz",
            "şorba", "çaxır", "şərab", "içmək", "süzmə", "südlü", "ördək", "hindquşu", "quş", "toyuq", "yumurta"
        )
        words.associateBy { Categorizer.norm(it) }
            .filter { (k, v) -> k != v }            // yalnız xüsusi hərfi olan sözlər
    }

    private val WORD = Regex("[\\p{L}\\p{N}]+")

    fun fix(name: String): String {
        var s = name
        if (s.none { it.isLowerCase() }) s = titleCase(s)
        return WORD.replace(s) { fixWord(it.value) }.replace(Regex("\\s+"), " ").trim()
    }

    /** BÜTÖV BÖYÜK HƏRFLİ mətn → "Coca Cola 0.5L", "Süd", "İsti". İ varsa Azərbaycan qaydası. */
    fun titleCase(s: String): String =
        s.split(' ').filter { it.isNotEmpty() }.joinToString(" ") { w ->
            if (w.any { it.isDigit() } || w.length <= 2) w
            else {
                val loc = if (w.any { it == 'İ' || it == 'ı' }) AZ else Locale.ROOT
                w.lowercase(loc).replaceFirstChar { c -> c.uppercase(loc) }
            }
        }

    private fun fixWord(w0: String): String {
        var w = w0.map { PRE[it] ?: it }.joinToString("")
        var cyr = 0
        var lat = 0
        for (c in w) if (c.isLetter()) {
            when (Character.UnicodeScript.of(c.code)) {
                Character.UnicodeScript.CYRILLIC -> cyr++
                Character.UnicodeScript.LATIN -> lat++
                else -> {}
            }
        }
        // bir sözdə iki əlifba — çoxluq qalır, oxşar hərflər çevrilir
        if (cyr > 0 && lat > 0) {
            w = if (cyr >= lat) w.map { LAT2CYR[it] ?: it }.joinToString("")
            else w.map { CYR2LAT[it] ?: it }.joinToString("")
            val lat2 = w.count { it.isLetter() && Character.UnicodeScript.of(it.code) == Character.UnicodeScript.LATIN }
            if (lat2 == 0) return w                       // tam kirill oldu
        } else if (cyr > 0) {
            return w                                      // təmiz rus sözü — toxunulmur
        }
        w = fixDigits(w)
        return fixLexicon(w)
    }

    /** Sözün içində tək "9" → ə, tək "0" → o ("S9RIN" → "SƏRIN", "K0LA" → "KOLA"). */
    private fun fixDigits(w: String): String {
        val letters = w.count { it.isLetter() }
        val digits = w.count { it.isDigit() }
        if (digits != 1 || letters < 3) return w
        val i = w.indexOfFirst { it.isDigit() }
        val prev = w.getOrNull(i - 1)?.takeIf { it.isLetter() }
        val next = w.getOrNull(i + 1)?.takeIf { it.isLetter() }
        val upper = (prev ?: next)?.isUpperCase() == true && (next ?: prev)?.isUpperCase() == true
        return when (w[i]) {
            '9' -> if (prev != null || next != null) w.replaceRange(i, i + 1, if (upper) "Ə" else "ə") else w
            '0' -> if (prev != null && next != null) w.replaceRange(i, i + 1, if (upper) "O" else "o") else w
            else -> w
        }
    }

    private fun fixLexicon(w: String): String {
        if (w.length < 3 || w.any { it in SPECIAL } || w.any { !it.isLetter() }) return w
        val good = LEX[Categorizer.norm(w)] ?: return w
        return when {
            w.none { it.isLowerCase() } -> good.uppercase(AZ)
            w[0].isUpperCase() -> good.replaceFirstChar { it.uppercase(AZ) }
            else -> good
        }
    }
}
