package az.market.endirim

import android.graphics.Bitmap
import android.graphics.Color

/**
 * Endirimli qiymət adətən rəngli fonda (qırmızı; Oba-da yaşıl; Rahat-da sarı) və ya qırmızı çərçivədə olur.
 * Yazı çox vaxt ağdır (Rahat-da sarı fonda qara). Bu obyekt:
 *  1) rəngli "qiymət nişanlarını" (dolu fonlu bloklar) şəkildə tapır;
 *  2) nişanın içindəki mətni OCR üçün yüksək kontrastlı (ağ fonda qara yazı) şəklə çevirir;
 *  3) qiymət sətrinin çərçivədə / nişanda olub-olmadığını bildirir.
 */
object Frame {
    const val RED = 1
    const val GREEN = 2
    const val YELLOW = 4

    /** Marketə görə nişan rəngləri: hamıda qırmızı; Oba — + yaşıl; Rahat — + sarı. */
    fun allowedFor(market: String): Int = when (market) {
        "Oba Market" -> RED or GREEN
        "Rahat Market" -> RED or YELLOW
        else -> RED
    }

    fun classOf(c: Int): Int {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        if (r >= 200 && g >= 170 && b <= 110 && r - b >= 100) return YELLOW
        if (r >= 140 && r - g >= 80 && r - b >= 70) return RED
        if (g >= 100 && g - r >= 40 && g - b >= 40) return GREEN
        return 0
    }

    class Badge(val l: Int, val t: Int, val r: Int, val b: Int, val cls: Int)

    fun inside(b: Badge, ln: OLine): Boolean {
        val cx = (ln.l + ln.r) / 2
        val cy = (ln.t + ln.b) / 2
        return cx in b.l..b.r && cy in b.t..b.b
    }

    fun inBadge(badges: List<Badge>, ln: OLine): Boolean = badges.any { inside(it, ln) }

    /** Dolu rəngli bloklar (qiymət nişanları): kobud şəbəkədə eyni rəngli sahələr birləşdirilir. */
    fun badges(bmp: Bitmap, allowed: Int): List<Badge> {
        return try {
            val w = bmp.width
            val h = bmp.height
            val step = maxOf(3, w / 220)
            val gw = w / step
            val gh = h / step
            if (gw < 8 || gh < 8) return emptyList()
            val cls = ByteArray(gw * gh)
            for (gy in 0 until gh) {
                val y = gy * step + step / 2
                for (gx in 0 until gw) {
                    val c = classOf(bmp.getPixel(gx * step + step / 2, y))
                    if ((c and allowed) != 0) cls[gy * gw + gx] = c.toByte()
                }
            }
            val seen = BooleanArray(gw * gh)
            val stack = IntArray(gw * gh)
            val out = ArrayList<Badge>()
            for (start in cls.indices) {
                if (cls[start].toInt() == 0 || seen[start]) continue
                val k = cls[start]
                var sp = 0
                stack[sp++] = start
                seen[start] = true
                var cnt = 0
                var minx = gw; var maxx = -1; var miny = gh; var maxy = -1
                while (sp > 0) {
                    val p = stack[--sp]
                    val px = p % gw
                    val py = p / gw
                    cnt++
                    if (px < minx) minx = px
                    if (px > maxx) maxx = px
                    if (py < miny) miny = py
                    if (py > maxy) maxy = py
                    for (dy in -1..1) for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
                        val nx = px + dx
                        val ny = py + dy
                        if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                        val q = ny * gw + nx
                        if (!seen[q] && cls[q] == k) {
                            seen[q] = true
                            stack[sp++] = q
                        }
                    }
                }
                val bw = (maxx - minx + 1) * step
                val bh = (maxy - miny + 1) * step
                val fill = cnt.toFloat() / ((maxx - minx + 1) * (maxy - miny + 1))
                if (bw < 0.04f * w || bh < 0.02f * w) continue       // çox kiçik
                if (bw > 0.5f * w || bh > 0.35f * w) continue        // fon / başlıq zolağı
                if (fill < 0.3f) continue                            // boş çərçivə — sətir üzrə yoxlanır
                out.add(Badge(minx * step, miny * step, (maxx + 1) * step, (maxy + 1) * step, k.toInt()))
            }
            out.sortedWith(compareBy({ it.t / (2 * step) }, { it.l })).take(40)
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** OCR üçün hazırlanmış nişan şəkli: nişan rəngi → ağ, qalan (yazı) → qara. */
    class Prepared(val bmp: Bitmap, private val x: Int, private val y: Int, private val k: Float, private val m: Int) {
        fun mapX(v: Int): Int = x + ((v - m) * k).toInt()
        fun mapY(v: Int): Int = y + ((v - m) * k).toInt()
    }

    fun prepare(bmp: Bitmap, b: Badge): Prepared? {
        return try {
            val x = b.l.coerceIn(0, bmp.width - 1)
            val y = b.t.coerceIn(0, bmp.height - 1)
            val w = minOf(b.r - b.l, bmp.width - x)
            val h = minOf(b.b - b.t, bmp.height - y)
            if (w < 8 || h < 8) return null
            val src = Bitmap.createBitmap(bmp, x, y, w, h)
            val scale = when {
                w > 420 -> 420f / w
                w < 200 -> 2f
                else -> 1f
            }
            val sw = (w * scale).toInt().coerceAtLeast(8)
            val sh = (h * scale).toInt().coerceAtLeast(8)
            val sc = if (sw == w && sh == h) src else Bitmap.createScaledBitmap(src, sw, sh, true)
            val px = IntArray(sw * sh)
            sc.getPixels(px, 0, sw, 0, 0, sw, sh)
            if (sc !== src) sc.recycle()
            src.recycle()
            val m = 12
            val rw = sw + 2 * m
            val rh = sh + 2 * m
            val out = IntArray(rw * rh) { Color.WHITE }
            for (yy in 0 until sh) {
                var lo = -1
                var hi = -1
                for (xx in 0 until sw) {
                    if ((classOf(px[yy * sw + xx]) and b.cls) != 0) {
                        if (lo < 0) lo = xx
                        hi = xx
                    }
                }
                if (lo < 0) continue
                for (xx in lo..hi) {
                    val isBadge = (classOf(px[yy * sw + xx]) and b.cls) != 0
                    out[(yy + m) * rw + (xx + m)] = if (isBadge) Color.WHITE else Color.BLACK
                }
            }
            val res = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888)
            res.setPixels(out, 0, rw, 0, 0, rw, rh)
            Prepared(res, x, y, w.toFloat() / sw, m)
        } catch (e: Exception) {
            null
        }
    }

    // ---------- nişansız, yalnız çərçivə (qırmızı xətt) ----------

    private fun hit(bmp: Bitmap, x0: Int, y0: Int, dx: Int, dy: Int, reach: Int, allowed: Int): Boolean {
        val w = bmp.width
        val h = bmp.height
        var run = 0
        for (s in 3..reach) {
            val x = x0 + dx * s
            val y = y0 + dy * s
            if (x < 0 || y < 0 || x >= w || y >= h) return false
            if ((classOf(bmp.getPixel(x, y)) and allowed) != 0) {
                run++
                if (run >= 2) return true
            } else run = 0
        }
        return false
    }

    /** Qiymət sətrinin 4 tərəfindən üçündə rəngli xətt/fon varsa — çərçivəlidir. */
    fun isFramed(bmp: Bitmap, ln: OLine, allowed: Int): Boolean {
        return try {
            val reach = maxOf(ln.h * 2.5f, bmp.width * 0.045f).toInt().coerceIn(24, maxOf(24, (bmp.width * 0.12f).toInt()))
            val fr = floatArrayOf(0.25f, 0.5f, 0.75f)
            var left = 0; var right = 0; var top = 0; var bottom = 0
            for (f in fr) {
                val y = (ln.t + ln.h * f).toInt().coerceIn(0, bmp.height - 1)
                if (hit(bmp, ln.l.coerceIn(0, bmp.width - 1), y, -1, 0, reach, allowed)) left++
                if (hit(bmp, ln.r.coerceIn(0, bmp.width - 1), y, 1, 0, reach, allowed)) right++
                val x = (ln.l + ln.w * f).toInt().coerceIn(0, bmp.width - 1)
                if (hit(bmp, x, ln.t.coerceIn(0, bmp.height - 1), 0, -1, reach, allowed)) top++
                if (hit(bmp, x, ln.b.coerceIn(0, bmp.height - 1), 0, 1, reach, allowed)) bottom++
            }
            var sides = 0
            if (left >= 2) sides++
            if (right >= 2) sides++
            if (top >= 2) sides++
            if (bottom >= 2) sides++
            sides >= 3
        } catch (e: Exception) {
            false
        }
    }

    // ---------- üstündən xətt çəkilmiş (köhnə, endirimsiz) qiymət ----------

    /**
     * Qiymət sətrinin üstündən xətt çəkilibmi: sətrin ortasında üfüqi və ya iki diaqonal xətt boyunca
     * piksellərin ≥90%-i fon rəngindən fərqlidirsə (adi rəqəmlərdə belə xətt olmur) — köhnə qiymətdir.
     */
    fun isStruck(bmp: Bitmap, ln: OLine): Boolean {
        return try {
            val bw = bmp.width
            val bh = bmp.height
            val x0 = ln.l.coerceIn(0, bw - 1)
            val x1 = ln.r.coerceIn(0, bw - 1)
            val y0 = ln.t.coerceIn(0, bh - 1)
            val y1 = ln.b.coerceIn(0, bh - 1)
            val w = x1 - x0
            val h = y1 - y0
            if (w < 16 || h < 10) return false
            val mx = (x0 + x1) / 2
            val pts = listOf(x0 to y0, x1 to y0, x0 to y1, x1 to y1, mx to y0, mx to y1)
            var sr = 0; var sg = 0; var sb = 0
            for ((px, py) in pts) {
                val c = bmp.getPixel(px, py)
                sr += (c shr 16) and 0xFF; sg += (c shr 8) and 0xFF; sb += c and 0xFF
            }
            val br = sr / pts.size; val bg = sg / pts.size; val bb = sb / pts.size
            fun ink(x: Int, y: Int): Boolean {
                if (x < 0 || y < 0 || x >= bw || y >= bh) return false
                val c = bmp.getPixel(x, y)
                return Math.abs(((c shr 16) and 0xFF) - br) + Math.abs(((c shr 8) and 0xFF) - bg) + Math.abs((c and 0xFF) - bb) > 150
            }
            fun inkNear(x: Int, y: Int) = ink(x, y) || ink(x, y - 1) || ink(x, y + 1)
            val stepX = maxOf(1, w / 80)
            // üfüqi xətt: hündürlüyün 30%..70% aralığında
            for (k in 3..7) {
                val y = y0 + h * k / 10
                var n = 0; var hit = 0; var x = x0
                while (x <= x1) { n++; if (inkNear(x, y)) hit++; x += stepX }
                if (hit >= 0.9 * n) return true
            }
            // diaqonal xətt (iki istiqamət, bir neçə meyl)
            for (d in floatArrayOf(0f, 0.15f, 0.3f)) {
                for (dir in 0..1) {
                    var n = 0; var hit = 0; var x = x0
                    while (x <= x1) {
                        val t = (x - x0).toFloat() / w
                        val span = h * (1f - 2f * d)
                        val yy = if (dir == 0) (y1 - d * h - t * span).toInt() else (y0 + d * h + t * span).toInt()
                        n++; if (inkNear(x, yy)) hit++; x += stepX
                    }
                    if (hit >= 0.9 * n) return true
                }
            }
            false
        } catch (e: Exception) {
            false
        }
    }
}
