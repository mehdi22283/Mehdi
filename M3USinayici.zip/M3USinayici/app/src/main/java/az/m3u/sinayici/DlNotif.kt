package az.m3u.sinayici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/** Bütün endirmələr üçün vahid bildiriş: ad + faiz + MB, bitəndə ✅, xəta olsa ❌. */
class DlNotif(private val ctx: Context, private val name: String, private var total: Long) {
    companion object {
        private const val CH = "zip_dl"
        private val seq = AtomicInteger(0)
    }

    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val id = 5000 + seq.incrementAndGet() % 90000
    private var done = 0L
    private var lastT = 0L
    private var lastPct = -1

    init {
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Endirmələr", NotificationManager.IMPORTANCE_LOW))
        DlLog.active[id] = "$name — 0%"
        post(base("Başlayır...").setOngoing(true).setProgress(0, 0, true))
    }

    @Suppress("DEPRECATION")
    private fun base(text: String): Notification.Builder {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH) else Notification.Builder(ctx)
        val pi = PendingIntent.getActivity(ctx, id, Intent("android.intent.action.VIEW_DOWNLOADS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return b.setSmallIcon(R.drawable.ic_notif).setContentTitle(name).setContentText(text).setContentIntent(pi).setOnlyAlertOnce(true)
    }

    private fun post(b: Notification.Builder) { try { nm.notify(id, b.build()) } catch (_: Exception) {} }

    fun setTotal(t: Long) { total = t }

    /** Yazılan bayt sayını artırır; bildiriş ~0.4 san-də bir yenilənir. */
    @Synchronized fun add(n: Long) {
        done += n
        val now = System.currentTimeMillis()
        val pct = if (total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else -1
        if (now - lastT < 400 || pct == lastPct) return
        lastT = now; lastPct = pct
        val txt = if (pct >= 0) String.format(Locale.US, "%d%% — %.1f / %.1f MB", pct, done / 1048576.0, total / 1048576.0)
                  else String.format(Locale.US, "%.1f MB", done / 1048576.0)
        DlLog.active[id] = "$name — " + (if (pct >= 0) "$pct%" else String.format(Locale.US, "%.1f MB", done / 1048576.0))
        val b = base(txt).setOngoing(true)
        if (pct >= 0) b.setProgress(100, pct, false) else b.setProgress(0, 0, true)
        post(b)
    }

    /** apk verilibsə: bildirişə (və "📲 Quraşdır" düyməsinə) toxunanda sistem quraşdırıcısı açılır. */
    @Suppress("DEPRECATION")
    fun finish(text: String = name, apk: android.net.Uri? = null) {
        DlLog.active.remove(id)
        val b = base(text).setContentTitle("✅ Endirildi — 100%").setAutoCancel(true).setOngoing(false).setProgress(0, 0, false)
        if (apk != null) {
            val inst = Intent(Intent.ACTION_VIEW).setDataAndType(apk, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(ctx, id + 100000, inst, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.setContentTitle("✅ Endirildi — quraşdırmaq üçün toxunun").setContentIntent(pi)
            b.addAction(Notification.Action.Builder(null, "📲 Quraşdır", pi).build())
        }
        post(b)
    }

    fun fail(msg: String?) {
        DlLog.active.remove(id)
        post(base(msg ?: "Naməlum xəta").setContentTitle("❌ Endirmə xətası: $name").setAutoCancel(true).setOngoing(false).setProgress(0, 0, false))
    }
}
