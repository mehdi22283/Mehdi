package az.market.endirim

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.github.chrisbanes.photoview.PhotoView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class PageVH(val img: PhotoView) : RecyclerView.ViewHolder(img) {
    var job: Job? = null
}

private fun newPhotoView(parent: ViewGroup) = PhotoView(parent.context).apply {
    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    scaleType = ImageView.ScaleType.FIT_CENTER
}

class ImageAdapter(private val urls: List<String>) : RecyclerView.Adapter<PageVH>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PageVH(newPhotoView(parent))
    override fun getItemCount() = urls.size
    override fun onBindViewHolder(holder: PageVH, position: Int) {
        holder.img.load(urls[position]) { crossfade(true) }
    }
}

/** PDF səhifələrini slayd kimi göstərir (PdfRenderer, səhifə-səhifə). */
class PdfAdapter(file: File, private val widthPx: Int, private val scope: CoroutineScope) :
    RecyclerView.Adapter<PageVH>() {

    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val cache = LruCache<Int, Bitmap>(3)
    private var closed = false

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PageVH(newPhotoView(parent))
    override fun getItemCount() = renderer.pageCount

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        holder.job?.cancel()
        val cached = cache.get(position)
        if (cached != null) {
            holder.img.setImageBitmap(cached)
            return
        }
        holder.img.setImageDrawable(null)
        holder.job = scope.launch {
            val bmp = withContext(Dispatchers.IO) { render(position) } ?: return@launch
            cache.put(position, bmp)
            if (holder.bindingAdapterPosition == position) holder.img.setImageBitmap(bmp)
        }
    }

    override fun onViewRecycled(holder: PageVH) {
        holder.job?.cancel()
    }

    private fun render(i: Int): Bitmap? = synchronized(renderer) {
        if (closed) return null
        val page = renderer.openPage(i)
        try {
            val h = (widthPx.toFloat() * page.height / page.width).toInt()
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        } finally {
            page.close()
        }
    }

    fun close() {
        synchronized(renderer) {
            if (closed) return
            closed = true
            renderer.close()
            pfd.close()
        }
    }
}
