package az.mehdi.iptvplayer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** TV açılanda tətbiqi avtomatik başladır (Android 10+ üçün "Digər tətbiqlərin üstündə göstər" icazəsi lazımdır). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        if (a == Intent.ACTION_BOOT_COMPLETED || a == "android.intent.action.QUICKBOOT_POWERON") {
            runCatching {
                context.startActivity(
                    Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
    }
}
