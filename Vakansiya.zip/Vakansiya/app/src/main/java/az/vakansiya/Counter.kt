package az.vakansiya

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener
import java.util.Calendar

/** Saytları gizli brauzerlərdə eyni anda açıb bu gün / dünən yerləşdirilən elanları təxmini sayır. */
class Counter(
    private val ctx: Context,
    private val sites: List<Site>,
    private val onUpdate: (Int) -> Unit,
    private val onDone: () -> Unit
) {
    private val h = Handler(Looper.getMainLooper())
    private val wvs = mutableListOf<WebView>()
    private val finished = BooleanArray(sites.size)
    private val started = BooleanArray(sites.size)
    private var left = sites.size
    var stopped = false

    // ay adları: azərbaycanca, qısaltma, ingiliscə, rusca
    private val months = arrayOf(
        "yanvar|yan|january|jan|января",
        "fevral|fev|february|feb|февраля",
        "mart|mar|march|марта",
        "aprel|apr|april|апреля",
        "may|мая",
        "iyun|iyn|june|jun|июня",
        "iyul|iyl|july|jul|июля",
        "avqust|avq|august|aug|августа",
        "sentyabr|sen|september|sep|сентября",
        "oktyabr|okt|october|oct|октября",
        "noyabr|noy|november|nov|ноября",
        "dekabr|dek|december|dec|декабря"
    )
    private val end = "\$"
    private val nb = "(^|[^0-9])"
    private val na = "([^0-9]|$end)"

    private fun datePat(c: Calendar): String {
        val d = c.get(Calendar.DAY_OF_MONTH)
        val m = c.get(Calendar.MONTH) + 1
        val y = c.get(Calendar.YEAR)
        val yy = y % 100
        val mn = months[m - 1]
        return listOf(
            "${nb}0?$d[./-]0?$m[./-]($y|$yy)$na",
            "$y[./-]0?$m[./-]0?$d$na",
            "${nb}0?$d[ .]*($mn)",
            "($mn)[ .]*0?$d$na"
        ).joinToString("|")
    }

    private val tw = "bu gün|bugün|bu gun|bugun|today|сегодня|indicə|az əvvəl|just now"
    private val yw = "dünən|dunen|yesterday|вчера|${nb}(1|bir)[ ]*(gün|gun)[ ]*(əvvəl|evvel|öncə)|1 day ago"
    private val hr = "([0-9]+|bir)[ ]*(saat|hour|hr|час)[a-zəöüçşğı.]*[ ]*(əvvəl|evvel|öncə|ago|назад)"
    private val mn = "([0-9]+)[ ]*(dəq|dəqiqə|min|мин)[a-zəöüçşğı.]*[ ]*(əvvəl|evvel|öncə|ago|назад)"

    /** Ümumi (və "diqqətli" kart əsaslı) sayma skripti. */
    private fun js(careful: Boolean): String {
        val cal = Calendar.getInstance()
        val td = datePat(cal)
        cal.add(Calendar.DAY_OF_MONTH, -1)
        val yd = datePat(cal)
        return """(function(){
var L=JSON.parse(${Links.js(careful)});
var careful=$careful;
var TW=new RegExp("$tw"),YW=new RegExp("$yw"),TD=new RegExp("$td"),YD=new RegExp("$yd"),HR=new RegExp("$hr"),MN=new RegExp("$mn");
var DL=/(son tarix|son müraciət tarixi|son müraciət|deadline|bitmə tarixi|valid until)[: ]*[0-9]{1,2}[ .\/-]+[a-zəıöüçşğ0-9]+([ .\/-]+[0-9]{2,4})?/g;
var now=new Date(),mins=now.getHours()*60+now.getMinutes();
function cls(x){x=x.toLowerCase().replace(/\u0307/g,'').replace(/\s+/g,' ').replace(DL,' ');
if(YW.test(x))return 2;if(TW.test(x))return 1;
var m=x.match(HR);if(m){var n=(m[1]=='bir')?1:parseInt(m[1]);return n*60>mins?2:1}
m=x.match(MN);if(m){return parseInt(m[1])>mins?2:1}
if(TD.test(x))return 1;if(YD.test(x))return 2;return 0}
function lineCount(){var lines=(document.body?document.body.innerText:'').split('\n'),t=0,y=0,p='';
for(var i=0;i<lines.length;i++){var l=lines[i].replace(/\s+/g,' ').trim().toLowerCase();if(l.length<3||l===p)continue;p=l;var r=cls(l);if(r==1)t++;else if(r==2)y++}
return [t,y]}
function cardCount(){
var A=[],hs=document.querySelectorAll('h1 a[href],h2 a[href],h3 a[href],h4 a[href]');
for(var i=0;i<hs.length;i++){if(hs[i].innerText.trim().length>3&&hs[i].href.indexOf('http')==0)A.push(hs[i])}
if(A.length<3){
 for(var pass=0;pass<2&&A.length<3;pass++){A=[];var all=document.querySelectorAll('a[href]'),sig={},c=[];
  for(var i=0;i<all.length;i++){var a=all[i],u;try{u=new URL(a.href)}catch(e){continue}
   if(u.origin!==location.origin)continue;var seg=u.pathname.split('/').filter(Boolean);
   if(seg.length<1)continue;if(pass==0?!/[0-9]{3,}/.test(u.pathname):seg.length<2)continue;
   if(a.innerText.trim().length<4)continue;sig[seg[0]]=(sig[seg[0]]||0)+1;c.push([seg[0],a])}
  var best='',bn=0;for(var k in sig){if(sig[k]>bn){bn=sig[k];best=k}}
  for(var i=0;i<c.length;i++){if(c[i][0]===best)A.push(c[i][1])}}}
var seen={},t=0,y=0,n=0;
function dh(el){var d={},m=0;for(var i=0;i<A.length;i++){if(el.contains(A[i])&&!d[A[i].href]){d[A[i].href]=1;m++}}return m}
for(var i=0;i<A.length;i++){var h=A[i].href;if(seen[h])continue;seen[h]=1;n++;
 var el=A[i],card=A[i];
 for(var k=0;k<8&&el.parentElement&&el.parentElement!==document.body;k++){el=el.parentElement;if(dh(el)>1)break;card=el}
 var r=cls(card.innerText||'');if(r==1)t++;else if(r==2)y++}
return [t,y,n]}
var res=null;
if(careful){res=cardCount();if(res[2]<3||res[0]+res[1]==0)res=null}
if(!res)res=lineCount();
return JSON.stringify({t:res[0],y:res[1],l:L});})()"""
    }

    /**
     * JobSite.az: siyahıda yerləşdirmə tarixi yoxdur (yalnız "Son Tarix" - bitmə tarixi görünür).
     * Ona görə ən yeni elanların öz səhifələri açılır və "Yerləşdirilib ..." tarixi oxunur.
     */
    private fun detailJs(url: String): String {
        fun arr(c: Calendar) = "[${c.get(Calendar.DAY_OF_MONTH)},${c.get(Calendar.MONTH) + 1},${c.get(Calendar.YEAR)}]"
        val c1 = Calendar.getInstance()
        val c2 = Calendar.getInstance(); c2.add(Calendar.DAY_OF_MONTH, -1)
        val staj = Store.stajFilter(url)
        return """(function(){
var L=JSON.parse(${Links.js(false)});
var A=[],seen={},a=document.querySelectorAll('a[href]');
for(var i=0;i<a.length;i++){var h=a[i].href.split('#')[0];
 if(h.indexOf('/vakansiya-is-elani/')<0||!/-[0-9]+${'$'}/.test(h)||seen[h])continue;seen[h]=1;A.push(h)}
function idOf(u){return parseInt(u.match(/([0-9]+)${'$'}/)[1])}
A.sort(function(x,y){return idOf(y)-idOf(x)});A=A.slice(0,${if (staj) 50 else 30});
var T=${arr(c1)},Y=${arr(c2)};
var F=$staj;
var keep=[];
var MON=['yanvar','fevral','mart','aprel','may','iyun','iyul','avqust','sentyabr','oktyabr','noyabr','dekabr'];
function eq(d,m,y,Z){return d==Z[0]&&m==Z[1]&&y==Z[2]}
function norm(z){return z.replace(/\s+/g,' ').toLowerCase().replace(/\u0307/g,'').trim()}
var W='[^a-zəıöüçşğ]';
var TITLE=new RegExp('(^|'+W+')(staj|stajçı|stajyor|intern|internship)('+W+'|${'$'})|təcrübəçi|təcrübə proqram|təcrübə keçmə');
var HEAD=new RegExp('(^|'+W+')(stajçı|stajyor|internship)('+W+'|${'$'})|təcrübəçi|təcrübə proqram');
var fin=false;
function get(h){var c=new AbortController(),t=setTimeout(function(){c.abort()},10000);
 return fetch(h,{credentials:'omit',signal:c.signal}).then(function(r){clearTimeout(t);return r.ok?r.text():null}).catch(function(){clearTimeout(t);return null})}
function send(arr){if(fin)return;
 var okN=arr.filter(function(z){return z!==null}).length;if(okN==0)return;fin=true;var t=0,y=0;
 arr.forEach(function(html,idx){if(html===null)return;
  var x=norm(html.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi,' ').replace(/<[^>]*>/g,' '));
  var hd=x.split(' təsvir ')[0];
  if(F){var ttl='';try{var d=new DOMParser().parseFromString(html,'text/html');var e=d.querySelector('h1');ttl=norm((e&&e.textContent)||d.title||'')}catch(er){}
   var hw=hd.substring(Math.max(0,hd.length-450));
   if(!(TITLE.test(ttl)||HEAD.test(hw)))return}
  keep.push(A[idx]);
  var m=hd.match(/yerləşdirilib ([0-9]{1,2}) ([a-zəıöüçşğ]+) ([0-9]{4})/)||x.match(/yerləşdirilib ([0-9]{1,2}) ([a-zəıöüçşğ]+) ([0-9]{4})/);if(!m)return;
  var dd=parseInt(m[1]),mo=MON.indexOf(m[2])+1,yr=parseInt(m[3]);
  if(eq(dd,mo,yr,T))t++;else if(eq(dd,mo,yr,Y))y++});
 Bridge.done(JSON.stringify({t:t,y:y,l:F?keep:L.concat(A)}))}
Promise.all(A.map(get)).then(send);
})()"""
    }

    inner class Bridge(val i: Int) {
        @JavascriptInterface
        fun done(json: String) {
            h.post {
                if (!stopped && !finished[i]) {
                    try {
                        val o = JSONObject(json)
                        sites[i].today = o.getInt("t")
                        sites[i].yest = o.getInt("y")
                        val arr = o.getJSONArray("l")
                        sites[i].links = List(arr.length()) { arr.getString(it) }
                    } catch (e: Exception) { }
                    finish(i)
                }
            }
        }
    }

    /** Səhifə hazır olana qədər tez-tez yoxlayır (sabit gözləmə yoxdur): nəticə sabitləşən kimi qəbul edir. */
    private fun poll(v: WebView, i: Int, site: Site, detail: Boolean) {
        val careful = Store.careful(site.url)
        val script = if (detail) "" else js(careful)
        val deadline = System.currentTimeMillis() + (if (detail) 7000L else if (careful) 9000L else 6000L)
        var last = ""
        fun tick() {
            if (stopped || finished[i]) return
            val late = System.currentTimeMillis() >= deadline
            if (detail) {
                v.evaluateJavascript("document.querySelectorAll('a[href*=\"/vakansiya-is-elani/\"]').length") { r ->
                    if (stopped || finished[i]) return@evaluateJavascript
                    val n = r?.toIntOrNull() ?: 0
                    if (n > 0 || late) v.evaluateJavascript(detailJs(site.url), null)
                    else h.postDelayed({ tick() }, 300)
                }
            } else {
                v.evaluateJavascript(script) { r ->
                    if (stopped || finished[i]) return@evaluateJavascript
                    var o: JSONObject? = null
                    try { o = JSONObject(JSONTokener(r).nextValue() as String) } catch (e: Exception) { }
                    val size = o?.getJSONArray("l")?.length() ?: 0
                    if (o != null && ((size >= 3 && r == last) || late)) {
                        site.today = o.getInt("t")
                        site.yest = o.getInt("y")
                        val arr = o.getJSONArray("l")
                        site.links = List(arr.length()) { arr.getString(it) }
                        finish(i)
                    } else if (late) finish(i)
                    else { last = r ?: ""; h.postDelayed({ tick() }, 400) }
                }
            }
        }
        h.postDelayed({ tick() }, 250)
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    fun start() {
        if (sites.isEmpty()) { onDone(); return }
        sites.forEachIndexed { i, site ->
            val detail = Store.detail(site.url)
            val w = WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.blockNetworkImage = true
                settings.loadsImagesAutomatically = false
                if (detail) addJavascriptInterface(Bridge(i), "Bridge")
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(v: WebView, u: String) {
                        if (stopped || finished[i] || started[i]) return
                        started[i] = true
                        poll(v, i, site, detail)
                    }
                }
            }
            wvs.add(w)
            w.loadUrl(site.url)
            // hər sayt üçün ayrıca vaxt limiti
            h.postDelayed({ if (!stopped && !finished[i]) finish(i) }, if (detail) 15000L else 12000L)
        }
    }

    private fun finish(i: Int) {
        if (finished[i]) return
        finished[i] = true
        try { wvs[i].destroy() } catch (e: Exception) { }
        onUpdate(i)
        left--
        if (left == 0 && !stopped) onDone()
    }

    fun stop() {
        stopped = true
        h.removeCallbacksAndMessages(null)
        wvs.forEachIndexed { i, w ->
            if (!finished[i]) { finished[i] = true; try { w.destroy() } catch (e: Exception) { } }
        }
    }
}
