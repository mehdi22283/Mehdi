package az.vakansiya

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

/** Skan zamanı lazımsız yükləmələri (reklam/izləmə skriptləri, şrift, video) bloklayır: səhifə daha tez hazır olur. */
object Block {
    private val hosts = listOf(
        "google-analytics.com", "googletagmanager.com", "doubleclick.net", "googlesyndication.com",
        "googleadservices.com", "connect.facebook.net", "hotjar.com", "clarity.ms", "mc.yandex",
        "adnxs.com", "criteo.", "taboola.", "outbrain.", "yadro.ru"
    )
    private val ext = Regex("""\.(woff2?|ttf|otf|mp4|webm|mp3|m4a)(\?|$)""", RegexOption.IGNORE_CASE)

    fun intercept(req: WebResourceRequest): WebResourceResponse? {
        if (req.isForMainFrame) return null
        val u = req.url.toString()
        val bad = hosts.any { u.contains(it) } || ext.containsMatchIn(u)
        return if (bad) WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0))) else null
    }
}
