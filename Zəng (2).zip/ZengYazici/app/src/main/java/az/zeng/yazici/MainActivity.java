package az.zeng.yazici;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    // ---------- rənglər (qaranlıq tema) ----------
    private static final int BG = 0xFF0E1014, CARD = 0xFF181B22, CARD2 = 0xFF232733,
            TXT = 0xFFECEFF4, SUB = 0xFF9AA3B2, ACC = 0xFF4C8DFF, GRN = 0xFF34C77B,
            RED = 0xFFFF5A5F, AMB = 0xFFFFB020;

    static class Rec {
        String id, path, src, dir, label, status, note;
        long ts;
        int dur;
        boolean live;
    }

    static class VH {
        TextView icon, name, meta, tag, play, time;
        SeekBar seek;
        View bar;
        String path;
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Rec> all = new ArrayList<>();
    private final List<Rec> shown = new ArrayList<>();
    private SharedPreferences p;
    private TextView headline, mainBtn, empty, countTv;
    private final TextView[] steps = new TextView[5];
    private final TextView[] chips = new TextView[3];
    private final boolean[] ok = new boolean[5];
    private Adapter ad;
    private MediaPlayer mp;
    private String curPath, sig = "";
    private VH curVH;
    private boolean resumed;
    private int filter = 0; // 0 hamısı, 1 gələn, 2 gedən

    private static final String[] STEP_NAMES = {
            "İcazələr", "Cütləşmə (Wireless debugging)", "Yazıcı proses", "WhatsApp bildiriş girişi", "Avtostart (Xiaomi)"};
    private static final String[] STEP_ACTIONS = {
            "İcazələri ver", "Cütləşdir", "Yazıcı prosesi başlat", "WhatsApp girişini aç", "Avtostartı aç"};

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (!resumed) return;
            reload(false);
            h.postDelayed(this, 4000);
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private static int alpha(int c, int a) {
        return (a << 24) | (c & 0xFFFFFF);
    }

    private GradientDrawable rr(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private void bg(View v, int color, int radiusDp) {
        v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), rr(color, radiusDp), null));
    }

    private TextView tv(String t, int size, int color, boolean bold) {
        TextView x = new TextView(this);
        x.setText(t);
        x.setTextSize(size);
        x.setTextColor(color);
        if (bold) x.setTypeface(null, Typeface.BOLD);
        return x;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackground(rr(CARD, 20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        c.setLayoutParams(lp);
        return c;
    }

    private TextView smallBtn(String t, View.OnClickListener l) {
        TextView b = tv(t, 14, TXT, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(12), dp(8), dp(12));
        bg(b, CARD2, 14);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("st", 0);
        Notif.init(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setBackgroundColor(BG);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(dp(16), dp(28), dp(16), dp(4));

        head.addView(tv("Zəng Yazıcı", 28, TXT, true));
        TextView sub = tv("Gələn və gedən zənglər avtomatik yazılır", 14, SUB, false);
        sub.setPadding(0, dp(2), 0, dp(16));
        head.addView(sub);

        // ----- tək pəncərə: vəziyyət + tək düymə -----
        LinearLayout sc = card();
        headline = tv("Yoxlanılır…", 18, TXT, true);
        headline.setPadding(0, 0, 0, dp(10));
        sc.addView(headline);
        for (int i = 0; i < steps.length; i++) {
            steps[i] = tv("", 14, SUB, false);
            steps[i].setPadding(0, dp(3), 0, dp(3));
            sc.addView(steps[i]);
        }
        mainBtn = tv("", 16, Color.WHITE, true);
        mainBtn.setGravity(Gravity.CENTER);
        mainBtn.setPadding(dp(12), dp(16), dp(12), dp(16));
        bg(mainBtn, ACC, 16);
        mainBtn.setOnClickListener(v -> mainAction());
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-1, -2);
        mlp.setMargins(0, dp(14), 0, dp(10));
        sc.addView(mainBtn, mlp);

        LinearLayout row = new LinearLayout(this);
        TextView t1 = smallBtn("Sınaq yazısı (6 san)", v -> test());
        TextView t2 = smallBtn("Jurnal", v -> showLog());
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1);
        l1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1);
        l2.setMargins(dp(6), 0, 0, 0);
        row.addView(t1, l1);
        row.addView(t2, l2);
        sc.addView(row);
        head.addView(sc);

        // ----- parametrlər -----
        LinearLayout set = card();
        Switch sw = sw("Telefon zəngi: mikrofon + dinamik rejimi (VOICE_CALL işləməsə)");
        sw.setChecked(p.getInt("ph_mode", 0) == 1);
        sw.setOnCheckedChangeListener((v, on) -> p.edit().putInt("ph_mode", on ? 1 : 0).apply());
        set.addView(sw);
        Switch sw2 = sw("Hər zəngdə yazıcı prosesi avtomatik başlat (Wi-Fi + Wireless debugging açıq olmalıdır)");
        sw2.setChecked(p.getBoolean("auto_adb", true));
        sw2.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("auto_adb", on).apply());
        set.addView(sw2);
        head.addView(set);

        // ----- tarixçə + filtr -----
        LinearLayout tr = new LinearLayout(this);
        tr.setGravity(Gravity.CENTER_VERTICAL);
        TextView lt = tv("Zəng tarixçəsi", 20, TXT, true);
        countTv = tv("", 13, SUB, false);
        tr.addView(lt, new LinearLayout.LayoutParams(0, -2, 1));
        tr.addView(countTv);
        tr.setPadding(0, dp(6), 0, dp(10));
        head.addView(tr);

        LinearLayout cr = new LinearLayout(this);
        String[] cn = {"Hamısı", "Gələn", "Gedən"};
        for (int i = 0; i < 3; i++) {
            final int fi = i;
            chips[i] = tv(cn[i], 14, TXT, true);
            chips[i].setGravity(Gravity.CENTER);
            chips[i].setPadding(dp(14), dp(10), dp(14), dp(10));
            chips[i].setOnClickListener(v -> {
                filter = fi;
                applyFilter();
            });
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1);
            cl.setMargins(i == 0 ? 0 : dp(4), 0, i == 2 ? 0 : dp(4), 0);
            cr.addView(chips[i], cl);
        }
        head.addView(cr);

        empty = tv("Bu filtrə uyğun zəng yoxdur", 14, SUB, false);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(0, dp(32), 0, dp(32));
        head.addView(empty);

        ListView list = new ListView(this);
        list.setBackgroundColor(BG);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(android.R.color.transparent);
        list.setCacheColorHint(Color.TRANSPARENT);
        list.addHeaderView(head, null, false);
        View foot = new View(this);
        foot.setLayoutParams(new ListView.LayoutParams(-1, dp(24)));
        list.addFooterView(foot, null, false);
        ad = new Adapter();
        list.setAdapter(ad);
        setContentView(list);
        updateChips();
    }

    private Switch sw(String t) {
        Switch s = new Switch(this);
        s.setText(t);
        s.setTextSize(14);
        s.setTextColor(TXT);
        s.setPadding(0, dp(8), 0, dp(8));
        return s;
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        refresh();
        reload(true);
        h.postDelayed(poll, 4000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        h.removeCallbacks(poll);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlayer();
    }

    private boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    // ---------- tək düymə məntiqi ----------

    private int nextStep() {
        for (int i = 0; i < ok.length; i++) if (!ok[i]) return i;
        return ok.length;
    }

    private void mainAction() {
        switch (nextStep()) {
            case 0:
                askPerms();
                break;
            case 1:
                pairing();
                break;
            case 2:
                startProc();
                break;
            case 3:
                try {
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                } catch (Throwable t) {
                    Toast.makeText(this, "Açıla bilmədi", Toast.LENGTH_SHORT).show();
                }
                break;
            case 4:
                autostart();
                p.edit().putBoolean("autostart_done", true).apply();
                break;
            default:
                startProc();
        }
    }

    private void refresh() {
        new Thread(() -> {
            final boolean up = RecorderClient.ping(this);
            runOnUiThread(() -> {
                boolean ph = has(Manifest.permission.READ_PHONE_STATE) && has(Manifest.permission.READ_CALL_LOG)
                        && has(Manifest.permission.PROCESS_OUTGOING_CALLS)
                        && (Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS));
                String en = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
                ok[0] = ph;
                ok[1] = AdbMgr.paired(this);
                ok[2] = up;
                ok[3] = en != null && en.contains(getPackageName());
                ok[4] = p.getBoolean("autostart_done", false);
                for (int i = 0; i < steps.length; i++) {
                    steps[i].setText((ok[i] ? "✔  " : "○  ") + STEP_NAMES[i]);
                    steps[i].setTextColor(ok[i] ? GRN : SUB);
                }
                int n = nextStep();
                if (n >= ok.length) {
                    headline.setText("● Hazırdır");
                    headline.setTextColor(GRN);
                    mainBtn.setText("Yazıcı prosesi yenidən başlat");
                    bg(mainBtn, CARD2, 16);
                } else {
                    boolean core = ok[0] && ok[1] && ok[2];
                    headline.setText(core ? "● Yazıcı işləyir (əlavə addım qalıb)" : "Quraşdırma lazımdır");
                    headline.setTextColor(core ? AMB : TXT);
                    mainBtn.setText((n + 1) + "/5  ·  " + STEP_ACTIONS[n]);
                    bg(mainBtn, ACC, 16);
                }
            });
        }).start();
    }

    private void askPerms() {
        List<String> need = new ArrayList<>(Arrays.asList(
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.PROCESS_OUTGOING_CALLS));
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(need.toArray(new String[0]), 1);
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] pm, int[] r) {
        super.onRequestPermissionsResult(c, pm, r);
        refresh();
    }

    private void pairing() {
        Notif.pairPrompt(this, "Developer options > Wireless debugging > \"Pair device with pairing code\" pəncərəsini açın və göstərilən 6 rəqəmli kodu bura yazın.");
        Toast.makeText(this, "Bildiriş panelini açıb kodu yazın", Toast.LENGTH_LONG).show();
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
        } catch (Throwable t) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void startProc() {
        Toast.makeText(this, "Başladılır…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String msg;
            try {
                AdbStarter.startDaemon(this);
                Thread.sleep(1200);
                msg = RecorderClient.ping(this) ? "Yazıcı proses işləyir" : "Başladılmadı, Jurnala baxın";
            } catch (Throwable t) {
                msg = "Xəta: " + t.getMessage();
            }
            final String fm = msg;
            runOnUiThread(() -> {
                Toast.makeText(this, fm, Toast.LENGTH_LONG).show();
                refresh();
            });
        }).start();
    }

    private void autostart() {
        try {
            Intent i = new Intent();
            i.setComponent(new ComponentName("com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            startActivity(i);
        } catch (Throwable t) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void test() {
        RecorderClient.begin(this, "ph", "out", "Sinaq", null);
        h.postDelayed(() -> RecorderClient.end(this, "ph", () -> reload(true)), 6000);
    }

    private AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
    }

    private void showLog() {
        final String[] out = {""};
        RecorderClient.run(this, r -> out[0] = r.log(), err -> dlg()
                .setTitle("Jurnal")
                .setMessage((err != null ? "Xəta: " + err.getMessage() + "\n" : "")
                        + (p.getString("adb_err", "").isEmpty() ? "" : "adb: " + p.getString("adb_err", "") + "\n")
                        + (out[0].isEmpty() ? "" : out[0]))
                .setPositiveButton("Bağla", null)
                .show());
    }

    private void confirmDelete(final Rec r) {
        dlg().setMessage("Bu qeyd silinsin?\n" + r.label + "\n" + stamp(r.ts))
                .setPositiveButton("Sil", (d, w) -> {
                    if (r.path != null) {
                        if (r.path.equals(curPath)) stopPlayer();
                        new File(r.path).delete();
                    }
                    HistoryStore.remove(this, r.id);
                    reload(true);
                })
                .setNegativeButton("Ləğv et", null)
                .show();
    }

    // ---------- tarixçə siyahısı ----------

    private File mediaDir() {
        File[] ds = getExternalMediaDirs();
        return ds != null && ds.length > 0 ? ds[0] : null;
    }

    private static String stamp(long ts) {
        return new SimpleDateFormat("dd.MM.yyyy  HH:mm", Locale.US).format(new Date(ts));
    }

    private void reload(boolean force) {
        File d = mediaDir();
        File[] fs = d == null ? null : d.listFiles((x, n) -> n.endsWith(".wav"));
        if (fs == null) fs = new File[0];
        Arrays.sort(fs, (a, b) -> b.getName().compareTo(a.getName()));
        boolean active = p.getBoolean("active", false);
        String ap = p.getString("path", "");
        String s = HistoryStore.stamp(this) + "|" + fs.length + "|" + (fs.length > 0 ? fs[0].getName() : "") + "|" + active;
        if (!force && s.equals(sig)) return;
        sig = s;

        all.clear();
        Set<String> seen = new HashSet<>();
        for (HistoryStore.Item hi : HistoryStore.all(this)) {
            Rec r = new Rec();
            r.id = hi.id;
            r.ts = hi.ts;
            r.src = hi.src;
            r.dir = hi.dir;
            r.label = hi.label.isEmpty() ? "Naməlum" : hi.label;
            r.status = hi.status;
            r.note = hi.note;
            if (hi.id.endsWith(".wav")) {
                seen.add(hi.id);
                File f = new File(hi.id);
                if (f.exists()) r.path = hi.id;
            }
            r.live = active && hi.id.equals(ap);
            if (r.path != null && !r.live) r.dur = durationOf(new File(r.path));
            all.add(r);
        }
        // tarixçədə olmayan köhnə yazılar
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        for (File x : fs) {
            if (seen.contains(x.getAbsolutePath())) continue;
            String n = x.getName().substring(0, x.getName().length() - 4);
            String[] a = n.split("__", 4);
            if (a.length < 4) continue;
            Rec r = new Rec();
            r.id = x.getAbsolutePath();
            r.path = r.id;
            r.src = a[1];
            r.dir = a[2];
            r.label = a[3].replace('_', ' ');
            r.status = "ok";
            r.note = "";
            try {
                r.ts = f.parse(a[0]).getTime();
            } catch (Exception e) {
                r.ts = x.lastModified();
            }
            r.live = active && r.path.equals(ap);
            r.dur = r.live ? 0 : durationOf(x);
            all.add(r);
        }
        Collections.sort(all, (x, y) -> Long.compare(y.ts, x.ts));
        applyFilter();
    }

    private void applyFilter() {
        shown.clear();
        for (Rec r : all) {
            if (filter == 0 || (filter == 1 && "in".equals(r.dir)) || (filter == 2 && "out".equals(r.dir)))
                shown.add(r);
        }
        updateChips();
        empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        countTv.setText(shown.size() + " zəng");
        ad.notifyDataSetChanged();
    }

    private void updateChips() {
        int in = 0, out = 0;
        for (Rec r : all) {
            if ("in".equals(r.dir)) in++;
            else out++;
        }
        String[] names = {"Hamısı " + all.size(), "Gələn " + in, "Gedən " + out};
        for (int i = 0; i < 3; i++) {
            chips[i].setText(names[i]);
            chips[i].setTextColor(i == filter ? Color.WHITE : SUB);
            bg(chips[i], i == filter ? ACC : CARD, 14);
        }
    }

    private static int durationOf(File f) {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            if (f.length() <= 44) return 0;
            r.seek(24);
            byte[] b = new byte[4];
            r.readFully(b);
            int rate = (b[0] & 255) | ((b[1] & 255) << 8) | ((b[2] & 255) << 16) | ((b[3] & 255) << 24);
            if (rate <= 0) return 0;
            return (int) ((f.length() - 44) / (rate * 2L));
        } catch (Exception e) {
            return 0;
        }
    }

    private static String fmt(int sec) {
        return String.format(Locale.US, "%d:%02d", sec / 60, sec % 60);
    }

    // ---------- player ----------

    private void stopPlayer() {
        if (mp != null) {
            try {
                mp.release();
            } catch (Throwable ignored) {
            }
            mp = null;
        }
        curPath = null;
        curVH = null;
    }

    private void toggle(VH v, Rec r) {
        try {
            if (r.path.equals(curPath) && mp != null) {
                if (mp.isPlaying()) {
                    mp.pause();
                    v.play.setText("▶");
                } else {
                    mp.start();
                    v.play.setText("⏸");
                    tick();
                }
                return;
            }
            stopPlayer();
            mp = new MediaPlayer();
            mp.setDataSource(r.path);
            mp.prepare();
            mp.setOnCompletionListener(m -> {
                stopPlayer();
                ad.notifyDataSetChanged();
            });
            mp.start();
            curPath = r.path;
            curVH = v;
            v.play.setText("⏸");
            tick();
        } catch (Throwable t) {
            Toast.makeText(this, "Oxutmaq olmadı: " + t.getMessage(), Toast.LENGTH_LONG).show();
            stopPlayer();
        }
    }

    private final Runnable ticker = this::tick;

    private void tick() {
        h.removeCallbacks(ticker);
        if (mp == null || curVH == null) return;
        try {
            if (curPath != null && curPath.equals(curVH.path)) {
                int d = mp.getDuration(), c = mp.getCurrentPosition();
                curVH.seek.setMax(Math.max(d, 1));
                curVH.seek.setProgress(c);
                curVH.time.setText(fmt(c / 1000) + " / " + fmt(d / 1000));
            }
            if (mp.isPlaying()) h.postDelayed(ticker, 300);
        } catch (Throwable ignored) {
        }
    }

    // ---------- adapter ----------

    private class Adapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int i) {
            return shown.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        private View create() {
            LinearLayout wrap = new LinearLayout(MainActivity.this);
            wrap.setPadding(dp(16), dp(5), dp(16), dp(5));
            LinearLayout card = new LinearLayout(MainActivity.this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackground(rr(CARD, 18));
            wrap.addView(card, new LinearLayout.LayoutParams(-1, -2));

            final VH v = new VH();
            LinearLayout top = new LinearLayout(MainActivity.this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            v.icon = tv("", 18, Color.WHITE, true);
            v.icon.setGravity(Gravity.CENTER);
            top.addView(v.icon, new LinearLayout.LayoutParams(dp(42), dp(42)));

            LinearLayout mid = new LinearLayout(MainActivity.this);
            mid.setOrientation(LinearLayout.VERTICAL);
            mid.setPadding(dp(12), 0, dp(8), 0);
            v.name = tv("", 16, TXT, true);
            v.name.setSingleLine(true);
            v.meta = tv("", 12, SUB, false);
            v.meta.setPadding(0, dp(2), 0, 0);
            mid.addView(v.name);
            mid.addView(v.meta);
            top.addView(mid, new LinearLayout.LayoutParams(0, -2, 1));
            v.tag = tv("", 13, SUB, true);
            top.addView(v.tag);
            card.addView(top);

            LinearLayout bar = new LinearLayout(MainActivity.this);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setPadding(0, dp(8), 0, 0);
            v.play = tv("▶", 22, TXT, false);
            v.play.setPadding(dp(4), dp(4), dp(12), dp(4));
            v.seek = new SeekBar(MainActivity.this);
            v.seek.setProgressTintList(ColorStateList.valueOf(ACC));
            v.seek.setThumbTintList(ColorStateList.valueOf(ACC));
            v.time = tv("", 12, SUB, false);
            v.time.setPadding(dp(8), 0, 0, 0);
            bar.addView(v.play);
            bar.addView(v.seek, new LinearLayout.LayoutParams(0, -2, 1));
            bar.addView(v.time);
            card.addView(bar);
            v.bar = bar;
            v.seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar s, int pr, boolean user) {
                    if (user && mp != null && v.path != null && v.path.equals(curPath)) mp.seekTo(pr);
                }

                @Override
                public void onStartTrackingTouch(SeekBar s) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar s) {
                }
            });
            wrap.setTag(new Object[]{v, card});
            return wrap;
        }

        @Override
        public View getView(int pos, View cv, ViewGroup par) {
            final Rec r = shown.get(pos);
            if (cv == null) cv = create();
            Object[] t = (Object[]) cv.getTag();
            final VH v = (VH) t[0];
            View card = (View) t[1];

            boolean missed = "missed".equals(r.status);
            boolean in = "in".equals(r.dir);
            int col = missed ? RED : (in ? GRN : ACC);
            v.icon.setText(missed ? "✕" : (in ? "↙" : "↗"));
            v.icon.setBackground(rr(alpha(col, 0x40), 21));
            v.icon.setTextColor(col);
            v.name.setText(r.label);
            String src = "wa".equals(r.src) ? "WhatsApp" : "Telefon";
            String dirName = missed ? "Cavabsız zəng" : (in ? "Gələn" : "Gedən");
            v.meta.setText(stamp(r.ts) + "  ·  " + src + "  ·  " + dirName);

            v.path = r.path;
            boolean playable = r.path != null && !r.live && "ok".equals(r.status);
            if (r.live) {
                v.tag.setText("● yazılır");
                v.tag.setTextColor(RED);
            } else if ("err".equals(r.status)) {
                v.tag.setText("Xəta");
                v.tag.setTextColor(AMB);
            } else if (missed) {
                v.tag.setText("");
            } else if (r.path == null) {
                v.tag.setText("Fayl yoxdur");
                v.tag.setTextColor(SUB);
            } else {
                v.tag.setText(fmt(r.dur));
                v.tag.setTextColor(SUB);
            }
            v.bar.setVisibility(playable || (r.path != null && !r.live && !"err".equals(r.status)) ? View.VISIBLE : View.GONE);

            if (v.bar.getVisibility() == View.VISIBLE) {
                v.play.setOnClickListener(x -> toggle(v, r));
                if (r.path.equals(curPath) && mp != null) {
                    curVH = v;
                    v.play.setText(mp.isPlaying() ? "⏸" : "▶");
                    tick();
                } else {
                    v.play.setText("▶");
                    v.seek.setMax(Math.max(r.dur * 1000, 1));
                    v.seek.setProgress(0);
                    v.time.setText("0:00 / " + fmt(r.dur));
                }
            }
            card.setOnLongClickListener(x -> {
                confirmDelete(r);
                return true;
            });
            return cv;
        }
    }
}
