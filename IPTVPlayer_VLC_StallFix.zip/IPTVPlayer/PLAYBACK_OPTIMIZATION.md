# IPTV Player – sürətli açılış və şəbəkə sabitliyi

- VLC network-caching 2 saniyə, live-caching 1.5 saniyədir: sabit açılış və qısa şəbəkə dalğalanmalarına ehtiyat.
- VLC-də gecikmiş kadrları zorla saxlama seçimi çıxarıldı; gecikmə yarananda pleyer kadrları ata bilər və canlı yayım daha axıcı qala bilər.
- Bufer dəyərləri MainActivity.kt-nin başında sabitlərdədir (EXO_*, VLC_*): Exo min 10 san, max 20 san, ilkin 2 san, rebufer 4 san; VLC network 2 san, live 1.5 san. Köhnə bufer kanal dəyişəndə dərhal atılır.
- ExoPlayer HTTP bağlantı timeout-u 2 saniyə, oxuma timeout-u 3 saniyədir.
- Axın başlamasa və ya buffering uzun çəksə: ExoPlayer-də 2 saniyədən (EXO_OPEN_TIMEOUT_MS), VLC-də 10 saniyədən sonra alternativ pleyerə keçid edilir. Canlı axın kəsilsə (STATE_ENDED) ExoPlayer-dən VLC-yə keçilir.
- Sürətli kanal dəyişmələrində son seçim üstün tutulur; əvvəlki 350 ms gözləmə 100 ms edilib.
- Kanal dəyişmə nəsli ilə köhnə player hadisələri filtrlənir; HTTP reconnect aktivdir.

Qeyd: Daha qısa bufer ilk görüntünü tezləşdirə bilər, lakin zəif internetdə donma ehtimalını artıra bilər. Real nəticə IPTV mənbəyindən, kodekdən və bağlantıdan asılıdır. Android SDK/Gradle və canlı IPTV axınları ilə cihaz testi bu mühitdə aparılmayıb.

- Əsas pleyer ExoPlayer-dir (Media3 1.4.1). Kanal 2 saniyə içində açılmasa və ya xəta versə, avtomatik VLC (libVLC 3.6.0) ehtiyatına keçilir.
- Kanalın səsi AAC-dirsə ExoPlayer ilə davam edir; AAC deyilsə və ya oxunmursa, avtomatik VLC-yə keçilir.
- Kanalın səsi AAC-dirsə ExoPlayer ilə davam edir; AAC deyilsə və ya oxunmursa avtomatik VLC-yə keçilir.
