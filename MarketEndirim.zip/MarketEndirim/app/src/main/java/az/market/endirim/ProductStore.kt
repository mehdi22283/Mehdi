package az.market.endirim

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Skan edilmiş məhsullar (jurnal linki → məhsullar). Diskdə products.json faylında saxlanır. */
object ProductStore {
    private const val VERSION = 7   // 7: yalnız məhsul adı + kateqoriya (qiymət yoxdur); 6 (qiymətli) oxunur, adlar götürülüb yenidən yazılır — yenidən skan lazım deyil
    @Volatile var needsRewrite = false
    private val map = LinkedHashMap<String, List<Product>>()
    private val marketOf = HashMap<String, String>()
    private val sigs = HashMap<String, String>()

    private val writeLock = Mutex()   // eyni vaxtda iki yazma products.json.part faylını korlamasın

    private fun file(ctx: Context) = File(ctx.filesDir, "products.json")

    @Synchronized
    fun load(ctx: Context): List<Product> {
        map.clear()
        marketOf.clear()
        sigs.clear()
        needsRewrite = false
        try {
            val f = file(ctx)
            if (f.exists()) {
                val root = JSONObject(f.readText())
                val v = root.optInt("v")
                if (v == VERSION || v == 6) {
                    val migrate = v != VERSION
                    val cats = root.getJSONObject("catalogs")
                    var removed = false     // mötərizəli adlar silinibsə fayl təzədən yazılır
                    for (url in cats.keys()) {
                        val o = cats.getJSONObject(url)
                        val market = o.getString("market")
                        val arr = o.getJSONArray("items")
                        val list = ArrayList<Product>(arr.length())
                        val seen = HashSet<String>()
                        for (i in 0 until arr.length()) {
                            val it = arr.getJSONObject(i)
                            val raw = it.getString("n")
                            // köhnə (v6) adlar yeni yazılış qaydaları ilə bir dəfə düzəldilir və kateqoriya təyin olunur
                            val name = if (migrate) AzText.fix(raw) else raw
                            if (ProductParser.hasParens(raw) || ProductParser.hasParens(name) || AzText.hasCyrillic(name)) { removed = true; continue }
                            val cat = Categorizer.classify(name)      // kateqoriya qaydaları dəyişə bilər — həmişə təzədən təyin olunur
                            if (!it.has("c") || it.getString("c") != cat) removed = true
                            val p = Product(name, market, url, it.optInt("pg", 1), cat)
                            if (seen.add(p.dkey)) list.add(p) else removed = true
                        }
                        map[url] = list
                        marketOf[url] = market
                        if (!o.isNull("sig") && o.has("sig")) sigs[url] = o.getString("sig")
                    }
                    if (migrate || removed) needsRewrite = true
                }
            }
        } catch (e: Exception) {
            map.clear()
        }
        return all()
    }

    /** Köhnə formatdan köçürülən nəticələri yeni formatda diskə yazır. */
    suspend fun rewriteIfNeeded(ctx: Context) {
        if (needsRewrite) {
            needsRewrite = false
            save(ctx)
        }
    }

    @Synchronized
    fun all(): List<Product> = map.values.flatten()

    @Synchronized
    fun scannedUrls(): Set<String> = map.keys.toSet()

    @Synchronized
    fun sigOf(url: String): String? = sigs[url]

    suspend fun put(ctx: Context, url: String, market: String, items: List<Product>, sig: String?) {
        synchronized(this) {
            map[url] = items
            marketOf[url] = market
            if (sig != null) sigs[url] = sig else sigs.remove(url)
        }
        save(ctx)
    }

    /** Jurnal dəyişəndə köhnə skan nəticəsi atılır (yenidən skan olunacaq). */
    suspend fun forget(ctx: Context, url: String) {
        val had = synchronized(this) { sigs.remove(url); marketOf.remove(url); map.remove(url) != null }
        if (had) save(ctx)
    }

    /** Siyahıda olmayan köhnə jurnalların məhsulları silinir. */
    suspend fun cleanup(ctx: Context, keepUrls: Set<String>) {
        val changed = synchronized(this) { map.keys.retainAll(keepUrls) }
        if (changed) save(ctx)
    }

    private suspend fun save(ctx: Context) = withContext(Dispatchers.IO) {
        writeLock.withLock {
            try {
                // snapshot kilidin içində alınır — sonuncu yazan həmişə ən yeni vəziyyəti yazır
                val snapshot = synchronized(this@ProductStore) { LinkedHashMap(map) }
                val markets = synchronized(this@ProductStore) { HashMap(marketOf) }
                val sigSnap = synchronized(this@ProductStore) { HashMap(sigs) }
                val cats = JSONObject()
                for ((url, list) in snapshot) {
                    val arr = JSONArray()
                    for (p in list) arr.put(JSONObject().apply {
                        put("n", p.name)
                        put("c", p.cat)
                        put("pg", p.page)
                    })
                    cats.put(url, JSONObject().put("market", markets[url] ?: "").put("sig", sigSnap[url] ?: JSONObject.NULL).put("items", arr))
                }
                val f = file(ctx)
                val tmp = File(f.path + ".part")
                tmp.writeText(JSONObject().put("v", VERSION).put("catalogs", cats).toString())
                if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
            } catch (e: Exception) {
            }
        }
    }
}
