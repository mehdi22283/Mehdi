package az.yvok.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;

import java.io.IOException;
import java.io.InputStream;

/**
 * Şəkli "sənəd skan" effektinə çevirir: kölgə və fon yox olur, mətn qara, kağız ağ olur.
 * OCR-dan əvvəl hər şəkilə (kamera və qalereya) tətbiq olunur.
 */
final class DocEnhance {
    private static final int MAX_SIDE = 2800;          // uzun tərəf bundan böyük olmasın
    private static final long MAX_PIXELS = 7_000_000L; // inteqral cəmin int-i aşmaması üçün (7M*255 < 2^31)

    private DocEnhance() { }

    /** Şəkli yükləyir, EXIF-ə görə düzgün çevirir və lazım olsa kiçildir. */
    static Bitmap load(Context c, Uri uri) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, o);
        }
        int w0 = o.outWidth, h0 = o.outHeight;
        if (w0 <= 0 || h0 <= 0) throw new IOException("şəkil oxunmadı");

        int sample = 1;
        while (Math.max(w0, h0) / (sample * 2) >= MAX_SIDE) sample *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = sample;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bmp;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            bmp = BitmapFactory.decodeStream(in, null, o);
        }
        if (bmp == null) throw new IOException("şəkil açılmadı");

        // EXIF çevrilməsi
        int orient = ExifInterface.ORIENTATION_NORMAL;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in != null) orient = new ExifInterface(in).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
        } catch (Exception ignored) { }
        Matrix m = new Matrix();
        switch (orient) {
            case ExifInterface.ORIENTATION_ROTATE_90: m.postRotate(90); break;
            case ExifInterface.ORIENTATION_ROTATE_180: m.postRotate(180); break;
            case ExifInterface.ORIENTATION_ROTATE_270: m.postRotate(270); break;
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_FLIP_VERTICAL: m.postScale(1, -1); break;
            case ExifInterface.ORIENTATION_TRANSPOSE: m.postRotate(90); m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_TRANSVERSE: m.postRotate(270); m.postScale(-1, 1); break;
            default: break;
        }
        // Kiçiltmə (ölçü həddi)
        float scale = 1f;
        int w = bmp.getWidth(), h = bmp.getHeight();
        int maxSide = Math.max(w, h);
        if (maxSide > MAX_SIDE) scale = Math.min(scale, (float) MAX_SIDE / maxSide);
        if ((long) w * h > MAX_PIXELS) scale = Math.min(scale, (float) Math.sqrt((double) MAX_PIXELS / ((double) w * h)));
        if (scale < 1f) m.postScale(scale, scale);

        if (!m.isIdentity()) {
            Bitmap t = Bitmap.createBitmap(bmp, 0, 0, w, h, m, true);
            if (t != bmp) bmp.recycle();
            bmp = t;
        }
        return bmp;
    }

    /** Yerli (lokal) orta parlaqlığa görə fonu ağ edir, mətni qaraldır. */
    static Bitmap enhance(Bitmap src) {
        final int w = src.getWidth(), h = src.getHeight();
        final int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);

        // boz tonlama
        final byte[] gray = new byte[w * h];
        for (int i = 0; i < px.length; i++) {
            int p = px[i];
            int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
            gray[i] = (byte) ((r * 77 + g * 151 + b * 28) >> 8);
        }

        // inteqral cədvəl (sürətli yerli orta üçün)
        final int W1 = w + 1;
        final int[] integ = new int[W1 * (h + 1)];
        for (int y = 0; y < h; y++) {
            int rowSum = 0;
            int base = (y + 1) * W1, prev = y * W1, gi = y * w;
            for (int x = 0; x < w; x++) {
                rowSum += gray[gi + x] & 255;
                integ[base + x + 1] = integ[prev + x + 1] + rowSum;
            }
        }

        final int r = Math.max(24, Math.min(w, h) / 20);   // pəncərənin yarım ölçüsü
        final float lo = 0.45f, hi = 0.90f;                // bunun altı qara, üstü ağ
        for (int y = 0; y < h; y++) {
            int y0 = Math.max(0, y - r), y1 = Math.min(h - 1, y + r);
            int rowA = y0 * W1, rowB = (y1 + 1) * W1;
            int hh = y1 - y0 + 1;
            for (int x = 0; x < w; x++) {
                int x0 = Math.max(0, x - r), x1 = Math.min(w - 1, x + r);
                int sum = integ[rowB + x1 + 1] - integ[rowA + x1 + 1] - integ[rowB + x0] + integ[rowA + x0];
                int area = hh * (x1 - x0 + 1);
                int g = gray[y * w + x] & 255;
                int v;
                // Sürətli yollar (nəticə eynidir): kağız (g >= 0.90*orta) -> ağ, mürəkkəb (g <= 0.45*orta) -> qara.
                // Yalnız keçid zonasındakı piksellər üçün hamar hesablama aparılır.
                long ga = (long) g * area;
                if (sum >= area && ga * 10 >= 9L * sum) v = 255;
                else if (sum >= area && ga * 20 <= 9L * sum) v = 0;
                else {
                    float mean = (float) sum / area;
                    if (mean < 1f) mean = 1f;
                    float t = (g / mean - lo) / (hi - lo);
                    if (t <= 0f) t = 0f; else if (t >= 1f) t = 1f;
                    v = (int) (t * t * (3f - 2f * t) * 255f + 0.5f);   // hamar keçid
                }
                px[y * w + x] = 0xFF000000 | (v << 16) | (v << 8) | v;
            }
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }
}
