package com.zengyazici

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.*
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var list: LinearLayout
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }.also { root.addView(it) }

        info = TextView(this).apply { textSize = 15f }
        root.addView(TextView(this).apply {
            text = "Yalnız qanunun icazə verdiyi hallarda və qarşı tərəfin xəbəri ilə zəng yazın."
            textSize = 12f
        })
        root.addView(info)
        btn("1. Mikrofon/Telefon icazələri") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Shizuku icazəsi ver") {
            if (!Shizuku.pingBinder()) toast("Shizuku işləmir. Əvvəlcə Shizuku-nu başladın.")
            else if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(100)
            else toast("İcazə artıq var")
        }
        btn("3. Yazını BAŞLAT (avto)") { startForegroundService(Intent(this, CallWatcherService::class.java)); refresh() }
        btn("Yazını DAYANDIR") { stopService(Intent(this, CallWatcherService::class.java)); refresh() }
        btn("Siyahını yenilə") { refresh() }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root, ViewGroup.LayoutParams(-1, -2)) })
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    override fun onResume() { super.onResume(); h.post(object : Runnable { override fun run() { refresh(); h.postDelayed(this, 2000) } }) }
    override fun onPause() { super.onPause(); h.removeCallbacksAndMessages(null) }
    override fun onDestroy() { Shizuku.removeRequestPermissionResultListener(permListener); mp?.release(); super.onDestroy() }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun refresh() {
        val sh = if (!Shizuku.pingBinder()) "işləmir" else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "icazə var" else "icazə yoxdur"
        info.text = "Shizuku: $sh\nVəziyyət: ${CallWatcherService.status}"
        list.removeAllViews()
        CallWatcherService.dir(this).listFiles()?.sortedByDescending { it.name }?.forEach { f ->
            list.addView(Button(this).apply {
                text = "${f.name}  (${f.length() / 1024} KB)\nBas: oxut, uzun bas: sil"
                setOnClickListener {
                    mp?.release()
                    mp = MediaPlayer().apply { setDataSource(f.absolutePath); prepare(); start() }
                }
                setOnLongClickListener { f.delete(); refresh(); true }
            })
        }
    }
}
