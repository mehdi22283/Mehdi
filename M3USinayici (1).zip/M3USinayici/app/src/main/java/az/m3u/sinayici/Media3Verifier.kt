package az.m3u.sinayici

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/**
 * Tester bitəndən sonra 🔴 kanalları səssiz (görüntüsüz) olaraq iki player ilə yenidən yoxlayır:
 *   1) Media3 (ExoPlayer) — bir neçə profil (başlıq dəsti) ilə;
 *   2) Media3 açmasa → LibVLC (bəzi kanallar yalnız VLC-də açılır).
 * Kanal bu ikisindən birində açılırsa (Net.exoOk + 🟢). İKİSİNDƏ də açılmırsa (qoşulma / HTTP status xətası daxil)
 * Net.exoFail çağırılır və kanal 🔴 qalır.
 * Eyni anda PAR (20) kanal paralel yoxlanır; onlardan ən çox VLC_PAR (4)-i VLC mərhələsindədir.
 */
object Media3Verifier {
    private const val PAR = 20
    private const val PAR_OTT = 48          // qrup ▶️ (yalnız Ott) yoxlaması üçün ayrıca paralel limit — standart yoxlamanı yavaşlatmır
    private const val VLC_PAR = 10
    private const val M3_TIMEOUT = 4500L
    private fun ottOnly(t: Int) = t == 3 || t == 4          // qrup ▶️ düyməsi: yalnız Ott (Media3), HTTP və VLC yoxdur
    private fun strictP(t: Int) = t == 2 || t == 3 || t == 4
    private const val STRICT_TAG = 2        // 2-ci playlist: sərt rejim — hər player cəhdi üçün cəmi 3 saniyə gözləmə
    private const val OTT_MS = 5000L        // qrup ▶️ (yalnız Ott): hər cəhd üçün 5 saniyə gözləmə
    private const val STRICT_MS = 3000L      // bu müddətdə video/yayım gəlməsə → növbəti player / 🔴
    private const val STRICT_STABLE = 800L   // VLC: Playing-dən sonra bu qədər xətasız davam etsə işləyir
    private const val M3_STABLE = 2500L   // READY-dən sonra xətasız bu qədər oynamalıdır (IO_UNSPECIFIED kimi gec xətalar tutulsun)
    private const val VLC_TIMEOUT = 6000L
    private const val VLC_STABLE = 1500L   // Playing-dən sonra xətasız bu qədər davam edərsə → işləyir

    private val TS_FLAGS = DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
        DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS

    private class Job(val url: String, val hdr: String, val tag: Int, val done: (Boolean) -> Unit) {
        var player: ExoPlayer? = null
        var timeout: Runnable? = null
        var vlcPlayer: MediaPlayer? = null
        var vlcTimeout: Runnable? = null
        var vlcStable: Runnable? = null
        var vlcCounted = false
        var vlcTargets: List<Net.Target> = emptyList()
        var finished = false
        var modes: List<Boolean>? = null   // Ott-only: HTTP-siz cəhd rejimləri (true = HLS)
        val extra = ArrayList<(Boolean) -> Unit>()   // eyni linkli digər kanallar: bir dəfə yoxlanır, nəticə hamıya verilir
        val key get() = "$tag|$url"
    }

    private val h = Handler(Looper.getMainLooper())
    private val index = HashMap<String, Job>()
    private val queue = ArrayDeque<Job>()
    private val vlcQueue = ArrayDeque<Job>()
    private val active = HashSet<Job>()
    private var vlcRunning = 0
    private var vlcLib: LibVLC? = null
    private var gen = 0

    /** tag = playlist nömrəsi (1/2): iki playlist eyni anda, bir-birini gözlətmədən yoxlanır. */
    fun add(ctx: Context, url: String, hdr: String, tag: Int = 0, done: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        h.post {
            val k = "$tag|$url"
            val ex = index[k]
            if (ex != null && !ex.finished) { ex.extra.add(done); return@post }
            val j = Job(url, hdr, tag, done)
            index[k] = j
            queue.addLast(j); pump(app)
        }
    }

    /** tag verilərsə yalnız o playlistin yoxlaması ləğv olunur, digəri davam edir. */
    fun cancel(tag: Int? = null) {
        h.post {
            if (tag == null) {
                gen++
                queue.clear(); vlcQueue.clear(); index.clear()
                active.toList().forEach { stop(it) }
                active.clear()
            } else {
                queue.removeAll { it.tag == tag }
                index.values.removeAll { it.tag == tag }
                vlcQueue.removeAll { it.tag == tag }
                active.filter { it.tag == tag }.forEach { stop(it); active.remove(it) }
            }
            // boşalan yerlərə digər playlistin növbədəki kanalları keçir
            pumpLater()
        }
    }

    private var appCtx: Context? = null
    private fun pumpLater() { appCtx?.let { pump(it); pumpVlc(it) } }

    /** Növbədən növbəti kanalı seç: aktiv işi ən az olan playlistdən (ədalətli bölgü). */
    private fun nextJob(otherOk: Boolean, ottOk: Boolean): Job? {
        val cand = queue.filter { if (ottOnly(it.tag)) ottOk else otherOk }
        if (cand.isEmpty()) return null
        val tags = cand.map { it.tag }.distinct()
        val best = tags.minByOrNull { t -> active.count { it.tag == t } } ?: return null
        val j = cand.first { it.tag == best }
        queue.remove(j)
        return j
    }

    private fun releaseVlcPlayer(j: Job) {
        j.vlcTimeout?.let { h.removeCallbacks(it) }; j.vlcTimeout = null
        j.vlcStable?.let { h.removeCallbacks(it) }; j.vlcStable = null
        val vp = j.vlcPlayer; j.vlcPlayer = null
        if (vp != null) Thread {   // stop/release bloklaya bilər → fon axınında
            try { vp.setEventListener(null); vp.stop() } catch (e: Exception) { }
            try { vp.release() } catch (e: Exception) { }
        }.start()
    }

    private fun stop(j: Job) {
        j.finished = true
        j.timeout?.let { h.removeCallbacks(it) }; j.timeout = null
        val p = j.player; j.player = null
        if (p != null) h.post { try { p.release() } catch (e: Exception) { } }
        releaseVlcPlayer(j)
        vlcQueue.remove(j)
        if (j.vlcCounted) { j.vlcCounted = false; vlcRunning-- }
    }

    private fun pump(app: Context) {
        appCtx = app
        while (true) {
            val ottActive = active.count { ottOnly(it.tag) }
            val j = nextJob(active.size - ottActive < PAR, ottActive < PAR_OTT) ?: return
            active.add(j)
            val my = gen
            Thread {
                val all = Net.profiles(j.url, j.hdr)
                // Media3: ilk 2 profil + sonuncu (Chrome+Referer) — "okhttp" kimi aralıqdakılar atılır ki, yoxlama uzanmasın
                var m3 = if (all.size <= 3) all else listOf(all[0], all[1], all.last())
                if (j.tag == STRICT_TAG) m3 = listOf(all[0])   // sərt rejim: yalnız ən yaxşı profil
                // VLC: VLC-UA profili + Chrome profili
                var vl = listOfNotNull(all.firstOrNull { it.name == "VLC" }, all.lastOrNull()).distinctBy { it.name }
                // 2-ci playlist (VLC, hər cəhd 3 san): 🔴 yalnız İKİ fərqli profildə (VLC-UA və Chrome+Referer) yayım gəlməyəndə verilir
                if (ottOnly(j.tag)) {
                    val path = try { Uri.parse(all[0].url).path?.lowercase() ?: "" } catch (e: Exception) { "" }
                    val modes: List<Boolean> = when {
                        path.endsWith(".m3u8") || path.endsWith(".m3u") -> listOf(true)
                        path.endsWith(".ts") || path.endsWith(".mp4") || path.endsWith(".mkv") || path.endsWith(".flv") ||
                            path.endsWith(".aac") || path.endsWith(".mp3") -> listOf(false)
                        else -> listOf(false, true)
                    }
                    // 🔴 təsdiqi: eyni rejimlər ikinci dəfə fərqli (Chrome+Referer) profillə təkrarlanır
                    val twoPass = if (all.size > 1) modes + modes else modes
                    j.modes = twoPass
                    m3 = modes.map { all[0] } + (if (all.size > 1) modes.map { all.last() } else emptyList())
                    vl = emptyList()
                }
                h.post {
                    if (my == gen && !j.finished) {
                        j.vlcTargets = vl
                        if (j.tag == STRICT_TAG) toVlc(app, j, my)   // 2-ci playlist: yalnız VLC ilə yoxlanır (Media3 atlanır)
                        else attempt(app, j, m3, 0, my)
                    }
                }
            }.start()
        }
    }

    private fun end(app: Context, j: Job, ok: Boolean, my: Int) {
        if (j.finished || my != gen) return
        if (!ok && !Net.online(app)) {   // internet yoxdursa nəticə "açılmır" sayılmır: iş bir az sonra yenidən növbəyə qoyulur
            stop(j); active.remove(j); index.remove(j.key)
            val nj = Job(j.url, j.hdr, j.tag, j.done); nj.extra.addAll(j.extra)
            index[nj.key] = nj
            h.postDelayed({ if (my == gen && index[nj.key] === nj) { queue.addLast(nj); pump(app) } }, 3000)
            pump(app); pumpVlc(app)
            return
        }
        stop(j); active.remove(j)
        if (!ottOnly(j.tag)) { if (ok) Net.exoOk(j.url) else if (Net.online(app)) Net.exoFail(j.url) }   // oflayn halda 🔴 yadda saxlanmır
        index.remove(j.key)
        j.done(ok); j.extra.forEach { it(ok) }
        pump(app); pumpVlc(app)
        scheduleIdleRelease()
    }

    // ---------------------------------------------------------------- Media3 mərhələsi
    private fun attempt(app: Context, j: Job, ps: List<Net.Target>, i: Int, my: Int) {
        if (j.finished || my != gen) return
        j.timeout?.let { h.removeCallbacks(it) }; j.timeout = null
        val old = j.player; j.player = null
        if (old != null) try { old.release() } catch (e: Exception) { }
        if (i >= ps.size) { if (ottOnly(j.tag)) end(app, j, false, my) else toVlc(app, j, my); return }    // Media3 açmadı → VLC (Ott-only: 🔴)
        val t = ps[i]
        val fixed = j.modes
        if (fixed != null) { start(app, j, ps, i, t, fixed[i], my); return }   // Ott-only: HTTP sorğusu yoxdur
        Thread {
            val hls = try { quickHls(t) } catch (e: Exception) { false }
            h.post { if (my == gen && !j.finished) start(app, j, ps, i, t, hls, my) }
        }.start()
    }

    /** Uzantıdan bəlli olursa əlavə şəbəkə sorğusu atılmır (sürət); yalnız qeyri-müəyyən linklərdə məzmun yoxlanır. */
    private fun quickHls(t: Net.Target): Boolean {
        val path = try { Uri.parse(t.url).path?.lowercase() ?: "" } catch (e: Exception) { "" }
        if (path.endsWith(".m3u8") || path.endsWith(".m3u")) return true
        if (path.endsWith(".ts") || path.endsWith(".mp4") || path.endsWith(".mkv") || path.endsWith(".flv") ||
            path.endsWith(".aac") || path.endsWith(".mp3")) return false
        return Net.isHls(t)
    }

    private fun start(app: Context, j: Job, ps: List<Net.Target>, i: Int, t: Net.Target, hls: Boolean, my: Int) {
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(if (ottOnly(j.tag)) 5000 else 4000).setReadTimeoutMs(if (ottOnly(j.tag)) 5000 else 4000)
        val ds = ResolvingDataSource.Factory(http, ResolvingDataSource.Resolver { spec -> spec.withAdditionalHeaders(t.headers) })
        val policy = DefaultLoadErrorHandlingPolicy(if (ottOnly(j.tag)) 0 else 1)   // xətada uzun təkrar cəhdlər yoxdur → tez nəticə
        val msf: MediaSource.Factory = if (hls)
            HlsMediaSource.Factory(ds)
                .setExtractorFactory(DefaultHlsExtractorFactory(TS_FLAGS, true))
                .setLoadErrorHandlingPolicy(policy)
        else
            DefaultMediaSourceFactory(ds, DefaultExtractorsFactory().setTsExtractorFlags(TS_FLAGS).setConstantBitrateSeekingEnabled(true))
                .setLoadErrorHandlingPolicy(policy)
        // Kiçik bufer həddi: kanal ilk saniyələr yüklənən kimi READY olur (defolt 2.5 san gözləmir)
        val ott = ottOnly(j.tag)
        val lc = if (ott) DefaultLoadControl.Builder().setBufferDurationsMs(1000, 2000, 300, 500).build()
                 else DefaultLoadControl.Builder().setBufferDurationsMs(1500, 3000, 500, 1000).build()
        val pb = ExoPlayer.Builder(app, DefaultRenderersFactory(app).setEnableDecoderFallback(true))
            .setLoadControl(lc)
            .setMediaSourceFactory(msf)
        val p = pb.build()
        p.volume = 0f
        j.player = p
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && j.player === p && !strictP(j.tag)) {
                    // Dərhal 🟢 yox: bir müddət oynamalıdır. Xəta gəlsə (onPlayerError) və ya dayansa → növbəti profil / VLC
                    j.timeout?.let { h.removeCallbacks(it) }
                    var rechecked = false
                    lateinit var chk: Runnable
                    chk = Runnable {
                        if (j.player !== p || j.finished || my != gen) return@Runnable
                        if (p.playbackState == Player.STATE_READY && p.isPlaying) { Net.markGood(t.url, t.name); end(app, j, true, my) }
                        else if (!rechecked) { rechecked = true; j.timeout = chk; h.postDelayed(chk, M3_STABLE) }
                        else attempt(app, j, ps, i + 1, my)
                    }
                    j.timeout = chk
                    h.postDelayed(chk, M3_STABLE)
                }
            }
            override fun onPlayerError(e: PlaybackException) {
                if (j.player === p) attempt(app, j, ps, i + 1, my)
            }
        })
        if (strictP(j.tag)) {
            // Sərt rejim: 3 saniyə ərzində yayım həqiqətən oynamalıdır (oynayır + ən azı 0.5 san irəliləyib), əks halda növbəti cəhd
            val t0 = SystemClock.uptimeMillis()
            lateinit var poll: Runnable
            poll = Runnable {
                if (j.player !== p || j.finished || my != gen) return@Runnable
                if (p.playbackState == Player.STATE_READY && p.isPlaying && p.currentPosition >= (if (ottOnly(j.tag)) 300 else 500)) { Net.markGood(t.url, t.name); end(app, j, true, my) }
                else if (SystemClock.uptimeMillis() - t0 >= (if (ottOnly(j.tag)) OTT_MS else STRICT_MS)) attempt(app, j, ps, i + 1, my)
                else { j.timeout = poll; h.postDelayed(poll, 100) }
            }
            j.timeout = poll
            h.postDelayed(poll, 100)
        } else {
            val tm = Runnable { if (j.player === p) attempt(app, j, ps, i + 1, my) }
            j.timeout = tm
            h.postDelayed(tm, M3_TIMEOUT)
        }
        val mi = MediaItem.Builder().setUri(t.url)
        if (hls) mi.setMimeType(MimeTypes.APPLICATION_M3U8)
        p.setMediaItem(mi.build()); p.prepare(); p.playWhenReady = true
    }

    // ---------------------------------------------------------------- VLC mərhələsi
    private fun toVlc(app: Context, j: Job, my: Int) {
        if (j.finished || my != gen) return
        if (j.vlcTargets.isEmpty()) { end(app, j, false, my); return }
        vlcQueue.addLast(j)
        pumpVlc(app)
    }

    private fun pumpVlc(app: Context) {
        while (vlcRunning < VLC_PAR) {
            val j = vlcQueue.removeFirstOrNull() ?: return
            if (j.finished) continue
            vlcRunning++; j.vlcCounted = true
            vlcAttempt(app, j, 0, gen)
        }
    }

    private fun lib(app: Context): LibVLC {
        vlcLib?.let { return it }
        return LibVLC(app, arrayListOf("--http-reconnect", "--network-caching=1500")).also { vlcLib = it }
    }

    /** Hamısı bitəndən bir müddət sonra LibVLC nümunəsi buraxılır (yaddaş qənaəti). */
    private var idleRel: Runnable? = null
    private fun scheduleIdleRelease() {
        idleRel?.let { h.removeCallbacks(it) }
        val r = Runnable {
            if (vlcRunning == 0 && vlcQueue.isEmpty()) {
                val l = vlcLib; vlcLib = null
                if (l != null) Thread { try { l.release() } catch (e: Exception) { } }.start()
            }
        }
        idleRel = r
        h.postDelayed(r, 20000)
    }

    private fun vlcAttempt(app: Context, j: Job, i: Int, my: Int) {
        if (j.finished || my != gen) return
        releaseVlcPlayer(j)
        if (i >= j.vlcTargets.size) { end(app, j, false, my); return }   // iki player də açmadı → 🔴
        val t = j.vlcTargets[i]
        val mp: MediaPlayer = try {
            val l = lib(app)
            val player = MediaPlayer(l)
            val m = Media(l, Uri.parse(t.url))
            m.addOption(":no-video")
            t.headers["User-Agent"]?.let { m.addOption(":http-user-agent=$it") }
            t.headers["Referer"]?.let { m.addOption(":http-referrer=$it") }
            m.addOption(":network-caching=1500")
            player.setMedia(m)
            m.release()
            player.setVolume(0)
            player
        } catch (e: Throwable) { vlcAttempt(app, j, i + 1, my); return }
        j.vlcPlayer = mp
        var playing = false
        mp.setEventListener(object : MediaPlayer.EventListener {
            override fun onEvent(event: MediaPlayer.Event) {
                val type = event.type
                val tc = if (type == MediaPlayer.Event.TimeChanged) event.timeChanged else 0L
                h.post {
                    if (j.finished || my != gen || j.vlcPlayer !== mp) return@post
                    when (type) {
                        MediaPlayer.Event.Playing -> if (!playing) {
                            playing = true
                            val st = Runnable { if (j.vlcPlayer === mp) { Net.markGood(t.url, t.name); end(app, j, true, my) } }
                            j.vlcStable = st
                            h.postDelayed(st, if (j.tag == STRICT_TAG) STRICT_STABLE else VLC_STABLE)
                        }
                        MediaPlayer.Event.TimeChanged ->
                            if (playing && tc > 0) { Net.markGood(t.url, t.name); end(app, j, true, my) }
                        MediaPlayer.Event.EncounteredError, MediaPlayer.Event.EndReached ->
                            vlcAttempt(app, j, i + 1, my)
                        else -> {}
                    }
                }
            }
        })
        val tm = Runnable { if (j.vlcPlayer === mp) vlcAttempt(app, j, i + 1, my) }
        j.vlcTimeout = tm
        h.postDelayed(tm, if (j.tag == STRICT_TAG) STRICT_MS else VLC_TIMEOUT)
        try { mp.play() } catch (e: Throwable) { vlcAttempt(app, j, i + 1, my) }
    }
}
