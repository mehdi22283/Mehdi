package az.yvok.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String EBEL_URL = "https://e-belediyye.gov.az/tax-debts";
    private static final Pattern CODE = Pattern.compile("^10011[A-Z0-9]{7}$");
    private static final Pattern NAME_OK = Pattern.compile("^[\\p{L}\\s.'\\-]{3,100}$");
    private static final Pattern DEBT_OK = Pattern.compile("^(\\d{1,9}(\\.\\d{1,2})?)?$");
    private static final int REQ_OCR = 7001;
    private static final int REQ_CONTACT = 7002;
    private static final int CV_MAX = 33;   // gündəlik Cloud Vision sorğu limiti (sayğac)
    // OCR səhvlərinə tolerant: 1/I/L/| və 0/O/Q/D qarışıqlığı "10011" prefiksində düzəldilir,
    // sonrakı 7 simvol isə mövqeyə görə normallaşdırılır (bax: fixOcrTail)
    private static final Pattern OCR_CODE = Pattern.compile("[1IL|!][0OQD][0OQD][1IL|!][1IL|!]([A-Z0-9|!]{7,8})");
    private static final int MAX_JOBS_PER_VIEW = 10;   // bu qədər sorğudan sonra gizli WebView təzələnir (yavaşlama yığılmasın)
    private static final int LOAD_LIMIT_MS = 4500;     // ilkin kod üçün maksimum gözləmə (sayt gec cavab verəndə düzgün kod "tapılmadı" olmasın)
    private static final int VARIANT_LIMIT_MS = 2000;  // variant kodlar üçün qısa gözləmə
    private static final int PAGE_GUARD_MS = 8000;     // səhifənin özü açılmasa ümumi qoruyucu
    private static final int MAX_WORKERS = 6;   // toplu yoxlama üçün paralel gizli səhifə sayı

    private static class Job {
        final String code;          // hazırda yoxlanılan kod (O/Q variantı ola bilər)
        final String orig;          // istifadəçinin siyahısındakı ilkin kod
        final boolean batch;
        int pageRetries = 0;        // səhifə açılmadığı üçün neçə dəfə təkrar başladılıb
        ArrayDeque<String> variants = null;   // yoxlanılmamış O/Q/I variantları (ilk "tapılmadı"dan sonra qurulur)
        Group grp = null;                     // variant sorğuları eyni qrupda paralel yoxlanılır
        Job(String code, boolean batch) { this.code = code; this.orig = code; this.batch = batch; }
        Job(String code, Job from) { this.code = code; this.orig = from.orig; this.batch = from.batch; this.variants = from.variants; }
    }

    // Bir kodun variantları: boş işçilərdə PARALEL yoxlanılır, ilk tapılan nəticə qazanır, qalanları ləğv olunur
    private static class Group {
        final Job root;       // istifadəçinin siyahısındakı ilkin sorğu
        int left;             // hələ "tapılmadı" deməyən variant sayı
        boolean done = false; // nəticə tapılıb və ya hamısı uğursuz olub
        Group(Job root) { this.root = root; }
    }

    // Hər Worker = e-belediyye.gov.az açıq olan bir gizli WebView (ui-nin ARXASINDA işləyir)
    private class Worker {
        WebView wv;                       // köhnələndə yenisi ilə əvəz olunur
        int jobs = 0;                     // bu WebView neçə sorğu emal edib
        boolean loaded = false;
        String pending = null;
        Job current = null;
        final Runnable watchdog = () -> onWatchdog(this);
    }

    private FrameLayout root;
    private WebView ui;
    private String injectJs;
    private Worker single;                                   // yalnız YVÖK xanası (mesaj göndərmə) üçün
    private final ArrayList<Worker> pool = new ArrayList<>(); // yalnız toplu yoxlama üçün
    private final ArrayDeque<Job> batchJobs = new ArrayDeque<>();
    private Uri cameraUri = null;
    private TextRecognizer mlRec = null;

    private synchronized TextRecognizer recognizer() {
        if (mlRec == null) mlRec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        return mlRec;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mlRec != null) { mlRec.close(); mlRec = null; }
    }
    private int maxWorkers = MAX_WORKERS;   // güclü cihazlarda daha çox paralel gizli səhifə
    private String ocrEngine = "mlkit";   // "mlkit" və ya "cloud"
    private String cvKey = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        injectJs = readAsset("inject.js");
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null && am.getMemoryClass() >= 256) maxWorkers = MAX_WORKERS + 2;
        } catch (Throwable ignored) { }
        clearOcrCache();                      // əvvəlki sessiyadan qalan kamera şəkilləri

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ui = new WebView(this);
        ui.setBackgroundColor(Color.BLACK);
        ui.setFocusable(true);
        ui.setFocusableInTouchMode(true);
        root.addView(ui, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        setupCommon(ui);

        // ---- Yuxarı: öz səhifəmiz (assets/index.html) ----
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        ui.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                ui.requestFocus();
                ui.evaluateJavascript("document.getElementById('phone-input').focus();", null);
                ui.postDelayed(() -> {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(ui, InputMethodManager.SHOW_IMPLICIT);
                }, 350);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {                                   // whatsapp:// və xarici linklər
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Tətbiq tapılmadı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        ui.addJavascriptInterface(new Object() {
            // YVÖK xanası (mesaj göndərmə): yalnız öz gizli səhifəsini sıfırlayır
            @JavascriptInterface
            public void reset() {
                runOnUiThread(() -> recycle(single));
            }

            @JavascriptInterface
            public void fill(String code) {
                final String v = "10011" + (code == null ? "" : code.toUpperCase());
                if (!CODE.matcher(v).matches()) return;
                runOnUiThread(() -> {
                    if (single.current != null) recycle(single);   // əvvəlki sorğunu ləğv et
                    status("loading");
                    start(single, new Job(v, false));
                });
            }

            // Konkret Whatsapp (və ya Business) tətbiqinə yönləndir
            @JavascriptInterface
            public void openWa(String phone, String text, boolean business) {
                final String pkg = business ? "com.whatsapp.w4b" : "com.whatsapp";
                final String url = "whatsapp://send?phone=994" + phone
                        + ((text != null && !text.isEmpty()) ? "&text=" + Uri.encode(text) : "");
                runOnUiThread(() -> {
                    try {
                        Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        it.setPackage(pkg);
                        startActivity(it);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this,
                                business ? "Whatsapp Business tapılmadı" : "Whatsapp tapılmadı",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }

            // Kontaktlar siyahısını aç (icazə tələb etmir: yalnız seçilən kontaktın nömrəsi oxunur)
            @JavascriptInterface
            public void pickContact() {
                runOnUiThread(() -> {
                    try {
                        Intent it = new Intent(Intent.ACTION_PICK,
                                android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                        startActivityForResult(it, REQ_CONTACT);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Kontaktlar tətbiqi tapılmadı", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            // Android mesajlaşma (SMS) tətbiqinə yönləndir
            @JavascriptInterface
            public void openSms(String phone, String text) {
                runOnUiThread(() -> {
                    try {
                        Intent it = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:+994" + phone));
                        it.putExtra("sms_body", text == null ? "" : text);
                        startActivity(it);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Mesajlaşma tətbiqi tapılmadı", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            // YVÖK xanasına fokus verildikdə klaviaturanı aç
            @JavascriptInterface
            public void kbd() {
                runOnUiThread(() -> {
                    ui.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(ui, InputMethodManager.SHOW_IMPLICIT);
                });
            }

            // Toplu yoxlama səhifələrini əvvəlcədən hazırla ("Şəkildən oxu" basılanda)
            @JavascriptInterface
            public void warm() {
                runOnUiThread(() -> { recognizer(); while (pool.size() < maxWorkers) createWorker(true); });
            }

            // Toplu yoxlama: vergüllə ayrılmış tam kodlar (10011XXXXXXX)
            @JavascriptInterface
            public void batch(String csv) { enqueueBatch(csv, false); }

            // Əllə redaktə olunan kod: heç bir variant/kombinasiya yoxlanmır, yalnız həmin kod yoxlanılır
            @JavascriptInterface
            public void batchExact(String csv) { enqueueBatch(csv, true); }

            private void enqueueBatch(String csv, final boolean exact) {
                if (csv == null) return;
                final String[] parts = csv.split(",");
                runOnUiThread(() -> {
                    for (String c : parts) {
                        c = c.trim().toUpperCase();
                        if (!CODE.matcher(c).matches()) continue;
                        boolean dup = false;
                        for (Worker w : pool) {
                            if (w.current != null && (w.current.code.equals(c) || w.current.orig.equals(c))) { dup = true; break; }
                        }
                        if (!dup) for (Job j : batchJobs) if (j.code.equals(c)) { dup = true; break; }
                        if (!dup) {
                            Job nj = new Job(c, true);
                            if (exact) nj.variants = new ArrayDeque<>();   // boş növbə: variant qurulmur
                            batchJobs.addLast(nj);
                        }
                    }
                    pumpBatch();
                });
            }

            // Şəkildən kod oxu: kamera və ya qalereya
            @JavascriptInterface
            public void ocr(String engine, String key) {
                final String eng = "cloud".equals(engine) ? "cloud" : "mlkit";
                final String k = key == null ? "" : key.trim();
                runOnUiThread(() -> {
                    ocrEngine = eng;
                    cvKey = k;
                    if ("cloud".equals(eng) && cvLeft() <= 0) {
                        toast("Cloud Vision limiti bitib (0/" + CV_MAX + "), ML Kit ilə oxunacaq");
                        ocrEngine = "mlkit";
                    }
                    openOcrChooser();
                });
            }

            // Qalan Cloud Vision sorğu sayı
            @JavascriptInterface
            public int cvLeft() {
                return MainActivity.this.cvLeft();
            }

            @JavascriptInterface
            public void batchStop() {
                runOnUiThread(() -> {
                    batchJobs.clear();
                    for (Worker w : pool) {
                        if (w.current != null) recycle(w);
                        else if (!w.loaded && w.wv != null) { w.wv.stopLoading(); w.wv.loadUrl(EBEL_URL); }   // ilişib qalmış boş səhifəni təzələ
                    }
                });
            }
        }, "Android");
        ui.loadUrl("https://" + HOST + "/assets/index.html");

        // ---- Aşağı: e-belediyye.gov.az (gizli WebView-lar) ----
        single = createWorker(false);
    }

    // ---------------- OCR ----------------
    private void openOcrChooser() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        Intent chooser = Intent.createChooser(pick, "Şəkil seçin");
        cameraUri = null;
        try {
            File dir = new File(getCacheDir(), "ocr");
            dir.mkdirs();
            File f = new File(dir, "cam_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("", cameraUri));
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        } catch (Exception e) {
            cameraUri = null;   // kamera olmasa yalnız qalereya
        }
        try {
            startActivityForResult(chooser, REQ_OCR);
        } catch (Exception e) {
            toast("Şəkil seçmək mümkün olmadı");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CONTACT) {
            if (res != RESULT_OK || data == null || data.getData() == null) return;
            try (android.database.Cursor c = getContentResolver().query(data.getData(),
                    new String[]{android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String num = c.getString(0);
                    ui.evaluateJavascript("window.setPhoneFromContact(" + JSONObject.quote(num == null ? "" : num) + ");", null);
                }
            } catch (Exception e) {
                toast("Nömrəni oxumaq mümkün olmadı");
            }
            return;
        }
        if (req != REQ_OCR) return;
        if (res != RESULT_OK) { clearOcrCache(); return; }
        ArrayList<Uri> uris = new ArrayList<>();
        if (data != null && data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) uris.add(u);
            }
        } else if (data != null && data.getData() != null) {
            uris.add(data.getData());
        } else if (cameraUri != null) {
            uris.add(cameraUri);      // kamera çəkilişi
        }
        if (uris.isEmpty()) return;
        runOcr(uris);
    }

    // Hər şəkil əvvəlcə "sənəd skan" effektinə çevrilir (DocEnhance), sonra oxunur.
    // Effektli şəkildə kod tapılmasa, orijinal şəkil də yoxlanılır.
    // Şəkillər PARALEL oxunur (sürət üçün), nəticələr seçilmə sırasına görə birləşdirilir
    private void runOcr(ArrayList<Uri> uris) {
        toast("Şəkil oxunur…");
        final TextRecognizer rec = recognizer();   // bir dəfə yaradılır, hər oxumada təkrar yüklənmir
        final int n = uris.size();
        final ArrayList<ArrayList<String>> res = new ArrayList<>();
        for (int i = 0; i < n; i++) res.add(null);
        final int[] left = {n};
        final boolean cloud = "cloud".equals(ocrEngine) && !cvKey.isEmpty();
        final int avail = cloud ? cvLeft() : 0;      // qalan limit qədər şəkil Cloud Vision ilə, artığı ML Kit ilə
        if (cloud && n > avail) toast("Limit çatmır: ilk " + avail + " şəkil Cloud Vision, qalanı ML Kit ilə oxunur");
        for (int i = 0; i < n; i++) {
            final int idx = i;
            final Uri uri = uris.get(i);
            if (cloud && i < avail) {
                new Thread(() -> cloudOcr(rec, uri, idx, res, left)).start();
                continue;
            }
            mlkitMulti(rec, uri, idx, res, left);
        }
    }

    // ---------------- Cloud Vision ----------------
    private SharedPreferences cvPrefs() { return getSharedPreferences("cv", MODE_PRIVATE); }

    private static String today() { return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()); }

    // Qalan sorğu sayı: hər gün yenidən CV_MAX olur
    private synchronized int cvLeft() {
        SharedPreferences p = cvPrefs();
        if (!today().equals(p.getString("day", ""))) {
            p.edit().putString("day", today()).putInt("used", 0).apply();
            return CV_MAX;
        }
        return Math.max(0, CV_MAX - p.getInt("used", 0));
    }

    private synchronized void cvSetUsed(int used) {
        cvPrefs().edit().putString("day", today()).putInt("used", Math.max(0, Math.min(CV_MAX, used))).apply();
        final int left = cvLeft();
        runOnUiThread(() -> ui.evaluateJavascript("window.setCvLeft(" + left + ");", null));
    }

    private synchronized void cvUsedOne() { cvSetUsed(CV_MAX - cvLeft() + 1); }

    // Bir şəkil = bir Cloud Vision sorğusu (DOCUMENT_TEXT_DETECTION). Xəta olarsa ML Kit-ə keçilir.
    private void cloudOcr(final TextRecognizer rec, final Uri uri, final int idx,
                          final ArrayList<ArrayList<String>> res, final int[] left) {
        final ArrayList<String> found = new ArrayList<>();
        String err = null;
        try {
            Bitmap bmp = DocEnhance.load(this, uri);
            // Cloud Vision-a bütün səhifə əvəzinə kod sütununun böyüdülmüş, solğun yazıları gücləndirilmiş hissəsi göndərilir.
            // Bu, ad/telefon/məbləğ sütunlarının qarışmasını azaldır və OCR üçün simvolları böyüdür.
            float[] stripScale = {1f};
            Bitmap strip = targetCodeStrip(bmp, stripScale);
            bmp.recycle();
            Bitmap inkClean = DocEnhance.suppressBlueInk(strip);
            strip.recycle();
            Bitmap cloudImage = DocEnhance.enhance(inkClean, 0.82f, 0.99f);
            inkClean.recycle();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            cloudImage.compress(Bitmap.CompressFormat.JPEG, 95, bos);
            cloudImage.recycle();
            String b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);

            JSONObject image = new JSONObject().put("content", b64);
            JSONObject feat = new JSONObject().put("type", "DOCUMENT_TEXT_DETECTION");
            JSONObject req = new JSONObject().put("image", image).put("features", new JSONArray().put(feat));
            byte[] body = new JSONObject().put("requests", new JSONArray().put(req)).toString().getBytes("UTF-8");

            URL url = new URL("https://vision.googleapis.com/v1/images:annotate?key=" + URLEncoder.encode(cvKey, "UTF-8"));
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            try (OutputStream os = c.getOutputStream()) { os.write(body); }
            int code = c.getResponseCode();
            InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream rb = new ByteArrayOutputStream();
            if (is != null) {
                byte[] buf = new byte[8192];
                int r;
                while ((r = is.read(buf)) > 0) rb.write(buf, 0, r);
                is.close();
            }
            String txt = rb.toString("UTF-8");
            if (code == 200) {
                cvUsedOne();
                JSONObject first = new JSONObject(txt).getJSONArray("responses").getJSONObject(0);
                if (first.has("error")) {
                    err = first.getJSONObject("error").optString("message", "Cloud Vision xətası");
                } else {
                    JSONObject fta = first.optJSONObject("fullTextAnnotation");
                    String text = fta == null ? "" : fta.optString("text", "");
                    ArrayList<String> colLines = null;
                    try { colLines = cloudColumnLines(fta); } catch (Throwable ignored) { }
                    // Sütun etibarlı müəyyən edilməyibsə, bütün səhifə mətnini oxuyub siyahıya qatma.
                    // Boş nəticədə aşağıda ML Kit-in hədəf-sütun skanı işə düşəcək.
                    if (colLines != null) {
                        for (String line : colLines) found.addAll(lineCodes(line.toUpperCase()));
                    }
                }
            } else {
                String msg = "";
                try { msg = new JSONObject(txt).getJSONObject("error").optString("message", ""); } catch (Exception ignored) { }
                if (code == 429) { cvSetUsed(CV_MAX); err = "Google Cloud Vision limiti dolub"; }
                else if (code == 400 && msg.toLowerCase(Locale.ROOT).contains("api key")) err = "Cloud Vision API açarı yanlışdır";
                else if (code == 403) err = "Cloud Vision API açarı icazəsizdir və ya Cloud Vision API aktiv deyil";
                else err = "Cloud Vision xətası (" + code + ")" + (msg.isEmpty() ? "" : ": " + msg);
            }
        } catch (Throwable t) {
            err = "Cloud Vision-a qoşulmaq mümkün olmadı";
        }
        final String e = err;
        runOnUiThread(() -> {
            if (e != null) toast(e);
            // Cloud Vision heç nə qaytarmayıbsa, hədəf sütunu böyüdən çoxkeçidli ML Kit skanına keç.
            if (found.isEmpty()) { mlkitMulti(rec, uri, idx, res, left); return; }
            // Cloud Vision nəticəsini böyüdülmüş yerli skanla da müqayisə et; daha çox sətir tapılan nəticəni seç.
            mlkitSupplement(rec, uri, idx, res, left, found);
        });
    }

    // Cloud Vision: sözləri qutularına görə sütuna süzür və sətirlərə yığır; sütun tapılmasa null qaytarır
    private ArrayList<String> cloudColumnLines(JSONObject fta) throws Exception {
        if (fta == null) return null;
        ArrayList<String> wt = new ArrayList<>();
        ArrayList<int[]> wb = new ArrayList<>();   // {sol, sağ, yuxarı, aşağı, sətir sonu?1:0}
        JSONArray pages = fta.optJSONArray("pages");
        if (pages == null) return null;
        for (int a = 0; a < pages.length(); a++) {
            JSONArray blocks = pages.getJSONObject(a).optJSONArray("blocks");
            if (blocks == null) continue;
            for (int b = 0; b < blocks.length(); b++) {
                JSONArray paras = blocks.getJSONObject(b).optJSONArray("paragraphs");
                if (paras == null) continue;
                for (int c = 0; c < paras.length(); c++) {
                    JSONArray words = paras.getJSONObject(c).optJSONArray("words");
                    if (words == null) continue;
                    for (int d = 0; d < words.length(); d++) {
                        JSONObject w = words.getJSONObject(d);
                        JSONArray syms = w.optJSONArray("symbols");
                        JSONArray vs = w.getJSONObject("boundingBox").optJSONArray("vertices");
                        if (syms == null || vs == null || vs.length() == 0) continue;
                        StringBuilder sb = new StringBuilder();
                        boolean eol = false;
                        for (int k = 0; k < syms.length(); k++) {
                            JSONObject sy = syms.getJSONObject(k);
                            sb.append(sy.optString("text", ""));
                            JSONObject pr = sy.optJSONObject("property");
                            JSONObject br = pr == null ? null : pr.optJSONObject("detectedBreak");
                            if (br != null) {
                                String ty = br.optString("type", "");
                                if (ty.equals("EOL_SURE_SPACE") || ty.equals("LINE_BREAK")) eol = true;
                            }
                        }
                        int l = Integer.MAX_VALUE, r = Integer.MIN_VALUE, tp = Integer.MAX_VALUE, bt = Integer.MIN_VALUE;
                        for (int k = 0; k < vs.length(); k++) {
                            JSONObject v = vs.getJSONObject(k);
                            int x = v.optInt("x", 0), y = v.optInt("y", 0);
                            l = Math.min(l, x); r = Math.max(r, x); tp = Math.min(tp, y); bt = Math.max(bt, y);
                        }
                        wt.add(sb.toString().toUpperCase());
                        wb.add(new int[]{l, r, tp, bt, eol ? 1 : 0});
                    }
                }
            }
        }
        ArrayList<Integer> ls = new ArrayList<>(), ws = new ArrayList<>();
        for (int i = 0; i < wt.size(); i++)
            if (OCR_CODE.matcher(wt.get(i)).find()) { ls.add(wb.get(i)[0]); ws.add(wb.get(i)[1] - wb.get(i)[0]); }
        if (ls.isEmpty()) return null;
        Collections.sort(ls); Collections.sort(ws);
        int medL = ls.get(ls.size() / 2), medW = Math.max(1, ws.get(ws.size() / 2));
        float cl = medL - 0.35f * medW, cr = medL + 1.35f * medW;   // sütunun üfüqi aralığı
        ArrayList<String> lines = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i < wt.size(); i++) {
            int[] q = wb.get(i);
            float cx = (q[0] + q[1]) / 2f;
            if (cx >= cl && cx <= cr) { if (cur.length() > 0) cur.append(' '); cur.append(wt.get(i)); }
            if (q[4] == 1) { if (cur.length() > 0) lines.add(cur.toString()); cur.setLength(0); }
        }
        if (cur.length() > 0) lines.add(cur.toString());
        return lines;
    }

    // ---------------- ML Kit: çoxkeçidli oxuma ----------------
    // Hər şəkil bir neçə həssaslıqda oxunur: adi, solğun, çox solğun (DocEnhance) və orijinal.
    // Hər effektli şəkil həm bütöv, həm də 10011 sütunu kəsilib böyüdülmüş halda oxunur.
    // Nəticələr cərgə mövqeyinə görə birləşdirilir: eyni cərgədə fərqli oxunuşlar olsa səsvermə ilə seçilir,
    // yalnız bir keçiddə görünən (solğun) kod isə itmir.
    private static final class Hit {
        final String code; final float y; final int pass; final boolean partial;
        Hit(String code, float y, int pass) { this.code = code; this.y = y; this.pass = pass; this.partial = code.startsWith("~"); }
    }

    private void mlkitMulti(final TextRecognizer rec, final Uri uri, final int idx,
                            final ArrayList<ArrayList<String>> res, final int[] left) {
        new Thread(() -> {
            ArrayList<String> r = new ArrayList<>();
            try { r = multiPass(rec, uri); } catch (Throwable ignored) { }
            final ArrayList<String> fr = r;
            runOnUiThread(() -> ocrImgDone(rec, fr, idx, res, left));
        }).start();
    }

    private void mlkitSupplement(final TextRecognizer rec, final Uri uri, final int idx,
                                 final ArrayList<ArrayList<String>> res, final int[] left,
                                 final ArrayList<String> cloudFound) {
        new Thread(() -> {
            ArrayList<String> localFound = new ArrayList<>();
            try { localFound = multiPass(rec, uri); } catch (Throwable ignored) { }
            // Eyni sayda sətirdə Cloud Vision üstün tutulur; lokal OCR yalnız əlavə sətir taparsa seçilir.
            final ArrayList<String> chosen = localFound.size() > cloudFound.size() ? localFound : cloudFound;
            runOnUiThread(() -> ocrImgDone(rec, chosen, idx, res, left));
        }).start();
    }

    private static Text runRec(TextRecognizer rec, Bitmap bmp) {
        try { return Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)), 40, TimeUnit.SECONDS); }
        catch (Throwable e) { return null; }
    }

    private static final class PassOut {
        final ArrayList<Hit> hits = new ArrayList<>();
        final ArrayList<Float> lineHs = new ArrayList<>();
        int pass;
    }

    // kind: 0 = effektli (a,b), 1 = orijinal, 2 = yerli kontrast (a), 3 = fon-müstəqil (a,b), 4 = tərs boz
    private PassOut onePass(TextRecognizer rec, Bitmap bmp, int kind, float a, float b, int pass, float H) {
        PassOut po = new PassOut();
        po.pass = pass;
        try {
            if (kind == 1) {
                collectHits(runRec(rec, bmp), po.hits, pass, 0f, 1f, H, po.lineHs);
                return po;
            }
            Bitmap enh = null;
            try {
                if (kind == 0) enh = DocEnhance.enhance(bmp, a, b);
                else if (kind == 2) enh = DocEnhance.enhanceLocal(bmp, a);
                else if (kind == 3) enh = DocEnhance.enhanceBg(bmp, a, b);
                else enh = DocEnhance.invertGray(bmp);
            } catch (Throwable ignored) { }
            if (enh != null) {
                readEnhanced(rec, enh, po.hits, pass, kind == 2 ? enh.getHeight() : H, po.lineHs);
                enh.recycle();
            }
        } catch (Throwable ignored) { }
        return po;
    }

    // Keçidləri paralel işlədir (effekt hesablaması ML Kit oxuması ilə üst-üstə düşür); nəticələr keçid sırası ilə qaytarılır
    private ArrayList<PassOut> runPasses(final TextRecognizer rec, final Bitmap bmp, final float H, final float[][] specs) {
        ArrayList<PassOut> outs = new ArrayList<>();
        java.util.concurrent.ExecutorService ex = java.util.concurrent.Executors.newFixedThreadPool(2);
        try {
            ArrayList<java.util.concurrent.Future<PassOut>> fs = new ArrayList<>();
            for (final float[] sp : specs) {
                fs.add(ex.submit(() -> onePass(rec, bmp, (int) sp[0], sp[1], sp[2], (int) sp[3], H)));
            }
            for (java.util.concurrent.Future<PassOut> f : fs) {
                try { outs.add(f.get()); } catch (Throwable ignored) { }
            }
        } finally { ex.shutdown(); }
        return outs;
    }

    // Sürətli mərhələ kifayətdirmi: bütün cərgələr tam kodlu, hər biri ən azı iki dəfə oxunub, cərgələr arasında boşluq (itmiş solğun cərgə) yoxdur
    private boolean confident(ArrayList<Hit> hits, ArrayList<Float> lineHs, ArrayList<String> out, ArrayList<Float> ys) {
        if (out.isEmpty()) return false;
        for (String c : out) if (c.startsWith("~")) return false;
        int full = 0;
        for (Hit h : hits) if (!h.partial) full++;
        if (full < 2 * out.size()) return false;
        if (ys.size() >= 3) {
            ArrayList<Float> gaps = new ArrayList<>();
            for (int i = 1; i < ys.size(); i++) gaps.add(ys.get(i) - ys.get(i - 1));
            ArrayList<Float> sg = new ArrayList<>(gaps);
            Collections.sort(sg);
            float med = sg.get(sg.size() / 2);
            for (float g : gaps) if (med > 0f && g > 1.7f * med) return false;
        }
        return true;
    }

    private ArrayList<String> multiPass(TextRecognizer rec, Uri uri) throws Exception {
        Bitmap bmp = DocEnhance.load(this, uri);
        final float H = bmp.getHeight();
        ArrayList<Hit> hits = new ArrayList<>();
        ArrayList<Float> lineHs = new ArrayList<>();
        ArrayList<String> out;

        // Mərhələ A: adi effekt + orijinal.
        ArrayList<PassOut> a = runPasses(rec, bmp, H, new float[][]{{0, 0.45f, 0.90f, 0}, {1, 0, 0, 6}});
        for (PassOut po : a) { hits.addAll(po.hits); lineHs.addAll(po.lineHs); }
        ArrayList<Float> ysA = new ArrayList<>();
        out = mergeHits(new ArrayList<>(hits), new ArrayList<>(lineHs), ysA);
        boolean needDeepPasses = !confident(hits, lineHs, out, ysA);

        // Mərhələ B/C: yalnız ilkin oxunuş əmin deyilsə, digər adaptiv kontrast variantları.
        if (needDeepPasses) {
            ArrayList<PassOut> bs = runPasses(rec, bmp, H, new float[][]{
                    {0, 0.70f, 0.97f, 2}, {0, 0.82f, 0.99f, 4}, {2, 0.55f, 0, 7}, {2, 0.35f, 0, 9}});
            for (PassOut po : bs) { hits.addAll(po.hits); lineHs.addAll(po.lineHs); }
            ArrayList<Float> ys = new ArrayList<>();
            out = mergeHits(hits, lineHs, ys);

            // Rəngli/boz fon üçün əlavə üsullar yalnız əvvəlki üsullar nəticə verməyəndə.
            if (out.isEmpty()) {
                ArrayList<PassOut> cs = runPasses(rec, bmp, H, new float[][]{
                        {3, 14f, 60f, 11}, {3, 7f, 30f, 13}, {4, 0, 0, 15}});
                for (PassOut po : cs) { hits.addAll(po.hits); lineHs.addAll(po.lineHs); }
            }
        }

        // Müstəqil hədəf-sütun skanı: kodları əvvəlcə oxumaqla sütunu tapmaq tələb olunmur.
        // Beləliklə, solğun sətirlər ilkin OCR-dən yayınsa belə, həmin zolaq böyüdülərək yenidən oxunur.
        ArrayList<PassOut> targeted = runTargetStripPasses(rec, bmp, H);
        for (PassOut po : targeted) { hits.addAll(po.hits); lineHs.addAll(po.lineHs); }

        ArrayList<Float> ysFinal = new ArrayList<>();
        out = mergeHits(hits, lineHs, ysFinal);
        bmp.recycle();
        return out;
    }

    /**
     * Cədvəlin 10011 kod sütununun yerləşdiyi mərkəzi zolağı bütün hündürlük boyunca kəsir.
     * Kəsim əlavə keçiddir; bütün səhifə skanını əvəz etmir. Yalnız bu zolaq gücləndirilir və OCR edilir.
     */
    private Bitmap targetCodeStrip(Bitmap src, float[] scaleOut) {
        int w = src.getWidth(), h = src.getHeight();
        // Bu tip cədvəldə kod sütunu səhifənin təxminən 28%-58% eni arasındadır.
        int x0 = Math.max(0, Math.min(w - 1, Math.round(w * 0.28f)));
        int x1 = Math.max(x0 + 1, Math.min(w, Math.round(w * 0.58f)));
        Bitmap crop = Bitmap.createBitmap(src, x0, 0, x1 - x0, h);
        int cw = crop.getWidth();
        // Böyütməni yaddaş daxilində saxla ki, ML Kit böyük, solğun simvolları daha rahat seçsin.
        double pixelCap = Math.sqrt(2_700_000.0 / Math.max(1.0, (double) cw * h));
        float scale = (float) Math.min(2.5, Math.min(pixelCap,
                Math.min(950.0 / cw, 3600.0 / Math.max(1, h))));
        if (scale < 1f) scale = 1f;
        Bitmap scaled = crop;
        if (scale > 1.01f) {
            scaled = Bitmap.createScaledBitmap(crop, Math.max(1, Math.round(cw * scale)),
                    Math.max(1, Math.round(h * scale)), true);
            if (scaled != crop) crop.recycle();
        }
        scaleOut[0] = scale;
        return scaled;
    }

    private PassOut oneTargetStripPass(TextRecognizer rec, Bitmap strip, float scale, float H,
                                       int kind, float a, float b, int pass) {
        PassOut po = new PassOut();
        po.pass = pass;
        Bitmap enhanced = null;
        try {
            if (kind == 0) enhanced = DocEnhance.enhance(strip, a, b);
            else if (kind == 3) enhanced = DocEnhance.enhanceBg(strip, a, b);
            else enhanced = strip;
            Text t = runRec(rec, enhanced);
            collectHits(t, po.hits, pass, 0f, scale, H, po.lineHs);
        } catch (Throwable ignored) {
        } finally {
            if (enhanced != null && enhanced != strip) enhanced.recycle();
        }
        return po;
    }

    private ArrayList<PassOut> runTargetStripPasses(TextRecognizer rec, Bitmap original, float H) {
        ArrayList<PassOut> outs = new ArrayList<>();
        float[] info = {1f};
        Bitmap strip = null;
        try {
            strip = targetCodeStrip(original, info);
            float scale = info[0];
            // Mavi qələm qeydlərini ağlaşdır, boz/qara çap edilmiş kodları saxla.
            Bitmap inkClean = DocEnhance.suppressBlueInk(strip);
            strip.recycle();
            strip = inkClean;
            // Raw, orta kontrast, çox həssas kontrast və fon fərqinə əsaslanan variantlar.
            // Keçidlər ardıcıl işləyir ki, zəif telefonlarda yaddaş pik həddi böyüməsin.
            outs.add(oneTargetStripPass(rec, strip, scale, H, 1, 0f, 0f, 21));
            outs.add(oneTargetStripPass(rec, strip, scale, H, 0, 0.70f, 0.97f, 23));
            outs.add(oneTargetStripPass(rec, strip, scale, H, 0, 0.82f, 0.99f, 25));
            outs.add(oneTargetStripPass(rec, strip, scale, H, 3, 7f, 30f, 27));
        } catch (Throwable ignored) {
        } finally {
            if (strip != null && !strip.isRecycled()) strip.recycle();
        }
        return outs;
    }

    // Bir keçid: bütöv şəkil + 10011 sütunu kəsilib böyüdülmüş hal (keçid nömrələri: pass və pass+1)
    private void readEnhanced(TextRecognizer rec, Bitmap enh, ArrayList<Hit> hits, int pass, float H, ArrayList<Float> lineHs) {
        Text t = runRec(rec, enh);
        collectHits(t, hits, pass, 0f, 1f, H, lineHs);
        Bitmap crop = null;
        float[] info = {0f, 1f};
        try { if (t != null) crop = cropColumn(enh, t, info); } catch (Throwable ignored) { }
        if (crop != null) {
            Text t2 = runRec(rec, crop);
            collectHits(t2, hits, pass + 1, info[0], info[1], H, lineHs);
            crop.recycle();
        }
    }

    // 10011 sütununun üfüqi aralığı [sol, sağ, orta qutu hündürlüyü]; sütun tapılmasa null (süzgəc işləmir)
    private float[] columnRange(Text t) {
        ArrayList<Rect> bx = codeBoxes(t);
        if (bx.isEmpty()) {                                   // sütun 1 koddan ibarətdirsə həmin kodun qutusu götürülür
            for (Text.TextBlock b : t.getTextBlocks())
                for (Text.Line ln : b.getLines())
                    for (Text.Element el : ln.getElements()) {
                        Rect r = el.getBoundingBox();
                        if (r != null && OCR_CODE.matcher(el.getText().toUpperCase()).find()) bx.add(r);
                    }
            if (bx.size() != 1) return null;
        }
        int l = Integer.MAX_VALUE, r = Integer.MIN_VALUE;
        ArrayList<Integer> hs = new ArrayList<>(), ws = new ArrayList<>();
        for (Rect q : bx) { l = Math.min(l, q.left); r = Math.max(r, q.right); hs.add(q.height()); ws.add(q.width()); }
        Collections.sort(hs); Collections.sort(ws);
        float pad = 0.25f * Math.max(1, ws.get(ws.size() / 2));
        return new float[]{l - pad, r + pad, Math.max(1, hs.get(hs.size() / 2))};
    }

    // Əlyazma və sütundan kənar mətnlər nəzərə alınmır: yalnız 10011 sütununun içindəki çap sözlər oxunur.
    private void collectHits(Text t, ArrayList<Hit> hits, int pass, float yOff, float sc, float H, ArrayList<Float> lineHs) {
        if (t == null) return;
        final float[] col = columnRange(t);
        for (Text.TextBlock b : t.getTextBlocks())
            for (Text.Line ln : b.getLines()) {
                String u = ln.getText().toUpperCase();
                Rect r = ln.getBoundingBox();
                float medH = 0f;
                if (col != null) {
                    StringBuilder sb = new StringBuilder();
                    Rect un = null;
                    for (Text.Element el : ln.getElements()) {
                        Rect er = el.getBoundingBox();
                        if (er == null) continue;
                        float cx = er.centerX();
                        if (cx < col[0] || cx > col[1]) continue;      // sütundan kənardakı söz (əlyazma, qeyd) atılır
                        if (sb.length() > 0) sb.append(' ');
                        sb.append(el.getText().toUpperCase());
                        if (un == null) un = new Rect(er); else un.union(er);
                    }
                    if (un == null) continue;
                    u = sb.toString();
                    r = un;
                    medH = col[2];
                }
                ArrayList<String> ms = lineCodes(u);
                // Kod formatına uyğun gəlməyən adi mətn heç vaxt toplu siyahıya əlavə edilmir.
                // Yarımçıq namizədlər lineCodes/partialsIn daxilində ən azı 5 simvol şərtindən keçir.
                if (ms.isEmpty() || r == null) continue;
                // Yarımçıq oxunuşlar üçün: yazının hündürlüyü çap koduna uyğun olmalıdır (iri/əyri əlyazma atılır)
                if (medH > 0f) {
                    boolean hasFull = false;
                    for (String m : ms) if (!m.startsWith("~")) { hasFull = true; break; }
                    if (!hasFull && (r.height() > 2.2f * medH || r.height() < 0.35f * medH)) continue;
                }
                float y = (yOff + r.centerY() / sc) / H;          // şəkil hündürlüyünə nisbətdə mövqe
                lineHs.add(r.height() / sc / H);
                for (String m : ms) hits.add(new Hit(m, y, pass));
            }
    }

    private ArrayList<String> mergeHits(ArrayList<Hit> hits, ArrayList<Float> lineHs, ArrayList<Float> ysOut) {
        ArrayList<String> out = new ArrayList<>();
        if (hits.isEmpty()) return out;
        Collections.sort(lineHs);
        float tol = Math.max(0.004f, 0.5f * lineHs.get(lineHs.size() / 2));   // yarım sətir hündürlüyü: eyni cərgə
        Collections.sort(hits, (p, q) -> Float.compare(p.y, q.y));
        ArrayList<ArrayList<Hit>> groups = new ArrayList<>();
        ArrayList<Hit> cur = null;
        float curY = 0f;
        for (Hit h : hits) {
            boolean join = cur != null && Math.abs(h.y - curY) <= tol;
            if (join) for (Hit g : cur) if (g.pass == h.pass && !g.code.equals(h.code)) { join = false; break; }   // eyni keçiddə iki fərqli kod = iki cərgə
            if (!join) { cur = new ArrayList<>(); groups.add(cur); cur.add(h); curY = h.y; }
            else { cur.add(h); curY = (curY * (cur.size() - 1) + h.y) / cur.size(); }
        }
        ArrayList<Object[]> rows = new ArrayList<>();
        for (ArrayList<Hit> g : groups) {
            ArrayList<Hit> pool = new ArrayList<>();
            for (Hit a : g) if (!a.partial) pool.add(a);
            final boolean onlyPartial = pool.isEmpty();       // cərgədə heç bir keçiddə tam kod oxunmayıb
            if (onlyPartial) pool = g;
            String best = null;
            int bestVotes = -1, bestFirst = Integer.MAX_VALUE, bestLen = -1;
            for (Hit a : pool) {
                int votes = 0, first = Integer.MAX_VALUE;
                for (Hit b : pool) if (b.code.equals(a.code)) { votes++; first = Math.min(first, b.pass); }
                int len = a.code.length();
                boolean better = votes > bestVotes
                        || (votes == bestVotes && onlyPartial && len > bestLen)
                        || (votes == bestVotes && (!onlyPartial || len == bestLen) && first < bestFirst);
                if (better) { best = a.code; bestVotes = votes; bestFirst = first; bestLen = len; }
            }
            if (best != null) {
                float sy = 0f;
                for (Hit a : g) sy += a.y;
                rows.add(new Object[]{sy / g.size(), best});
            }
        }
        // Tam kodlu cərgənin yanında (eyni cərgənin başqa keçiddəki yarımçıq oxunuşu) yarımçıq kod ayrıca cərgə sayılmır
        ArrayList<Float> fullYs = new ArrayList<>();
        for (Object[] r : rows) if (!((String) r[1]).startsWith("~")) fullYs.add((Float) r[0]);
        for (int i = rows.size() - 1; i >= 0; i--) {
            if (!((String) rows.get(i)[1]).startsWith("~")) continue;
            float py = (Float) rows.get(i)[0];
            for (float fy : fullYs) if (Math.abs(fy - py) <= 1.5f * tol) { rows.remove(i); break; }
        }
        // Fotodakı ardıcıllıq: cərgələr yalnız şəkildəki mövqeyinə (yuxarıdan aşağı) görə düzülür
        Collections.sort(rows, (p, q) -> Float.compare((Float) p[0], (Float) q[0]));
        for (Object[] r : rows) { out.add((String) r[1]); ysOut.add((Float) r[0]); }
        return out;
    }

    // Yalnız 10011 sütununa aid qutular (başqa sütundan təsadüfi uyğunluqlar atılır)
    private ArrayList<Rect> codeBoxes(Text t) {
        ArrayList<Rect> rs = new ArrayList<>();
        for (Text.TextBlock b : t.getTextBlocks())
            for (Text.Line ln : b.getLines())
                for (Text.Element el : ln.getElements()) {
                    Rect r = el.getBoundingBox();
                    if (r != null && OCR_CODE.matcher(el.getText().toUpperCase()).find()) rs.add(r);
                }
        if (rs.size() < 2) {          // kod bir neçə sözə bölünübsə sətir qutularına bax
            rs.clear();
            for (Text.TextBlock b : t.getTextBlocks())
                for (Text.Line ln : b.getLines()) {
                    Rect r = ln.getBoundingBox();
                    String u = ln.getText().toUpperCase();
                    if (r != null && (OCR_CODE.matcher(u).find() || OCR_CODE.matcher(u.replaceAll("\\s+", "")).find())) rs.add(r);
                }
        }
        ArrayList<Rect> out = new ArrayList<>();
        if (rs.size() < 2) return out;
        ArrayList<Integer> ls = new ArrayList<>(), ws = new ArrayList<>();
        for (Rect r : rs) { ls.add(r.left); ws.add(r.width()); }
        Collections.sort(ls); Collections.sort(ws);
        int medL = ls.get(ls.size() / 2), medW = Math.max(1, ws.get(ws.size() / 2));
        for (Rect r : rs) if (Math.abs(r.left - medL) <= 0.6f * medW) out.add(r);
        return out;
    }

    private Bitmap cropColumn(Bitmap bmp, Text t, float[] info) {
        ArrayList<Rect> bx = codeBoxes(t);
        int n = bx.size();
        if (n < 2) return null;
        int l = Integer.MAX_VALUE, r = Integer.MIN_VALUE, top = Integer.MAX_VALUE, bot = Integer.MIN_VALUE;
        ArrayList<Integer> hs = new ArrayList<>(), ws = new ArrayList<>();
        for (Rect q : bx) {
            l = Math.min(l, q.left); r = Math.max(r, q.right);
            top = Math.min(top, q.top); bot = Math.max(bot, q.bottom);
            hs.add(q.height()); ws.add(q.width());
        }
        Collections.sort(hs); Collections.sort(ws);
        int medH = Math.max(6, hs.get(n / 2)), medW = Math.max(1, ws.get(n / 2));
        int pad = Math.max(8, medW / 8);
        int x = Math.max(0, l - pad), x2 = Math.min(bmp.getWidth(), r + pad);
        if (x2 - x > 0.9f * bmp.getWidth()) { x = 0; x2 = bmp.getWidth(); }
        int w = x2 - x;
        int y = Math.max(0, top - medH), y2 = Math.min(bmp.getHeight(), bot + medH);
        int h = y2 - y;
        if (w < 20 || h < 20) return null;
        Bitmap c = Bitmap.createBitmap(bmp, x, y, w, h);
        float sc = Math.min(4f, Math.min(1400f / w, 4096f / h));   // yaddaş/ML Kit həddinə qədər maksimum yaxınlaşdırma
        if (sc > 1.1f) c = Bitmap.createScaledBitmap(c, Math.round(w * sc), Math.round(h * sc), true);
        info[0] = y;                                  // kəsilmiş hissənin şəkildəki yuxarı mövqeyi
        info[1] = (float) c.getHeight() / h;          // şaquli miqyas
        return c;
    }

    private void ocrImgDone(TextRecognizer rec, ArrayList<String> s, int idx,
                            ArrayList<ArrayList<String>> res, int[] left) {
        res.set(idx, s);
        if (--left[0] > 0) return;
        ArrayList<String> found = new ArrayList<>();
        for (ArrayList<String> x : res) if (x != null) found.addAll(x);   // indeks sırası = seçilmə sırası
        ocrFinish(rec, found);
    }

    // Kameradan çəkilən müvəqqəti şəkillər (cache/ocr) oxunandan sonra silinir.
    // Qalereyadan seçilən şəkillərə toxunulmur.
    private void clearOcrCache() {
        try {
            File[] fs = new File(getCacheDir(), "ocr").listFiles();
            if (fs != null) for (File f : fs) f.delete();
        } catch (Exception ignored) { }
        cameraUri = null;
    }

    private void ocrFinish(TextRecognizer rec, ArrayList<String> found) {
        clearOcrCache();
        if (found.isEmpty()) {
            toast("Şəkildə kod tapılmadı");
            return;
        }
        ui.evaluateJavascript("window.addOcrCodes(" + JSONObject.quote(String.join("\n", found)) + ");", null);
    }

    private static float centerY(Text.Line l) {
        Rect r = l.getBoundingBox();
        return r == null ? 0 : r.centerY();
    }

    private static int left(Text.Line l) {
        Rect r = l.getBoundingBox();
        return r == null ? 0 : r.left;
    }

    // Bir sətirdəki bütün 10011 kodları: tam kodlar + yarımçıq/oxunmayanlar ("~" + oxunan mətn).
    // Dublikatlar silinmir, heç bir 10011 itmir.
    private ArrayList<String> lineCodes(String u) {
        ArrayList<String> out = matchesIn(u);
        if (out.isEmpty()) {
            ArrayList<String> sp = matchesIn(u.replaceAll("\\s+", ""));   // kod boşluqla bölünüb
            if (!sp.isEmpty()) return sp;
        }
        out.addAll(partialsIn(u));
        return out;
    }

    private static final String[] PRE_SETS = {"1IL|!", "0OQD", "0OQD", "1IL|!", "1IL|!"};

    private static int preScore(String t) {
        int n = Math.min(5, t.length()), sc = 0;
        for (int i = 0; i < n; i++) if (PRE_SETS[i].indexOf(t.charAt(i)) >= 0) sc++;
        return sc;
    }

    // Tam koda çevrilməyən, amma 10011-ə bənzəyən sözlər: yarımçıq (7 simvoldan az/çox), pozulmuş prefiks və s.
    private ArrayList<String> partialsIn(String u) {
        ArrayList<String> out = new ArrayList<>();
        String[] tk = u.trim().split("\\s+");
        for (int i = 0; i < tk.length; i++) {
            if (tk[i].matches("[0-9]+[.,:/-][0-9]+.*")) continue;   // məbləğ, tarix və s. rəqəm formatları kod deyil
            String t = tk[i].replaceAll("[^A-Z0-9|!]", "");
            if (t.length() < 5) continue;
            if (OCR_CODE.matcher(t).find()) continue;             // tam kod artıq götürülüb
            if (preScore(t) < 4) continue;                         // 10011-ə kifayət qədər bənzəmir
            String cand = t;
            if (cand.length() == 5 && preScore(cand) == 5 && i + 1 < tk.length) {   // "10011 ABC12": prefiks ayrı sözdədirsə növbəti söz birləşir
                String nx = tk[i + 1].replaceAll("[^A-Z0-9|!]", "");
                if (nx.length() >= 2 && nx.length() <= 7 && nx.matches(".*[0-9].*") && !tk[i + 1].matches("[0-9]+[.,:/-][0-9]+.*") && !OCR_CODE.matcher(nx).find()) { cand = cand + nx; i++; }
            }
            if (cand.length() >= 5 && preScore(cand) == 5) cand = "10011" + fixOcrTail(cand.substring(5));
            out.add("~" + cand);
        }
        return out;
    }


    private ArrayList<String> matchesIn(String s) {
        ArrayList<String> out = new ArrayList<>();
        java.util.regex.Matcher m = OCR_CODE.matcher(s);
        while (m.find()) {
            String tail = m.group(1);
            if (tail.length() == 8) {
                // OCR bəzən "H" hərfini "II" kimi oxuyur (10011HEX1150 -> 10011IIEX1150): kod bir simvol uzanır.
                // Hərf hissəsində (ilk 3 simvol) yanaşı iki I/1/L varsa onlar "H" ilə əvəz olunur, sondakı simvol itmir.
                String merged = null;
                for (int i = 0; i < 3 && merged == null; i++) {
                    if (isIlike(tail.charAt(i)) && isIlike(tail.charAt(i + 1)))
                        merged = tail.substring(0, i) + "H" + tail.substring(i + 2);
                }
                tail = merged != null ? merged : tail.substring(0, 7);
            }
            out.add("10011" + fixOcrTail(tail));
        }
        return out;
    }

    private static boolean isIlike(char c) { return c == 'I' || c == '1' || c == 'L' || c == '|' || c == '!'; }

    // Koddakı 7 simvolun qaydası: 6-8-ci simvollar (tail[0..2]) hərf, 9-12-ci simvollar (tail[3..6]) rəqəmdir.
    // Hərf yerində: 0 -> O, 1/|/! -> I   (O, Q və digər hərflər olduğu kimi qalır)
    // Rəqəm yerində: O/Q/D -> 0, I/L/|/! -> 1, S -> 5
    private static String fixOcrTail(String t) {
        StringBuilder sb = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (i < 3) {
                if (c == '0') c = 'O';
                else if (c == '1' || c == '|' || c == '!') c = 'I';
            } else {
                if (c == 'O' || c == 'Q' || c == 'D') c = '0';
                else if (c == 'I' || c == 'L' || c == '|' || c == '!') c = '1';
                else if (c == 'S') c = '5';
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private Worker createWorker(boolean batch) {
        final Worker w = new Worker();
        if (batch) pool.add(w);
        attachWebView(w);
        return w;
    }

    private void attachWebView(final Worker w) {
        final WebView wv = new WebView(this);
        wv.setBackgroundColor(Color.WHITE);
        wv.setFocusable(false);                       // klaviaturanı/fokusu oğurlamasın
        wv.setFocusableInTouchMode(false);
        // ui-nin ARXASINA (index 0) əlavə olunur: tam ölçüdə layout alır, amma görünmür
        root.addView(wv, 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setupCommon(wv);
        wv.getSettings().setLoadsImagesAutomatically(false);   // gizli səhifədə şəkil lazım deyil: daha tez açılır
        wv.getSettings().setBlockNetworkImage(true);
        w.wv = wv;
        w.loaded = false;
        wv.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void result(final String code, final String name, final String debt) {
                runOnUiThread(() -> { if (w.wv == wv) onEbelResult(w, code, name, debt); });
            }

            @JavascriptInterface
            public void fail(final String code, final String reason) {
                runOnUiThread(() -> { if (w.wv == wv) onEbelFail(w, code, reason); });
            }
        }, "AndroidEbel");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                if (w.wv == wv) w.loaded = false;     // yeni yükləmə başlayıb: köhnə "hazırdır" siqnalı keçərsiz
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (w.wv != wv) return;
                v.clearHistory();                      // hər təzələmə tarixçəni şişirtməsin
                w.loaded = true;
                if (w.pending != null) {
                    String p = w.pending;
                    w.pending = null;
                    runFill(w, p);
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                // Əsas səhifə yüklənmədisə 45 san gözləmədən tez təkrar yüklə
                if (w.wv != wv || r == null || !r.isForMainFrame()) return;
                v.postDelayed(() -> { if (w.wv == wv && !w.loaded) wv.loadUrl(EBEL_URL); }, 1500);
            }
        });
        wv.loadUrl(EBEL_URL);
    }

    // Köhnə WebView tam məhv edilir, yenisi açılır (uzun işləyəndə yaddaş və yavaşlıq yığılmasın)
    private void rebuild(Worker w) {
        WebView old = w.wv;
        old.removeCallbacks(w.watchdog);
        w.wv = null;
        old.stopLoading();
        old.setWebViewClient(new WebViewClient());
        root.removeView(old);
        old.destroy();
        w.jobs = 0;
        w.current = null;
        w.pending = null;
        attachWebView(w);
    }

    // Səhifəni təzədən yüklə: hər kod TƏMİZ səhifədə yoxlanılır, əvvəlki sorğunun vəziyyəti qalmır
    private void recycle(Worker w) {
        if (w.current != null && ++w.jobs >= MAX_JOBS_PER_VIEW) { rebuild(w); return; }
        w.wv.removeCallbacks(w.watchdog);
        w.current = null;
        w.pending = null;
        w.loaded = false;
        w.wv.stopLoading();
        w.wv.loadUrl(EBEL_URL);
    }

    private void start(Worker w, Job j) {
        w.current = j;
        w.wv.removeCallbacks(w.watchdog);
        if (w.loaded) {
            runFill(w, j.code);                          // 5 san sayğacı runFill-də başlayır
        } else {
            w.pending = j.code;                          // səhifə hələ açılır: sayğac açılandan sonra başlayacaq
            w.wv.postDelayed(w.watchdog, PAGE_GUARD_MS);
        }
    }

    private Worker pickBatchWorker() {
        for (Worker w : pool) if (w.current == null && w.loaded) return w;
        for (Worker w : pool) if (w.current == null) return w;
        if (pool.size() < maxWorkers) return createWorker(true);
        return null;
    }

    private void pumpBatch() {
        while (!batchJobs.isEmpty()) {
            Worker w = pickBatchWorker();
            if (w == null) return;
            start(w, batchJobs.pollFirst());
        }
    }

    private void runFill(Worker w, String value) {
        w.wv.removeCallbacks(w.watchdog);
        final boolean isVariant = w.current != null && !w.current.code.equals(w.current.orig);
        w.wv.postDelayed(w.watchdog, isVariant ? VARIANT_LIMIT_MS : LOAD_LIMIT_MS);
        w.wv.evaluateJavascript(injectJs + ";window.__yvokRun('" + value + "');", null);
    }

    private void onEbelResult(Worker w, String code, String name, String debt) {
        Job j = w.current;
        if (j == null || code == null || !j.code.equals(code)) return;   // köhnə/yad nəticə
        final String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        final String d = debt == null ? "" : debt.trim();
        final Group g = j.grp;
        if (g != null) {
            if (g.done) { recycle(w); pumpBatch(); return; }      // başqa variant artıq qazanıb
            if (NAME_OK.matcher(n).matches() && DEBT_OK.matcher(d).matches()) {
                g.done = true;                                      // qalan variantları ləğv et
                for (java.util.Iterator<Job> it = batchJobs.iterator(); it.hasNext(); ) if (it.next().grp == g) it.remove();
                for (Worker o : pool) if (o != w && o.current != null && o.current.grp == g) recycle(o);
            }
        }
        recycle(w);
        if (!NAME_OK.matcher(n).matches() || !DEBT_OK.matcher(d).matches()) {
            failJob(j, "Məlumat formatı tanınmadı");
        } else if (j.batch) {
            ui.evaluateJavascript("window.setBatchResult(" + JSONObject.quote(j.orig) + ","
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + "," + JSONObject.quote(j.code) + ");", null);
        } else {
            ui.evaluateJavascript("window.setEbelStatus('ok');window.setEbelResult("
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
            if (d.isEmpty()) toast("Borc məbləği tapılmadı");
        }
        if (j.batch) pumpBatch();
    }

    private void onEbelFail(Worker w, String code, String reason) {
        Job j = w.current;
        if (j == null || (code != null && !j.code.equals(code))) return;
        handleFail(w, j, "Məlumat tapılmadı");
    }

    private void onWatchdog(Worker w) {
        Job j = w.current;
        if (j == null) return;
        // Səhifə heç açılmayıbsa kod səhv deyil: variantlara keçmədən təmiz səhifədə eyni kodu təkrar yoxla
        if (!w.loaded && j.pageRetries < 2) {
            j.pageRetries++;
            rebuild(w);
            start(w, j);
            return;
        }
        handleFail(w, j, "Məlumat tapılmadı");
    }

    private void handleFail(Worker w, Job j, String msg) {
        // Nəticə gəlməyibsə (kod yanlışdır) qarışan simvol variantları yoxlanılır (0/O/Q, 1/I, 9-12-ci simvollarda 5/S).
        // Variantlar artıq ardıcıl yox, boş işçilərdə PARALEL yoxlanılır. Nəticə gəlibsə koda toxunulmur.
        // "Sayt cavab vermədi" mesajı yoxdur: bütün uğursuzluqlar "Məlumat tapılmadı"dır.
        if (j.batch) {
            final Group g = j.grp;
            if (g != null) {                                        // variant sorğusu uğursuz oldu
                recycle(w);
                if (!g.done && --g.left <= 0) { g.done = true; failJob(g.root, msg); }
                pumpBatch();
                return;
            }
            if (j.variants == null) j.variants = buildVariants(j.orig);
            if (!j.variants.isEmpty()) {
                Group ng = new Group(j);
                ArrayList<Job> vs = new ArrayList<>();
                String next;
                while ((next = j.variants.pollFirst()) != null) {
                    Job vj = new Job(next, j);
                    vj.variants = new ArrayDeque<>();
                    vj.grp = ng;
                    vs.add(vj);
                }
                ng.left = vs.size();
                for (int i = vs.size() - 1; i >= 0; i--) batchJobs.addFirst(vs.get(i));   // növbənin əvvəlinə: az dəyişikliklidən başlayaraq
                recycle(w);
                pumpBatch();
                return;
            }
        }
        recycle(w);
        failJob(j, msg);                      // təkrar yoxlama yoxdur: 5 saniyədən çox gözlətmə
        if (j.batch) pumpBatch();
    }

    // Qarışan simvol qrupları: {0,O,Q,D} və {1,I,L} (6-12-ci simvollar), {5,S} (yalnız 8-12-ci simvollar). Koddakı 6-12-ci simvolların (indeks 5..11) hər biri
    // öz qrupunun istənilən üzvü ilə əvəz oluna bilər (hər iki istiqamətdə: O->0, 0->O, 0<->D, I->1, 1->I, 1<->L, O<->Q ...).
    // Variantlar az dəyişiklikdən çoxuna doğru sıralanır və MAX_VARIANTS ilə məhdudlaşdırılır.
    private static final int MAX_VARIANTS = 40;

    private static String confusableGroup(char c, int i) {
        if (c == '0' || c == 'O' || c == 'Q' || c == 'D') return "0OQD";
        if (c == '1' || c == 'I' || c == 'L') return "1IL";
        if (i >= 7 && (c == '5' || c == 'S')) return "5S";   // 8-12-ci simvollarda 5<->S qarışır
        return null;
    }

    private static ArrayDeque<String> buildVariants(String code) {
        ArrayList<Integer> pos = new ArrayList<>();
        for (int i = 5; i < code.length(); i++) if (confusableGroup(code.charAt(i), i) != null) pos.add(i);
        int n = pos.size();
        ArrayList<String> list = new ArrayList<>();
        ArrayList<int[]> meta = new ArrayList<>();
        int[] idx = new int[n];                       // hər mövqedə qrupdan seçilən üzvün nömrəsi
        while (true) {
            char[] cs = code.toCharArray();
            int d = 0;
            for (int b = 0; b < n; b++) {
                int i = pos.get(b);
                char nc = confusableGroup(code.charAt(i), i).charAt(idx[b]);
                if (cs[i] != nc) { cs[i] = nc; d++; }
            }
            if (d > 0) {
                list.add(new String(cs));
                meta.add(new int[]{d, list.size() - 1});
            }
            int b = 0;                                // sayğacı bir artır (qarışıq say sistemi)
            while (b < n) {
                if (++idx[b] < confusableGroup(code.charAt(pos.get(b)), pos.get(b)).length()) break;
                idx[b++] = 0;
            }
            if (b == n) break;
        }
        Collections.sort(meta, (p, q) -> p[0] != q[0] ? Integer.compare(p[0], q[0]) : Integer.compare(p[1], q[1]));
        ArrayDeque<String> out = new ArrayDeque<>();
        for (int[] m : meta) { if (out.size() >= MAX_VARIANTS) break; out.add(list.get(m[1])); }
        // II <-> H: OCR "H" hərfini "II" kimi oxuyub kodu bir simvol qısaldıbsa (sonu itib),
        // "II" -> "H" edilir və itən son rəqəm 0-9 ilə tamamlanır. Bu variantlar ƏVVƏLDƏ yoxlanılır.
        ArrayDeque<String> hv = new ArrayDeque<>();
        for (int i = 5; i <= 6; i++) {
            if (code.length() == 12 && isIlike(code.charAt(i)) && isIlike(code.charAt(i + 1))) {
                String base = code.substring(0, i) + "H" + code.substring(i + 2);   // 11 simvol
                for (char d = '0'; d <= '9'; d++) hv.add(base + d);
            }
        }
        if (!hv.isEmpty()) { hv.addAll(out); return hv; }
        return out;
    }

    private void failJob(Job j, String msg) {
        if (j.batch) {
            ui.evaluateJavascript("window.setBatchFail(" + JSONObject.quote(j.orig) + ","
                    + JSONObject.quote(msg) + ");", null);
        } else {
            status("fail");
            toast(msg);
        }
    }

    private void setupCommon(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("OK", (d, x) -> res.confirm())
                        .setOnCancelListener(d -> res.confirm()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("Bəli", (d, x) -> res.confirm())
                        .setNegativeButton("Xeyr", (d, x) -> res.cancel())
                        .setOnCancelListener(d -> res.cancel()).show();
                return true;
            }
        });
    }

    private void status(final String st) {
        runOnUiThread(() -> ui.evaluateJavascript("window.setEbelStatus('" + st + "');", null));
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
