package az.videoyabax;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import java.io.File;

public class VideoService extends Service {
    private VideoServer server;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (server == null) {
            Notification.Builder nb;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel("vb", "Videoya bax", NotificationManager.IMPORTANCE_LOW);
                ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
                nb = new Notification.Builder(this, "vb");
            } else {
                nb = new Notification.Builder(this);
            }
            nb.setContentTitle("Videoya bax").setContentText("Hazırdır – port " + VideoServer.PORT)
                    .setSmallIcon(android.R.drawable.ic_media_play);
            startForeground(1, nb.build());

            File[] old = getCacheDir().listFiles();
            if (old != null) for (File f : old) if (f.getName().startsWith("video_")) f.delete();

            server = new VideoServer(this);
            VideoServer.listener = () -> {
                try {
                    Intent i = new Intent(VideoService.this, MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(i);
                } catch (Exception ignored) { }
            };
            server.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (server != null) server.stop();
        VideoServer.listener = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
