package com.example.xiaomibattery

import android.app.Activity
import android.content.*
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var big: TextView
    private lateinit var bar: ProgressBar
    private var maxT = -100f
    private var minT = 100f
    private val h = Handler(Looper.getMainLooper())
    private val bases = listOf("/sys/class/power_supply/battery/", "/sys/class/power_supply/bms/")
    private val tick = object : Runnable {
        override fun run() { registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { update(it) }; h.postDelayed(this, 2000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((16*dp).toInt(), (40*dp).toInt(), (16*dp).toInt(), (16*dp).toInt()); setBackgroundColor(Color.parseColor("#121212")) }
        big = TextView(this).apply { textSize = 56f; setTextColor(Color.parseColor("#FF6900")); gravity = Gravity.CENTER }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        info = TextView(this).apply { textSize = 16f; setTextColor(Color.WHITE); setLineSpacing(8f, 1f); setPadding(0, (16*dp).toInt(), 0, (16*dp).toInt()) }
        root.addView(big); root.addView(bar)
        root.addView(ScrollView(this).apply { addView(info) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(btn("🔋 Batareya qənaəti (Xiaomi)") { open("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity") })
        root.addView(btn("🚀 Avtomatik başlama (Autostart)") { open("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity") })
        root.addView(btn("⚙️ Batareya optimallaşdırması") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        root.addView(btn("📊 Sistem batareya istifadəsi") { startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) })
        setContentView(root)
    }

    private fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }

    private fun open(p: String, cl: String) {
        try { startActivity(Intent().setComponent(ComponentName(p, cl))) } catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) } catch (_: Exception) { Toast.makeText(this, "Səhifə tapılmadı", Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    // ---------- köməkçi funksiyalar ----------
    private fun sys(name: String): String? {
        for (b in bases) try { val s = File(b + name).readText().trim(); if (s.isNotEmpty()) return s } catch (_: Exception) {}
        return null
    }
    private fun mah(v: Double) = if (v > 20000) v / 1000.0 else v
    private fun date(sec: Long): String? {
        val now = System.currentTimeMillis() / 1000
        return if (sec in 946684800..now) SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(sec * 1000)) else null
    }
    private fun designFromProfile(): Double? = try {
        val c = Class.forName("com.android.internal.os.PowerProfile")
        (c.getMethod("getBatteryCapacity").invoke(c.getConstructor(Context::class.java).newInstance(this)) as Double).takeIf { it > 0 }
    } catch (_: Throwable) { null }

    private fun phoneFirstUse(): String? = try {
        packageManager.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
            .minOfOrNull { packageManager.getPackageInfo(it.packageName, 0).firstInstallTime }
            ?.let { date(it / 1000) }
    } catch (_: Throwable) { null }

    private fun update(i: Intent) {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val pct = i.getIntExtra("level", 0) * 100 / i.getIntExtra("scale", 100)
        val status = when (i.getIntExtra("status", 0)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Şarj olur ⚡"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Boşalır"
            BatteryManager.BATTERY_STATUS_FULL -> "Dolu ✅"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Şarj olmur"
            else -> "Naməlum" }
        val plug = when (i.getIntExtra("plugged", 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Adapter (AC)"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Simsiz"
            0 -> "Qoşulmayıb"
            else -> "Digər" }
        val health = when (i.getIntExtra("health", 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Yaxşı"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Həddən artıq isti 🔥"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Ölü"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Yüksək gərginlik"
            BatteryManager.BATTERY_HEALTH_COLD -> "Soyuq ❄️"
            else -> "Naməlum" }
        val temp = i.getIntExtra("temperature", 0) / 10f
        if (temp > maxT) maxT = temp; if (temp < minT) minT = temp
        val mv = i.getIntExtra("voltage", 0)
        val cycles = i.getIntExtra("android.os.extra.CYCLE_COUNT", -1).takeIf { it >= 0 } ?: sys("cycle_count")?.toIntOrNull()
        val cur = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW).toDouble()
        val ma = if (abs(cur) > 20000) cur / 1000 else cur
        val watt = abs(ma) * mv / 1_000_000.0

        // --- real tutum və real faiz ---
        val cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER).toDouble()
        val nowMah = if (cc > 0) mah(cc) else null
        val sysDesign = sys("charge_full_design")?.toDoubleOrNull()?.let { mah(it) }
        val profDesign = designFromProfile()
        val design = sysDesign ?: profDesign
        var full: Double? = sys("charge_full")?.toDoubleOrNull()?.let { mah(it) }
        if (full == null && Build.VERSION.SDK_INT >= 34 && design != null) {
            val soh = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATE_OF_HEALTH)
            if (soh in 1..100) full = design * soh / 100
        }
        if (full == null && nowMah != null && pct > 0) full = nowMah * 100 / pct   // təxmini
        val realPct = if (nowMah != null && full != null && full > 0) nowMah * 100 / full else null
        val healthPct = if (full != null && design != null && design > 0) full * 100 / design else null

        // --- tarixlər ---
        var bFirst: String? = null; var bMade: String? = null
        if (Build.VERSION.SDK_INT >= 34) try {
            bFirst = date(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_FIRST_USAGE_DATE))
            bMade = date(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_MANUFACTURING_DATE))
        } catch (_: Throwable) {}

        // --- orijinallıq ---
        val auth = (sys("authentic") ?: sys("battery_authentic"))?.toIntOrNull()
        val original = when {
            auth == 1 -> "Orijinal ✅"
            auth == 0 -> "Orijinal DEYİL ⚠️"
            sysDesign != null && profDesign != null && abs(sysDesign - profDesign) / profDesign > 0.15 ->
                "Şübhəli ⚠️ (tutum sistem məlumatı ilə uyğun gəlmir)"
            else -> "Yoxlanıla bilmədi (bu model məlumat vermir)" }

        big.text = "$pct%"; bar.progress = pct
        info.text = buildString {
            appendLine("📱 ${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE}\n")
            appendLine("Vəziyyət: $status")
            appendLine("Mənbə: $plug")
            appendLine("Sağlamlıq (sistem): $health")
            appendLine("Temperatur: $temp °C (min ${"%.1f".format(minT)} / max ${"%.1f".format(maxT)})")
            appendLine("Gərginlik: $mv mV")
            appendLine("Cərəyan: ${"%.0f".format(ma)} mA • Güc: ${"%.2f".format(watt)} W")
            appendLine("\n— REAL MƏLUMATLAR —")
            appendLine("Real batareya faizi: ${realPct?.let { "%.1f".format(it) + "%" } ?: "-"}  (sistemdə: $pct%)")
            appendLine("Real tutum: ${full?.let { "%.0f mAh".format(it) } ?: "-"} / dizayn: ${design?.let { "%.0f mAh".format(it) } ?: "-"}")
            appendLine("Real tutum faizi: ${healthPct?.let { "%.1f".format(it) + "%" } ?: "-"}")
            appendLine("Qalan yük: ${nowMah?.let { "%.0f mAh".format(it) } ?: "-"}")
            appendLine("Şarj dövrü: ${cycles ?: "-"}")
            appendLine("\n— TARİXLƏR —")
            appendLine("Batareya ilk istifadə: ${bFirst ?: "Android verməyir (Android 14+ lazımdır)"}")
            appendLine("Batareya istehsal tarixi: ${bMade ?: "-"}")
            appendLine("Telefon ilk istifadə (təxmini): ${phoneFirstUse() ?: "-"}")
            appendLine("\n— ORİJİNALLIQ —")
            appendLine(original)
            appendLine("\nQeyd: bəzi dəyərlər Xiaomi modelindən və Android versiyasından asılıdır; oxuna bilməyənlər \"-\" göstərilir.")
        }
    }
}
