# YVÖK Yoxla — Android Studio layihəsi

Android tətbiqi Yelo Bank-ın göstərilən ödəniş-axtarış səhifəsini WebView daxilində açır və nəticələri ayrıca ekranda göstərməyə çalışır.

## İş prinsipi

- İstifadəçi yalnız son 7 rəqəmi daxil edir.
- Soldakı `10011` prefiksi tam YVÖK kodunu yaradır.
- 7-ci rəqəm daxil edilən kimi tətbiq saytdakı YVÖK sahəsini tapır, kodu yerləşdirir və axtarış düyməsini basır.
- Nəticədən `Ödəyən`, `YVÖK` və `Məbləğ (AZN)` dəyərləri oxunub göstərilir.
- Məbləğ mənfidirsə `0.00` göstərilir.
- Tətbiq ödəniş etmir; yalnız axtarış nəticəsini göstərmək üçündür.

## Açmaq və APK yaratmaq

1. Android Studio-da `Open` seçin və bu qovluğu açın.
2. Gradle sinxronizasiyasının tamamlanmasını gözləyin (Android Gradle Plugin 8.7.3, JDK 17, Android SDK 35 tələb olunur).
3. `Build > Build APK(s)` seçin.
4. APK adətən `app/build/outputs/apk/debug/app-debug.apk` qovluğunda yaranacaq.

## Qeydlər

Bu iş mühitində Android SDK/Gradle quraşdırılmadığı və Yelo portalının canlı səhifəsi birbaşa yüklənmədiyi üçün APK-ni burada yığmaq və real hesab/YVÖK ilə sonadək yoxlamaq mümkün olmadı. Layihə canlı portalın HTML sahələrini avtomatik aşkarlamağa çalışır; bank portalının səhifə quruluşu dəyişərsə sahə seçicisini yeniləmək lazım gələ bilər. Nəticə gəlmədikdə tətbiq məlumat uydurmur, status mesajı göstərir.
