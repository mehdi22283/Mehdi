package az.m3u.sinayici

import android.net.Uri
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Brauzer kimi başlıqlar (User-Agent, Referer, Origin), "link|Header=Value" yazılışı və #EXTVLCOPT başlıqları. */
object Net {
    const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    class Target(val url: String, val headers: Map<String, String>)

    private fun canon(k: String): String = when (k.trim().lowercase()) {
        "user-agent" -> "User-Agent"
        "referer", "referrer" -> "Referer"
        "origin" -> "Origin"
        else -> k.trim()
    }

    fun target(raw: String, hdrJson: String): Target {
        val parts = raw.split("|", limit = 2)
        val url = parts[0].trim()
        val h = LinkedHashMap<String, String>()
        if (parts.size > 1) parts[1].split("&").forEach { kv ->
            val i = kv.indexOf('=')
            if (i > 0) h[canon(kv.substring(0, i))] = Uri.decode(kv.substring(i + 1))
        }
        try {
            val o = JSONObject(hdrJson)
            for (k in o.keys()) h[canon(k)] = o.getString(k)
        } catch (e: Exception) { }
        val u = Uri.parse(url)
        val origin = if (u.scheme != null && u.host != null) u.scheme + "://" + u.authority else ""
        if (!h.containsKey("User-Agent")) h["User-Agent"] = UA
        if (origin.isNotEmpty()) {
            if (!h.containsKey("Referer")) h["Referer"] = "$origin/"
            if (!h.containsKey("Origin")) h["Origin"] = origin
        }
        return Target(url, h)
    }

    /** Qarışıq protokollu (http↔https) yönləndirmələri də izləyir. */
    fun connect(t: Target, range: String?, timeout: Int): HttpURLConnection {
        var cur = t.url
        repeat(6) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.connectTimeout = timeout; c.readTimeout = timeout; c.instanceFollowRedirects = false
            for ((k, v) in t.headers) c.setRequestProperty(k, v)
            if (range != null) c.setRequestProperty("Range", range)
            val code = c.responseCode
            if (code in 300..399 && code != 304) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc == null) throw IOException("redirect without location")
                cur = URL(URL(cur), loc).toString()
            } else return c
        }
        throw IOException("too many redirects")
    }

    /** Məzmun #EXTM3U ilə başlayırsa HLS-dir (uzantısı olmayan linklər üçün). */
    fun isHls(t: Target): Boolean {
        val c = connect(t, "bytes=0-31", 8000)
        try {
            val b = ByteArray(7); var r = 0
            c.inputStream.use { s ->
                while (r < 7) { val n = s.read(b, r, 7 - r); if (n < 0) break; r += n }
            }
            return String(b, 0, r) == "#EXTM3U"
        } finally { c.disconnect() }
    }

    fun probe(raw: String, hdrJson: String): String = try {
        val c = connect(target(raw, hdrJson), "bytes=0-64", 9000)
        val code = c.responseCode
        c.disconnect()
        if (code in 200..299) "ok" else "unknown"
    } catch (e: Exception) { "dead" }
}
