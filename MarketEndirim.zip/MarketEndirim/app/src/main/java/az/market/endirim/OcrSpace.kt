package az.market.endirim

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Pulsuz onlayn OCR (OCR.space, Engine 2): ayda 25 000 sorğu, kredit kartı yoxdur. Pulsuz açar e-poçtla alınır.
 * Limit: 1 MB/şəkil, gündə ~500 və saatda ~180 sorğu. Limit dolanda və ya xəta olanda tətbiq ML Kit/Tesseract ilə davam edir.
 * Səhifə şəkli ocr.space serverinə göndərilir (jurnallar ictimai olduğu üçün problem deyil).
 */
object OcrSpace {
    private const val ENDPOINT = "https://api.ocr.space/parse/image"
    private const val MAX_BYTES = 950_000

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    /** Açar rədd olunub / limit dolub — tətbiq yenidən açılana və ya açar dəyişənə qədər onlayn OCR söndürülür. */
    @Volatile private var blocked = false

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ocrspace", Context.MODE_PRIVATE)
    fun key(ctx: Context): String = prefs(ctx).getString("key", "")?.trim().orEmpty()
    fun switchedOn(ctx: Context): Boolean = prefs(ctx).getBoolean("on", true)
    fun enabled(ctx: Context): Boolean = !blocked && key(ctx).isNotEmpty() && switchedOn(ctx)

    fun save(ctx: Context, key: String, on: Boolean) {
        prefs(ctx).edit().putString("key", key.trim()).putBoolean("on", on).apply()
        blocked = false
    }

    /** Şəkil ≤ ~1 MB olana qədər kiçildilir / sıxılır. Qaytarır: JPEG baytları və miqyas (göndərilən / orijinal). */
    private fun encode(bmp: Bitmap): Pair<ByteArray, Float>? {
        var edge = 2400
        var q = 85
        for (i in 0 until 7) {
            val s = minOf(1f, edge.toFloat() / maxOf(bmp.width, bmp.height))
            val b = if (s < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt().coerceAtLeast(1), (bmp.height * s).toInt().coerceAtLeast(1), true) else bmp
            val bo = ByteArrayOutputStream()
            b.compress(Bitmap.CompressFormat.JPEG, q, bo)
            if (b !== bmp) b.recycle()
            if (bo.size() <= MAX_BYTES) return bo.toByteArray() to s
            edge = (edge * 0.85f).toInt()
            q = maxOf(60, q - 5)
        }
        return null
    }

    /** Səhifəni oxuyub sətirləri (səhifə koordinatlarında) qaytarır; alınmasa null. */
    suspend fun lines(ctx: Context, bmp: Bitmap): List<OLine>? {
        if (!enabled(ctx)) return null
        val (bytes, s) = withContext(Dispatchers.Default) { encode(bmp) } ?: return null
        for (attempt in 1..3) {
            try {
                val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("OCREngine", "2")
                    .addFormDataPart("isOverlayRequired", "true")
                    .addFormDataPart("scale", "true")
                    .addFormDataPart("file", "page.jpg", bytes.toRequestBody("image/jpeg".toMediaType()))
                    .build()
                val req = Request.Builder().url(ENDPOINT).header("apikey", key(ctx)).post(body).build()
                val (code, text) = withContext(Dispatchers.IO) {
                    http.newCall(req).execute().use { it.code to (it.body?.string() ?: "") }
                }
                when {
                    code == 200 -> return parse(text, 1f / s)
                    code == 403 || code == 429 -> {
                        blocked = true
                        toast(ctx, "OCR.space limiti dolub və ya açar qəbul olunmadı — yerli OCR ilə davam edir")
                        return null
                    }
                    code >= 500 -> delay(2500L * attempt)
                    else -> return null
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: IOException) {
                delay(2000L * attempt)
            }
        }
        return null
    }

    private class W(val t: String, val l: Int, val tp: Int, val r: Int, val b: Int) {
        val h get() = b - tp
    }

    private fun parse(resp: String, back: Float): List<OLine>? {
        return try {
            val root = JSONObject(resp)
            if (root.optBoolean("IsErroredOnProcessing", false)) {
                val msg = root.opt("ErrorMessage")?.toString().orEmpty().lowercase()
                if ("limit" in msg || "key" in msg) blocked = true
                return null
            }
            val pr = root.optJSONArray("ParsedResults") ?: return null
            if (pr.length() == 0) return null
            val lines = pr.getJSONObject(0).optJSONObject("TextOverlay")?.optJSONArray("Lines") ?: return null
            val out = ArrayList<OLine>()
            for (i in 0 until lines.length()) {
                val ws = lines.getJSONObject(i).optJSONArray("Words") ?: continue
                val words = ArrayList<W>()
                for (j in 0 until ws.length()) {
                    val w = ws.getJSONObject(j)
                    val txt = w.optString("WordText", "").trim()
                    if (txt.isEmpty()) continue
                    val l = (w.optDouble("Left", 0.0) * back).toInt()
                    val t = (w.optDouble("Top", 0.0) * back).toInt()
                    val r = l + (w.optDouble("Width", 0.0) * back).toInt()
                    val b = t + (w.optDouble("Height", 0.0) * back).toInt()
                    words.add(W(txt, l, t, r, b))
                }
                words.sortBy { it.l }
                // OCR.space sütunları bir sətirdə birləşdirə bilir — boşluq böyükdürsə ayrıca sətirlərə bölünür (ML Kit kimi)
                var cur = ArrayList<W>()
                fun flush() {
                    if (cur.isEmpty()) return
                    out.add(OLine(cur.joinToString(" ") { it.t }, cur.minOf { it.l }, cur.minOf { it.tp }, cur.maxOf { it.r }, cur.maxOf { it.b }))
                    cur = ArrayList()
                }
                for (w in words) {
                    val last = cur.lastOrNull()
                    if (last != null && w.l - last.r > 1.2f * maxOf(w.h, last.h)) flush()
                    cur.add(w)
                }
                flush()
            }
            out
        } catch (e: Exception) {
            null
        }
    }

    private fun toast(ctx: Context, msg: String) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_LONG).show() }
    }
}
