package az.zeng.yazici;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static class Rec {
        String path, src, dir, label;
        long ts;
        int dur;
        boolean live;
    }

    static class VH {
        TextView play, time;
        SeekBar seek;
        String path;
        int dur;
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Rec> recs = new ArrayList<>();
    private final List<Rec> allRecs = new ArrayList<>();
    private String filter = "all";
    private LinearLayout rootLayout;
    private TextView countView;
    private SharedPreferences p;
    private TextView status;
    private Adapter ad;
    private MediaPlayer mp;
    private String curPath, sig = "";
    private VH curVH;
    private boolean resumed;

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (!resumed) return;
            reload(false);
            h.postDelayed(this, 4000);
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF0B1020);
        getWindow().setNavigationBarColor(0xFF0B1020);
        getWindow().getDecorView().setSystemUiVisibility(0);
        p = getSharedPreferences("st", 0);
        Notif.init(this);

        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(0xFF0B1020);
        rootLayout.setPadding(dp(16), dp(18), dp(16), 0);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18), dp(18), dp(18), dp(18));
        header.setBackground(round(0xFF151D32, 22));
        TextView eyebrow = label("ZƏNG MƏRKƏZİ  •  AVTOMATİK", 11, 0xFF8B9BBC);
        header.addView(eyebrow);
        TextView title = label("Zəng Yazıcı", 27, 0xFFF3F6FF);
        title.setPadding(0, dp(5), 0, dp(3));
        header.addView(title);
        status = label("Vəziyyət yoxlanılır…", 13, 0xFFB7C3DA);
        status.setPadding(0, dp(4), 0, dp(12));
        header.addView(status);
        Button start = btn("▶   Başlat / Quraşdır", v -> {
            if (!has(Manifest.permission.READ_PHONE_STATE) || !has(Manifest.permission.READ_CALL_LOG)) {
                askPerms();
            } else if (!AdbMgr.paired(this)) {
                pairing();
            } else {
                startProc();
            }
        });
        start.setTextColor(0xFFFFFFFF);
        start.setBackground(round(0xFF635BFF, 16));
        header.addView(start, new LinearLayout.LayoutParams(-1, dp(52)));
        Button settings = btn("⚙   Quraşdırma və əlavə seçimlər", v -> showSetup());
        settings.setTextColor(0xFFD8E1F4);
        settings.setBackground(round(0xFF26324B, 14));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(46));
        sp.topMargin = dp(8);
        header.addView(settings, sp);
        rootLayout.addView(header);

        LinearLayout listHead = new LinearLayout(this);
        listHead.setGravity(Gravity.CENTER_VERTICAL);
        listHead.setPadding(dp(2), dp(18), dp(2), dp(10));
        TextView lt = label("Zəng tarixçəsi", 19, 0xFFF3F6FF);
        listHead.addView(lt, new LinearLayout.LayoutParams(0, -2, 1));
        countView = label("0 yazı", 12, 0xFF9AA9C5);
        listHead.addView(countView);
        rootLayout.addView(listHead);

        LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.setPadding(0, 0, 0, dp(10));
        filters.addView(filterButton("Bütün", "all"), new LinearLayout.LayoutParams(0, dp(40), 1));
        filters.addView(filterButton("Gələn", "in"), new LinearLayout.LayoutParams(0, dp(40), 1));
        filters.addView(filterButton("Gedən", "out"), new LinearLayout.LayoutParams(0, dp(40), 1));
        rootLayout.addView(filters);

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(dp(8));
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setBackgroundColor(0xFF0B1020);
        ad = new Adapter();
        list.setAdapter(ad);
        list.setOnItemLongClickListener((par, v, pos, id) -> {
            if (pos >= 0 && pos < recs.size()) confirmDelete(recs.get(pos));
            return true;
        });
        rootLayout.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(rootLayout);
    }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        return d;
    }

    private Button filterButton(String text, String value) {
        Button b = btn(text, v -> { filter = value; updateFilterButtons(); applyFilter(); });
        b.setTextSize(13); b.setTextColor(0xFFDCE5F8); b.setPadding(0, 0, 0, 0);
        b.setBackground(round("all".equals(value) ? 0xFF635BFF : 0xFF202B42, 12));
        b.setTag(value);
        return b;
    }

    private void updateFilterButtons() {
        if (rootLayout == null) return;
        // Filter selection is reflected when the list is refreshed.
        View v = rootLayout;
        setFilterColors(v);
    }

    private void setFilterColors(View v) {
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View c = g.getChildAt(i);
                if (c instanceof Button && c.getTag() instanceof String) {
                    String f = (String) c.getTag();
                    c.setBackground(round(filter.equals(f) ? 0xFF635BFF : 0xFF202B42, 12));
                }
                setFilterColors(c);
            }
        }
    }

    private void applyFilter() {
        recs.clear();
        for (Rec r : allRecs) if ("all".equals(filter) || filter.equals(r.dir)) recs.add(r);
        if (countView != null) countView.setText(recs.size() + " yazı");
        if (ad != null) ad.notifyDataSetChanged();
    }

    private void showSetup() {
        String[] options = {"İcazələri ver", "Wireless debugging ilə cütləşdir", "Yazıcı prosesini başlat", "WhatsApp bildiriş girişini aktiv et", "Avtostart (Xiaomi / HyperOS)", "6 saniyəlik sınaq yazısı", "Jurnal / xəta məlumatı"};
        new AlertDialog.Builder(this).setTitle("Quraşdırma və seçimlər")
                .setItems(options, (d, which) -> {
                    switch (which) {
                        case 0: askPerms(); break;
                        case 1: pairing(); break;
                        case 2: startProc(); break;
                        case 3: startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); break;
                        case 4: autostart(); break;
                        case 5: test(); break;
                        case 6: showLog(); break;
                    }
                }).setNegativeButton("Bağla", null).show();
    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(0xFFEAF0FF);
        b.setBackground(round(0xFF26324B, 14));
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        refresh();
        reload(true);
        h.postDelayed(poll, 4000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        h.removeCallbacks(poll);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlayer();
    }

    private boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void refresh() {
        new Thread(() -> {
            final boolean up = RecorderClient.ping(this);
            runOnUiThread(() -> {
                StringBuilder s = new StringBuilder();
                s.append(up ? "✔ Yazıcı proses işləyir\n" : "✖ Yazıcı proses işləmir (2 və 3-cü düymələr)\n");
                s.append(AdbMgr.paired(this) ? "✔ Wireless debugging ilə cütləşib\n" : "✖ Hələ cütləşməyib\n");
                boolean ph = has(Manifest.permission.READ_PHONE_STATE) && has(Manifest.permission.READ_CALL_LOG)
                        && has(Manifest.permission.PROCESS_OUTGOING_CALLS);
                s.append(ph ? "✔ Telefon icazələri verilib\n" : "✖ Telefon icazələri çatmır\n");
                String en = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
                boolean nl = en != null && en.contains(getPackageName());
                s.append(nl ? "✔ WhatsApp üçün bildiriş girişi aktivdir" : "✖ WhatsApp üçün bildiriş girişi söndürülüb");
                status.setText(s.toString());
            });
        }).start();
    }

    private void askPerms() {
        List<String> need = new ArrayList<>(Arrays.asList(
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.PROCESS_OUTGOING_CALLS));
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(need.toArray(new String[0]), 1);
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] pm, int[] r) {
        super.onRequestPermissionsResult(c, pm, r);
        refresh();
    }

    private void pairing() {
        Notif.pairPrompt(this, "Developer options > Wireless debugging > \"Pair device with pairing code\" pəncərəsini açın və göstərilən 6 rəqəmli kodu bura yazın.");
        Toast.makeText(this, "Bildiriş panelini açıb kodu yazın", Toast.LENGTH_LONG).show();
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
        } catch (Throwable t) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void startProc() {
        Toast.makeText(this, "Başladılır…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String msg;
            try {
                AdbStarter.startDaemon(this);
                Thread.sleep(1200);
                if (RecorderClient.ping(this)) {
                    Intent monitor = new Intent(this, MonitorService.class).setAction(MonitorService.ACTION_START);
                    if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(monitor); else startService(monitor);
                    msg = "Yazıcı işləyir; arxa fonda zəng izləmə aktivdir";
                } else { msg = "Başladılmadı, Jurnala baxın"; }
            } catch (Throwable t) {
                msg = "Xəta: " + t.getMessage();
            }
            final String fm = msg;
            runOnUiThread(() -> {
                Toast.makeText(this, fm, Toast.LENGTH_LONG).show();
                refresh();
            });
        }).start();
    }

    private void autostart() {
        try {
            Intent i = new Intent();
            i.setComponent(new ComponentName("com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            startActivity(i);
        } catch (Throwable t) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void test() {
        RecorderClient.begin(this, "ph", "out", "Sinaq", null);
        h.postDelayed(() -> RecorderClient.end(this, "ph", () -> reload(true)), 6000);
    }

    private void showLog() {
        final String[] out = {""};
        RecorderClient.run(this, r -> out[0] = r.log(), err -> new AlertDialog.Builder(this)
                .setTitle("Jurnal")
                .setMessage((err != null ? "Xəta: " + err.getMessage() + "\n" : "") + (p.getString("adb_err", "").isEmpty() ? "" : "adb: " + p.getString("adb_err", "") + "\n") + (out[0].isEmpty() ? "" : out[0]))
                .setPositiveButton("Bağla", null)
                .show());
    }

    private void confirmDelete(final Rec r) {
        new AlertDialog.Builder(this)
                .setMessage("Bu yazı silinsin?\n" + r.label)
                .setPositiveButton("Sil", (d, w) -> {
                    if (r.path.equals(curPath)) stopPlayer();
                    new File(r.path).delete();
                    reload(true);
                })
                .setNegativeButton("Ləğv et", null)
                .show();
    }

    // ---------- siyahı ----------

    private File mediaDir() {
        File[] ds = getExternalMediaDirs();
        return ds != null && ds.length > 0 ? ds[0] : null;
    }

    private void reload(boolean force) {
        File d = mediaDir();
        File[] fs = d == null ? null : d.listFiles((x, n) -> n.endsWith(".wav"));
        if (fs == null) fs = new File[0];
        Arrays.sort(fs, (a, b) -> b.getName().compareTo(a.getName()));
        boolean active = p.getBoolean("active", false);
        String ap = p.getString("path", "");
        String s = fs.length + "|" + (fs.length > 0 ? fs[0].getName() : "") + "|" + active;
        if (!force && s.equals(sig)) return;
        sig = s;
        allRecs.clear();
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        for (File x : fs) {
            String n = x.getName().substring(0, x.getName().length() - 4);
            String[] a = n.split("__", 4);
            if (a.length < 4) continue;
            Rec r = new Rec();
            r.path = x.getAbsolutePath();
            r.src = a[1];
            r.dir = a[2];
            r.label = a[3].replace('_', ' ');
            try {
                r.ts = f.parse(a[0]).getTime();
            } catch (Exception e) {
                r.ts = x.lastModified();
            }
            r.live = active && r.path.equals(ap);
            r.dur = r.live ? 0 : durationOf(x);
            allRecs.add(r);
        }
        applyFilter();
    }

    private static int durationOf(File f) {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            if (f.length() <= 44) return 0;
            r.seek(24);
            byte[] b = new byte[4];
            r.readFully(b);
            int rate = (b[0] & 255) | ((b[1] & 255) << 8) | ((b[2] & 255) << 16) | ((b[3] & 255) << 24);
            if (rate <= 0) return 0;
            return (int) ((f.length() - 44) / (rate * 2L));
        } catch (Exception e) {
            return 0;
        }
    }

    private static String fmt(int sec) {
        return String.format(Locale.US, "%d:%02d", sec / 60, sec % 60);
    }

    // ---------- player ----------

    private void stopPlayer() {
        if (mp != null) {
            try {
                mp.release();
            } catch (Throwable ignored) {
            }
            mp = null;
        }
        curPath = null;
        curVH = null;
    }

    private void toggle(VH v, Rec r) {
        try {
            if (r.path.equals(curPath) && mp != null) {
                if (mp.isPlaying()) {
                    mp.pause();
                    v.play.setText("▶");
                } else {
                    mp.start();
                    v.play.setText("⏸");
                    tick();
                }
                return;
            }
            stopPlayer();
            mp = new MediaPlayer();
            mp.setDataSource(r.path);
            mp.prepare();
            mp.setOnCompletionListener(m -> {
                stopPlayer();
                ad.notifyDataSetChanged();
            });
            mp.start();
            curPath = r.path;
            curVH = v;
            v.play.setText("⏸");
            tick();
        } catch (Throwable t) {
            Toast.makeText(this, "Oxutmaq olmadı: " + t.getMessage(), Toast.LENGTH_LONG).show();
            stopPlayer();
        }
    }

    private final Runnable ticker = this::tick;

    private void tick() {
        h.removeCallbacks(ticker);
        if (mp == null || curVH == null) return;
        try {
            if (curPath != null && curPath.equals(curVH.path)) {
                int d = mp.getDuration(), c = mp.getCurrentPosition();
                curVH.seek.setMax(Math.max(d, 1));
                curVH.seek.setProgress(c);
                curVH.time.setText(fmt(c / 1000) + " / " + fmt(d / 1000));
            }
            if (mp.isPlaying()) h.postDelayed(ticker, 300);
        } catch (Throwable ignored) {
        }
    }

    // ---------- adapter ----------

    private class Adapter extends BaseAdapter {
        @Override
        public int getCount() {
            return recs.size();
        }

        @Override
        public Object getItem(int i) {
            return recs.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View cv, ViewGroup par) {
            final Rec r = recs.get(pos);
            LinearLayout root;
            TextView badge, arrow, name, when;
            VH v;
            if (cv == null) {
                root = new LinearLayout(MainActivity.this);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setPadding(dp(14), dp(12), dp(14), dp(12));
                root.setBackground(round(0xFF151D32, 16));

                LinearLayout top = new LinearLayout(MainActivity.this);
                top.setGravity(Gravity.CENTER_VERTICAL);
                badge = new TextView(MainActivity.this);
                badge.setTextColor(Color.WHITE);
                badge.setTextSize(11);
                badge.setPadding(dp(8), dp(2), dp(8), dp(2));
                arrow = new TextView(MainActivity.this);
                arrow.setTextSize(20);
                arrow.setPadding(dp(8), 0, dp(8), 0);
                name = new TextView(MainActivity.this);
                name.setTextSize(16);
                name.setTextColor(0xFFF1F5FF);
                name.setSingleLine(true);
                when = new TextView(MainActivity.this);
                when.setTextSize(12);
                top.addView(badge);
                top.addView(arrow);
                top.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                top.addView(when);
                root.addView(top);

                LinearLayout bar = new LinearLayout(MainActivity.this);
                bar.setGravity(Gravity.CENTER_VERTICAL);
                v = new VH();
                v.play = new TextView(MainActivity.this);
                v.play.setTextSize(24);
                v.play.setPadding(dp(4), dp(4), dp(12), dp(4));
                v.seek = new SeekBar(MainActivity.this);
                v.time = new TextView(MainActivity.this);
                v.time.setTextSize(12);
                v.time.setTextColor(0xFF9AA9C5);
                v.time.setPadding(dp(8), 0, 0, 0);
                bar.addView(v.play);
                bar.addView(v.seek, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                bar.addView(v.time);
                root.addView(bar);
                root.setTag(new Object[]{v, badge, arrow, name, when, bar});
                final VH fv = v;
                v.seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar s, int pr, boolean user) {
                        if (user && mp != null && fv.path != null && fv.path.equals(curPath)) mp.seekTo(pr);
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar s) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar s) {
                    }
                });
            } else {
                root = (LinearLayout) cv;
            }
            Object[] t = (Object[]) root.getTag();
            v = (VH) t[0];
            badge = (TextView) t[1];
            arrow = (TextView) t[2];
            name = (TextView) t[3];
            when = (TextView) t[4];
            View bar = (View) t[5];

            boolean wa = "wa".equals(r.src);
            boolean in = "in".equals(r.dir);
            badge.setText(wa ? "WhatsApp" : "Telefon");
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(10));
            bg.setColor(wa ? 0xFF25A244 : 0xFF455A64);
            badge.setBackground(bg);
            arrow.setText(in ? "↙" : "↗");
            arrow.setTextColor(in ? 0xFF42D6A4 : 0xFF8D9BFF);
            name.setText(r.label);
            when.setText(new SimpleDateFormat("dd.MM.yyyy  HH:mm", Locale.US).format(new Date(r.ts)));
            when.setTextColor(0xFF9AA9C5);

            v.path = r.path;
            v.dur = r.dur;
            if (r.live) {
                v.play.setText("●");
                v.play.setTextColor(0xFFE53935);
                v.seek.setVisibility(View.INVISIBLE);
                v.time.setText("yazılır…");
                v.play.setOnClickListener(null);
            } else {
                v.play.setTextColor(0xFFB9C5FF);
                v.seek.setVisibility(View.VISIBLE);
                v.play.setOnClickListener(x -> toggle(v0(x), r));
                if (r.path.equals(curPath) && mp != null) {
                    curVH = v;
                    v.play.setText(mp.isPlaying() ? "⏸" : "▶");
                    tick();
                } else {
                    v.play.setText("▶");
                    v.seek.setMax(Math.max(r.dur * 1000, 1));
                    v.seek.setProgress(0);
                    v.time.setText("0:00 / " + fmt(r.dur));
                }
            }
            root.setOnLongClickListener(x -> {
                confirmDelete(r);
                return true;
            });
            return root;
        }

        private VH v0(View playView) {
            LinearLayout root = (LinearLayout) ((View) playView.getParent()).getParent();
            return (VH) ((Object[]) root.getTag())[0];
        }
    }
}
