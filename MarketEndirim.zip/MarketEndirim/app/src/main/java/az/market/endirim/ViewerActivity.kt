package az.market.endirim

import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlinx.coroutines.launch

class ViewerActivity : AppCompatActivity() {
    private var pdfAdapter: PdfAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)

        @Suppress("DEPRECATION")
        val c = intent.getSerializableExtra("catalog") as Catalog

        val title = findViewById<TextView>(R.id.title)
        val counter = findViewById<TextView>(R.id.counter)
        val pager = findViewById<ViewPager2>(R.id.pager)
        val web = findViewById<WebView>(R.id.web)
        val progress = findViewById<ProgressBar>(R.id.progress)

        title.text = c.market + (c.date?.let { "  •  " + DateUtil.info(it).label } ?: "")
        findViewById<View>(R.id.back).setOnClickListener { finish() }

        when (c.kind) {
            Kind.IMAGES -> setPages(pager, counter, ImageAdapter(c.urls))
            Kind.WEB -> {
                pager.visibility = View.GONE
                web.visibility = View.VISIBLE
                web.settings.javaScriptEnabled = true
                web.settings.domStorageEnabled = true
                web.webViewClient = WebViewClient()
                web.loadUrl(c.urls[0])
            }
            Kind.PDF -> {
                progress.visibility = View.VISIBLE
                lifecycleScope.launch {
                    try {
                        val f = Downloader.ensure(applicationContext, c.urls[0])
                        val w = (resources.displayMetrics.widthPixels * 1.5f).toInt()
                        val a = PdfAdapter(f, w, lifecycleScope)
                        pdfAdapter = a
                        setPages(pager, counter, a)
                    } catch (e: Exception) {
                        Toast.makeText(this@ViewerActivity, "PDF açılmadı: ${e.message}", Toast.LENGTH_LONG).show()
                    } finally {
                        progress.visibility = View.GONE
                    }
                }
            }
        }
    }

    private fun setPages(pager: ViewPager2, counter: TextView, adapter: RecyclerView.Adapter<*>) {
        pager.adapter = adapter
        counter.text = "1/${adapter.itemCount}"
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                counter.text = "${position + 1}/${adapter.itemCount}"
            }
        })
    }

    override fun onDestroy() {
        pdfAdapter?.close()
        super.onDestroy()
    }
}
