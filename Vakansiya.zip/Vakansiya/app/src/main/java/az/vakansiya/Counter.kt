package az.vakansiya

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Calendar

/** Saytları gizli brauzerdə ardıcıl açıb bu gün / dünən tarixli elanları təxmini sayır. */
class Counter(
    private val ctx: Context,
    private val sites: List<Site>,
    private val onUpdate: (Int) -> Unit,
    private val onDone: () -> Unit
) {
    private val h = Handler(Looper.getMainLooper())
    private var wv: WebView? = null
    private var cur = -1
    private var evald = false
    var stopped = false

    private val months = arrayOf("yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avqust", "sentyabr", "oktyabr", "noyabr", "dekabr")
    private val end = "\$"

    private fun datePat(c: Calendar): String {
        val d = c.get(Calendar.DAY_OF_MONTH)
        val m = c.get(Calendar.MONTH) + 1
        val y = c.get(Calendar.YEAR)
        return "(^|[^0-9])0?$d[./-]0?$m[./-]$y|$y-0?$m-0?$d([^0-9]|$end)|(^|[^0-9])0?$d[ ]+${months[m - 1]}"
    }

    private fun js(): String {
        val cal = Calendar.getInstance()
        val t = datePat(cal) +
            "|bu gün|bugün|today|[0-9]+ (saat|dəqiqə|dəq|saniyə) əvvəl|[0-9]+ (hour|minute)s? ago|indicə|az əvvəl"
        cal.add(Calendar.DAY_OF_MONTH, -1)
        val y = datePat(cal) + "|dünən|yesterday|(^|[^0-9])1 gün əvvəl|1 day ago"
        return """(function(){var t=(document.body?document.body.innerText:'').replace(/\s+/g,' ').toLowerCase();
function c(p){var m=t.match(new RegExp(p,'g'));return m?m.length:0}
return c("$t")+","+c("$y");})()"""
    }

    fun start() {
        wv = WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, u: String) {
                    val my = cur
                    h.postDelayed({
                        if (!stopped && cur == my && !evald) {
                            evald = true
                            v.evaluateJavascript(js()) { r ->
                                if (cur == my && my >= 0 && my < sites.size) {
                                    try {
                                        val p = r.trim('"').split(",")
                                        sites[my].today = p[0].toInt()
                                        sites[my].yest = p[1].toInt()
                                    } catch (e: Exception) { }
                                    onUpdate(my)
                                    advance()
                                }
                            }
                        }
                    }, 3500)
                }
            }
        }
        advance()
    }

    private fun advance() {
        cur++
        evald = false
        if (cur >= sites.size || stopped) {
            wv?.destroy(); wv = null
            onDone()
            return
        }
        val my = cur
        wv?.loadUrl(sites[my].url)
        h.postDelayed({
            if (cur == my && !evald && !stopped) { evald = true; advance() }
        }, 20000)
    }

    fun stop() {
        stopped = true
        wv?.destroy(); wv = null
    }
}
