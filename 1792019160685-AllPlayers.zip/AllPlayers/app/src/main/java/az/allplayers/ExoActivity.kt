package az.allplayers

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class ExoActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val view = PlayerView(this)
        setContentView(view)
        val url = intent.getStringExtra("url") ?: return finish()
        player = ExoPlayer.Builder(this).build().also { p ->
            view.player = p
            p.setMediaItem(MediaItem.fromUri(url))
            p.addListener(object : Player.Listener {
                override fun onPlayerError(e: PlaybackException) {
                    Toast.makeText(this@ExoActivity, "Xəta: ${e.errorCodeName}", Toast.LENGTH_LONG).show()
                }
            })
            p.prepare(); p.playWhenReady = true
        }
    }

    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { super.onDestroy(); player?.release() }
}
