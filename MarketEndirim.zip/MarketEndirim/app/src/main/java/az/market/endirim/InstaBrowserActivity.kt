package az.market.endirim

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Mini brauzer: bütün marketlərin Instagram səhifələri.
 *  - Onlayn: səhifə canlı açılır (giriş bir dəfə edilir, cookie yadda qalır).
 *  - Oflayn: yalnız əvvəlcədən yüklənmiş post şəkilləri (InstaAuto) qalereya kimi göstərilir.
 *  - Sağa/sola sürüşdürmə: digər marketə keçid.
 */
class InstaBrowserActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var pager: ViewPager2
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var tabScroll: HorizontalScrollView
    private val tabs = ArrayList<Button>()
    private val users: List<Pair<String, String>> = InstaSaver.users()
    private var current = 0

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    /** Üfüqi sürüşdürməni tutur (uşaq görünüşlər toxunuşu öz qaydasında işləməyə davam edir). */
    private inner class SwipeFrame(c: Context) : FrameLayout(c) {
        private var downX = 0f
        private var downY = 0f
        private var multi = false

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            val r = super.dispatchTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = ev.x; downY = ev.y; multi = false }
                MotionEvent.ACTION_POINTER_DOWN -> multi = true
                MotionEvent.ACTION_UP -> {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (!multi && Math.abs(dx) > dp(90) && Math.abs(dx) > Math.abs(dy) * 2) {
                        val next = if (dx < 0) current + 1 else current - 1
                        if (next in users.indices) open(next)
                    }
                }
            }
            return r
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brand.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
        }
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        users.forEachIndexed { i, (market, _) ->
            val b = Button(this, null, 0, com.google.android.material.R.style.Widget_MaterialComponents_Button_TextButton).apply {
                text = market
                isAllCaps = false
                setOnClickListener { open(i) }
            }
            tabs.add(b)
            tabRow.addView(b)
        }
        tabScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabRow)
        }
        root.addView(tabScroll)

        status = TextView(this).apply {
            textSize = 13f
            setPadding(dp(16), 0, dp(16), dp(4))
        }
        root.addView(status)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        web = WebView(this)
        pager = ViewPager2(this).apply {
            orientation = ViewPager2.ORIENTATION_VERTICAL
            visibility = View.GONE
        }
        val holder = SwipeFrame(this)
        holder.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        holder.addView(pager, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(holder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            userAgentString = InstaSaver.UA
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val sc = request.url.scheme
                return sc != "http" && sc != "https"
            }

            override fun onPageFinished(view: WebView, url: String?) {
                progress.visibility = View.GONE
            }
        }
        web.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.visibility == View.VISIBLE && web.canGoBack()) web.goBack() else finish()
            }
        })
        // şəkil yükləmə prosesinin irəliləyişi (ana ekrandakı Instagram düyməsi başladır)
        InstaAuto.listener = { s -> status.text = s }
        val start = users.indexOfFirst { it.first == intent.getStringExtra("market") }.coerceAtLeast(0)
        open(start)
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        InstaAuto.listener = null
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    private fun highlight(i: Int) {
        current = i
        tabs.forEachIndexed { k, b ->
            b.alpha = if (k == i) 1f else 0.55f
            b.setTypeface(null, if (k == i) Typeface.BOLD else Typeface.NORMAL)
            if (k == i) b.setTextColor(Brand.colorOf(users[k].first))
        }
        tabScroll.post { tabScroll.smoothScrollTo((tabs[i].left - dp(48)).coerceAtLeast(0), 0) }
    }

    private fun savedInfo(user: String): String {
        val n = InstaSaver.images(this, user).size
        val t = InstaSaver.lastOk(this, user)
        return if (n > 0 && t > 0)
            "Saxlanıb: $n şəkil, " + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(Date(t))
        else "Offline şəkil yoxdur"
    }

    /** İnternet varsa canlı, yoxdursa saxlanmış şəkillər açılır. */
    private fun open(i: Int) {
        highlight(i)
        val user = users[i].second
        if (!Store.online(this)) {
            showGallery(user)
            return
        }
        pager.visibility = View.GONE
        web.visibility = View.VISIBLE
        web.settings.javaScriptEnabled = true
        web.loadUrl("https://www.instagram.com/$user/")
        status.text = "Canlı · " + savedInfo(user) +
            if (InstaSaver.needLogin(this) && !InstaSaver.loggedIn()) " · Şəkillərin yüklənməsi üçün burada Instagram-a daxil olun" else ""
    }

    private fun showGallery(user: String) {
        web.loadUrl("about:blank")
        web.visibility = View.GONE
        val files = InstaSaver.images(this, user)
        if (files.isEmpty()) {
            pager.visibility = View.GONE
            status.text = "Oflayn — bu market üçün saxlanmış şəkil yoxdur"
            return
        }
        pager.adapter = ImageAdapter(files.map { "file://" + it.absolutePath })
        pager.setCurrentItem(0, false)
        pager.visibility = View.VISIBLE
        status.text = "Oflayn · " + savedInfo(user)
    }
}
