package az.zeng.yazici;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


/** Tətbiq tərəfi: lokal soket ilə shell yazıcı prosesinə (Daemon) qoşulur. Lazım olsa onu adb ilə başladır. */
public final class RecorderClient {
    public interface Api {
        boolean start(String path, int mode) throws Exception;

        long stop() throws Exception;

        String log() throws Exception;
    }

    public interface Action {
        void run(Api r) throws Exception;
    }

    public interface Done {
        void done(Throwable err);
    }

    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();

    private RecorderClient() {
    }

    static synchronized void ident(Context c) {
        SharedPreferences p = c.getSharedPreferences("st", 0);
        if (p.getInt("d_port", 0) == 0 || p.getString("d_tok", null) == null) {
            p.edit().putInt("d_port", 30000 + new Random().nextInt(30000))
                    .putString("d_tok", UUID.randomUUID().toString().replace("-", "")).apply();
        }
    }

    private static String call(Context c, String line, int timeoutMs) throws IOException {
        ident(c);
        SharedPreferences p = c.getSharedPreferences("st", 0);
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress("127.0.0.1", p.getInt("d_port", 0)), 1500);
            s.setSoTimeout(timeoutMs);
            Writer w = new OutputStreamWriter(s.getOutputStream(), "UTF-8");
            w.write(p.getString("d_tok", "") + " " + line + "\n");
            w.flush();
            String r = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8")).readLine();
            if (r == null) throw new IOException("boş cavab");
            return r;
        }
    }

    /** Yazıcı proses işləyir və versiyası uyğundur? */
    public static boolean ping(Context c) {
        try {
            return ("OK " + Daemon.VER).equals(call(c, "PING", 1500));
        } catch (Throwable t) {
            return false;
        }
    }

    private static void ensureDaemon(Context c) throws Exception {
        String r = null;
        try {
            r = call(c, "PING", 1500);
        } catch (IOException ignored) {
        }
        if (("OK " + Daemon.VER).equals(r)) return;
        if (r != null && r.startsWith("OK")) {
            try {
                call(c, "QUIT", 1500);
            } catch (IOException ignored) {
            }
            Thread.sleep(400);
        }
        SharedPreferences p = c.getSharedPreferences("st", 0);
        if (!AdbMgr.paired(c))
            throw new Exception("Yazıcı proses işləmir və cütləşmə edilməyib (tətbiqdə 2-ci düymə)");
        if (!p.getBoolean("auto_adb", true))
            throw new Exception("Yazıcı proses işləmir (tətbiqdə 3-cü düyməni basın)");
        AdbStarter.startDaemon(c);
        for (int i = 0; i < 10; i++) {
            if (ping(c)) return;
            Thread.sleep(400);
        }
        throw new Exception("Yazıcı proses başlamadı");
    }

    private static Api api(final Context c) {
        return new Api() {
            @Override
            public boolean start(String path, int mode) throws Exception {
                return call(c, "START " + path + " " + mode, 8000).startsWith("OK");
            }

            @Override
            public long stop() throws Exception {
                String r = call(c, "STOP", 8000);
                try {
                    return Long.parseLong(r.substring(3).trim());
                } catch (Exception e) {
                    return 0;
                }
            }

            @Override
            public String log() throws Exception {
                String r = call(c, "LOG", 3000);
                return r.length() > 3 ? r.substring(3).replace("\\n", "\n") : "";
            }
        };
    }

    /** Əməliyyatı yazıcı prosesə qarşı icra edir; done həmişə əsas threaddə çağırılır. */
    public static void run(final Context ctx, final Action a, final Done d) {
        final Context c = ctx.getApplicationContext();
        EX.execute(() -> {
            Throwable err = null;
            try {
                ensureDaemon(c);
                a.run(api(c));
            } catch (Throwable t) {
                err = t;
            }
            final Throwable e = err;
            UI.post(() -> {
                if (d != null) d.done(e);
            });
        });
    }

    /** Zəng çalan/yığılan anda yazıcı prosesi öncədən hazırlayır (səssiz, xətalar buraxılır). */
    public static void warmUp(Context ctx, final Runnable after) {
        final Context c = ctx.getApplicationContext();
        EX.execute(() -> {
            try {
                ensureDaemon(c);
            } catch (Throwable ignored) {
            }
            if (after != null) UI.post(after);
        });
    }

    /** Yazını başladır (artıq aktivdirsə heç nə etmir). */
    public static void begin(Context c, String src, String dir, String label, Runnable after) {
        final Context a = c.getApplicationContext();
        final SharedPreferences p = a.getSharedPreferences("st", 0);
        final String path;
        synchronized (RecorderClient.class) {
            if (p.getBoolean("active", false) && System.currentTimeMillis() - p.getLong("t", 0) < 4 * 3600_000L) {
                if (after != null) after.run();
                return;
            }
            File[] dirs = a.getExternalMediaDirs();
            File d = (dirs != null && dirs.length > 0 && dirs[0] != null) ? dirs[0] : a.getExternalFilesDir(null);
            d.mkdirs();
            String name = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date())
                    + "__" + src + "__" + dir + "__" + safe(label) + ".wav";
            path = new File(d, name).getAbsolutePath();
            p.edit().putBoolean("active", true).putLong("t", System.currentTimeMillis())
                    .putString("src", src).putString("dir", dir).putString("label", label)
                    .putString("path", path).commit();
            HistoryStore.Item hi = new HistoryStore.Item();
            hi.id = path;
            hi.ts = System.currentTimeMillis();
            hi.src = src;
            hi.dir = dir;
            hi.label = label == null ? "" : label;
            hi.status = "rec";
            HistoryStore.add(a, hi);
        }
        final int mode = src.equals("ph") ? p.getInt("ph_mode", 0) : 1;
        Notif.recording(a, src, dir, label);
        run(a, r -> {
            if (!r.start(path, mode)) throw new Exception(lastLine(r.log()));
        }, err -> {
            if (err != null) {
                p.edit().putBoolean("active", false).apply();
                HistoryStore.update(a, path, 0, "err", String.valueOf(err.getMessage()));
                Notif.cancelRec(a);
                Notif.error(a, String.valueOf(err.getMessage()));
            }
            if (after != null) after.run();
        });
    }

    /** Yazını bitirir. src==null olarsa istənilən aktiv yazı dayandırılır. */
    public static void end(Context c, String src, Runnable after) {
        final Context a = c.getApplicationContext();
        final SharedPreferences p = a.getSharedPreferences("st", 0);
        final String asrc, dir, label, epath;
        synchronized (RecorderClient.class) {
            if (!p.getBoolean("active", false) || (src != null && !src.equals(p.getString("src", "")))) {
                if (after != null) after.run();
                return;
            }
            asrc = p.getString("src", "ph");
            dir = p.getString("dir", "in");
            label = p.getString("label", "");
            epath = p.getString("path", "");
            p.edit().putBoolean("active", false).commit();
        }
        final long[] ms = new long[1];
        run(a, r -> ms[0] = r.stop(), err -> {
            HistoryStore.update(a, epath, ms[0], err == null ? "ok" : "err", err == null ? "" : String.valueOf(err.getMessage()));
            Notif.cancelRec(a);
            Notif.saved(a, asrc, dir, label, ms[0], err);
            if (after != null) after.run();
        });
    }

    static String safe(String s) {
        if (s == null || s.trim().isEmpty()) return "Namelum";
        String r = s.trim().replaceAll("[^\\p{L}\\p{N}+\\-]", "_").replaceAll("_+", "_");
        return r.length() > 40 ? r.substring(0, 40) : r;
    }

    private static String lastLine(String log) {
        if (log == null) return "naməlum xəta";
        String[] ls = log.trim().split("\n");
        return ls.length == 0 ? "naməlum xəta" : ls[ls.length - 1];
    }
}
