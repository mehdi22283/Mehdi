package az.market.endirim

import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette

object Brand {
    /** Logo rəngi hələ oxunmayıbsa göstərilən neytral rəng. */
    val FALLBACK: Int = 0xFF455A64.toInt()

    val logos = mapOf(
        "Bravo Market" to "https://bravosupermarket.az/site/templates/img/newLogo.png",
        "Araz Market" to "https://www.arazmarket.az/_next/static/media/logo.42b6a354.svg",
        "Al Market" to "https://almarket.az/assets/img/icons/logo.svg",
        "Rahat Market" to "https://rahatmarket.az/images/s_logo.svg",
        "Tamstore" to "https://www.tamstore.az/uploads/1703078675-6582eb13d78b9.png"
    )

    /** Logodan oxunmuş rənglər */
    val colors = HashMap<String, Int>()

    fun pick(p: Palette?): Int? {
        val c = p?.vibrantSwatch?.rgb ?: p?.dominantSwatch?.rgb ?: return null
        return if (ColorUtils.calculateLuminance(c) > 0.9) null else c
    }
}
