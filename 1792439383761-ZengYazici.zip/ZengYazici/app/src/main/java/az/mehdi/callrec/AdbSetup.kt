package az.mehdi.callrec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.provider.Settings
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object AdbSetup {
    @Volatile var ui: ((String) -> Unit)? = null
    @Volatile private var busy = false

    private fun say(c: Context, msg: String) {
        ui?.invoke(msg)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("adb", "Quraşdırma", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(3, Notification.Builder(c, "adb").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Zəng Yazıcı").setContentText(msg).build())
    }

    fun codeNotification(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("adb", "Quraşdırma", NotificationManager.IMPORTANCE_HIGH))
        val ri = RemoteInput.Builder("code").setLabel("Pairing kodu (6 rəqəm)").build()
        val pi = PendingIntent.getBroadcast(c, 1, Intent(c, PairReceiver::class.java),
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val act = Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_send),
            "Kodu yaz", pi).addRemoteInput(ri).build()
        nm.notify(2, Notification.Builder(c, "adb").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Pairing kodunu yaz")
            .setContentText("Pair device with pairing code açıq olsun, kodu buraya yaz")
            .addAction(act).build())
    }

    private fun discover(c: Context, type: String): Int? {
        val nsd = c.getSystemService(NsdManager::class.java)
        val latch = CountDownLatch(1)
        var port: Int? = null
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onServiceFound(si: NsdServiceInfo) {
                try {
                    nsd.resolveService(si, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(s: NsdServiceInfo, e: Int) {}
                        override fun onServiceResolved(s: NsdServiceInfo) { port = s.port; latch.countDown() }
                    })
                } catch (e: Exception) { }
            }
            override fun onServiceLost(si: NsdServiceInfo) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) { latch.countDown() }
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l)
        latch.await(12, TimeUnit.SECONDS)
        try { nsd.stopServiceDiscovery(l) } catch (e: Exception) { }
        return port
    }

    fun run(c0: Context, code: String) {
        val c = c0.applicationContext
        if (busy) return
        busy = true
        Thread {
            try {
                say(c, "Cütləşmə xidməti axtarılır…")
                val pp = discover(c, "_adb-tls-pairing._tcp")
                    ?: throw Exception("Pair dialoqu açıq deyil və ya Wi-Fi yoxdur")
                val m = AdbMgr.get(c)
                say(c, "Cütləşdirilir…")
                if (!m.pair("127.0.0.1", pp, code)) throw Exception("Kod səhvdir")
                say(c, "Qoşulur…")
                val cp = discover(c, "_adb-tls-connect._tcp")
                    ?: throw Exception("Wireless debugging aktiv deyil")
                if (!m.connect("127.0.0.1", cp)) throw Exception("Qoşulmaq alınmadı")
                say(c, "İcazələr verilir…")
                val pkg = c.packageName
                listOf(
                    "pm grant $pkg android.permission.RECORD_AUDIO",
                    "pm grant $pkg android.permission.READ_PHONE_STATE",
                    "pm grant $pkg android.permission.READ_CALL_LOG",
                    "pm grant $pkg android.permission.POST_NOTIFICATIONS",
                    "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS",
                    "appops set $pkg RUN_IN_BACKGROUND allow",
                    "dumpsys deviceidle whitelist +$pkg"
                ).forEach { cmd ->
                    try {
                        val s = m.openStream("shell:$cmd")
                        try { s.openInputStream().readBytes() } finally { try { s.close() } catch (e: Exception) { } }
                    } catch (e: Exception) { }
                }
                try { m.disconnect() } catch (e: Exception) { }
                val acc = enableAccessibility(c)
                say(c, if (acc) "✅ Hazırdır. Tətbiqi aç." else "✅ İcazələr verildi. WhatsApp izləməni aktiv et.")
            } catch (e: Throwable) {
                say(c, "❌ " + (e.message ?: e.toString()))
            } finally { busy = false }
        }.start()
    }

    fun enableAccessibility(c: Context): Boolean = try {
        val comp = "${c.packageName}/${c.packageName}.WaService"
        val cur = Settings.Secure.getString(c.contentResolver, "enabled_accessibility_services") ?: ""
        if (!cur.contains(comp))
            Settings.Secure.putString(c.contentResolver, "enabled_accessibility_services",
                if (cur.isEmpty()) comp else "$cur:$comp")
        Settings.Secure.putString(c.contentResolver, "accessibility_enabled", "1")
        true
    } catch (e: SecurityException) { false }
}
