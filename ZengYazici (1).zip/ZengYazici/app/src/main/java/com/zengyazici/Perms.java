package com.zengyazici;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import java.util.ArrayList;
import java.util.List;

/** Tətbiqin işləməsi üçün lazım olan bütün icazələrin cari vəziyyəti. */
public class Perms {
    public static class Row {
        public final String name;
        public final boolean ok;
        Row(String n, boolean o) { name = n; ok = o; }
    }

    private static boolean granted(Context c, String p) {
        return c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean adb() {
        try { AdbMgr m = AdbMgr.peek(); return m != null && m.isConnected(); } catch (Throwable e) { return false; }
    }

    public static boolean runtime(Context c) {
        boolean ok = granted(c, Manifest.permission.READ_PHONE_STATE)
                && granted(c, Manifest.permission.READ_CALL_LOG)
                && granted(c, Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33) ok &= granted(c, Manifest.permission.POST_NOTIFICATIONS);
        return ok;
    }

    public static boolean listener(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(c.getPackageName() + "/");
    }

    public static boolean accessibility(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), "enabled_accessibility_services");
        boolean on = Settings.Secure.getInt(c.getContentResolver(), "accessibility_enabled", 0) == 1;
        return on && s != null && s.contains(c.getPackageName() + "/");
    }

    public static boolean overlay(Context c) { return Settings.canDrawOverlays(c); }

    public static boolean battery(Context c) {
        try {
            return ((PowerManager) c.getSystemService(Context.POWER_SERVICE)).isIgnoringBatteryOptimizations(c.getPackageName());
        } catch (Throwable e) { return false; }
    }

    public static List<Row> rows(Context c) {
        List<Row> l = new ArrayList<>();
        l.add(new Row("ADB qoşulması", adb()));
        l.add(new Row("Telefon vəziyyəti", granted(c, Manifest.permission.READ_PHONE_STATE)));
        l.add(new Row("Zəng jurnalı", granted(c, Manifest.permission.READ_CALL_LOG)));
        l.add(new Row("Mikrofon", granted(c, Manifest.permission.RECORD_AUDIO)));
        if (Build.VERSION.SDK_INT >= 33) l.add(new Row("Bildirişlər", granted(c, Manifest.permission.POST_NOTIFICATIONS)));
        l.add(new Row("Bildiriş girişi", listener(c)));
        l.add(new Row("Əlçatımlılıq", accessibility(c)));
        l.add(new Row("Tətbiqlərin üstündə göstərmə", overlay(c)));
        l.add(new Row("Batareya: məhdudiyyət yoxdur", battery(c)));
        return l;
    }

    public static boolean allOk(Context c) {
        for (Row r : rows(c)) if (!r.ok) return false;
        return true;
    }
}
