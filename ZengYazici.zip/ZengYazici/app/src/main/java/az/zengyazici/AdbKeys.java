package az.zengyazici;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.util.Date;
import java.util.Random;

import sun.security.x509.AlgorithmId;
import sun.security.x509.CertificateAlgorithmId;
import sun.security.x509.CertificateExtensions;
import sun.security.x509.CertificateIssuerName;
import sun.security.x509.CertificateSerialNumber;
import sun.security.x509.CertificateSubjectName;
import sun.security.x509.CertificateValidity;
import sun.security.x509.CertificateVersion;
import sun.security.x509.CertificateX509Key;
import sun.security.x509.KeyIdentifier;
import sun.security.x509.PrivateKeyUsageExtension;
import sun.security.x509.SubjectKeyIdentifierExtension;
import sun.security.x509.X500Name;
import sun.security.x509.X509CertImpl;
import sun.security.x509.X509CertInfo;

final class AdbKeys {
    private AdbKeys() {}

    /** @return {PrivateKey, java.security.cert.Certificate} */
    static Object[] generate() throws Exception {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048, SecureRandom.getInstance("SHA1PRNG"));
        KeyPair kp = g.generateKeyPair();
        PublicKey pub = kp.getPublic();
        PrivateKey priv = kp.getPrivate();
        String alg = "SHA512withRSA";
        Date nb = new Date();
        Date na = new Date(System.currentTimeMillis() + 10L * 365L * 86400000L);
        CertificateExtensions ext = new CertificateExtensions();
        ext.set("SubjectKeyIdentifier", new SubjectKeyIdentifierExtension(new KeyIdentifier(pub).getIdentifier()));
        X500Name name = new X500Name("CN=ZengYazici");
        ext.set("PrivateKeyUsage", new PrivateKeyUsageExtension(nb, na));
        X509CertInfo info = new X509CertInfo();
        info.set("version", new CertificateVersion(2));
        info.set("serialNumber", new CertificateSerialNumber(new Random().nextInt() & Integer.MAX_VALUE));
        info.set("algorithmID", new CertificateAlgorithmId(AlgorithmId.get(alg)));
        info.set("subject", new CertificateSubjectName(name));
        info.set("key", new CertificateX509Key(pub));
        info.set("validity", new CertificateValidity(nb, na));
        info.set("issuer", new CertificateIssuerName(name));
        info.set("extensions", ext);
        X509CertImpl cert = new X509CertImpl(info);
        cert.sign(priv, alg);
        return new Object[]{priv, cert};
    }
}
