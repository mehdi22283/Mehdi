package az.zeng.yazici;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * adb (shell uid) ilə başladılan ayrıca proses:
 * app_process -Djava.class.path=APK /system/bin az.zeng.yazici.Daemon PORT TOKEN
 * Yalnız 127.0.0.1 üzərində, token ilə qorunan sadə sətir protokolu dinləyir.
 */
public class Daemon {
    static final int VER = 1;

    public static void main(String[] a) {
        int port = Integer.parseInt(a[0]);
        String token = a[1];
        Recorder rec = new Recorder();
        try (ServerSocket ss = new ServerSocket(port, 4, InetAddress.getByName("127.0.0.1"))) {
            while (true) {
                try (Socket s = ss.accept()) {
                    s.setSoTimeout(3000);
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
                    Writer out = new OutputStreamWriter(s.getOutputStream(), "UTF-8");
                    String line = in.readLine();
                    String resp = handle(rec, token, line);
                    out.write(resp + "\n");
                    out.flush();
                    if ("OK bye".equals(resp)) {
                        rec.stopInternal();
                        System.exit(0);
                    }
                } catch (Throwable t) {
                    // növbəti bağlantı
                }
            }
        } catch (Throwable t) {
            // port məşğuldur = daemon artıq işləyir
            System.exit(1);
        }
    }

    private static String handle(Recorder rec, String token, String line) {
        if (line == null) return "ERR empty";
        String[] p = line.split(" ", 3);
        if (p.length < 2 || !token.equals(p[0])) return "ERR auth";
        switch (p[1]) {
            case "PING":
                return "OK " + VER;
            case "START":
                if (p.length < 3) return "ERR args";
                String[] q = p[2].split(" ");
                if (q.length < 2) return "ERR args";
                return rec.start(q[0], Integer.parseInt(q[1])) ? "OK" : "ERR start";
            case "STOP":
                return "OK " + rec.stop();
            case "STATUS":
                return "OK " + rec.isRecording();
            case "LOG":
                return "OK " + rec.getLog().replace("\n", "\\n");
            case "QUIT":
                return "OK bye";
            default:
                return "ERR cmd";
        }
    }
}
