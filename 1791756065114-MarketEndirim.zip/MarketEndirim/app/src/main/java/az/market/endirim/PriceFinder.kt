package az.market.endirim

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Məhsul adının yeri (OCR sətirlərinin birləşmiş çərçivəsi). */
data class NameBox(val name: String, val l: Int, val t: Int, val r: Int, val b: Int) {
    val w get() = r - l
    val h get() = b - t
}

/**
 * Səhifədəki qiymətləri tapır və hər məhsul adına ən uyğun qiyməti seçir:
 *  1) qiymət namizədləri: X.XX / XX.XX / X,XX (yanında ₼ ola da bilər, olmaya da), ₼-lı tək ədəd, iri tək ədəd (+ yanındakı kiçik qəpik);
 *  2) üstündən xətt çəkilmiş (köhnə) qiymətlər piksel təhlili ilə ayrılıb atılır;
 *  3) ad çərçivəsinin ətrafında görünməz halqa genişlənir, ilk toxunduğu qiymət seçilir (eyni anda bir neçəsinə toxunarsa — ən irisi).
 */
object PriceFinder {
    class PBox(val value: String, val l: Int, val t: Int, val r: Int, val b: Int, val struck: Boolean) {
        val h get() = b - t
    }

    private val DEC = Regex("""(?<![\d.,])(\d{1,3})\s?[.,]\s?(\d{2})(?!\d)\s*(₼|azn|man\.?)?""", RegexOption.IGNORE_CASE)
    private val INT_CUR = Regex("""^\D{0,2}(\d{1,3})\s?(₼|azn|man\.?)\s*$""", RegexOption.IGNORE_CASE)
    private val INT_ONLY = Regex("""^(\d{1,2})$""")
    private val CENTS = Regex("""^[.,]?\s?(\d{2})\s?(₼|azn|man\.?)?$""", RegexOption.IGNORE_CASE)
    private val UNIT_AFTER = Regex("""^\s*(kq|kg|qr|gr|g|ml|l|litr|sm|mm|m|əd|ədəd|%)(?![\p{L}])""", RegexOption.IGNORE_CASE)

    fun candidates(lines: List<OLine>, bmp: Bitmap): List<PBox> {
        val out = ArrayList<PBox>()
        val letterH = lines.filter { it.text.count { c -> c.isLetter() } >= 3 }.map { it.h }.sorted()
        val medH = if (letterH.isEmpty()) 20 else letterH[letterH.size / 2]
        val used = BooleanArray(lines.size)

        fun add(v: String, l: Int, t: Int, r: Int, b: Int) {
            out.add(PBox(v, l, t, r, b, isStruck(bmp, l, t, r, b)))
        }

        for ((i, ln) in lines.withIndex()) {
            val tx = ln.text.trim()
            if (tx.contains('%')) continue
            val m = DEC.find(tx)
            if (m != null) {
                val cur = m.groupValues[3].isNotEmpty()
                val after = tx.substring(m.range.last + 1)
                if (!cur && UNIT_AFTER.containsMatchIn(after)) continue        // 1.50 kq, 0.50 L — çəki/həcm, qiymət deyil
                if (tx.length - m.value.length > 6 && !cur) continue           // sətirdə çoxlu əlavə mətn varsa, qiymət sətri deyil
                used[i] = true
                add(m.groupValues[1] + "." + m.groupValues[2] + "₼", ln.l, ln.t, ln.r, ln.b)
                continue
            }
            val mi = INT_CUR.find(tx)
            if (mi != null) {
                used[i] = true
                add(mi.groupValues[1] + "₼", ln.l, ln.t, ln.r, ln.b)
            }
        }

        // iri tək ədəd (məs. "2") + sağında kiçik qəpik ("99") → 2.99₼
        for ((i, ln) in lines.withIndex()) {
            if (used[i]) continue
            val m = INT_ONLY.find(ln.text.trim()) ?: continue
            if (ln.h < 1.8f * medH) continue
            var best: OLine? = null
            for ((j, o) in lines.withIndex()) {
                if (j == i || used[j]) continue
                if (!CENTS.containsMatchIn(o.text.trim())) continue
                val gap = o.l - ln.r
                if (gap < -0.2f * ln.h || gap > 0.7f * ln.h) continue
                if (o.t > ln.t + 0.5f * ln.h || o.h > 0.8f * ln.h) continue
                if (best == null || o.l < best.l) best = o
            }
            val v = if (best != null) {
                val c = CENTS.find(best.text.trim())!!.groupValues[1]
                used[lines.indexOf(best)] = true
                m.groupValues[1] + "." + c + "₼"
            } else m.groupValues[1] + "₼"
            used[i] = true
            add(v, ln.l, ln.t, max(ln.r, best?.r ?: ln.r), max(ln.b, best?.b ?: ln.b))
        }
        return out
    }

    /** Görünməz halqanın radiusu: ad çərçivəsi hər tərəfə neçə piksel genişlənəndə qiymət çərçivəsinə toxunur (0 = üst-üstə düşür). */
    private fun ringGap(a: NameBox, p: PBox): Int {
        val dx = max(0, max(a.l, p.l) - min(a.r, p.r))
        val dy = max(0, max(a.t, p.t) - min(a.b, p.b))
        return max(dx, dy)
    }

    /**
     * Ad çərçivəsinin ətrafında görünməz halqa hər tərəfə genişlənir; halqanın ilk toxunduğu qiymət götürülür.
     * Üstündən xətt çəkilmiş qiymətlərə toxunmaq sayılmır (halqa onların üstündən keçib davam edir).
     * Eyni addımda (ad hündürlüyünün ~15%-i daxilində) bir neçə qiymətə birdən toxunarsa, şrifti ən iri olan seçilir.
     */
    fun pick(nb: NameBox, cands: List<PBox>, pageW: Int): String? {
        val maxR = min(max(nb.w, nb.h * 6).toFloat(), pageW * 0.45f) * 1.3f
        val hits = cands.filter { !it.struck }.map { it to ringGap(nb, it) }.filter { it.second <= maxR }
        if (hits.isEmpty()) return null
        val first = hits.minOf { it.second }
        val step = max(2, (nb.h * 0.15f).toInt())
        return hits.filter { it.second <= first + step }.maxByOrNull { it.first.h }?.first?.value
    }

    // ---------------- üstündən xətt çəkilmə yoxlaması ----------------

    /**
     * Qiymətin çərçivəsində fon rəngindən fərqli piksellərdən ibarət fasiləsiz düz xətt (üfüqi, maili və ya çarpaz)
     * çərçivənin ≥70%-ni keçirsə, qiymət üstündən xətt çəkilmiş sayılır. Rəqəmlər arasında boşluq olduğundan rəqəmlər belə xətt yaratmır.
     */
    private fun isStruck(bmp: Bitmap, l0: Int, t0: Int, r0: Int, b0: Int): Boolean {
        val l = l0.coerceIn(0, bmp.width - 1)
        val t = t0.coerceIn(0, bmp.height - 1)
        val r = r0.coerceIn(l + 1, bmp.width)
        val b = b0.coerceIn(t + 1, bmp.height)
        val w = r - l
        val h = b - t
        if (w < 12 || h < 6 || w < 1.3f * h) return false     // tək rəqəm: yoxlama etibarsızdır
        val px = IntArray(w * h)
        try { bmp.getPixels(px, 0, w, l, t, w, h) } catch (e: Exception) { return false }

        // fon = çərçivənin kənar zolağındakı (üst/alt 2 sətir, sol/sağ 1 sütun) ən çox təkrarlanan rəng;
        // bütün sahənin modası yox — qalın rəqəmlər sahənin yarısını tuta bilər
        val hist = HashMap<Int, Int>()
        fun vote(c: Int) {
            val k = ((c shr 20) and 0xF) shl 8 or (((c shr 12) and 0xF) shl 4) or ((c shr 4) and 0xF)
            hist[k] = (hist[k] ?: 0) + 1
        }
        for (y in 0 until h) {
            val edgeRow = y < 2 || y >= h - 2
            if (edgeRow) for (x in 0 until w) vote(px[y * w + x]) else { vote(px[y * w]); vote(px[y * w + w - 1]) }
        }
        val bk = hist.maxByOrNull { it.value }!!.key
        val br = ((bk shr 8) and 0xF) * 16 + 8
        val bg = ((bk shr 4) and 0xF) * 16 + 8
        val bb = (bk and 0xF) * 16 + 8
        val ink = BooleanArray(w * h) { i ->
            val c = px[i]
            abs(((c shr 16) and 0xFF) - br) + abs(((c shr 8) and 0xFF) - bg) + abs((c and 0xFF) - bb) > 110
        }
        fun at(x: Int, y: Int): Boolean = x in 0 until w && y in 0 until h && ink[y * w + x]
        // 1–2 piksel qalınlıqlı xəttin sətirə uyğunsuzluğuna dözüm
        fun near(x: Int, y: Int): Boolean = at(x, y) || at(x, y - 1) || at(x, y + 1)

        val fr = floatArrayOf(0f, 0.15f, 0.3f, 0.45f, 0.5f, 0.55f, 0.7f, 0.85f, 1f)
        val need = 0.7f
        for (a in fr) for (c in fr) {
            val y0 = a * (h - 1)
            val y1 = c * (h - 1)
            var run = 0
            var miss = 0
            var best = 0
            for (x in 0 until w) {
                val y = (y0 + (y1 - y0) * x / (w - 1)).toInt()
                if (near(x, y)) { run++; miss = 0; if (run > best) best = run }
                else { miss++; if (miss > 2) { run = 0; miss = 0 } else run++ }   // ən çox 2 piksellik qırıqlara dözüm
            }
            if (best >= need * w) return true
        }
        return false
    }
}
