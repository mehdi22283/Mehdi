package az.vakansiya

import android.content.Context
import org.json.JSONArray
import java.util.Locale

/**
 * "Xüsusi Vakansiya" açar sözləri.
 * Yazılış: kiçik hərflə, azərbaycan hərfləri sadələşdirilmiş (ə→e, ı→i, ö→o, ü→u, ç→c, ş→s, ğ→g).
 * Prefiks:  "="  → yalnız tam söz kimi (məs. "=it")
 *           "^"  → yalnız başlığın əvvəlində (məs. "^operator")
 *           heç nə → sözün əvvəli uyğun gəlsə kifayətdir (məs. "qeydiyyatci" → "qeydiyyatçısı" da tapılır)
 * Yeni söz əlavə etmək üçün siyahıya sətir əlavə etmək yetərlidir.
 */
object Keywords {
    /** İT (ən yüksək prioritet) — ilkin siyahı */
    val DEF_IT = listOf(
        "=it", "it support", "it dəstək",
        "informasiya texnologiyaları", "information technology",
        "texniki dəstək", "texniki mütəxəssis",
        "technical support", "tech support", "technical specialist", "technical engineer",
        "helpdesk", "help desk", "help-desk", "service desk", "servicedesk",
        "support specialist", "support engineer", "dəstək mütəxəssis", "dəstək mühəndis",
        "kompüter texniki", "kompyuter texniki", "kompüter mühəndis", "kompüter mütəxəssis",
        "kompyuter mütəxəssis", "avadanlıq texniki"
    )

    /** Çağrı mərkəzi və qeydiyyat / resepşn — ilkin siyahı */
    val DEF_OTHER = listOf(
        "çağrı mərkəzi", "çağrı operator", "çağırış mərkəzi", "call center", "call centre",
        "call-center", "callcenter", "contact center", "contact centre", "contact-center",
        "əlaqə mərkəzi", "zəng mərkəzi", "kol mərkəz", "kol sentr",
        "müştəri xidmətləri", "müştəri dəstək", "müştəri təmsilçi", "customer support", "customer service",
        "customer care", "hotline", "qaynar xətt", "telefon operator", "kol operator", "zəng operator",
        "əlaqə operator", "müştəri operator", "chat operator", "online operator", "^operator",
        "qeydiyyatçı", "resepsiyon", "resepşn", "ressepşn", "resepsion", "recepsion",
        "reception", "front desk", "frontdesk", "ön qeydiyyat"
    )

    private fun fold(x: String) = x.lowercase(Locale.ROOT)
        .replace('ə', 'e').replace('ı', 'i').replace('ö', 'o').replace('ü', 'u')
        .replace('ç', 'c').replace('ş', 's').replace('ğ', 'g').replace("i̇", "i").trim()

    /** Əvvəlki versiyada ASCII yazılmış ilkin sözləri Azərbaycan hərfli formaya çevirir. */
    private val upgrade: Map<String, String> by lazy { (DEF_IT + DEF_OTHER).associateBy { fold(it) } }

    private fun prefs(c: Context) = c.getSharedPreferences("kw", Context.MODE_PRIVATE)

    private fun read(c: Context, key: String, def: List<String>): MutableList<String> {
        val s = prefs(c).getString(key, null) ?: return def.toMutableList()
        return try {
            val a = JSONArray(s)
            MutableList(a.length()) { val w = a.getString(it); if (w == fold(w)) (upgrade[w] ?: w) else w }
        } catch (e: Exception) { def.toMutableList() }
    }

    fun it(c: Context): MutableList<String> = read(c, "it", DEF_IT)
    fun other(c: Context): MutableList<String> = read(c, "other", DEF_OTHER)

    fun save(c: Context, it: List<String>, other: List<String>) {
        prefs(c).edit().putString("it", JSONArray(it).toString()).putString("other", JSONArray(other).toString()).apply()
    }

    /** Səhifəyə yerləşdirilən JS parçası: S massivi və kindOf(başlıq) / titleOf(link, kart) funksiyaları. */
    fun js(c: Context): String {
        val itJson = JSONArray(it(c)).toString()
        val other = JSONArray(other(c)).toString()
        return """var S=[],KW_IT=$itJson,KW_OT=$other;
function fold(x){return (x||'').toLowerCase().replace(/\u0307/g,'').replace(/ə/g,'e').replace(/ı/g,'i').replace(/ö/g,'o').replace(/ü/g,'u').replace(/ç/g,'c').replace(/ş/g,'s').replace(/ğ/g,'g').replace(/\s+/g,' ').trim()}
function isL(c){return /[a-z0-9\u0430-\u044f\u0451]/.test(c)}
function hasKw(t,kw){kw=fold(kw);var w=false,st=false;
 if(kw.charAt(0)=='='){w=true;kw=kw.substring(1)}else if(kw.charAt(0)=='^'){st=true;kw=kw.substring(1)}
 var i=t.indexOf(kw);
 while(i>=0){
  if(st){if(i==0)return true}
  else{var okL=i==0||!isL(t.charAt(i-1));var okR=!w||i+kw.length>=t.length||!isL(t.charAt(i+kw.length));if(okL&&okR)return true}
  i=t.indexOf(kw,i+1)}
 return false}
function kindOf(title){var t=fold(title);if(t.length<2)return 0;
 for(var i=0;i<KW_IT.length;i++){if(hasKw(t,KW_IT[i]))return 1}
 for(var j=0;j<KW_OT.length;j++){if(hasKw(t,KW_OT[j]))return 2}
 return 0}
var SAL=/\u20bc|(^|[^a-z])(azn|manat)([^a-z]|$)|^[0-9][0-9 .,\u2013-]*$/;
function isSal(z){return SAL.test((z||'').toLowerCase())}
function cleanT(z){return (z||'').replace(/[0-9][0-9 .,\u2013-]*[ ]*(\u20bc|azn|manat)/ig,' ').replace(/\s+/g,' ').trim()}
function lns(el){var p=((el&&el.innerText)||'').split('\n'),o=[];for(var i=0;i<p.length;i++){var z=p[i].trim();if(z)o.push(z)}return o}
function titleOf(a,card){var h=null;try{h=card.querySelector('h1,h2,h3,h4,h5')}catch(e){}
 var s=(h&&h.innerText)?h.innerText:(a.innerText||'');var p=s.split('\n'),o=[];
 for(var i=0;i<p.length&&o.length<2;i++){var z=p[i].trim();if(z)o.push(z)}
 var bad=false;for(var q=0;q<o.length;q++){if(isSal(o[q]))bad=true}
 if(!bad)return o.join(' ').substring(0,140);
 /* ilk sətirlər maaşdır (₼): elan adı maaşın üstündəki sətirdir */
 var anc=(a.innerText||'').split('\n')[0].trim(),el=card;
 for(var u=0;u<4&&el;u++){var L=lns(el),k=L.indexOf(anc);if(k<0||!isSal(L[k])){k=-1;for(var m=0;m<L.length;m++){if(isSal(L[m])){k=m;break}}}
  if(k>0){for(var j=k-1;j>=0;j--){if(!isSal(L[j])&&/[a-z\u0430-\u044f\u0259\u0131\u00f6\u00fc\u00e7\u015f\u011f]/i.test(L[j]))return cleanT(L[j]).substring(0,140)}}
  if(k>=0){for(var j=k+1;j<L.length;j++){if(!isSal(L[j])&&L[j].length>2)return cleanT(L[j]).substring(0,140)}}
  el=el.parentElement}
 return cleanT(o.join(' ')).substring(0,140)}
"""
    }
}
