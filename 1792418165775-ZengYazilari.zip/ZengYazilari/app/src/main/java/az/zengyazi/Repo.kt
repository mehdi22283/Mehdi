package az.zengyazi

import android.content.Context
import android.media.MediaMetadataRetriever
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/** Hazırda gedən yazının məlumatı. null = yazı yoxdur. */
data class Info(val number: String, val app: String, val incoming: Boolean, val startMs: Long)

object RecState {
    val active = MutableStateFlow<Info?>(null)
    val source = MutableStateFlow("")
}

/** Bütün səs mənbələri. Avtomatik rejimdə yuxarıdan aşağı sınanır. */
object Sources {
    val all: List<Pair<String, Int>> = buildList {
        add("Zəng səsi (VOICE_CALL)" to 4)
        add("Zəng gələn səs (VOICE_DOWNLINK)" to 3)
        add("Zəng gedən səs (VOICE_UPLINK)" to 2)
        add("Sistem səsi (REMOTE_SUBMIX)" to 8)
        add("Emalsız mikrofon (UNPROCESSED)" to 9)
        add("Səs tanıma (VOICE_RECOGNITION)" to 6)
        add("Mikrofon (MIC)" to 1)
        add("Kamera mikrofonu (CAMCORDER)" to 5)
        if (android.os.Build.VERSION.SDK_INT >= 29) add("Səs performansı (VOICE_PERFORMANCE)" to 10)
        add("Zəng mikrofonu (VOICE_COMMUNICATION)" to 7)
        add("Defolt (DEFAULT)" to 0)
    }
}

data class Rec(
    val file: File, val ts: Long, val incoming: Boolean,
    val app: String, val number: String, val durMs: Int
)

object Repo {
    private fun dir(c: Context) = File(c.filesDir, "recordings").apply { mkdirs() }

    fun newFile(c: Context, i: Info): File {
        val n = i.number.replace(Regex("[\\\\/_:*?\"<>|]"), "-").ifBlank { "Namelum" }
        val d = if (i.incoming) "in" else "out"
        val a = if (i.app == "WhatsApp") "wa" else "ph"
        return File(dir(c), "${i.startMs}_${d}_${a}_$n.m4a")
    }

    fun load(c: Context): List<Rec> =
        (dir(c).listFiles() ?: emptyArray()).mapNotNull { f ->
            val p = f.name.removeSuffix(".m4a").split("_", limit = 4)
            if (p.size != 4) return@mapNotNull null
            val dur = try {
                MediaMetadataRetriever().run {
                    setDataSource(f.path)
                    val v = extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toInt() ?: 0
                    release(); v
                }
            } catch (e: Exception) { 0 }
            Rec(f, p[0].toLongOrNull() ?: 0L, p[1] == "in",
                if (p[2] == "wa") "WhatsApp" else "Telefon", p[3], dur)
        }.sortedByDescending { it.ts }

    fun hasConsent(c: Context) =
        c.getSharedPreferences("p", Context.MODE_PRIVATE).getBoolean("consent", false)

    fun setConsent(c: Context) =
        c.getSharedPreferences("p", Context.MODE_PRIVATE).edit().putBoolean("consent", true).apply()

    fun speaker(c: Context) =
        c.getSharedPreferences("p", Context.MODE_PRIVATE).getBoolean("speaker", true)

    fun setSpeaker(c: Context, v: Boolean) =
        c.getSharedPreferences("p", Context.MODE_PRIVATE).edit().putBoolean("speaker", v).apply()

    /** -1 = avtomatik (hamısını sına), digər = Sources.all indeksi. */
    fun source(c: Context) =
        c.getSharedPreferences("p", Context.MODE_PRIVATE).getInt("source", -1)

    fun setSource(c: Context, v: Int) =
        c.getSharedPreferences("p", Context.MODE_PRIVATE).edit().putInt("source", v).apply()
}
