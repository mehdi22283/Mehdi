package az.vakansiya

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import org.json.JSONTokener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** JobSite kimi saytlarda nəticəni JS-dən qəbul edən körpü. */
class WorkerBridge(private val cb: (String) -> Unit) {
    @JavascriptInterface
    fun done(json: String) { cb(json) }
}

/**
 * Arxa planda saytları yoxlayır. "Yeni" yalnız BU GÜN yerləşdirilən elandır:
 *  - bu günkü elan sayı artarsa → bildiriş
 *  - bu gün yerləşdirilən "Xüsusi Vakansiya" (İT, çağrı mərkəzi, qeydiyyat...) tapılsa → ayrıca bildiriş
 */
class CheckWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {

    override fun doWork(): Result {
        val c = applicationContext
        val sites = Store.load(c).filter { !it.skip && !Store.stajFilter(it.url) }
        if (sites.isEmpty()) return Result.success()
        val main = Handler(Looper.getMainLooper())
        val latch = CountDownLatch(sites.size)
        val results = ConcurrentHashMap<String, JSONObject>()
        val wvs = ConcurrentHashMap<Int, WebView>()
        val done = Array(sites.size) { AtomicBoolean(false) }
        val started = Array(sites.size) { AtomicBoolean(false) }

        fun finish(i: Int) {
            if (done[i].compareAndSet(false, true)) {
                try { wvs[i]?.destroy() } catch (e: Exception) { }
                latch.countDown()
            }
        }

        main.post {
            sites.forEachIndexed { i, s ->
                try {
                    val detail = Store.detail(s.url)
                    val careful = Store.careful(s.url)
                    val w = WebView(c)
                    w.settings.javaScriptEnabled = true
                    w.settings.domStorageEnabled = true
                    w.settings.blockNetworkImage = true
                    if (detail) {
                        w.addJavascriptInterface(WorkerBridge { json ->
                            try { results[s.url] = JSONObject(json) } catch (e: Exception) { }
                            main.post { finish(i) }
                        }, "Bridge")
                    }
                    w.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(v: WebView, u: String) {
                            if (!started[i].compareAndSet(false, true)) return
                            main.postDelayed({
                                if (done[i].get()) return@postDelayed
                                if (detail) {
                                    v.evaluateJavascript(Scan.detailJs(c, s.url), null)
                                } else {
                                    v.evaluateJavascript(Scan.js(c, careful)) { r ->
                                        try {
                                            val str = JSONTokener(r).nextValue() as String
                                            results[s.url] = JSONObject(str)
                                        } catch (e: Exception) { }
                                        finish(i)
                                    }
                                }
                            }, if (careful) 9000L else 4500L)
                        }
                    }
                    wvs[i] = w
                    w.loadUrl(s.url)
                    main.postDelayed({ finish(i) }, if (detail) 60000L else 45000L)
                } catch (e: Exception) { finish(i) }
            }
        }
        latch.await(85, TimeUnit.SECONDS)
        main.post { sites.indices.forEach { finish(it) } }

        val prefs = c.getSharedPreferences("seen", Context.MODE_PRIVATE)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val spKey = "sp_$today"
        val spSeen = HashSet<String>(prefs.getStringSet(spKey, emptySet()) ?: emptySet())
        val ed = prefs.edit()
        // köhnə (əvvəlki günlərin / köhnə sistemin) qeydlərini təmizlə
        for (k in prefs.all.keys) if ((k.startsWith("sp_") && k != spKey) || k.startsWith("s_")) ed.remove(k)

        var spCount = 0
        for (s in sites) {
            val o = results[s.url] ?: continue
            val t = o.optInt("t", -1)
            if (t >= 0) {
                val key = "tc_" + s.url
                val prev = prefs.getString(key, null)
                val base = if (prev != null && prev.startsWith("$today|")) prev.substringAfter('|').toIntOrNull() ?: 0 else 0
                // ilk dəfə yoxlananda səssiz başlanğıc; sonra bu günkü say artdıqca bildiriş
                if (prev != null && t > base) notifyCount(c, s, t - base)
                ed.putString(key, "$today|${maxOf(base, t)}")
            }
            for (h in Hit.parse(o.optJSONArray("s")).filter { it.kind > 0 && it.day == 0 }) {
                if (spSeen.add(h.url) && spCount < 10) { spCount++; notifySpecial(c, s, h) }
            }
        }
        ed.putStringSet(spKey, spSeen)
        ed.apply()
        return Result.success()
    }

    private fun channel(c: Context, id: String, name: String, imp: Int) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(id, name, imp)
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun open(c: Context, s: Site, start: String, code: Int): PendingIntent {
        val intent = Intent(c, BrowserActivity::class.java)
            .putExtra("base", s.url).putExtra("start", start).putExtra("title", s.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(c, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun notifyCount(c: Context, s: Site, n: Int) {
        val nm = NotificationManagerCompat.from(c)
        if (!nm.areNotificationsEnabled()) return
        channel(c, "vak", "Bu gün yeni vakansiyalar", NotificationManager.IMPORTANCE_DEFAULT)
        val id = s.url.hashCode()
        val nt = NotificationCompat.Builder(c, "vak")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(s.name)
            .setContentText("Bu gün $n yeni elan paylaşıldı")
            .setContentIntent(open(c, s, s.url, id))
            .setAutoCancel(true)
            .build()
        try { nm.notify(id, nt) } catch (e: SecurityException) { }
    }

    private fun notifySpecial(c: Context, s: Site, h: Hit) {
        val nm = NotificationManagerCompat.from(c)
        if (!nm.areNotificationsEnabled()) return
        channel(c, "vak_special", "Xüsusi vakansiyalar", NotificationManager.IMPORTANCE_HIGH)
        val id = ("sp" + h.url).hashCode()
        val title = if (h.kind == 1) "🖥 İT Xüsusi Vakansiya" else "★ Xüsusi Vakansiya"
        val text = s.name + ": " + h.title
        val nt = NotificationCompat.Builder(c, "vak_special")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open(c, s, h.url, id))
            .setAutoCancel(true)
            .build()
        try { nm.notify(id, nt) } catch (e: SecurityException) { }
    }
}
