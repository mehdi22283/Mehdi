package az.wifiscan

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import java.net.*
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicInteger

class Scanner(
    private val ctx: Context,
    private val onUpdate: () -> Unit,
    private val onProgress: (Int, Int) -> Unit,
    private val onDone: () -> Unit
) {
    @Volatile private var cancelled = false
    @Volatile private var pool: ExecutorService? = null

    fun cancel() { cancelled = true; pool?.shutdownNow() }

    fun start(ip: String, prefix: Int, gw: String) { Thread { run(ip, prefix, gw) }.start() }

    private fun run(ip: String, prefix: Int, gw: String) {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wm.createMulticastLock("wifiskan").apply { setReferenceCounted(false); acquire() }
        try {
            val p = prefix.coerceIn(24, 30)
            val base = Net.toInt(ip) and (-1 shl (32 - p))
            val n = (1 shl (32 - p)) - 2
            val self = Device(ip).apply {
                isSelf = true; name = Build.MODEL; vendor = Build.MANUFACTURER
                model = "${Build.MANUFACTURER} ${Build.MODEL}"; isGateway = (ip == gw)
            }
            Net.classify(self); Store.devices[ip] = self; onUpdate()
            val up = Thread { ssdp() }; up.start()
            val ex = Executors.newFixedThreadPool(96); pool = ex
            val done = AtomicInteger(0)
            for (i in 1..n) {
                val h = Net.fromInt(base + i)
                ex.execute {
                    try { if (!cancelled && h != ip) probe(h, gw) } catch (e: Throwable) {}
                    onProgress(done.incrementAndGet(), n)
                }
            }
            ex.shutdown(); ex.awaitTermination(10, TimeUnit.MINUTES)
            up.join(9000)
        } catch (e: Throwable) {
        } finally { lock.release(); pool = null; onDone() }
    }

    private fun probe(h: String, gw: String) {
        val up = Net.alive(h)
        var mac = Net.arp(h)
        if (!up && mac.isEmpty()) return
        val d = Device(h)
        d.isGateway = h == gw
        d.mac = mac; d.vendor = Oui.vendor(mac); d.randomMac = Oui.isRandom(mac)
        Store.devices[h] = d; Net.classify(d); onUpdate()

        val ex = Executors.newFixedThreadPool(24)
        for (port in Net.PORTS.keys) ex.execute { if (!cancelled && Net.open(h, port)) { d.ports.add(port); Net.classify(d); onUpdate() } }
        ex.shutdown(); ex.awaitTermination(40, TimeUnit.SECONDS)

        if (mac.isEmpty()) {
            mac = Net.arp(h)
            if (mac.isNotEmpty()) { d.mac = mac; d.vendor = Oui.vendor(mac); d.randomMac = Oui.isRandom(mac) }
        }
        Net.classify(d); onUpdate()

        val nm = Net.netbios(h).ifEmpty { Net.dns(h) }
        if (nm.isNotEmpty()) d.name = nm
        Net.classify(d); onUpdate()

        val hp = listOf(80, 8080, 8000, 81, 8081, 8090, 5000).firstOrNull { it in d.ports }
        if (hp != null) d.http = Net.http(h, hp)
        Net.classify(d); onUpdate()
    }

    private fun ssdp() {
        try {
            val s = DatagramSocket(); s.soTimeout = 700
            val msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n".toByteArray()
            val grp = InetAddress.getByName("239.255.255.250")
            val end = System.currentTimeMillis() + 9000
            val seen = HashSet<String>()
            var last = 0L
            val buf = ByteArray(4096)
            while (System.currentTimeMillis() < end && !cancelled) {
                if (System.currentTimeMillis() - last > 2500) {
                    s.send(DatagramPacket(msg, msg.size, grp, 1900)); last = System.currentTimeMillis()
                }
                try {
                    val pk = DatagramPacket(buf, buf.size); s.receive(pk)
                    val txt = String(pk.data, 0, pk.length)
                    val loc = Regex("(?i)location:\\s*(\\S+)").find(txt)?.groupValues?.get(1) ?: continue
                    val srv = Regex("(?i)server:\\s*(.+)").find(txt)?.groupValues?.get(1)?.trim() ?: ""
                    val ip = pk.address.hostAddress ?: continue
                    if (!seen.add(loc)) continue
                    Thread { fetchDesc(ip, loc, srv) }.start()
                } catch (e: SocketTimeoutException) {}
            }
            s.close()
        } catch (e: Throwable) {}
    }

    private fun fetchDesc(ip: String, loc: String, srv: String) {
        try {
            val c = URL(loc).openConnection() as HttpURLConnection
            c.connectTimeout = 1500; c.readTimeout = 1500
            val x = c.inputStream.bufferedReader().readText()
            fun t(tag: String) = Regex("<$tag>(.*?)</$tag>", RegexOption.DOT_MATCHES_ALL).find(x)?.groupValues?.get(1)?.trim() ?: ""
            val old = Store.upnp[ip]
            if (old == null || old.model.isBlank()) Store.upnp[ip] = Upnp(t("friendlyName"), t("manufacturer"), t("modelName"), srv)
            Store.devices[ip]?.let { Net.classify(it) }
            onUpdate()
        } catch (e: Throwable) {}
    }
}
