package az.videoyabax;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/** TV-də işləyən kiçik HTTP server: səhifə verir, videonu qəbul edir və yüklənərkən player-ə ötürür. */
public class VideoServer {
    public static final int PORT = 3169;

    public interface Listener { void onNewVideo(); }

    public static volatile Listener listener;
    public static volatile int gen = 0;
    public static volatile long total = 0, written = 0;
    public static volatile boolean done = false, failed = false;

    private static File file;
    private final File dir;
    private ServerSocket ss;
    private volatile boolean running;

    public VideoServer(File dir) { this.dir = dir; }

    public void start() {
        running = true;
        new Thread(() -> {
            while (running) {
                try {
                    if (ss == null || ss.isClosed()) {
                        ss = new ServerSocket();
                        ss.setReuseAddress(true);
                        ss.bind(new InetSocketAddress(PORT));
                    }
                    final Socket s = ss.accept();
                    new Thread(() -> handle(s)).start();
                } catch (Exception e) {
                    try { Thread.sleep(1000); } catch (Exception ignored) { }
                }
            }
        }).start();
    }

    public void stop() {
        running = false;
        try { if (ss != null) ss.close(); } catch (Exception ignored) { }
    }

    private void handle(Socket s) {
        try {
            s.setTcpNoDelay(true);
            InputStream in = new BufferedInputStream(s.getInputStream(), 65536);
            OutputStream out = s.getOutputStream();
            String line = readLine(in);
            if (line == null) return;
            String[] p = line.split(" ");
            if (p.length < 2) return;
            String method = p[0], target = p[1];
            Map<String, String> h = new HashMap<>();
            String l;
            while ((l = readLine(in)) != null && !l.isEmpty()) {
                int i = l.indexOf(':');
                if (i > 0) h.put(l.substring(0, i).trim().toLowerCase(), l.substring(i + 1).trim());
            }
            String path = target, query = "";
            int q = target.indexOf('?');
            if (q >= 0) { path = target.substring(0, q); query = target.substring(q + 1); }

            if ((method.equals("PUT") || method.equals("POST")) && path.equals("/upload")) {
                upload(in, out, h, query);
            } else if (path.equals("/stream")) {
                stream(method, h, out);
            } else {
                send(out, 200, "text/html; charset=utf-8", PAGE);
            }
        } catch (Exception ignored) {
        } finally {
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    private void upload(InputStream in, OutputStream out, Map<String, String> h, String query) throws IOException {
        long len;
        try { len = Long.parseLong(h.get("content-length")); }
        catch (Exception e) { send(out, 411, "text/plain; charset=utf-8", "Content-Length yoxdur"); return; }
        if (dir.getUsableSpace() < len + 100L * 1024 * 1024) {
            send(out, 507, "text/plain; charset=utf-8", "TV-də kifayət qədər boş yer yoxdur");
            return;
        }
        final int g;
        synchronized (VideoServer.class) {
            gen++;
            g = gen;
            if (file != null) file.delete();
            file = new File(dir, "video_" + g + ".bin");
            total = len; written = 0; done = false; failed = false;
        }
        Listener ls = listener;
        if (ls != null) ls.onNewVideo();

        FileOutputStream fo = new FileOutputStream(file);
        byte[] buf = new byte[131072];
        long rem = len;
        try {
            while (rem > 0 && gen == g) {
                int n = in.read(buf, 0, (int) Math.min(buf.length, rem));
                if (n < 0) break;
                fo.write(buf, 0, n);
                rem -= n;
                if (gen == g) written += n;
            }
        } finally {
            fo.close();
        }
        if (gen == g) { if (rem == 0) done = true; else failed = true; }
        try { send(out, 200, "text/plain; charset=utf-8", "OK"); } catch (Exception ignored) { }
    }

    private void stream(String method, Map<String, String> h, OutputStream out) throws IOException {
        final int g = gen;
        File f = file;
        long tot = total;
        if (g == 0 || f == null || tot <= 0) { send(out, 404, "text/plain; charset=utf-8", "Video yoxdur"); return; }
        long start = 0, end = tot - 1;
        boolean partial = false;
        String r = h.get("range");
        if (r != null && r.startsWith("bytes=")) {
            try {
                String[] pr = r.substring(6).split(",")[0].trim().split("-", -1);
                if (pr[0].isEmpty()) start = Math.max(0, tot - Long.parseLong(pr[1]));
                else {
                    start = Long.parseLong(pr[0]);
                    if (pr.length > 1 && !pr[1].isEmpty()) end = Math.min(end, Long.parseLong(pr[1]));
                }
                partial = true;
            } catch (Exception ignored) { }
        }
        if (start >= tot || start > end) {
            out.write(("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */" + tot + "\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
            out.flush();
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(partial ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n");
        sb.append("Content-Type: video/mp4\r\nAccept-Ranges: bytes\r\n");
        sb.append("Content-Length: ").append(end - start + 1).append("\r\n");
        if (partial) sb.append("Content-Range: bytes ").append(start).append("-").append(end).append("/").append(tot).append("\r\n");
        sb.append("Connection: close\r\n\r\n");
        out.write(sb.toString().getBytes("UTF-8"));
        out.flush();
        if (method.equals("HEAD")) return;

        RandomAccessFile raf = new RandomAccessFile(f, "r");
        try {
            raf.seek(start);
            long pos = start;
            byte[] buf = new byte[131072];
            while (pos <= end) {
                if (gen != g) break;
                long avail = done ? tot : written;
                if (pos >= avail) {
                    if (failed) break;
                    Thread.sleep(50);
                    continue;
                }
                int n = (int) Math.min(Math.min(buf.length, avail - pos), end - pos + 1);
                int rd = raf.read(buf, 0, n);
                if (rd <= 0) { Thread.sleep(50); continue; }
                out.write(buf, 0, rd);
                pos += rd;
            }
            out.flush();
        } catch (InterruptedException ignored) {
        } finally {
            raf.close();
        }
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
            if (b.size() > 16384) break;
        }
        if (c == -1 && b.size() == 0) return null;
        return b.toString("UTF-8");
    }

    private static void send(OutputStream out, int code, String type, String body) throws IOException {
        byte[] b = body.getBytes("UTF-8");
        String hd = "HTTP/1.1 " + code + (code == 200 ? " OK" : " Error") + "\r\nContent-Type: " + type
                + "\r\nContent-Length: " + b.length + "\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";
        out.write(hd.getBytes("UTF-8"));
        out.write(b);
        out.flush();
    }

    private static final String PAGE = "<!doctype html><html lang=az><head><meta charset=utf-8>"
            + "<meta name=viewport content='width=device-width,initial-scale=1'><title>Videoya bax</title>"
            + "<style>body{margin:0;font-family:system-ui,sans-serif;background:#0b1437;color:#fff;display:flex;"
            + "min-height:100vh;align-items:center;justify-content:center;text-align:center}"
            + ".c{padding:24px;max-width:420px;width:100%}h1{margin:0 0 6px}p{color:#b8c4ff;margin:8px 0}"
            + "label{display:block;margin:24px 0;padding:18px;border-radius:14px;background:#ff5a4f;font-size:20px;font-weight:700}"
            + "input{display:none}.bar{height:12px;background:#22306b;border-radius:6px;overflow:hidden;margin-top:18px}"
            + ".bar div{height:100%;width:0;background:#ffc857}#s{margin-top:12px;font-size:16px}</style></head><body>"
            + "<div class=c><h1>&#9654; Videoya bax</h1><p>Telefondakı videonu seçin &ndash; TV-də açılacaq.</p>"
            + "<label for=f>Video seç</label><input id=f type=file accept='video/*'>"
            + "<div class=bar><div id=b></div></div><div id=s></div>"
            + "<p style='font-size:13px'>Yükləmə bitənə qədər bu səhifəni bağlamayın. Telefonu başqa işlər üçün istifadə edə bilərsiniz.</p></div>"
            + "<script>var f=document.getElementById('f'),b=document.getElementById('b'),s=document.getElementById('s');"
            + "f.onchange=function(){var file=f.files[0];if(!file)return;var x=new XMLHttpRequest();"
            + "x.open('PUT','/upload?name='+encodeURIComponent(file.name));"
            + "x.upload.onprogress=function(e){if(e.lengthComputable){var p=Math.round(e.loaded*100/e.total);"
            + "b.style.width=p+'%';s.textContent='TV-yə ötürülür: '+p+'% ('+Math.round(e.loaded/1048576)+' / '+Math.round(e.total/1048576)+' MB)';}};"
            + "x.onload=function(){if(x.status==200){b.style.width='100%';s.textContent='Tamamlandı. Video TV-dədir.';}else{s.textContent='Xəta: '+x.responseText;}};"
            + "x.onerror=function(){s.textContent='Bağlantı kəsildi.';};x.send(file);s.textContent='Başlayır...';};</script></body></html>";
}
