package az.allplayers

import android.content.*
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var input: EditText
    private val defaultUrl = "http://live.tvnet.az/aztv_hd/index.m3u8"

    // ad, paket, (ehtiyat paket)
    private val externals = listOf(
        Triple("VLC", "org.videolan.vlc", ""),
        Triple("MX Player", "com.mxtech.videoplayer.ad", "com.mxtech.videoplayer.pro"),
        Triple("Kodi", "org.xbmc.kodi", ""),
        Triple("Just Player", "com.brouken.player", ""),
        Triple("Next Player", "dev.anilbeesetti.nextplayer", ""),
        Triple("Web Video Caster", "com.instantbits.cast.webvideo", "")
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }
        sv.addView(root)
        setContentView(sv)

        root.addView(TextView(this).apply {
            text = "▶ Bütün Playerlər"; textSize = 24f; setTextColor(0xFFFFFFFF.toInt())
        })
        input = EditText(this).apply {
            setText(sharedUrl() ?: defaultUrl)
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF888888.toInt())
            hint = "m3u8 linki"; textSize = 14f
        }
        root.addView(input)

        row(root, "📋 Yapışdır" to { paste() }, "🗑 Təmizlə" to { input.setText("") }, "📄 Kopyala" to { copy() })

        header(root, "Daxili playerlər")
        btn(root, "▶ ExoPlayer (Media3)") { openInternal(ExoActivity::class.java) }
        btn(root, "▶ VLC (daxili libVLC)") { openInternal(VlcActivity::class.java) }

        header(root, "Xarici playerlər")
        externals.forEach { (name, pkg, alt) -> btn(root, "↗ $name") { openExternal(name, pkg, alt) } }

        header(root, "Digər")
        btn(root, "📱 Hamısı (sistem seçimi)") { chooser() }
        btn(root, "🌐 Brauzerdə aç") { startSafe(Intent(Intent.ACTION_VIEW, Uri.parse(url()))) }
    }

    private fun sharedUrl(): String? = when (intent?.action) {
        Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)?.trim()
        Intent.ACTION_VIEW -> intent.dataString
        else -> null
    }

    private fun url() = input.text.toString().trim().ifEmpty { defaultUrl }

    private fun openInternal(c: Class<*>) =
        startActivity(Intent(this, c).putExtra("url", url()))

    private fun videoIntent(pkg: String?) = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(Uri.parse(url()), "application/x-mpegURL")
        pkg?.let { setPackage(it) }
    }

    private fun openExternal(name: String, pkg: String, alt: String) {
        val tries = listOf(pkg, alt).filter { it.isNotEmpty() }
        for (p in tries) {
            if (installed(p)) { startSafe(videoIntent(p)); return }
        }
        toast("$name quraşdırılmayıb — Play Store açılır")
        startSafe(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
    }

    private fun chooser() {
        startSafe(Intent.createChooser(videoIntent(null), "Player seçin"))
    }

    private fun installed(p: String) = try {
        packageManager.getPackageInfo(p, 0); true
    } catch (e: Exception) { false }

    private fun startSafe(i: Intent) {
        try { startActivity(i) } catch (e: Exception) { toast("Açıla bilmədi") }
    }

    private fun paste() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.primaryClip?.getItemAt(0)?.text?.let { input.setText(it.toString().trim()) }
    }

    private fun copy() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("url", url())); toast("Kopyalandı")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun header(p: LinearLayout, t: String) = p.addView(TextView(this).apply {
        text = t; textSize = 16f; setTextColor(0xFF90CAF9.toInt()); setPadding(0, dp(20), 0, dp(4))
    })

    private fun btn(p: LinearLayout, t: String, f: () -> Unit) = p.addView(Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    })

    private fun row(p: LinearLayout, vararg items: Pair<String, () -> Unit>) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        items.forEach { (t, f) ->
            r.addView(Button(this).apply {
                text = t; isAllCaps = false; textSize = 12f; setOnClickListener { f() }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        p.addView(r)
    }
}
