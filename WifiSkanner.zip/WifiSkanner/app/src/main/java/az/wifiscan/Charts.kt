package az.wifiscan

import android.content.Context
import android.graphics.*
import android.view.View

/** Sadə xətt qrafiki. Dəyər < 0 = itki (qırmızı nöqtə). */
class LineChartView(ctx: Context, private val unit: String, private val col: Int) : View(ctx) {
    private val data = ArrayList<Float>()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = col; strokeWidth = 4f; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = (col and 0x00FFFFFF) or 0x33000000; style = Paint.Style.FILL }
    private val grid = Paint().apply { this.color = 0xFF222B33.toInt(); strokeWidth = 2f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFF8FA3B5.toInt(); textSize = 26f }
    private val loss = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFFFF5252.toInt(); style = Paint.Style.FILL }

    fun set(values: List<Float>) { synchronized(data) { data.clear(); data.addAll(values) }; postInvalidate() }
    fun clear() = set(emptyList())

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        val left = 90f; val top = 12f; val bot = h - 12f; val right = w - 10f
        val pts = synchronized(data) { ArrayList(data) }
        val mx = (pts.maxOrNull() ?: 0f).coerceAtLeast(1f)
        val top1 = niceMax(mx)
        for (i in 0..4) {
            val y = bot - (bot - top) * i / 4f
            c.drawLine(left, y, right, y, grid)
            val v = top1 * i / 4f
            c.drawText(if (top1 >= 10) "%.0f".format(v) else "%.1f".format(v), 4f, y + 9f, txt)
        }
        c.drawText(unit, 4f, top + 26f + 28f, txt)
        if (pts.isEmpty()) return
        val n = pts.size
        val dx = if (n > 1) (right - left) / (n - 1) else 0f
        val path = Path(); val area = Path(); var started = false; var lastX = left
        for (i in 0 until n) {
            val v = pts[i]; val x = left + dx * i
            if (v < 0) { c.drawCircle(x, bot - 4f, 7f, loss); continue }
            val y = bot - (bot - top) * (v / top1).coerceIn(0f, 1f)
            if (!started) { path.moveTo(x, y); area.moveTo(x, bot); area.lineTo(x, y); started = true } else { path.lineTo(x, y); area.lineTo(x, y) }
            lastX = x
        }
        if (started) { area.lineTo(lastX, bot); area.close(); c.drawPath(area, fill); c.drawPath(path, line) }
    }

    private fun niceMax(v: Float): Float {
        val steps = floatArrayOf(2f, 5f, 10f, 20f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f)
        for (s in steps) if (v <= s) return s
        return v
    }
}
