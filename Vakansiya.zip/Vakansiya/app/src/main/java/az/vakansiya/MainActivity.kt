package az.vakansiya

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.widget.ImageView
import androidx.work.*
import java.util.concurrent.TimeUnit
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var sites: MutableList<Site>
    private lateinit var adapter: Adapter
    private lateinit var touch: ItemTouchHelper
    private lateinit var status: TextView
    private var counter: Counter? = null
    private lateinit var bell: TextView
    private lateinit var since: TextView
    private lateinit var specAll: TextView
    private val singles = ArrayList<Counter>()
    private val FRESH_MS = 15L * 60 * 1000
    private var stopTime = 0L
    private var started = false
    /** Son girişin vaxtı: bundan sonra tapılan xüsusi vakansiyalar "yeni" sayılır. */
    private var baseline = 0L
    /** "Baxıldı" basılmayan xüsusi vakansiyalar (sayt ünvanına görə). */
    private var spMap: Map<String, List<Sp>> = emptyMap()
    private val addFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@registerForActivityResult
        Thread {
            val n = uris.count { Files.add(this, it) != null }
            runOnUiThread {
                android.widget.Toast.makeText(this, if (n > 0) "$n fayl əlavə edildi" else "Fayl əlavə edilmədi", android.widget.Toast.LENGTH_SHORT).show()
                filesDialog()
            }
        }.start()
    }

    private fun filesDialog() {
        val fs = Files.list(this)
        val items = (fs.map { it.name + "  (" + Files.size(it) + ")" } + "＋ Fayl əlavə et").toTypedArray()
        AlertDialog.Builder(this).setTitle("Fayllarım (saytlara yükləmək üçün)")
            .setItems(items) { _, w ->
                if (w == fs.size) addFiles.launch(arrayOf("*/*"))
                else AlertDialog.Builder(this).setMessage("\"${fs[w].name}\" silinsin?")
                    .setPositiveButton("Sil") { _, _ -> fs[w].delete(); filesDialog() }
                    .setNegativeButton("Ləğv et") { _, _ -> filesDialog() }.show()
            }.setNegativeButton("Bağla", null).show()
    }

    /** Son yoxlama 15 dəqiqədən az əvvəl bitibsə, siyahı yenilənmir: yadda saxlanılan nəticələr göstərilir. */
    private fun startVisit() {
        val done = getSharedPreferences("app", MODE_PRIVATE).getLong("scanDone", 0L)
        val act = sites.filter { !it.skip }
        if (done > 0 && System.currentTimeMillis() - done < FRESH_MS && act.any { it.today >= 0 }) {
            act.forEach { it.checked = true }
            adapter.notifyDataSetChanged()
            refreshStatus()
            updateSince()
        } else refresh()
    }

    /** Yeni giriş: əvvəlki girişin sonunu "bazis" kimi götürür (30 dəqiqədən az fasilə eyni giriş sayılır). */
    private fun beginVisit() {
        val p = getSharedPreferences("app", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = p.getLong("lastActive", 0L)
        if (last == 0L || now - last > 30 * 60 * 1000 || !p.contains("visitBase")) {
            baseline = last
            p.edit().putLong("visitBase", last).apply()
        } else baseline = p.getLong("visitBase", 0L)
        p.edit().putLong("lastActive", now).apply()
    }

    private fun unseenSpecials(): List<Sp> {
        val urls = sites.filter { !it.skip }.map { it.url }.toSet()
        return SpecialStore.load(this).filter { !it.seen && it.siteUrl in urls }
            .sortedWith(compareBy({ it.hit.kind }, { -it.ts }))
    }

    private fun siteOf(x: Sp): Site = sites.firstOrNull { it.url == x.siteUrl } ?: Site(x.siteName, x.siteUrl)

    private fun spText(l: List<Sp>): String {
        val it1 = l.count { it.hit.kind == 1 }
        val nw = l.count { it.ts > baseline }
        return "★ ${l.size} Xüsusi Vakansiya" + (if (it1 > 0) "  (İT: $it1)" else "") + (if (nw > 0) "  •  🆕 $nw yeni" else "")
    }

    /** Sol üstdəki bildiriş: hər məlumat ayrıca sətirdə (yeni olanlar: 🖥️ İT, 💼 digər xüsusi). */
    private fun spLines(l: List<Sp>): String {
        val itNew = l.count { it.hit.kind == 1 && it.ts > baseline }
        val ccNew = l.count { it.hit.kind == 2 && it.ts > baseline }
        val scNew = l.count { it.hit.kind == 3 && it.ts > baseline }
        val sb = StringBuilder("★ ${l.size} Xüsusi Vakansiya")
        if (itNew > 0) sb.append("\n🖥️ $itNew Yeni")
        if (ccNew > 0) sb.append("\n💼 $ccNew Yeni")
        if (scNew > 0) sb.append("\n👮🏻‍♂️ $scNew Yeni")
        return sb.toString()
    }

    /** "Yeni" yalnız bu gün yerləşdirilən elanlardır. */
    private fun updateSince() {
        // tapılan xüsusi vakansiyaları yadda saxla: "baxıldı" basılana qədər qalır
        SpecialStore.add(this, sites.filter { !it.skip }.flatMap { s -> s.special.map { s to it } })
        val un = unseenSpecials()
        val newMap = un.groupBy { it.siteUrl }
        val oldMap = spMap
        spMap = newMap
        // yalnız dəyişən saytların sətirləri yenilənir (bütün siyahı yanıb-sönmür)
        for (u in (newMap.keys + oldMap.keys).toSet()) {
            if (newMap[u]?.map { it.hit.url } != oldMap[u]?.map { it.hit.url }) {
                val pos = sites.indexOfFirst { it.url == u }
                if (pos >= 0) adapter.notifyItemChanged(pos)
            }
        }
        dlgRefresh?.invoke()
        val act = sites.filter { !it.skip }
        val total = act.sumOf { maxOf(it.today, 0) }
        val busy = act.any { !it.checked }
        val todayHits = act.flatMap { it.items }.filter { it.day == 0 }
        val itC = todayHits.count { it.kind == 1 }
        val ccC = todayHits.count { it.kind == 2 }
        val scC = todayHits.count { it.kind == 3 }
        val rest = maxOf(total - itC - ccC - scC, 0)
        since.text = if (act.none { it.today >= 0 }) "Bu gün yeni elanlar hesablanır…" else "Bu gün yeni: $total elan" + (if (busy) " …" else "")
        // kateqoriyalar ★ Xüsusi Vakansiya bildirişinin altında göstərilir
        val cat = StringBuilder()
        if (act.any { it.today >= 0 } && (itC > 0 || ccC > 0 || scC > 0)) {
            if (itC > 0) cat.append("🖥️ İT: $itC")
            if (ccC > 0) { if (cat.isNotEmpty()) cat.append("\n"); cat.append("💼 Xidmət: $ccC") }
            if (scC > 0) { if (cat.isNotEmpty()) cat.append("\n"); cat.append("👮🏻‍♂️ Mühafizə: $scC") }
            if (rest > 0) { cat.append("\n"); cat.append("📋 Digər: $rest") }
        }
        // ★ sətri, onun altında kateqoriyaların sayları (İT → Xidmət → Mühafizə)
        val spTxt = listOf(if (un.isEmpty()) "" else "★ ${un.size} Xüsusi Vakansiya", cat.toString()).filter { it.isNotEmpty() }.joinToString("\n")
        if (spTxt.isEmpty()) {
            specAll.visibility = android.view.View.GONE
        } else {
            specAll.text = spTxt
            specAll.visibility = android.view.View.VISIBLE
        }
    }

    /** Açar sözlər: siyahı. Silmək üçün sola sürüşdürün. */
    private fun keywordsDialog() {
        class Kw(val word: String, val cat: Int)
        val list = ArrayList<Kw>()
        Keywords.it(this).forEach { list.add(Kw(it, 1)) }
        Keywords.other(this).forEach { list.add(Kw(it, 2)) }
        Keywords.sec(this).forEach { list.add(Kw(it, 3)) }
        var changed = false
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val add = TextView(this).apply {
            text = "＋ Açar söz əlavə et"; textSize = 16f; setTextColor(Color.parseColor("#60A5FA"))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(20), dp(12), dp(20), dp(4))
        }
        val hint = TextView(this).apply {
            text = "Silmək üçün sözü sola sürüşdürün"; textSize = 12f
            setTextColor(Color.parseColor("#9CA3AF")); setPadding(dp(20), 0, dp(20), dp(8))
        }
        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        val adp = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val tv = TextView(this@MainActivity).apply {
                    textSize = 16f; setTextColor(Color.parseColor("#F5F5F5"))
                    setBackgroundColor(Color.parseColor("#303030"))
                    setPadding(dp(20), dp(14), dp(20), dp(14))
                    layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                }
                return object : RecyclerView.ViewHolder(tv) {}
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
                val k = list[i]
                (h.itemView as TextView).text = (when (k.cat) { 1 -> "🖥 İT  •  "; 3 -> "👮🏻‍♂️ Mühafizə  •  "; else -> "💼  " }) + k.word
            }
            override fun getItemCount() = list.size
        }
        rv.adapter = adp
        val red = android.graphics.Paint().apply { color = Color.parseColor("#DC2626") }
        val white = android.graphics.Paint().apply { color = Color.WHITE; textSize = dp(15).toFloat(); isAntiAlias = true; textAlign = android.graphics.Paint.Align.RIGHT }
        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            override fun onMove(r: RecyclerView, a: RecyclerView.ViewHolder, b: RecyclerView.ViewHolder) = false
            override fun onSwiped(v: RecyclerView.ViewHolder, d: Int) {
                val pos = v.adapterPosition
                if (pos < 0) return
                list.removeAt(pos)
                adp.notifyItemRemoved(pos)
                Keywords.save(this@MainActivity, list.filter { it.cat == 1 }.map { it.word }, list.filter { it.cat == 2 }.map { it.word }, list.filter { it.cat == 3 }.map { it.word })
                changed = true
            }
            override fun onChildDraw(c: android.graphics.Canvas, r: RecyclerView, v: RecyclerView.ViewHolder, dX: Float, dY: Float, st: Int, active: Boolean) {
                val it = v.itemView
                if (dX < 0) {
                    c.drawRect(it.right + dX, it.top.toFloat(), it.right.toFloat(), it.bottom.toFloat(), red)
                    c.drawText("Sil", it.right - dp(20).toFloat(), it.top + it.height / 2f + dp(5), white)
                }
                super.onChildDraw(c, r, v, dX, dY, st, active)
            }
        }).attachToRecyclerView(rv)
        box.addView(add)
        box.addView(hint)
        box.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)))
        val dlg = AlertDialog.Builder(this).setTitle("Açar sözlər (${list.size})").setView(box)
            .setNegativeButton("Bağla", null).create()
        dlg.setOnDismissListener { if (changed) refresh() }
        add.setOnClickListener { dlg.dismiss(); addKeywordDialog() }
        dlg.show()
    }

    private fun addKeywordDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val e = EditText(this).apply { hint = "məs. Texniki Dəstək" }
        box.addView(e)
        box.addView(TextView(this).apply {
            text = "Sözün əvvəli uyğun gəlsə tapılır (qeydiyyatçı → qeydiyyatçısı). Yalnız tam söz üçün əvvəlinə = yazın (=it)."
            textSize = 12f; setTextColor(Color.parseColor("#6B7280")); setPadding(0, dp(8), 0, 0)
        })
        fun add(cat: Int) {
            val w = e.text.toString().trim()
            if (w.isEmpty()) return
            val it1 = Keywords.it(this); val ot = Keywords.other(this); val sc = Keywords.sec(this)
            if (it1.any { x -> x.equals(w, true) } || ot.any { x -> x.equals(w, true) } || sc.any { x -> x.equals(w, true) }) {
                android.widget.Toast.makeText(this, "Bu söz artıq var", android.widget.Toast.LENGTH_SHORT).show()
            } else {
                when (cat) { 1 -> it1.add(0, w); 3 -> sc.add(0, w); else -> ot.add(0, w) }
                Keywords.save(this, it1, ot, sc)
                refresh()
            }
            keywordsDialog()
        }
        AlertDialog.Builder(this).setTitle("Yeni açar söz").setView(box)
            .setPositiveButton("🖥️ İT") { _, _ -> add(1) }
            .setNeutralButton("💼 Çağrı") { _, _ -> add(2) }
            .setNegativeButton("👮🏻‍♂️ Mühafizə") { _, _ -> add(3) }
            .setOnCancelListener { keywordsDialog() }.show()
    }

    private fun refreshSite(s: Site) {
        if (s.skip || !s.checked) return
        s.today = -1; s.yest = -1; s.d2 = -1; s.items = emptyList(); s.checked = false
        val pos0 = sites.indexOfFirst { it === s }
        if (pos0 >= 0) adapter.notifyItemChanged(pos0)
        refreshStatus(); updateSince()
        val c = Counter(this, listOf(s), { _ ->
            s.checked = true
            val pos = sites.indexOfFirst { it === s }
            if (pos >= 0) adapter.notifyItemChanged(pos)
            refreshStatus(); updateSince()
        }, { Store.save(this, sites); refreshStatus(); updateSince() }, { _ ->
            val pos = sites.indexOfFirst { it === s }
            if (pos >= 0) adapter.notifyItemChanged(pos)
            updateSince()
        })
        singles.add(c)
        c.start()
    }

    private var lastUrl = ""
    private var dlgRefresh: (() -> Unit)? = null

    private fun markLast(url: String) {
        lastUrl = url
        getSharedPreferences("app", MODE_PRIVATE).edit().putString("lastSite", url).apply()
        adapter.notifyDataSetChanged()
    }

    private fun dlgText(t: String, header: Boolean): TextView = TextView(this).apply {
        text = t
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        if (header) {
            textSize = 14f; setTextColor(Color.parseColor("#34D399")); setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(16), dp(12), dp(16), dp(4))
        } else {
            textSize = 13f; setTextColor(Color.parseColor("#9CA3AF"))
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
    }

    /** Ümumi AMOLED (tam qara) pəncərə: mərkəzdə, hündürlüyü məzmuna görə. fill() hər yenilənmədə yenidən çağırılır. */
    private fun amoled(title: String, link: Pair<String, () -> Unit>?, viewed: (() -> Unit)? = null, fill: (LinearLayout, android.app.Dialog) -> Unit) {
        val d = android.app.Dialog(this)
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg("#000000", 16, "#2A2A2A")
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(6), dp(10))
        }
        head.addView(TextView(this).apply {
            text = title; textSize = 18f; setTextColor(Color.WHITE); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        if (link != null) head.addView(TextView(this).apply {
            text = link.first; textSize = 14f; setTextColor(Color.parseColor("#60A5FA"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { d.dismiss(); link.second() }
        })
        head.addView(TextView(this).apply {
            text = "✕"; textSize = 20f; setTextColor(Color.WHITE)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { d.dismiss() }
        })
        // sağ yuxarı küncdə "baxıldı" ikonu
        if (viewed != null) head.addView(TextView(this).apply {
            text = "👁"; textSize = 20f; setTextColor(Color.parseColor("#34D399"))
            contentDescription = "Baxıldı"
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { d.dismiss(); viewed() }
        })
        root.addView(head)
        root.addView(android.view.View(this).apply {
            setBackgroundColor(Color.parseColor("#262626"))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val maxH = (resources.displayMetrics.heightPixels * 0.8).toInt()
        val sv = object : android.widget.ScrollView(this) {
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, android.view.View.MeasureSpec.makeMeasureSpec(maxH, android.view.View.MeasureSpec.AT_MOST))
            }
        }.apply { addView(list) }
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        fun rebuild() { list.removeAllViews(); fill(list, d) }
        rebuild()
        dlgRefresh = { rebuild() }
        d.setOnDismissListener { dlgRefresh = null }
        d.setContentView(root)
        d.show()
        d.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }
    }

    private fun hitRow(list: LinearLayout, d: android.app.Dialog, s: Site, h: Hit) {
        val tv = android.util.TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        list.addView(TextView(this).apply {
            text = (if (h.kind == 1) "🖥️ " else if (h.kind == 2) "💼 " else if (h.kind == 3) "👮🏻‍♂️ " else "") + h.title
            textSize = 15f; setTextColor(Color.parseColor("#F5F5F5"))
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setBackgroundResource(tv.resourceId)
            setOnClickListener { d.dismiss(); openHit(s, h) }
        })
    }

    /** Saytın üstünə basanda: son 2 gün üzrə elan adları. */
    private fun siteDialog(s: Site) {
        markLast(s.url)
        amoled(s.name, "Sayta keç ›" to { openSite(s) }) { list, d ->
            if (s.skip) { list.addView(dlgText("Bu sayt yoxlanılmır. Yandırmaq üçün sətrə uzun basın.", false)); return@amoled }
            var any = false
            val dayColor = mapOf(0 to "#34D399", 1 to "#FBBF24", 2 to "#F472B6")   // ana ekrandakı rənglərlə eyni
            for ((day, label) in listOf(0 to "Bu gün", 1 to "Dünən", 2 to "2 gün əvvəl")) {
                val l = s.items.filter { it.day == day }
                val n = when (day) { 0 -> s.today; 1 -> s.yest; else -> s.d2 }
                val cnt = if (n >= 0) maxOf(n, l.size) else l.size
                if (cnt == 0) continue
                any = true
                list.addView(dlgText("$label  —  $cnt", true).apply { setTextColor(Color.parseColor(dayColor[day]!!)) })
                for (h in l.take(100)) hitRow(list, d, s, h)
                if (l.isEmpty()) list.addView(dlgText("(elan adları bu saytdan alına bilmədi)", false))
            }
            if (!any) list.addView(dlgText(if (s.checked) "Son 2 gün üzrə elan tapılmadı." else "Yoxlama gedir…", false))
        }
    }

    /** "Bu gün yeni" yazısına toxunanda: bütün saytlar üzrə bu gün yeni elanlar. */
    private fun todayDialog() {
        amoled("Bu gün yeni elanlar", null) { list, d ->
            var any = false
            for (s in sites.filter { !it.skip }) {
                val l = s.items.filter { it.day == 0 }
                val cnt = if (s.today >= 0) maxOf(s.today, l.size) else l.size
                if (cnt == 0) continue
                any = true
                list.addView(dlgText("${s.name}  —  $cnt", true))
                for (h in l.take(100)) hitRow(list, d, s, h)
                if (l.isEmpty()) list.addView(dlgText("(elan adları bu saytdan alına bilmədi)", false))
            }
            if (!any) list.addView(dlgText(if (sites.any { !it.skip && !it.checked }) "Yoxlama gedir…" else "Bu gün yeni elan tapılmadı.", false))
        }
    }

    private fun markSpecialsSeen(siteUrl: String?) {
        SpecialStore.markSeen(this, siteUrl)
        android.widget.Toast.makeText(this, "Baxıldı kimi qeyd edildi", android.widget.Toast.LENGTH_SHORT).show()
        updateSince()
    }

    private fun spRow(list: LinearLayout, d: android.app.Dialog, x: Sp, fresh: Boolean, showSite: Boolean) {
        val tv = android.util.TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        val sb = android.text.SpannableStringBuilder((if (fresh) "🆕 " else "") + (if (x.hit.kind == 1) "🖥️ " else if (x.hit.kind == 3) "👮🏻‍♂️ " else "💼 ") + x.hit.title)
        if (showSite) {
            val st = sb.length
            sb.append("\n").append(x.siteName)
            sb.setSpan(android.text.style.RelativeSizeSpan(0.82f), st, sb.length, 0)
            sb.setSpan(android.text.style.ForegroundColorSpan(Color.parseColor("#9CA3AF")), st, sb.length, 0)
        }
        list.addView(TextView(this).apply {
            text = sb
            textSize = 15f; setTextColor(Color.parseColor(if (fresh) "#FFFFFF" else "#D1D5DB"))
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setBackgroundResource(tv.resourceId)
            setOnClickListener { d.dismiss(); openHit(siteOf(x), x.hit) }
        })
    }

    /** Əvvəl "son girişdən bu yana yeni", sonra əvvəlki xüsusi vakansiyalar. */
    private fun spBody(list: LinearLayout, d: android.app.Dialog, items: List<Sp>, showSite: Boolean) {
        val fresh = items.filter { it.ts > baseline }
        val old = items.filter { it.ts <= baseline }
        if (fresh.isNotEmpty()) {
            list.addView(dlgText("🆕 Son girişdən bu yana yeni  —  ${fresh.size}", true).apply { setTextColor(Color.parseColor("#FB923C")) })
            for (x in fresh) spRow(list, d, x, true, showSite)
        } else {
            list.addView(dlgText("Son girişdən bu yana yeni xüsusi vakansiya yoxdur.", false))
        }
        if (old.isNotEmpty()) {
            list.addView(dlgText("Əvvəlki  —  ${old.size}", true))
            for (x in old) spRow(list, d, x, false, showSite)
        }
    }

    private fun allSpecialsDialog() {
        if (unseenSpecials().isEmpty()) return
        amoled("★ Xüsusi Vakansiyalar", null, viewed = { markSpecialsSeen(null) }) { list, d ->
            spBody(list, d, unseenSpecials(), true)
        }
    }

    private fun specialsDialog(s: Site) {
        if (spMap[s.url].isNullOrEmpty()) return
        amoled("${s.name}: ★ Xüsusi Vakansiyalar", null, viewed = { markSpecialsSeen(s.url) }) { list, d ->
            spBody(list, d, unseenSpecials().filter { it.siteUrl == s.url }, false)
        }
    }

    private fun openSite(s: Site) {
        markLast(s.url)
        startActivity(Intent(this, BrowserActivity::class.java)
            .putExtra("base", s.url).putExtra("start", s.url).putExtra("title", s.name))
    }

    private fun openHit(s: Site, h: Hit) {
        markLast(s.url)
        startActivity(Intent(this, BrowserActivity::class.java)
            .putExtra("base", s.url).putExtra("start", h.url).putExtra("title", s.name))
    }

    override fun onStart() {
        super.onStart()
        if (started && System.currentTimeMillis() - stopTime > FRESH_MS) { beginVisit(); startVisit() }
        started = true
    }

    override fun onStop() {
        super.onStop()
        stopTime = System.currentTimeMillis()
        getSharedPreferences("app", MODE_PRIVATE).edit().putLong("lastActive", stopTime).apply()
    }

    private fun notifOn() = getSharedPreferences("app", MODE_PRIVATE).getBoolean("notif", true)

    private fun applyNotif() {
        bell.text = if (notifOn()) "🔔" else "🔕"
        val wm = WorkManager.getInstance(this)
        if (notifOn()) {
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            val cons = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
            wm.enqueueUniquePeriodicWork("check", ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequest.Builder(CheckWorker::class.java, 15, TimeUnit.MINUTES).setConstraints(cons).build())
            wm.enqueueUniqueWork("check_now", ExistingWorkPolicy.KEEP,
                OneTimeWorkRequest.Builder(CheckWorker::class.java).setConstraints(cons).build())
        } else {
            wm.cancelUniqueWork("check")
            wm.cancelUniqueWork("check_now")
        }
    }

    private fun toggleNotif() {
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("notif", !notifOn()).apply()
        applyNotif()
        android.widget.Toast.makeText(this, if (notifOn()) "Bildirişlər açıq" else "Bildirişlər bağlı", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    private fun bg(color: String, r: Int, stroke: String = "#262626") = GradientDrawable().apply {
        setColor(Color.parseColor(color)); cornerRadius = dp(r).toFloat(); setStroke(dp(1), Color.parseColor(stroke))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        sites = Store.load(this)
        lastUrl = getSharedPreferences("app", MODE_PRIVATE).getString("lastSite", "") ?: ""

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#000000"))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#000000"))
            setPadding(dp(16), dp(12), dp(8), dp(12))
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleBox.addView(TextView(this).apply {
            text = "Vakansiyalar"; textSize = 20f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        status = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#9CA3AF")) }
        titleBox.addView(status)
        since = TextView(this).apply {
            textSize = 13f; setTextColor(Color.parseColor("#60A5FA"))
            setPadding(0, dp(2), 0, dp(2))
            setOnClickListener { todayDialog() }
        }
        titleBox.addView(since)
        specAll = TextView(this).apply {
            textSize = 13f; setTextColor(Color.parseColor("#FB923C")); setTypeface(typeface, android.graphics.Typeface.BOLD)
            visibility = android.view.View.GONE
            setOnClickListener { allSpecialsDialog() }
        }
        titleBox.addView(specAll)
        top.addView(titleBox)
        top.addView(TextView(this).apply {
            text = "⟳"; textSize = 24f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { refresh() }
        })
        bell = TextView(this).apply {
            textSize = 22f; setTextColor(Color.WHITE)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { toggleNotif() }
        }
        top.addView(bell)
        top.addView(TextView(this).apply {
            text = "🔑"; textSize = 22f; setTextColor(Color.WHITE)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { keywordsDialog() }
        })
        top.addView(TextView(this).apply {
            text = "📎"; textSize = 22f; setTextColor(Color.WHITE)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { filesDialog() }
        })
        top.addView(TextView(this).apply {
            text = "＋"; textSize = 26f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(4), dp(14), dp(4))
            setOnClickListener { addDialog() }
        })
        root.addView(top)

        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        rv.setPadding(dp(10), dp(8), dp(10), dp(8))
        rv.clipToPadding = false
        (rv.itemAnimator as? androidx.recyclerview.widget.SimpleItemAnimator)?.supportsChangeAnimations = false
        adapter = Adapter()
        rv.adapter = adapter
        touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun isLongPressDragEnabled() = false
            override fun onMove(r: RecyclerView, a: RecyclerView.ViewHolder, b: RecyclerView.ViewHolder): Boolean {
                val from = a.adapterPosition; val to = b.adapterPosition
                if (from < 0 || to < 0) return false
                sites.add(to, sites.removeAt(from))
                adapter.notifyItemMoved(from, to)
                return true
            }
            override fun onSwiped(v: RecyclerView.ViewHolder, d: Int) {}
            override fun clearView(r: RecyclerView, v: RecyclerView.ViewHolder) {
                super.clearView(r, v)
                Store.save(this@MainActivity, sites)
            }
        })
        touch.attachToRecyclerView(rv)
        root.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        refreshStatus()
        applyNotif()
        beginVisit()
        startVisit()
    }

    override fun onResume() {
        super.onResume()
        // brauzerdə yadda saxlanan son ünvanları yenidən oxu
        val fresh = Store.load(this)
        for (s in sites) fresh.firstOrNull { it.url == s.url }?.let { s.last = it.last }
    }

    /** "Yoxlanıldı: X/Y" — Y yalnız yoxlanılan (söndürülməmiş) saytlardır; həmişə görünür. */
    private fun refreshStatus() {
        val act = sites.filter { !it.skip }
        status.text = "Yoxlanıldı: ${act.count { it.checked }}/${act.size}"
    }

    private fun refresh() {
        counter?.stop()
        singles.forEach { it.stop() }; singles.clear()
        sites.forEach { it.today = -1; it.yest = -1; it.items = emptyList(); it.d2 = -1; it.links = null; it.checked = false }
        adapter.notifyDataSetChanged()
        updateSince()
        val snapshot = sites.filter { !it.skip }
        refreshStatus()
        counter = Counter(this, snapshot, { i ->
            val s = snapshot[i]
            s.checked = true
            val pos = sites.indexOfFirst { it === s }
            if (pos >= 0) adapter.notifyItemChanged(pos)
            refreshStatus()
            updateSince()
        }, {
            Store.save(this, sites)
            getSharedPreferences("app", MODE_PRIVATE).edit().putLong("scanDone", System.currentTimeMillis()).apply()
            refreshStatus()
            updateSince()
        }, { i ->
            val pos = sites.indexOfFirst { it === snapshot[i] }
            if (pos >= 0) adapter.notifyItemChanged(pos)
            updateSince()
        })
        counter!!.start()
    }

    private fun addDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val n = EditText(this).apply { hint = "Saytın adı" }
        val u = EditText(this).apply { hint = "Ünvan (https://...)"; setText("https://") }
        box.addView(n); box.addView(u)
        AlertDialog.Builder(this).setTitle("Yeni sayt").setView(box)
            .setPositiveButton("Əlavə et") { _, _ ->
                var url = u.text.toString().trim()
                if (url.isEmpty() || url == "https://") return@setPositiveButton
                if (!url.startsWith("http")) url = "https://$url"
                val name = n.text.toString().trim().ifEmpty { url.removePrefix("https://").removePrefix("http://").substringBefore("/") }
                sites.add(Site(name, url))
                Store.save(this, sites)
                adapter.notifyItemInserted(sites.size - 1)
            }.setNegativeButton("Ləğv et", null).show()
    }

    private fun editDialog(pos: Int) {
        val s = sites[pos]
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val n = EditText(this).apply { setText(s.name) }
        val u = EditText(this).apply { setText(s.url) }
        box.addView(n); box.addView(u)
        AlertDialog.Builder(this).setTitle("Redaktə").setView(box)
            .setPositiveButton("Yadda saxla") { _, _ ->
                s.name = n.text.toString().trim().ifEmpty { s.name }
                val nu = u.text.toString().trim()
                if (nu.isNotEmpty() && nu != s.url) { s.url = nu; s.last = ""; s.today = -1; s.yest = -1 }
                Store.save(this, sites)
                adapter.notifyItemChanged(pos)
            }.setNegativeButton("Ləğv et", null).show()
    }

    private fun menu(pos: Int) {
        AlertDialog.Builder(this).setTitle(sites[pos].name)
            .setItems(arrayOf("Sil", "Redaktə", if (sites[pos].skip) "Yoxlamanı yandır" else "Yoxlamanı söndür")) { _, w ->
                if (w == 0) {
                    AlertDialog.Builder(this).setMessage("\"${sites[pos].name}\" silinsin?")
                        .setPositiveButton("Sil") { _, _ ->
                            sites.removeAt(pos)
                            Store.save(this, sites)
                            adapter.notifyItemRemoved(pos)
                            refreshStatus()
                        }.setNegativeButton("Ləğv et", null).show()
                } else if (w == 1) editDialog(pos)
                else {
                    sites[pos].skip = !sites[pos].skip
                    if (sites[pos].skip) { sites[pos].today = -1; sites[pos].yest = -1; sites[pos].items = emptyList(); sites[pos].d2 = -1 }
                    Store.save(this, sites)
                    adapter.notifyItemChanged(pos)
                    updateSince()
                    if (sites[pos].skip) refreshStatus() else refresh()
                }
            }.show()
    }

    private fun open(pos: Int) = openSite(sites[pos])

    override fun onDestroy() {
        counter?.stop()
        singles.forEach { it.stop() }
        super.onDestroy()
    }

    inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        inner class VH(val row: LinearLayout, val head: LinearLayout, val handle: TextView, val icon: ImageView, val name: TextView, val cnt: TextView, val spec: TextView, val arrow: TextView, val refresh: TextView) : RecyclerView.ViewHolder(row)

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                background = bg("#0D0D0D", 12)
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(0, dp(4), 0, dp(4))
                }
            }
            val head = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val handle = TextView(this@MainActivity).apply {
                text = "☰"; textSize = 22f; setTextColor(Color.parseColor("#6B7280"))
                setPadding(dp(16), dp(18), dp(16), dp(18))
            }
            val icon = ImageView(this@MainActivity).apply {
                background = bg("#1A1A1A", 10)
                setPadding(dp(7), dp(7), dp(7), dp(7))
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(0, 0, dp(12), 0) }
            }
            val mid = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val nameRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val name = TextView(this@MainActivity).apply {
                textSize = 17f; setTextColor(Color.parseColor("#F5F5F5")); setTypeface(typeface, android.graphics.Typeface.BOLD)
                maxLines = 1
            }
            val refresh = TextView(this@MainActivity).apply {
                text = "⟳"; textSize = 22f; setTextColor(Color.parseColor("#60A5FA")); gravity = Gravity.CENTER
                setPadding(dp(12), dp(2), dp(12), dp(2))
            }
            nameRow.addView(name); nameRow.addView(refresh)
            val cnt = TextView(this@MainActivity).apply { textSize = 13f; setTextColor(Color.parseColor("#9CA3AF")) }
            val spec = TextView(this@MainActivity).apply {
                textSize = 13f; setTextColor(Color.parseColor("#FB923C")); setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, dp(4), 0, dp(2))
            }
            mid.addView(nameRow); mid.addView(cnt); mid.addView(spec)
            val arrow = TextView(this@MainActivity).apply {
                text = "›"; textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                includeFontPadding = false
                background = GradientDrawable().apply { setColor(Color.parseColor("#2563EB")); cornerRadius = dp(12).toFloat() }
                layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(dp(6), dp(8), dp(12), dp(8)) }
            }
            head.addView(handle); head.addView(icon); head.addView(mid); head.addView(arrow)
            row.addView(head)
            return VH(row, head, handle, icon, name, cnt, spec, arrow, refresh)
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onBindViewHolder(h: VH, i: Int) {
            val s = sites[i]
            h.name.text = s.name
            h.icon.setImageDrawable(null)
            h.icon.tag = s.url
            Icons.load(this@MainActivity, s.url) { bm ->
                if (bm != null && h.icon.tag == s.url) h.icon.setImageBitmap(bm)
            }
            if (s.skip) {
                h.cnt.text = "Yoxlanılmır"
                h.name.alpha = 0.5f
            } else {
                h.name.alpha = 1f
                val a = if (s.today < 0) (if (s.checked) "Bu gün: ?" else "Bu gün: …") else "Bu gün: ${s.today}"
                val b = if (s.yest < 0) (if (s.checked) "Dünən: ?" else "Dünən: …") else "Dünən: ${s.yest}"
                val sp = android.text.SpannableStringBuilder()
                sp.append(a)
                sp.setSpan(android.text.style.ForegroundColorSpan(Color.parseColor("#34D399")), 0, a.length, 0)
                sp.append("  •  ")
                val st = sp.length
                sp.append(b)
                sp.setSpan(android.text.style.ForegroundColorSpan(Color.parseColor("#FBBF24")), st, sp.length, 0)
                if (s.d2 >= 0 || s.checked) {
                    sp.append("  •  ")
                    val st3 = sp.length
                    sp.append(if (s.d2 < 0) "2 gün əvvəl: ?" else "2 gün əvvəl: ${s.d2}")
                    sp.setSpan(android.text.style.ForegroundColorSpan(Color.parseColor("#F472B6")), st3, sp.length, 0)
                }
                if (!s.checked && s.today >= 0) {
                    val st4 = sp.length
                    sp.append("  ⟳")
                    sp.setSpan(android.text.style.ForegroundColorSpan(Color.parseColor("#6B7280")), st4, sp.length, 0)
                }
                h.cnt.text = sp
            }
            val spl = spMap[s.url].orEmpty()
            if (!s.skip && spl.isNotEmpty()) {
                h.spec.text = spLines(spl)
                h.spec.visibility = android.view.View.VISIBLE
                h.spec.setOnClickListener { val p = h.adapterPosition; if (p >= 0) specialsDialog(sites[p]) }
            } else {
                h.spec.visibility = android.view.View.GONE
                h.spec.setOnClickListener(null)
            }
            h.handle.setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) touch.startDrag(h)
                false
            }
            h.refresh.visibility = if (s.skip) android.view.View.GONE else android.view.View.VISIBLE
            h.refresh.alpha = if (s.checked) 1f else 0.35f
            h.refresh.setOnClickListener { val p = h.adapterPosition; if (p >= 0) refreshSite(sites[p]) }
            h.row.background = if (s.url == lastUrl) bg("#10233F", 12, "#2563EB") else bg("#0D0D0D", 12)
            h.head.setOnClickListener {
                val p = h.adapterPosition
                if (p >= 0) siteDialog(sites[p])
            }
            h.arrow.setOnClickListener { val p = h.adapterPosition; if (p >= 0) open(p) }
            h.head.setOnLongClickListener { val p = h.adapterPosition; if (p >= 0) menu(p); true }
        }

        override fun getItemCount() = sites.size
    }
}
