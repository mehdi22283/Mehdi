package az.market.endirim

import java.util.Locale

/**
 * OCR-dan gələn məhsul adlarını düzəldir:
 *  1) kirill "oxşar" hərflərin latın sözün içinə qarışması (məs. kirill "о") — latına çevrilir; tam kirill (rus) adlar siyahıdan atılır;
 *  2) "ə" hərfinin "9", "ә", "э" kimi oxunması; sözün içindəki "0" → "o";
 *  3) BÜTÖV BÖYÜK HƏRFLİ adlar düzgün kiçildilir (İ/I Azərbaycan qaydası ilə);
 *  4) ən çox işlənən Azərbaycan sözlərinin ə, ı, ö, ü, ş, ç, ğ hərfləri itibsə bərpa olunur (sud → süd, cay → çay);
 *  5) lüğətdəki sözdən yalnız 1 hərfi fərqli (OCR səhvi) uzun sözlər düzəldilir (kolbosa → kolbasa).
 */
object AzText {
    val AZ: Locale = Locale.forLanguageTag("az-AZ")

    private const val SPECIAL = "əƏıİöÖüÜşŞçÇğĞ"

    /** Kirill əlifbalı Azərbaycan hərfləri → latın. */
    private val PRE = mapOf(
        'ә' to 'ə', 'Ә' to 'Ə', 'ө' to 'ö', 'Ө' to 'Ö', 'ү' to 'ü', 'Ү' to 'Ü',
        'ғ' to 'ğ', 'Ғ' to 'Ğ', 'һ' to 'h', 'Һ' to 'H', 'ј' to 'j', 'Ј' to 'J', 'ҹ' to 'c', 'Ҹ' to 'C'
    )

    private val CYR2LAT = mapOf(
        'А' to 'A', 'а' to 'a', 'В' to 'B', 'Е' to 'E', 'е' to 'e', 'К' to 'K', 'к' to 'k', 'М' to 'M',
        'Н' to 'H', 'О' to 'O', 'о' to 'o', 'Р' to 'P', 'р' to 'p', 'С' to 'C', 'с' to 'c', 'Т' to 'T',
        'у' to 'y', 'Х' to 'X', 'х' to 'x', 'І' to 'I', 'і' to 'i', 'Ѕ' to 'S', 'ѕ' to 's', 'Э' to 'Ə', 'э' to 'ə'
    )

    private val AZ_WORDS = """
        süd südlü qatıq qaymaq kərə yağ yağlı yağsız pendir kəsmik ayran kefir motal süzmə smetana yumurta xama
        çörək lavaş təndir bulka xəmir baton kruasan çay qəhvə kakao şəkər şəkərsiz qənd duz istiot un nişasta maya soda vanil
        düyü yarma qarabaşaq mərcimək lobya noxud makaron şəhriyyə spagetti günəbaxan zeytun sirkə ketçup mayonez sous
        konserv mürəbbə bal şokolad şokoladlı konfet peçenye biskvit vafli tort kek halva paxlava saqqız dondurma çips çərəz
        çərəzlər qoz fındıq badam fıstıq kişmiş innab qurudulmuş meyvə meyvələr tərəvəz tərəvəzlər alma armud banan portağal
        naringi limon üzüm nar xiyar pomidor kartof soğan sarımsaq kələm yerkökü bibər badımcan qarpız yemiş ispanaq çiyələk
        moruq böyürtkən qaragilə albalı gilas heyva avokado ananas kivi qabaq xurma ərik şaftalı gavalı alça əncir tut
        göyərti nanə cəfəri şüyüd reyhan kərəviz turp çuğundur sitrus kəklikotu darçın zəfəran zirə ədviyyat ədviyyatlar
        ət əti toyuq hindquşu ördək kolbasa sosis sucuk kabab qiymə dana vetçina kotlet qanad ciyər balıq qızılbalıq siyənək
        kalmar krevet kürü sardina kilkə xəlvət içki içkilər içəcək şirə nektar kompot limonad qazlı qazsız mineral bulaq
        içməli pivə şərab araq konyak viski enerji soyuq kvas sərinləşdirici
        təmizlik yuyucu toz sabun şampun dezodorant diş fırça dəsmal kağız salfet tualet krem losyon maska ətir parfüm
        maye bulaşıq paltar yumşaldıcı ağardıcı süngər zibil torba kisə folqa plastik qab stəkan boşqab qaşıq çəngəl bıçaq
        tava qazan çaynik fincan mətbəx bağça uşaq körpə bez püre qarışıq
        təzə təbii yaşıl qırmızı sarı göy qara şirin acı duzlu qovrulmuş bişmiş hazır dondurulmuş doğranmış çiy dənli bütöv
        ədəd qutu şüşə banka paket litr kiloqram çəki çeşid çeşidli ləzzət ləzzətli ətirli xüsusi böyük kiçik orta ekstra
        klassik şirniyyat qənnadı bakaliya ərzaq çanta qoruyucu şəffaf çəhrayı dəniz şorba çaxır sərin isti ağ
        süd südlü
    """.trim().split(Regex("\\s+"))

    /** norm(söz) → düzgün yazılış. Açar diakritiksiz olduğu üçün "sud", "süd", "sud" hamısı eyni sözə düşür. */
    private val AZ_MAP: Map<String, String> by lazy { AZ_WORDS.associateBy { Categorizer.norm(it) } }

    /** Uzunluğa görə qruplanmış açarlar (1 hərf fərqli söz axtarışı üçün). */
    /** Adda kirill (rus) hərf varmı — belə adlar siyahılara salınmır. */
    fun hasCyrillic(s: String): Boolean =
        s.any { it.isLetter() && Character.UnicodeScript.of(it.code) == Character.UnicodeScript.CYRILLIC }

    private val AZ_BY_LEN: Map<Int, List<String>> by lazy { AZ_MAP.keys.groupBy { it.length } }

    /**
     * Lüğətdəki sözdən düz 1 hərfi fərqli YEGANƏ söz varsa onu qaytarır (OCR bir hərfi səhv oxuyub).
     * Mühafizəkar qaydalar: söz ≥ 6 hərf, uzunluq eyni, fərqli hərf sonuncu 2 hərfdə olmur — çünki şəkilçi/çevik
     * formalar (süd/südlü) səhv "düzəlməsin".
     */
    private fun fuzzy(key: String, byLen: Map<Int, List<String>>): String? {
        if (key.length < 6) return null
        val pool = byLen[key.length] ?: return null
        val stemEnd = key.length - 2
        var found: String? = null
        for (cand in pool) {
            var diff = -1
            var ok = true
            for (i in key.indices) {
                if (key[i] != cand[i]) {
                    if (diff >= 0) { ok = false; break }
                    diff = i
                }
            }
            if (ok && diff in 0 until stemEnd) {
                if (found != null && found != cand) return null
                found = cand
            }
        }
        return found
    }

    private fun recase(src: String, good: String): String = when {
        src.none { it.isLowerCase() } -> good.uppercase(AZ)
        src[0].isUpperCase() -> good.replaceFirstChar { it.uppercase(AZ) }
        else -> good
    }

    private val WORD = Regex("[\\p{L}\\p{N}]+")

    fun fix(name: String): String {
        var s = name
        if (s.none { it.isLowerCase() }) s = titleCase(s)
        return WORD.replace(s) { fixWord(it.value) }.replace(Regex("\\s+"), " ").trim()
    }

    /** BÜTÖV BÖYÜK HƏRFLİ mətn → "Coca Cola 0.5L", "Süd", "İsti". İ varsa Azərbaycan qaydası. */
    fun titleCase(s: String): String =
        s.split(' ').filter { it.isNotEmpty() }.joinToString(" ") { w ->
            if (w.any { it.isDigit() } || w.length <= 2) w
            else {
                val loc = if (w.any { it == 'İ' || it == 'ı' }) AZ else Locale.ROOT
                w.lowercase(loc).replaceFirstChar { c -> c.uppercase(loc) }
            }
        }

    private fun fixWord(w0: String): String {
        var w = w0.map { PRE[it] ?: it }.joinToString("")
        var cyr = 0
        var lat = 0
        for (c in w) if (c.isLetter()) {
            when (Character.UnicodeScript.of(c.code)) {
                Character.UnicodeScript.CYRILLIC -> cyr++
                Character.UnicodeScript.LATIN -> lat++
                else -> {}
            }
        }
        // bir sözdə iki əlifba (OCR səhvi) — oxşar kirill hərflər latına çevrilir
        if (cyr > 0 && lat > 0) {
            w = w.map { CYR2LAT[it] ?: it }.joinToString("")
        } else if (cyr > 0) {
            return w                                      // tam kirill söz — məhsul siyahısına salınmır (hasCyrillic)
        }
        w = fixDigits(w)
        return fixLexicon(w)
    }

    /** Sözün içində tək "9" → ə, tək "0" → o ("S9RIN" → "SƏRIN", "K0LA" → "KOLA"). */
    private fun fixDigits(w: String): String {
        val letters = w.count { it.isLetter() }
        val digits = w.count { it.isDigit() }
        if (digits != 1 || letters < 3) return w
        val i = w.indexOfFirst { it.isDigit() }
        val prev = w.getOrNull(i - 1)?.takeIf { it.isLetter() }
        val next = w.getOrNull(i + 1)?.takeIf { it.isLetter() }
        val upper = (prev ?: next)?.isUpperCase() == true && (next ?: prev)?.isUpperCase() == true
        return when (w[i]) {
            '9' -> if (prev != null || next != null) w.replaceRange(i, i + 1, if (upper) "Ə" else "ə") else w
            '0' -> if (prev != null && next != null) w.replaceRange(i, i + 1, if (upper) "O" else "o") else w
            else -> w
        }
    }

    private fun fixLexicon(w: String): String {
        if (w.length < 3 || w.any { it in SPECIAL } || w.any { !it.isLetter() }) return w
        val key = Categorizer.norm(w)
        val good = AZ_MAP[key] ?: fuzzy(key, AZ_BY_LEN)?.let { AZ_MAP[it] } ?: return w
        return recase(w, good)
    }
}
