package az.m3u.sinayici

import android.app.Activity
import android.os.Bundle
import android.util.Base64
import android.webkit.*
import android.widget.Toast
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Ottplayer üçün daxili brauzer. Endirilən fayl filesDir/playlist1.m3u kimi daimi saxlanılır. */
class BrowserActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this); setContentView(web)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; javaScriptCanOpenWindowsAutomatically = true }
        CookieManager.getInstance().setAcceptCookie(true)
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(object {
            @JavascriptInterface fun saveBase64(s: String) = save(Base64.decode(s, Base64.DEFAULT))
        }, "NativeSave")
        web.setDownloadListener { url, ua, _, _, _ ->
            Toast.makeText(this, "Yüklənir...", Toast.LENGTH_SHORT).show()
            when {
                url.startsWith("blob:") -> web.evaluateJavascript(
                    "fetch('$url').then(r=>r.blob()).then(b=>{var f=new FileReader();f.onload=function(){NativeSave.saveBase64(f.result.split(',')[1]);};f.readAsDataURL(b);});", null)
                url.startsWith("data:") -> save(Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT))
                else -> Thread {
                    try {
                        val c = URL(url).openConnection() as HttpURLConnection
                        c.setRequestProperty("User-Agent", ua)
                        CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                        save(c.inputStream.readBytes())
                    } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() } }
                }.start()
            }
        }
        web.loadUrl("https://ottplayer.tv/playlist/original")
    }

    private fun save(bytes: ByteArray) {
        val t = String(bytes, Charsets.UTF_8)
        runOnUiThread {
            if (!t.contains("#EXTINF") && !t.contains("#EXTM3U")) {
                Toast.makeText(this, "Endirilən fayl M3U deyil", Toast.LENGTH_LONG).show(); return@runOnUiThread
            }
            File(filesDir, "playlist1.m3u").writeText(t)
            setResult(RESULT_OK); finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
