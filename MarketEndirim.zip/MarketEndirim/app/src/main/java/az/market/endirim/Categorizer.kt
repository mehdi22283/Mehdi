package az.market.endirim

import java.util.Locale

/** Məhsul adına görə kateqoriya təyin edir və axtarış üçün mətni normallaşdırır (ə→e, ı→i, ş→s ...). */
object Categorizer {

    const val OTHER = "Digər"

    /** Bu sıra ilə yoxlanılır (əvvəlkilər üstünlük təşkil edir: məs. "Fairy limon" → Təmizlik, "Süd şokoladı" → Şirniyyat). */
    private val RULES: List<Pair<String, List<String>>> = listOf(
        "Uşaq məhsulları" to listOf("usaq", "pampers", "huggies", "bebek", "baby", "bebelac", "nutrilon", "hipp", "pyure", "mamalac", "uşaq", "детск", "подгузник", "пюре", "смесь"),
        "Təmizlik və gigiyena" to listOf(
            "persil", "ariel", "tide", "fairy", "domestos", "javel", "yuyucu", "tozu", "temizlik", "salfet", "pecetka",
            "kagiz", "pakel", "folqa", "sunger", "aerozol", "sprey", "losyon", "lenor", "comfort", "vanish", "pemolux", "mayesi", "oyuncaq", "порошок", "моющ", "чистящ", "салфетк", "бумага", "пакет", "губка", "освежитель", "отбеливатель"
        ),
        "Təmizlik və gigiyena" to listOf(
            "sampun", "sabun", "dezodorant", "deodorant", "krem", "tiras", "gigiyenik", "parfum", "maska", "colgate",
            "nivea", "dove", "always", "ped", "diş", "firca", "pasta", "shampoo", "gel", "tualet", "шампунь", "мыло", "дезодорант", "зубная", "крем", "гель", "прокладки"
        ),
        "Dondurulmuş məhsullar" to listOf("dondurulmus", "donmus", "pelmen", "nugget", "frozen", "manti", "пельмен", "заморож", "вареник", "наггетс"),
        "Şirniyyat və qənnadı" to listOf(
            "sokolad", "konfet", "pecenye", "biskvit", "vafli", "tort", "keks", "halva", "paxlava", "saqqiz", "dondurma",
            "cips", "cerez", "qoz", "findiq", "badam", "snickers", "bounty", "mars", "twix", "milka", "oreo", "nutella",
            "krujka", "draje", "marmelad", "zefir", "napoleon", "roll", "bar", "cokolad", "шоколад", "конфет", "печенье", "вафл", "торт", "мороженое", "чипсы", "орех", "жевательн", "зефир"
        ),
        "İçkilər, çay və qəhvə" to listOf(
            "cola", "coca", "kola", "fanta", "sprite", "pepsi", "cappy", "mirinda", "schweppes", "sire", "limonad", "nektar",
            "kompot", "icki", "su", "mineral", "nabran", "sirab", "badamli", "qazli", "pive", "sarab", "araq", "konyak",
            "viski", "vodka", "enerji", "energy", "redbull", "burn", "flash", "tonik", "kvas", "sok", "juice", "icecek", "вода", "сок", "напиток", "лимонад", "пиво", "вино", "водка", "коньяк", "квас", "нектар", "газирован", "минеральн"
        ),
        "İçkilər, çay və qəhvə" to listOf("cay", "qehve", "nescafe", "jacobs", "lipton", "ahmad", "akbar", "kakao", "kofe", "coffee", "tea", "чай", "кофе", "какао"),
        "Süd məhsulları və yumurta" to listOf(
            "sud", "qaymaq", "qatiq", "ayran", "pendir", "kefir", "yogurt", "jogurt", "yumurta", "kere", "smetana", "danone",
            "activia", "milk", "marqarin", "motal", "suzme", "молоко", "сыр", "творог", "кефир", "йогурт", "сметана", "масло", "яйцо", "яйца", "сливки", "маргарин", "ряженка"
        ),
        "Ət, quş və balıq" to listOf(
            "et", "mal", "qoyun", "toyuq", "quş", "qus", "kolbasa", "sosis", "sucuk", "kabab", "qiyma", "dana", "hind",
            "vetchina", "sosiska", "qanad", "file", "kotlet", "pastrami", "ciyer", "bud", "мясо", "колбас", "сосиск", "курин", "говядин", "баранин", "фарш", "ветчина", "филе", "окорочк", "индейк"
        ),
        "Ət, quş və balıq" to listOf("baliq", "qizilbaliq", "siyenek", "kalmar", "krevet", "ikra", "tuna", "sardina", "hamsi", "kilka", "xalvar", "рыба", "лосось", "икра", "креветк", "тунец", "сельдь", "кальмар", "сардин"),
        "Bakaliya və çörək" to listOf("corek", "lavas", "tendir", "bulka", "xemir", "baton", "kruasan", "simit", "toast", "bagel", "хлеб", "лаваш", "булка", "батон", "багет", "мука", "тесто"),
        "Bakaliya və çörək" to listOf(
            "duyu", "makaron", "spagetti", "yarma", "mercimek", "lobya", "noxud", "un", "seker", "duz", "yag", "gunebaxan",
            "sirke", "ketcap", "mayonez", "sous", "konserv", "bal", "murebbe", "edviyyat", "qarabogday", "bulqur", "noodle",
            "dosirak", "fasilye", "zeytun", "turşu", "tursu", "pasta", "chips", "ceviz", "kisamis", "gogerti", "макарон", "крупа", "рис", "гречка", "сахар", "соль", "мед", "консерв", "кетчуп", "майонез", "соус", "уксус", "фасоль", "горох", "лапша", "оливк"
        ),
        "Meyvə və tərəvəz" to listOf(
            "alma", "armud", "banan", "portagal", "mandarin", "limon", "uzum", "nar", "xiyar", "pomidor", "kartof", "sogan",
            "sarimsaq", "kelem", "yerkoku", "biber", "badimcan", "qarpiz", "yemis", "meyve", "terevez", "ispanaq", "cilek",
            "albali", "gilas", "heyva", "ayva", "avokado", "ananas", "kivi", "gavali", "xurma", "enar", "sitrus", "yasil", "яблок", "груш", "банан", "апельсин", "мандарин", "лимон", "виноград", "огурц", "помидор", "томат", "картофел", "лук", "чеснок", "капуст", "морков", "перец", "арбуз", "персик", "клубник", "фрукт", "овощ"
        )
    )

    /** Kateqoriyaların göstərilmə sırası (Digər sonda). */
    val ORDER: List<String> = listOf(
        "İçkilər, çay və qəhvə", "Süd məhsulları və yumurta", "Ət, quş və balıq", "Meyvə və tərəvəz",
        "Bakaliya və çörək", "Şirniyyat və qənnadı", "Dondurulmuş məhsullar",
        "Təmizlik və gigiyena", "Uşaq məhsulları", OTHER
    )

    /** Köhnə (birləşdirilməmiş) kateqoriya adları → yeni birləşdirilmiş ad (yadda saxlanmış məhsullar üçün). */
    private val OLD_TO_NEW = mapOf(
        "İçkilər" to "İçkilər, çay və qəhvə", "Çay və qəhvə" to "İçkilər, çay və qəhvə",
        "Ət və ət məhsulları" to "Ət, quş və balıq", "Balıq və dəniz məhsulları" to "Ət, quş və balıq",
        "Çörək və un məmulatları" to "Bakaliya və çörək", "Bakaliya" to "Bakaliya və çörək",
        "Təmizlik və məişət" to "Təmizlik və gigiyena", "Şəxsi gigiyena" to "Təmizlik və gigiyena"
    )
    fun mergeOld(cat: String): String = OLD_TO_NEW[cat] ?: cat

    /**
     * Sözlərə bölmə (normallaşdırılmış mətn üçün). Rəqəmlər arasındakı nöqtə/vergül saxlanır ki, "0.5" və "1.5" ayrılmasın
     * (ondalıq ayırıcı vahid işarəyə çevrilir: "0,5l" və "0.5l" eyni sayılır).
     */
    private val DECIMAL = Regex("(?<=\\p{N})[.,](?=\\p{N})")
    private val WORD_SPLIT = Regex("[^\\p{L}\\p{N}\\u0001]+")
    fun words(normalized: String): List<String> =
        DECIMAL.replace(normalized, "\u0001").split(WORD_SPLIT).filter { it.isNotEmpty() }

    private val RULES_NORM: List<Pair<String, List<String>>> =
        RULES.map { (c, kws) -> c to kws.map { norm(it) }.distinct() }

    fun norm(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s.lowercase(Locale.ROOT)) {
            when (ch) {
                'ə' -> sb.append('e')
                'ı' -> sb.append('i')
                'ö' -> sb.append('o')
                'ü' -> sb.append('u')
                'ş' -> sb.append('s')
                'ç' -> sb.append('c')
                'ğ' -> sb.append('g')
                'ё' -> sb.append('е')       // rus: ё = е (axtarışda eyni)
                'ә' -> sb.append('e')       // kirill "ә" (OCR bəzən belə oxuyur)
                '\u0307' -> {}            // "İ" → "i̇" birləşən nöqtə
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /** BÜTÖV BÖYÜK HƏRFLİ OCR adlarını oxunaqlı hala gətirir: "COCA COLA 0.5L" → "Coca Cola 0.5L" (İ/I Azərbaycan qaydası ilə). */
    fun pretty(name: String): String {
        if (name.any { it.isLowerCase() }) return name
        return AzText.titleCase(name)
    }

    fun classify(name: String): String {
        val tokens = norm(name).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return OTHER
        for ((cat, kws) in RULES_NORM) {
            for (kw in kws) {
                val hit = if (kw.length <= 3) tokens.any { it == kw } else tokens.any { it.startsWith(kw) }
                if (hit) return cat
            }
        }
        return OTHER
    }
}
