package az.zeng.yazici;

import android.app.RemoteInput;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/** Bildirişdə yazılan 6 rəqəmli cütləşdirmə kodunu qəbul edib cütləşir və yazıcını başladır. */
public class PairReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context c, Intent i) {
        Bundle r = RemoteInput.getResultsFromIntent(i);
        if (r == null) return;
        CharSequence cs = r.getCharSequence("code");
        final String code = cs == null ? "" : cs.toString().trim();
        final PendingResult pr = goAsync();
        final Context a = c.getApplicationContext();
        new Thread(() -> {
            try {
                Notif.pairStatus(a, "Cütləşdirilir…");
                int port = AdbStarter.discover(a, "_adb-tls-pairing._tcp", 8000);
                if (port <= 0)
                    throw new Exception("Cütləşdirmə xidməti tapılmadı. \"Pair device with pairing code\" pəncərəsi açıq qalmalıdır.");
                AdbStarter.pair(a, port, code);
                Notif.pairStatus(a, "Cütləşdi. Yazıcı proses başladılır…");
                AdbStarter.startDaemon(a);
                boolean up = false;
                for (int k = 0; k < 10 && !up; k++) {
                    Thread.sleep(500);
                    up = RecorderClient.ping(a);
                }
                Notif.pairStatus(a, up ? "Hazırdır. Zəngləri yazmağa başlaya bilərsiniz."
                        : "Cütləşdi, amma yazıcı proses başlamadı. Tətbiqdəki Jurnala baxın.");
            } catch (Throwable t) {
                Notif.pairStatus(a, "Alınmadı: " + t.getMessage());
            } finally {
                pr.finish();
            }
        }).start();
    }
}
