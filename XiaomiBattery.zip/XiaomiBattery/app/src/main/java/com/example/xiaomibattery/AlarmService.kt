package com.example.xiaomibattery

import android.app.*
import android.content.*
import android.media.*
import android.os.*

class AlarmService : Service() {
    private var rt: Ringtone? = null
    private var rang = false
    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val lvl = i.getIntExtra("level", 0) * 100 / i.getIntExtra("scale", 100)
            val plugged = i.getIntExtra("plugged", 0) != 0
            if (plugged && lvl >= 100) { if (!rang) { rang = true; ring() } }
            else { rang = false; stopRing() }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); registerReceiver(rcv, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }
    override fun onDestroy() { stopRing(); try { unregisterReceiver(rcv) } catch (_: Exception) {}; super.onDestroy() }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val n = notif("100% olanda zəng çalacaq")
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (i?.action == "STOP_RING") stopRing()
        return START_STICKY
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("bat", "Batareya zəngi", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, AlarmService::class.java).setAction("STOP_RING"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "bat") else Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.ic_lock_idle_charging).setContentTitle("Xiaomi Batareya")
            .setContentText(text).setOngoing(true).addAction(android.R.drawable.ic_media_pause, "Zəngi dayandır", stop).build()
    }

    private fun ring() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        rt = RingtoneManager.getRingtone(this, uri)?.apply {
            audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            if (Build.VERSION.SDK_INT >= 28) isLooping = true
            play()
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, notif("🔋 100%! Batareya doldu — adapteri çıxarın"))
    }

    private fun stopRing() { try { rt?.stop() } catch (_: Exception) {}; rt = null }
}
