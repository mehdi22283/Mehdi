package az.wifiscan

import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.Inet6Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.URL

fun toolsPage(u: Ui): Page {
    val sv = ScrollView(u.act)
    val root = u.vbox(); root.setPadding(u.dp(12), u.dp(8), u.dp(12), u.dp(24))
    sv.addView(root)
    root.addView(u.tv("Alətlər", 22f, u.ACC, true))

    fun outView() = u.tv("", 12f, u.TXT, false, true).apply { setTextIsSelectable(true); setPadding(0, u.dp(6), 0, 0) }

    // ---------- 1) IP və DNS məlumatı ----------
    val c1 = u.card(); root.addView(c1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = u.dp(8) })
    c1.addView(u.tv("🌐 IP və DNS məlumatı", 16f, u.TXT, true))
    val o1 = outView()
    val b1 = u.btn("Yenilə") {}
    c1.addView(b1); c1.addView(o1)
    b1.setOnClickListener {
        b1.isEnabled = false; o1.text = "Yüklənir…"
        Thread {
            val sb = StringBuilder()
            val ni = u.netInfo()
            if (ni == null) sb.append("❌ Wi-Fi/şəbəkə yoxdur\n") else {
                sb.append("📱 Lokal IPv4: ${ni.first}/${ni.second}\n🚪 Gateway: ${ni.third.ifEmpty { "—" }}\n")
            }
            try {
                val v6 = NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
                    .filter { it is Inet6Address && !it.isLoopbackAddress && !it.isLinkLocalAddress }.mapNotNull { it.hostAddress?.substringBefore('%') }
                if (v6.isNotEmpty()) sb.append("🔢 IPv6: ${v6.joinToString(", ")}\n")
            } catch (e: Exception) {}
            val dns = Dns.systemServers(u.act)
            sb.append("🧭 DNS serverlər: ${if (dns.isEmpty()) "—" else dns.joinToString(", ")}\n")
            var pub = ""
            try {
                val c = URL("http://ip-api.com/json/?fields=status,country,regionName,city,isp,org,as,query,timezone,mobile,proxy,hosting").openConnection() as HttpURLConnection
                c.connectTimeout = 4000; c.readTimeout = 4000
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                if (j.optString("status") == "success") {
                    pub = j.optString("query")
                    sb.append("\n🌍 Public IP: $pub\n📍 ${j.optString("city")}, ${j.optString("regionName")}, ${j.optString("country")}\n")
                    sb.append("🏢 ${j.optString("isp")} (${j.optString("org")})\n🔢 ${j.optString("as")}\n🕒 ${j.optString("timezone")}\n")
                    val flags = ArrayList<String>()
                    if (j.optBoolean("mobile")) flags.add("mobil şəbəkə")
                    if (j.optBoolean("proxy")) flags.add("proxy/VPN")
                    if (j.optBoolean("hosting")) flags.add("hosting/datacenter")
                    if (flags.isNotEmpty()) sb.append("🏷 ${flags.joinToString(", ")}\n")
                } else sb.append("\n🌍 Public IP alına bilmədi\n")
            } catch (e: Exception) { sb.append("\n🌍 Public IP alına bilmədi (internet yoxdur?)\n") }
            if (pub.isNotEmpty()) {
                val rd = try { InetAddress.getByName(pub).canonicalHostName.let { if (it == pub) "" else it } } catch (e: Exception) { "" }
                if (rd.isNotEmpty()) sb.append("🔖 Reverse DNS: $rd\n")
            }
            sb.append("\n⏱ DNS cavab sürəti (google.com):\n")
            val servers = (dns + listOf("8.8.8.8", "1.1.1.1", "9.9.9.9")).distinct()
            for (s in servers) {
                val r = Dns.query("google.com", 1, s, 2500)
                val tag = if (dns.contains(s)) " (sistem)" else ""
                sb.append(if (r.rcode == 0 && r.lines.isNotEmpty()) "  ✔ $s$tag  ${r.ms} ms\n" else "  ✖ $s$tag  ${r.error.ifEmpty { "cavab yoxdur" }}\n")
            }
            u.post { o1.text = sb.toString(); b1.isEnabled = true }
        }.start()
    }

    // ---------- 2) DNS lookup ----------
    val c2 = u.card(); root.addView(c2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = u.dp(12) })
    c2.addView(u.tv("🔎 DNS lookup", 16f, u.TXT, true))
    val dom = u.edit("Domen və ya IP", "google.com"); c2.addView(dom)
    val typeSp = u.spinner(Dns.TYPES.keys.toList()); c2.addView(typeSp)
    val srvSp = u.spinner(listOf("Sistem DNS", "8.8.8.8 (Google)", "1.1.1.1 (Cloudflare)", "9.9.9.9 (Quad9)")); c2.addView(srvSp)
    val o2 = outView()
    val b2 = u.btn("Axtar") {}
    c2.addView(b2); c2.addView(o2)

    fun runDns() {
        val q0 = dom.text.toString().trim(); if (q0.isEmpty()) return
        val tName = typeSp.selectedItem.toString()
        var type = Dns.TYPES[tName] ?: 1
        var q = q0
        if (tName == "PTR" && Dns.isIpv4(q0)) q = Dns.reverseName(q0)
        if (Dns.isIpv4(q0) && tName != "PTR") { type = 12; q = Dns.reverseName(q0) }
        val sel = srvSp.selectedItemPosition
        b2.isEnabled = false; o2.text = "Sorğu göndərilir…"
        val finalType = type; val finalQ = q
        Thread {
            val server = when (sel) {
                1 -> "8.8.8.8"; 2 -> "1.1.1.1"; 3 -> "9.9.9.9"
                else -> Dns.systemServers(u.act).firstOrNull() ?: "8.8.8.8"
            }
            val r = Dns.query(finalQ, finalType, server)
            val sb = StringBuilder()
            sb.append("Server: $server • ${r.ms} ms\nSorğu: $finalQ\n\n")
            if (r.error.isNotEmpty()) sb.append("❌ ${r.error}")
            else if (r.rcode == 3) sb.append("❌ NXDOMAIN: belə domen mövcud deyil")
            else if (r.rcode != 0) sb.append("❌ DNS xətası (rcode ${r.rcode})")
            else if (r.lines.isEmpty()) sb.append("Bu növ üçün qeyd yoxdur")
            else r.lines.forEach { sb.append(it).append("\n") }
            u.post { o2.text = sb.toString(); b2.isEnabled = true }
        }.start()
    }
    b2.setOnClickListener { runDns() }

    // ---------- 3) WHOIS ----------
    val c3 = u.card(); root.addView(c3, LinearLayout.LayoutParams(-1, -2).apply { topMargin = u.dp(12) })
    c3.addView(u.tv("📇 WHOIS", 16f, u.TXT, true))
    val wh = u.edit("Domen və ya IP", "example.com"); c3.addView(wh)
    val o3 = outView()
    val b3 = u.btn("WHOIS sorğusu") {}
    c3.addView(b3); c3.addView(o3)

    fun runWhois() {
        val q = wh.text.toString().trim(); if (q.isEmpty()) return
        b3.isEnabled = false; o3.text = "Sorğu göndərilir…"
        Thread {
            val txt = try { Whois.lookup(q) } catch (e: Exception) { "❌ ${e.message ?: "xəta"}" }
            u.post { o3.text = txt; b3.isEnabled = true }
        }.start()
    }
    b3.setOnClickListener { runWhois() }

    // ---------- 4) İstehsalçı bazası ----------
    val c4 = u.card(); root.addView(c4, LinearLayout.LayoutParams(-1, -2).apply { topMargin = u.dp(12) })
    c4.addView(u.tv("🏷 İstehsalçı (OUI) bazası", 16f, u.TXT, true))
    val st = u.tv("", 12f, u.SUB)
    c4.addView(st)
    val mac = u.edit("MAC (məs. 44:19:B6:12:34:56)", ""); c4.addView(mac)
    val o4 = outView()
    val bFind = u.btn("MAC-dan istehsalçını tap") {}
    val bUp = u.btn("⬇ Bazanı internetdən yenilə") {}
    c4.addView(bFind); c4.addView(bUp); c4.addView(o4)
    fun status() {
        Thread {
            Oui.load(u.act.applicationContext)
            u.post { st.text = "Baza: ${Oui.size} yazı • " + (if (Oui.isFull) "✅ tam IEEE bazası" else "⚠ yalnız daxili qısa siyahı, yeniləyin") }
        }.start()
    }
    status()
    bFind.setOnClickListener {
        val m = mac.text.toString().trim()
        Thread {
            Oui.load(u.act.applicationContext)
            val v = Oui.vendor(m)
            val rnd = Oui.isRandom(m.replace("-", ":"))
            u.post { o4.text = if (v.isNotEmpty()) "✅ $v" + (if (rnd) "\n(ikinci simvol təsadüfi/private MAC göstərir)" else "") else "❌ Bazada tapılmadı" + (if (rnd) "\n(təsadüfi/private MAC: telefon Wi-Fi privacy aktivdir)" else "") }
        }.start()
    }
    bUp.setOnClickListener {
        bUp.isEnabled = false; o4.text = "Yüklənir (təxminən 2-3 MB)…"
        Thread {
            val msg = try { "✅ Yeniləndi: ${Oui.download(u.act.applicationContext)} yazı" } catch (e: Exception) { "❌ Yüklənmədi: ${e.message}" }
            u.post { o4.text = msg; bUp.isEnabled = true; status() }
        }.start()
    }

    return Page(sv, open = { h ->
        dom.setText(h); wh.setText(h)
        typeSp.setSelection(if (Dns.isIpv4(h)) Dns.TYPES.keys.indexOf("PTR") else 0)
        sv.scrollTo(0, 0)
        runDns(); runWhois()
    })
}
