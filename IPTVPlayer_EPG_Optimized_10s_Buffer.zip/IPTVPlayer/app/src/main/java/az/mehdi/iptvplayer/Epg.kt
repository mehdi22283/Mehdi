package az.mehdi.iptvplayer

import android.content.Context
import android.util.Xml
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.text.Normalizer
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.zip.GZIPInputStream

/** Yeganə mənbə: EPG (proqram cədvəli) və kanal loqoları buradan alınır. Fayl .gz-dir, açılıb XML kimi oxunur. */
const val EPG_URL = "https://iptvx.one/EPG_NOARCH"
private const val EPG_MAX_AGE_MS = 6L * 3600 * 1000

class Prog(val start: Long, var stop: Long, val title: String, val desc: String)

private val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm").withZone(ZoneId.systemDefault())
fun hm(t: Long): String = HM.format(Instant.ofEpochSecond(t))

/** Bu gün üçün boş, sabah üçün "Sabah", sonrası üçün "dd.MM". */
fun dayLabel(t: Long): String {
    val d = Instant.ofEpochSecond(t).atZone(ZoneId.systemDefault()).toLocalDate()
    val today = java.time.LocalDate.now()
    return when (d) {
        today -> ""
        today.plusDays(1) -> "Sabah"
        else -> "%02d.%02d".format(d.dayOfMonth, d.monthValue)
    }
}

private val BRACKETS = Regex("[\\[(].*?[\\])]")
private val QUALITY = Regex("\\b(hd|fhd|uhd|sd|4k|8k|hevc|h265|backup|ehtiyat|biraz|tr|az)\\b")
private val MODIFIERS = Regex("\\p{Lm}+")
private val NON_ALNUM = Regex("[^\\p{L}\\p{N}]")
private val MARKS = Regex("\\p{Mn}+")

/** Kanal adını müqayisə üçün sadələşdirir (kiril hərfləri də qalır). */
fun normKey(s: String): String {
    var t = s.lowercase().replace('ə', 'e').replace('ı', 'i')
    t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(MARKS, "")
    t = t.replace(MODIFIERS, " ").replace(BRACKETS, " ").replace(QUALITY, " ")
    return t.replace(NON_ALNUM, "")
}

private class Snap(
    val idByUrl: Map<String, String>,
    val icons: Map<String, String>,
    val progs: Map<String, List<Prog>>,
    val time: Long = System.currentTimeMillis()
)

class EpgStore(private val ctx: Context) {
    @Volatile private var snap = Snap(emptyMap(), emptyMap(), emptyMap())
    /** İlk yükləmə cəhdi bitəndə (uğurlu və ya uğursuz) tamamlanır; loqo axtarışı bunu gözləyir. */
    val ready = CompletableDeferred<Unit>()
    private val lock = Mutex()
    private var sig = 0
    private val file = File(ctx.filesDir, "epg_source.bin")

    fun idFor(ch: Channel): String? = snap.idByUrl[ch.url]
    fun iconUrl(id: String): String? = snap.icons[id]

    /** Kanalın indi gedən və sonrakı bütün proqramları (cədvəl). */
    fun programs(ch: Channel): List<Prog> {
        val s = snap
        val id = s.idByUrl[ch.url] ?: return emptyList()
        val t = System.currentTimeMillis() / 1000
        return s.progs[id].orEmpty().filter { it.stop > t }
    }

    fun nowNext(ch: Channel): Pair<Prog?, Prog?> {
        val s = snap
        val id = s.idByUrl[ch.url] ?: return null to null
        val list = s.progs[id] ?: return null to null
        val t = System.currentTimeMillis() / 1000
        var now: Prog? = null
        var next: Prog? = null
        for (p in list) {
            if (p.start <= t && t < p.stop) now = p
            else if (p.start > t) { next = p; break }
        }
        return now to next
    }

    private fun sigOf(channels: List<Channel>) =
        channels.size * 31 + channels.fold(0) { a, c -> a * 31 + c.url.hashCode() }

    /** Telefonda saxlanılan EPG nüsxəsini dərhal yükləyir (şəbəkə gözləmədən). Dəyişiklik olubsa true. */
    suspend fun loadCached(channels: List<Channel>): Boolean = lock.withLock {
        val s = sigOf(channels)
        if (!file.exists() || s == sig) return@withLock false
        var changed = false
        try {
            withContext(Dispatchers.IO) { snap = parse(file, channels); sig = s; changed = true }
            ready.complete(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            changed = false
        }
        changed
    }

    /**
     * Mənbədə yenilik varsa (ETag / Last-Modified / məzmun hash-i) tam endirir, .gz-i açıb yoxlayır və
     * yalnız tam uğurlu olarsa bütün EPG-ni birdəfəlik əvəz edir. Playlist dəyişibsə keşdən yenidən uyğunlaşdırır.
     * Dəyişiklik olubsa true; mənbənin özü yenilənibsə `sourceUpdated` true olur.
     */
    @Volatile private var sourceUpdated = false
    /** Mənbə yenilənibsə true qaytarır və bayrağı təmizləyir. */
    fun consumeSourceUpdated(): Boolean { val v = sourceUpdated; sourceUpdated = false; return v }

    suspend fun update(channels: List<Channel>, force: Boolean = false): Boolean = lock.withLock {
        val s = sigOf(channels)
        var changed = false
        try {
            withContext(Dispatchers.IO) {
                var newSnap: Snap? = null
                var dl: Dl? = null
                val nowMs = android.os.SystemClock.elapsedRealtime()
                if (force || nowMs - lastCheck > 60 * 1000L || !file.exists()) {
                    lastCheck = nowMs
                    val got = download()
                    if (got != null) {
                        newSnap = runCatching { parse(got.f, channels) }.getOrNull()
                        if (newSnap == null) got.f.delete() // zədəli/yarımçıq: köhnə qalır
                        else dl = got
                    }
                }
                if (newSnap == null && file.exists() && s != sig) newSnap = parse(file, channels)
                if (newSnap != null) {
                    if (dl != null) {
                        if (file.exists()) file.delete()
                        dl.f.renameTo(file)
                        prefs.edit().putString("etag", dl.etag).putString("lm", dl.lm).putString("sha", dl.sha).apply()
                        sourceUpdated = true
                    }
                    snap = newSnap; sig = s; changed = true // hamısı birdən dəyişir
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            changed = false
        } finally {
            ready.complete(Unit)
        }
        changed
    }

    private var lastRescan = 0L

    private fun sameProgs(a: List<Prog>?, b: List<Prog>?): Boolean {
        if (a == null || b == null) return a == b
        if (a.size != b.size) return false
        for (i in a.indices) if (a[i].start != b[i].start || a[i].stop != b[i].stop || a[i].title != b[i].title) return false
        return true
    }

    /**
     * Kanal dəyişəndə çağırılır: bu kanalın EPG-si köhnəlibsə (indi/sonrakı proqram yoxdur və ya məlumat 30 dəqiqədən köhnədir)
     * telefondakı EPG faylında yenidən yoxlayıb yeniləyir. Fayl yoxlaması ən çox 3 dəqiqədə bir edilir.
     * Kanalın proqramı dəyişibsə true.
     */
    suspend fun refreshChannel(ch: Channel, channels: List<Channel>): Boolean = lock.withLock {
        val id = snap.idByUrl[ch.url]
        if (id == null || !file.exists()) return@withLock false
        val (n, x) = nowNext(ch)
        if (n != null && x != null && System.currentTimeMillis() - snap.time < 30 * 60 * 1000L) return@withLock false
        val nowMs = android.os.SystemClock.elapsedRealtime()
        if (nowMs - lastRescan < 3 * 60 * 1000L) return@withLock false
        lastRescan = nowMs
        var changed = false
        try {
            withContext(Dispatchers.IO) {
                val before = snap.progs[id]
                val ns = parse(file, channels)
                snap = ns; sig = sigOf(channels)
                changed = !sameProgs(before, ns.progs[id])
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            changed = false
        }
        changed
    }

    private class Dl(val f: File, val etag: String?, val lm: String?, val sha: String)
    private val prefs = ctx.getSharedPreferences("epg", Context.MODE_PRIVATE)
    private var lastCheck = 0L

    private fun sha1(f: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-1")
        f.inputStream().use { i -> val buf = ByteArray(64 * 1024); while (true) { val n = i.read(buf); if (n < 0) break; md.update(buf, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Yeni məzmun varsa fresh fayla endirib qaytarır; dəyişiklik yoxdursa (304 / eyni hash) null. */
    private fun download(): Dl? {
        val fresh = File(ctx.filesDir, "epg_new.bin")
        return try {
            val have = file.exists()
            val r = fetchConditional(
                EPG_URL, fresh,
                if (have) prefs.getString("etag", null) else null,
                if (have) prefs.getString("lm", null) else null, 30000
            )
            if (r.notModified) { fresh.delete(); null }
            else if (fresh.length() <= 200 || !looksValid(fresh)) { fresh.delete(); null }
            else {
                val sha = sha1(fresh)
                if (have && sha == prefs.getString("sha", null)) {
                    prefs.edit().putString("etag", r.etag).putString("lm", r.lastMod).apply()
                    fresh.delete(); null
                } else Dl(fresh, r.etag, r.lastMod, sha)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            fresh.delete(); null
        }
    }

    private fun looksValid(f: File): Boolean = f.inputStream().use {
        val a = it.read(); val b = it.read()
        (a == 0x1f && b == 0x8b) || a == '<'.code || a == 0xEF // gzip, XML və ya BOM-lu XML
    }

    /** .gz isə açır, deyilsə (server artıq açıb göndərib) olduğu kimi oxuyur. */
    private fun open(f: File): InputStream {
        val b = BufferedInputStream(FileInputStream(f), 64 * 1024)
        b.mark(2)
        val b0 = b.read(); val b1 = b.read()
        b.reset()
        return if (b0 == 0x1f && b1 == 0x8b) GZIPInputStream(b, 64 * 1024) else b
    }

    private fun match(
        ch: Channel, ids: Set<String>, idsLower: Map<String, String>, keyToId: Map<String, String>,
        fuzzy: Lazy<NameFuzzy>
    ): String? {
        ch.tvgId?.let { t ->
            if (t in ids) return t
            idsLower[t.lowercase()]?.let { return it }
        }
        val keys = listOf(ch.tvgName, ch.name).mapNotNull { c -> c?.let { normKey(it) }?.takeIf { it.isNotEmpty() } }
        for (n in keys) {
            keyToId[n]?.let { return it }
            keyToId[n.removeSuffix("tv")]?.let { return it }
            keyToId[n + "tv"]?.let { return it }
        }
        for (n in keys) fuzzy.value.find(n)?.let { return it }
        return null
    }

    private fun parse(f: File, channels: List<Channel>): Snap {
        val now = System.currentTimeMillis() / 1000
        val horizon = now + 48 * 3600
        val names = ArrayList<Pair<String, String>>()
        val iconAll = HashMap<String, String>()
        val ids = HashSet<String>()
        val wanted = HashSet<String>()
        var idByUrl: Map<String, String> = emptyMap()
        var built = false
        val progs = HashMap<String, ArrayList<Prog>>()

        fun build() {
            built = true
            val keyToId = HashMap<String, String>()
            for ((id, n) in names) { val k = normKey(n); if (k.isNotEmpty()) keyToId.putIfAbsent(k, id) }
            val idsLower = HashMap<String, String>()
            for (id in ids) idsLower.putIfAbsent(id.lowercase(), id)
            val m = HashMap<String, String>()
            val fuzzy = lazy { NameFuzzy(keyToId) }
            for (c in channels) match(c, ids, idsLower, keyToId, fuzzy)?.let { m[c.url] = it }
            idByUrl = m
            wanted.addAll(m.values)
        }

        var curId: String? = null
        var inProg = false
        var pId = ""; var pStart = 0L; var pStop = 0L
        var pTitle: String? = null; var pDesc: String? = null

        open(f).use { input ->
            val p = Xml.newPullParser()
            p.setInput(input, null)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "channel" -> { curId = p.getAttributeValue(null, "id"); curId?.let { ids.add(it) } }
                        "display-name" -> {
                            val cid = curId
                            if (cid != null) { val t = p.nextText().trim(); if (t.isNotEmpty()) names.add(cid to t) }
                        }
                        "icon" -> {
                            val cid = curId
                            val src = p.getAttributeValue(null, "src")
                            if (cid != null && src != null && src.startsWith("http")) iconAll.putIfAbsent(cid, src)
                        }
                        "programme" -> {
                            if (!built) build()
                            inProg = false
                            val cid = p.getAttributeValue(null, "channel")
                            if (cid != null && cid in wanted) {
                                val st = xmltvTime(p.getAttributeValue(null, "start"))
                                val sp = xmltvTime(p.getAttributeValue(null, "stop"))
                                val keep = st > 0 && st < horizon && (if (sp > 0) sp > now else st > now - 4 * 3600)
                                if (keep) {
                                    inProg = true; pId = cid; pStart = st; pStop = sp
                                    pTitle = null; pDesc = null
                                }
                            }
                        }
                        "title" -> if (inProg && pTitle == null) pTitle = p.nextText().trim()
                        "desc" -> if (inProg && pDesc == null) pDesc = p.nextText().trim()
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    when (p.name) {
                        "channel" -> curId = null
                        "programme" -> if (inProg) {
                            inProg = false
                            val title = pTitle
                            if (!title.isNullOrEmpty()) {
                                progs.getOrPut(pId) { ArrayList() }.add(Prog(pStart, pStop, title, pDesc.orEmpty()))
                            }
                        }
                    }
                }
                ev = p.next()
            }
        }
        if (!built) build()

        val out = HashMap<String, List<Prog>>()
        for ((id, l) in progs) {
            l.sortBy { it.start }
            for (i in l.indices) if (l[i].stop <= 0) l[i].stop = if (i + 1 < l.size) l[i + 1].start else l[i].start + 3600
            out[id] = l
        }
        val icons = HashMap<String, String>()
        for (id in wanted) iconAll[id]?.let { icons[id] = it }
        return Snap(idByUrl, icons, out)
    }
}

/** XMLTV vaxtı: 20261023183000 +0300 */
private fun xmltvTime(s: String?): Long {
    if (s == null) return 0
    val t = s.trim()
    if (t.length < 12) return 0
    return try {
        val y = t.substring(0, 4).toInt(); val mo = t.substring(4, 6).toInt(); val d = t.substring(6, 8).toInt()
        val h = t.substring(8, 10).toInt(); val mi = t.substring(10, 12).toInt()
        val sec = if (t.length >= 14 && t[12].isDigit()) t.substring(12, 14).toInt() else 0
        val rest = t.drop(if (t.length >= 14 && t[12].isDigit()) 14 else 12).trim()
        var off = 0
        if (rest.length >= 5 && (rest[0] == '+' || rest[0] == '-')) {
            val sign = if (rest[0] == '-') -1 else 1
            off = sign * (rest.substring(1, 3).toInt() * 3600 + rest.substring(3, 5).toInt() * 60)
        }
        LocalDateTime.of(y, mo, d, h, mi, sec).toEpochSecond(ZoneOffset.ofTotalSeconds(off))
    } catch (e: Throwable) { 0 }
}


private fun digitsOf(x: String) = x.filter { it.isDigit() }

private fun levDist(a: String, b: String, max: Int): Int {
    if (kotlin.math.abs(a.length - b.length) > max) return max + 1
    var prev = IntArray(b.length + 1) { it }
    var cur = IntArray(b.length + 1)
    for (i in 1..a.length) {
        cur[0] = i
        var rowMin = cur[0]
        for (j in 1..b.length) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
            if (cur[j] < rowMin) rowMin = cur[j]
        }
        if (rowMin > max) return max + 1
        val t = prev; prev = cur; cur = t
    }
    return prev[b.length]
}

/**
 * Oxşar ad axtarışı (EPG və loqo mənbələri üçün ortaq): açar -> dəyər xəritəsində
 * bir-birini ehtiva edən və ya 1-2 hərf fərqli adlar tapılır (rəqəmlər eyni olmalıdır).
 */
class NameFuzzy(keyToVal: Map<String, String>) {
    private val byLen = HashMap<Int, ArrayList<Pair<String, String>>>()
    init { for ((k, v) in keyToVal) byLen.getOrPut(k.length) { ArrayList() }.add(k to v) }

    fun find(n: String): String? {
        if (n.length < 3) return null
        val dn = digitsOf(n)
        var best: String? = null
        var bestScore = 0.0
        for (l in maxOf(3, n.length - 8)..(n.length + 8)) {
            val bucket = byLen[l] ?: continue
            for ((k, v) in bucket) {
                val sh = if (k.length <= n.length) k else n
                val lo = if (k.length <= n.length) n else k
                if (sh.length < 4 || !lo.contains(sh)) continue
                if (digitsOf(k) != dn) continue
                val sc = sh.length.toDouble() / lo.length
                if (sc >= 0.55 && sc > bestScore) { bestScore = sc; best = v }
            }
        }
        if (best != null) return best
        if (n.length < 5) return null
        val maxD = if (n.length >= 10) 2 else 1
        var bd = maxD + 1
        for (l in (n.length - maxD)..(n.length + maxD)) {
            val bucket = byLen[l] ?: continue
            for ((k, v) in bucket) {
                if (k[0] != n[0] && k.last() != n.last()) continue
                if (digitsOf(k) != dn) continue
                val d = levDist(n, k, maxD)
                if (d < bd) { bd = d; best = v }
            }
        }
        return best
    }
}
