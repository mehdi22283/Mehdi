package com.mehdi.keymapper

import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.reflect.Method

/**
 * ADB shell (uid=shell) daxilində daimi işləyir və stdin-dən gələn əmrləri
 * dərhal sistemə inject edir. "input keyevent" kimi hər dəfə yeni proses
 * açmadığı üçün gecikmə demək olar ki, yoxdur.
 *
 * Protokol (hər sətir): "D kod təkrar" | "U kod" | "K kod"
 */
object Injector {
    private var target: Any? = null
    private var inject: Method? = null

    @JvmStatic
    fun main(args: Array<String>) {
        try { setup() } catch (_: Throwable) {}
        val br = BufferedReader(InputStreamReader(System.`in`))
        while (true) {
            val line = br.readLine() ?: break
            val p = line.trim().split(" ")
            val code = p.getOrNull(1)?.toIntOrNull() ?: continue
            try {
                when (p[0]) {
                    "D" -> send(KeyEvent.ACTION_DOWN, code, p.getOrNull(2)?.toIntOrNull() ?: 0)
                    "U" -> send(KeyEvent.ACTION_UP, code, 0)
                    "K" -> { send(KeyEvent.ACTION_DOWN, code, 0); send(KeyEvent.ACTION_UP, code, 0) }
                }
            } catch (_: Throwable) {
                try { Runtime.getRuntime().exec(arrayOf("input", "keyevent", code.toString())) } catch (_: Throwable) {}
            }
        }
    }

    private fun setup() {
        try {
            val cls = Class.forName("android.hardware.input.InputManager")
            target = cls.getMethod("getInstance").invoke(null)
            inject = cls.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (_: Throwable) {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "input")
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            target = stub.getMethod("asInterface", android.os.IBinder::class.java).invoke(null, binder)
            inject = target!!.javaClass.getMethod(
                "injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType
            )
        }
    }

    private fun send(action: Int, code: Int, repeat: Int) {
        val now = SystemClock.uptimeMillis()
        val e = KeyEvent(now, now, action, code, repeat, 0, -1, 0, 0, InputDevice.SOURCE_KEYBOARD)
        // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        inject!!.invoke(target, e, 0)
    }
}
