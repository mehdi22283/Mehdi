package com.mehdi.keymapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class KeepAliveService : Service() {
    override fun onCreate() {
        super.onCreate()
        val id = "keepalive"
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
                NotificationChannel(id, "Key Mapper", NotificationManager.IMPORTANCE_MIN)
            )
        }
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, id) else Notification.Builder(this)
        startForeground(
            1,
            n.setContentTitle("Key Mapper TV aktivdir")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}
