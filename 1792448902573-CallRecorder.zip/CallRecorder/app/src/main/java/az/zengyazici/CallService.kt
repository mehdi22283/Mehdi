package az.zengyazici

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.MediaRecorder
import android.os.*
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class CallService : Service() {
    private lateinit var am: AudioManager
    private lateinit var nm: NotificationManager
    private val h = Handler(Looper.getMainLooper())
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var ringing = false
    private var idle = 0

    private val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) {
            if (state == TelephonyManager.CALL_STATE_RINGING) ringing = true
        }
    }
    private val poll = object : Runnable {
        override fun run() { tick(); h.postDelayed(this, 1000) }
    }

    override fun onCreate() {
        am = getSystemService(AudioManager::class.java)
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("status", "Xidmət", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alert", "Zəng yazısı", NotificationManager.IMPORTANCE_HIGH))
        startForeground(1, build("status", "Zəng Yazıcı işləyir", "Zənglər gözlənilir…", true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        try { getSystemService(TelephonyManager::class.java).registerTelephonyCallback(mainExecutor, cb) } catch (_: Exception) {}
        h.post(poll)
    }

    private fun build(ch: String, title: String, text: String, ongoing: Boolean) =
        Notification.Builder(this, ch).setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(title).setContentText(text).setOngoing(ongoing)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .setAutoCancel(!ongoing).build()

    private fun tick() {
        val kind = when (am.mode) {
            AudioManager.MODE_IN_CALL -> "phone"
            AudioManager.MODE_IN_COMMUNICATION -> "whatsapp"
            else -> null
        }
        if (kind != null) { idle = 0; if (rec == null) start(kind) }
        else if (rec != null && ++idle >= 2) stop()
    }

    private fun start(kind: String) {
        val inc = if (kind == "phone") ringing else System.currentTimeMillis() - WaListener.incomingAt < 90_000
        val dir = if (inc) "in" else "out"
        val dirName = File(getExternalFilesDir(null), "calls").apply { mkdirs() }
        val f = File(dirName, "${kind}_${dir}_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.m4a")
        val src = if (kind == "phone") MediaRecorder.AudioSource.VOICE_CALL else MediaRecorder.AudioSource.MIC
        rec = tryRec(f, src) ?: tryRec(f, MediaRecorder.AudioSource.MIC)
        if (rec != null) {
            file = f
            nm.notify(2, build("alert", "● Zəng yazılır", (if (kind == "phone") "Telefon" else "WhatsApp") + " • " + if (inc) "Gələn" else "Gedən", false))
        }
    }

    private fun tryRec(f: File, src: Int): MediaRecorder? = try {
        MediaRecorder(this).apply {
            setAudioSource(src); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioSamplingRate(44100)
            setAudioEncodingBitRate(128000); setOutputFile(f.absolutePath); prepare(); start()
        }
    } catch (e: Exception) { null }

    private fun stop() {
        try { rec?.stop() } catch (_: Exception) {}
        rec?.release(); rec = null; ringing = false
        nm.cancel(2)
        file?.let { nm.notify(3, build("alert", "✔ Zəng yazıldı", it.name, false)) }
        file = null
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { h.removeCallbacks(poll); if (rec != null) stop() }
}
