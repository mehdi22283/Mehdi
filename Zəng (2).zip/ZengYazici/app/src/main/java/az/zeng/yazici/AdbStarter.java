package az.zeng.yazici;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;

import java.io.Closeable;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Telefonun öz simsiz debaq xidməti ilə (cütləşmə + qoşulma) shell yazıcı prosesini başladır. */
final class AdbStarter {
    private static final String HOST = "127.0.0.1";

    private AdbStarter() {
    }

    private static Object invoke(Object o, String name, Class<?>[] types, Object... args) throws Exception {
        try {
            return o.getClass().getMethod(name, types).invoke(o, args);
        } catch (InvocationTargetException e) {
            Throwable t = e.getCause();
            if (t instanceof Exception) throw (Exception) t;
            throw e;
        }
    }

    private static Set<String> ownAddresses() throws Exception {
        Set<String> own = new HashSet<>();
        for (Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces(); e.hasMoreElements(); ) {
            for (InterfaceAddress ia : e.nextElement().getInterfaceAddresses()) {
                String h = ia.getAddress().getHostAddress();
                int i = h.indexOf('%');
                own.add(i >= 0 ? h.substring(0, i) : h);
            }
        }
        return own;
    }

    /** mDNS ilə xidmətin portunu tapır (yalnız bu telefonun öz xidməti qəbul edilir). */
    static int discover(Context c, String type, long timeoutMs) throws Exception {
        final NsdManager nsd = c.getSystemService(NsdManager.class);
        final Set<String> own = ownAddresses();
        final CountDownLatch latch = new CountDownLatch(1);
        final int[] port = {-1};
        NsdManager.DiscoveryListener dl = new NsdManager.DiscoveryListener() {
            @Override
            public void onStartDiscoveryFailed(String t, int e) {
                latch.countDown();
            }

            @Override
            public void onStopDiscoveryFailed(String t, int e) {
            }

            @Override
            public void onDiscoveryStarted(String t) {
            }

            @Override
            public void onDiscoveryStopped(String t) {
            }

            @Override
            public void onServiceFound(NsdServiceInfo si) {
                nsd.resolveService(si, new NsdManager.ResolveListener() {
                    @Override
                    public void onResolveFailed(NsdServiceInfo s, int e) {
                    }

                    @Override
                    public void onServiceResolved(NsdServiceInfo r) {
                        try {
                            String h = r.getHost().getHostAddress();
                            int i = h.indexOf('%');
                            if (i >= 0) h = h.substring(0, i);
                            if (own.contains(h) && port[0] < 0) {
                                port[0] = r.getPort();
                                latch.countDown();
                            }
                        } catch (Throwable ignored) {
                        }
                    }
                });
            }

            @Override
            public void onServiceLost(NsdServiceInfo si) {
            }
        };
        nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, dl);
        latch.await(timeoutMs, TimeUnit.MILLISECONDS);
        try {
            nsd.stopServiceDiscovery(dl);
        } catch (Throwable ignored) {
        }
        return port[0];
    }

    static void pair(Context c, int port, String code) throws Exception {
        AdbMgr m = AdbMgr.get(c);
        Object ok = invoke(m, "pair", new Class<?>[]{String.class, int.class, String.class}, HOST, port, code);
        if (ok instanceof Boolean && !((Boolean) ok)) throw new Exception("Cütləşmə alınmadı (kod səhvdir?)");
        c.getSharedPreferences("st", 0).edit().putBoolean("paired", true).apply();
    }

    private static void connect(AdbMgr m, int port) throws Exception {
        Object conn = invoke(m, "isConnected", new Class<?>[0]);
        if (conn instanceof Boolean && (Boolean) conn) return;
        try {
            invoke(m, "connectTls", new Class<?>[]{String.class, int.class}, HOST, port);
        } catch (NoSuchMethodException e) {
            invoke(m, "connect", new Class<?>[]{String.class, int.class}, HOST, port);
        }
    }

    /** Yazıcı prosesi artıq işləmirsə adb vasitəsilə shell kimi başladır. */
    static void startDaemon(Context c) throws Exception {
        SharedPreferences p = c.getSharedPreferences("st", 0);
        try {
            int port = discover(c, "_adb-tls-connect._tcp", 5000);
            if (port <= 0)
                throw new Exception("Simsiz debaq tapılmadı (Wi-Fi qoşulu və Wireless debugging açıqdır?)");
            AdbMgr m = AdbMgr.get(c);
            connect(m, port);
            RecorderClient.ident(c);
            String cmd = "app_process -Djava.class.path=" + c.getPackageCodePath()
                    + " /system/bin --nice-name=zeng_rec az.zeng.yazici.Daemon "
                    + p.getInt("d_port", 0) + " " + p.getString("d_tok", "")
                    + " > /data/local/tmp/zeng.log 2>&1";
            cmd = "(setsid nohup " + cmd + " &) ; sleep 1";
            final Object st = invoke(m, "openStream", new Class<?>[]{String.class}, "shell:" + cmd);
            final InputStream in = (InputStream) invoke(st, "openInputStream", new Class<?>[0]);
            Thread t = new Thread(() -> {
                try {
                    byte[] b = new byte[512];
                    while (in.read(b) >= 0) ;
                } catch (Throwable ignored) {
                }
            });
            t.start();
            t.join(4000);
            try {
                if (st instanceof Closeable) ((Closeable) st).close();
            } catch (Throwable ignored) {
            }
            try {
                invoke(m, "disconnect", new Class<?>[0]);
            } catch (Throwable ignored) {
            }
            p.edit().remove("adb_err").apply();
        } catch (Throwable t) {
            p.edit().putString("adb_err", String.valueOf(t)).apply();
            if (t instanceof Exception) throw (Exception) t;
            throw new Exception(t);
        }
    }
}
