package az.vakansiya

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.widget.ImageView
import androidx.work.*
import java.util.concurrent.TimeUnit
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var sites: MutableList<Site>
    private lateinit var adapter: Adapter
    private lateinit var touch: ItemTouchHelper
    private lateinit var status: TextView
    private var counter: Counter? = null
    private lateinit var bell: TextView
    private lateinit var since: TextView
    private var sessionBase: Map<String, Set<String>> = emptyMap()
    private var prevVisit = 0L
    private var stopTime = 0L
    private var started = false
    private val addFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@registerForActivityResult
        Thread {
            val n = uris.count { Files.add(this, it) != null }
            runOnUiThread {
                android.widget.Toast.makeText(this, if (n > 0) "$n fayl əlavə edildi" else "Fayl əlavə edilmədi", android.widget.Toast.LENGTH_SHORT).show()
                filesDialog()
            }
        }.start()
    }

    private fun filesDialog() {
        val fs = Files.list(this)
        val items = (fs.map { it.name + "  (" + Files.size(it) + ")" } + "＋ Fayl əlavə et").toTypedArray()
        AlertDialog.Builder(this).setTitle("Fayllarım (saytlara yükləmək üçün)")
            .setItems(items) { _, w ->
                if (w == fs.size) addFiles.launch(arrayOf("*/*"))
                else AlertDialog.Builder(this).setMessage("\"${fs[w].name}\" silinsin?")
                    .setPositiveButton("Sil") { _, _ -> fs[w].delete(); filesDialog() }
                    .setNegativeButton("Ləğv et") { _, _ -> filesDialog() }.show()
            }.setNegativeButton("Bağla", null).show()
    }

    private val visitPrefs by lazy { getSharedPreferences("visit", MODE_PRIVATE) }

    private fun loadBase(): Map<String, Set<String>> {
        val m = HashMap<String, Set<String>>()
        for ((k, v) in visitPrefs.all) {
            if (!k.startsWith("v_") || v !is String) continue
            try {
                val a = JSONArray(v)
                val set = HashSet<String>()
                for (i in 0 until a.length()) set.add(a.getString(i))
                m[k] = set
            } catch (e: Exception) { }
        }
        return m
    }

    private fun startVisit() {
        val ap = getSharedPreferences("app", MODE_PRIVATE)
        prevVisit = ap.getLong("last_open", 0L)
        ap.edit().putLong("last_open", System.currentTimeMillis()).apply()
        sessionBase = loadBase()
        refresh()
    }

    private fun updateSince() {
        val known = sites.filter { !it.skip && it.fresh >= 0 }
        val total = known.sumOf { it.fresh }
        since.text = when {
            prevVisit == 0L -> "İlk giriş — yeni elan izləməsi başladı"
            known.isEmpty() -> "Son girişdən bəri: hesablanır…"
            else -> "Son girişdən bəri (" + SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(prevVisit)) + "): $total yeni elan"
        }
    }

    override fun onStart() {
        super.onStart()
        if (started && System.currentTimeMillis() - stopTime > 30 * 60 * 1000) startVisit()
        started = true
    }

    override fun onStop() {
        super.onStop()
        stopTime = System.currentTimeMillis()
    }

    private fun notifOn() = getSharedPreferences("app", MODE_PRIVATE).getBoolean("notif", true)

    private fun applyNotif() {
        bell.text = if (notifOn()) "🔔" else "🔕"
        val wm = WorkManager.getInstance(this)
        if (notifOn()) {
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            val cons = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
            wm.enqueueUniquePeriodicWork("check", ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequest.Builder(CheckWorker::class.java, 15, TimeUnit.MINUTES).setConstraints(cons).build())
            wm.enqueueUniqueWork("check_now", ExistingWorkPolicy.KEEP,
                OneTimeWorkRequest.Builder(CheckWorker::class.java).setConstraints(cons).build())
        } else {
            wm.cancelUniqueWork("check")
            wm.cancelUniqueWork("check_now")
        }
    }

    private fun toggleNotif() {
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("notif", !notifOn()).apply()
        applyNotif()
        android.widget.Toast.makeText(this, if (notifOn()) "Bildirişlər açıq" else "Bildirişlər bağlı", android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    private fun bg(color: String, r: Int) = GradientDrawable().apply {
        setColor(Color.parseColor(color)); cornerRadius = dp(r).toFloat(); setStroke(dp(1), Color.parseColor("#262626"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        sites = Store.load(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#000000"))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#000000"))
            setPadding(dp(16), dp(12), dp(8), dp(12))
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleBox.addView(TextView(this).apply {
            text = "Vakansiyalar"; textSize = 20f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        status = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#9CA3AF")) }
        titleBox.addView(status)
        since = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#60A5FA")) }
        titleBox.addView(since)
        top.addView(titleBox)
        top.addView(TextView(this).apply {
            text = "⟳"; textSize = 24f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { refresh() }
        })
        bell = TextView(this).apply {
            textSize = 22f; setTextColor(Color.WHITE)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { toggleNotif() }
        }
        top.addView(bell)
        top.addView(TextView(this).apply {
            text = "📎"; textSize = 22f; setTextColor(Color.WHITE)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { filesDialog() }
        })
        top.addView(TextView(this).apply {
            text = "＋"; textSize = 26f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(4), dp(14), dp(4))
            setOnClickListener { addDialog() }
        })
        root.addView(top)

        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        rv.setPadding(dp(10), dp(8), dp(10), dp(8))
        rv.clipToPadding = false
        adapter = Adapter()
        rv.adapter = adapter
        touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun isLongPressDragEnabled() = false
            override fun onMove(r: RecyclerView, a: RecyclerView.ViewHolder, b: RecyclerView.ViewHolder): Boolean {
                val from = a.adapterPosition; val to = b.adapterPosition
                if (from < 0 || to < 0) return false
                sites.add(to, sites.removeAt(from))
                adapter.notifyItemMoved(from, to)
                return true
            }
            override fun onSwiped(v: RecyclerView.ViewHolder, d: Int) {}
            override fun clearView(r: RecyclerView, v: RecyclerView.ViewHolder) {
                super.clearView(r, v)
                Store.save(this@MainActivity, sites)
            }
        })
        touch.attachToRecyclerView(rv)
        root.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        updateStatus("")
        applyNotif()
        startVisit()
    }

    override fun onResume() {
        super.onResume()
        // brauzerdə yadda saxlanan son ünvanları yenidən oxu
        val fresh = Store.load(this)
        for (s in sites) fresh.firstOrNull { it.url == s.url }?.let { s.last = it.last }
    }

    private fun updateStatus(t: String) {
        status.text = if (t.isEmpty()) "Basıb saxla: sil • ☰ ilə sürüşdür" else t
    }

    private fun refresh() {
        counter?.stop()
        sites.forEach { it.today = -1; it.yest = -1; it.fresh = -1; it.links = null }
        adapter.notifyDataSetChanged()
        updateSince()
        val snapshot = sites.filter { !it.skip }
        var doneCount = 0
        counter = Counter(this, snapshot, { i ->
            val s = snapshot[i]
            val key = "v_" + s.url
            val base = sessionBase[key]
            val cur = s.links
            if (cur != null && cur.size >= (if (Store.stajFilter(s.url)) 0 else 3)) {
                if (base != null) s.fresh = cur.count { it !in base }
                val merged = LinkedHashSet<String>(cur)
                if (base != null) merged.addAll(base)
                val arr = JSONArray()
                merged.take(1000).forEach { arr.put(it) }
                visitPrefs.edit().putString(key, arr.toString()).apply()
            }
            val pos = sites.indexOfFirst { it === s }
            if (pos >= 0) adapter.notifyItemChanged(pos)
            doneCount++
            updateStatus("Yoxlanıldı: $doneCount/${snapshot.size}")
            updateSince()
        }, {
            Store.save(this, sites)
            updateStatus("Say təxminidir • ⟳ ilə yenilə")
            updateSince()
        })
        counter!!.start()
    }

    private fun addDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val n = EditText(this).apply { hint = "Saytın adı" }
        val u = EditText(this).apply { hint = "Ünvan (https://...)"; setText("https://") }
        box.addView(n); box.addView(u)
        AlertDialog.Builder(this).setTitle("Yeni sayt").setView(box)
            .setPositiveButton("Əlavə et") { _, _ ->
                var url = u.text.toString().trim()
                if (url.isEmpty() || url == "https://") return@setPositiveButton
                if (!url.startsWith("http")) url = "https://$url"
                val name = n.text.toString().trim().ifEmpty { url.removePrefix("https://").removePrefix("http://").substringBefore("/") }
                sites.add(Site(name, url))
                Store.save(this, sites)
                adapter.notifyItemInserted(sites.size - 1)
            }.setNegativeButton("Ləğv et", null).show()
    }

    private fun editDialog(pos: Int) {
        val s = sites[pos]
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val n = EditText(this).apply { setText(s.name) }
        val u = EditText(this).apply { setText(s.url) }
        box.addView(n); box.addView(u)
        AlertDialog.Builder(this).setTitle("Redaktə").setView(box)
            .setPositiveButton("Yadda saxla") { _, _ ->
                s.name = n.text.toString().trim().ifEmpty { s.name }
                val nu = u.text.toString().trim()
                if (nu.isNotEmpty() && nu != s.url) { s.url = nu; s.last = ""; s.today = -1; s.yest = -1 }
                Store.save(this, sites)
                adapter.notifyItemChanged(pos)
            }.setNegativeButton("Ləğv et", null).show()
    }

    private fun menu(pos: Int) {
        AlertDialog.Builder(this).setTitle(sites[pos].name)
            .setItems(arrayOf("Sil", "Redaktə", if (sites[pos].skip) "Yoxlamanı yandır" else "Yoxlamanı söndür")) { _, w ->
                if (w == 0) {
                    AlertDialog.Builder(this).setMessage("\"${sites[pos].name}\" silinsin?")
                        .setPositiveButton("Sil") { _, _ ->
                            sites.removeAt(pos)
                            Store.save(this, sites)
                            adapter.notifyItemRemoved(pos)
                        }.setNegativeButton("Ləğv et", null).show()
                } else if (w == 1) editDialog(pos)
                else {
                    sites[pos].skip = !sites[pos].skip
                    Store.save(this, sites)
                    adapter.notifyItemChanged(pos)
                    updateSince()
                }
            }.show()
    }

    private fun open(pos: Int) {
        val s = sites[pos]
        startActivity(Intent(this, BrowserActivity::class.java)
            .putExtra("base", s.url)
            .putExtra("start", s.url)
            .putExtra("title", s.name))
    }

    override fun onDestroy() {
        counter?.stop()
        super.onDestroy()
    }

    inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        inner class VH(val row: LinearLayout, val handle: TextView, val icon: ImageView, val name: TextView, val cnt: TextView) : RecyclerView.ViewHolder(row)

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = bg("#0D0D0D", 12)
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(0, dp(4), 0, dp(4))
                }
            }
            val handle = TextView(this@MainActivity).apply {
                text = "☰"; textSize = 22f; setTextColor(Color.parseColor("#6B7280"))
                setPadding(dp(16), dp(18), dp(16), dp(18))
            }
            val icon = ImageView(this@MainActivity).apply {
                background = bg("#1A1A1A", 10)
                setPadding(dp(7), dp(7), dp(7), dp(7))
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(0, 0, dp(12), 0) }
            }
            val mid = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val name = TextView(this@MainActivity).apply {
                textSize = 17f; setTextColor(Color.parseColor("#F5F5F5")); setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
            val cnt = TextView(this@MainActivity).apply { textSize = 13f; setTextColor(Color.parseColor("#9CA3AF")) }
            mid.addView(name); mid.addView(cnt)
            val arrow = TextView(this@MainActivity).apply {
                text = "›"; textSize = 26f; setTextColor(Color.parseColor("#6B7280")); setPadding(dp(8), 0, dp(16), 0)
            }
            row.addView(handle); row.addView(icon); row.addView(mid); row.addView(arrow)
            return VH(row, handle, icon, name, cnt)
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onBindViewHolder(h: VH, i: Int) {
            val s = sites[i]
            h.name.text = s.name
            h.icon.setImageDrawable(null)
            h.icon.tag = s.url
            Icons.load(this@MainActivity, s.url) { bm ->
                if (bm != null && h.icon.tag == s.url) h.icon.setImageBitmap(bm)
            }
            if (s.skip) {
                h.cnt.text = "Yoxlanılmır"
                h.name.alpha = 0.5f
            } else {
                h.name.alpha = 1f
                val a = if (s.today < 0) "Bu gün: …" else "Bu gün: ${s.today}"
                val b = if (s.yest < 0) "Dünən: …" else "Dünən: ${s.yest}"
                val sp = android.text.SpannableStringBuilder()
                sp.append(a)
                sp.setSpan(android.text.style.ForegroundColorSpan(Color.parseColor("#34D399")), 0, a.length, 0)
                sp.append("  •  ")
                val st = sp.length
                sp.append(b)
                sp.setSpan(android.text.style.ForegroundColorSpan(Color.parseColor("#FBBF24")), st, sp.length, 0)
                if (s.fresh > 0) {
                    sp.append("  •  ")
                    val st2 = sp.length
                    sp.append("+${s.fresh} yeni")
                    sp.setSpan(android.text.style.ForegroundColorSpan(Color.parseColor("#60A5FA")), st2, sp.length, 0)
                }
                h.cnt.text = sp
            }
            h.handle.setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) touch.startDrag(h)
                false
            }
            h.row.setOnClickListener { val p = h.adapterPosition; if (p >= 0) open(p) }
            h.row.setOnLongClickListener { val p = h.adapterPosition; if (p >= 0) menu(p); true }
        }

        override fun getItemCount() = sites.size
    }
}
