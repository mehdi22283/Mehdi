package az.market.endirim

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/** WebView-dan JS ilə gələn (blob:) PDF-i hissə-hissə fayla yazır. */
class PdfBridge(private val tmp: File, private val onFinish: (Boolean) -> Unit) {
    private var out: FileOutputStream? = null

    @JavascriptInterface
    fun begin() {
        try { out?.close() } catch (e: Exception) {}
        out = try { FileOutputStream(tmp) } catch (e: Exception) { null }
    }

    @JavascriptInterface
    fun chunk(b64: String) {
        try { out?.write(Base64.decode(b64, Base64.DEFAULT)) } catch (e: Exception) {}
    }

    @JavascriptInterface
    fun end() {
        val ok = out != null
        try { out?.close() } catch (e: Exception) {}
        out = null
        onFinish(ok)
    }

    @JavascriptInterface
    fun fail() {
        try { out?.close() } catch (e: Exception) {}
        out = null
        onFinish(false)
    }
}

/**
 * Bravo: slayd (Publuu flipbook) WebView-da açılır. İstifadəçi slaydın içindəki "PDF yüklə" düyməsinə basanda
 * PDF tutulub tətbiqin yaddaşına yazılır və slaydın yerinə keçir. Endirim günü bitəndə (və ya yeni jurnal çıxanda)
 * PDF silinir, slayd yenidən WebView-da açılır.
 */
object BravoPdf {
    const val MARKET = "Bravo Market"
    const val LOCAL = "local:bravo.pdf"
    private const val TITLE = "Supermanat Hiper"

    /** Hər uğurlu yükləmədə dəyişir — MainActivity onResume-da bunu görüb siyahını yeniləyir. */
    @Volatile
    var stamp = 0L
        private set

    private val http = OkHttpClient()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("bravopdf", Context.MODE_PRIVATE)

    fun file(ctx: Context): File = Downloader.fileFor(ctx, LOCAL)

    fun isLocal(c: Catalog) = c.urls[0] == LOCAL

    private fun looksPdf(f: File): Boolean = try {
        f.inputStream().use { s ->
            val buf = ByteArray(1024)
            val n = s.read(buf)
            n > 4 && String(buf, 0, n, Charsets.ISO_8859_1).contains("%PDF")
        }
    } catch (e: Exception) {
        false
    }

    /** Yüklənmiş müvəqqəti fayl həqiqətən PDF-dirsə, köhnənin yerinə yazır. */
    @Synchronized
    private fun commit(ctx: Context, pageUrl: String, pageDate: String?, tmp: File): Boolean {
        if (!tmp.exists() || !looksPdf(tmp)) {
            tmp.delete()
            return false
        }
        val f = file(ctx)
        f.delete()
        if (!tmp.renameTo(f)) {
            tmp.delete()
            return false
        }
        // tarix: slaydın katalogundan, yoxsa slayd üçün əvvəl OCR ilə oxunmuş tarixdən
        val date = pageDate ?: ctx.getSharedPreferences("bravo", Context.MODE_PRIVATE).getString(pageUrl, null)?.ifEmpty { null }
        val e = prefs(ctx).edit().putString("web", pageUrl)
        if (date != null) e.putString("date", date) else e.remove("date")
        e.apply()
        Thumbs.file(ctx, LOCAL).delete()
        ctx.getSharedPreferences("ocr", Context.MODE_PRIVATE).edit().remove(f.name).apply()
        stamp = System.nanoTime()
        return true
    }

    /** PDF-dən OCR ilə oxunan tarixi yadda saxlayır (yükləyəndə tarix məlum olmayıbsa). */
    fun setDate(ctx: Context, date: String) {
        if (file(ctx).exists()) prefs(ctx).edit().putString("date", date).apply()
    }

    private fun clear(ctx: Context) {
        file(ctx).delete()
        File(file(ctx).path + ".part").delete()
        prefs(ctx).edit().clear().apply()
        Thumbs.file(ctx, LOCAL).delete()
        ctx.getSharedPreferences("ocr", Context.MODE_PRIVATE).edit().remove(file(ctx).name).apply()
    }

    /**
     * Bravo jurnal siyahısına PDF qaydasını tətbiq edir:
     *  - yüklənmiş PDF var, endirim bitməyib və jurnal eynidir → slaydın yerinə PDF;
     *  - endirim günü bitib → PDF silinir, slayd (WebView) qayıdır;
     *  - saytda yeni jurnal (yeni slayd linki) çıxıb → köhnə PDF silinir.
     */
    fun apply(ctx: Context, cats: List<Catalog>): List<Catalog> {
        val web = cats.firstOrNull { it.kind == Kind.WEB }
        val local = cats.firstOrNull { isLocal(it) }
        val p = prefs(ctx)
        val f = file(ctx)
        val savedUrl = p.getString("web", null)
        val savedDate = p.getString("date", null)
        val others = cats.filter { it !== web && it !== local }

        // PDF yoxdur (və ya silinib) — adi slayd
        if (!f.exists() || f.length() == 0L || savedUrl == null) {
            if (local == null) return cats
            clear(ctx)
            return listOfNotNull(web) + others
        }
        // sayta yeni jurnal çıxıb
        if (web != null && web.urls[0] != savedUrl) {
            clear(ctx)
            return listOf(web) + others
        }
        val date = savedDate ?: local?.date
        // endirim günü bitib — slayd yenidən WebView-da
        if (date != null && DateUtil.info(date).state == 4) {
            clear(ctx)
            val w = web?.let { if (it.date == null) it.copy(date = date) else it }
                ?: Catalog(MARKET, TITLE, date, Kind.WEB, listOf(savedUrl), "Veb-jurnal")
            return listOf(w) + others
        }
        val title = web?.title ?: local?.title ?: TITLE
        return listOf(Catalog(MARKET, title, date, Kind.PDF, listOf(LOCAL), "PDF")) + others
    }

    // ---------------- WebView-da PDF yükləməni tutmaq ----------------

    /**
     * Slayd WebView-sına qoşulur: "PDF yüklə" düyməsi nə ilə işləyirsə (birbaşa link, yeni pəncərə, fayl yükləmə,
     * blob:) PDF tutulur, yadda saxlanır və onDone(true) çağırılır.
     */
    @SuppressLint("SetJavaScriptEnabled")
    fun attach(web: WebView, pageUrl: String, pageDate: String?, scope: CoroutineScope, onDone: (Boolean) -> Unit) {
        val ctx = web.context.applicationContext
        val main = Handler(Looper.getMainLooper())
        val busy = AtomicBoolean(false)
        val ua = web.settings.userAgentString
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.setSupportMultipleWindows(true)
        web.settings.javaScriptCanOpenWindowsAutomatically = true

        fun toast(t: String) = main.post { Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show() }

        fun finish(ok: Boolean) {
            busy.set(false)
            main.post {
                Toast.makeText(
                    ctx,
                    if (ok) "Bravo PDF yadda saxlandı — slaydın yerinə keçdi" else "PDF yüklənmədi",
                    Toast.LENGTH_LONG
                ).show()
                onDone(ok)
            }
        }

        fun fromHttp(url: String) {
            if (!busy.compareAndSet(false, true)) return
            toast("PDF yüklənir…")
            val cookie = CookieManager.getInstance().getCookie(url)
            scope.launch(Dispatchers.IO) {
                val ok = try {
                    val req = Request.Builder().url(url)
                        .header("User-Agent", ua)
                        .header("Referer", pageUrl)
                        .apply { if (!cookie.isNullOrEmpty()) header("Cookie", cookie) }
                        .build()
                    val tmp = File(file(ctx).path + ".part")
                    http.newCall(req).execute().use { r ->
                        if (!r.isSuccessful) false
                        else {
                            FileOutputStream(tmp).use { o -> r.body!!.byteStream().copyTo(o) }
                            commit(ctx, pageUrl, pageDate, tmp)
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    false
                }
                finish(ok)
            }
        }

        // blob: linkləri yalnız səhifənin öz içində oxunur
        val tmpBlob = File(file(ctx).path + ".part")
        web.addJavascriptInterface(PdfBridge(tmpBlob) { ok ->
            finish(if (ok) commit(ctx, pageUrl, pageDate, tmpBlob) else false)
        }, "AndroidPdf")

        fun fromBlob(url: String) {
            if (!busy.compareAndSet(false, true)) return
            toast("PDF yüklənir…")
            val safe = url.replace("\\", "\\\\").replace("\"", "\\\"")
            val js = "(function(u){try{var x=new XMLHttpRequest();x.open('GET',u,true);x.responseType='blob';" +
                "x.onload=function(){var r=new FileReader();r.onloadend=function(){" +
                "var s=String(r.result||'');s=s.substring(s.indexOf(',')+1);AndroidPdf.begin();" +
                "var n=1048576;for(var k=0;k<s.length;k+=n){AndroidPdf.chunk(s.substring(k,k+n));}AndroidPdf.end();};" +
                "r.readAsDataURL(x.response);};x.onerror=function(){AndroidPdf.fail();};x.send();}" +
                "catch(e){AndroidPdf.fail();}})(\"" + safe + "\")"
            web.post { web.evaluateJavascript(js, null) }
        }

        /** PDF-ə bənzəyən linkdirsə özümüz yükləyirik (true), yoxsa səhifə adi davam edir (false). */
        fun handle(url: String): Boolean {
            if (url.startsWith("blob:")) {
                fromBlob(url)
                return true
            }
            if (!url.startsWith("http")) return false
            val path = url.substringBefore('?').substringBefore('#').lowercase()
            if (path.endsWith(".pdf") || path.contains("/download")) {
                fromHttp(url)
                return true
            }
            return false
        }

        web.setDownloadListener { url, _, _, _, _ ->
            if (url.startsWith("blob:")) fromBlob(url) else fromHttp(url)
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                handle(request.url.toString())
        }

        // düymə yeni pəncərə (target=_blank / window.open) açırsa — açılan ünvan tutulur
        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val popup = WebView(view.context)
                popup.settings.javaScriptEnabled = true
                popup.setDownloadListener { url, _, _, _, _ ->
                    if (url.startsWith("blob:")) fromBlob(url) else fromHttp(url)
                }
                popup.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                        handle(request.url.toString())
                        return true      // yeni pəncərədə heç nə açılmır
                    }

                    override fun onPageStarted(v: WebView, url: String, favicon: android.graphics.Bitmap?) {
                        if (handle(url)) v.stopLoading()
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = popup
                resultMsg.sendToTarget()
                main.postDelayed({ try { popup.destroy() } catch (e: Exception) {} }, 30_000)
                return true
            }
        }
    }
}
