package com.zengyazici

import android.media.AudioFormat
import android.media.AudioRecord
import android.os.ParcelFileDescriptor
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.system.exitProcess

/** Shizuku vasitəsilə shell UID ilə işləyir (CAPTURE_AUDIO_OUTPUT icazəsi var). */
class RecorderUserService : IRecorder.Stub() {

    companion object {
        const val RATE = 16000
        // 4 = VOICE_CALL, 5 = VOICE_DOWNLINK, 8 = REMOTE_SUBMIX, 7 = VOICE_COMMUNICATION, 1 = MIC
    }

    @Volatile private var running = false
    private var thread: Thread? = null

    private fun open(source: Int): AudioRecord? = try {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(source, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192) * 2)
        if (r.state == AudioRecord.STATE_INITIALIZED) r else { r.release(); null }
    } catch (t: Throwable) { null }

    override fun start(out: ParcelFileDescriptor): String {
        if (running) return "artıq yazır"
        // 1) VOICE_CALL: hər iki tərəf bir mənbədə
        var a = open(4)
        var b: AudioRecord? = null
        var mode = "VOICE_CALL"
        if (a == null) {
            // 2) Qarşı tərəf (sistem çıxışı) + mikrofon
            a = open(8)
            b = open(7) ?: open(1)
            mode = "SUBMIX+MIC"
            if (a == null) { a = b; b = null; mode = "yalnız mikrofon" }
        }
        if (a == null) { out.close(); return "XƏTA: heç bir audio mənbəyi açılmadı" }

        val src1 = a; val src2 = b
        val fos = FileOutputStream(out.fileDescriptor)
        val ch = fos.channel
        ch.position(0); ch.write(ByteBuffer.wrap(ByteArray(44))) // başlıq yeri
        running = true
        thread = Thread {
            val n = 1600
            val s1 = ShortArray(n); val s2 = ShortArray(n)
            val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
            var total = 0L
            try {
                src1.startRecording(); src2?.startRecording()
                while (running) {
                    val r1 = src1.read(s1, 0, n)
                    if (r1 <= 0) continue
                    if (src2 != null) {
                        val r2 = src2.read(s2, 0, r1)
                        for (i in 0 until r1) {
                            val v = s1[i] + (if (i < r2) s2[i].toInt() else 0)
                            s1[i] = v.coerceIn(-32768, 32767).toShort()
                        }
                    }
                    bb.clear()
                    for (i in 0 until r1) bb.putShort(s1[i])
                    bb.flip()
                    ch.write(bb)
                    total += r1 * 2
                }
            } catch (_: Throwable) {
            } finally {
                try { src1.stop(); src1.release() } catch (_: Throwable) {}
                try { src2?.stop(); src2?.release() } catch (_: Throwable) {}
                try {
                    val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                    h.put("RIFF".toByteArray()); h.putInt((36 + total).toInt())
                    h.put("WAVEfmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
                    h.putInt(RATE); h.putInt(RATE * 2); h.putShort(2); h.putShort(16)
                    h.put("data".toByteArray()); h.putInt(total.toInt())
                    h.flip(); ch.position(0); ch.write(h)
                    fos.close(); out.close()
                } catch (_: Throwable) {}
            }
        }.also { it.start() }
        return "OK:$mode"
    }

    override fun stop() {
        running = false
        thread?.join(2000)
        thread = null
    }

    override fun destroy() { stop(); exitProcess(0) }
}
