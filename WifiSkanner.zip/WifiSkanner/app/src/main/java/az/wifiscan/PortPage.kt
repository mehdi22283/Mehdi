package az.wifiscan

import android.view.View
import android.widget.*
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.ConcurrentSkipListSet
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

private val NAMES: Map<Int, String> = Net.PORTS + mapOf(
    25 to "SMTP", 110 to "POP3", 111 to "rpcbind", 143 to "IMAP", 993 to "IMAPS", 995 to "POP3S", 1433 to "MSSQL", 2049 to "NFS",
    3306 to "MySQL", 5432 to "PostgreSQL", 5353 to "mDNS", 6379 to "Redis", 8888 to "HTTP-alt", 9200 to "Elasticsearch", 27017 to "MongoDB"
)

private fun parsePorts(s: String): List<Int>? {
    val t = s.lowercase().trim()
    if (t.isEmpty() || t == "top") return Net.PORTS.keys.toList()
    if (t == "all") return (1..65535).toList()
    val out = LinkedHashSet<Int>()
    for (part in t.split(",", " ").filter { it.isNotBlank() }) {
        if (part.contains("-")) {
            val a = part.substringBefore("-").trim().toIntOrNull() ?: return null
            val b = part.substringAfter("-").trim().toIntOrNull() ?: return null
            if (a !in 1..65535 || b !in 1..65535 || a > b) return null
            for (x in a..b) out.add(x)
        } else {
            val x = part.toIntOrNull() ?: return null
            if (x !in 1..65535) return null
            out.add(x)
        }
    }
    return out.toList()
}

fun portPage(u: Ui): Page {
    val p = u.vbox()
    p.addView(u.tv("Port skanı", 22f, u.ACC, true))
    val host = u.edit("Host / IP", "192.168.1.1"); p.addView(host)
    val ports = u.edit("Portlar", "all"); p.addView(ports)
    p.addView(u.tv("top = məşhur portlar • all = 1-65535 • nümunə: 1-1024 və ya 22,80,8000-8100\nYalnız öz cihazlarınızı skan edin.", 11f, u.SUB))
    val pb = ProgressBar(u.act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
    val status = u.tv("", 13f)
    val out = LinearLayout(u.act).apply { orientation = LinearLayout.VERTICAL }
    val camBtn = u.btn("📹 Canlı bax (RTSP 554)") {}.apply { visibility = View.GONE }
    val running = AtomicBoolean(false)
    var pool: ExecutorService? = null
    lateinit var goBtn: Button

    fun finish() { running.set(false); goBtn.text = "▶ Skan et" }

    fun start() {
        if (running.get()) { running.set(false); pool?.shutdownNow(); return }
        val h = host.text.toString().trim(); if (h.isEmpty()) return
        val list = parsePorts(ports.text.toString()) ?: run { u.toast("Port formatı səhvdir"); return }
        running.set(true); goBtn.text = "⏹ Dayandır"; out.removeAllViews(); camBtn.visibility = View.GONE; pb.progress = 0
        status.text = "Həll edilir: $h …"
        Thread {
            val ip = try { InetAddress.getAllByName(h).firstOrNull { it is Inet4Address }?.hostAddress ?: h } catch (e: Exception) { null }
            if (ip == null) { u.post { status.text = "❌ Host tapılmadı: $h"; finish() }; return@Thread }
            val to = if (Net.isPrivate(ip)) 600 else 1500
            val open = ConcurrentSkipListSet<Int>()
            val ex = Executors.newFixedThreadPool(200); pool = ex
            val done = AtomicInteger(0); val total = list.size
            for (pt in list) ex.execute {
                if (running.get() && Net.open(ip, pt, to)) {
                    open.add(pt)
                    u.post { out.addView(u.tv("✅ $pt/tcp  ${NAMES[pt] ?: ""}", 13f, u.GRN, false, true)) }
                }
                val dn = done.incrementAndGet()
                if (dn % 40 == 0 || dn == total) u.post { pb.progress = dn * 100 / total; status.text = "$ip • $dn/$total • açıq: ${open.size}" }
            }
            ex.shutdown()
            try { ex.awaitTermination(40, TimeUnit.MINUTES) } catch (e: InterruptedException) {}
            val wasStopped = !running.get()

            val httpPorts = intArrayOf(80, 81, 8000, 8080, 8081, 8090, 5000)
            val info = LinkedHashMap<Int, String>()
            for (pt in open) {
                info[pt] = when {
                    pt == 21 || pt == 22 || pt == 23 || pt == 25 || pt == 110 || pt == 143 -> Net.banner(ip, pt)
                    pt in httpPorts -> Net.http(ip, pt)
                    else -> ""
                }
            }
            val dev = Store.devices[ip] ?: Device(ip)
            dev.ports.addAll(open)
            for ((pt, b) in info) {
                if (b.isNotEmpty() && (pt == 21 || pt == 22 || pt == 23)) dev.banners[pt] = b
                if (b.isNotEmpty() && pt in httpPorts && dev.http.isEmpty()) dev.http = b
            }
            Net.classify(dev)
            try { if (Net.isPrivate(ip)) VulnCheck.run(dev) else dev.vulns = VulnCheck.analyze(dev) } catch (e: Throwable) {}

            u.post {
                out.removeAllViews()
                out.addView(u.tv("Hədəf: $h ($ip)\n${open.size} açıq port • ${list.size} port yoxlanıldı${if (wasStopped) " (dayandırıldı)" else ""}", 13f, u.ACC, true))
                if (open.isEmpty()) out.addView(u.tv("Açıq port tapılmadı (və ya firewall bağlayır).", 13f, u.SUB))
                for (pt in open) {
                    val b = info[pt] ?: ""
                    out.addView(u.tv("✅ $pt/tcp  ${NAMES[pt] ?: "naməlum"}" + (if (b.isNotEmpty()) "\n      $b" else ""), 13f, u.TXT, false, true).apply { setPadding(0, u.dp(3), 0, u.dp(3)) })
                }
                val vs = dev.vulns
                out.addView(u.tv(if (vs.isEmpty()) "\n✅ Xəbərdarlıq tapılmadı" else "\n⚠ Təhlükəsizlik xəbərdarlıqları (${vs.size})", 14f, if (vs.isEmpty()) u.GRN else u.ORG, true))
                vs.forEach { out.addView(u.vulnView(it)) }
                if (554 in open) {
                    camBtn.visibility = View.VISIBLE
                    camBtn.setOnClickListener { u.openCamera(ip, "${dev.vendor} ${dev.model}".trim()) }
                }
                status.text = "Bitdi • açıq: ${open.size}"
                pb.progress = 100
                finish()
            }
        }.start()
    }

    goBtn = u.btn("▶ Skan et") { start() }
    p.addView(goBtn); p.addView(pb); p.addView(status); p.addView(camBtn)
    p.addView(ScrollView(u.act).apply { addView(out) }, LinearLayout.LayoutParams(-1, 0, 1f))
    return Page(p, open = { h -> host.setText(h); if (!running.get()) start() })
}
