package az.mehdi.callrec

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class SetupActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_setup)
        findViewById<TextView>(R.id.steps).text =
            "Kompüter lazım deyil. Telefon Wi-Fi-a qoşulu olmalıdır (Android 11+).\n\n" +
            "1) Developer options → Wireless debugging aç.\n" +
            "2) '2' düyməsinə bas, bildiriş çıxacaq.\n" +
            "3) Wireless debugging → 'Pair device with pairing code' aç. Kod görünən zaman bildiriş panelini aşağı çək, kodu yaz və göndər.\n" +
            "   (Ekranı bölmüsənsə, kodu aşağıdakı xanaya da yaza bilərsən.)\n" +
            "4) Aşağıda ✅ görünənə qədər gözlə."
        val log = findViewById<TextView>(R.id.log)
        AdbSetup.ui = { m -> runOnUiThread { log.text = m } }
        findViewById<Button>(R.id.dev).setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        }
        findViewById<Button>(R.id.notif).setOnClickListener {
            AdbSetup.codeNotification(this)
            Toast.makeText(this, "Bildiriş göndərildi", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.pair).setOnClickListener {
            val code = findViewById<EditText>(R.id.code).text.toString().trim()
            if (code.length == 6) AdbSetup.run(this, code)
            else Toast.makeText(this, "6 rəqəmli kodu yaz", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.bat).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")))
            } catch (e: Exception) { }
        }
        findViewById<Button>(R.id.acc).setOnClickListener {
            if (AdbSetup.enableAccessibility(this)) {
                Toast.makeText(this, "Aktiv edildi ✅", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Əvvəl cütləşdirmə et (1–3)", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }

    override fun onDestroy() { AdbSetup.ui = null; super.onDestroy() }
}
