package az.m3u.sinayici

import android.os.Build
import android.webkit.CookieManager
import android.webkit.WebView

/**
 * Bütün WebView-lar (əsas ekran, Ottplayer, GitHub, mini brauzer) eyni cookie/localStorage anbarını bölüşür.
 * Girişlər (cookie) və saytların yadda saxladığı dəyişikliklər tətbiq bağlansa belə qalsın deyə:
 *  - cookie və DOM-storage həmişə açıqdır, üçüncü tərəf cookie-lərinə də icazə verilir;
 *  - müddətsiz (sessiya) cookie-lər 1 il müddətli edilir;
 *  - cookie-lər diskə mütəmadi yazılır (flush).
 */
object WebPersist {
    fun setup(w: WebView) {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        try { cm.setAcceptThirdPartyCookies(w, true) } catch (e: Exception) { }
        w.settings.domStorageEnabled = true
        @Suppress("DEPRECATION")
        try { w.settings.databaseEnabled = true } catch (e: Exception) { }
        @Suppress("DEPRECATION")
        try { w.settings.saveFormData = true } catch (e: Exception) { }
        w.settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
    }

    /** Səhifə yüklənəndə: bu saytın sessiya cookie-lərini 1 illik edir ki, giriş tətbiq yenidən açılanda itməsin. */
    fun keep(url: String?) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return
        try {
            val cm = CookieManager.getInstance()
            val raw = cm.getCookie(url)
            if (!raw.isNullOrEmpty()) {
                val secure = if (url.startsWith("https://")) "; Secure" else ""
                raw.split(";").map { it.trim() }.filter { it.contains("=") }.forEach { c ->
                    cm.setCookie(url, "$c; Max-Age=31536000; Path=/$secure")
                }
            }
            flush()
        } catch (e: Exception) { }
    }

    fun flush() {
        try { if (Build.VERSION.SDK_INT >= 21) CookieManager.getInstance().flush() } catch (e: Exception) { }
    }
}
