package com.example.xiaomibattery

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var big: TextView
    private lateinit var bar: ProgressBar
    private var maxT = -100f
    private var minT = 100f
    private val h = Handler(Looper.getMainLooper())
    private val bases = listOf("/sys/class/power_supply/battery/", "/sys/class/power_supply/bms/")
    private val tick = object : Runnable {
        override fun run() { registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { update(it) }; h.postDelayed(this, 2000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((16*dp).toInt(), (40*dp).toInt(), (16*dp).toInt(), (16*dp).toInt()); setBackgroundColor(Color.parseColor("#121212")) }
        big = TextView(this).apply { textSize = 56f; setTextColor(Color.parseColor("#FF6900")); gravity = Gravity.CENTER }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        info = TextView(this).apply { textSize = 16f; setTextColor(Color.WHITE); setLineSpacing(8f, 1f); setPadding(0, (16*dp).toInt(), 0, (16*dp).toInt()) }
        root.addView(big); root.addView(bar)
        root.addView(ScrollView(this).apply { addView(info) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(btn("🔋 Batareya qənaəti (Xiaomi)") { open("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity") })
        root.addView(btn("🚀 Avtomatik başlama (Autostart)") { open("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity") })
        root.addView(btn("⚙️ Batareya optimallaşdırması") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        root.addView(btn("📊 Sistem batareya istifadəsi") { startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) })
        root.addView(btn("⚡ Şarj sürəti testi") { startTest() })
        val ab = btn("") { }
        fun refreshAb() { ab.text = if (getSharedPreferences("bat", MODE_PRIVATE).getBoolean("alarm", false)) "🔔 100%-də zəng: AÇIQ" else "🔕 100%-də zəng: SÖNÜLÜ" }
        ab.setOnClickListener { toggleAlarm(); refreshAb() }
        refreshAb(); root.addView(ab)
        setContentView(root)
        if (getSharedPreferences("bat", MODE_PRIVATE).getBoolean("alarm", false)) startAlarm()
    }

    private fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }

    private fun open(p: String, cl: String) {
        try { startActivity(Intent().setComponent(ComponentName(p, cl))) } catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) } catch (_: Exception) { Toast.makeText(this, "Səhifə tapılmadı", Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun startTest() {
        val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        if ((registerReceiver(null, f)?.getIntExtra("plugged", 0) ?: 0) == 0) {
            Toast.makeText(this, "Əvvəlcə şarj cihazını qoşun", Toast.LENGTH_LONG).show(); return
        }
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val tv = TextView(this).apply { setPadding(48, 32, 48, 32); textSize = 16f }
        val dlg = AlertDialog.Builder(this).setTitle("⚡ Şarj sürəti testi").setView(tv).setNegativeButton("Bağla", null).create()
        dlg.show()
        val ws = ArrayList<Double>(); val mas = ArrayList<Double>(); val total = 20
        val r = object : Runnable {
            override fun run() {
                if (!dlg.isShowing) return
                val i = registerReceiver(null, f)
                val cur = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW).toDouble()
                val ma = abs(if (abs(cur) > 20000) cur / 1000 else cur)
                val w = ma * (i?.getIntExtra("voltage", 0) ?: 0) / 1_000_000.0
                mas.add(ma); ws.add(w)
                if (ws.size < total) {
                    tv.text = "Test gedir... ${ws.size}/$total san\nİndi: ${ma.toInt()} mA • ${"%.1f".format(w)} W\n\nTelefonu işlətməyin, ekranı söndürmək daha dəqiq nəticə verir."
                    h.postDelayed(this, 1000)
                } else {
                    val avg = ws.average(); val peak = ws.max()
                    val cls = when {
                        avg < 1 -> "Şarj olmur (batareya dolu ola bilər)"
                        avg < 5 -> "Çox yavaş 🐢 (zəif adapter/kabel)"
                        avg < 10 -> "Normal"
                        avg < 20 -> "Sürətli ⚡"
                        avg < 35 -> "Çox sürətli ⚡⚡"
                        else -> "Turbo ⚡⚡⚡"
                    }
                    tv.text = "Orta güc: ${"%.1f".format(avg)} W\nMaksimum güc: ${"%.1f".format(peak)} W\nOrta cərəyan: ${mas.average().toInt()} mA\n\nNəticə: $cls\n\nQeyd: bu, batareyaya çatan gücdür; adapterin yazılı gücündən 10-20% az olması normaldır. Batareya dolduqca sürət azalır."
                }
            }
        }
        h.post(r)
    }

    private fun startAlarm() {
        val s = Intent(this, AlarmService::class.java)
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(s) else startService(s) } catch (_: Exception) {}
    }
    private fun toggleAlarm() {
        val p = getSharedPreferences("bat", MODE_PRIVATE)
        val on = !p.getBoolean("alarm", false)
        p.edit().putBoolean("alarm", on).apply()
        if (on) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
            startAlarm()
            Toast.makeText(this, "Batareya 100% olanda zəng çalacaq", Toast.LENGTH_LONG).show()
        } else stopService(Intent(this, AlarmService::class.java))
    }

    private fun rdPath(p: String): String? = try { File(p).readText().trim().takeIf { it.isNotEmpty() } } catch (_: Exception) { null }

    private fun forecast(health: Double?, est: Boolean, cycles: Int?, firstSec: Long): String {
        if (health == null) return "Məlumat yoxdur"
        if (health <= 80) return "Tutum 80%-dən aşağıdır — dəyişdirməyi düşünün"
        val prefs = getSharedPreferences("bat", MODE_PRIVATE)
        val day = System.currentTimeMillis() / 86400000
        val pts = (prefs.getString("hs", "") ?: "").split(";").filter { it.contains(":") }
            .map { val (d, v) = it.split(":"); d.toLong() to v.toDouble() }.toMutableList()
        if (!est && pts.none { it.first == day }) {
            pts.add(day to health)
            prefs.edit().putString("hs", pts.takeLast(400).joinToString(";") { "${it.first}:" + String.format(Locale.US, "%.2f", it.second) }).apply()
        }
        val span = if (pts.size > 1) pts.last().first - pts.first().first else 0L
        if (pts.size >= 3 && span >= 14) {
            val mx = pts.map { it.first.toDouble() }.average(); val my = pts.map { it.second }.average()
            var sxx = 0.0; var sxy = 0.0
            for (q in pts) { sxx += (q.first - mx) * (q.first - mx); sxy += (q.first - mx) * (q.second - my) }
            val slope = sxy / sxx
            return if (slope > -0.002) "Tutum sabit görünür (izləmə: $span gün)"
            else "~${((health - 80) / -slope / 30.4).toInt()} ay (80%-ə qədər, izləmə: $span gün)"
        }
        if (cycles != null && cycles > 0) {
            val left = 500 - cycles
            if (left <= 0) return "Dövr sayı 500-ü keçib — tutum azala bilər"
            val age = if (firstSec > 0) (System.currentTimeMillis() / 1000 - firstSec) / 86400.0 else 0.0
            return if (age >= 30) "~${(left / (cycles / age) / 30.4).toInt()} ay (dövrlərə görə, təxmini)"
            else "~$left dövr qalıb (500 dövrdə 80% qəbul edilir)"
        }
        return "Məlumat toplanır — tətbiqi hər gün açın (14 gündən sonra dəqiqləşir)"
    }

    // ---------- köməkçi funksiyalar ----------
    private fun sys(name: String): String? {
        for (b in bases) try { val s = File(b + name).readText().trim(); if (s.isNotEmpty()) return s } catch (_: Exception) {}
        return null
    }
    private fun mah(v: Double) = if (v > 20000) v / 1000.0 else v
    private fun date(sec: Long): String? {
        val now = System.currentTimeMillis() / 1000
        return if (sec in 946684800..now) SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(sec * 1000)) else null
    }
    private fun designFromProfile(): Double? = try {
        val c = Class.forName("com.android.internal.os.PowerProfile")
        (c.getMethod("getBatteryCapacity").invoke(c.getConstructor(Context::class.java).newInstance(this)) as Double).takeIf { it > 0 }
    } catch (_: Throwable) { null }

    private fun phoneFirstUse(): String? = try {
        packageManager.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
            .minOfOrNull { packageManager.getPackageInfo(it.packageName, 0).firstInstallTime }
            ?.let { date(it / 1000) }
    } catch (_: Throwable) { null }

    private fun update(i: Intent) {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val pct = i.getIntExtra("level", 0) * 100 / i.getIntExtra("scale", 100)
        val status = when (i.getIntExtra("status", 0)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Şarj olur ⚡"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Boşalır"
            BatteryManager.BATTERY_STATUS_FULL -> "Dolu ✅"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Şarj olmur"
            else -> "Naməlum" }
        val plug = when (i.getIntExtra("plugged", 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Adapter (AC)"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Simsiz"
            0 -> "Qoşulmayıb"
            else -> "Digər" }
        val health = when (i.getIntExtra("health", 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Yaxşı"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Həddən artıq isti 🔥"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Ölü"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Yüksək gərginlik"
            BatteryManager.BATTERY_HEALTH_COLD -> "Soyuq ❄️"
            else -> "Naməlum" }
        val temp = i.getIntExtra("temperature", 0) / 10f
        if (temp > maxT) maxT = temp; if (temp < minT) minT = temp
        val mv = i.getIntExtra("voltage", 0)
        val cycles = i.getIntExtra("android.os.extra.CYCLE_COUNT", -1).takeIf { it >= 0 } ?: sys("cycle_count")?.toIntOrNull()
        val cur = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW).toDouble()
        val ma = if (abs(cur) > 20000) cur / 1000 else cur
        val watt = abs(ma) * mv / 1_000_000.0

        // --- real tutum və real faiz ---
        val cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER).toDouble()
        val nowMah = if (cc > 0) mah(cc) else null
        val sysDesign = sys("charge_full_design")?.toDoubleOrNull()?.let { mah(it) }
        val profDesign = designFromProfile()
        val design = sysDesign ?: profDesign
        var estFull = false
        var full: Double? = sys("charge_full")?.toDoubleOrNull()?.let { mah(it) }
        if (full == null && Build.VERSION.SDK_INT >= 34 && design != null) {
            val soh = try { bm.getIntProperty(10) } catch (_: Throwable) { -1 }
            if (soh in 1..100) full = design * soh / 100
        }
        if (full == null && nowMah != null && pct > 0) { full = nowMah * 100 / pct; estFull = true }
        val realPct = if (nowMah != null && full != null && full > 0) nowMah * 100 / full else null
        val healthPct = if (full != null && design != null && design > 0) full * 100 / design else null

        // --- tarixlər ---
        var bFirst: String? = null; var bMade: String? = null; var bFirstSec = 0L
        if (Build.VERSION.SDK_INT >= 34) try {
            bFirstSec = bm.getLongProperty(12); bFirst = date(bFirstSec)
            bMade = date(bm.getLongProperty(11))
        } catch (_: Throwable) {}

        // --- orijinallıq ---
        val auth = (sys("authentic") ?: sys("battery_authentic"))?.toIntOrNull()
        val original = when {
            auth == 1 -> "Orijinal ✅"
            auth == 0 -> "Orijinal DEYİL ⚠️"
            sysDesign != null && profDesign != null && abs(sysDesign - profDesign) / profDesign > 0.15 ->
                "Şübhəli ⚠️ (tutum sistem məlumatı ilə uyğun gəlmir)"
            else -> "Yoxlanıla bilmədi (bu model məlumat vermir)" }

        val rtp = rdPath("/sys/class/power_supply/usb/real_type")
        val src = when (rtp) {
            "USB_PD", "USB_PD_DRP" -> "USB Power Delivery (PD)"
            "USB_HVDCP" -> "Quick Charge 2.0"
            "USB_HVDCP_3" -> "Quick Charge 3.0"
            "USB_HVDCP_3P5" -> "Quick Charge 3+"
            "USB_DCP" -> "Adi adapter (DCP)"
            "USB_CDP" -> "USB CDP"
            "USB" -> "Kompüter USB"
            else -> rtp }
        val ctRaw = sys("charge_type")
        val ct = when (ctRaw) {
            "Fast" -> "Sürətli"; "Trickle" -> "Damcı (dolmağa yaxın)"; "Standard", "Normal" -> "Standart"
            "Taper" -> "Azalan (dolmağa yaxın)"; else -> ctRaw }
        val speed = when { watt < 5 -> "yavaş"; watt < 10 -> "adi"; watt < 20 -> "sürətli"; watt < 35 -> "çox sürətli"; else -> "turbo" }
        val chargeType = when {
            plug == "Qoşulmayıb" || status.startsWith("Boşalır") -> "Şarj olmur"
            status.startsWith("Dolu") -> "Batareya dolu"
            else -> listOfNotNull(src, ct?.let { "rejim: $it" }, "$speed (${"%.1f".format(watt)} W)").joinToString(" • ") }
        val life = forecast(healthPct, estFull, cycles, bFirstSec)

        big.text = "$pct%"; bar.progress = pct
        info.text = buildString {
            appendLine("📱 ${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE}\n")
            appendLine("Vəziyyət: $status")
            appendLine("Mənbə: $plug")
            appendLine("Şarj növü: $chargeType")
            appendLine("Sağlamlıq (sistem): $health")
            appendLine("Temperatur: $temp °C (min ${"%.1f".format(minT)} / max ${"%.1f".format(maxT)})")
            appendLine("Gərginlik: $mv mV")
            appendLine("Cərəyan: ${"%.0f".format(ma)} mA • Güc: ${"%.2f".format(watt)} W")
            appendLine("\n— REAL MƏLUMATLAR —")
            appendLine("Real batareya faizi: ${realPct?.let { "%.1f".format(it) + "%" } ?: "-"}  (sistemdə: $pct%)")
            appendLine("Real tutum: ${full?.let { "%.0f mAh".format(it) } ?: "-"} / dizayn: ${design?.let { "%.0f mAh".format(it) } ?: "-"}")
            appendLine("Real tutum faizi: ${healthPct?.let { "%.1f".format(it) + "%" } ?: "-"}")
            appendLine("Qalan yük: ${nowMah?.let { "%.0f mAh".format(it) } ?: "-"}")
            appendLine("Şarj dövrü: ${cycles ?: "-"}")
            appendLine("Batareya ömrü proqnozu: $life")
            appendLine("\n— TARİXLƏR —")
            appendLine("Batareya ilk istifadə: ${bFirst ?: "Android verməyir (Android 14+ lazımdır)"}")
            appendLine("Batareya istehsal tarixi: ${bMade ?: "-"}")
            appendLine("Telefon ilk istifadə (təxmini): ${phoneFirstUse() ?: "-"}")
            appendLine("\n— ORİJİNALLIQ —")
            appendLine(original)
            appendLine("\nQeyd: bəzi dəyərlər Xiaomi modelindən və Android versiyasından asılıdır; oxuna bilməyənlər \"-\" göstərilir.")
        }
    }
}
