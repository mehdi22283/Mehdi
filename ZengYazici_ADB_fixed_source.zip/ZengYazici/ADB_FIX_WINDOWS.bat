@echo off
setlocal
adb get-state >nul 2>&1
if errorlevel 1 (
  echo Telefon ADB ile gorunmur. USB debugging-i acin ve icazeni tesdiq edin.
  pause
  exit /b 1
)
echo Zeng Yazici icazeleri verilir...
adb shell pm grant com.zengyazici android.permission.RECORD_AUDIO
adb shell pm grant com.zengyazici android.permission.READ_PHONE_STATE
adb shell pm grant com.zengyazici android.permission.READ_CALL_LOG
adb shell pm grant com.zengyazici android.permission.POST_NOTIFICATIONS 2>nul
adb shell appops set com.zengyazici RECORD_AUDIO allow
adb shell appops set com.zengyazici SYSTEM_ALERT_WINDOW allow
adb shell appops set com.zengyazici RUN_IN_BACKGROUND allow
adb shell appops set com.zengyazici RUN_ANY_IN_BACKGROUND allow
adb shell dumpsys deviceidle whitelist +com.zengyazici
adb shell cmd notification allow_listener com.zengyazici/com.zengyazici.WaListener
adb shell am force-stop com.zengyazici
adb shell monkey -p com.zengyazici 1
echo.
echo Bitdi. WhatsApp-da test zengi edin ve proqramin Menyu -^> Log bolmesine baxin.
pause
