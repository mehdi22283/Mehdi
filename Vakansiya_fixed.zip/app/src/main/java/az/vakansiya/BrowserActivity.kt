package az.vakansiya

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

class BrowserActivity : AppCompatActivity() {
    private lateinit var wv: WebView
    private lateinit var base: String
    private var cssDark = false
    private var pending: ValueCallback<Array<Uri>>? = null

    // sistem fayl seçicisi (telefondan birdəfəlik seçim)
    private val sysPick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = pending; pending = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
    }

    private fun systemPicker(p: WebChromeClient.FileChooserParams) {
        try { sysPick.launch(p.createIntent()) }
        catch (e: Exception) { pending?.onReceiveValue(null); pending = null }
    }

    /** Sayt fayl istəyəndə: əvvəlcə tətbiqə əlavə edilmiş fayllar göstərilir. */
    private fun chooseFile(cb: ValueCallback<Array<Uri>>, p: WebChromeClient.FileChooserParams) {
        pending?.onReceiveValue(null)
        pending = cb
        val all = Files.list(this)
        if (all.isEmpty()) {
            android.widget.Toast.makeText(this, "Tətbiqdə saxlanmış fayl yoxdur (əsas səhifədə 📎)", android.widget.Toast.LENGTH_LONG).show()
            systemPicker(p); return
        }
        val ok = all.filter { Files.matches(it, p.acceptTypes) }
        val list = if (ok.isEmpty()) all else ok
        val names = list.map { it.name + "  (" + Files.size(it) + ")" }.toTypedArray()
        fun deliver(files: List<java.io.File>) {
            val c = pending; pending = null
            c?.onReceiveValue(if (files.isEmpty()) null else files.map { Files.uri(this, it) }.toTypedArray())
        }
        val b = AlertDialog.Builder(this).setTitle("Yüklənəcək fayl")
        if (p.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
            val chk = BooleanArray(list.size)
            b.setMultiChoiceItems(names, chk) { _, i, v -> chk[i] = v }
            b.setPositiveButton("Seç") { _, _ -> deliver(list.filterIndexed { i, _ -> chk[i] }) }
        } else {
            b.setItems(names) { _, i -> deliver(listOf(list[i])) }
        }
        b.setNeutralButton("Telefondan seç") { _, _ -> systemPicker(p) }
        b.setNegativeButton("Ləğv et") { _, _ -> deliver(emptyList()) }
        b.setOnCancelListener { deliver(emptyList()) }
        b.show()
    }

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    /** Gmail-də həmin ünvana yeni məktub yazma ekranını açır; Gmail yoxdursa, başqa mail proqramı. */
    private fun composeGmail(addr: String) {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(addr)))
        try {
            startActivity(Intent(i).setPackage("com.google.android.gm"))
        } catch (e: Exception) {
            try { startActivity(i) }
            catch (e2: Exception) {
                android.widget.Toast.makeText(this, "Mail proqramı tapılmadı", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun btn(t: String, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setOnClickListener { click() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        base = intent.getStringExtra("base") ?: ""
        val start = intent.getStringExtra("start") ?: base
        val title = intent.getStringExtra("title") ?: ""

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#000000"))
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(btn("◀") { if (wv.canGoBack()) wv.goBack() })
        bar.addView(btn("🏠") { wv.loadUrl(base) })
        bar.addView(btn("⟳") { wv.reload() })
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleBox.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 15f; maxLines = 1
            gravity = Gravity.CENTER
        })
        val mailPrefs = getSharedPreferences("app", MODE_PRIVATE)
        val mailRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val mailBox = android.widget.EditText(this).apply {
            hint = "mail ünvanı"; textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.ITALIC)
            setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#6B7280"))
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#374151"))
            setText(mailPrefs.getString("mailTo", ""))
            setPadding(dp(4), dp(2), dp(4), dp(2))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val send = TextView(this).apply {
            text = "✉"; textSize = 18f; setTextColor(Color.parseColor("#60A5FA"))
            setPadding(dp(10), dp(2), dp(4), dp(2))
        }
        fun go() {
            val a = mailBox.text.toString().trim()
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(a).matches()) {
                android.widget.Toast.makeText(this, "Düzgün mail ünvanı yazın", android.widget.Toast.LENGTH_SHORT).show()
                return
            }
            mailPrefs.edit().putString("mailTo", a).apply()
            composeGmail(a)
        }
        send.setOnClickListener { go() }
        mailBox.setOnEditorActionListener { _, _, _ -> go(); true }
        mailRow.addView(mailBox); mailRow.addView(send)
        titleBox.addView(mailRow)
        bar.addView(titleBox)
        bar.addView(btn("✕") { finish() })
        root.addView(bar)

        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#60A5FA"))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3))
        }
        root.addView(pb)

        wv = WebView(this)
        wv.setBackgroundColor(Color.BLACK)
        root.addView(wv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(wv.settings, true)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            @Suppress("DEPRECATION")
            WebSettingsCompat.setForceDark(wv.settings, WebSettingsCompat.FORCE_DARK_ON)
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK_STRATEGY)) {
                @Suppress("DEPRECATION")
                WebSettingsCompat.setForceDarkStrategy(wv.settings, WebSettingsCompat.DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING)
            }
        } else cssDark = true
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: android.webkit.WebResourceRequest): Boolean {
                val u = r.url.toString()
                if (u.startsWith("http://") || u.startsWith("https://")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { }
                return true
            }
            override fun onPageStarted(v: WebView, u: String, f: android.graphics.Bitmap?) { pb.visibility = View.VISIBLE }
            override fun onPageFinished(v: WebView, u: String) {
                pb.visibility = View.GONE
                if (cssDark) v.evaluateJavascript("(function(){if(document.getElementById('__dk'))return;var s=document.createElement('style');s.id='__dk';s.textContent='html{background:#fff;filter:invert(1) hue-rotate(180deg)}img,video,picture,canvas,svg image{filter:invert(1) hue-rotate(180deg)}';document.head.appendChild(s)})()", null)
                Store.setLast(this@BrowserActivity, base, u)
                CookieManager.getInstance().flush()
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { pb.progress = p }
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: WebChromeClient.FileChooserParams): Boolean {
                chooseFile(cb, p); return true
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (wv.canGoBack()) wv.goBack() else finish() }
        })
        wv.loadUrl(start)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        pending?.onReceiveValue(null); pending = null
        wv.destroy()
        super.onDestroy()
    }
}
