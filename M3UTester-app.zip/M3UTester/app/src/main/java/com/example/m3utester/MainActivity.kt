package com.example.m3utester

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private var list = mutableListOf<Ch>()
    private lateinit var status: TextView
    private lateinit var adapter: BaseAdapter

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val text = contentResolver.openInputStream(uri)!!.bufferedReader().readText()
        val prev = list.associate { it.url to it.ok }
        list = parseM3u(text).onEach { it.ok = prev[it.url] }
        Store.save(this, list)
        adapter.notifyDataSetChanged()
        runTest()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33)
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.POST_NOTIFICATIONS)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        val ott = Button(this).apply {
            text = "OTT Player-ə daxil ol"
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://ottplayer.es"))) }
        }
        val load = Button(this).apply { text = "M3U faylı yüklə"; setOnClickListener { picker.launch(arrayOf("*/*")) } }
        status = TextView(this).apply { setPadding(0, 12, 0, 12) }
        val lv = ListView(this)
        val hist = Button(this).apply {
            text = "Tarixçə"
            setOnClickListener { startActivity(Intent(this@MainActivity, HistoryActivity::class.java)) }
        }
        root.addView(ott); root.addView(load); root.addView(hist); root.addView(status); root.addView(lv)
        setContentView(root)

        list = Store.load(this)
        adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(i: Int) = list[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val c = list[i]
                val icon = when (c.ok) { true -> "🟢"; false -> "🔴"; null -> "⏳" }
                return (v as? TextView ?: TextView(this@MainActivity).apply { textSize = 16f; setPadding(8, 20, 8, 20) })
                    .also { it.text = "$icon  ${c.name}" }
            }
        }
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, i, _ ->
            startActivity(Intent(this, PlayerActivity::class.java)
                .putExtra("n", list[i].name).putExtra("u", list[i].url))
        }
        updateStatus()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "check", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<CheckWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())
    }

    private fun runTest() = lifecycleScope.launch {
        val old = list.map { it.ok }
        list.forEach { it.ok = null }
        testAll(list) { adapter.notifyDataSetChanged(); updateStatus() }
        History.add(this@MainActivity, diff(old, list))
        Store.save(this@MainActivity, list)
        updateStatus()
    }

    private fun updateStatus() {
        status.text = "🟢 ${list.count { it.ok == true }}   🔴 ${list.count { it.ok == false }}   ⏳ ${list.count { it.ok == null }}"
    }
}
