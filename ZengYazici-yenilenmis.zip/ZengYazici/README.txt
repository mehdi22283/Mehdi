ZƏNG YAZICI

Yenilənmiş interfeys:
- Qaranlıq tema və yenilənmiş dizayn.
- Əsas pəncərədə vahid “Başlat / Quraşdır” düyməsi.
- Əlavə parametrlər bir “Quraşdırma və əlavə seçimlər” menyusunda toplanıb.
- Zəng tarixçəsində Bütün, Gələn və Gedən filtrləri.
- Hər yazının tarix və saatı tam göstərilir.

İLK QURAŞDIRMA
1) “Başlat / Quraşdır” düyməsini basıb telefon icazələrini verin.
2) Wireless debugging-i aktiv edin və menyudan “Wireless debugging ilə cütləşdir” seçin. Pairing kodunu tətbiqin bildirişindən daxil edin.
3) “Quraşdırma və əlavə seçimlər” menyusundan WhatsApp bildiriş girişini aktiv edin.
4) Xiaomi/HyperOS cihazlarında avtomatik başlatma icazəsini də aktiv edin.
5) Sınaq yazısı ilə yoxlayın.

Quraşdırma tamamlandıqdan və Android icazələri verildikdən sonra adi telefon zənglərində yazı prosesi zəng başlayanda avtomatik başlamağa çalışır. Yazıcı prosesinin ilk işə salınması üçün Wireless debugging cütləşməsi tələb olunur. Android versiyası, istehsalçı məhdudiyyətləri və zəng səs marşrutlaşdırması nəticəyə təsir edə bilər.

Yazılar WAV formatında /sdcard/Android/media/az.zeng.yazici/ qovluğunda saxlanılır. Yazını silmək üçün siyahı elementinə uzun basın.
