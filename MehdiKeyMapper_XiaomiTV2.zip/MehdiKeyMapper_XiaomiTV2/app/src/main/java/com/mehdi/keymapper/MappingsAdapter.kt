package com.mehdi.keymapper

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MappingsAdapter(
    private var items: List<KeyMapping>,
    private val onEditClick: (KeyMapping) -> Unit,
    private val onDeleteClick: (KeyMapping) -> Unit
) : RecyclerView.Adapter<MappingsAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvLabel: TextView = view.findViewById(R.id.tvItemLabel)
        val tvDetails: TextView = view.findViewById(R.id.tvItemDetails)
        val btnEdit: Button = view.findViewById(R.id.btnEditItem)
        val btnDelete: Button = view.findViewById(R.id.btnDeleteItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_mapping, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvLabel.text = item.label.ifEmpty { "Düymə: KeyCode ${item.triggerKeyCode}" }
        
        val typeStr = if (item.isLongPress) "Uzun Basma" else "Qısa Basma"
        val actionStr = when (item.actionType) {
            ActionType.KEY_REMAP -> "Hedef KeyCode: ${item.targetKeyCode}"
            ActionType.LAUNCH_APP -> "Tətbiq: ${item.targetPackage}"
            ActionType.FORCE_STOP_CURRENT_APP -> "Aktiv Tətbiqi Bağla"
        }

        holder.tvDetails.text = "Təkrar: $typeStr | Əməl: $actionStr"

        holder.btnEdit.setOnClickListener { onEditClick(item) }
        holder.btnDelete.setOnClickListener { onDeleteClick(item) }
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<KeyMapping>) {
        items = newItems
        notifyDataSetChanged()
    }
}
