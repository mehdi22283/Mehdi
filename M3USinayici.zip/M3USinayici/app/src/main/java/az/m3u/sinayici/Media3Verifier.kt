package az.m3u.sinayici

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

/**
 * Tester bitəndən sonra 🔴 kanalları səssiz (görüntüsüz) Media3 ilə yenidən yoxlayır.
 * Kanal STATE_READY-ə çatırsa işləyir sayılır (Net.exoOk + 🟢), əks halda Net.exoFail (🔴 qalır).
 * Eyni anda PAR kanal yoxlanır; hər kanal üçün ən çox MAX_PROFILES profil sınanır.
 */
object Media3Verifier {
    private const val PAR = 3
    private const val TIMEOUT = 8000L
    private const val MAX_PROFILES = 3

    private class Job(val url: String, val hdr: String, val done: (Boolean) -> Unit) {
        var player: ExoPlayer? = null
        var timeout: Runnable? = null
        var finished = false
    }

    private val h = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<Job>()
    private val active = HashSet<Job>()
    private var gen = 0

    fun add(ctx: Context, url: String, hdr: String, done: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        h.post { queue.addLast(Job(url, hdr, done)); pump(app) }
    }

    fun cancel() {
        h.post {
            gen++
            queue.clear()
            active.toList().forEach { stop(it) }
            active.clear()
        }
    }

    private fun stop(j: Job) {
        j.finished = true
        j.timeout?.let { h.removeCallbacks(it) }; j.timeout = null
        val p = j.player; j.player = null
        if (p != null) h.post { try { p.release() } catch (e: Exception) { } }
    }

    private fun pump(app: Context) {
        while (active.size < PAR) {
            val j = queue.removeFirstOrNull() ?: return
            active.add(j)
            val my = gen
            Thread {
                val ps = Net.profiles(j.url, j.hdr).take(MAX_PROFILES)
                h.post { if (my == gen && !j.finished) attempt(app, j, ps, 0, my) }
            }.start()
        }
    }

    private fun end(app: Context, j: Job, ok: Boolean, my: Int) {
        if (j.finished || my != gen) return
        stop(j); active.remove(j)
        if (ok) Net.exoOk(j.url) else Net.exoFail(j.url)
        j.done(ok)
        pump(app)
    }

    private fun attempt(app: Context, j: Job, ps: List<Net.Target>, i: Int, my: Int) {
        if (j.finished || my != gen) return
        j.timeout?.let { h.removeCallbacks(it) }; j.timeout = null
        val old = j.player; j.player = null
        if (old != null) try { old.release() } catch (e: Exception) { }
        if (i >= ps.size) { end(app, j, false, my); return }
        val t = ps[i]
        Thread {
            val hls = try { Net.isHls(t) } catch (e: Exception) { false }
            h.post { if (my == gen && !j.finished) start(app, j, ps, i, t, hls, my) }
        }.start()
    }

    private fun start(app: Context, j: Job, ps: List<Net.Target>, i: Int, t: Net.Target, hls: Boolean, my: Int) {
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(7000).setReadTimeoutMs(7000)
        val ds = ResolvingDataSource.Factory(http, ResolvingDataSource.Resolver { spec -> spec.withAdditionalHeaders(t.headers) })
        val p = ExoPlayer.Builder(app).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build()
        p.volume = 0f
        j.player = p
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && j.player === p) { Net.markGood(t.url, t.name); end(app, j, true, my) }
            }
            override fun onPlayerError(e: PlaybackException) {
                if (j.player === p) attempt(app, j, ps, i + 1, my)
            }
        })
        val tm = Runnable { if (j.player === p) attempt(app, j, ps, i + 1, my) }
        j.timeout = tm
        h.postDelayed(tm, TIMEOUT)
        val mi = MediaItem.Builder().setUri(t.url)
        if (hls) mi.setMimeType(MimeTypes.APPLICATION_M3U8)
        p.setMediaItem(mi.build()); p.prepare(); p.playWhenReady = true
    }
}
