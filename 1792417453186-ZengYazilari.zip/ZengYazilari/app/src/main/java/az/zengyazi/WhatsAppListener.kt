package az.zengyazi

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * WhatsApp zəng bildirişlərini izləyir.
 * Zəng çalanda bildirişdə 2 düymə (Cavab/Rədd), danışıq zamanı 1 düymə (Bitir) olur.
 */
class WhatsAppListener : NotificationListenerService() {
    private var pendingIncoming = false
    private var name = "Naməlum"

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp") return
        val n = sbn.notification
        if (n.category != Notification.CATEGORY_CALL) return
        n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.let { name = it }
        val actions = n.actions?.size ?: 0
        if (actions >= 2) { pendingIncoming = true; return }          // çalır
        if (RecState.active.value?.app != "WhatsApp")                  // danışıq başladı
            RecorderService.start(this, name, "WhatsApp", pendingIncoming)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp") return
        if (sbn.notification.category != Notification.CATEGORY_CALL) return
        if (RecState.active.value?.app == "WhatsApp") RecorderService.stop(this)
        pendingIncoming = false
    }
}
