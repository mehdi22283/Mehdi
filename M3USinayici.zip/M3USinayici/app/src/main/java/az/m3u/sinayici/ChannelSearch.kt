package az.m3u.sinayici

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.util.concurrent.Executors

/** Saxlanılan playlistlərdə (1-ci və 2-ci) kanal adına görə axtarış: əvvəl dəqiq, sonra oxşar uyğunluqlar. */
object ChannelSearch {

    class Ch(val name: String, val group: String, val url: String, val hdr: String, val list: Int) {
        val norm: String = normalize(name)
        val core: String = coreOf(name)
    }

    private class Row(val header: String?, val ch: Ch?, val score: Float = 0f)

    private val noise = setOf("hd", "fhd", "uhd", "sd", "4k", "8k", "hevc", "h264", "h265", "720p", "1080p", "720", "1080", "50fps", "backup", "yedek")

    private fun fold(s: String): String {
        val sb = StringBuilder()
        for (c in s.lowercase()) {
            val m = when (c) {
                'ə' -> 'e'
                'ı' -> 'i'
                'ö' -> 'o'
                'ü' -> 'u'
                'ç' -> 'c'
                'ş' -> 's'
                'ğ' -> 'g'
                'ё' -> 'е'
                else -> c
            }
            sb.append(m)
        }
        return Normalizer.normalize(sb.toString(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    }

    private fun tokens(s: String): List<String> =
        fold(s).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }

    fun normalize(s: String): String = tokens(s).joinToString("")
    fun coreOf(s: String): String = tokens(s).filter { it !in noise }.joinToString("")

    fun parse(text: String, list: Int): List<Ch> {
        val out = ArrayList<Ch>()
        var name: String? = null
        var group = "Digər"
        var hdr: JSONObject? = null
        val grp = Regex("group-title=\"([^\"]*)\"", RegexOption.IGNORE_CASE)
        val opt = Regex("^#EXTVLCOPT:\\s*http-(user-agent|referrer|referer|origin)\\s*=\\s*(.+)$", RegexOption.IGNORE_CASE)
        for (raw in text.split(Regex("\\r?\\n"))) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#EXTM3U")) continue
            if (line.uppercase().startsWith("#EXTINF")) {
                group = grp.find(line)?.groupValues?.get(1)?.trim()?.ifEmpty { "Digər" } ?: "Digər"
                val i = line.indexOf(',')
                name = if (i >= 0) line.substring(i + 1).trim().ifEmpty { "Naməlum kanal" } else "Naməlum kanal"
                hdr = null
            } else if (line.uppercase().startsWith("#EXTGRP:")) {
                val g = line.substringAfter(':').trim()
                if (g.isNotEmpty()) group = g
            } else if (line.startsWith("#")) {
                val m = opt.find(line)
                if (m != null && name != null) {
                    if (hdr == null) hdr = JSONObject()
                    hdr.put(m.groupValues[1].lowercase(), m.groupValues[2].trim())
                }
            } else {
                out.add(Ch(name ?: line, group, line, hdr?.toString() ?: "{}", list))
                name = null; group = "Digər"; hdr = null
            }
        }
        return out
    }

    private fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    private fun sim(a: String, b: String): Float {
        val m = maxOf(a.length, b.length)
        if (m == 0) return 0f
        if (Math.abs(a.length - b.length) > m * 0.35) return 0f
        return 1f - lev(a, b).toFloat() / m
    }

    /** 1.0 = dəqiq; 0 < x < 1 = oxşar; 0 = uyğun deyil. */
    private fun score(c: Ch, qn: String, qcore: String, qtok: List<String>): Float {
        if (c.norm == qn) return 1f
        if (qcore.isNotEmpty() && c.core == qcore) return 0.95f
        if (qn.length >= 2 && c.norm.startsWith(qn)) return 0.85f
        if (qn.length >= 2 && c.norm.contains(qn)) return 0.75f
        val ctok = tokens(c.name)
        if (qtok.isNotEmpty() && qtok.all { t -> ctok.any { it == t || it.startsWith(t) } || c.norm.contains(t) }) return 0.7f
        if (qn.length >= 3) {
            var best = sim(c.core, qcore)
            if (c.norm.length > qn.length) best = maxOf(best, sim(c.norm.substring(0, qn.length), qn))
            for (t in ctok) if (t.length >= 3) best = maxOf(best, sim(t, qn))
            if (best >= 0.75f) return best * 0.69f
        }
        return 0f
    }

    fun show(act: Activity) {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val ui = Handler(Looper.getMainLooper())
        val exec = Executors.newSingleThreadExecutor()
        val all = java.util.concurrent.atomic.AtomicReference<List<Ch>?>(null)
        val genRef = java.util.concurrent.atomic.AtomicInteger(0)

        val dlg = Dialog(act)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)

        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; setPadding(px(12), px(12), px(12), px(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0D1117")); cornerRadius = px(16).toFloat(); setStroke(px(1), Color.parseColor("#30363D"))
            }
        }

        val top = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(act).apply { text = "🔍 Kanal axtarışı"; setTextColor(Color.WHITE); textSize = 17f },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(TextView(act).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            setPadding(px(14), px(6), px(14), px(6)); setOnClickListener { dlg.dismiss() }
        })
        root.addView(top)

        val input = EditText(act).apply {
            hint = "Kanal adı (məs: AzTV)"; setHintTextColor(Color.parseColor("#6E7681")); setTextColor(Color.WHITE)
            textSize = 16f; isSingleLine = true; imeOptions = EditorInfo.IME_ACTION_SEARCH
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(px(12), px(10), px(12), px(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#161B22")); cornerRadius = px(8).toFloat(); setStroke(px(1), Color.parseColor("#30363D"))
            }
        }
        root.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })

        val info = TextView(act).apply { setTextColor(Color.parseColor("#8B949E")); textSize = 12.5f; setPadding(px(2), px(8), px(2), px(6)); text = "Playlistlər yüklənir..." }
        root.addView(info)

        var rows: List<Row> = emptyList()
        val ad = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(i: Int) = rows[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun isEnabled(i: Int) = rows[i].ch != null
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val r = rows[i]
                val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
                if (r.header != null) {
                    box.setPadding(px(4), px(12), px(4), px(4))
                    box.addView(TextView(act).apply { text = r.header; setTextColor(Color.parseColor("#58A6FF")); textSize = 13f })
                } else {
                    val c = r.ch!!
                    box.setPadding(px(10), px(9), px(10), px(9))
                    box.background = GradientDrawable().apply { setColor(Color.parseColor("#161B22")); cornerRadius = px(8).toFloat() }
                    box.addView(TextView(act).apply { text = c.name; setTextColor(Color.WHITE); textSize = 15f; maxLines = 2 })
                    box.addView(TextView(act).apply {
                        text = "${c.list}-ci playlist  ·  ${c.group}"; setTextColor(Color.parseColor("#8B949E")); textSize = 12f
                    })
                }
                val wrap = LinearLayout(act).apply { setPadding(0, px(3), 0, px(3)) }
                wrap.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                return wrap
            }
        }
        val lv = ListView(act).apply {
            adapter = ad; divider = null; dividerHeight = 0; setBackgroundColor(Color.TRANSPARENT)
            clipToPadding = false; setPadding(0, 0, 0, px(16))
            setOnItemClickListener { _, _, pos, _ ->
                val r = rows[pos]; val ch = r.ch ?: return@setOnItemClickListener
                val chans = rows.mapNotNull { it.ch }
                PlayQueue.items = chans.map { QItem(it.name, it.url, it.hdr) }
                PlayQueue.index = chans.indexOf(ch).coerceAtLeast(0)
                act.startActivity(Intent(act, PlayerActivity::class.java))
            }
        }
        root.addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        dlg.setContentView(root)

        fun search(q: String) {
            val my = genRef.incrementAndGet()
            val data = all.get() ?: return
            if (exec.isShutdown) return
            if (q.isBlank()) { rows = emptyList(); ad.notifyDataSetChanged(); info.text = "${data.size} kanal axtarışa hazırdır"; return }
            exec.execute {
                val qn = normalize(q); val qcore = coreOf(q); val qtok = tokens(q)
                val exact = ArrayList<Ch>(); val similar = ArrayList<Pair<Ch, Float>>()
                for (c in data) {
                    if (my != genRef.get()) return@execute
                    val s = score(c, qn, qcore, qtok)
                    if (s >= 1f) exact.add(c) else if (s > 0f) similar.add(c to s)
                }
                similar.sortWith(compareByDescending<Pair<Ch, Float>> { it.second }.thenBy { it.first.name.length })
                val out = ArrayList<Row>()
                if (exact.isNotEmpty()) { out.add(Row("✅ Dəqiq uyğunluq (${exact.size})", null)); exact.take(300).forEach { out.add(Row(null, it)) } }
                if (similar.isNotEmpty()) { out.add(Row("≈ Oxşar kanallar (${similar.size})", null)); similar.take(300).forEach { out.add(Row(null, it.first)) } }
                ui.post {
                    if (my != genRef.get()) return@post
                    rows = out; ad.notifyDataSetChanged(); lv.setSelection(0)
                    info.text = if (out.isEmpty()) "Heç nə tapılmadı" else "Dəqiq: ${exact.size}  ·  Oxşar: ${similar.size}"
                }
            }
        }

        var pending: Runnable? = null
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                pending?.let { ui.removeCallbacks(it) }
                val r = Runnable { search(s?.toString() ?: "") }; pending = r
                ui.postDelayed(r, 180)
            }
        })
        input.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { search(input.text.toString()); true } else false }
        dlg.setOnDismissListener { genRef.incrementAndGet(); exec.shutdownNow() }

        // playlistləri arxa planda oxu
        Thread {
            val list = ArrayList<Ch>()
            for (n in 1..2) {
                val f = File(act.filesDir, "playlist$n.m3u")
                if (f.exists()) try { list.addAll(parse(f.readText(), n)) } catch (e: Exception) { }
            }
            ui.post {
                all.set(list)
                info.text = if (list.isEmpty()) "Playlist boşdur — əvvəlcə M3U yükləyin" else "${list.size} kanal axtarışa hazırdır"
                search(input.text.toString())
            }
        }.start()

        dlg.show()
        dlg.window?.let { w ->
            val dm = act.resources.displayMetrics
            w.setLayout((dm.widthPixels * 0.94f).toInt(), (dm.heightPixels * 0.58f).toInt())
            w.setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            val a = w.attributes; a.y = px(40); w.attributes = a
        }
        input.requestFocus()
    }
}
