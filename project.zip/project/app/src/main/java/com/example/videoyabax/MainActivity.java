package com.example.videoyabax;

import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.format.Formatter;
import android.view.View;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;

import fi.iki.elonen.NanoHTTPD;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private LocalServer server;
    private VideoView videoView;
    private TextView ipTextView;
    private static final int PORT = 3169;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        videoView = findViewById(R.id.videoView);
        ipTextView = findViewById(R.id.ipTextView);

        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(videoView);
        videoView.setMediaController(mediaController);

        startServer();
    }

    private void startServer() {
        try {
            server = new LocalServer(PORT);
            server.start();
            String ip = getIpAddress();
            ipTextView.setText("Telefonda brauzerdə daxil olun:\nhttp://" + ip + ":" + PORT);
        } catch (IOException e) {
            ipTextView.setText("Server xətası: " + e.getMessage());
        }
    }

    private String getIpAddress() {
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        return Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (server != null) {
            server.stop();
        }
    }

    private class LocalServer extends NanoHTTPD {
        private InputStream currentVideoStream = null;

        public LocalServer(int port) {
            super(port);
        }

        @Override
        public Response serve(IHTTPSession session) {
            String uri = session.getUri();

            if (uri.equals("/stream")) {
                if (currentVideoStream != null) {
                    return newChunkedResponse(Response.Status.OK, "video/mp4", currentVideoStream);
                } else {
                    return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Video tapılmadı");
                }
            }

            if (Method.POST.equals(session.getMethod())) {
                try {
                    Map<String, String> files = new HashMap<>();
                    session.parseBody(files);

                    currentVideoStream = session.getInputStream();

                    runOnUiThread(() -> {
                        ipTextView.setVisibility(View.GONE);
                        videoView.setVideoURI(Uri.parse("http://localhost:" + PORT + "/stream"));
                        videoView.start();
                    });

                    return newFixedLengthResponse("Video TV-də oynadılır!");
                } catch (Exception e) {
                    return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, e.getMessage());
                }
            }

            String html = "<!DOCTYPE html><html><head>"
                    + "<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
                    + "<style>body{font-family:sans-serif;text-align:center;padding:50px;background:#f4f4f4;}"
                    + "input,button{padding:15px;margin:10px;font-size:18px;width:80%;max-width:400px;border-radius:8px;border:1px solid #ccc;}</style>"
                    + "</head><body>"
                    + "<h2>Videoya bax - TV Streamer</h2>"
                    + "<form method='post' enctype='multipart/form-data'>"
                    + "<input type='file' name='file' accept='video/*' required><br>"
                    + "<button type='submit'>TV-də Aç</button>"
                    + "</form></body></html>";

            return newFixedLengthResponse(html);
        }
    }
}
