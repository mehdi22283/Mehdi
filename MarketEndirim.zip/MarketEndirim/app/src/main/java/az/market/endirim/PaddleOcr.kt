package az.market.endirim

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.FloatBuffer
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Oflayn ən güclü mühərrik: PaddleOCR PP-OCRv5 — ONNX Runtime ilə telefonda işləyir.
 *  1) detektor mətn sətirlərini tapır (DB: ehtimal xəritəsi → bağlı sahələr → qutular);
 *  2) tanıyıcı hər qutunu oxuyur (CTC, "greedy" açma). Tanıyıcı LATIN modeldir (Azərbaycan dili "az" daxildir: ə ı ş ç ö ü ğ).
 * Modellər (ONNX, HuggingFace) ilk istifadədə bir dəfə endirilir. Əvvəlki versiya Paddle-ın rəsmi ".tar" linklərindən ONNX
 * gözləyirdi — onlar Paddle formatındadır (ONNX deyil), ona görə heç vaxt işə düşmürdü.
 */
object PaddleOcr {
    private const val HF = "https://huggingface.co/"
    // detektor: əvvəl yüngül (mobil, ~5 MB), alınmasa böyük (~84 MB)
    private val DET_URLS = listOf(
        HF + "vladadu/pp-ocrv5-arabic-mobile-onnx/resolve/main/PP-OCRv5_mobile_det.onnx",
        HF + "monkt/paddleocr-onnx/resolve/main/detection/v5/det.onnx",
        HF + "Mrdhnto/paddleocr-onnx/resolve/main/detection/v5/det.onnx"
    )
    // tanıyıcı: latın (fransız/alman/türk/azərbaycan... 30+ dil), PP-OCRv5
    private val REC_URLS = listOf(
        HF + "monkt/paddleocr-onnx/resolve/main/languages/latin/rec.onnx",
        HF + "Mrdhnto/paddleocr-onnx/resolve/main/languages/latin/rec.onnx"
    )
    private val DICT_URLS = listOf(
        HF + "monkt/paddleocr-onnx/resolve/main/languages/latin/dict.txt",
        HF + "Mrdhnto/paddleocr-onnx/resolve/main/languages/latin/dict.txt"
    )
    private const val F_DET = "det5.onnx"
    private const val F_REC = "rec_latin.onnx"
    private const val F_DICT = "rec_latin_dict.txt"
    private const val RETRY_MS = 300_000L     // xəta olsa 5 dəqiqədən sonra yenidən cəhd
    private const val DET_SIDE = 1600          // böyük tərəf: jurnal səhifələrində kiçik yazılar 1280-də itirdi (PaddleOCR-ın standartı 960)
    private const val BIN_THRESH = 0.3f
    private const val BOX_THRESH = 0.6f
    private const val UNCLIP = 1.5f
    @Volatile private var recH = 48

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    @Volatile private var env: OrtEnvironment? = null
    @Volatile private var det: OrtSession? = null
    @Volatile private var rec: OrtSession? = null
    @Volatile private var dict: List<String> = emptyList()
    @Volatile private var appCtx: Context? = null
    private val initLock = Any()
    @Volatile private var lastReport = 0L

    /** ONNX Runtime-ın hər sessiya üçün axın sayı; paralel skanda ProductScanner azaldır (səhifələr özü paralel işləyir). */
    @Volatile var threads = 2
    @Volatile private var failedAt = 0L
    private fun isFailed() = failedAt != 0L && System.currentTimeMillis() - failedAt < RETRY_MS
    private fun markFailed() { failedAt = System.currentTimeMillis() }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("paddle", Context.MODE_PRIVATE)
    fun switchedOn(ctx: Context): Boolean = prefs(ctx).getBoolean("on", true)
    fun save(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean("on", on).apply()
        failedAt = 0L
    }

    private fun dir(ctx: Context) = File(ctx.filesDir, "paddle").apply { mkdirs() }
    private fun f(ctx: Context, n: String) = File(dir(ctx), n)

    /** Qoşulubdur və (hələ) xəta verməyib. */
    fun enabled(ctx: Context): Boolean = switchedOn(ctx) && !isFailed()

    /** Modellər artıq endirilib (sığnatura üçün: yalnız hazır olanda skan imzası dəyişir). */
    fun ready(ctx: Context): Boolean = enabled(ctx) && f(ctx, F_DET).exists() && f(ctx, F_REC).exists() && f(ctx, F_DICT).exists()

    // ---------------- endirmə və yükləmə ----------------

    private fun toast(ctx: Context, msg: String) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    /** Xəta səbəbini istifadəçiyə göstərir (səssiz uğursuzluq olmasın deyə); tez-tez təkrarlanmır. */
    private fun report(ctx: Context?, msg: String) {
        val c = ctx ?: return
        val now = System.currentTimeMillis()
        if (now - lastReport < 20_000L) return
        lastReport = now
        toast(c, "PaddleOCR: $msg")
    }

    /** Linklər sıra ilə sınanır; ilk uğurlu endirilən fayl yazılır. Çox kiçik fayl (səhv səhifə) qəbul olunmur. */
    private fun download(urls: List<String>, dest: File, minBytes: Long) {
        val errs = ArrayList<String>()
        for (u in urls) {
            val tmp = File(dest.parentFile, dest.name + ".part")
            try {
                http.newCall(Request.Builder().url(u).header("User-Agent", "Mozilla/5.0").build()).execute().use { r ->
                    if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                    r.body!!.byteStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
                }
                if (tmp.length() < minBytes) throw IOException("fayl çox kiçikdir (${tmp.length()} bayt)")
                dest.delete()
                if (!tmp.renameTo(dest)) throw IOException("fayl yazılmadı")
                return
            } catch (e: Exception) {
                tmp.delete()
                errs.add(u.substringAfter("huggingface.co/").substringBefore("/resolve") + ": " + (e.message ?: e.javaClass.simpleName))
            }
        }
        throw IOException(errs.joinToString("; "))
    }

    /** dict.txt: hər sətir bir simvol (boşluq simvolu ola bilər — kəsilmir). */
    private fun loadDict(file: File): List<String> {
        val lines = file.readText(Charsets.UTF_8).split("\n").map { it.removeSuffix("\r") }
        return if (lines.isNotEmpty() && lines.last().isEmpty()) lines.dropLast(1) else lines
    }

    private fun ensure(ctx: Context): Boolean {
        if (isFailed()) return false
        if (det != null && rec != null) return true
        synchronized(initLock) {
            if (isFailed()) return false
            if (det != null && rec != null) return true
            appCtx = ctx.applicationContext
            var corrupt = false
            try {
                if (!f(ctx, F_DET).exists()) {
                    toast(ctx, "PaddleOCR modelləri endirilir (bir dəfə)…")
                    download(DET_URLS, f(ctx, F_DET), 1_000_000L)
                }
                if (!f(ctx, F_REC).exists()) download(REC_URLS, f(ctx, F_REC), 3_000_000L)
                if (!f(ctx, F_DICT).exists()) download(DICT_URLS, f(ctx, F_DICT), 500L)
                corrupt = true          // bundan sonrakı xəta fayl zədəsi deməkdir — fayllar silinir
                val dc = loadDict(f(ctx, F_DICT))
                if (dc.size < 50) throw IOException("lüğət oxunmadı")
                val e = OrtEnvironment.getEnvironment()
                val n = threads.coerceAtLeast(1)
                val ds = e.createSession(f(ctx, F_DET).absolutePath, OrtSession.SessionOptions().apply { setIntraOpNumThreads(n) })
                val rs = e.createSession(f(ctx, F_REC).absolutePath, OrtSession.SessionOptions().apply { setIntraOpNumThreads(n) })
                recH = try {
                    val h = (rs.inputInfo[rs.inputNames.first()]?.info as? TensorInfo)?.shape?.getOrNull(2) ?: -1L
                    if (h in 16L..96L) h.toInt() else 48
                } catch (ex: Exception) {
                    48
                }
                env = e; dict = dc; rec = rs; det = ds
                corrupt = false         // modellər yükləndi; özünütest uğursuz olsa fayllar silinmir
                // həqiqətən oxuyurmu? Sadə mətn şəkli oxunur — oxumursa mühərrik söndürülür və dəqiq səbəb göstərilir
                val why = selfTest()
                if (why != null) {
                    det = null; rec = null
                    try { ds.close(); rs.close() } catch (x: Exception) { }
                    throw IOException(why)
                }
                return true
            } catch (e: Throwable) {
                markFailed()
                if (corrupt) for (n in listOf(F_DET, F_REC, F_DICT)) f(ctx, n).delete()
                report(ctx, "işə düşmədi: " + (e.message ?: e.javaClass.simpleName).take(160))
                return false
            }
        }
        @Suppress("UNREACHABLE_CODE")
        return false
    }

    /** Sadə mətn şəklini çəkib oxuyur. Uğurludursa null, deyilsə səbəb mətni. */
    private fun selfTest(): String? {
        val bmp = Bitmap.createBitmap(900, 240, Bitmap.Config.ARGB_8888)
        try {
            val cv = Canvas(bmp)
            cv.drawColor(Color.WHITE)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = Color.BLACK
            p.textSize = 110f
            p.typeface = Typeface.DEFAULT_BOLD
            cv.drawText("ENDIRIM 3.99", 30f, 150f, p)
            val boxes = detect(bmp)
            val sb = StringBuilder()
            for (bx in boxes) recognize(bmp, bx)?.let { sb.append(it) }
            val flat = sb.toString().uppercase().filter { it.isLetterOrDigit() }
            val ok = flat.contains("ENDI") || flat.contains("IRIM") || flat.contains("399")
            return if (ok) null else "özünütest: ${boxes.size} qutu tapıldı, oxunan «$flat»"
        } catch (e: Throwable) {
            return "özünütest xətası: " + (e.message ?: e.javaClass.simpleName).take(120)
        } finally {
            bmp.recycle()
        }
    }

    // ---------------- oxuma ----------------

    private class Box(val l: Int, val t: Int, val r: Int, val b: Int)

    /** Səhifədəki bütün sətirləri (səhifə koordinatlarında) qaytarır; mühərrik işləməsə null. Bir neçə səhifə paralel çağıra bilər. */
    suspend fun lines(ctx: Context, bmp: Bitmap): List<OLine>? {
        if (!enabled(ctx)) return null
        return withContext(Dispatchers.Default) {
            if (!ensure(ctx)) return@withContext null
            try {
                val boxes = detect(bmp)
                val out = ArrayList<OLine>()
                for (bx in boxes) {
                    val txt = recognize(bmp, bx) ?: continue
                    out.add(OLine(txt, bx.l, bx.t, bx.r, bx.b))
                }
                out
            } catch (e: Exception) {
                report(ctx, "oxuma xətası: " + (e.message ?: e.javaClass.simpleName).take(120))
                null
            }
        }
    }

    /** DB detektoru: ehtimal xəritəsi → eşik → bağlı sahələr → bir qədər genişləndirilmiş qutular. */
    private fun detect(bmp: Bitmap): List<Box> {
        val e = env!!
        val s = det!!
        val w = bmp.width
        val h = bmp.height
        val sc = minOf(1f, DET_SIDE.toFloat() / maxOf(w, h))
        val nw = (((w * sc) / 32f).roundToInt() * 32).coerceAtLeast(32)
        val nh = (((h * sc) / 32f).roundToInt() * 32).coerceAtLeast(32)
        val sb = Bitmap.createScaledBitmap(bmp, nw, nh, true)
        val px = IntArray(nw * nh)
        sb.getPixels(px, 0, nw, 0, 0, nw, nh)
        if (sb !== bmp) sb.recycle()
        val plane = nw * nh
        val data = FloatArray(3 * plane)
        // PaddleOCR/OpenCV kimi BGR sırası; ImageNet orta/sapma
        for (i in 0 until plane) {
            val c = px[i]
            val r = ((c shr 16) and 0xFF) / 255f
            val g = ((c shr 8) and 0xFF) / 255f
            val b = (c and 0xFF) / 255f
            data[i] = (b - 0.485f) / 0.229f
            data[plane + i] = (g - 0.456f) / 0.224f
            data[2 * plane + i] = (r - 0.406f) / 0.225f
        }
        var prob: Array<FloatArray>? = null
        OnnxTensor.createTensor(e, FloatBuffer.wrap(data), longArrayOf(1, 3, nh.toLong(), nw.toLong())).use { t ->
            s.run(mapOf(s.inputNames.first() to t)).use { res ->
                @Suppress("UNCHECKED_CAST")
                val v = res[0].value as Array<Array<Array<FloatArray>>>
                prob = v[0][0]
            }
        }
        val p = prob ?: return emptyList()
        val ph = p.size
        val pw = p[0].size
        val seen = BooleanArray(pw * ph)
        val stack = IntArray(pw * ph)
        val sx = w.toFloat() / pw
        val sy = h.toFloat() / ph
        val boxes = ArrayList<Box>()
        for (start in 0 until pw * ph) {
            if (seen[start] || p[start / pw][start % pw] <= BIN_THRESH) continue
            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var minx = pw; var maxx = -1; var miny = ph; var maxy = -1
            var sum = 0f; var cnt = 0
            while (sp > 0) {
                val q = stack[--sp]
                val qx = q % pw
                val qy = q / pw
                sum += p[qy][qx]; cnt++
                if (qx < minx) minx = qx
                if (qx > maxx) maxx = qx
                if (qy < miny) miny = qy
                if (qy > maxy) maxy = qy
                if (qx > 0) { val n = q - 1; if (!seen[n] && p[qy][qx - 1] > BIN_THRESH) { seen[n] = true; stack[sp++] = n } }
                if (qx < pw - 1) { val n = q + 1; if (!seen[n] && p[qy][qx + 1] > BIN_THRESH) { seen[n] = true; stack[sp++] = n } }
                if (qy > 0) { val n = q - pw; if (!seen[n] && p[qy - 1][qx] > BIN_THRESH) { seen[n] = true; stack[sp++] = n } }
                if (qy < ph - 1) { val n = q + pw; if (!seen[n] && p[qy + 1][qx] > BIN_THRESH) { seen[n] = true; stack[sp++] = n } }
            }
            val bw = maxx - minx + 1
            val bh = maxy - miny + 1
            if (minOf(bw, bh) < 3 || cnt < 12) continue
            if (sum / cnt < BOX_THRESH) continue
            // DB "unclip": məsafə = sahə * nisbət / perimetr
            val d = (bw * bh * UNCLIP) / (2f * (bw + bh))
            val l = ((minx - d) * sx).toInt().coerceIn(0, w - 1)
            val t = ((miny - d) * sy).toInt().coerceIn(0, h - 1)
            val r = (((maxx + 1) + d) * sx).toInt().coerceIn(l + 1, w)
            val b = (((maxy + 1) + d) * sy).toInt().coerceIn(t + 1, h)
            boxes.add(Box(l, t, r, b))
        }
        return boxes.sortedWith(compareBy({ it.t / 20 }, { it.l }))
    }

    /** Tanıyıcı: qutu kəsilir, hündürlüyü 48-ə gətirilir, CTC çıxışı açılır. Əminlik aşağıdırsa null. */
    private fun recognize(bmp: Bitmap, bx: Box): String? {
        val e = env!!
        val s = rec!!
        val w = bx.r - bx.l
        val h = bx.b - bx.t
        if (w < 6 || h < 6) return null
        if (h > 1.5f * w) return null          // şaquli yazı — atılır
        val crop = Bitmap.createBitmap(bmp, bx.l, bx.t, w, h)
        val tw = ceil(recH.toFloat() * w / h).toInt().coerceIn(16, 2000)
        val sb = Bitmap.createScaledBitmap(crop, tw, recH, true)
        if (sb !== crop) crop.recycle()
        val px = IntArray(tw * recH)
        sb.getPixels(px, 0, tw, 0, 0, tw, recH)
        sb.recycle()
        val plane = tw * recH
        val data = FloatArray(3 * plane)
        for (i in 0 until plane) {
            val c = px[i]
            data[i] = ((c and 0xFF) / 255f - 0.5f) / 0.5f                       // B
            data[plane + i] = (((c shr 8) and 0xFF) / 255f - 0.5f) / 0.5f        // G
            data[2 * plane + i] = (((c shr 16) and 0xFF) / 255f - 0.5f) / 0.5f   // R
        }
        var steps: Array<FloatArray>? = null
        OnnxTensor.createTensor(e, FloatBuffer.wrap(data), longArrayOf(1, 3, recH.toLong(), tw.toLong())).use { t ->
            s.run(mapOf(s.inputNames.first() to t)).use { res ->
                @Suppress("UNCHECKED_CAST")
                val v = res[0].value as Array<Array<FloatArray>>
                steps = v[0]
            }
        }
        val out = steps ?: return null
        if (out.isEmpty()) return null
        val classes = out[0].size
        if (classes != dict.size + 2 && classes != dict.size + 1) {
            markFailed()             // lüğət çıxışa uyğun deyil — səhv mətn əvəzinə mühərrik müvəqqəti söndürülür
            report(appCtx, "lüğət modelə uyğun deyil (model $classes sinif, lüğət ${dict.size} simvol)")
            return null
        }
        val sbd = StringBuilder()
        var prev = -1
        var confSum = 0f
        var confN = 0
        for (row in out) {
            var best = 0
            var bv = row[0]
            for (k in 1 until row.size) if (row[k] > bv) { bv = row[k]; best = k }
            if (best != 0 && best != prev) {
                val idx = best - 1
                sbd.append(if (idx < dict.size) dict[idx] else " ")
                confSum += bv; confN++
            }
            prev = best
        }
        if (confN == 0) return null
        val txt = sbd.toString().trim()
        if (txt.isEmpty() || confSum / confN < 0.45f) return null
        return txt
    }
}
