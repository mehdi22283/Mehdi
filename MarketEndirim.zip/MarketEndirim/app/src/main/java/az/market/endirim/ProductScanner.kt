package az.market.endirim

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

/**
 * Jurnalların bütün səhifələrini OCR ilə oxuyub məhsul adı + qiymət çıxarır.
 *  - PDF: hər səhifə render edilib oxunur;
 *  - şəkil albomu (Al Market): şəkillər endirilib oxunur;
 *  - veb-jurnal (Bravo flipbook): gizli WebView-da səhifələr ekran görüntüsü ilə oxunur (sınaqsız, ən zəif hissə).
 */
object ProductScanner {
    private const val PDF_W = 2000
    private const val MAX_H = 4200
    private const val MAX_IMG_W = 2400
    private const val MAX_WEB_PAGES = 60
    private val http = OkHttpClient()

    /** Jurnalın "barmaq izi": PDF üçün serverin ETag/Last-Modified/ölçüsü, digərləri üçün linklər. Dəyişəndə yenidən skan olunur. */
    fun sigFor(ctx: Context, c: Catalog): String? =
        if (c.kind == Kind.PDF) Downloader.storedSig(ctx, c.urls[0]) else "u:" + c.urls.joinToString("|").hashCode()

    suspend fun scan(act: Activity, c: Catalog, onProgress: (page: Int, total: Int) -> Unit): List<Product> {
        appCtx = act.applicationContext
        return dedupe(
            when (c.kind) {
                Kind.PDF -> scanPdf(act.applicationContext, c, onProgress)
                Kind.IMAGES -> scanImages(c, onProgress)
                Kind.WEB -> scanWeb(act, c, onProgress)
            }
        )
    }

    private fun dedupe(list: List<Product>): List<Product> {
        val seen = HashSet<String>()
        return list.filter { seen.add(it.key + "|" + it.price) }
    }

    private lateinit var appCtx: Context

    /** ML Kit (latın/azərbaycan) sətirlərinə Tesseract-ın tapdığı rus sətirlərini əlavə edir; üst-üstə düşən ML Kit səpələnmələrini silir. */
    private fun mergeRu(mk: List<OLine>, ru: List<OLine>): List<OLine> {
        if (ru.isEmpty()) return mk
        fun overlap(a: OLine, b: OLine): Boolean {
            val ox = minOf(a.r, b.r) - maxOf(a.l, b.l)
            val oy = minOf(a.b, b.b) - maxOf(a.t, b.t)
            return ox > 0 && oy > 0 && oy >= 0.4f * minOf(a.h, b.h) && ox >= 0.3f * minOf(a.w, b.w)
        }
        return mk.filter { m -> ru.none { overlap(m, it) } } + ru
    }

    private suspend fun pageProducts(bmp: Bitmap, c: Catalog, pageNo: Int): List<Product> {
        val text = Ocr.recognizeText(bmp)
        val mk = text.textBlocks.flatMap { it.lines }.mapNotNull { ln ->
            ln.boundingBox?.let { OLine(ln.text, it.left, it.top, it.right, it.bottom) }
        }
        val lines = mergeRu(mk, Ocr.cyrillicLines(appCtx, bmp))
        val raws = withContext(Dispatchers.Default) { ProductParser.parse(lines, bmp.width, bmp.height) }
        return raws.map { Product(it.name, it.price, it.old, c.market, c.urls[0], pageNo, Categorizer.classify(it.name)) }
    }

    // ---------------- PDF ----------------
    private suspend fun scanPdf(ctx: Context, c: Catalog, onProgress: (Int, Int) -> Unit): List<Product> {
        val file = Downloader.ensure(ctx, c.urls[0])
        val out = ArrayList<Product>()
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try {
            val n = r.pageCount
            for (i in 0 until n) {
                onProgress(i + 1, n)
                val bmp = withContext(Dispatchers.IO) { renderPage(r, i) }
                try {
                    out.addAll(pageProducts(bmp, c, i + 1))
                } finally {
                    bmp.recycle()
                }
            }
        } finally {
            r.close()
            pfd.close()
        }
        return out
    }

    private fun renderPage(r: PdfRenderer, i: Int): Bitmap {
        val p = r.openPage(i)
        try {
            var w = PDF_W
            var h = (w.toFloat() * p.height / p.width).toInt()
            if (h > MAX_H) {
                w = (w.toFloat() * MAX_H / h).toInt()
                h = MAX_H
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            p.close()
        }
    }

    // ---------------- Şəkil albomu ----------------
    private suspend fun scanImages(c: Catalog, onProgress: (Int, Int) -> Unit): List<Product> {
        val out = ArrayList<Product>()
        var failed = 0
        for ((i, url) in c.urls.withIndex()) {
            onProgress(i + 1, c.urls.size)
            try {
                val bmp = withContext(Dispatchers.IO) { download(url) }
                try {
                    out.addAll(pageProducts(bmp, c, i + 1))
                } finally {
                    bmp.recycle()
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                failed++
            }
        }
        if (failed == c.urls.size) throw IOException("Şəkillər yüklənmədi")
        return out
    }

    private fun download(url: String): Bitmap {
        val req = Request.Builder().url(url).header("User-Agent", Insta.UA).build()
        val bytes = http.newCall(req).execute().use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            it.body!!.bytes()
        }
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / sample > MAX_IMG_W) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2) ?: throw IOException("Şəkil açılmadı")
    }

    // ---------------- Veb-jurnal (Bravo flipbook) ----------------
    private suspend fun scanWeb(act: Activity, c: Catalog, onProgress: (Int, Int) -> Unit): List<Product> {
        val root = act.findViewById<ViewGroup>(android.R.id.content)
        val w = (act.resources.displayMetrics.widthPixels * 1.8f).toInt()    // böyük ölçü → kiçik yazılar da oxunur
        val h = (w * 1.45f).toInt()
        val web = WebView(act)
        val out = ArrayList<Product>()
        try {
            web.settings.javaScriptEnabled = true
            web.settings.domStorageEnabled = true
            web.translationX = -w.toFloat()          // ekranın kənarında, görünmür
            root.addView(web, FrameLayout.LayoutParams(w, h))
            web.loadUrl(c.urls[0])
            delay(8000)

            val seen = HashSet<String>()
            var method = 0
            var stale = 0
            var pages = 0
            for (n in 1..MAX_WEB_PAGES) {
                onProgress(n, 0)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                web.draw(Canvas(bmp))
                try {
                    val text = try { Ocr.recognizeText(bmp) } catch (e: Exception) { null }
                    val sig = Categorizer.norm(text?.text ?: "").filter { it.isLetterOrDigit() }.take(300)
                    if (text != null && sig.length >= 20 && seen.add(sig)) {
                        stale = 0
                        pages++
                        out.addAll(pageProducts(bmp, c, pages))
                    } else {
                        stale++
                        if (stale >= 4) break
                        method = (method + 1) % 3     // səhifə dəyişmədi — başqa keçid üsulu sına
                    }
                } finally {
                    bmp.recycle()
                }
                advance(web, w, h, method)
                delay(2500)
            }
        } finally {
            root.removeView(web)
            web.destroy()
        }
        return out
    }

    /** Növbəti səhifəyə keç: 0 = klaviatura →, 1 = "next" düyməsinə klik, 2 = sola sürüşdürmə. */
    private fun advance(web: WebView, w: Int, h: Int, method: Int) {
        when (method) {
            0 -> {
                web.requestFocus()
                val t = SystemClock.uptimeMillis()
                web.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT, 0))
                web.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_RIGHT, 0))
            }
            1 -> web.evaluateJavascript(
                "(function(){var e=document.querySelector('[class*=\"next\" i],[class*=\"Next\"],[aria-label*=\"ext\" i],[title*=\"ext\" i]');if(e){e.click();}})()",
                null
            )
            else -> {
                val t0 = SystemClock.uptimeMillis()
                val y = h * 0.5f
                val x0 = w * 0.8f
                val x1 = w * 0.2f
                fun ev(action: Int, x: Float, dt: Long) =
                    MotionEvent.obtain(t0, t0 + dt, action, x, y, 0).also { web.dispatchTouchEvent(it); it.recycle() }
                ev(MotionEvent.ACTION_DOWN, x0, 0)
                for (i in 1..6) ev(MotionEvent.ACTION_MOVE, x0 + (x1 - x0) * i / 6f, i * 25L)
                ev(MotionEvent.ACTION_UP, x1, 175)
            }
        }
    }
}
