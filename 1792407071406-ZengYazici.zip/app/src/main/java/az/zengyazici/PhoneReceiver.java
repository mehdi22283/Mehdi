package az.zengyazici;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.CallLog;
import android.telephony.TelephonyManager;
import java.io.File;

public class PhoneReceiver extends BroadcastReceiver {
    static boolean incoming = false, started = false;
    static String number = "";

    @Override
    public void onReceive(final Context c, Intent i) {
        String a = i.getAction();
        if (Intent.ACTION_NEW_OUTGOING_CALL.equals(a)) {
            String n = i.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
            if (n != null) number = n;
            incoming = false;
            return;
        }
        if (!TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(a)) return;
        String st = i.getStringExtra(TelephonyManager.EXTRA_STATE);
        String n = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
        if (TelephonyManager.EXTRA_STATE_RINGING.equals(st)) {
            incoming = true;
            if (n != null && !n.isEmpty()) number = n;
        } else if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(st)) {
            CallAccessService.clicked = false;
            CallAccessService.inCall = true;
            if (!started) {
                started = true;
                Rec.start(c, "tel", incoming ? "in" : "out", number);
            }
        } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(st)) {
            CallAccessService.inCall = false;
            final boolean needNum = number.isEmpty();
            final File f = started ? Rec.stop(c) : null;
            started = false; incoming = false; number = "";
            final PendingResult pr = goAsync();
            new Thread(() -> {
                try {
                    Thread.sleep(3500);
                    if (f != null && needNum && c.checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED) {
                        try (Cursor cur = c.getContentResolver().query(CallLog.Calls.CONTENT_URI,
                                new String[]{CallLog.Calls.NUMBER}, null, null, CallLog.Calls.DATE + " DESC LIMIT 1")) {
                            if (cur != null && cur.moveToFirst()) {
                                String num = cur.getString(0);
                                if (num != null && !num.isEmpty()) Rec.rename(f, num);
                            }
                        }
                    }
                    Importer.run(c);
                } catch (Exception e) { }
                pr.finish();
            }).start();
        }
    }
}
