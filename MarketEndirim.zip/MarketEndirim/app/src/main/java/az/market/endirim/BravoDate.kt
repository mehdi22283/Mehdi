package az.market.endirim

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import kotlinx.coroutines.delay

/** Bravo flipbook-un ilk səhifəsindəki tarixi ("1-15 oktyabr" kimi) ekran görüntüsündən OCR ilə oxuyur. */
object BravoDate {
    suspend fun read(activity: Activity, url: String): String? {
        val prefs = activity.getSharedPreferences("bravo", Context.MODE_PRIVATE)
        prefs.getString(url, null)?.let { if (it.isNotEmpty()) return it }

        val root = activity.findViewById<ViewGroup>(android.R.id.content)
        val w = activity.resources.displayMetrics.widthPixels
        val h = (w * 1.6f).toInt()
        val web = WebView(activity)
        try {
            web.settings.javaScriptEnabled = true
            web.settings.domStorageEnabled = true
            web.translationX = -w.toFloat()          // ekranın kənarında, görünmür
            root.addView(web, FrameLayout.LayoutParams(w, h))
            web.loadUrl(url)

            repeat(3) {
                delay(5000)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                web.draw(Canvas(bmp))
                val text = try { Ocr.recognize(bmp) } catch (e: Exception) { "" }
                val d = DateUtil.find(text)
                if (d != null) {
                    prefs.edit().putString(url, d).apply()
                    return d
                }
            }
            return null
        } finally {
            root.removeView(web)
            web.destroy()
        }
    }
}
