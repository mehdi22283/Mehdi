package com.mehdi.keymapper;

import android.os.IBinder;
import android.os.SystemClock;
import android.view.InputEvent;
import android.view.KeyEvent;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * ADB ilə (shell istifadəçisi kimi) TV-də başladılır. 127.0.0.1-də dinləyir,
 * düymə əmrlərini dərhal sistemə inject edir.
 * Protokol (sətir-sətir): ilk sətir token, sonra "D kod təkrar" | "U kod" | "T kod".
 */
public class Injector {
    static final int VERSION = 1;
    static Object im;
    static Method inject;
    static long downTime = 0;

    public static void main(String[] args) throws Exception {
        int port = Integer.parseInt(args[0]);
        final String token = args[1];

        Class<?> sm = Class.forName("android.os.ServiceManager");
        IBinder binder = (IBinder) sm.getMethod("getService", String.class).invoke(null, "input");
        Class<?> stub = Class.forName("android.hardware.input.IInputManager$Stub");
        im = stub.getMethod("asInterface", IBinder.class).invoke(null, binder);
        Class<?> iface = Class.forName("android.hardware.input.IInputManager");
        inject = iface.getMethod("injectInputEvent", InputEvent.class, int.class);

        ServerSocket server = new ServerSocket(port, 4, InetAddress.getByName("127.0.0.1"));
        System.out.println("READY");
        System.out.flush();

        while (true) {
            final Socket s = server.accept();
            Thread t = new Thread(new Runnable() {
                public void run() {
                    serve(s, token);
                }
            });
            t.setDaemon(true);
            t.start();
        }
    }

    static void serve(Socket s, String token) {
        Set<Integer> held = new HashSet<Integer>();
        try {
            s.setTcpNoDelay(true);
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream()));
            String first = r.readLine();
            if (first == null || !first.equals(token)) {
                s.close();
                return;
            }
            OutputStream o = s.getOutputStream();
            o.write(("OK " + VERSION + "\n").getBytes());
            o.flush();

            String line;
            while ((line = r.readLine()) != null) {
                try {
                    handle(line.trim(), held);
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        } finally {
            // bağlantı kəsilsə ilişib qalmış düymələri burax
            Iterator<Integer> it = held.iterator();
            while (it.hasNext()) {
                try {
                    send(KeyEvent.ACTION_UP, it.next().intValue(), 0);
                } catch (Throwable ignored) {
                }
            }
            try {
                s.close();
            } catch (Throwable ignored) {
            }
        }
    }

    static void handle(String l, Set<Integer> held) throws Exception {
        if (l.length() == 0) return;
        String[] p = l.split(" ");
        char c = p[0].charAt(0);
        int code = Integer.parseInt(p[1]);
        if (c == 'D') {
            int rep = p.length > 2 ? Integer.parseInt(p[2]) : 0;
            held.add(Integer.valueOf(code));
            send(KeyEvent.ACTION_DOWN, code, rep);
        } else if (c == 'U') {
            held.remove(Integer.valueOf(code));
            send(KeyEvent.ACTION_UP, code, 0);
        } else if (c == 'T') {
            send(KeyEvent.ACTION_DOWN, code, 0);
            send(KeyEvent.ACTION_UP, code, 0);
        }
    }

    static synchronized void send(int action, int code, int repeat) throws Exception {
        long now = SystemClock.uptimeMillis();
        if (action == KeyEvent.ACTION_DOWN && repeat == 0) downTime = now;
        if (downTime == 0) downTime = now;
        KeyEvent ev = new KeyEvent(downTime, now, action, code, repeat, 0, -1, 0, 0, 0x301);
        inject.invoke(im, ev, 0); // 0 = ASYNC
    }
}
