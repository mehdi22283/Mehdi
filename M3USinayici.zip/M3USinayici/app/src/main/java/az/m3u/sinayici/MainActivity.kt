package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.provider.OpenableColumns
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var prevLogin = ""
    private val pool = Executors.newFixedThreadPool(24)
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var ghCfg: JSONObject? = null
    private var pendingName = ""
    private var pendingText = ""
    /** Xarici tətbiqdən (fayl meneceri, Paylaş) gələn .m3u/.m3u8 faylları: JS götürənə qədər burada gözləyir. */
    private val pendingExt = ArrayList<Pair<String, String>>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("m3u", MODE_PRIVATE)
        prevLogin = sp.getString("lastLogin", "") ?: ""
        sp.edit().putString("lastLogin", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())).apply()
        web = WebView(this); setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = true
            allowFileAccessFromFileURLs = true; allowUniversalAccessFromFileURLs = true
        }
        web.addJavascriptInterface(Bridge(), "Android")
        if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                val pick = Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                if (p?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                startActivityForResult(pick, 2)
                return true
            }
            override fun onJsAlert(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r?.confirm() }
                    .setOnCancelListener { r?.cancel() }.show(); return true
            }
            override fun onJsConfirm(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r?.confirm() }
                    .setNegativeButton("Ləğv et") { _, _ -> r?.cancel() }.setOnCancelListener { r?.cancel() }.show(); return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        if (b == null) handleExternalIntent(intent)
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        if (i != null) { setIntent(i); handleExternalIntent(i) }
    }

    /** .m3u/.m3u8 faylı başqa tətbiqdən "Bununla aç" / "Paylaş" ilə gələndə oxuyub 2-ci playlistə yükləməyə hazırlayır. */
    @Suppress("DEPRECATION")
    private fun handleExternalIntent(i: Intent?) {
        if (i == null) return
        if ((i.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) return
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_VIEW -> i.data?.let { uris.add(it) }
            Intent.ACTION_SEND -> (if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> (if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM))?.let { uris.addAll(it) }
            else -> return
        }
        if (uris.isEmpty()) return
        pool.execute {
            var added = 0
            for (u in uris) {
                try {
                    var name = ""
                    if (u.scheme == "content") {
                        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                            if (c.moveToFirst()) name = c.getString(0) ?: ""
                        }
                    }
                    if (name.isEmpty()) name = u.lastPathSegment?.substringAfterLast('/') ?: "playlist.m3u"
                    val bytes = contentResolver.openInputStream(u)?.use { it.readBytes() } ?: continue
                    if (bytes.size > 30 * 1024 * 1024) continue
                    var text = String(bytes, Charsets.UTF_8)
                    if (text.startsWith("\uFEFF")) text = text.substring(1)
                    synchronized(pendingExt) { pendingExt.add(Pair(name, text)) }
                    added++
                } catch (e: Exception) { /* oxunmayan fayl keçilir */ }
            }
            runOnUiThread {
                if (added == 0) Toast.makeText(this, "Fayl oxunmadı", Toast.LENGTH_LONG).show()
                else web.evaluateJavascript("if(window.loadExternalPlaylists)loadExternalPlaylists()", null)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("if(window.syncLast)syncLast();if(window.syncExo)syncExo();if(window.loadExternalPlaylists)loadExternalPlaylists()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq == 2) {
            var res: Array<Uri>? = null
            if (rs == RESULT_OK && d != null) {
                val cd = d.clipData
                res = if (cd != null && cd.itemCount > 0) Array(cd.itemCount) { k -> cd.getItemAt(k).uri }
                      else d.data?.let { arrayOf(it) }
            }
            fileCb?.onReceiveValue(res); fileCb = null
        } else if (rq == 1 && rs == RESULT_OK) web.evaluateJavascript("ottImportFromNative(" + (d?.getIntExtra("list", 1) ?: 1) + ")", null)
        else if (rq == 4 && rs == RESULT_OK && d?.data != null) ghUpload(d.data!!)
    }

    /** Playlisti Downloads qovluğuna yazır (Android 10+: MediaStore, əvvəlki: birbaşa fayl). */
    private fun writeToDownloads(name: String, text: String) {
        try {
            val bytes = text.toByteArray(Charsets.UTF_8)
            val shown: String
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "audio/x-mpegurl")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: throw java.io.IOException("Fayl yaradıla bilmədi")
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                shown = name
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                var f = File(dir, name); var i = 1
                while (f.exists()) { f = File(dir, name.substringBeforeLast('.') + " ($i)." + name.substringAfterLast('.')); i++ }
                f.writeBytes(bytes)
                shown = f.name
            }
            Toast.makeText(this, "Downloads qovluğuna yazıldı: $shown", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "İxrac xətası: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportPlaylist(name: String, text: String) {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingName = name; pendingText = text
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 3)
        } else writeToDownloads(name, text)
    }

    override fun onRequestPermissionsResult(rq: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(rq, p, g)
        if (rq == 3) {
            if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) writeToDownloads(pendingName, pendingText)
            else Toast.makeText(this, "İcazə verilmədi", Toast.LENGTH_LONG).show()
            pendingText = ""
        }
    }

    // ---------- GitHub: fayl seç və yüklə (native) ----------
    private fun encPath(p: String) = p.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    private fun ghUpload(uri: Uri) {
        val cfg = ghCfg ?: return
        ghUploadBytes(cfg, null) {
            var name = "file"
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) name = it.getString(0) ?: name
            }
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Fayl oxuna bilmədi")
            Pair(name, bytes)
        }
    }

    /** İxrac: playlisti Downloads-a yox, yalnız GitHub "Fayl seç və yüklə" bölməsinin repo qoşulmasına yükləyir. */
    private fun ghUploadText(cfgJson: String, name: String, text: String) {
        val cfg = try { JSONObject(cfgJson) } catch (e: Exception) {
            Toast.makeText(this, "GitHub ayarları oxunmadı", Toast.LENGTH_LONG).show(); return
        }
        ghUploadBytes(cfg, null) { Pair(name, text.toByteArray(Charsets.UTF_8)) }
    }

    private fun ghUploadBytes(cfg: JSONObject, unused: Any?, source: () -> Pair<String, ByteArray>) {
        web.evaluateJavascript("if(window.ghNativeBusy)ghNativeBusy()", null)
        Thread {
            val res = JSONObject()
            try {
                val (name, bytes) = source()
                if (bytes.size > 25 * 1024 * 1024) throw IOException("Fayl çox böyükdür (maks. 25 MB)")
                val repo = cfg.getString("repo").trim().trim('/')
                val branch = cfg.optString("branch", "main").ifEmpty { "main" }
                val folder = cfg.optString("folder", "").trim().trim('/')
                val safe = name.replace(Regex("[^\\w.\\-]+"), "_")
                val stamped = "${System.currentTimeMillis()}-$safe"
                val path = if (folder.isNotEmpty()) "$folder/$stamped" else stamped
                val body = JSONObject()
                    .put("message", "M3U Sınayıcı: \"$name\" yükləndi")
                    .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
                    .put("branch", branch)
                val c = URL("https://api.github.com/repos/$repo/contents/${encPath(path)}").openConnection() as HttpURLConnection
                c.requestMethod = "PUT"; c.doOutput = true
                c.connectTimeout = 20000; c.readTimeout = 60000
                val tk = cfg.getString("token").replace(Regex("(?i)^\\s*(bearer|token)\\s+"), "").replace(Regex("[\\s\"']+"), "")
                c.setRequestProperty("Authorization", "Bearer $tk")
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("User-Agent", "M3USinayici")
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                c.disconnect()
                val j = try { JSONObject(txt) } catch (e: Exception) { JSONObject() }
                if (code == 401) throw IOException("Token yanlışdır, vaxtı bitib və ya ləğv edilib (401). GitHub-da yeni token yaradıb \"GitHub-a daxil ol\" bölməsində yeniləyin.")
                if (code == 403 || code == 404) throw IOException(j.optString("message", "HTTP $code") + " — token bu repoya yazma icazəsinə (Contents: Read and write) malik olmaya bilər, ya da repo adı səhvdir.")
                if (code !in 200..299) throw IOException(j.optString("message", "GitHub xətası (HTTP $code)"))
                val content = j.getJSONObject("content")
                val p = content.getString("path")
                res.put("ok", true).put("name", name).put("path", p).put("sha", content.getString("sha"))
                    .put("rawUrl", "https://raw.githubusercontent.com/$repo/$branch/${encPath(p)}")
                    .put("blobUrl", "https://github.com/$repo/blob/$branch/${encPath(p)}")
            } catch (e: Exception) {
                res.put("ok", false).put("error", e.message ?: e.toString())
            }
            runOnUiThread { web.evaluateJavascript("ghNativeDone(" + JSONObject.quote(res.toString()) + ")", null) }
        }.start()
    }

    inner class Bridge {
        /** JS çağırır: xarici tətbiqdən gələn faylları [{name,text}] kimi qaytarır və növbəni təmizləyir. */
        @JavascriptInterface fun takeExternalFiles(): String {
            val out = JSONArray()
            synchronized(pendingExt) {
                pendingExt.forEach { out.put(JSONObject().put("name", it.first).put("text", it.second)) }
                pendingExt.clear()
            }
            return out.toString()
        }
        @JavascriptInterface fun openChannelSearch(n: Int, json: String) {
            val arr = JSONArray(json)
            val chans = ArrayList<ChannelSearch.Ch>(arr.length())
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                chans.add(ChannelSearch.Ch(a.getString(0), a.optString(1).ifEmpty { "Digər" }, a.getString(2), a.optJSONObject(3)?.toString() ?: "{}", n))
            }
            runOnUiThread { ChannelSearch.show(this@MainActivity, n, chans) }
        }
        @JavascriptInterface fun openOtt() = runOnUiThread { startActivityForResult(Intent(this@MainActivity, BrowserActivity::class.java), 1) }
        /** Mini brauzer: ünvan qutusu olan sərbəst brauzer. */
        @JavascriptInterface fun openMini() = runOnUiThread {
            if (MiniBrowser.isOpen()) Toast.makeText(this@MainActivity, "Mini brauzer artıq açıqdır", Toast.LENGTH_SHORT).show()
            else startActivityForResult(Intent(this@MainActivity, BrowserActivity::class.java).putExtra("mini", true), 1)
        }
        /** ExoPlayer-in xəta verdiyi kanalların linkləri (JSON massiv). */
        @JavascriptInterface fun getExoFailed(): String = JSONArray(Net.exoFailedList()).toString()
        @JavascriptInterface fun playQueue(json: String, index: Int) {
            val arr = JSONArray(json)
            val list = ArrayList<QItem>(arr.length())
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                list.add(QItem(a.getString(0), a.getString(1), a.optJSONObject(2)?.toString() ?: "{}"))
            }
            PlayQueue.items = list; PlayQueue.index = index
            runOnUiThread { startActivity(Intent(this@MainActivity, PlayerActivity::class.java)) }
        }
        @JavascriptInterface fun probe(url: String, hdr: String, id: Int) {
            pool.execute {
                val r = Net.probe(url, hdr)
                runOnUiThread { web.evaluateJavascript("__probeDone($id,'$r')", null) }
            }
        }
        @JavascriptInterface fun getSavedPlaylist(): String {
            val f = File(filesDir, "playlist1.m3u"); return if (f.exists()) f.readText() else ""
        }
        @JavascriptInterface fun getSavedPlaylist2(): String {
            val f = File(filesDir, "playlist2.m3u"); return if (f.exists()) f.readText() else ""
        }
        @JavascriptInterface fun getSavedPlaylist2Url(): String {
            val f = File(filesDir, "playlist2.url"); return if (f.exists()) f.readText().trim() else ""
        }
        @JavascriptInterface fun getLastLogin(): String = prevLogin
        /** GitHub axtarışı üçün daxili brauzer: tapılan playlist [list]-ci siyahıya yüklənir; token API limiti üçündür. */
        @JavascriptInterface fun openBrowser(url: String, list: Int, token: String) = runOnUiThread {
            startActivityForResult(Intent(this@MainActivity, BrowserActivity::class.java)
                .putExtra("url", url).putExtra("list", list).putExtra("token", token), 1)
        }
        @JavascriptInterface fun ghPick(cfgJson: String) = runOnUiThread {
            try {
                ghCfg = JSONObject(cfgJson)
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 4)
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "Fayl seçici açılmadı: ${e.message}", Toast.LENGTH_LONG).show() }
        }
        @JavascriptInterface fun ghExport(cfgJson: String, name: String, text: String) = runOnUiThread {
            try { ghUploadText(cfgJson, name, text) }
            catch (e: Exception) { Toast.makeText(this@MainActivity, "İxrac xətası: ${e.message}", Toast.LENGTH_LONG).show() }
        }
        @JavascriptInterface fun getLastUrl(): String = getSharedPreferences("m3u", MODE_PRIVATE).getString("lastUrl", "") ?: ""
        @JavascriptInterface fun saveToDownloads(name: String, text: String) = runOnUiThread { exportPlaylist(name, text) }
    }
}
