package az.axtaris.baza

import android.app.Activity
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import java.io.File
import java.util.Locale

data class Card(val path: String, val title: String, val headers: List<String>, val cells: List<String>)

class MainActivity : Activity() {

    private lateinit var db: SQLiteDatabase
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var mainSearch: SearchUi
    private lateinit var catSearch: SearchUi
    private lateinit var searchPanel: LinearLayout
    private lateinit var catPanel: LinearLayout
    private lateinit var btnSearch: Button
    private lateinit var btnCat: Button

    // catalog state
    private lateinit var tvPath: TextView
    private lateinit var tvTotal: TextView
    private lateinit var catList: ListView
    private val cardAdapterCat by lazy { CardAdapter() }
    private var level = 0
    private var fileId = 0L
    private var streetId = 0L
    private var buildingId = 0L
    private var fileName = ""
    private var streetName = ""
    private var catIds = ArrayList<Long>()
    private var catNames = ArrayList<String>()
    private var catCounts = ArrayList<Int>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = openDb()
        buildUi()
        showTab(true)
    }

    // ---------- database ----------
    private fun openDb(): SQLiteDatabase {
        val f = File(filesDir, "data.db")
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val ver = 2
        if (!f.exists() || prefs.getInt("dbver", 0) != ver) {
            assets.open("data.db").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            prefs.edit().putInt("dbver", ver).apply()
        }
        return SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY)
    }

    private fun fold(s: String): String {
        var t = s.replace('İ', 'i').replace('I', 'ı').lowercase(Locale.ROOT)
        t = t.replace('ə', 'e').replace('ı', 'i').replace('ö', 'o').replace('ü', 'u')
            .replace('ş', 's').replace('ç', 'c').replace('ğ', 'g')
        return t.trim().replace(Regex("\\s+"), " ")
    }

    private fun jsonList(s: String): List<String> {
        val a = JSONArray(s); return List(a.length()) { a.getString(it) }
    }

    private fun rowOf(vararg items: Pair<View, Float>): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            items.forEachIndexed { i, (v, w) ->
                addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w).apply {
                    if (i > 0) leftMargin = dp(6)
                })
            }
        }

    // =====================================================================
    //  Axtarış bölməsi (həm "Axtarış" tabında, həm kataloqun hər səviyyəsində)
    // =====================================================================
    /**
     * scope: axtarışın daraldığı yer — (SQL şərti, arqument) və ya null (hər yer).
     * onActive: xanalardan biri dolu olanda true (kataloqda siyahını nəticələrlə əvəz etmək üçün).
     */
    inner class SearchUi(
        private val scope: () -> Pair<String, String>?,
        private val onActive: (Boolean) -> Unit
    ) {
        private val tokS = Any()
        private val tokG = Any()
        private var searchGen = 0
        private var sugGen = 0
        private var suppress = false
        private val adapter = CardAdapter()

        val etStreet: EditText = edit("Küçə adı", "street")
        val etMenzil: EditText = edit("Mənzil", "menzil")
        val etSoyad: EditText = edit("Soyad", "soyad")
        val etAd: EditText = edit("Ad", "ad")
        val etAta: EditText = edit("Atasının adı", "ata")
        val etNomre: EditText = edit("Nömrə", "nomre", InputType.TYPE_CLASS_PHONE)

        val form = LinearLayout(this@MainActivity)
        private val row2 = rowOf(etMenzil to 0.8f, etSoyad to 1.1f, etAd to 1f)
        private val row3 = rowOf(etAta to 1f, etNomre to 1f)
        private val sugBox = LinearLayout(this@MainActivity)
        val tvCount = TextView(this@MainActivity)
        val results = ListView(this@MainActivity)
        val resultsBox = LinearLayout(this@MainActivity)

        init {
            form.orientation = LinearLayout.VERTICAL
            form.setPadding(dp(8), dp(4), dp(8), dp(4))
            // Küçə adı — ən yuxarıda, qalanları onun altında
            form.addView(etStreet, LinearLayout.LayoutParams(-1, -2))
            form.addView(row2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            form.addView(row3, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

            sugBox.orientation = LinearLayout.VERTICAL
            sugBox.visibility = View.GONE
            sugBox.elevation = dp(6).toFloat()
            sugBox.background = GradientDrawable().apply {
                setColor(Color.WHITE); setStroke(dp(1), Color.parseColor("#B0BEC5")); cornerRadius = dp(8).toFloat()
            }
            form.addView(sugBox, 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })

            val btnClear = Button(this@MainActivity)
            btnClear.text = "Təmizlə"
            btnClear.setOnClickListener { clear(); scheduleSearch() }
            form.addView(btnClear, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

            tvCount.textSize = 13f
            tvCount.setPadding(dp(12), dp(2), dp(12), dp(4))
            tvCount.setTextColor(Color.DKGRAY)
            results.divider = null
            results.adapter = adapter
            results.clipToPadding = false
            results.setPadding(dp(8), 0, dp(8), dp(8))
            results.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) hideSug(); false }
            resultsBox.orientation = LinearLayout.VERTICAL
            resultsBox.addView(tvCount)
            resultsBox.addView(results, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        private fun edit(hint: String, key: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
            val e = EditText(this@MainActivity)
            e.hint = hint
            e.textSize = 14f
            e.isSingleLine = true
            e.inputType = type or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            e.imeOptions = EditorInfo.IME_ACTION_SEARCH
            e.setPadding(dp(8), dp(10), dp(8), dp(10))
            e.background = GradientDrawable().apply {
                setColor(Color.WHITE); setStroke(dp(1), Color.parseColor("#B0BEC5")); cornerRadius = dp(8).toFloat()
            }
            e.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (suppress) return
                    scheduleSearch(); scheduleSuggest(key)
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            e.setOnFocusChangeListener { _, has -> if (has) scheduleSuggest(key) }
            e.setOnEditorActionListener { v, _, _ ->
                hideSug()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(v.windowToken, 0)
                true
            }
            return e
        }

        private fun fieldOf(key: String): EditText = when (key) {
            "street" -> etStreet; "menzil" -> etMenzil; "soyad" -> etSoyad
            "ad" -> etAd; "ata" -> etAta; else -> etNomre
        }

        fun isEmpty(): Boolean =
            listOf(etStreet, etMenzil, etSoyad, etAd, etAta).all { fold(it.text.toString()).isEmpty() } &&
                etNomre.text.toString().none { it.isDigit() }

        fun clear() {
            suppress = true
            listOf(etStreet, etMenzil, etSoyad, etAd, etAta, etNomre).forEach { it.setText("") }
            suppress = false
            hideSug()
        }

        fun hideSug() {
            sugGen++
            sugBox.visibility = View.GONE
        }

        fun sugVisible() = sugBox.visibility == View.VISIBLE

        private fun buildWhere(exclude: String?, where: ArrayList<String>, args: ArrayList<String>) {
            scope()?.let { where.add(it.first); args.add(it.second) }
            if (exclude != "street") fold(etStreet.text.toString()).split(' ').filter { it.isNotEmpty() }
                .forEach { where.add("b.name_n LIKE ?"); args.add("%$it%") }
            val mz = fold(etMenzil.text.toString())
            if (exclude != "menzil" && mz.isNotEmpty()) { where.add("r.menzil_n = ?"); args.add(mz) }
            val so = fold(etSoyad.text.toString())
            if (exclude != "soyad" && so.isNotEmpty()) { where.add("r.soyad_n LIKE ?"); args.add("%$so%") }
            val ad = fold(etAd.text.toString())
            if (exclude != "ad" && ad.isNotEmpty()) { where.add("r.ad_n LIKE ?"); args.add("%$ad%") }
            val at = fold(etAta.text.toString())
            if (exclude != "ata" && at.isNotEmpty()) { where.add("r.ata_n LIKE ?"); args.add("%$at%") }
            val nr = etNomre.text.toString().filter { it.isDigit() }
            if (exclude != "nomre" && nr.isNotEmpty()) { where.add("r.nomre_d LIKE ?"); args.add("%$nr%") }
        }

        // ----- təkliflər -----
        private fun scheduleSuggest(key: String) {
            ui.removeCallbacksAndMessages(tokG)
            ui.postAtTime({ doSuggest(key) }, tokG, SystemClock.uptimeMillis() + 120)
        }

        private fun doSuggest(key: String) {
            val et = fieldOf(key)
            val q = fold(et.text.toString())
            if (key == "nomre" || q.isEmpty() || !et.hasFocus()) { hideSug(); return }
            val gen = ++sugGen
            Thread {
                val items = ArrayList<String>()
                try {
                    if (key == "street") {
                        val toks = q.split(' ').filter { it.isNotEmpty() }
                        val where = ArrayList<String>(); val args = ArrayList<String>()
                        scope()?.let { where.add(it.first); args.add(it.second) }
                        toks.forEach { where.add("b.name_n LIKE ?"); args.add("%$it%") }
                        val w = where.joinToString(" AND ")
                        db.rawQuery(
                            "SELECT DISTINCT s.name FROM streets s JOIN buildings b ON b.street_id = s.id WHERE $w ORDER BY s.name LIMIT 4",
                            args.toTypedArray()
                        ).use { c -> while (c.moveToNext()) items.add(c.getString(0)) }
                        db.rawQuery(
                            "SELECT DISTINCT b.name FROM buildings b WHERE $w ORDER BY b.file_id, b.ord LIMIT 10",
                            args.toTypedArray()
                        ).use { c -> while (c.moveToNext()) { val n = c.getString(0); if (n !in items) items.add(n) } }
                    } else {
                        val col = when (key) { "menzil" -> "r.menzil"; "soyad" -> "r.soyad"; "ad" -> "r.ad"; else -> "r.ata" }
                        val where = ArrayList<String>(); val args = ArrayList<String>()
                        buildWhere(key, where, args)
                        where.add("${col}_n LIKE ?"); args.add("$q%")
                        where.add("$col <> ''")
                        db.rawQuery(
                            "SELECT DISTINCT $col FROM rows r JOIN buildings b ON b.id = r.building_id WHERE " +
                                where.joinToString(" AND ") + " ORDER BY ${col}_n LIMIT 8", args.toTypedArray()
                        ).use { c -> while (c.moveToNext()) items.add(c.getString(0)) }
                    }
                } catch (e: Exception) { /* ignore */ }
                runOnUiThread { if (gen == sugGen) showSug(key, items) }
            }.start()
        }

        private fun showSug(key: String, items: List<String>) {
            if (items.isEmpty()) { sugBox.visibility = View.GONE; return }
            val anchor: View = when (key) { "street" -> etStreet; "menzil", "soyad", "ad" -> row2; else -> row3 }
            form.removeView(sugBox)
            form.addView(sugBox, form.indexOfChild(anchor) + 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
            sugBox.removeAllViews()
            items.forEachIndexed { idx, text ->
                val tv = TextView(this@MainActivity)
                tv.text = "🔍  $text"; tv.textSize = 15f; tv.setTextColor(Color.parseColor("#263238"))
                tv.setPadding(dp(12), dp(11), dp(12), dp(11))
                tv.setOnClickListener {
                    val f = fieldOf(key)
                    suppress = true
                    f.setText(items[idx])
                    f.setSelection(f.text.length)
                    suppress = false
                    hideSug(); scheduleSearch()
                }
                sugBox.addView(tv)
            }
            sugBox.visibility = View.VISIBLE
        }

        // ----- axtarış -----
        fun scheduleSearch() {
            onActive(!isEmpty())
            ui.removeCallbacksAndMessages(tokS)
            ui.postAtTime({ doSearch() }, tokS, SystemClock.uptimeMillis() + 250)
        }

        private fun doSearch() {
            if (isEmpty()) {
                adapter.set(emptyList()); tvCount.text = "Axtarmaq üçün yuxarıdakı xanalara yazın"; return
            }
            val gen = ++searchGen
            Thread {
                val where = ArrayList<String>(); val args = ArrayList<String>()
                buildWhere(null, where, args)
                val sql = "SELECT r.cells, b.headers, b.name, b.title, f.name FROM rows r " +
                    "JOIN buildings b ON b.id = r.building_id JOIN files f ON f.id = b.file_id " +
                    "WHERE " + where.joinToString(" AND ") + " ORDER BY f.ord, b.ord, r.ord LIMIT 201"
                val list = ArrayList<Card>()
                try {
                    db.rawQuery(sql, args.toTypedArray()).use { c ->
                        while (c.moveToNext()) {
                            list.add(Card(
                                path = c.getString(4) + "  ›  " + c.getString(2),
                                title = c.getString(3),
                                headers = jsonList(c.getString(1)),
                                cells = jsonList(c.getString(0))
                            ))
                        }
                    }
                } catch (e: Exception) { /* ignore */ }
                runOnUiThread {
                    if (gen == searchGen) {
                        val more = list.size > 200
                        val shown = if (more) list.subList(0, 200) else list
                        adapter.set(shown)
                        tvCount.text = if (shown.isEmpty()) "Nəticə tapılmadı"
                        else if (more) "İlk 200 nəticə göstərilir — axtarışı dəqiqləşdirin" else "${shown.size} nəticə"
                        results.setSelection(0)
                    }
                }
            }.start()
        }
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#ECEFF1"))
        }

        btnSearch = Button(this).apply { text = "Axtarış"; setOnClickListener { showTab(true) } }
        btnCat = Button(this).apply { text = "Kataloq"; setOnClickListener { showTab(false) } }
        root.addView(rowOf(btnSearch to 1f, btnCat to 1f), LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(24); leftMargin = dp(8); rightMargin = dp(8)
        })

        // ----- Axtarış tabı (bütün bazada) -----
        mainSearch = SearchUi(scope = { null }, onActive = { })
        searchPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        searchPanel.addView(mainSearch.form)
        searchPanel.addView(mainSearch.resultsBox, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(searchPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        // ----- Kataloq tabı: başlıq (sağda ümumi mənzil sayı) + axtarış + siyahı -----
        catList = ListView(this)
        catSearch = SearchUi(
            scope = {
                when (level) {
                    1 -> Pair("b.file_id = ?", fileId.toString())
                    2 -> Pair("b.street_id = ?", streetId.toString())
                    3 -> Pair("b.id = ?", buildingId.toString())
                    else -> null
                }
            },
            onActive = { active ->
                catSearch.resultsBox.visibility = if (active) View.VISIBLE else View.GONE
                catList.visibility = if (active) View.GONE else View.VISIBLE
            }
        )
        catPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvPath = TextView(this).apply {
            textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#263238"))
        }
        tvTotal = TextView(this).apply {
            textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#1565C0"))
            gravity = Gravity.END
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            addView(tvPath, LinearLayout.LayoutParams(0, -2, 1f))
            addView(tvTotal, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        }
        catPanel.addView(header)
        catPanel.addView(catSearch.form)
        val frame = FrameLayout(this)
        frame.addView(catList, FrameLayout.LayoutParams(-1, -1))
        catSearch.resultsBox.visibility = View.GONE
        frame.addView(catSearch.resultsBox, FrameLayout.LayoutParams(-1, -1))
        catPanel.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(catPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        catList.setOnItemClickListener { _, _, pos, _ ->
            if (level < 3) openChild(catIds[pos], catNames[pos])
        }

        setContentView(root)
        loadLevel()
    }

    private fun showTab(search: Boolean) {
        searchPanel.visibility = if (search) View.VISIBLE else View.GONE
        catPanel.visibility = if (search) View.GONE else View.VISIBLE
        btnSearch.alpha = if (search) 1f else 0.55f
        btnCat.alpha = if (search) 0.55f else 1f
        if (search) { catSearch.hideSug(); mainSearch.scheduleSearch() } else { mainSearch.hideSug() }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (catPanel.visibility == View.VISIBLE) {
            if (catSearch.sugVisible()) { catSearch.hideSug(); return }
            if (!catSearch.isEmpty()) { catSearch.clear(); catSearch.scheduleSearch(); return }
            if (level > 0) { level--; loadLevel() } else showTab(true)
        } else {
            if (mainSearch.sugVisible()) { mainSearch.hideSug(); return }
            super.onBackPressed()
        }
    }

    // ---------- kataloq ----------
    private fun openChild(id: Long, label: String) {
        when (level) {
            0 -> { fileId = id; fileName = label }
            1 -> { streetId = id; streetName = label }
            2 -> { buildingId = id }
        }
        level++; loadLevel()
    }

    private fun loadLevel() {
        catSearch.clear()
        catSearch.resultsBox.visibility = View.GONE
        catList.visibility = View.VISIBLE
        catIds = ArrayList(); catNames = ArrayList(); catCounts = ArrayList()
        when (level) {
            0 -> {
                tvPath.text = "Əsas kateqoriya (fayl)"
                db.rawQuery(
                    "SELECT f.id, f.name, COUNT(r.id) FROM files f JOIN buildings b ON b.file_id = f.id " +
                        "JOIN rows r ON r.building_id = b.id GROUP BY f.id ORDER BY f.ord", null
                ).use { c -> while (c.moveToNext()) { catIds.add(c.getLong(0)); catNames.add(c.getString(1)); catCounts.add(c.getInt(2)) } }
            }
            1 -> {
                tvPath.text = fileName
                db.rawQuery(
                    "SELECT s.id, s.name, COUNT(r.id) FROM streets s JOIN buildings b ON b.street_id = s.id " +
                        "JOIN rows r ON r.building_id = b.id WHERE s.file_id = ? GROUP BY s.id ORDER BY s.ord",
                    arrayOf(fileId.toString())
                ).use { c -> while (c.moveToNext()) { catIds.add(c.getLong(0)); catNames.add(c.getString(1)); catCounts.add(c.getInt(2)) } }
            }
            2 -> {
                tvPath.text = "$fileName  ›  $streetName"
                db.rawQuery(
                    "SELECT b.id, b.name, COUNT(r.id) FROM buildings b JOIN rows r ON r.building_id = b.id " +
                        "WHERE b.street_id = ? GROUP BY b.id ORDER BY b.ord",
                    arrayOf(streetId.toString())
                ).use { c -> while (c.moveToNext()) { catIds.add(c.getLong(0)); catNames.add(c.getString(1)); catCounts.add(c.getInt(2)) } }
            }
            3 -> {
                val cards = ArrayList<Card>()
                db.rawQuery("SELECT headers, name, title FROM buildings WHERE id=?", arrayOf(buildingId.toString())).use { b ->
                    if (b.moveToFirst()) {
                        val hdr = jsonList(b.getString(0)); val nm = b.getString(1); val title = b.getString(2)
                        tvPath.text = "$fileName  ›  $nm"
                        db.rawQuery("SELECT cells FROM rows WHERE building_id=? ORDER BY ord", arrayOf(buildingId.toString())).use { c ->
                            while (c.moveToNext()) cards.add(Card("", title, hdr, jsonList(c.getString(0))))
                        }
                    }
                }
                tvTotal.text = "(${cards.size})"
                cardAdapterCat.set(cards)
                catList.divider = null
                catList.adapter = cardAdapterCat
                catList.clipToPadding = false
                catList.setPadding(dp(8), 0, dp(8), dp(8))
                return
            }
        }
        tvTotal.text = "(${catCounts.sum()})"
        catList.divider = ColorDrawable(Color.parseColor("#CFD8DC"))
        catList.dividerHeight = 1
        catList.setPadding(0, 0, 0, 0)
        catList.adapter = CatAdapter()
    }

    /** Ad solda, ümumi mənzil sayı mötərizədə sağda */
    inner class CatAdapter : BaseAdapter() {
        override fun getCount() = catNames.size
        override fun getItem(position: Int) = catNames[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setBackgroundColor(Color.WHITE)
            row.setPadding(dp(14), dp(14), dp(14), dp(14))
            val name = TextView(this@MainActivity)
            name.text = catNames[position]; name.textSize = 15f; name.setTextColor(Color.parseColor("#263238"))
            val cnt = TextView(this@MainActivity)
            cnt.text = "(${catCounts[position]})"; cnt.textSize = 15f
            cnt.typeface = Typeface.DEFAULT_BOLD; cnt.setTextColor(Color.parseColor("#1565C0")); cnt.gravity = Gravity.END
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(cnt, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
            return row
        }
    }

    // ---------- nəticə kartları ----------
    inner class CardAdapter : BaseAdapter() {
        private var items: List<Card> = emptyList()
        fun set(l: List<Card>) { items = l; notifyDataSetChanged() }
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val c = items[position]
            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = dp(10).toFloat(); setStroke(dp(1), Color.parseColor("#CFD8DC"))
                }
            }
            if (c.path.isNotEmpty()) box.addView(TextView(this@MainActivity).apply {
                text = c.path; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#1565C0"))
            })
            if (c.title.isNotEmpty()) box.addView(TextView(this@MainActivity).apply {
                text = c.title; textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 0, 0, dp(4))
            })
            for (i in c.headers.indices) {
                val v = c.cells.getOrNull(i).orEmpty().ifEmpty { "—" }
                box.addView(TextView(this@MainActivity).apply {
                    text = "${c.headers[i]}: $v"; textSize = 14f; setTextColor(Color.parseColor("#263238"))
                    setTextIsSelectable(true)
                })
            }
            val wrap = FrameLayout(this@MainActivity).apply {
                setPadding(0, dp(3), 0, dp(3)); layoutParams = AbsListView.LayoutParams(-1, -2)
            }
            wrap.addView(box, FrameLayout.LayoutParams(-1, -2))
            return wrap
        }
    }
}
