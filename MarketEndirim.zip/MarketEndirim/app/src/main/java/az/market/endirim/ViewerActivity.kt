package az.market.endirim

import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlinx.coroutines.launch

class ViewerActivity : AppCompatActivity() {
    private var pdfAdapter: PdfAdapter? = null
    private var pageCb: ViewPager2.OnPageChangeCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)

        @Suppress("DEPRECATION")
        val c = intent.getSerializableExtra("catalog") as Catalog

        val title = findViewById<TextView>(R.id.title)
        val counter = findViewById<TextView>(R.id.counter)
        val pager = findViewById<ViewPager2>(R.id.pager)
        val web = findViewById<WebView>(R.id.web)
        val progress = findViewById<ProgressBar>(R.id.progress)

        val startPage = intent.getIntExtra("page", 0).coerceAtLeast(0)
        val product = intent.getStringExtra("product")
        title.text = c.market + (c.date?.let { "  •  " + DateUtil.info(it).label } ?: "")
        findViewById<View>(R.id.back).setOnClickListener { finish() }

        when (c.kind) {
            Kind.IMAGES -> setPages(pager, counter, ImageAdapter(c.urls), startPage)
            Kind.WEB -> {
                pager.visibility = View.GONE
                web.visibility = View.VISIBLE
                web.settings.javaScriptEnabled = true
                web.settings.domStorageEnabled = true
                web.webViewClient = WebViewClient()
                // Bravo: slaydın içindəki "PDF yüklə" düyməsi tutulur — PDF slaydın yerinə keçir
                if (c.market == BravoPdf.MARKET) {
                    BravoPdf.attach(web, c.urls[0], c.date, lifecycleScope) { ok ->
                        if (ok) {
                            web.stopLoading()
                            web.loadUrl("about:blank")
                            web.visibility = View.GONE
                            pager.visibility = View.VISIBLE
                            showPdf(BravoPdf.LOCAL, 0, pager, counter, progress)
                        }
                    }
                }
                web.loadUrl(c.urls[0])
                if (product != null) Toast.makeText(this, "$product — jurnalın ${startPage + 1}-ci səhifəsi", Toast.LENGTH_LONG).show()
            }
            Kind.PDF -> showPdf(c.urls[0], startPage, pager, counter, progress)
        }
    }

    private fun showPdf(url: String, startPage: Int, pager: ViewPager2, counter: TextView, progress: ProgressBar) {
        progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val f = Downloader.ensure(applicationContext, url)
                val w = (resources.displayMetrics.widthPixels * 1.5f).toInt()
                pdfAdapter?.close()
                val a = PdfAdapter(f, w, lifecycleScope)
                pdfAdapter = a
                setPages(pager, counter, a, startPage)
            } catch (e: Exception) {
                Toast.makeText(this@ViewerActivity, "PDF açılmadı: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    private fun setPages(pager: ViewPager2, counter: TextView, adapter: RecyclerView.Adapter<*>, start: Int = 0) {
        pager.adapter = adapter
        val first = start.coerceIn(0, (adapter.itemCount - 1).coerceAtLeast(0))
        counter.text = "${first + 1}/${adapter.itemCount}"
        if (first > 0) pager.setCurrentItem(first, false)
        pageCb?.let { pager.unregisterOnPageChangeCallback(it) }
        val cb = object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                counter.text = "${position + 1}/${adapter.itemCount}"
            }
        }
        pageCb = cb
        pager.registerOnPageChangeCallback(cb)
    }

    override fun onDestroy() {
        pdfAdapter?.close()
        super.onDestroy()
    }
}
