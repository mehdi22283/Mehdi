package az.airpods.pro2;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx, Intent in) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(in.getAction())) return;
        if (!Prefs.boot(ctx) || !Prefs.wantRun(ctx)) return;
        String perm = Build.VERSION.SDK_INT >= 31
                ? Manifest.permission.BLUETOOTH_SCAN : Manifest.permission.ACCESS_FINE_LOCATION;
        if (ctx.checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) return;
        try {
            ctx.startForegroundService(new Intent(ctx, PodsService.class));
        } catch (Exception ignored) { }
    }
}
