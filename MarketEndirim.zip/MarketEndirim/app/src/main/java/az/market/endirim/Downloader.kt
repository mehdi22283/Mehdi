package az.market.endirim

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

object Downloader {
    private const val UA = "Mozilla/5.0 (Linux; Android 13) Chrome/124.0 Mobile Safari/537.36"
    private val locks = ConcurrentHashMap<String, Any>()

    private fun dir(ctx: Context) = File(ctx.filesDir, "pdfs").apply { mkdirs() }
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("pdfsig", Context.MODE_PRIVATE)

    /** "local:ad.pdf" — internetdən deyil, istifadəçinin özü yüklədiyi (məs. Bravo) PDF; filesDir/localpdfs-də saxlanır. */
    fun isLocal(url: String) = url.startsWith("local:")

    fun fileFor(ctx: Context, url: String): File {
        if (isLocal(url)) return File(File(ctx.filesDir, "localpdfs").apply { mkdirs() }, url.removePrefix("local:"))
        val name = url.substringAfterLast('/').substringBefore('?').takeLast(60)
        return File(dir(ctx), url.hashCode().toUInt().toString(16) + "_" + name)
    }

    /** Serverin verdiyi "barmaq izi": ETag → Last-Modified → Content-Length (prefikslə: e:/m:/l:). */
    private fun sigOf(c: HttpURLConnection): String? {
        c.getHeaderField("ETag")?.let { return "e:$it" }
        c.getHeaderField("Last-Modified")?.let { return "m:$it" }
        c.getHeaderField("Content-Length")?.let { return "l:$it" }
        return null
    }

    /** Yüklənmiş PDF-in yadda saxlanmış izi (yoxdursa null). */
    fun storedSig(ctx: Context, url: String): String? {
        if (isLocal(url)) return fileFor(ctx, url).takeIf { it.exists() }?.let { "m:" + it.lastModified() }
        return prefs(ctx).getString(url, null)
    }

    /** PDF artıq yüklənibsə təkrar yükləmir. */
    suspend fun ensure(ctx: Context, url: String): File = withContext(Dispatchers.IO) {
        val f = fileFor(ctx, url)
        if (isLocal(url)) {
            if (!(f.exists() && f.length() > 0)) throw IOException("PDF tapılmadı")
            return@withContext f
        }
        synchronized(locks.getOrPut(url) { Any() }) {
            if (!(f.exists() && f.length() > 0)) {
                val tmp = File(f.path + ".part")
                val c = URL(url).openConnection() as HttpURLConnection
                try {
                    c.setRequestProperty("User-Agent", UA)
                    c.connectTimeout = 20_000
                    c.readTimeout = 60_000
                    if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
                    val sig = sigOf(c)
                    c.inputStream.use { input -> FileOutputStream(tmp).use { out -> input.copyTo(out) } }
                    if (!tmp.renameTo(f)) throw IOException("Fayl yazıla bilmədi")
                    prefs(ctx).edit().apply { if (sig != null) putString(url, sig) else remove(url) }.apply()
                } finally {
                    c.disconnect()
                    if (tmp.exists()) tmp.delete()
                }
            }
        }
        f
    }

    /** Serverdəki faylın cari izi (HEAD sorğusu); alınmasa null. */
    fun remoteSig(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "HEAD"
            c.setRequestProperty("User-Agent", UA)
            c.connectTimeout = 8_000
            c.readTimeout = 8_000
            if (c.responseCode == 200) sigOf(c) else null
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null
    }

    /**
     * Serverdəki PDF dəyişibsə (eyni linkdə yeni fayl) köhnə nüsxəni, miniatürü, tarix-OCR nəticəsini
     * silir (skan edilmiş məhsullar yenisi skan olunana qədər qalır). Dəyişibsə true qaytarır — sonra ensure() yenisini yükləyir.
     */
    suspend fun refreshIfChanged(ctx: Context, url: String): Boolean = withContext(Dispatchers.IO) {
        if (isLocal(url)) return@withContext false
        val stored = storedSig(ctx, url) ?: return@withContext false
        if (!fileFor(ctx, url).exists()) return@withContext false
        val remote = remoteSig(url) ?: return@withContext false
        if (remote == stored || remote.take(2) != stored.take(2)) return@withContext false
        synchronized(locks.getOrPut(url) { Any() }) {
            val f = fileFor(ctx, url)
            f.delete()
            prefs(ctx).edit().remove(url).apply()
            ctx.getSharedPreferences("ocr", Context.MODE_PRIVATE).edit().remove(f.name).apply()
            Thumbs.file(ctx, url).delete()
        }
        // Köhnə skan nəticələri burada silinmir: yeni PDF yüklənib yenidən skan olunana qədər (və ya internet
        // olmasa) oflayn axtarış köhnə nəticələrlə işləməyə davam edir; skan bitəndə put() onları əvəz edir.
        true
    }

    /** Siyahıda olmayan köhnə PDF-ləri silir. */
    fun cleanup(ctx: Context, keepUrls: List<String>) {
        val keep = keepUrls.map { fileFor(ctx, it).name }.toSet()
        dir(ctx).listFiles()?.forEach { if (it.name !in keep) it.delete() }
    }
}
