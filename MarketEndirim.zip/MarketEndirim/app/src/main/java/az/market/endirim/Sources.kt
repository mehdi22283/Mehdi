package az.market.endirim

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.json.JSONObject
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Sources {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private fun get(url: String): Document =
        Jsoup.connect(url).userAgent(UA).timeout(25_000).followRedirects(true).maxBodySize(0).get()

    // ---------- Bravo: Publuu flipbook (WebView-da açılır) ----------
    suspend fun bravo(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://bravosupermarket.az/special-offers/leaflet/")
        val link = Regex("""https://publuu\.com/flip-book/\d+/\d+""").find(doc.html())?.value
            ?: throw IllegalStateException("Publuu linki tapılmadı")
        listOf(
            Catalog("Bravo Market", "Supermanat Hiper", DateUtil.find(doc.body().text()), Kind.WEB, listOf(link), "Veb-jurnal")
        )
    }

    // ---------- Araz: səhifədə PDF + tarix ----------
    suspend fun araz(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://www.arazmarket.az/az/discount-magazine")
        val links = doc.select("a[href*=.pdf]").toList().filter { it.absUrl("href").isNotEmpty() }
        if (links.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        val seen = HashSet<String>()
        links.mapNotNull { a ->
            val url = a.absUrl("href")
            if (!seen.add(url)) return@mapNotNull null
            val date = dateAround(a) ?: DateUtil.find(doc.body().text())
            Catalog("Araz Market", "Endirim jurnalı", date, Kind.PDF, listOf(url), "PDF")
        }
    }

    private fun dateAround(el: Element): String? {
        var cur: Element? = el
        repeat(5) {
            cur = cur?.parent()
            val d = cur?.text()?.let { DateUtil.find(it) }
            if (d != null) return d
        }
        return null
    }

    // ---------- Rahat: iki PDF, tarix fayl adından ----------
    suspend fun rahat(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://rahatmarket.az/az/aksiyalar/rahat-market")
        val urls = doc.select("a[href*=.pdf]").map { it.absUrl("href") }.filter { it.isNotEmpty() }.distinct()
        if (urls.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        urls.mapIndexed { i, u ->
            val name = u.substringAfterLast('/').substringBefore(".pdf")
            Catalog("Rahat Market", "Jurnal ${i + 1}", DateUtil.fromFileName(name), Kind.PDF, listOf(u), "PDF")
        }
    }

    // ---------- Tamstore: "Elektron jurnal" bölməsindəki bütün PDF-lər ----------
    suspend fun tamstore(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://www.tamstore.az/az/kampaniyalar")
        val urls = LinkedHashSet<String>()
        doc.select("a[href*=.pdf]").forEach { val u = it.absUrl("href"); if (u.isNotEmpty()) urls.add(u) }
        Regex("""https?://[^"'\s)<>]+\.pdf""").findAll(doc.html()).forEach {
            if (it.value.contains("tamstore.az")) urls.add(it.value)
        }
        if (urls.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        val fmt = SimpleDateFormat("dd.MM.yyyy", Locale.US)
        val sorted = urls.sortedByDescending { ts(it) }
        // siyahının sonundakı (ən köhnə) 2 PDF atılır
        val kept = if (sorted.size > 2) sorted.dropLast(2) else sorted
        kept.mapIndexed { i, u ->
            val t = ts(u)
            val note = if (t > 0) "Yüklənib: " + fmt.format(Date(t * 1000)) else null
            // tarix PDF-dən OCR ilə oxunacaq (MainActivity)
            Catalog("Tamstore", "Elektron jurnal ${i + 1}", null, Kind.PDF, listOf(u), note)
        }
    }

    private fun ts(u: String): Long = u.substringAfterLast('/').substringBefore('-').toLongOrNull() ?: 0L

    // ---------- Al Market: Telegram kanalından son albom ----------
    private data class Msg(val id: Int, val time: String, val text: String, val photos: List<String>)

    private val bgUrl = Regex("""url\(['"]?([^'")]+)""")

    private fun parseMsg(el: Element): Msg? {
        val post = el.selectFirst(".tgme_widget_message")?.attr("data-post") ?: return null
        val id = post.substringAfterLast('/').toIntOrNull() ?: return null
        val time = el.selectFirst(".tgme_widget_message_date time")?.attr("datetime") ?: ""
        val text = el.selectFirst(".tgme_widget_message_text")?.text() ?: ""
        val photos = el.select(".tgme_widget_message_photo_wrap")
            .mapNotNull { bgUrl.find(it.attr("style"))?.groupValues?.get(1) }
        return Msg(id, time, text, photos)
    }

    suspend fun al(): List<Catalog> = withContext(Dispatchers.IO) {
        val all = ArrayList<Msg>()
        var url = "https://t.me/s/almarketler"
        for (page in 0 until 3) {
            val msgs = get(url).select(".tgme_widget_message_wrap").mapNotNull { parseMsg(it) }
            if (msgs.isEmpty()) break
            all.addAll(0, msgs)
            url = "https://t.me/s/almarketler?before=" + msgs.first().id
        }
        // eyni dəqiqədə paylaşılan ardıcıl şəkilli mesajlar = bir albom
        val groups = ArrayList<MutableList<Msg>>()
        for (m in all) {
            if (m.photos.isEmpty()) continue
            val last = groups.lastOrNull()
            if (last != null && last.last().time.take(16) == m.time.take(16)) last.add(m) else groups.add(mutableListOf(m))
        }
        val kw = Regex("kataloq|endirim|aksiya|kampaniya", RegexOption.IGNORE_CASE)
        val pick = groups.lastOrNull { g -> kw.containsMatchIn(g.joinToString(" ") { it.text }) }
            ?: groups.lastOrNull { g -> g.sumOf { it.photos.size } >= 5 }
            ?: throw IllegalStateException("Kataloq paylaşımı tapılmadı")
        val photos = pick.flatMap { it.photos }
        val text = pick.joinToString(" ") { it.text }
        listOf(Catalog("Al Market", "Kataloq", DateUtil.find(text), Kind.IMAGES, photos, "${photos.size} şəkil"))
    }

    // ---------- Bolmart: Facebook səhifəsindən "Bol Endirimlər" postu ----------
    private const val FB_UA =
        "Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; SCH-I535 Build/KOT49H) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30"
    private const val FB_PAGE = "bolmart.supermarket"
    private const val POST_SEL = "article, div[data-ft]"

    private fun fbGet(url: String): Document =
        Jsoup.connect(url).userAgent(FB_UA).header("Accept-Language", "az,en;q=0.8")
            .timeout(25_000).followRedirects(true).maxBodySize(0).ignoreHttpErrors(true).get()

    /** Hərf fərqlərini (İ, ı, ə, ş...) atıb kiçik hərfə salır — "Bol Endirimlər" axtarışı üçün. */
    private fun norm(t: String): String =
        Normalizer.normalize(t, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
            .replace('ı', 'i').replace('ə', 'e').replace('Ə', 'e').lowercase(Locale.ROOT)

    private val bolStart = Regex("^\\W*bol\\s*endirim")
    /** Post mətni (başlıq/ad sətri sayılmadan) "Bol Endirimlər" ilə BAŞLAYIRMI. */
    private fun isBol(t: String) = bolStart.containsMatchIn(norm(t.trim()))
    private fun bodyStartsBol(post: Element): Boolean =
        post.select("p, div, span").any { isBol(it.text()) }

    private fun fbLoginWall(doc: Document): Boolean {
        val h = doc.html()
        return doc.select("input[name=pass]").isNotEmpty() || h.contains("login_form") && doc.select("article").isEmpty()
    }

    private fun fbImg(doc: Element): String? {
        doc.select("a[href]").firstOrNull { a ->
            val h = a.absUrl("href")
            (h.contains("fbcdn.net") || h.contains("scontent")) &&
                norm(a.text()).let { it.contains("full size") || it.contains("tam olcu") || it.contains("olcude") }
        }?.let { return it.absUrl("href") }
        doc.select("a[href*=fbcdn.net], a[href*=scontent]").firstOrNull()?.let { return it.absUrl("href") }
        return doc.select("img[src*=scontent], img[src*=fbcdn.net]")
            .map { it.absUrl("src") }
            .firstOrNull { !it.contains("emoji") && !it.contains("/p50x50/") && !it.contains("/s32x32") }
    }

    private fun photoLinks(doc: Element): List<String> =
        doc.select("a[href*=photo.php], a[href*=/photo/], a[href*=/photos/]").map { it.absUrl("href") }
            .filter { it.isNotEmpty() }

    /** mbasic.facebook.com: səhifənin son postları arasından "Bol Endirimlər" postunu tapır. */
    private fun bolFromMbasic(): Pair<String, List<String>>? {
        val page = fbGet("https://mbasic.facebook.com/$FB_PAGE")
        if (fbLoginWall(page)) return null
        // səhifədə yuxarıdan aşağı = yenidən köhnəyə; mətni "Bol Endirimlər" ilə başlayan ilk (ən son) post
        var post: Element = page.select(POST_SEL).firstOrNull { bodyStartsBol(it) } ?: return null
        // iç-içə sarğılardan ən daxili uyğun postu seç
        while (true) {
            val inner = post.select(POST_SEL).firstOrNull { it !== post && bodyStartsBol(it) } ?: break
            post = inner
        }
        val text = post.text()
        val storyUrl = post.select("a[href]").map { it.absUrl("href") }
            .firstOrNull { it.contains("story.php") || it.contains("/posts/") || it.contains("permalink") }
        val story = if (storyUrl != null) fbGet(storyUrl) else page
        val pages = LinkedHashSet<String>()
        pages.addAll(photoLinks(post)); pages.addAll(photoLinks(story))
        // çox şəkilli postda albomun hamısı: /media/set/ səhifələri
        var next: String? = (post.select("a[href*=/media/set/]") + story.select("a[href*=/media/set/]"))
            .firstOrNull()?.absUrl("href")
        var guard = 0
        while (next != null && guard++ < 6) {
            val d = fbGet(next)
            val before = pages.size
            pages.addAll(photoLinks(d))
            next = d.select("a[href*=/media/set/]").firstOrNull { a ->
                norm(a.text()).let { it.contains("daha cox") || it.contains("see more") || it.contains("novbeti") || it.contains("next") }
            }?.absUrl("href")
            if (pages.size == before) break
        }
        val photos = LinkedHashSet<String>()
        for (u in pages.take(40)) {
            try { fbImg(fbGet(u))?.let { photos.add(it) } } catch (e: Exception) { }
        }
        if (photos.isEmpty()) {
            // photo səhifələri açılmadısa postun öz şəkilləri
            (post.select("img[src*=scontent], img[src*=fbcdn.net]") + story.select("img[src*=scontent], img[src*=fbcdn.net]"))
                .map { it.absUrl("src") }
                .filter { !it.contains("emoji") && !it.contains("/p50x50/") && !it.contains("/s32x32") }
                .forEach { photos.add(it) }
        }
        return if (photos.isEmpty()) null else text to photos.toList()
    }

    private fun unescapeJson(raw: String): String =
        try { JSONObject("{\"s\":\"$raw\"}").getString("s") } catch (e: Exception) { raw.replace("\\/", "/") }

    /** Ehtiyat yol: m.facebook.com / www.facebook.com səhifəsinin JSON-undan "Bol Endirim" postunun şəkilləri. */
    private fun bolFromJson(): Pair<String, List<String>>? {
        for (base in listOf("https://m.facebook.com/$FB_PAGE", "https://www.facebook.com/$FB_PAGE")) {
            val html = try { Jsoup.connect(base).userAgent(UA).header("Accept-Language", "az,en;q=0.8")
                .timeout(25_000).maxBodySize(0).ignoreHttpErrors(true).get().html() } catch (e: Exception) { continue }
            val m = Regex("\"(?:text|message)\":\"\\s*Bol\\s*Endirim", RegexOption.IGNORE_CASE).find(html) ?: continue
            val from = (m.range.first - 1500).coerceAtLeast(0)
            val win = html.substring(from, (m.range.first + 9000).coerceAtMost(html.length))
            val photos = Regex(""""uri":"(https:[^"]+?(?:scontent|fbcdn)[^"]+)"""").findAll(win)
                .map { unescapeJson(it.groupValues[1]) }
                .filter { !it.contains("emoji") && !it.contains("/p50x50/") && !it.contains("/s32x32") }
                .distinct().toList()
            if (photos.isNotEmpty()) return html.substring(m.range.first, (m.range.first + 300).coerceAtMost(html.length)) to photos
        }
        return null
    }

    suspend fun bolmart(): List<Catalog> = withContext(Dispatchers.IO) {
        val found = try { bolFromMbasic() } catch (e: Exception) { null } ?: bolFromJson()
            ?: throw IllegalStateException("Facebook-da \"Bol Endirimlər\" postu tapılmadı (Facebook giriş tələb edə bilər)")
        val (text, photos) = found
        listOf(Catalog("Bolmart", "Bol Endirimlər", DateUtil.find(text), Kind.IMAGES, photos, "${photos.size} şəkil"))
    }
}
