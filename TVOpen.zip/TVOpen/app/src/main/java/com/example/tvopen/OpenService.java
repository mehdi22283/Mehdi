package com.example.tvopen;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

import java.io.InputStream;
import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;

public class OpenService extends Service {
    public static final int PORT = 3169;
    private static final String CHANNEL = "filmebax";
    private static final char[] KS_PASS = "tvopen".toCharArray();

    private TvServer server;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(1, buildNotification());
        if (server == null) {
            final TvServer srv = new TvServer(PORT, buildSsl(), this::openUrl);
            server = srv;
            new Thread(() -> {
                try {
                    srv.start();
                } catch (Exception e) {
                    server = null;
                }
            }, "filmebax-start").start();
        }
        return START_STICKY;
    }

    // Sayt açılır (arxa planda olanda "digər tətbiqlərin üstündə göstər" icazəsi lazımdır)
    private void openUrl(String url) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    // https üçün sertifikat; yüklənməsə yalnız http işləyəcək
    private SSLContext buildSsl() {
        try (InputStream is = getResources().openRawResource(R.raw.tvopen_keystore)) {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            ks.load(is, KS_PASS);
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(
                    KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(ks, KS_PASS);
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(kmf.getKeyManagers(), null, null);
            return ctx;
        } catch (Exception e) {
            return null;
        }
    }

    private Notification buildNotification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "Filmə bax", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        return b.setContentTitle("Filmə bax işləyir")
                .setContentText("Port " + PORT)
                .setSmallIcon(R.drawable.ic_launcher_film)
                .build();
    }

    @Override
    public void onDestroy() {
        if (server != null) server.stop();
        server = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
