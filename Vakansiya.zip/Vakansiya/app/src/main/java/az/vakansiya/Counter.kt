package az.vakansiya

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Calendar

/** Saytları gizli brauzerdə ardıcıl açıb bu gün / dünən tarixli elanları təxmini sayır. */
class Counter(
    private val ctx: Context,
    private val sites: List<Site>,
    private val onUpdate: (Int) -> Unit,
    private val onDone: () -> Unit
) {
    private val h = Handler(Looper.getMainLooper())
    private val wvs = mutableListOf<WebView>()
    private val finished = BooleanArray(sites.size)
    private var left = sites.size
    var stopped = false

    // ay adları: azərbaycanca, qısaltma, ingiliscə, rusca
    private val months = arrayOf(
        "yanvar|yan|january|jan|января",
        "fevral|fev|february|feb|февраля",
        "mart|mar|march|марта",
        "aprel|apr|april|апреля",
        "may|мая",
        "iyun|iyn|june|jun|июня",
        "iyul|iyl|july|jul|июля",
        "avqust|avq|august|aug|августа",
        "sentyabr|sen|september|sep|сентября",
        "oktyabr|okt|october|oct|октября",
        "noyabr|noy|november|nov|ноября",
        "dekabr|dek|december|dec|декабря"
    )
    private val end = "\$"
    private val nb = "(^|[^0-9])"
    private val na = "([^0-9]|$end)"

    private fun datePat(c: Calendar): String {
        val d = c.get(Calendar.DAY_OF_MONTH)
        val m = c.get(Calendar.MONTH) + 1
        val y = c.get(Calendar.YEAR)
        val yy = y % 100
        val mn = months[m - 1]
        return listOf(
            // 11.10.2026  11/10/2026  11-10-2026  11.10.26
            "${nb}0?$d[./-]0?$m[./-]($y|$yy)$na",
            // 2026-10-11  2026.10.11  2026/10/11
            "$y[./-]0?$m[./-]0?$d$na",
            // 11 oktyabr  11 Oktyabr 2026  11 okt.
            "${nb}0?$d[ .]*($mn)",
            // oct 11, 2026
            "($mn)[ .]*0?$d$na"
        ).joinToString("|")
    }

    private val ago = "(bir|neçə|[0-9]+)[ ]*(saat|saatlıq|dəq|dəqiqə|dəqiqe|san|saniyə|hour|hours|hr|minute|minutes|min|час|часа|часов|мин|минут|минуты)[a-zəöüçşğı.]*[ ]*(əvvəl|evvel|öncə|ago|назад)"

    private fun js(): String {
        val cal = Calendar.getInstance()
        val t = datePat(cal) +
            "|bu gün|bugün|bu gun|bugun|today|сегодня|indicə|indi paylaş|az əvvəl|just now|" + ago
        cal.add(Calendar.DAY_OF_MONTH, -1)
        val y = datePat(cal) +
            "|dünən|dunen|yesterday|вчера|${nb}(1|bir)[ ]*(gün|gun)[ ]*(əvvəl|evvel|öncə)|1 day ago"
        return """(function(){
var lines=(document.body?document.body.innerText:'').toLowerCase().split('\n');
function c(p){var r=new RegExp(p),g=new RegExp(p,'g'),n=0;
for(var i=0;i<lines.length;i++){var l=lines[i].replace(/\s+/g,' ');
if(l.length<3||!r.test(l))continue;
if(l.length<=120){n++}else{var m=l.match(g);n+=m?m.length:1}}
return n}
return c("$t")+","+c("$y");})()"""
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    fun start() {
        if (sites.isEmpty()) { onDone(); return }
        sites.forEachIndexed { i, site ->
            val w = WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(v: WebView, u: String) {
                        h.postDelayed({
                            if (!stopped && !finished[i]) {
                                v.evaluateJavascript(js()) { r ->
                                    if (!stopped && !finished[i]) {
                                        try {
                                            val p = r.trim('"').split(",")
                                            site.today = p[0].toInt()
                                            site.yest = p[1].toInt()
                                        } catch (e: Exception) { }
                                        finish(i)
                                    }
                                }
                            }
                        }, 3500)
                    }
                }
            }
            wvs.add(w)
            w.loadUrl(site.url)
            // hər sayt üçün ayrıca vaxt limiti
            h.postDelayed({ if (!stopped && !finished[i]) finish(i) }, 25000)
        }
    }

    private fun finish(i: Int) {
        if (finished[i]) return
        finished[i] = true
        try { wvs[i].destroy() } catch (e: Exception) { }
        onUpdate(i)
        left--
        if (left == 0 && !stopped) onDone()
    }

    fun stop() {
        stopped = true
        h.removeCallbacksAndMessages(null)
        wvs.forEachIndexed { i, w ->
            if (!finished[i]) { finished[i] = true; try { w.destroy() } catch (e: Exception) { } }
        }
    }
}
