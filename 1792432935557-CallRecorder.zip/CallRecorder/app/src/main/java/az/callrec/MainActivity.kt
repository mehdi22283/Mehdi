package az.callrec

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: RecAdapter

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        val rv = findViewById<RecyclerView>(R.id.list)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = RecAdapter(this) { findViewById<View>(R.id.empty).visibility = if (it) View.VISIBLE else View.GONE }
        rv.adapter = adapter
        val p = getSharedPreferences("s", 0)
        val cb = findViewById<CheckBox>(R.id.speaker)
        cb.isChecked = p.getBoolean("speaker", true)
        cb.setOnCheckedChangeListener { _, c -> p.edit().putBoolean("speaker", c).apply() }
        findViewById<Button>(R.id.acc).setOnClickListener {
            AlertDialog.Builder(this).setTitle("WhatsApp zəngləri")
                .setMessage("Əlçatanlıq (Accessibility) bölməsində \"Zəng Yazıcı\"nı aktiv edin.")
                .setPositiveButton("Aç") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }.show()
        }
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (perms.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED })
            ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); startSvc()
    }

    private fun startSvc() {
        val ok = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE)
            .all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        if (ok) ContextCompat.startForegroundService(this, Intent(this, RecorderService::class.java))
    }

    override fun onResume() { super.onResume(); startSvc(); adapter.reload() }
    override fun onPause() { super.onPause(); adapter.stop() }
}
