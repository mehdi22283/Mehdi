package com.mehdi.keymapper

import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val ui = Handler(Looper.getMainLooper())

    private val refreshTask: Runnable = Runnable { refresh() }
    private val adbListener: Runnable = Runnable { ui.post(refreshTask) }
    private val pollTask: Runnable = object : Runnable {
        override fun run() {
            Adb.ping()
            refresh()
            ui.postDelayed(this, 5000L)
        }
    }

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun makeButton(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { f() }
        return b
    }

    private fun makeRow(vararg v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (x in v) {
            r.addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        return r
    }

    private fun makeLabel(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 15f
        tv.setPadding(0, dp(14), 0, dp(2))
        return tv
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(20), dp(20), dp(20))

        val title = TextView(this)
        title.text = "Key Mapper TV"
        title.textSize = 26f
        root.addView(title)

        status = TextView(this)
        status.textSize = 16f
        status.setPadding(0, dp(12), 0, dp(12))
        root.addView(status)

        root.addView(
            makeRow(
                makeButton("ADB ilə qoşul") { Adb.connect(true) },
                makeButton("ADB ünvanı") { showHostDialog() }
            )
        )
        root.addView(
            makeRow(
                makeButton("Servisi ADB ilə aktiv et") { Adb.enableAccessibilityAsync() },
                makeButton("Əlçatımlılıq ayarları") {
                    try {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    } catch (e: Exception) {
                    }
                }
            )
        )
        root.addView(makeButton("Sürət ayarları (təkrar / iki dəfə basma)") { showSpeedDialog() })

        root.addView(makeLabel("Düymə əvəzləmələri"))
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        root.addView(list)

        root.addView(
            makeRow(
                makeButton("+ Yeni düymə") { showEditor(null) },
                makeButton("Standarta qaytar") { confirmReset() }
            )
        )

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33) {
            try {
                requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
            } catch (e: Exception) {
            }
        }
        try {
            val s = Intent(this, KeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s) else startService(s)
        } catch (e: Exception) {
        }
        Adb.connect()
        rebuildList()
    }

    override fun onStart() {
        super.onStart()
        Adb.listeners.add(adbListener)
        ui.post(pollTask)
    }

    override fun onStop() {
        Adb.listeners.remove(adbListener)
        ui.removeCallbacks(pollTask)
        super.onStop()
    }

    private fun refresh() {
        val adb: String = when (Adb.state) {
            Adb.State.CONNECTED -> "QOŞULUB ✔ (" + Adb.usedHost + ")"
            Adb.State.CONNECTING -> "qoşulur..."
            Adb.State.ERROR -> "XƏTA ✘ " + (Adb.error ?: "")
            else -> "QOŞULMAYIB ✘"
        }
        val svc = if (KeepAliveService.running) "İŞLƏYİR ✔" else "DAYANIB ✘"
        val acc = if (KeyMapperService.running) "AKTİV ✔" else "SÖNÜLÜ ✘"
        val fast = if (Adb.fast) "AKTİV ✔" else "ehtiyat rejim (yavaş) ✘ " + (Adb.fastError ?: "")
        status.text = "Arxa plan servisi: " + svc +
            "\nDüymə tutma servisi: " + acc +
            "\nADB " + Store.host + ":" + Adb.PORT + ": " + adb +
            "\nSürətli düymə göndərmə: " + fast
    }

    private fun rebuildList() {
        list.removeAllViews()
        for (m in Store.mappings) {
            val tv = TextView(this)
            tv.text = Store.keyName(m.key).removePrefix("KEYCODE_") +
                "\n  Qısa: " + m.onShort.describe() +
                "\n  Uzun: " + m.onLong.describe() +
                "\n  İki dəfə: " + m.onDouble.describe()
            tv.textSize = 16f
            tv.setPadding(0, dp(12), 0, dp(4))
            list.addView(tv)
            list.addView(
                makeRow(
                    makeButton("Redaktə") { showEditor(m) },
                    makeButton("Sil") {
                        Store.remove(m.key)
                        rebuildList()
                    }
                )
            )
        }
    }

    private fun confirmReset() {
        val b = AlertDialog.Builder(this)
        b.setMessage("Bütün düymə ayarları standart vəziyyətə qayıtsın?")
        b.setPositiveButton("Bəli", DialogInterface.OnClickListener { _, _ ->
            Store.reset()
            rebuildList()
        })
        b.setNegativeButton("Xeyr", null)
        b.show()
    }

    private fun showHostDialog() {
        val et = EditText(this)
        et.setSingleLine()
        et.setText(Store.host)
        val b = AlertDialog.Builder(this)
        b.setTitle("ADB IP ünvanı (port həmişə 5555)")
        b.setView(et)
        b.setPositiveButton("Yadda saxla", DialogInterface.OnClickListener { _, _ ->
            val h = et.text.toString().trim().substringBefore(":")
            if (h.isNotEmpty()) {
                Store.host = h
                Adb.connect(true)
                refresh()
            } else {
                toast("IP boşdur")
            }
        })
        b.setNegativeButton("Ləğv et", null)
        b.show()
    }

    private fun showSpeedDialog() {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(20), dp(8), dp(20), 0)

        c.addView(makeLabel("Basılı saxlayanda təkrarın başlama gecikməsi (ms)"))
        val d = EditText(this)
        d.setSingleLine()
        d.inputType = InputType.TYPE_CLASS_NUMBER
        d.setText(Store.repeatDelay.toString())
        c.addView(d)

        c.addView(makeLabel("Təkrar intervalı (ms) - kiçik olsa daha sürətli"))
        val i = EditText(this)
        i.setSingleLine()
        i.inputType = InputType.TYPE_CLASS_NUMBER
        i.setText(Store.repeatInterval.toString())
        c.addView(i)

        c.addView(makeLabel("İki dəfə basma pəncərəsi (ms) - kiçik olsa tək basma daha tez işləyir"))
        val w = EditText(this)
        w.setSingleLine()
        w.inputType = InputType.TYPE_CLASS_NUMBER
        w.setText(Store.doubleWindow.toString())
        c.addView(w)

        val b = AlertDialog.Builder(this)
        b.setTitle("Sürət ayarları")
        b.setView(c)
        b.setPositiveButton("Yadda saxla", DialogInterface.OnClickListener { _, _ ->
            val dv = d.text.toString().toLongOrNull() ?: 250L
            val iv = i.text.toString().toLongOrNull() ?: 40L
            Store.repeatDelay = dv.coerceIn(50L, 2000L)
            Store.repeatInterval = iv.coerceIn(15L, 500L)
            val wv = w.text.toString().toLongOrNull() ?: 250L
            Store.doubleWindow = wv.coerceIn(120L, 1000L)
        })
        b.setNegativeButton("Ləğv et", null)
        b.show()
    }

    private fun captureKey(onKey: (Int) -> Unit) {
        val holder = arrayOfNulls<AlertDialog>(1)
        val timeout = Runnable { holder[0]?.dismiss() }

        val b = AlertDialog.Builder(this)
        b.setTitle("Düyməyə basın")
        b.setMessage("8 saniyə ərzində pultda və ya klaviaturada düyməyə basın")
        b.setOnKeyListener(DialogInterface.OnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                holder[0]?.dismiss()
                onKey(keyCode)
            }
            true
        })
        b.setOnDismissListener(DialogInterface.OnDismissListener {
            KeyMapperService.capture = null
            ui.removeCallbacks(timeout)
        })
        val dlg = b.create()
        holder[0] = dlg
        KeyMapperService.capture = { code: Int ->
            holder[0]?.dismiss()
            onKey(code)
        }
        dlg.show()
        ui.postDelayed(timeout, 8000L)
    }

    private fun actionEditor(parent: LinearLayout, title: String, a: Action): Pair<Spinner, EditText> {
        parent.addView(makeLabel(title))

        val et = EditText(this)
        et.setSingleLine()
        et.setText(a.param)

        val sp = Spinner(this)
        sp.adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, Actions.LABELS)
        val idx = Actions.TYPES.indexOf(a.type)
        sp.setSelection(if (idx < 0) 0 else idx)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                et.hint = Actions.HINTS[pos]
                val t = Actions.TYPES[pos]
                et.visibility = if (t == "KEY" || t == "KEY_LONG" || t == "APP" || t == "SHELL") View.VISIBLE else View.GONE
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        parent.addView(sp)
        parent.addView(et)
        return Pair(sp, et)
    }

    private fun showEditor(old: Mapping?) {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(20), dp(8), dp(20), 0)

        c.addView(makeLabel("Mənbə düymə"))
        val keyEt = EditText(this)
        keyEt.setSingleLine()
        keyEt.hint = "KEYCODE_BUTTON_5"
        if (old != null) keyEt.setText(Store.keyName(old.key))
        c.addView(keyEt)
        c.addView(makeButton("Düyməni tut") {
            captureKey { code -> keyEt.setText(Store.keyName(code)) }
        })

        val shortEd = actionEditor(c, "Qısa basma", old?.onShort ?: Action())
        val longEd = actionEditor(c, "Uzun basma", old?.onLong ?: Action())
        val dblEd = actionEditor(c, "İki dəfə basma", old?.onDouble ?: Action())

        val sv = ScrollView(this)
        sv.addView(c)

        val b = AlertDialog.Builder(this)
        b.setTitle(if (old == null) "Yeni düymə" else "Düyməni redaktə et")
        b.setView(sv)
        b.setPositiveButton("Yadda saxla", DialogInterface.OnClickListener { _, _ ->
            val code = Store.parseKey(keyEt.text.toString())
            if (code == 0) {
                toast("Düymə tanınmadı")
            } else {
                val s = Action(Actions.TYPES[shortEd.first.selectedItemPosition], shortEd.second.text.toString().trim())
                val l = Action(Actions.TYPES[longEd.first.selectedItemPosition], longEd.second.text.toString().trim())
                val d = Action(Actions.TYPES[dblEd.first.selectedItemPosition], dblEd.second.text.toString().trim())
                Store.upsert(old?.key, Mapping(code, s, l, d))
                rebuildList()
            }
        })
        b.setNegativeButton("Ləğv et", null)
        b.show()
    }
}
