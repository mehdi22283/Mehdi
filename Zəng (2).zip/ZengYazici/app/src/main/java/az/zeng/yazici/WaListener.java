package az.zeng.yazici;

import android.app.Notification;
import android.content.SharedPreferences;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/**
 * WhatsApp zəngləri: WhatsApp-ın "zəng" kateqoriyalı bildirişinə görə başlayır/bitir.
 * Sistem özü bağlayır; tətbiqin öz daimi xidməti və bildirişi yoxdur.
 */
public class WaListener extends NotificationListenerService {
    private static final long RING_TTL = 90_000;

    private static boolean isWa(StatusBarNotification s) {
        String p = s.getPackageName();
        return "com.whatsapp".equals(p) || "com.whatsapp.w4b".equals(p);
    }

    private static boolean isCall(Notification n) {
        return Notification.CATEGORY_CALL.equals(n.category);
    }

    /** Zəng çalarkən bildirişdə "Cavab ver / Rədd et" kimi 2 düymə və ya fullScreenIntent olur. */
    private static boolean isRinging(Notification n) {
        return n.fullScreenIntent != null || (n.actions != null && n.actions.length >= 2);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (!isWa(sbn)) return;
        Notification n = sbn.getNotification();
        if (!isCall(n)) return;
        SharedPreferences p = getSharedPreferences("st", 0);
        CharSequence t = n.extras.getCharSequence(Notification.EXTRA_TITLE);
        String name = t == null || t.length() == 0 ? "WhatsApp" : t.toString();
        long now = System.currentTimeMillis();
        if (isRinging(n)) {
            p.edit().putLong("wa_ring_t", now).putString("wa_name", name).apply();
            return;
        }
        boolean inc = now - p.getLong("wa_ring_t", 0) < RING_TTL;
        String label = inc ? p.getString("wa_name", name) : name;
        RecorderClient.begin(this, "wa", inc ? "in" : "out", label, null);
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        if (!isWa(sbn)) return;
        Notification n = sbn.getNotification();
        if (!isCall(n) || isRinging(n)) return;
        getSharedPreferences("st", 0).edit().remove("wa_ring_t").apply();
        RecorderClient.end(this, "wa", null);
    }
}
