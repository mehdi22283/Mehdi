package az.zengyazici;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** WhatsApp zəng bildirişlərini izləyir: zəng başlayanda yazır, bitəndə dayandırır. */
public class WaNotificationService extends NotificationListenerService {
    static long ringAt = 0;
    static String ringName = "";

    private boolean isWaCall(StatusBarNotification sbn) {
        return sbn.getPackageName().startsWith("com.whatsapp")
                && Notification.CATEGORY_CALL.equals(sbn.getNotification().category);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (!isWaCall(sbn)) return;
        Notification n = sbn.getNotification();
        CharSequence t = n.extras.getCharSequence(Notification.EXTRA_TITLE);
        String name = t == null ? "" : t.toString();
        if (n.fullScreenIntent != null) { // gələn zəng çalır
            ringAt = System.currentTimeMillis();
            ringName = name;
            return;
        }
        if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0 && !Rec.active()) {
            boolean in = System.currentTimeMillis() - ringAt < 90000;
            Rec.start(this, "wa", in ? "in" : "out", in && !ringName.isEmpty() ? ringName : name);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        if (isWaCall(sbn) && Rec.active() && "wa".equals(Rec.app)) {
            Rec.stop(this);
            ringAt = 0;
        }
    }
}
