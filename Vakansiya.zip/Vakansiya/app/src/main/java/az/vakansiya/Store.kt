package az.vakansiya

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Site(var name: String, var url: String, var last: String = "", var today: Int = -1, var yest: Int = -1)

object Store {
    private val DEFAULTS = listOf(
        "HelloJob" to "https://www.hellojob.az/vakansiyalar",
        "Work.az" to "https://www.work.az/vakansiyalar?orderBy=DATE&orderDirection=DESC",
        "Busy.az" to "https://busy.az/vacancies",
        "HRIN" to "https://hrin.az/",
        "Glorri Jobs" to "https://jobs.glorri.az/?cityId=62f1516b22d84be76acb9d2d",
        "JobSearch" to "https://jobsearch.az/vacancies",
        "JobSearch Staj" to "https://jobsearch.az/internship-program",
        "eJob" to "https://ejob.az/is-elanlari/",
        "AzVak" to "https://azvak.az/",
        "AzJob" to "https://azjob.az/",
        "İşəqəbul" to "https://iseqebul.az/",
        "Boss.az" to "https://boss.az/search/vacancies",
        "EasyJob" to "https://easyjob.az/?search=&company_id=&category_id=&date=three_days&salary=",
        "HumanPro" to "https://humanpro.az/az/vakansiyalar",
        "Jooble" to "https://jooble.az/",
        "JobSite (İT)" to "https://jobsite.az/vakansiya-is-elanlari/informasiya-texnologiyalari",
        "Jobing (Bakı)" to "https://jobing.az/baki",
        "Vəzifə" to "https://vezife.az/",
        "Jobu" to "https://jobu.az/vakansiyalar/?filter-orderby=newest"
    )

    private fun p(c: Context) = c.getSharedPreferences("vak", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Site> {
        val s = p(c).getString("sites", null)
        val l = mutableListOf<Site>()
        if (s == null) {
            DEFAULTS.forEach { l.add(Site(it.first, it.second)) }
            save(c, l)
            return l
        }
        val a = JSONArray(s)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            l.add(Site(o.getString("n"), o.getString("u"), o.optString("l", ""), o.optInt("t", -1), o.optInt("y", -1)))
        }
        return l
    }

    fun save(c: Context, l: List<Site>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("n", it.name).put("u", it.url).put("l", it.last).put("t", it.today).put("y", it.yest))
        }
        p(c).edit().putString("sites", a.toString()).apply()
    }

    fun setLast(c: Context, base: String, last: String) {
        val l = load(c)
        l.firstOrNull { it.url == base }?.last = last
        save(c, l)
    }
}
