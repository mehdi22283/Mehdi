# IPTV Player – sürətli açılış və şəbəkə sabitliyi

- VLC şəbəkə və canlı yayım keşləri 2 saniyədir: ilkin açılışı sürətləndirmək və qısa şəbəkə dalğalanmalarına bir qədər ehtiyat saxlamaq üçün balans.
- VLC-də gecikmiş kadrları zorla saxlama seçimi çıxarıldı; gecikmə yarananda pleyer kadrları ata bilər və canlı yayım daha axıcı qala bilər.
- ExoPlayer bufer hədləri: 8 saniyə minimum, 45 saniyə maksimum, ilkin oynatma üçün 0.8 saniyə, yenidən başlama üçün 1.8 saniyə. Bu, ilk kadrı daha tez göstərməyə çalışır; şəbəkə zəifdirsə daha tez-tez buffering ola bilər.
- HTTP bağlantı timeout-u 2.5 saniyə, oxuma timeout-u 4.5 saniyədir; cavab verməyən mənbədən daha tez alternativ pleyerə keçməyə kömək edir.
- Axın başlamasa və ya buffering uzun çəksə, 10 saniyədən sonra alternativ pleyerə keçid edilir.
- Sürətli kanal dəyişmələrində son seçim üstün tutulur; əvvəlki 350 ms gözləmə 100 ms edilib.
- Kanal dəyişmə nəsli ilə köhnə player hadisələri filtrlənir; HTTP reconnect aktivdir.

Qeyd: Daha qısa bufer ilk görüntünü tezləşdirə bilər, lakin zəif internetdə donma ehtimalını artıra bilər. Real nəticə IPTV mənbəyindən, kodekdən və bağlantıdan asılıdır. Android SDK/Gradle və canlı IPTV axınları ilə cihaz testi bu mühitdə aparılmayıb.
