package az.m3u.sinayici

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/** HTML ↔ native körpü. Yalnız yerli (asset) səhifəyə bağlanır. */
class Bridge(private val act: MainActivity, private val web: WebView) {
    private val pool = Executors.newFixedThreadPool(40)

    private fun js(id: Int, quoted: String) {
        web.post {
            try { web.evaluateJavascript("window.__nativeCb($id,$quoted)", null) } catch (_: Exception) {}
        }
    }

    @JavascriptInterface
    fun probe(url: String, id: Int) {
        pool.execute { js(id, JSONObject.quote(Net.probe(url))) }
    }

    @JavascriptInterface
    fun fetchText(url: String, id: Int) {
        pool.execute {
            val o = JSONObject()
            try {
                o.put("ok", true).put("text", Net.fetchText(url))
            } catch (e: Exception) {
                o.put("ok", false).put("error", e.message ?: "xəta")
            }
            js(id, JSONObject.quote(o.toString()))
        }
    }

    @JavascriptInterface
    fun play(name: String, urlsJson: String) {
        act.runOnUiThread {
            act.startActivity(
                Intent(act, PlayerActivity::class.java)
                    .putExtra("name", name)
                    .putExtra("urls", urlsJson)
            )
        }
    }

    @JavascriptInterface
    fun openBrowser(url: String) {
        act.runOnUiThread { act.openBrowser(url) }
    }

    @JavascriptInterface
    fun takePending(): String = Store.takePending(act)

    @JavascriptInterface
    fun getFirstPlaylist(): String = Store.getFirst(act)

    @JavascriptInterface
    fun reportStatuses(json: String) {
        try { Store.report(act, JSONArray(json)) } catch (_: Exception) {}
    }

    @JavascriptInterface
    fun getFirstStats(): String = Store.stats(act)

    @JavascriptInterface
    fun clearHistory() = Store.clearHistory(act)

    @JavascriptInterface
    fun copyText(text: String) {
        act.runOnUiThread {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("m3u", text))
        }
    }

    @JavascriptInterface
    fun saveTextFile(name: String, text: String) {
        val ok = try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "audio/x-mpegurl")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = act.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                if (uri == null) false else {
                    act.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    true
                }
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                File(dir, name).writeText(text)
                true
            }
        } catch (e: Exception) {
            false
        }
        act.runOnUiThread {
            Toast.makeText(act, if (ok) "✔ Yüklənənlər qovluğuna saxlanıldı: $name" else "✖ Saxlanmadı", Toast.LENGTH_LONG).show()
        }
    }
}
