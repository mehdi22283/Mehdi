package az.zeng.yazici;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Visible foreground status while the user has enabled call monitoring. */
public class MonitorService extends Service {
    public static final String ACTION_START = "az.zeng.yazici.MONITOR_START";
    public static final String ACTION_STOP = "az.zeng.yazici.MONITOR_STOP";
    private static final String CHANNEL = "monitor_status";
    private static final int ID = 1004;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            getSharedPreferences("st", 0).edit().putBoolean("monitor_enabled", false).apply();
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.cancel(ID);
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        getSharedPreferences("st", 0).edit().putBoolean("monitor_enabled", true).apply();
        createChannel();
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 4, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, MonitorService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 5, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_rec)
                .setContentTitle("Zəng Yazıcı aktivdir")
                .setContentText("Telefon və WhatsApp zəngləri izlənir; yazı başlayanda ayrıca bildiriş göstəriləcək")
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(new Notification.Action.Builder(null, "İzləməni dayandır", stopPi).build())
                .build();
        startForeground(ID, n);
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Zəng izləmə vəziyyəti", NotificationManager.IMPORTANCE_LOW));
        }
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
