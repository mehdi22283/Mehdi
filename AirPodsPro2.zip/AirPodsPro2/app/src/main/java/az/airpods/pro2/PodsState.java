package az.airpods.pro2;

/** Apple "proximity pairing" BLE reklam paketinin (0x004C, tip 0x07) oxunmuş halı. */
public class PodsState {
    public static final int APPLE = 0x004C;

    public int model;
    public String name = "AirPods";
    public String address = "";
    public int left = -1, right = -1, caseLevel = -1;   // 0..100, -1 = məlum deyil
    public boolean chgL, chgR, chgC, inL, inR;
    public int rssi;
    public boolean generic;      // AirPods olmayan, ümumi Bluetooth qulaqlıq
    public int single = -1;      // tək batareya səviyyəsi (ümumi qulaqlıqlar)

    public static PodsState parse(byte[] d, int rssi, String address) {
        if (d == null || d.length < 27) return null;
        if ((d[0] & 0xFF) != 0x07 || (d[1] & 0xFF) != 0x19) return null;

        PodsState s = new PodsState();
        s.rssi = rssi;
        s.address = address == null ? "" : address;
        s.model = ((d[3] & 0xFF) << 8) | (d[4] & 0xFF);
        s.name = nameOf(s.model);

        int st = d[5] & 0xFF;
        boolean flip = (((st >> 4) & 0x02) == 0);
        int ear = st & 0x0F;
        s.inL = (ear & (flip ? 0x08 : 0x02)) != 0;
        s.inR = (ear & (flip ? 0x02 : 0x08)) != 0;

        int pods = d[6] & 0xFF;
        int hi = (pods >> 4) & 0x0F, lo = pods & 0x0F;
        s.left = level(flip ? hi : lo);
        s.right = level(flip ? lo : hi);

        int fl = (d[7] >> 4) & 0x0F;
        s.caseLevel = level(d[7] & 0x0F);
        s.chgL = (fl & (flip ? 0x02 : 0x01)) != 0;
        s.chgR = (fl & (flip ? 0x01 : 0x02)) != 0;
        s.chgC = (fl & 0x04) != 0;
        return s;
    }

    private static int level(int n) {
        return n <= 10 ? n * 10 : -1;
    }

    private static String nameOf(int m) {
        switch (m) {
            case 0x0220: return "AirPods";
            case 0x0F20: return "AirPods 2";
            case 0x1320: return "AirPods 3";
            case 0x1920:
            case 0x1B20: return "AirPods 4";
            case 0x0E20: return "AirPods Pro";
            case 0x1420:
            case 0x2420: return "AirPods Pro 2";
            case 0x0A20: return "AirPods Max";
            case 0x0320: return "Powerbeats3";
            case 0x0520: return "BeatsX";
            case 0x0620: return "Beats Solo3";
            case 0x0920: return "Beats Studio3";
            case 0x0B20: return "Powerbeats Pro";
            case 0x0C20: return "Beats Solo Pro";
            case 0x1120: return "Beats Studio Buds";
            default: return "Apple qulaqlıq";
        }
    }
}
