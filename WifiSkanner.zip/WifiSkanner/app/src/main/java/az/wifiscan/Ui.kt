package az.wifiscan

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import java.util.concurrent.CountDownLatch

/** Səhifələr arası ortaq köməkçilər (rənglər, düymələr, UI thread). */
class Ui(val act: Activity) {
    val h = Handler(Looper.getMainLooper())
    val BG = 0xFF000000.toInt()
    val CARD = 0xFF0C0C0C.toInt()
    val CARD2 = 0xFF161B22.toInt()
    val TXT = 0xFFE6EDF3.toInt()
    val SUB = 0xFF8FA3B5.toInt()
    val ACC = 0xFF4FC3F7.toInt()
    val GRN = 0xFF9CCC65.toInt()
    val RED = 0xFFFF5252.toInt()
    val YEL = 0xFFFFCA28.toInt()
    val ORG = 0xFFFF9800.toInt()

    /** Səhifə indeksləri: 0 Skan, 1 Port, 2 Ping, 3 Trace, 4 Sürət, 5 Alət */
    var go: (Int, String) -> Unit = { _, _ -> }

    fun dp(x: Int) = (x * act.resources.displayMetrics.density).toInt()

    fun tv(t: String = "", sz: Float = 14f, col: Int = TXT, bold: Boolean = false, mono: Boolean = false) =
        TextView(act).apply {
            text = t; textSize = sz; setTextColor(col)
            typeface = if (mono) Typeface.MONOSPACE else if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    fun btn(t: String, f: () -> Unit) = Button(act).apply {
        text = t; setTextColor(Color.BLACK); setBackgroundColor(ACC); setOnClickListener { f() }
    }

    fun edit(hint: String, def: String) = EditText(act).apply {
        setText(def); setHint(hint); setTextColor(TXT); setHintTextColor(SUB); setSingleLine()
    }

    fun post(f: () -> Unit) { h.post { f() } }

    fun onUiSync(f: () -> Unit) {
        val l = CountDownLatch(1); h.post { f(); l.countDown() }; l.await()
    }

    fun toast(m: String) = Toast.makeText(act, m, Toast.LENGTH_LONG).show()

    fun vbox(pad: Boolean = true) = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        if (pad) setPadding(dp(12), dp(8), dp(12), 0)
    }

    fun card() = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(CARD); setPadding(dp(10), dp(10), dp(10), dp(10))
    }

    fun gap(p: LinearLayout, dpv: Int = 8) {
        p.addView(View(act), LinearLayout.LayoutParams(-1, dp(dpv)))
    }

    fun spinner(items: List<String>): Spinner = Spinner(act).apply {
        adapter = object : ArrayAdapter<String>(act, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View =
                (super.getView(position, convertView, parent) as TextView).apply { setTextColor(TXT) }
            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View =
                (super.getDropDownView(position, convertView, parent) as TextView).apply { setTextColor(TXT); setBackgroundColor(CARD2); setPadding(dp(12), dp(12), dp(12), dp(12)) }
        }
    }

    fun vulnView(v: Vuln): TextView = tv("${v.icon} ${v.title}\n    ${v.detail}", 12f, when (v.level) { 3 -> RED; 2 -> ORG; else -> YEL }).apply {
        setPadding(0, dp(4), 0, dp(4))
    }

    fun netInfo(): Triple<String, Int, String>? {
        val cm = act.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val n = cm.activeNetwork ?: return null
        val lp = cm.getLinkProperties(n) ?: return null
        val la = lp.linkAddresses.firstOrNull { it.address is java.net.Inet4Address && !it.address.isLoopbackAddress } ?: return null
        val gw = lp.routes.firstOrNull { it.isDefaultRoute && it.gateway is java.net.Inet4Address }?.gateway?.hostAddress ?: ""
        return Triple(la.address.hostAddress ?: return null, la.prefixLength, gw)
    }

    fun openCamera(ip: String, vendor: String) {
        act.startActivity(Intent(act, CameraActivity::class.java).putExtra("ip", ip).putExtra("vendor", vendor))
    }
}

/** Səhifə = görünüş + "bu host ilə aç" callback-i */
class Page(val view: View, val open: (String) -> Unit = {}, val resume: () -> Unit = {}, val pause: () -> Unit = {})
