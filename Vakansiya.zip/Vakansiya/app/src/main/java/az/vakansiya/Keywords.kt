package az.vakansiya

import android.content.Context
import org.json.JSONArray

/**
 * "Xüsusi Vakansiya" açar sözləri.
 * Yazılış: kiçik hərflə, azərbaycan hərfləri sadələşdirilmiş (ə→e, ı→i, ö→o, ü→u, ç→c, ş→s, ğ→g).
 * Prefiks:  "="  → yalnız tam söz kimi (məs. "=it")
 *           "^"  → yalnız başlığın əvvəlində (məs. "^operator")
 *           heç nə → sözün əvvəli uyğun gəlsə kifayətdir (məs. "qeydiyyatci" → "qeydiyyatçısı" da tapılır)
 * Yeni söz əlavə etmək üçün siyahıya sətir əlavə etmək yetərlidir.
 */
object Keywords {
    /** İT (ən yüksək prioritet) — ilkin siyahı */
    val DEF_IT = listOf(
        "=it", "it support", "it destek",
        "informasiya texnologiyalari", "information technology",
        "texniki destek", "texniki mutexessis",
        "technical support", "tech support", "technical specialist", "technical engineer",
        "helpdesk", "help desk", "help-desk", "service desk", "servicedesk",
        "support specialist", "support engineer", "destek mutexessis", "destek muhendis",
        "komputer texniki", "kompyuter texniki", "komputer muhendis", "komputer mutexessis",
        "kompyuter mutexessis", "avadanliq texniki"
    )

    /** Çağrı mərkəzi və qeydiyyat / resepşn — ilkin siyahı */
    val DEF_OTHER = listOf(
        "cagri merkezi", "cagri operator", "cagiris merkezi", "call center", "call centre",
        "call-center", "callcenter", "contact center", "contact centre", "contact-center",
        "elaqe merkezi", "zeng merkezi", "kol merkez", "kol sentr",
        "musteri xidmetleri", "musteri destek", "musteri temsilci", "customer support", "customer service",
        "customer care", "hotline", "qaynar xett", "telefon operator", "kol operator", "zeng operator",
        "elaqe operator", "musteri operator", "chat operator", "online operator", "^operator",
        "qeydiyyatci", "resepsiyon", "resepsion", "resepsn", "ressepsn", "recepsion",
        "reception", "front desk", "frontdesk", "on qeydiyyat"
    )

    private fun prefs(c: Context) = c.getSharedPreferences("kw", Context.MODE_PRIVATE)

    private fun read(c: Context, key: String, def: List<String>): MutableList<String> {
        val s = prefs(c).getString(key, null) ?: return def.toMutableList()
        return try {
            val a = JSONArray(s)
            MutableList(a.length()) { a.getString(it) }
        } catch (e: Exception) { def.toMutableList() }
    }

    fun it(c: Context): MutableList<String> = read(c, "it", DEF_IT)
    fun other(c: Context): MutableList<String> = read(c, "other", DEF_OTHER)

    fun save(c: Context, it: List<String>, other: List<String>) {
        prefs(c).edit().putString("it", JSONArray(it).toString()).putString("other", JSONArray(other).toString()).apply()
    }

    /** Səhifəyə yerləşdirilən JS parçası: S massivi və kindOf(başlıq) / titleOf(link, kart) funksiyaları. */
    fun js(c: Context): String {
        val itJson = JSONArray(it(c)).toString()
        val other = JSONArray(other(c)).toString()
        return """var S=[],KW_IT=$itJson,KW_OT=$other;
function fold(x){return (x||'').toLowerCase().replace(/\u0307/g,'').replace(/ə/g,'e').replace(/ı/g,'i').replace(/ö/g,'o').replace(/ü/g,'u').replace(/ç/g,'c').replace(/ş/g,'s').replace(/ğ/g,'g').replace(/\s+/g,' ').trim()}
function isL(c){return /[a-z0-9\u0430-\u044f\u0451]/.test(c)}
function hasKw(t,kw){kw=fold(kw);var w=false,st=false;
 if(kw.charAt(0)=='='){w=true;kw=kw.substring(1)}else if(kw.charAt(0)=='^'){st=true;kw=kw.substring(1)}
 var i=t.indexOf(kw);
 while(i>=0){
  if(st){if(i==0)return true}
  else{var okL=i==0||!isL(t.charAt(i-1));var okR=!w||i+kw.length>=t.length||!isL(t.charAt(i+kw.length));if(okL&&okR)return true}
  i=t.indexOf(kw,i+1)}
 return false}
function kindOf(title){var t=fold(title);if(t.length<2)return 0;
 for(var i=0;i<KW_IT.length;i++){if(hasKw(t,KW_IT[i]))return 1}
 for(var j=0;j<KW_OT.length;j++){if(hasKw(t,KW_OT[j]))return 2}
 return 0}
function titleOf(a,card){var h=null;try{h=card.querySelector('h1,h2,h3,h4,h5')}catch(e){}
 var s=(h&&h.innerText)?h.innerText:(a.innerText||'');var p=s.split('\n'),o=[];
 for(var i=0;i<p.length&&o.length<2;i++){var z=p[i].trim();if(z)o.push(z)}
 return o.join(' ').substring(0,140)}
"""
    }
}
