package az.market.endirim

object DateUtil {
    private const val MONTHS = "yanvar|fevral|mart|aprel|may|iyun|iyul|avqust|sentyabr|oktyabr|noyabr|dekabr"
    private val IC = RegexOption.IGNORE_CASE

    private val full = Regex("""\d{1,2}[./]\d{1,2}[./]\d{2,4}\s*[-–—]\s*\d{1,2}[./]\d{1,2}[./]\d{2,4}""")
    private val twoMonths = Regex("""(\d{1,2})\s*($MONTHS)\s*[-–—]\s*(\d{1,2})\s*($MONTHS)""", IC)
    private val oneMonth = Regex("""(\d{1,2})\s*[-–—]\s*(\d{1,2})\s*($MONTHS)""", IC)
    private val until = Regex("""(\d{1,2})\s*($MONTHS)\s*(?:adək|ədək|dək|qədər)""", IC)

    private val nameTwo = Regex("""(\d{1,2}) ($MONTHS) (\d{1,2}) ($MONTHS)""")
    private val nameOne = Regex("""(\d{1,2}) (\d{1,2}) ($MONTHS)""")

    /** Mətndən endirim tarixini tapır (səhifə mətni, slayd altındakı yazı, OCR). */
    fun find(text: String): String? {
        val t = text.replace('\u00A0', ' ')
        full.find(t)?.let { return it.value.replace(Regex("""\s+"""), " ") }
        twoMonths.find(t)?.let {
            val g = it.groupValues
            return "${g[1]} ${g[2].lowercase()} - ${g[3]} ${g[4].lowercase()}"
        }
        oneMonth.find(t)?.let {
            val g = it.groupValues
            return "${g[1]}-${g[2]} ${g[3].lowercase()}"
        }
        until.find(t)?.let {
            val g = it.groupValues
            return "${g[1]} ${g[2].lowercase()} tarixinədək"
        }
        return null
    }

    /** Fayl adından, məs: 19-sentyabr_2-oktyabr  və ya  rahat_market_15_20_sentyabr */
    fun fromFileName(name: String): String? {
        val n = name.lowercase().replace('_', ' ').replace('-', ' ')
        nameTwo.find(n)?.let {
            val g = it.groupValues
            return "${g[1]} ${g[2]} - ${g[3]} ${g[4]}"
        }
        nameOne.find(n)?.let {
            val g = it.groupValues
            return "${g[1]}-${g[2]} ${g[3]}"
        }
        return null
    }
}
