package az.wifiscan

import android.app.AlertDialog
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

private val CAT_ORDER = listOf(
    "📱 Bu cihaz (Telefon)", "🌐 Router / Gateway", "🌐 Router (MikroTik)", "📡 Access Point", "📡 Şəbəkə cihazı (AP/Switch)",
    "📷 IP Kamera / NVR", "🚪 Access Control", "🖨 Printer", "📺 TV / Media", "💻 Kompüter", "🖥 Server / Linux",
    "📱 Telefon / Planşet", "📱 Telefon (təsadüfi MAC)", "💡 IoT cihaz", "❓ Naməlum"
)

private sealed class Row {
    class Head(val cat: String, val n: Int, val worst: Int, val open: Boolean) : Row()
    class Dev(val d: Device) : Row()
}

private fun ipKey(ip: String) = ip.split(".").fold(0L) { a, s -> a * 256 + (s.toLongOrNull() ?: 0) }

fun scanPage(u: Ui): Page {
    val p = u.vbox()
    p.addView(u.tv("Wi-Fi Skaner", 22f, u.ACC, true))
    val infoTv = u.tv("", 12f, u.SUB); p.addView(infoTv)
    val pb = ProgressBar(u.act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
    p.addView(pb)
    val cntTv = u.tv("Hazırdır", 13f); p.addView(cntTv)
    val warnTv = u.tv("", 12f, u.ORG); p.addView(warnTv)
    val fullChk = CheckBox(u.act).apply { text = "Tam port skanı (bütün 65535 port, çox uzun çəkir)"; setTextColor(u.TXT); isChecked = true }
    p.addView(fullChk)
    var scanner: Scanner? = null
    val fullRunning = AtomicBoolean(false)
    val userStop = AtomicBoolean(false)
    var fullPool: ExecutorService? = null
    val pend = AtomicBoolean(false)
    val collapsed = HashSet<String>()
    var rows: List<Row> = emptyList()

    fun build(): List<Row> {
        val groups = Store.devices.values.groupBy { it.type }
        val keys = groups.keys.sortedWith(compareBy<String>({ val i = CAT_ORDER.indexOf(it); if (i < 0) 99 else i }, { it }))
        val out = ArrayList<Row>()
        for (k in keys) {
            val list = (groups[k] ?: emptyList()).sortedBy { ipKey(it.ip) }
            val open = k !in collapsed
            out.add(Row.Head(k, list.size, list.maxOfOrNull { it.risk } ?: 0, open))
            if (open) list.forEach { out.add(Row.Dev(it)) }
        }
        return out
    }

    val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(i: Int): Any = rows[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(i: Int) = if (rows[i] is Row.Head) 0 else 1
        override fun getView(i: Int, cv: View?, parent: ViewGroup): View {
            val r = rows[i]
            if (r is Row.Head) {
                val t = (cv as? TextView) ?: u.tv("", 14f, u.ACC, true).apply {
                    setBackgroundColor(u.CARD2); setPadding(u.dp(12), u.dp(10), u.dp(12), u.dp(10))
                    layoutParams = AbsListView.LayoutParams(-1, -2)
                }
                val warn = when (r.worst) { 3 -> "  🔴"; 2 -> "  🟠"; 1 -> "  🟡"; else -> "" }
                t.text = (if (r.open) "▾ " else "▸ ") + r.cat + "  (${r.n})" + warn
                return t
            }
            val d = (r as Row.Dev).d
            val row = (cv as? LinearLayout) ?: LinearLayout(u.act).apply {
                orientation = LinearLayout.VERTICAL; setPadding(u.dp(12), u.dp(10), u.dp(12), u.dp(10)); setBackgroundColor(u.CARD)
                layoutParams = AbsListView.LayoutParams(-1, -2)
                addView(u.tv("", 15f, u.TXT, true)); addView(u.tv("", 13f, u.ACC))
                addView(u.tv("", 12f, u.SUB)); addView(u.tv("", 12f, u.GRN)); addView(u.tv("", 12f, u.ORG))
            }
            (row.getChildAt(0) as TextView).text = d.ip + (if (d.name.isNotBlank()) "   ${d.name}" else "")
            val m = listOf(d.vendor, d.model).filter { it.isNotBlank() }.distinct().joinToString(" • ")
            (row.getChildAt(1) as TextView).text = if (m.isEmpty()) "Model: məlum deyil" else m
            (row.getChildAt(2) as TextView).text = "MAC: ${if (d.mac.isEmpty()) "—" else d.mac}"
            (row.getChildAt(3) as TextView).text =
                if (d.ports.isEmpty()) "🔒 Açıq port yoxdur / yoxlanılır" else "🔓 " + d.ports.joinToString(", ") { "$it ${Net.PORTS[it] ?: ""}" }
            val w = row.getChildAt(4) as TextView
            val vs = d.vulns
            if (vs.isEmpty()) w.visibility = View.GONE else {
                w.visibility = View.VISIBLE
                w.text = "⚠ ${vs.size} xəbərdarlıq • ən yüksək: ${vs[0].label}"
                w.setTextColor(when (d.risk) { 3 -> u.RED; 2 -> u.ORG; else -> u.YEL })
            }
            return row
        }
    }

    fun reload() { rows = build(); adapter.notifyDataSetChanged() }
    fun refresh() { if (pend.compareAndSet(false, true)) u.h.postDelayed({ pend.set(false); reload() }, 200) }

    val lv = ListView(u.act)
    lv.adapter = adapter
    lv.divider = ColorDrawable(u.BG); lv.dividerHeight = u.dp(6)
    lv.setOnItemClickListener { _, _, pos, _ ->
        val r = rows[pos]
        if (r is Row.Head) { if (!collapsed.remove(r.cat)) collapsed.add(r.cat); reload() }
        else if (r is Row.Dev) showDevice(u, r.d)
    }

    fun summary() {
        val hi = Store.devices.values.count { it.risk >= 3 }; val md = Store.devices.values.count { it.risk == 2 }
        warnTv.text = if (hi + md == 0) "✅ Ciddi təhlükə aşkarlanmadı" else "⚠ Yüksək risk: $hi cihaz • Orta risk: $md cihaz (cihaza toxunub ətraflı baxın)"
    }

    fun startFull() {
        fullRunning.set(true)
        val sb = p.findViewWithTag<Button>("scanBtn")
        sb.text = "⏹ Dayandır"
        Thread {
            val list = Store.devices.values.filter { !it.isSelf }.sortedBy { ipKey(it.ip) }
            var idx = 0
            for (d in list) {
                if (!fullRunning.get()) break
                idx++
                val cur = idx
                val ex = Executors.newFixedThreadPool(300); fullPool = ex
                val done = AtomicInteger(0)
                for (pt in 1..65535) ex.execute {
                    if (fullRunning.get() && Net.open(d.ip, pt, 500)) { d.ports.add(pt); Net.classify(d); refresh() }
                    val n = done.incrementAndGet()
                    if (n % 500 == 0) u.post { pb.progress = n * 100 / 65535; cntTv.text = "Tam port skanı $cur/${list.size}: ${d.ip} • $n/65535 • açıq: ${d.ports.size}" }
                }
                ex.shutdown()
                try { ex.awaitTermination(60, TimeUnit.MINUTES) } catch (e: InterruptedException) {}
                if (fullRunning.get()) { try { VulnCheck.run(d) } catch (e: Throwable) {}; refresh() }
            }
            val stopped = !fullRunning.get()
            fullRunning.set(false)
            u.post {
                sb.text = "▶ Yenidən skan"; pb.progress = 100
                cntTv.text = (if (stopped) "Tam port skanı dayandırıldı" else "Tam port skanı bitdi") + " • ${Store.devices.size} cihaz"
                summary(); reload()
            }
        }.start()
    }

    fun toggleScan() {
        if (fullRunning.get()) { fullRunning.set(false); fullPool?.shutdownNow(); return }
        if (scanner != null) { userStop.set(true); scanner?.cancel(); return }
        userStop.set(false)
        val ni = u.netInfo()
        if (ni == null) { u.toast("Wi-Fi şəbəkəsinə qoşulun"); return }
        val (ip, prefix, gw) = ni
        Store.devices.clear(); Store.upnp.clear(); Store.mdns.clear(); Store.gateway = gw; Store.localIp = ip
        reload(); warnTv.text = ""
        infoTv.text = "IP: $ip/$prefix • Gateway: $gw"
        val sb = p.findViewWithTag<Button>("scanBtn")
        sb.text = "⏹ Dayandır"
        val s = Scanner(u.act.applicationContext,
            { refresh() },
            { ps, d, t -> u.post { pb.progress = d * 100 / maxOf(t, 1); cntTv.text = "Keçid $ps/2: $d/$t • Tapılan: ${Store.devices.size}" } },
            {
                u.post {
                    scanner = null; sb.text = "▶ Yenidən skan"; pb.progress = 100
                    cntTv.text = "Bitdi • ${Store.devices.size} cihaz • ${Store.devices.values.map { it.type }.distinct().size} kateqoriya"
                    summary(); reload()
                    if (fullChk.isChecked && Store.devices.size > 1 && !userStop.get()) startFull()
                }
            })
        scanner = s; s.start(ip, prefix, gw)
    }

    val scanBtn = u.btn("▶ Skana başla") { toggleScan() }
    scanBtn.tag = "scanBtn"
    p.addView(scanBtn)
    p.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
    return Page(p)
}

fun showDevice(u: Ui, d: Device) {
    val sv = ScrollView(u.act)
    val box = u.vbox(); box.setPadding(u.dp(16), u.dp(8), u.dp(16), u.dp(8))
    sv.addView(box)
    val s = StringBuilder()
    s.append("Tip: ${d.type}\nIP: ${d.ip}\nMAC: ${d.mac.ifEmpty { "—" }}${if (d.randomMac) " (təsadüfi/private MAC)" else ""}\n")
    s.append("İstehsalçı: ${d.vendor.ifEmpty { "—" }}\nModel: ${d.model.ifEmpty { "—" }}\nAd: ${d.name.ifEmpty { "—" }}\n")
    if (d.upnp.isNotEmpty()) s.append("UPnP: ${d.upnp}\n")
    if (d.http.isNotEmpty()) s.append("Web: ${d.http}\n")
    s.append("\nAçıq portlar:\n")
    if (d.ports.isEmpty()) s.append("  —\n") else d.ports.forEach { s.append("  $it  ${Net.PORTS[it] ?: ""}${d.banners[it]?.let { b -> "  [$b]" } ?: ""}\n") }
    box.addView(u.tv(s.toString(), 13f, u.TXT, false, true))

    val vs = d.vulns
    box.addView(u.tv(if (vs.isEmpty()) "✅ Xəbərdarlıq tapılmadı" else "⚠ Təhlükəsizlik xəbərdarlıqları (${vs.size})", 14f, if (vs.isEmpty()) u.GRN else u.ORG, true).apply { setPadding(0, u.dp(10), 0, u.dp(4)) })
    vs.forEach { box.addView(u.vulnView(it)) }
    box.addView(u.tv("Yoxlama açıq portlara və bannerlərə əsaslanır; tam təhlükəsizlik auditi əvəz etmir.", 11f, u.SUB).apply { setPadding(0, u.dp(6), 0, u.dp(8)) })

    val dlg = AlertDialog.Builder(u.act).setTitle(d.ip).setView(sv).setNegativeButton("Bağla", null).create()
    val acts = ArrayList<Pair<String, () -> Unit>>()
    acts.add("🏓 Ping" to { dlg.dismiss(); u.go(2, d.ip) })
    acts.add("🧭 Traceroute" to { dlg.dismiss(); u.go(3, d.ip) })
    acts.add("🔌 Port skan" to { dlg.dismiss(); u.go(1, d.ip) })
    acts.add("🔎 DNS / WHOIS" to { dlg.dismiss(); u.go(5, d.ip) })
    if (554 in d.ports || d.type.contains("Kamera")) {
        acts.add("📹 Canlı bax (RTSP)" to { dlg.dismiss(); u.openCamera(d.ip, "${d.vendor} ${d.model} ${d.name}".trim()) })
    }
    var i = 0
    while (i < acts.size) {
        val line = LinearLayout(u.act).apply { orientation = LinearLayout.HORIZONTAL }
        for (j in i until minOf(i + 2, acts.size)) {
            val a = acts[j]
            line.addView(u.btn(a.first) { a.second() }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        box.addView(line)
        i += 2
    }
    dlg.show()
}
