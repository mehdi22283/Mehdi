plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "az.videoyabax.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "az.videoyabax.tv"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // TV-də göstərilən standart ünvan (lazım gələrsə dəyişin)
        buildConfigField("String", "DEFAULT_TV_IP", "\"192.168.31.220\"")
        buildConfigField("int", "SERVER_PORT", "3169")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            // Sideload üçün debug açarı ilə imzalanır (GitHub Actions-da avtomatik yaranır)
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    // APK faylının adı: "Videoya bax.apk"
    applicationVariants.all {
        outputs.all {
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl)
                .outputFileName = "Videoya bax.apk"
        }
    }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("com.google.zxing:core:3.5.3")
}
