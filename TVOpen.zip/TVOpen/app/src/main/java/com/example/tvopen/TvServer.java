package com.example.tvopen;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.SSLContext;

/**
 * Bir portda həm http://, həm https:// qəbul edən sadə server.
 * Gələn ilk bayt 0x16 (TLS) olarsa, bağlantı daxili TLS serverə yönləndirilir.
 */
public class TvServer {

    public interface Opener { void open(String url) throws Exception; }

    private final int port;
    private final SSLContext ssl;
    private final Opener opener;

    private volatile boolean running = false;
    private ServerSocket mainSocket;
    private ServerSocket tlsSocket;

    private String lastUrl = "";
    private long lastTime = 0;

    public TvServer(int port, SSLContext ssl, Opener opener) {
        this.port = port;
        this.ssl = ssl;
        this.opener = opener;
    }

    public synchronized void start() throws IOException {
        if (running) return;
        ServerSocket m = new ServerSocket();
        m.setReuseAddress(true);
        m.bind(new InetSocketAddress(port));
        ServerSocket t = null;
        if (ssl != null) {
            t = ssl.getServerSocketFactory()
                    .createServerSocket(0, 50, InetAddress.getByName("127.0.0.1"));
        }
        mainSocket = m;
        tlsSocket = t;
        running = true;
        if (t != null) loop(t, false);
        loop(m, true);
    }

    public synchronized void stop() {
        running = false;
        close(mainSocket);
        close(tlsSocket);
        mainSocket = null;
        tlsSocket = null;
    }

    private void loop(final ServerSocket ss, final boolean routed) {
        Thread th = new Thread(() -> {
            while (running) {
                try {
                    final Socket s = ss.accept();
                    new Thread(() -> {
                        if (routed) route(s); else serve(s, "");
                    }).start();
                } catch (IOException e) {
                    break;
                }
            }
        }, routed ? "tv-main" : "tv-tls");
        th.setDaemon(true);
        th.start();
    }

    // Əsas port: ilk bayta baxıb http / https seçir
    private void route(Socket s) {
        try {
            s.setSoTimeout(10000);
            InputStream in = s.getInputStream();
            int first = in.read();
            if (first < 0) { close(s); return; }
            if (first == 0x16 && tlsSocket != null) {
                tunnel(s, in, first);
            } else {
                serve(s, String.valueOf((char) first));
            }
        } catch (Exception e) {
            close(s);
        }
    }

    private void tunnel(Socket client, InputStream cin, int first) throws IOException {
        Socket local = new Socket("127.0.0.1", tlsSocket.getLocalPort());
        local.setSoTimeout(10000);
        OutputStream lo = local.getOutputStream();
        lo.write(first);
        lo.flush();
        final InputStream li = local.getInputStream();
        final OutputStream co = client.getOutputStream();
        new Thread(() -> pump(li, co, local, client)).start();
        pump(cin, lo, local, client);
    }

    private static void pump(InputStream in, OutputStream out, Socket a, Socket b) {
        byte[] buf = new byte[8192];
        try {
            int n;
            while ((n = in.read(buf)) >= 0) {
                out.write(buf, 0, n);
                out.flush();
            }
        } catch (IOException ignored) {
        } finally {
            close(a);
            close(b);
        }
    }

    // HTTP sorğusunu oxuyub cavab verir (s ya adi, ya da TLS soketdir)
    private void serve(Socket s, String prefix) {
        try {
            s.setSoTimeout(10000);
            InputStream in = s.getInputStream();
            String line = readLine(in, prefix);
            if (line.isEmpty()) { close(s); return; }
            for (int i = 0; i < 64; i++) {           // başlıqları oxuyub at
                if (readLine(in, "").isEmpty()) break;
            }

            String[] parts = line.split(" ");
            String path = parts.length >= 2 ? parts[1] : "/";

            if (path.startsWith("/favicon")) {
                send(s, "404 Not Found", "");
                return;
            }
            if (!path.startsWith("/") || path.equals("/")) {
                send(s, "200 OK", "Filme bax isleyir. Istifade: TV_IP:" + port + "/google.com");
                return;
            }

            String url = path.substring(1);
            url = url.replaceFirst("^(?i)(https?):/+", "$1://");   // https:/x -> https://x
            if (!url.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
                url = "https://" + url;
            }

            String msg;
            if (isDuplicate(url)) {
                msg = "TV-de acildi: " + url;
            } else {
                try {
                    opener.open(url);
                    msg = "TV-de acildi: " + url;
                } catch (Exception e) {
                    msg = "Acila bilmedi (TV-de brauzer yoxdur?): " + e.getMessage();
                }
            }
            send(s, "200 OK", msg);
        } catch (Exception ignored) {
            close(s);
        }
    }

    // Brauzer eyni sorğunu iki dəfə göndərərsə, ikinci dəfə açmır
    private synchronized boolean isDuplicate(String url) {
        long now = System.currentTimeMillis();
        boolean dup = url.equals(lastUrl) && now - lastTime < 2000;
        lastUrl = url;
        lastTime = now;
        return dup;
    }

    private static void send(Socket s, String status, String text) throws IOException {
        byte[] body = ("<html><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='font-family:sans-serif;font-size:20px;padding:24px'>"
                + text.replace("<", "&lt;") + "</body></html>").getBytes(StandardCharsets.UTF_8);
        String head = "HTTP/1.1 " + status + "\r\nContent-Type: text/html; charset=utf-8\r\n"
                + "Content-Length: " + body.length + "\r\nConnection: close\r\n\r\n";
        OutputStream out = s.getOutputStream();
        out.write(head.getBytes(StandardCharsets.UTF_8));
        out.write(body);
        out.flush();
        close(s);
    }

    private static String readLine(InputStream in, String prefix) throws IOException {
        StringBuilder sb = new StringBuilder(prefix);
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r' && sb.length() < 8192) sb.append((char) c);
        }
        return sb.toString();
    }

    private static void close(Closeable c) {
        try { if (c != null) c.close(); } catch (IOException ignored) { }
    }
}
