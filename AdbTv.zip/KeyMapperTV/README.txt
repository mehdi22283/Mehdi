1) Android Studio -> Open -> KeyMapperTV -> Build > Build APK(s)
2) adb connect 192.168.31.220:5555
   adb install -r app/build/outputs/apk/debug/app-debug.apk
3) TV-de "Key Mapper TV" tetbiqini bir defe acin (batareya icazesi ve ayarlar acilacaq).
4) Ayarlar > Elcatimliliq > Endirilmis tetbiqler > Key Mapper TV > ON
5) Ilk qosulmada ADB icazesi cixsa: "Always allow".
