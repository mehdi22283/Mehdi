package az.vakansiya

import android.content.Context
import java.util.Calendar

/** Saytlardakı elanları sayan və "Xüsusi Vakansiya" açar sözlərini axtaran JS skriptləri (həm Counter, həm CheckWorker istifadə edir). */
object Scan {
    // ay adları: tam adlar (şəkilçi ilə də gələ bilər: "oktyabrın") və qısaltmalar (arxasında hərf olmamalıdır: "okt", "oct") - azərbaycanca və ingiliscə
    private val monthsFull = arrayOf(
        "yanvar|january",
        "fevral|february",
        "mart|march",
        "aprel|april",
        "mayın|mayda",
        "iyun|june",
        "iyul|july",
        "avqust|august",
        "sentyabr|september",
        "oktyabr|october",
        "noyabr|november",
        "dekabr|december"
    )
    private val monthsShort = arrayOf(
        "yan|jan", "fev|feb", "mar", "apr", "may", "iyn|jun",
        "iyl|jul", "avq|aug", "sen|sep|sept", "okt|oct", "noy|nov", "dek|dec"
    )
    private const val LT = "a-zəıöüçşğ"
    private val end = "\$"
    private val nb = "(^|[^0-9])"
    private val na = "([^0-9]|$end)"
    // gün və ya ay arasındakı ayırıcı: 13.10.2026, 13-10-26, 13/10/2026, 13 . 10 . 2026
    private val ns = "[ ]?[./-][ ]?"
    // günün sonundakı sıra şəkilçisi: 13th, 13-cü, 13-də, 13-ü
    private val ord = "(st|nd|rd|th|-?(ci|cı|cu|cü|nci|ncı|ncu|ncü|də|da|dən|dan|ndə|nda|ü|u))?"

    private fun datePat(c: Calendar): String {
        val d = c.get(Calendar.DAY_OF_MONTH)
        val m = c.get(Calendar.MONTH) + 1
        val y = c.get(Calendar.YEAR)
        val yy = y % 100
        val mn = "(?:(?:${monthsFull[m - 1]})[$LT]*|(?:${monthsShort[m - 1]})(?![$LT]))"
        // ay-gün yazılışından sonra başqa (köhnə) il gəlirsə tarix bu günə aid deyil: "13 oktyabr 2025"
        val yg = "(?![ .,-]*(?!$y)[0-9]{4})"
        val list = mutableListOf(
            "${nb}0?$d${ns}0?$m$ns($y|$yy)$na",                       // 13.10.2026, 13-10-26, 13/10/2026
            "${nb}$y$ns" + "0?$m$ns" + "0?$d$na",                      // 2026-10-13, 2026.10.13, 2026/10/13 (ISO də)
            "${nb}0?$d$ord[ .,-]*(of )?$mn$yg",                       // 13 okt, 13 Oktyabr, 13th Oct, 13-cü oktyabr
            "$mn[ .,-]*(the )?0?$d(?![0-9:])$yg",                      // okt 13, Oktyabr 13, October 13th, oktyabrın 13-də
            "(^|[^0-9./:,-])0?$d[./]0?$m(?![0-9]|[./-][0-9]| ?(azn|₼|manat|%|m2|m²|km|kq|kg))" // 13.10, 13/10 (ilsiz)
        )
        // ABŞ formatı 10/13/2026 - yalnız gün 12-dən böyükdürsə (qarışmasın deyə)
        if (d > 12) list.add("${nb}0?$m${ns}0?$d$ns($y|$yy)$na")
        return list.joinToString("|")
    }

    private val tw = "bu gün(?!lər)|bu gun|bu gündən|bu gunden|bu günkü|bu gunku|today|indicə|indice|az əvvəl|az evvel|saniyə əvvəl|saniye evvel|bir neçə dəqiqə|bir necə dəqiqə|just now|bir neçə saat|bir necə saat|neçə saat əvvəl|few hours ago"
    private val yw = "dünən|dunen|dünənki|yesterday|${nb}(1|bir|one)[ ]*(gün|gun|day)[ ]*(əvvəl|evvel|öncə|once|ago)|(^|[^$LT])a day ago|${nb}1 ?(d|g)[ ]*(ago|əvvəl|evvel)(?![$LT])"
    private val d3w = "${nb}(2|iki|two)[ ]*(gün|gun|days?)[$LT.]*[ ]*(əvvəl|evvel|öncə|oncə|ago)|srağagün|srağa gün|sragagun|sraga gun|day before yesterday|${nb}2 ?(d|g)[ ]*(ago|əvvəl|evvel)(?![$LT])"
    private val hr = "([0-9]+|bir)[ ]*(saat|hour|hr)[$LT.]*[ ]*(əvvəl|evvel|öncə|oncə|ago)"
    private val mn = "([0-9]+|bir)[ ]*(dəq|dəqiqə|min)[$LT.]*[ ]*(əvvəl|evvel|öncə|oncə|ago)"
    // qısa yazılış: "5h ago", "5 hrs ago", "5m ago"
    private val hrs = "${nb}([0-9]+) ?(h|hrs?)[ ]+ago"
    private val mns = "${nb}([0-9]+) ?m[ ]+ago"

    private fun jsStrArr(a: Array<String>) = a.joinToString(",", "[", "]") { "'" + it + "'" }

    /** Ümumi (və "diqqətli" kart əsaslı) sayma skripti. */
    fun js(ctx: Context, careful: Boolean, url: String = "", resolve: Boolean = false): String {
        // /internship-program saytı /vacancies-ə yönləndirilə bilər: staj rejimi skan ünvanından təyin olunur, səhifənin ünvanından yox
        val onst = url.contains("internship")
        val cal = Calendar.getInstance()
        val td = datePat(cal)
        cal.add(Calendar.DAY_OF_MONTH, -1)
        val yd = datePat(cal)
        cal.add(Calendar.DAY_OF_MONTH, -1)
        val wd = datePat(cal)
        return """(function(){
var L=JSON.parse(${Links.js(careful)});
var careful=$careful;
${Keywords.js(ctx)}
var TW=new RegExp("$tw"),YW=new RegExp("$yw"),D3=new RegExp("$d3w"),WD=new RegExp("$wd"),TD=new RegExp("$td"),YD=new RegExp("$yd"),HR=new RegExp("$hr"),MN=new RegExp("$mn"),HRS=new RegExp("$hrs"),MNS=new RegExp("$mns");
var DL=/(son tarix|son müraciət tarixi|son müraciət|son gün|deadline|bitmə tarixi|bitmə|bitir|bitər|bitəcək|başa çatır|müraciət müddəti|expires|expire|valid until|until)[: ]*[0-9]{1,2}[ .\/-]+[a-zəıöüçşğ0-9]+([ .\/-]+[0-9]{2,4})?/g;
var DL2=/[0-9]{1,2}[ .\/-]+[a-zəıöüçşğ0-9]+([ .\/-]+[0-9]{2,4})?[a-zəı-]* ?(tarixinə |tarixədək )?(qədər|dək)/g;
var RG=/([0-9]{1,2}[.\/-][0-9]{1,2}[.\/-][0-9]{2,4}) ?[-–—] ?[0-9]{1,2}[.\/-][0-9]{1,2}[.\/-][0-9]{2,4}/g;
var LBL=/^(son tarix|son müraciət( tarixi)?|son gün|bitmə( tarixi)?|bitir|bitər|deadline|müraciət müddəti)[: ]*${'$'}/;
var MRX=/(^|[^0-9])([0-9]{1,2})(?:st|nd|rd|th|-?[a-zəıöüçşğ]{1,3})? ?(?:of )?([a-zəıöüçşğ]{3,14})\.?,? ?([0-9]{4})?/g,MRX2=/(^|[^a-zəıöüçşğ])([a-zəıöüçşğ]{3,14})\.? ?([0-9]{1,2})(?![0-9:])(?:,? ?([0-9]{4})(?![0-9]))?/g;
var MF=${jsStrArr(monthsFull)},MSH=${jsStrArr(monthsShort)};
var MONRX=(function(){var o=[];for(var i=0;i<12;i++){o.push([new RegExp('^(?:'+MF[i]+')[$LT]*${'$'}'),new RegExp('^(?:'+MSH[i]+')${'$'}')])}return o})();
/* sözün ay adı olub-olmadığı (tam söz və ya qısaltma): "junior", "senior", "market" ay sayılmır */
function monOf(w){w=(w||'').toLowerCase().replace(/\u0307/g,'');for(var i=0;i<12;i++){if(MONRX[i][0].test(w)||MONRX[i][1].test(w))return i+1}return 0}
/* "30 gün qalır", "qalan 30 gün", "30 days left": N gün qalır - 30 = bu gün, 29 = dünən, 28 = 2 gün əvvəl */
var CDA=/([0-9]+) ?(gün|gun|days?) ?(qal[ıi]r|qal[ıi]b|qalan|qaldı|left|remaining)/,CDB=/(qal[ıi]r|qal[ıi]b|qalan|qaldı|left|remaining)[: ]*([0-9]+) ?(gün|gun|days?)/;
function cdLeft(x){var m=x.match(CDA);if(m)return parseInt(m[1]);m=x.match(CDB);if(m)return parseInt(m[2]);return -1}
function ageYMD(y,m,d){var a=new Date(y,m-1,d),b=new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate());return Math.round((b-a)/86400000)}
/* mətndəki ən köhnə tarixin yaşı (gün): elan tarixi + bitmə tarixi birgə yazılıbsa, bitmə tarixi bu günə uyğun gəlib köhnə elanı saymasın */
function oldest(x){var mx=-9999,m,re1=/(^|[^0-9])([0-9]{1,2})[.\/-]([0-9]{1,2})[.\/-]([0-9]{4}|[0-9]{2})(?![0-9])/g,re2=/(^|[^0-9])([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})(?![0-9])/g,a;
 while((m=re1.exec(x))){var yy=parseInt(m[4]);if(yy<100)yy+=2000;a=ageYMD(yy,parseInt(m[3]),parseInt(m[2]));if(a>mx)mx=a}
 while((m=re2.exec(x))){a=ageYMD(parseInt(m[2]),parseInt(m[3]),parseInt(m[4]));if(a>mx)mx=a}
 while((m=MRX.exec(x))){var mo=monOf(m[3]);if(!mo)continue;var y2=m[4]?parseInt(m[4]):new Date().getFullYear();a=ageYMD(y2,mo,parseInt(m[2]));if(!m[4]&&a<-60)a=ageYMD(y2-1,mo,parseInt(m[2]));if(a>mx)mx=a}
 MRX.lastIndex=0;
 while((m=MRX2.exec(x))){var mo2=monOf(m[2]);if(!mo2)continue;var y3=m[4]?parseInt(m[4]):new Date().getFullYear();a=ageYMD(y3,mo2,parseInt(m[3]));if(!m[4]&&a<-60)a=ageYMD(y3-1,mo2,parseInt(m[3]));if(a>mx)mx=a}
 MRX2.lastIndex=0;return mx}
var GL=location.hostname.indexOf('glorri')>=0,TM=/(^|[^0-9:.])([01]?[0-9]|2[0-3]):([0-5][0-9])([^0-9:]|$)/;
var HN=location.hostname,SCR=true,JU=HN.indexOf('jobu')>=0,IQ=HN.indexOf('iseqebul')>=0,JO=HN.indexOf('jooble')>=0,BS=HN.indexOf('boss.az')>=0,WK=HN.indexOf('work.az')>=0,VZ=HN.indexOf('vezife.az')>=0,RESOLVE=$resolve,UW={},PEND=0,RZ=[0,0,0],DET=(window.__vkDet=window.__vkDet||{}),RS=[];
var SHM='yan|fev|mar|apr|may|iyn|iyl|avq|sen|okt|noy|dek|jan|feb|jun|jul|aug|sep|oct|nov|dec';
var DATEISH=new RegExp('([0-9]{1,2})[ .\\/-]+([a-zəıöüçşğ]{3,9}|[0-9]{1,2})[ .\\/-]+[0-9]{2,4}|[0-9]+ ?(gün|saat|dəq|day|hour|min)|dünən|bu gün|today|yesterday|[0-9]{1,2}(st|nd|rd|th)? ?(of )?('+SHM+')|('+SHM+')[a-zəıöüçşğ]*\\.? ?[0-9]{1,2}([^0-9]|$)|[0-9]+ ?[a-zəıöüçşğ]+ ?(əvvəl|evvel|öncə|ago)|qal[ıi][rb]|srağa');
var now=new Date(),mins=now.getHours()*60+now.getMinutes(),UN=0;
/* yazılan saat (14:30) indiki saatdan böyük deyilsə bu gün, böyükdürsə hələ gəlməyib deməli dünəndir */
function timeCls(h,m){return h*60+m<=mins?1:2}
var HALF=/yarım saat əvvəl|yarim saat evvel|half an hour ago/;
function agoCls(totMin){if(totMin<=mins)return 1;var a=1+Math.floor((totMin-mins-1)/1440);return a==1?2:(a==2?3:0)}
function cls(x){x=x.toLowerCase().replace(/\u0307/g,'').replace(/\s+/g,' ');var cd=cdLeft(x);x=x.replace(RG,function(m,a){return a}).replace(DL,' ').replace(DL2,' ');
if(IQ&&cd>=0){var qa=30-cd;return qa==0?1:(qa==1?2:(qa==2?3:0))}
if(D3.test(x))return 3;if(YW.test(x))return 2;if(HALF.test(x))return agoCls(30);if(TW.test(x))return 1;
if(cd==30)return 1;if(cd==29)return 2;if(cd==28)return 3;
var m=x.match(HR);if(m){var n=(m[1]=='bir')?1:parseInt(m[1]);return agoCls(n*60)}
m=x.match(HRS);if(m)return agoCls(parseInt(m[2])*60);
m=x.match(MN);if(m){var q=(m[1]=='bir')?1:parseInt(m[1]);return agoCls(q)}
m=x.match(MNS);if(m)return agoCls(parseInt(m[2]));
if(oldest(x)>2)return 0;if(TD.test(x))return 1;if(YD.test(x))return 2;if(WD.test(x))return 3;if(GL){var tm=x.match(TM);if(tm)return timeCls(parseInt(tm[2]),parseInt(tm[3]))}return 0}
function lineCount(){RS=[];var lines=(document.body?document.body.innerText:'').split('\n'),t=0,y=0,w=0,p='';
for(var i=0;i<lines.length;i++){var l=lines[i].replace(/\s+/g,' ').trim().toLowerCase();if(l.length<3||l===p)continue;var p0=p;p=l;var r=cls(l);if(r>0&&LBL.test(p0))r=0;if(r>0||DATEISH.test(l))RS.push(r);if(r==1)t++;else if(r==2)y++;else if(r==3)w++}
return [t,y,w]}
function isoL(v){v=(v||'').trim();if(/^[0-9]{10}$/.test(v))v=new Date(parseInt(v)*1000).toISOString();else if(/^[0-9]{13}$/.test(v))v=new Date(parseInt(v)).toISOString();if(!/^[0-9]{4}-[0-9]{2}-[0-9]{2}/.test(v))return v;var d=new Date(v);if(isNaN(d.getTime()))return v;return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()}
function dattr(el){var s='';try{var q=el.querySelectorAll('time,[datetime],[data-date],[data-created],[data-time],[data-posted],[data-timestamp],[data-published],[data-publish],[data-added],[data-created-at],[data-posted-at],meta[itemprop=datePosted],meta[itemprop=datePublished]');
 for(var i=0;i<q.length&&i<10;i++){var e=q[i],v=e.getAttribute('datetime')||e.getAttribute('data-date')||e.getAttribute('data-created')||e.getAttribute('data-time')||e.getAttribute('data-posted')||e.getAttribute('data-timestamp')||e.getAttribute('data-published')||e.getAttribute('data-publish')||e.getAttribute('data-added')||e.getAttribute('data-created-at')||e.getAttribute('data-posted-at')||e.getAttribute('content')||'';if(v)s+=' '+isoL(v)}
 /* ikon / tooltip: title="13.10.2026" və ya aria-label="2 saat əvvəl" */
 var tq=el.querySelectorAll('[title],[aria-label]');
 for(var j=0;j<tq.length&&j<30;j++){var tv=(tq[j].getAttribute('title')||tq[j].getAttribute('aria-label')||'').replace(/\s+/g,' ').trim();if(tv.length>=3&&tv.length<=40&&DATEISH.test(tv.toLowerCase()))s+=' '+tv}}catch(e){}return s}
function dayDiff(v){var d=new Date(v);if(isNaN(d.getTime()))return -1;var a=new Date(d.getFullYear(),d.getMonth(),d.getDate()),b=new Date(now.getFullYear(),now.getMonth(),now.getDate());return Math.round((b-a)/86400000)}
function jsonCount(){RS=[];
 var found=[],seenT={};
 function add(t,v,u){if(!t||!v||typeof t!='string')return;var dd=dayDiff(v);if(dd<0)return;t=t.replace(/\s+/g,' ').trim();var kk=t+'|'+v+'|'+(u||'');if(t.length<3||seenT[kk])return;seenT[kk]=1;found.push({t:t,d:dd,u:u||''})}
 function walk(o,dep){if(!o||dep>14)return;
  if(Array.isArray(o)){for(var i=0;i<o.length&&i<600;i++)walk(o[i],dep+1);return}
  if(typeof o!='object')return;
  var t=o.title||o.name||o.position||o.vacancy_title||o.job_title||o.jobTitle,v=o.datePosted||o.created_at||o.createdAt||o.created||o.posted_at||o.postedAt||o.published_at||o.publishedAt||o.start_date||o.startDate||o.date||o.publish_date,u=o.url||o.link||o.href||'';
  if(typeof t=='string'&&typeof v=='string'&&/^[0-9]{4}-[0-9]{2}-[0-9]{2}/.test(v))add(t,v,(typeof u=='string')?u:'');
  for(var k in o){if(o.hasOwnProperty(k)&&o[k]&&typeof o[k]=='object')walk(o[k],dep+1)}}
 var sc=document.querySelectorAll('script[type="application/ld+json"],script#__NEXT_DATA__,script[type="application/json"]');
 for(var i=0;i<sc.length;i++){try{walk(JSON.parse(sc[i].textContent),0)}catch(e){}}
 if(found.length<3)return null;
 var an=document.querySelectorAll('a[href]'),t=0,y=0,w=0;
 for(var i=0;i<found.length;i++){var f=found[i],h=f.u;
  if(!h||h.indexOf('http')!=0){h='';var ft=fold(f.t);
   for(var j=0;j<an.length;j++){var at=fold(an[j].innerText||'');if(at.length>3&&at.indexOf(ft)>=0&&an[j].href.indexOf('http')==0){h=an[j].href;break}}
   if(!h)h=(f.u&&f.u.charAt(0)=='/')?location.origin+f.u:location.href}
  if(f.d==0)t++;else if(f.d==1)y++;else if(f.d==2)w++;RS.push(f.d==0?1:(f.d==1?2:(f.d==2?3:0)));
  if(f.d==0||f.d==1||f.d==2)S.push({n:f.t.substring(0,140),h:h,d:f.d,k:kindOf(f.t)})}
 return [t,y,found.length,w]}
/* ===== Təqvim / saat ikonu, "Yeni" nişanı ===== */
var ICK=/(^|[^a-z])(calendar|calender|clock|time|schedule|date|datetime|event|history|hourglass|stopwatch|timer|watch|posted|saat|tarix|taqvim|təqvim)([^a-z]|$)|\u23F0|\u231A|\u23F1|\u23F2|\uD83D[\uDD50-\uDD67]|\uD83D\uDCC5|\uD83D\uDCC6|\uD83D\uDDD3/;
var DLK=/(^|[^a-z])(deadline|expire|expires|expiry|due|end|ends|until|son|bitir|bitmə)([^a-z]|$)/;
function icSig(e){var s='';try{s=(e.tagName||'')+' '+(e.getAttribute('class')||'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||'')+' '+(e.getAttribute('alt')||'')+' '+(e.getAttribute('data-icon')||'')+' '+(e.getAttribute('data-testid')||'')+' '+(e.getAttribute('name')||'')+' '+(e.getAttribute('src')||'');
 if(e.children.length==0&&(e.textContent||'').trim().length<=24)s+=' '+(e.textContent||'');
 var us=e.querySelector?e.querySelector('use'):null;if(us)s+=' '+(us.getAttribute('href')||us.getAttribute('xlink:href')||'')}catch(x){}
 return s.replace(/([a-z])([A-Z])/g,function(m,a,b){return a+'-'+b}).toLowerCase()}
/* Təqvim / saat ikonunun SOLUNDA və ya SAĞINDA (qardaş mətn və ya qardaş element) həmişə elanın tarixi yazılır: ikonun yanındakı yazı birinci oxunur */
var ICF=false;
function txtOf(n){return ((n.nodeType==3?n.nodeValue:n.textContent)||'').replace(/\s+/g,' ').trim()}
function isGlyph(t){return t.length==0||(/^[a-z_ ]+$/i.test(t)&&t.length<24&&ICK.test(t.toLowerCase()))||/^[\u23F0\u231A\u23F1\u23F2\uD83D\uDD50-\uDD67\uDCC5\uDCC6\uDDD3]+${'$'}/.test(t)}
function adjTexts(e,card){var o=[],el=e,lv=0,t;
 if(e.children.length==0){t=txtOf(e);if(!isGlyph(t))o.push(t)}
 while(el&&el!==card&&!o.length&&lv<3){var n=el.nextSibling,g=0;
  while(n&&g<3){t=txtOf(n);if(t&&!isGlyph(t))o.push(t);n=n.nextSibling;g++}
  var p=el.previousSibling;g=0;
  while(p&&g<3){t=txtOf(p);if(t&&!isGlyph(t))o.push(t);p=p.previousSibling;g++}
  el=el.parentElement;lv++}
 if(!o.length&&e.parentElement&&e.parentElement!==card)o.push(txtOf(e.parentElement));
 return o}
/* qaytarır: 0..3 (ikonun yanındakı tarixə görə) və ya -1 (ikon/tarix tapılmadı). Gələcək tarix (son tarix) ikonu atlanır. */
function iconDate(card){ICF=false;
 try{var q=card.querySelectorAll('i,svg,img,span,em,time,label,ion-icon,mat-icon,small,b,div,p'),n=0;
  for(var i=0;i<q.length&&i<120&&n<8;i++){var e=q[i],sg=icSig(e);if(!ICK.test(sg)||DLK.test(sg))continue;n++;
   var ts=adjTexts(e,card);
   for(var k=0;k<ts.length;k++){var v=ts[k];if(v.length>40)continue;var lv=v.toLowerCase().replace(/\u0307/g,'').replace(/\s+/g,' '),r=cls(lv),od=oldest(lv);
    if(r>0){ICF=true;return r}
    if(DATEISH.test(lv)||od>-9999){if(od<0)continue;ICF=true;return 0}}}}catch(x){}
 return -1}
function icCls(card,ct){var ir=iconDate(card);return ir>=0?ir:cls(ct)}
/* "Yeni" nişanı (başqa tarix yoxdursa bu gün) */
function extraCls(card,ct){try{var lc=(ct||'').toLowerCase();
 if(!IQ&&!GL&&badgeNew(card)&&(VZ||!DATEISH.test(lc)))return 1}catch(x){}return 0}
var GLS=0;
function ageOf(lw){var b=new Date(now.getFullYear(),now.getMonth(),now.getDate()),m;
 if(/^(dünən|dunen)/.test(lw))return 1;
 if(/^bu gün/.test(lw))return 0;
 var tm0=lw.match(/^([01]?[0-9]|2[0-3]):([0-5][0-9])( |$)/);if(tm0)return (parseInt(tm0[1])*60+parseInt(tm0[2]))<=mins?0:1;
 var hm0=lw.match(/^([0-9]+) (saat|dəq)/);if(hm0){var tot0=parseInt(hm0[1])*(hm0[2]=='saat'?60:1);return tot0<=mins?0:1+Math.floor((tot0-mins-1)/1440)}
 m=lw.match(/^([0-9]+) gün/);if(m)return parseInt(m[1]);
 m=lw.match(/^([0-9]{1,2})[-.\/]([0-9]{1,2})[-.\/]([0-9]{2,4})/);
 if(m){var yr=parseInt(m[3]);if(yr<100)yr+=2000;return Math.round((b-new Date(yr,parseInt(m[2])-1,parseInt(m[1])))/86400000)}
 return -1}
function glorriScan(){
 var Z=[],R=(document.body?document.body.innerText:'').split('\n');
 for(var i=0;i<R.length;i++){var z=R[i].replace(/\s+/g,' ').trim();if(z)Z.push(z)}
 var DRX=/^[0-9]{1,2}[-.\/][0-9]{1,2}[-.\/][0-9]{2,4}( |$)/,RX=/^(bu gün|dünən|dunen|[0-9]+ (saat|gün|dəq)[a-zəı]* əvvəl)/,TX=/^([01]?[0-9]|2[0-3]):[0-5][0-9]( |$)/;
 var st=0,RES=/[0-9]+ ?\/ ?[0-9]+/,q0=0;
 for(var q=0;q<Z.length;q++){if(/^esas vakansiya/.test(fold(Z[q]))){q0=q;break}}
 for(var q=q0;q<Z.length;q++){var fz=fold(Z[q]);if(Z[q].length<60&&RES.test(fz)&&(fz.indexOf('netic')>=0||/^[0-9]+ ?\/ ?[0-9]+$/.test(fz))){st=q+1;break}}
 var t=0,y=0,w=0,n=0,seen={},seenNew=false,oldAfter=0,an=document.querySelectorAll('a[href]');
 for(var i=st+2;i<Z.length;i++){var l=Z[i],lw=l.toLowerCase();
  if(l.length>40)continue;
  if(!(DRX.test(lw)||RX.test(lw)||TX.test(lw)))continue;
  var title=Z[i-2];if(/^pro$/i.test(title)&&i-3>=st)title=Z[i-3];
  var comp=Z[i-1];
  if(!title||title.length<3||title.length>200||DRX.test(title.toLowerCase()))continue;
  var key=title+'|'+comp;if(seen[key])continue;seen[key]=1;n++;
  var r=cls(lw),h='',ft=fold(title);
  for(var j=0;j<an.length;j++){var at=fold(an[j].innerText||'');if(at.length>0&&at.length<ft.length+250&&at.indexOf(ft)>=0&&an[j].href.indexOf('http')==0){h=an[j].href.split('#')[0];break}}
  if(!h)h=location.href.split('#')[0]+'#g'+n;
  if(L.indexOf(h)<0)L.push(h);
  var ag=ageOf(lw);if(ag>=0&&ag<=2)seenNew=true;else if(ag>2&&seenNew)oldAfter++;
  if(r>0){if(r==1)t++;else if(r==2)y++;else w++;S.push({n:title.substring(0,140),h:h,d:(r==1?0:(r==2?1:2)),k:kindOf(title)})}}
 if(oldAfter<4){try{var se=document.scrollingElement||document.documentElement;window.scrollTo(0,se.scrollHeight);
  var al=document.querySelectorAll('div,main,section,ul');
  for(var k=0;k<al.length&&k<500;k++){var e2=al[k];if(e2.clientHeight>100&&e2.scrollHeight>e2.clientHeight+80){var oy=getComputedStyle(e2).overflowY;if(oy=='auto'||oy=='scroll')e2.scrollTop=e2.scrollHeight}}
  window.dispatchEvent(new Event('scroll'));
  var bs=document.querySelectorAll('button,[role=button]');
  for(var k=0;k<bs.length;k++){var tx=fold(bs[k].innerText||'');if(tx.length<30&&/^(daha cox( goster| yukle)?|load more|show more|more)$/.test(tx)){bs[k].click();break}}}catch(e){}}
 GLS=n>=3?(oldAfter>=4?2:1):0;
 return n>=3?[t,y,n,w]:null}
function cardCount(){RS=[];UW={};RZ=[0,0,0];
var A=[],hs=document.querySelectorAll('h1 a[href],h2 a[href],h3 a[href],h4 a[href]');
for(var i=0;i<hs.length;i++){if(hs[i].innerText.trim().length>3&&hs[i].href.indexOf('http')==0)A.push(hs[i])}
if(A.length<3){
 for(var pass=0;pass<2&&A.length<3;pass++){A=[];var all=document.querySelectorAll('a[href]'),sig={},c=[];
  for(var i=0;i<all.length;i++){var a=all[i],u;try{u=new URL(a.href)}catch(e){continue}
   if(u.origin!==location.origin)continue;var seg=u.pathname.split('/').filter(Boolean);
   if(seg.length<1)continue;if(pass==0?!/[0-9]{3,}/.test(u.pathname):seg.length<2)continue;
   if(a.innerText.trim().length<4)continue;sig[seg[0]]=(sig[seg[0]]||0)+1;c.push([seg[0],a])}
  var best='',bn=0;for(var k in sig){if(sig[k]>bn){bn=sig[k];best=k}}
  for(var i=0;i<c.length;i++){if(c[i][0]===best)A.push(c[i][1])}}}
var JSX=HN.indexOf('jobsearch')>=0,ONST=location.pathname.indexOf('internship')>=0||$onst,STJ=/staj|intern|təcrübə proq|təcrübəçi|stajyor/,ANYI=false,STJX=/(^|[^a-zəıöüçşğ])(staj|stajçı|stajyor|intern|internship|təcrübəçi)([^a-zəıöüçşğ]|$)|təcrübə proqram/;
if(JSX&&ONST){for(var q=0;q<A.length;q++){if(/internship/.test(A[q].pathname)){ANYI=true;break}}}
var seen={},t=0,y=0,w=0,n=0;
function dh(el){var d={},m=0;for(var i=0;i<A.length;i++){if(el.contains(A[i])&&!d[A[i].href]){d[A[i].href]=1;m++}}return m}
for(var i=0;i<A.length;i++){var h=A[i].href;if(seen[h])continue;seen[h]=1;
 var el=A[i],card=A[i];
 for(var k=0;k<8&&el.parentElement&&el.parentElement!==document.body;k++){el=el.parentElement;if(dh(el)>1)break;card=el}
 if(JSX){var isInt=/internship/.test(A[i].pathname.toLowerCase()),ctx=((card.innerText||'')+' '+A[i].pathname).toLowerCase().replace(/\u0307/g,''),stj=isInt||STJX.test(ctx);if(ONST?!stj:stj)continue}
 n++;
 var ct=(card.innerText||'')+' '+dattr(card),pnd=false;
var r=icCls(card,ct);
if(r==0&&!ICF&&!IQ&&!GL){var xr=extraCls(card,ct);if(xr>0)r=xr}
if(r==0&&!ICF&&!WK&&!DATEISH.test(ct.toLowerCase())){
 if(GL||IQ||JB||AZ||JU||JO){UN++}
 else{var rr=detRes(h,A[i],card,ct);if(rr===-2)pnd=true;else if(rr!==null){r=rr;if(r>0)RZ[r-1]++}}}
if(!pnd)RS.push(r);
if(r>0){if(r==1)t++;else if(r==2)y++;else w++;var tt=titleOf(A[i],card);S.push({n:tt,h:h,d:(r==1?0:(r==2?1:2)),k:kindOf(tt)})}}
return [t,y,n,w]}
/* Aşağı sürüşdürən saytlar (Glorri qaydası): 0 = elan azdır, 1 = daha yükləmək lazımdır, 2 = köhnə elanlara çatdıq */
function scrollState(){var n=RS.length;if(n<3)return 0;
if(BS){/* Boss.az: köhnə elana çatmaq kifayət deyil - səhifənin TAM sonuna qədər: hündürlük və link sayı bir neçə oxuma ardıcıl dəyişməyibsə son */
 var se0=document.scrollingElement||document.documentElement,sig=se0.scrollHeight+'|'+postCount(),W0=window;
 if(W0.__bsSig===sig){W0.__bsSame=(W0.__bsSame||0)+1}else{W0.__bsSig=sig;W0.__bsSame=0}
 var tl=0;for(var q=n-1;q>=0&&RS[q]==0;q--)tl++;
 /* bu gün/dünən/2 gün əvvəlki elanlar bitdi: ardıcıl 15 köhnə elan görünübsə (və ya səhifənin sonuna çatılıbsa) dayan */
 if(tl>=20)return 2;
 return W0.__bsSame>=40?2:1}
var tail=0;for(var i=n-1;i>=0&&RS[i]==0;i--)tail++;return tail>=(IQ?10:8)?2:1}
function moreLoad(){try{if(IQ){var ja=document.querySelectorAll('a[href*="/job/"]');if(ja.length)ja[ja.length-1].scrollIntoView({block:'end'});
 var ye=document.querySelectorAll('div,span,p,button'),ys=null;for(var k=0;k<ye.length&&k<4000;k++){var e3=ye[k];if(e3.children.length>1)continue;var t3=fold(e3.textContent||'');if(t3.length<25&&t3.indexOf('yuklen')==0){ys=e3}}
 if(ys){ys.scrollIntoView({block:'center'});try{ys.click()}catch(e){}}}
 /* "Daha çox yüklə / göstər" düyməsi: ən daxili uyğun element tapılır, ən yaxın real düyməyə (button / a / role=button) toxunulur (kənar qutuya toxunmaq React düyməsini işə salmır) */
 var bs=document.querySelectorAll('button,[role=button],a,span,div,li,p'),cand=[],MRE=/^(daha cox( goster| yukle)?|load more|show more|more|diger elanlar)${'$'}/;
 for(var k=0;k<bs.length&&k<5000;k++){var e=bs[k];if(e.children.length>2)continue;var tx=fold(e.textContent||'');
  if(tx.length>=30||!MRE.test(tx))continue;
  if(e.tagName=='A'){var hr=e.getAttribute('href')||'';if(hr&&hr!='#'&&hr.indexOf('javascript')!=0)continue}
  if(e.disabled)continue;var rc=e.getBoundingClientRect();if(rc.width==0&&rc.height==0)continue;
  cand.push(e)}
 if(cand.length){var cur=cand[0];for(var q=1;q<cand.length;q++){if(cur.contains(cand[q]))cur=cand[q]}
  var tg=cur;try{tg=cur.closest('button,[role=button],a')||cur}catch(e){}
  try{if(tg.disabled||tg.getAttribute('aria-disabled')=='true'){tg=null}}catch(e){}
  if(tg){try{tg.scrollIntoView({block:'center'})}catch(e){}
   try{tg.click()}catch(e){}
   }}
 var se=document.scrollingElement||document.documentElement;window.scrollTo(0,se.scrollHeight);if(BS){try{var ft=document.querySelector('footer');if(ft)ft.scrollIntoView({block:'end'});document.body.dispatchEvent(new WheelEvent('wheel',{deltaY:600,bubbles:true}))}catch(e){}}
 var al=document.querySelectorAll('div,main,section,ul');
 for(var k=0;k<al.length&&k<500;k++){var e2=al[k];if(e2.clientHeight>100&&e2.scrollHeight>e2.clientHeight+80){var oy=getComputedStyle(e2).overflowY;if(oy=='auto'||oy=='scroll')e2.scrollTop=e2.scrollHeight}}
 window.dispatchEvent(new Event('scroll'))}catch(e){}}
/* Jobu.az: "N Nəticədən 1 – 24 aralığı göstərilir" yazısından AŞAĞIdakı kartlar oxunur (tarix sətrindən kart tapılır) */
function jobuScan(){
 var RS0=RS;RS=[];
 var mk=null,all=document.querySelectorAll('*'),best=1e9;
 for(var i=0;i<all.length;i++){var e=all[i];if(e.children.length>6)continue;var tc=(e.textContent||'');if(tc.length>120)continue;var f=fold(tc);
  if(f.indexOf('neticeden')>=0&&f.indexOf('araligi')>=0&&tc.length<best){best=tc.length;mk=e}}
 if(JO)mk=null;
 if(!mk&&!JO){RS=RS0;return null}
 var tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null,false),nd,dl=[],lastEl=null;
 while((nd=tw.nextNode())){
  var pe=nd.parentElement;if(!pe||(mk&&(mk.contains(pe)||!(mk.compareDocumentPosition(pe)&4))))continue;
  var tx=(nd.nodeValue||'').replace(/\s+/g,' ').trim();
  if(tx.length<4||tx.length>40)continue;
  var lw=tx.toLowerCase();
  if(cls(lw)>0||DATEISH.test(lw)){if(pe!==lastEl){dl.push({e:pe,t:tx});lastEl=pe}}}
 var t=0,y=0,w=0,n=0,hits=[],seen={};
 for(var i=0;i<dl.length;i++){
  var card=dl[i].e;
  for(var k=0;k<10&&card.parentElement&&card.parentElement!==document.body;k++){
   var p=card.parentElement,multi=false;
   for(var j=0;j<dl.length;j++){if(j!=i&&p.contains(dl[j].e)){multi=true;break}}
   if(multi||((p.innerText||'').length>700))break;
   card=p}
  var lines=lns(card),title='',hh=null;
  try{hh=card.querySelector('h1,h2,h3,h4,h5,h6')}catch(e){}
  if(hh&&(hh.innerText||'').trim().length>2)title=hh.innerText.trim().split('\n')[0].trim();
  if(!title){for(var q=0;q<lines.length;q++){var z=lines[q];if(z.length<3||isSal(z)||DATEISH.test(z.toLowerCase())||/^(vip|premium|yeni|new|pro|top)$/i.test(z))continue;title=z;break}}
  title=title.replace(/^\s*\d{1,3}\s*[.)]\s+/,'');
  if(!title)continue;
  if(JO&&/jooble|is elanlari ve vakansiyalar/.test(fold(title)))continue;
  var a=null,ft=fold(title),as=card.querySelectorAll('a[href]');
  for(var j=0;j<as.length;j++){if(as[j].href.indexOf('http')!=0)continue;if(fold(as[j].innerText||'').indexOf(ft)>=0){a=as[j];break}}
  if(!a){for(var j=0;j<as.length;j++){if(as[j].href.indexOf(location.origin)==0){a=as[j];break}}}
  if(!a&&card.closest){a=card.closest('a[href]')}
  var h=a?a.href.split('#')[0]:'';
  if(!h)h=location.href.split('#')[0]+'#j'+(i+1);
  var key=(JO&&h.indexOf('#j')<0)?h:(h+'|'+fold(title));if(seen[key])continue;seen[key]=1;n++;
  if(L.indexOf(h)<0)L.push(h);
  var r=cls(dl[i].t.toLowerCase());RS.push(r);
  if(r>0){if(r==1)t++;else if(r==2)y++;else w++;hits.push({n:title.substring(0,140),h:h,d:(r==1?0:(r==2?1:2)),k:kindOf(title)})}}
 if(n<3){RS=RS0;return null}
 return {r:[t,y,n,w],h:hits}}
/* İşəqəbul: kartlar /job/kateqoriya/elan/ linkləridir; \"N gün qalıb\" yazısı elanın yaşını göstərir (30 = bu gün, 29 = dünən, 28 = 2 gün əvvəl) */
function iqScan(){RS=[];
 var as=document.querySelectorAll('a[href]'),seen={},t=0,y=0,w=0,n=0;
 for(var i=0;i<as.length;i++){var u;try{u=new URL(as[i].href)}catch(e){continue}
  if(u.origin!==location.origin||!/^\/job\/[^\/]+\/[^\/]+\/?${'$'}/.test(u.pathname))continue;
  var h=u.origin+u.pathname;if(seen[h])continue;
  var card=as[i].closest('tr')||as[i].closest('article,li');
  if(!card){card=as[i];for(var k=0;k<6&&card.parentElement&&card.parentElement!==document.body;k++){card=card.parentElement;if(/gün qal[ıi][rb]/i.test(card.innerText||''))break}}
  var tx=(card.innerText||'').replace(/\u0307/g,'');
  if(!/gün qal[ıi][rb]/i.test(tx))continue;
  seen[h]=1;n++;
  var r=cls(tx.toLowerCase().replace(/\s+/g,' '));RS.push(r);
  if(L.indexOf(h)<0)L.push(h);
  if(r>0){var title='',BG=/^(vip|yen[iİIı]|new|ətraflı)${'$'}/i,hh=null;
   try{hh=card.querySelector('h1,h2,h3,h4,h5,h6')}catch(e){}
   if(hh&&(hh.innerText||'').trim().length>3)title=hh.innerText.replace(/\s+/g,' ').trim();
   if(!title){var ls=tx.split(/[\n\t]|\s{2,}/);
    for(var q=0;q<ls.length;q++){var z=ls[q].replace(/\s+/g,' ').trim();if(z.length<4||BG.test(z)||/gün qal[ıi][rb]/i.test(z)||/₼|azn/i.test(z))continue;title=z;break}}
   title=title.replace(/^(vip|yen[iİIı]|new) /i,'');
   if(!title)title=(as[i].innerText||'').trim()||h;
   if(r==1)t++;else if(r==2)y++;else w++;
   S.push({n:title.substring(0,140),h:h,d:(r==1?0:(r==2?1:2)),k:kindOf(title)})}}
 return n>=3?[t,y,n,w]:null}
/* Elan linki kimi görünən link (adi menyu linklərini sayma): yolda 3+ rəqəm və ya 2+ hissə, səhifənin özü deyil */
function postLike(a){var u;try{u=new URL(a.href)}catch(e){return false}
 if(u.origin!==location.origin||u.pathname.length<2||u.pathname===location.pathname)return false;
 if((a.innerText||'').trim().length<4)return false;
 return /[0-9]{3,}/.test(u.pathname)||u.pathname.split('/').filter(Boolean).length>=2}
function postCount(){var as=document.querySelectorAll('a[href]'),sg={},n=0;for(var i=0;i<as.length;i++){if(postLike(as[i])){var h=as[i].href.split('#')[0];if(!sg[h]){sg[h]=1;n++}}}return n}
/* Tarix yazan mətn qovşağından elan kartını və linkini tapır: tarixi olub kartı/linki olmayan yazılar (məs. "bu gün: 2 yeni elan" başlığı) sayılmır */
function lineMap(){var out=[],seen={},tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null,false),nd;
 while((nd=tw.nextNode())){var tx=(nd.nodeValue||'').replace(/\s+/g,' ').trim();if(tx.length<3||tx.length>60)continue;
  var r=cls(tx.toLowerCase());if(r<=0)continue;
  var el=nd.parentElement,a=null,card=null;
  for(var k=0;k<8&&el&&el!==document.body;k++){
   var as=el.querySelectorAll('a[href]'),hs={},nh=0,first=null;
   for(var j=0;j<as.length;j++){if(!postLike(as[j]))continue;var hh=as[j].href.split('#')[0];if(!hs[hh]){hs[hh]=1;nh++;if(!first)first=as[j]}}
   if(nh>=1){if(nh==1&&(el.innerText||'').length<=700){a=first;card=el}break}
   el=el.parentElement}
  if(!a)continue;
  var h=a.href.split('#')[0];if(seen[h])continue;seen[h]=1;
  var tt=titleOf(a,card);if(!tt||tt.length<3)continue;
  out.push({n:tt,h:h,r:r,k:kindOf(tt)})}
 return out}
/* Jobing.az: hər elan kartında "### Başlıq" (h3), şirkət, "14 saat əvvəl" kimi yazı var; siyahı uzundur (aşağı sürüşdürüldükcə yüklənir) */
function jobingScan(){RS=[];
 var hs=document.querySelectorAll('h2,h3,h4'),t=0,y=0,w=0,n=0,seenK={};
 for(var i=0;i<hs.length;i++){var h3=hs[i],ttl=(h3.innerText||'').replace(/\s+/g,' ').trim();
  if(ttl.length<3||ttl.length>200)continue;
  var card=h3,el=h3;
  for(var k=0;k<8&&el.parentElement&&el.parentElement!==document.body;k++){el=el.parentElement;if(el.querySelectorAll(h3.tagName).length>1)break;card=el}
  if(card===h3)continue;
  var tx=(card.innerText||'').replace(/\s+/g,' ').trim();
  if(tx.length>1600)continue;
  var ft=fold(ttl),a=null;
  try{a=h3.closest('a[href]')}catch(e){}
  if(!a){var as=card.querySelectorAll('a[href]');
   for(var j=0;j<as.length;j++){if(as[j].href.indexOf('http')==0&&fold(as[j].innerText||'').indexOf(ft)>=0){a=as[j];break}}
   if(!a){for(var j=0;j<as.length;j++){if(as[j].href.indexOf('http')==0&&as[j].href.indexOf(location.origin)==0){a=as[j];break}}}}
  if(!a&&card.closest){try{a=card.closest('a[href]')}catch(e){}}
  if(h3.tagName!='H3'&&!a)continue;
  var href=a?a.href.split('#')[0]:'';
  n++;
  if(!href||href.indexOf('http')!=0)href=location.href.split('#')[0]+'#jb'+n;
  /* eyni kart iki dəfə oxunmasın (eyni link + eyni mətn); eyni adlı fərqli elanlar ayrıca qalır */
  var kk=href+'|'+tx;if(seenK[kk]){n--;continue}seenK[kk]=1;
  if(L.indexOf(href)<0)L.push(href);
  var r=icCls(card,(tx+' '+dattr(card)).toLowerCase());if(r==0&&!ICF){var xr=extraCls(card,tx);if(xr>0)r=xr}RS.push(r);
  if(r>0){if(r==1)t++;else if(r==2)y++;else w++;
   S.push({n:ttl.substring(0,140),h:href,d:(r==1?0:(r==2?1:2)),k:kindOf(ttl)})}}
 /* ehtiyat yoxlama: başlıq teqindən və kart quruluşundan asılı olmayaraq, linkinin ilk sətri açar sözə uyğun gələn elanları tap */
 try{var xa=document.querySelectorAll('a[href]');
  for(var q=0;q<xa.length;q++){var an2=xa[q],ah=an2.href.split('#')[0];
   if(ah.indexOf(location.origin)!=0||ah==location.href.split('#')[0])continue;
   var at=((an2.innerText||'').split('\n')[0]||'').replace(/\s+/g,' ').trim().replace(/^\d{1,3}\s*[.)]\s+/,'');
   if(at.length<3||at.length>140)continue;
   var kd=kindOf(at);if(!kd)continue;
   var dupF=false,fa=fold(at);
   for(var z=0;z<S.length;z++){if((fold(S[z].n.replace(/^\s*\d{1,3}\s*[.)]\s+/,''))==fa&&(S[z].h==ah||S[z].h.indexOf('#jb')>=0))||(JO&&S[z].h==ah)){dupF=true;break}}
   if(dupF)continue;
   var el2=an2,rr=0;
   for(var k=0;k<7&&el2;k++){var tx2=(el2.innerText||'').replace(/\s+/g,' ').trim();
    if(tx2.length>1600)break;
    rr=cls((tx2+' '+dattr(el2)).toLowerCase());if(rr>0)break;
    el2=el2.parentElement}
   if(rr>0){if(rr==1)t++;else if(rr==2)y++;else w++;n++;RS.push(rr);
    if(L.indexOf(ah)<0)L.push(ah);
    S.push({n:at,h:ah,d:(rr==1?0:(rr==2?1:2)),k:kd})}}}catch(e){}
 return n>=3?[t,y,n,w]:null}
/* AzJob.az: hər kart "### Başlıq" (h3 + link), şirkət və "07.10.2026  Bakı" yazır. Tarix DD.MM.YYYY kimi DƏQİQ oxunur (bu gün/dünən/2 gün əvvəl, qalanı köhnə) */
function azScan(){RS=[];
 var hs=document.querySelectorAll('h3'),t=0,y=0,w=0,n=0,seen={},DR=/(^|[^0-9])([0-9]{1,2})\.([0-9]{1,2})\.([0-9]{4})(?![0-9])/;
 for(var i=0;i<hs.length;i++){var a=hs[i].querySelector('a[href]');if(!a)continue;var h=a.href.split('#')[0].split('?')[0];if(h.indexOf('.html')<0)continue;var mid=h.match(/-([0-9]+)\.html/),sk=mid?mid[1]:h;if(seen[sk])continue;
  var card=hs[i],el=hs[i];
  for(var k=0;k<6&&el.parentElement&&el.parentElement!==document.body;k++){el=el.parentElement;if(el.querySelectorAll('h3').length>1)break;card=el}
  var m=(card.innerText||'').match(DR);if(!m)continue;
  seen[sk]=1;n++;if(L.indexOf(h)<0)L.push(h);
  var ag=ageYMD(parseInt(m[4]),parseInt(m[3]),parseInt(m[2])),r=ag==0?1:(ag==1?2:(ag==2?3:0));
  RS.push(r);
  if(r>0){if(r==1)t++;else if(r==2)y++;else w++;var tt=(hs[i].innerText||'').replace(/\s+/g,' ').trim();S.push({n:tt.substring(0,140),h:h,d:(r==1?0:(r==2?1:2)),k:kindOf(tt)})}}
 return n>=3?[t,y,n,w]:null}
/* ===== Yeni: vezife.az "yeni" nişanı, work.az kartları, tarixsiz elanların səbəbi və elan səhifəsindən tarix oxuma ===== */
var MP={yan:1,fev:2,mar:3,apr:4,may:5,iyn:6,iyl:7,avq:8,sen:9,okt:10,noy:11,dek:12};
function monNum(s){var mo0=monOf(s);if(mo0)return mo0;s=fold(s);if(s.indexOf('iyun')==0)return 6;if(s.indexOf('iyul')==0)return 7;return MP[s.substring(0,3)]||0}
function ageFromParts(d,mo,y){var a;if(y){a=ageYMD(y,mo,d)}else{a=ageYMD(now.getFullYear(),mo,d);if(a<-5)a=ageYMD(now.getFullYear()-1,mo,d)}return a}
function r3(age){return age==0?1:(age==1?2:(age==2?3:0))}
function badgeNew(card){try{var q=card.querySelectorAll('*');for(var i=0;i<q.length;i++){var e=q[i];if(e.children.length==0&&/^(yeni|yeni!|new|new!|yeni elan)${'$'}/.test(fold(e.textContent||'')))return true}}catch(e){}
 var tx=fold((card.innerText||'').replace(/\s+/g,' '));return / yeni${'$'}/.test(tx)}
function wkTitleSafe(a,card){var h=null;try{h=card.querySelector('h1,h2,h3,h4,h5,h6')}catch(e){}
 if(h&&(h.innerText||'').trim().length>2)return h.innerText.replace(/\s+/g,' ').trim();
 var L=lns(card);for(var i=0;i<L.length;i++){if(L[i].length>2)return L[i]}return titleOf(a,card)}
function uwAdd(k,a,card){var o=UW[k]||(UW[k]={n:0,e:[]});o.n++;if(o.e.length<2){var tt='';try{tt=wkTitleSafe(a,card)}catch(e){}if(tt)o.e.push(tt.substring(0,38))}}
function uwList(){var o=[],k;for(k in UW){o.push({k:k,n:UW[k].n,e:UW[k].e})}o.sort(function(x,y){return y.n-x.n});var r=[];
 for(var i=0;i<o.length&&i<4;i++){r.push(o[i].n+' elan: '+o[i].k+(o[i].e.length?' (məs. '+o[i].e.join(' · ')+')':''))}return r}
function undWhy(ct){var low=ct.toLowerCase();
 if(/son tarix|son müraciət|son gün|deadline|bitmə|bitir|bitər|qədər|expires|valid until/.test(low))return 'siyahıda yalnız son müraciət (bitmə) tarixi var, yerləşdirmə tarixi yoxdur';
 if(/[0-9]{1,2}[.\/-][0-9]{1,2}|yanvar|fevral|mart|aprel|iyun|iyul|avqust|sentyabr|oktyabr|noyabr|dekabr/.test(low))return 'tarix yazısı var, amma formatı tanınmadı';
 return 'sayt siyahıda elanın tarixini göstərmir'}
/* elanın öz səhifəsindən yerləşdirmə tarixini oxuyur: JSON-LD / meta / "Yerləşdirilib ..." mətni */
function pdate(html){var m,x=html,a;
 m=x.match(/"(?:datePosted|datePublished|dateCreated|date_posted|createdAt|created_at|publishedAt|published_at|postedAt|publishDate|publish_date)"\s*:\s*"([0-9]{4})-([0-9]{2})-([0-9]{2})/);
 if(m){a=ageYMD(+m[1],+m[2],+m[3]);if(a>=0)return a}
 m=x.match(/(?:published_time|datePublished|article:published)["'][^>]*?content=["']([0-9]{4})-([0-9]{2})-([0-9]{2})/i);
 if(m){a=ageYMD(+m[1],+m[2],+m[3]);if(a>=0)return a}
 var tx=x.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi,' ').replace(/<[^>]*>/g,' ');tx=fold(tx.replace(/&nbsp;/g,' '));
 m=tx.match(/(?:yerlesdirilib|yerlesdirilme tarixi|elan tarixi|derc olunub|derc tarixi|elave olunub|yayimlanib|paylasilib|posted|published|added|created)[: ]*([0-9]{1,2})[.\/-]([0-9]{1,2})[.\/-]([0-9]{4})/);
 if(m){a=ageYMD(+m[3],+m[2],+m[1]);if(a>=0)return a}
 m=tx.match(/(?:yerlesdirilib|yerlesdirilme tarixi|elan tarixi|derc olunub|derc tarixi|elave olunub|yayimlanib|paylasilib|posted|published|added|created)[: ]*([0-9]{1,2}) ([a-z]{3,9})\.? ?([0-9]{4})?/);
 if(m&&monNum(m[2])){a=ageFromParts(+m[1],monNum(m[2]),m[3]?+m[3]:0);if(a>=0)return a}
 m=tx.match(/(?:yerlesdirilib|derc olunub|elave olunub|yayimlanib|paylasilib|posted|published|added|created)[: ]*(bu gun|bugun|dunen|([0-9]+) (gun|saat|deq)[a-z]* evvel)/);
 if(m){if(m[1]=='dunen')return 1;if(m[2])return m[3]=='gun'?+m[2]:0;return 0}
 return null}
var Q=(window.__vkQ=window.__vkQ||{a:[],run:0,tot:0});
function pump(){while(Q.run<5&&Q.a.length){var h=Q.a.shift();Q.run++;getDet(h)}}
function getDet(h){var c=new AbortController(),tm=setTimeout(function(){c.abort()},9000),fin=function(){Q.run--;pump()};
 fetch(h,{credentials:'omit',signal:c.signal}).then(function(r){clearTimeout(tm);if(!r.ok)throw 1;return r.text()}).then(function(html){
  var age=pdate(html);
  if(age===null)DET[h]={s:2,why:'elanın öz səhifəsi açıldı, orada da tarix tapılmadı'};else DET[h]={s:1,r:r3(age),age:age};fin()},
  function(){DET[h]={s:2,why:'elanın öz səhifəsi açılmadı (xəta və ya vaxt aşımı)'};fin()})}
function sameOrg(h){try{return new URL(h,location.href).origin===location.origin}catch(e){return false}}
/* qaytarır: 0..3 (tarix elan səhifəsindən tapıldı), -2 (hələ oxunur), null (tarix tapılmadı: UN və səbəb yazılır) */
function detRes(h,a,card,ct){var why=undWhy(ct);
 if(!RESOLVE){UN++;uwAdd(why,a,card);return null}
 var d=DET[h];
 if(!d){if(!sameOrg(h)||h.split('#')[0]==location.href.split('#')[0])DET[h]={s:2,why:'elan başqa saytdadır, səhifəsi brauzer qaydasına görə oxuna bilmir'};
  else if(Q.tot>=60)DET[h]={s:2,why:'elan səhifəsindən oxuma limiti (60) dolub'};
  else{Q.tot++;DET[h]={s:0};Q.a.push(h);pump()}
  d=DET[h]}
 if(d.s==1)return d.r;
 UN++;
 if(d.s==0){PEND++;uwAdd('tarix elanın öz səhifəsindən oxunur…',a,card);return -2}
 uwAdd(why+'; '+d.why,a,card);return null}
/* Work.az: kart = /vakansiyalar/<ad> linki; tarix ayrıca yazıdır: "Bu gün", "Dünən", "10 okt". Premium kartlar yuxarıda sancılır (köhnə tarixli ola bilər) */
function wkQual(a){var u;try{u=new URL(a.href)}catch(e){return ''}if(u.origin!==location.origin)return '';var s=u.pathname.split('/').filter(Boolean);return (s.length==2&&s[0]=='vakansiyalar')?u.origin+u.pathname:''}
function wkScan(){RS=[];UW={};
 var as=document.querySelectorAll('a[href]'),seen={},t=0,y=0,w=0,n=0,DT=/^([0-9]{1,2}) ([a-z]{3,9})\.?( [0-9]{4})?${'$'}/;var DT2=/^([a-z]{3,9})\.? ([0-9]{1,2})(,? [0-9]{4})?${'$'}/;
 for(var i=0;i<as.length;i++){var h=wkQual(as[i]);if(!h||seen[h])continue;
  var card=as[i];
  for(var k=0;k<8&&card.parentElement&&card.parentElement!==document.body;k++){var p=card.parentElement,other=false,ps=p.querySelectorAll('a[href]');
   for(var j=0;j<ps.length;j++){var hh=wkQual(ps[j]);if(hh&&hh!==h){other=true;break}}
   if(other)break;card=p}
  seen[h]=1;n++;
  var age=-1,prem=false,lv=card.querySelectorAll('*');
  for(var j=0;j<lv.length;j++){var e=lv[j];if(e.children.length)continue;var z=fold(e.textContent||'');if(z.length<3||z.length>14)continue;
   if(z=='premium'){prem=true;continue}
   if(age<0){if(z=='bu gun')age=0;else if(z=='dunen')age=1;else{var m=z.match(DT),m2=z.match(DT2),ag=-1;if(m&&monNum(m[2]))ag=ageFromParts(parseInt(m[1]),monNum(m[2]),m[3]?parseInt(m[3]):0);else if(m2&&monNum(m2[1]))ag=ageFromParts(parseInt(m2[2]),monNum(m2[1]),m2[3]?parseInt(m2[3].replace(/[^0-9]/g,'')):0);if(ag>=0)age=ag}}}
  var r=0,pend=false,und=false,ct=(card.innerText||'');
  if(age>=0)r=r3(age);
  else{var rc=icCls(card,ct);if(rc==0&&!ICF){var xr0=extraCls(card,ct);if(xr0>0)rc=xr0}
   if(rc>0)r=rc;
   else if(!ICF&&!DATEISH.test(ct.toLowerCase())){und=true;var rr=detRes(h,as[i],card,ct);if(rr===-2)pend=true;else if(rr!==null){r=rr;und=false}}}
  if(!pend&&!und&&!(prem&&r==0))RS.push(r);
  if(L.indexOf(h)<0)L.push(h);
  if(r>0){var tt=wkTitleSafe(as[i],card);if(r==1)t++;else if(r==2)y++;else w++;S.push({n:tt.substring(0,140),h:h,d:(r==1?0:(r==2?1:2)),k:kindOf(tt)})}}
 return n>=3?[t,y,n,w]:null}
var JB=HN.indexOf("jobing.az")>=0,AZ=HN.indexOf("azjob.az")>=0;
var res=null,cc=cardCount(),w=0;
if(GL){S.length=0;res=glorriScan();if(!res)S.length=0}
else if(IQ){S.length=0;res=iqScan();if(!res)S.length=0}
else if(JB){S.length=0;res=jobingScan();if(!res)S.length=0}
else if(AZ){S.length=0;res=azScan();if(!res)S.length=0}
else if(WK){S.length=0;res=wkScan();if(!res)S.length=0}
else if(VZ&&cc[2]>=3){res=cc}
else if(JU||JO){try{var jr=jobuScan();if(jr){S.length=0;for(var ji=0;ji<jr.h.length;ji++)S.push(jr.h[ji]);res=jr.r}}catch(e){}}
if(!res&&careful){res=cc;if(!(HN.indexOf('jobsearch')>=0&&(location.pathname.indexOf('internship')>=0||$onst))&&(res[2]<3||res[0]+res[1]+res[3]==0)){S.length=0;res=jsonCount();if(!res)S.length=0}}
if(res){w=res[3]}else{res=lineCount();res[0]+=RZ[0];res[1]+=RZ[1];res[2]+=RZ[2];w=res[2];
 if(S.length==0&&(res[0]>0||res[1]>0||res[2]>0)){var lm=[];try{lm=lineMap()}catch(e){}
  if(lm.length>0){var t2=0,y2=0,w2=0;S.length=0;
   for(var li=0;li<lm.length;li++){var q=lm[li];if(L.indexOf(q.h)<0)L.push(q.h);if(q.r==1)t2++;else if(q.r==2)y2++;else w2++;S.push({n:q.n.substring(0,140),h:q.h,d:(q.r==1?0:(q.r==2?1:2)),k:q.k})}
   res=[t2,y2,w2];w=w2}
  else if(postCount()>=3){res=[0,0,0];w=0}}}
if(SCR&&!GL){GLS=scrollState();if(GLS==1)moreLoad()}
return JSON.stringify({t:res[0],y:res[1],w:w,l:L,s:S,g:GLS,n:Math.max(RS.length,L.length),u:UN,q:PEND,uw:uwList()});})()"""
    }

    /**
     * JobSite.az: siyahıda yerləşdirmə tarixi yoxdur (yalnız "Son Tarix" - bitmə tarixi görünür).
     * Ona görə ən yeni elanların öz səhifələri açılır və "Yerləşdirilib ..." tarixi oxunur.
     */
    fun detailJs(ctx: Context, url: String): String {
        fun arr(c: Calendar) = "[${c.get(Calendar.DAY_OF_MONTH)},${c.get(Calendar.MONTH) + 1},${c.get(Calendar.YEAR)}]"
        val c1 = Calendar.getInstance()
        val c2 = Calendar.getInstance(); c2.add(Calendar.DAY_OF_MONTH, -1)
        val c3 = Calendar.getInstance(); c3.add(Calendar.DAY_OF_MONTH, -2)
        val staj = Store.stajFilter(url)
        return """(function(){
var L=JSON.parse(${Links.js(false)});
var T=${arr(c1)},Y=${arr(c2)},W=${arr(c3)};
var F=$staj;
${Keywords.js(ctx)}
var t0=Date.now(),DEADLINE=40000;
var MON=['yanvar','fevral','mart','aprel','may','iyun','iyul','avqust','sentyabr','oktyabr','noyabr','dekabr'];
function eq(d,m,y,Z){return d==Z[0]&&m==Z[1]&&y==Z[2]}
function norm(z){return z.replace(/\s+/g,' ').toLowerCase().replace(/\u0307/g,'').trim()}
var W='[^a-zəıöüçşğ]';
var TITLE=new RegExp('(^|'+W+')(staj|stajçı|stajyor|intern|internship)('+W+'|${'$'})|təcrübəçi|təcrübə proqram|təcrübə keçmə');
var HEAD=new RegExp('(^|'+W+')(stajçı|stajyor|internship)('+W+'|${'$'})|təcrübəçi|təcrübə proqram');
var DRE=/yerləşdirilib ([0-9]{1,2}) ([a-zəıöüçşğ]+) ([0-9]{4})/;
function idOf(u){var m=u.match(/-([0-9]+)${'$'}/);return m?parseInt(m[1]):0}
function abs(a){try{return new URL(a.getAttribute('href'),location.href).href.split('#')[0]}catch(e){return ''}}
function jobLinks(root){var out=[],a=root.querySelectorAll('a[href]');
 for(var i=0;i<a.length;i++){var h=abs(a[i]);if(h.indexOf('/vakansiya-is-elani/')<0||!/-[0-9]+${'$'}/.test(h))continue;out.push(h)}return out}
function pn(h){var m=h.match(/(?:[?&](?:page|p)=|\/page\/)([0-9]+)/);return m?parseInt(m[1]):0}
function pageLinks(root){var r=[],a=root.querySelectorAll('a[href]');
 for(var i=0;i<a.length;i++){var h=abs(a[i]);if(!h||h.indexOf(location.origin)!==0)continue;
  if(pn(h)>0&&r.indexOf(h)<0)r.push(h)}
 r.sort(function(x,y){return pn(x)-pn(y)});return r.slice(0,7)}
function get(h,n){return new Promise(function(res){var c=new AbortController(),tm=setTimeout(function(){c.abort()},10000);
 fetch(h,{credentials:'omit',signal:c.signal}).then(function(r){clearTimeout(tm);if(!r.ok)throw 0;return r.text()})
 .then(res,function(){clearTimeout(tm);if(n>0)res(get(h,n-1));else res(null)})})}
var all={},list=[];
function addLinks(a){a.forEach(function(h){if(!all[h]){all[h]=1;list.push(h)}})}
addLinks(jobLinks(document));
var keep=[],fetched=[],t=0,y=0,w=0,fails=[],fin=false;
function proc(h,html){
 fetched.push(h);
 var x=norm(html.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi,' ').replace(/<[^>]*>/g,' '));
 var hd=x.split(' təsvir ')[0];
 var m=hd.match(DRE)||x.match(DRE),isT=false,isY=false,isW=false;
 if(m){var dd=parseInt(m[1]),mo=MON.indexOf(m[2])+1,yr=parseInt(m[3]);isT=eq(dd,mo,yr,T);isY=!isT&&eq(dd,mo,yr,Y);isW=!isT&&!isY&&eq(dd,mo,yr,W)}
 if((isT||isY||isW)&&!F){var rt='';try{var d0=new DOMParser().parseFromString(html,'text/html');var e0=d0.querySelector('h1');rt=((e0&&e0.textContent)||d0.title||'').replace(/\s+/g,' ').trim()}catch(er){}S.push({n:rt,h:h,d:(isT?0:(isY?1:2)),k:kindOf(rt)})}
 if(F){var ttl='';try{var d=new DOMParser().parseFromString(html,'text/html');var e=d.querySelector('h1');ttl=norm((e&&e.textContent)||d.title||'')}catch(er){}
  var hw=hd.substring(Math.max(0,hd.length-450));
  if(!(TITLE.test(ttl)||HEAD.test(hw)))return isT||isY||isW}
 keep.push(h);
 if(isT)t++;else if(isY)y++;else if(isW)w++;
 return isT||isY||isW}
function send(){if(fin)return;fin=true;
 Bridge.done(JSON.stringify({t:t,y:y,w:w,l:F?keep:L.concat(list),s:S}))}
function retryFails(){
 if(!fails.length||Date.now()-t0>DEADLINE+8000)return send();
 var f=fails;fails=[];
 Promise.all(f.map(function(h){return get(h,2)})).then(function(arr){
  arr.forEach(function(html,k){if(html!==null)proc(f[k],html)});send()})}
function run(){
 list.sort(function(a,b){return idOf(b)-idOf(a)});list=list.slice(0,250);
 if(list.length==0)return;
 var i=0,quiet=0;
 function step(){
  if(i>=list.length||Date.now()-t0>DEADLINE||quiet>=2)return retryFails();
  var batch=list.slice(i,i+15);i+=15;
  Promise.all(batch.map(function(h){return get(h,2)})).then(function(arr){
   var hit=0;
   arr.forEach(function(html,k){if(html===null){fails.push(batch[k]);return}if(proc(batch[k],html))hit++});
   quiet=hit>0?0:quiet+1;step()})}
 step()}
var pls=pageLinks(document);
Promise.all(pls.map(function(h){return get(h,2).then(function(html){
 if(!html)return;try{addLinks(jobLinks(new DOMParser().parseFromString(html,'text/html')))}catch(e){}})})).then(run,run);
})()"""
    }


    /** Növbəti səhifənin ünvanını tapır (rel=next, ?page=N / ?paged=N / /page/N, və ya nömrə düyməsi); tapılmasa "Növbəti" düyməsini basır. */
    fun nextJs(): String = """(function(){var u=new URL(location.href),q=['page','paged','p','pg','pageNumber'],cur=1,i,m;
for(i=0;i<q.length;i++){var v=u.searchParams.get(q[i]);if(v&&/^[0-9]+${'$'}/.test(v)){cur=parseInt(v);break}}
m=u.pathname.match(/\/(?:page|sehife)\/([0-9]+)/i);if(m)cur=parseInt(m[1]);
var nx=cur+1,as=document.querySelectorAll('a[href]');
function pg(h){try{var x=new URL(h,location.href);if(x.origin!==u.origin)return 0;for(var j=0;j<q.length;j++){var w=x.searchParams.get(q[j]);if(w&&/^[0-9]+${'$'}/.test(w))return parseInt(w)}var mm=x.pathname.match(/\/(?:page|sehife)\/([0-9]+)/i);return mm?parseInt(mm[1]):0}catch(e){return 0}}
function ok(h){return h&&h.charAt(0)!='#'&&h.indexOf('javascript')!=0}
var rn=document.querySelector('a[rel=next][href]');
if(rn&&ok(rn.getAttribute('href')))return JSON.stringify({h:new URL(rn.getAttribute('href'),location.href).href.split('#')[0]});
for(i=0;i<as.length;i++){var h=as[i].getAttribute('href')||'';if(ok(h)&&pg(as[i].href)==nx)return JSON.stringify({h:as[i].href.split('#')[0]})}
for(i=0;i<as.length;i++){var h2=as[i].getAttribute('href')||'',tx=(as[i].innerText||'').replace(/\s+/g,' ').trim();if(ok(h2)&&tx==''+nx&&as[i].origin==u.origin)return JSON.stringify({h:as[i].href.split('#')[0]})}
var cs=document.querySelectorAll('a,button,li,span');
for(i=0;i<cs.length;i++){var e=cs[i];if(e.children.length>1)continue;var t=(e.innerText||'').replace(/\s+/g,' ').trim().toLowerCase();
 if(t==''+nx||/^(növbəti|novbeti|next|›|»|>|→)${'$'}/.test(t)){if(e.getAttribute('aria-disabled')=='true'||e.disabled||(e.className+'').indexOf('disabled')>=0)continue;try{e.click();return JSON.stringify({c:1})}catch(er){}}}
return '{}'})()"""

    /** Hansı skriptin işləyəcəyini seçir: Telegram kanalı və ya JobSite tipli (elanın öz səhifəsi). */
    fun detailScript(ctx: Context, url: String): String = if (Store.telegram(url)) tgJs(ctx) else detailJs(ctx, url)

    /**
     * Telegram kanalı (t.me/s/KANAL): hər paylaşımda 10 elan var, paylaşımın saatı məlum olur.
     * Elan ilk dəfə kanalda göründüyü gün "yerləşdirilib" sayılır (təkrar paylaşımlar köhnə günə yazılır).
     * Nəticə: ən yeni paylaşımdan köhnəyə doğru, saatla birlikdə sıralanır.
     */
    fun tgJs(ctx: Context): String = """(function(){
${Keywords.js(ctx)}
var t0=Date.now(),DEADLINE=170000,MAXP=60,posts={},fin=false;
var now=new Date(),b=new Date(now.getFullYear(),now.getMonth(),now.getDate());
function dd(ts){var d=new Date(ts),a=new Date(d.getFullYear(),d.getMonth(),d.getDate());return Math.round((b-a)/86400000)}
function p2(n){return n<10?'0'+n:''+n}
function parse(root){var ws=root.querySelectorAll('.tgme_widget_message'),minId=1e12;
 for(var i=0;i<ws.length;i++){var w=ws[i],dp=w.getAttribute('data-post')||'',id=parseInt(dp.split('/').pop()||'0');
  if(!id)continue;if(id<minId)minId=id;
  var te=w.querySelector('.tgme_widget_message_date time')||w.querySelector('time'),ts=te?Date.parse(te.getAttribute('datetime')):NaN,tx=w.querySelector('.tgme_widget_message_text');
  if(!tx||isNaN(ts))continue;
  var ads=[],last='',nodes=tx.childNodes;
  for(var j=0;j<nodes.length;j++){var nd=nodes[j];
   if(nd.nodeType==3){var v=(nd.nodeValue||'').replace(/\s+/g,' ').trim();if(v)last=v}
   else if(nd.nodeName=='A'){var h=nd.getAttribute('href')||'';if(h.indexOf('hrin.az/vakansiya/')>=0){ads.push({t:last,u:h.split('?')[0].split('#')[0]});last=''}}
   else if(nd.nodeName!='BR'){if(nd.querySelector&&nd.querySelector('a')){var aa=nd.querySelectorAll('a[href*="hrin.az/vakansiya/"]');for(var q=0;q<aa.length;q++){ads.push({t:last,u:aa[q].getAttribute('href').split('?')[0]});last=''}}
    else{var v3=(nd.textContent||'').replace(/\s+/g,' ').trim();if(v3)last=v3}}}
  posts[id]={id:id,ts:ts,ads:ads}}
 return minId}
function get(u){return new Promise(function(res){var c=new AbortController(),tm=setTimeout(function(){c.abort()},10000);
 fetch(u,{credentials:'omit',signal:c.signal}).then(function(r){clearTimeout(tm);if(!r.ok)throw 0;return r.text()}).then(res,function(){clearTimeout(tm);res(null)})})}
function build(){
 var ids=Object.keys(posts).map(Number).sort(function(a,b){return a-b});
 if(!ids.length)return null;
 var best={},order=[];
 /* paylaşımın tarixinə görə: bu gün / dünən / 2 gün əvvəl paylaşılan postlardakı BÜTÜN elanlar; təkrar elan ən yeni postunun gününə yazılır */
 ids.forEach(function(id){var p=posts[id],d=dd(p.ts);if(d<0||d>2)return;
  p.ads.forEach(function(a){
   var n=parseInt(a.u.replace(/\/+${'$'}/,'').split('-').pop())||0,k=n||a.u,f=best[k];
   var ttl=a.t;if(!ttl){ttl=a.u.split('/').pop().replace(/-[0-9]+${'$'}/,'').replace(/-/g,' ')}
   if(!f){best[k]={t:ttl,u:a.u,ts:p.ts,n:n,d:d};order.push(k)}
   else if(p.ts>f.ts){f.ts=p.ts;f.d=d;if(a.t)f.t=a.t}})});
 var res=[];
 order.forEach(function(k){var f=best[k];res.push({f:f,d:f.d})});
 res.sort(function(x,y){return y.f.ts-x.f.ts});
 var t=0,y=0,w=0,S=[],L=[];
 res.forEach(function(r){var f=r.f,dt=new Date(f.ts);
  if(r.d==0)t++;else if(r.d==1)y++;else w++;
  L.push(f.u);
  S.push({n:f.t.substring(0,140),h:f.u,d:r.d,k:kindOf(f.t)})});
 return JSON.stringify({t:t,y:y,w:w,l:L,s:S})}
function send(){if(fin)return;fin=true;var j=build();if(j)Bridge.done(j)}
function part(){try{if(!fin&&Bridge.part){var j=build();if(j)Bridge.part(j)}}catch(e){}}
function oldest(){var m=1e15;for(var k in posts){if(posts[k].ts<m)m=posts[k].ts}return m}
function more(minId,n,tr){tr=tr||0;
 if(n>=MAXP||Date.now()-t0>DEADLINE||oldest()<b.getTime()-4*86400000)return send();
 get(location.pathname+'?before='+minId).then(function(html){
  if(!html){if(tr<3)return more(minId,n,tr+1);return send()}
  var m=1e12;try{m=parse(new DOMParser().parseFromString(html,'text/html'))}catch(e){}
  if(!m||m>=minId)return send();part();more(m,n+1,0)})}
try{var m0=parse(document);if(m0>=1e12)return;part();more(m0,0)}catch(e){send()}
})()"""
}
