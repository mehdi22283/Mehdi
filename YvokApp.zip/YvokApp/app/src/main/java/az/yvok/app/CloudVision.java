package az.yvok.app;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/**
 * Google Cloud Vision (DOCUMENT_TEXT_DETECTION) ilə onlayn OCR (tətbiqdə yeganə OCR mühərriki).
 */
final class CloudVision {
    // Açar index.html-də "Toplu yoxlama" yanındakı xanadan daxil edilir, SharedPreferences-də saxlanır.
    static volatile String apiKey = "";

    private static final int MAX_SIDE = 3000;

    private CloudVision() { }

    static volatile String lastError = null;

    static boolean enabled() { return !apiKey.isEmpty(); }

    /** Şəkildəki bütün mətni qaytarır; xəta və ya internet yoxdursa null. Yalnız arxa thread-də çağırılır. */
    static String detect(Context c, Bitmap src) {
        lastError = null;
        if (!enabled()) { lastError = "Vision API açarı yoxdur"; return null; }
        try {
            Bitmap b = src;
            int mx = Math.max(b.getWidth(), b.getHeight());
            if (mx > MAX_SIDE) {
                float k = (float) MAX_SIDE / mx;
                b = Bitmap.createScaledBitmap(b, Math.round(b.getWidth() * k), Math.round(b.getHeight() * k), true);
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 92, bos);
            if (b != src) b.recycle();
            String img64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);

            JSONObject req = new JSONObject()
                    .put("image", new JSONObject().put("content", img64))
                    .put("features", new JSONArray().put(new JSONObject().put("type", "DOCUMENT_TEXT_DETECTION")))
                    .put("imageContext", new JSONObject().put("languageHints", new JSONArray().put("en").put("az")));
            byte[] body = new JSONObject().put("requests", new JSONArray().put(req)).toString().getBytes("UTF-8");

            HttpURLConnection h = (HttpURLConnection) new URL("https://vision.googleapis.com/v1/images:annotate?key=" + apiKey).openConnection();
            h.setRequestMethod("POST");
            h.setConnectTimeout(8000);
            h.setReadTimeout(20000);
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            h.setRequestProperty("X-Android-Package", c.getPackageName());
            String sha = certSha1(c);
            if (sha != null) h.setRequestProperty("X-Android-Cert", sha);
            try (OutputStream os = h.getOutputStream()) { os.write(body); }
            int code = h.getResponseCode();
            if (code != 200) {
                lastError = (code == 400 || code == 403) ? "Vision açarı qəbul olunmadı (" + code + "): açarı və API-nin aktiv olduğunu yoxlayın"
                        : "Vision xətası (" + code + ")";
                return null;
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = h.getInputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            JSONObject r = new JSONObject(out.toString("UTF-8")).getJSONArray("responses").getJSONObject(0);
            JSONObject full = r.optJSONObject("fullTextAnnotation");
            return full == null ? null : full.optString("text", null);
        } catch (java.io.IOException t) {
            lastError = "İnternet yoxdur və ya Google-a qoşulmaq olmadı";
            return null;
        } catch (Throwable t) {
            lastError = "Vision cavabı oxunmadı";
            return null;
        }
    }

    @SuppressWarnings("deprecation")
    private static String certSha1(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNATURES);
            byte[] d = MessageDigest.getInstance("SHA-1").digest(pi.signatures[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02X", x));
            return sb.toString();
        } catch (Throwable t) {
            return null;
        }
    }
}
