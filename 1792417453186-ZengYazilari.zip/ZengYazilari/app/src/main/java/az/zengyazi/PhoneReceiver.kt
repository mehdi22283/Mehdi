package az.zengyazi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

/** Adi telefon zənglərini (gələn/gedən) izləyir. */
class PhoneReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        if (state == last) return
        val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        if (!num.isNullOrBlank()) number = num
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> incoming = true
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                if (last != TelephonyManager.EXTRA_STATE_RINGING) incoming = false
                RecorderService.start(c, number ?: "Naməlum", "Telefon", incoming)
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                if (last == TelephonyManager.EXTRA_STATE_OFFHOOK) RecorderService.stop(c)
                number = null; incoming = true
            }
        }
        last = state
    }

    companion object {
        private var last = TelephonyManager.EXTRA_STATE_IDLE
        private var incoming = true
        private var number: String? = null
    }
}
