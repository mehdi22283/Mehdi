package com.example.callrec

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

object Notif {
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("idle", "Xidmət", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("rec", "Yazılma", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("done", "Yazıldı", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("pair", "Cütləşdirmə", NotificationManager.IMPORTANCE_HIGH))
    }

    fun info(c: Context, id: Int, title: String, text: String) {
        channels(c)
        c.getSystemService(NotificationManager::class.java).notify(id, Notification.Builder(c, "done")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(title).setContentText(text).setAutoCancel(true).build())
    }

    /** Bildirişdən cavab yazma xanası: "PORT KOD" */
    fun pairPrompt(c: Context) {
        channels(c)
        val ri = RemoteInput.Builder("pair").setLabel("PORT KOD (məs: 37215 123456)").build()
        val pi = PendingIntent.getBroadcast(c, 7, Intent(c, PairReceiver::class.java),
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val act = Notification.Action.Builder(
            Icon.createWithResource(c, android.R.drawable.ic_menu_send), "Kodu daxil et", pi
        ).addRemoteInput(ri).build()
        c.getSystemService(NotificationManager::class.java).notify(5, Notification.Builder(c, "pair")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Cütləşdirmə lazımdır")
            .setContentText("Wireless debugging → Pair with pairing code → port və kodu bura yazın")
            .addAction(act).setOngoing(true).build())
    }
}
