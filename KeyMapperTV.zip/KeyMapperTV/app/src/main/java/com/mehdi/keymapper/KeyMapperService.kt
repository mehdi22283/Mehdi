package com.mehdi.keymapper

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class KeyMapperService : AccessibilityService() {

    companion object {
        const val LONG_MS = 600L
        @Volatile var running = false
        @Volatile var capture: ((Int) -> Unit)? = null
        @Volatile var swallowUp = -1
    }

    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var fgPkg: String? = null
    private var longFired = false
    private var pending: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        try {
            val k = Intent(this, KeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(k) else startService(k)
        } catch (_: Exception) {}
        Adb.connect()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val p = e?.packageName?.toString() ?: return
        if (p == packageName) return
        val skip = listOf("launcher", "tvhome", "systemui", "inputmethod", "settings")
        if (skip.any { p.contains(it, true) }) return
        fgPkg = p
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(ev: KeyEvent): Boolean {
        val cap = capture
        if (cap != null) {
            if (ev.action == KeyEvent.ACTION_DOWN) {
                capture = null
                swallowUp = ev.keyCode
                ui.post { cap(ev.keyCode) }
            }
            return true
        }
        if (ev.action == KeyEvent.ACTION_UP && ev.keyCode == swallowUp) {
            swallowUp = -1
            return true
        }

        val m = Store.find(ev.keyCode) ?: return false
        val hasLong = m.long.type != "NONE"
        val shortKey = if (m.short.type == "KEY") Store.parseKey(m.short.param) else 0

        // Gecikmə 0: qısa əməl həmişə DOWN anında dərhal icra olunur (UP-u gözləmir).
        // Uzun basma varsa, düymə LONG_MS müddətindən çox saxlanılanda əlavə olaraq icra olunur.
        when (ev.action) {
            KeyEvent.ACTION_DOWN -> {
                if (ev.repeatCount == 0) {
                    longFired = false
                    pending?.let { ui.removeCallbacks(it) }
                    pending = null
                    if (shortKey != 0) Adb.keyDown(shortKey, 0) else run(m.short)
                    if (hasLong) {
                        val r = Runnable { longFired = true; run(m.long) }
                        pending = r
                        ui.postDelayed(r, LONG_MS)
                    }
                } else if (!hasLong && shortKey != 0) {
                    Adb.keyDown(shortKey, ev.repeatCount)
                }
            }
            KeyEvent.ACTION_UP -> {
                pending?.let { ui.removeCallbacks(it) }
                pending = null
                if (shortKey != 0) Adb.keyUp(shortKey)
            }
        }
        return true
    }

    private fun run(a: Action) {
        when (a.type) {
            "KEY" -> {
                val c = Store.parseKey(a.param)
                if (c != 0) Adb.tap(c)
            }
            "APP" -> packageManager.getLaunchIntentForPackage(a.param.trim())?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(it)
            }
            "FORCE_STOP" -> forceStopCurrent()
            "HOME" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "BACK" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "SHELL" -> if (a.param.isNotBlank()) Adb.shell(a.param)
        }
    }

    private fun forceStopCurrent() {
        val p = fgPkg ?: return
        if (p == packageName) return
        Adb.shell("am force-stop $p")
        performGlobalAction(GLOBAL_ACTION_HOME)
        fgPkg = null
    }
}
