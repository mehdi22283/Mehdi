package com.zengyazici;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.net.Uri;

/** Xatırlatma günü çatanda bildiriş göndərir (xidmət işləməsə də alarm bunu oyadır). */
public class ReminderReceiver extends BroadcastReceiver {
    public static final String CH = "rem";

    @Override
    public void onReceive(Context c, Intent i) {
        fire(c, i.getIntExtra("id", -1));
    }

    static void fire(Context c, int id) {
        Notes.Entry e = Notes.get(c, id);
        if (e == null || e.done) return;
        Notes.markDone(c, id);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH, "Zəng xatırlatmaları", NotificationManager.IMPORTANCE_HIGH));

        Intent open = new Intent(c, NotesActivity.class).putExtra("key", e.key)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent op = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = new Notification.Builder(c, CH)
                .setSmallIcon(android.R.drawable.ic_menu_call)
                .setContentTitle("📞 Zəng xatırlatması")
                .setContentText("Yenidən zəng et: " + e.key)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setContentIntent(op);
        if (Notes.isNumber(e.key)) {
            Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + e.key)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent dp = PendingIntent.getActivity(c, id + 1000000, dial, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_call), "Zəng et", dp).build());
        }
        nm.notify(1000 + id, b.build());
    }
}
