package az.market.endirim

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Sources {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private fun get(url: String): Document =
        Jsoup.connect(url).userAgent(UA).timeout(25_000).followRedirects(true).maxBodySize(0).get()

    // ---------- Bravo: Publuu flipbook (WebView-da açılır) ----------
    suspend fun bravo(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://bravosupermarket.az/special-offers/leaflet/")
        val link = Regex("""https://publuu\.com/flip-book/\d+/\d+""").find(doc.html())?.value
            ?: throw IllegalStateException("Publuu linki tapılmadı")
        listOf(
            Catalog("Bravo Market", "Supermanat Hiper", DateUtil.find(doc.body().text()), Kind.WEB, listOf(link), "Veb-jurnal")
        )
    }

    // ---------- Araz: səhifədə PDF + tarix ----------
    suspend fun araz(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://www.arazmarket.az/az/discount-magazine")
        val links = doc.select("a[href*=.pdf]").toList().filter { it.absUrl("href").isNotEmpty() }
        if (links.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        val seen = HashSet<String>()
        links.mapNotNull { a ->
            val url = a.absUrl("href")
            if (!seen.add(url)) return@mapNotNull null
            val date = dateAround(a) ?: DateUtil.find(doc.body().text())
            Catalog("Araz Market", "Endirim jurnalı", date, Kind.PDF, listOf(url), "PDF")
        }
    }

    // ---------- Oba: səhifədəki bütün PDF-lər, tarix PDF-dən OCR ilə oxunur (Tamstore məntiqi) ----------
    suspend fun oba(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://oba.az/endirim-jurnali/")
        // sıra ilə: h2 başlıq → ondan sonrakı "Jurnalı yüklə" PDF linki
        val found = LinkedHashMap<String, String>()
        var lastTitle = ""
        doc.select("h2, a[href*=.pdf]").forEach { el ->
            if (el.tagName() == "h2") {
                lastTitle = el.text().trim()
            } else {
                val u = el.absUrl("href")
                if (u.isNotEmpty() && !found.containsKey(u)) found[u] = lastTitle
            }
        }
        Regex("""https?://[^"'\s)<>]+\.pdf""").findAll(doc.html()).forEach {
            if (it.value.contains("oba.az")) found.putIfAbsent(it.value, "")
        }
        // "SOBA dadı" jurnalı siyahıya düşmür
        found.entries.removeAll { (u, t) ->
            (t + " " + u).lowercase().let { it.contains("soba") }
        }
        if (found.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        found.entries.mapIndexed { i, (u, t) ->
            // tarix PDF-dən OCR ilə oxunacaq (MainActivity)
            Catalog("Oba Market", t.ifEmpty { "Endirim jurnalı ${i + 1}" }, null, Kind.PDF, listOf(u), "PDF")
        }
    }

    private fun dateAround(el: Element): String? {
        var cur: Element? = el
        repeat(5) {
            cur = cur?.parent()
            val d = cur?.text()?.let { DateUtil.find(it) }
            if (d != null) return d
        }
        return null
    }

    // ---------- Rahat: iki PDF, tarix fayl adından ----------
    suspend fun rahat(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://rahatmarket.az/az/aksiyalar/rahat-market")
        val urls = doc.select("a[href*=.pdf]").map { it.absUrl("href") }.filter { it.isNotEmpty() }.distinct()
        if (urls.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        urls.mapIndexed { i, u ->
            val name = u.substringAfterLast('/').substringBefore(".pdf")
            Catalog("Rahat Market", "Jurnal ${i + 1}", DateUtil.fromFileName(name), Kind.PDF, listOf(u), "PDF")
        }
    }

    // ---------- Tamstore: "Elektron jurnal" bölməsindəki bütün PDF-lər ----------
    suspend fun tamstore(): List<Catalog> = withContext(Dispatchers.IO) {
        val doc = get("https://www.tamstore.az/az/kampaniyalar")
        val urls = LinkedHashSet<String>()
        doc.select("a[href*=.pdf]").forEach { val u = it.absUrl("href"); if (u.isNotEmpty()) urls.add(u) }
        Regex("""https?://[^"'\s)<>]+\.pdf""").findAll(doc.html()).forEach {
            if (it.value.contains("tamstore.az")) urls.add(it.value)
        }
        if (urls.isEmpty()) throw IllegalStateException("PDF tapılmadı")
        val fmt = SimpleDateFormat("dd.MM.yyyy", Locale.US)
        val sorted = urls.sortedByDescending { ts(it) }
        // siyahının sonundakı (ən köhnə) 2 PDF atılır
        val kept = if (sorted.size > 2) sorted.dropLast(2) else sorted
        kept.mapIndexed { i, u ->
            val t = ts(u)
            val note = if (t > 0) "Yüklənib: " + fmt.format(Date(t * 1000)) else null
            // tarix PDF-dən OCR ilə oxunacaq (MainActivity)
            Catalog("Tamstore", "Elektron jurnal ${i + 1}", null, Kind.PDF, listOf(u), note)
        }
    }

    private fun ts(u: String): Long = u.substringAfterLast('/').substringBefore('-').toLongOrNull() ?: 0L

    // ---------- Al Market: rəsmi saytdakı kataloq slaydları ----------
    suspend fun al(): List<Catalog> = withContext(Dispatchers.IO) {
        val pageUrl = "https://almarket.az/az/kataloq/dusunmeden-al"
        val doc = get(pageUrl)

        // Kataloq slaydları rəsmi səhifədəki şəkillər kimi yerləşdirilir.
        val photos = LinkedHashSet<String>()
        doc.select("img").forEach { img ->
            val candidates = listOf(
                img.absUrl("src"),
                img.absUrl("data-src"),
                img.absUrl("data-lazy-src"),
                img.absUrl("data-original"),
                img.absUrl("data-fsrc")
            )
            candidates.forEach { u ->
                if (u.isNotBlank() &&
                    u.contains("/files/catalogs/") &&
                    u.substringBefore('?').lowercase().let {
                        it.endsWith(".webp") || it.endsWith(".jpg") ||
                        it.endsWith(".jpeg") || it.endsWith(".png")
                    }) photos.add(u)
            }
            val srcset = img.attr("srcset").ifBlank { img.attr("data-srcset") }
            srcset.split(",").forEach { part ->
                val u = part.trim().substringBefore(" ").let {
                    if (it.startsWith("http")) it else ""
                }
                if (u.isNotBlank() && u.contains("/files/catalogs/")) photos.add(u)
            }
        }

        // Bəzi versiyalarda slayd şəkilləri CSS background-image kimi verilir.
        val imageRegex = Regex("""https?://[^\\s"'()]+/files/catalogs/[^\\s"'()]+\\.(?:webp|jpe?g|png)(?:\\?[^\\s"'()]*)?""", RegexOption.IGNORE_CASE)
        imageRegex.findAll(doc.html()).forEach { photos.add(it.value) }

        if (photos.isEmpty()) throw IllegalStateException("Al Market kataloq slaydları tapılmadı")
        val text = doc.body().text()
        listOf(
            Catalog("Al Market", "Düşünmədən AL!", DateUtil.find(text), Kind.IMAGES,
                photos.toList(), "${photos.size} slayd")
        )
    }

}
