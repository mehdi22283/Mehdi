package az.videoyabax;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.util.VLCVideoLayout;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    /** MPEG-1/2 (DVD, VCD) formatları: proqram dekodlama ilə daha etibarlı oynayır. */
    private static final List<String> MPEG_EXT = Arrays.asList(".vob", ".mpg", ".mpeg", ".mpe", ".m2v", ".dat", ".vro");

    private LinearLayout idle;
    private TextView ipView, hud;
    private VLCVideoLayout vl;
    private LibVLC libVlc;
    private MediaPlayer mp;
    private int playedGen = 0;
    private final Handler handler = new Handler();
    private final Runnable hideHud = new Runnable() {
        @Override public void run() { hud.setVisibility(View.GONE); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0B1437);

        idle = new LinearLayout(this);
        idle.setOrientation(LinearLayout.VERTICAL);
        idle.setGravity(Gravity.CENTER);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        idle.addView(logo, new LinearLayout.LayoutParams(220, 220));
        idle.addView(text("Videoya bax", 44, 0xFFFFFFFF, true));
        idle.addView(text("Telefonun brauzerində bu ünvanı yazın:", 24, 0xFFB8C4FF, false));
        ipView = text("", 56, 0xFFFFC857, true);
        idle.addView(ipView);
        idle.addView(text("Sonra telefondakı videonu seçin – TV-də avtomatik açılacaq.", 22, 0xFF8FA0E0, false));

        vl = new VLCVideoLayout(this);
        vl.setVisibility(View.GONE);
        vl.setKeepScreenOn(true);

        hud = text("", 28, 0xFFFFFFFF, true);
        hud.setBackgroundColor(0xAA000000);
        hud.setVisibility(View.GONE);

        root.addView(idle, new ViewGroup.LayoutParams(-1, -1));
        root.addView(vl, new ViewGroup.LayoutParams(-1, -1));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        hp.setMargins(0, 40, 40, 0);
        root.addView(hud, hp);
        setContentView(root);

        Intent s = new Intent(this, VideoService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        askOverlayOnce();
    }

    private TextView text(String t, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(40, 12, 40, 12);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private void askOverlayOnce() {
        if (Build.VERSION.SDK_INT < 23) return;
        SharedPreferences sp = getSharedPreferences("vb", MODE_PRIVATE);
        if (sp.getBoolean("asked", false) || Settings.canDrawOverlays(this)) return;
        sp.edit().putBoolean("asked", true).apply();
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) { }
    }

    static String localIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) { }
        return "TV-nin-IP-si";
    }

    @Override
    protected void onResume() {
        super.onResume();
        ipView.setText(localIp() + ":" + VideoServer.PORT);
        check();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        check();
    }

    private void check() {
        if (VideoServer.hasVideo && VideoServer.gen != playedGen) play(VideoServer.gen);
    }

    private void play(int g) {
        playedGen = g;
        releasePlayer();

        String n = VideoServer.name == null ? "" : VideoServer.name;
        int dot = n.lastIndexOf('.');
        String ext = (dot >= 0 && n.length() - dot <= 6) ? n.substring(dot).replaceAll("[^A-Za-z0-9.]", "") : "";
        String url = "http://127.0.0.1:" + VideoServer.PORT + "/stream/video" + ext + "?g=" + g;

        ArrayList<String> opts = new ArrayList<>();
        opts.add("--network-caching=4000");
        opts.add("--file-caching=4000");
        libVlc = new LibVLC(this, opts);
        mp = new MediaPlayer(libVlc);
        mp.setEventListener(new MediaPlayer.EventListener() {
            @Override
            public void onEvent(final MediaPlayer.Event ev) {
                if (ev.type == MediaPlayer.Event.EndReached) {
                    runOnUiThread(new Runnable() { @Override public void run() { closePlayback(); } });
                } else if (ev.type == MediaPlayer.Event.EncounteredError) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            Toast.makeText(MainActivity.this, "Video açılmadı", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
        mp.attachViews(vl, null, false, false);
        idle.setVisibility(View.GONE);
        vl.setVisibility(View.VISIBLE);

        Media m = new Media(libVlc, Uri.parse(url));
        boolean mpeg = MPEG_EXT.contains(ext.toLowerCase(Locale.ROOT));
        m.setHWDecoderEnabled(!mpeg, false);
        mp.setMedia(m);
        m.release();
        mp.play();
    }

    private void releasePlayer() {
        if (mp != null) {
            try { mp.stop(); mp.detachViews(); mp.release(); } catch (Exception ignored) { }
            mp = null;
        }
        if (libVlc != null) {
            try { libVlc.release(); } catch (Exception ignored) { }
            libVlc = null;
        }
    }

    /** Oxutmanı bağlayır, videonu yaddaşdan silir, gözləmə ekranına qayıdır. */
    private void closePlayback() {
        releasePlayer();
        VideoServer.discard();
        vl.setVisibility(View.GONE);
        hud.setVisibility(View.GONE);
        idle.setVisibility(View.VISIBLE);
    }

    private void showHud(String t) {
        hud.setText(t);
        hud.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideHud);
        handler.postDelayed(hideHud, 2000);
    }

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
    }

    private void seek(long delta) {
        if (mp == null) return;
        long t = Math.max(0, mp.getTime() + delta);
        long len = mp.getLength();
        if (len > 0 && t > len - 1000) t = len - 1000;
        mp.setTime(t);
        showHud(fmt(t) + (len > 0 ? " / " + fmt(len) : ""));
    }

    @Override
    public boolean onKeyDown(int k, KeyEvent e) {
        if (mp != null) {
            switch (k) {
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                case KeyEvent.KEYCODE_SPACE:
                    if (mp.isPlaying()) { mp.pause(); showHud("⏸ Pauza"); }
                    else { mp.play(); showHud("▶ Oynayır"); }
                    return true;
                case KeyEvent.KEYCODE_MEDIA_PLAY:
                    mp.play(); showHud("▶ Oynayır"); return true;
                case KeyEvent.KEYCODE_MEDIA_PAUSE:
                    mp.pause(); showHud("⏸ Pauza"); return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                    seek(10000); return true;
                case KeyEvent.KEYCODE_DPAD_LEFT:
                case KeyEvent.KEYCODE_MEDIA_REWIND:
                    seek(-10000); return true;
                default:
                    break;
            }
        }
        return super.onKeyDown(k, e);
    }

    @Override
    public void onBackPressed() {
        if (mp != null) closePlayback(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (mp != null) { releasePlayer(); VideoServer.discard(); }
        super.onDestroy();
    }
}
