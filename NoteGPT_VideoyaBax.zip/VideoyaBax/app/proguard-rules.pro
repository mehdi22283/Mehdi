# Release build-də minify söndürülüb, ona görə bu fayl yalnız ehtiyat üçündür.
-dontwarn com.google.zxing.**
-keep class com.google.zxing.** { *; }
