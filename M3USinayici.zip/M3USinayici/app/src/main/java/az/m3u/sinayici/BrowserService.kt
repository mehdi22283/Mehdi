package az.m3u.sinayici

import android.app.Activity
import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.lang.ref.WeakReference

/** Tətbiq sinfi: açıq (görünən) activity sayını izləyir; Mini brauzer açıqkən tətbiqdən çıxılanda fon xidmətini işə salır. */
class App : Application() {
    private var started = 0

    override fun onCreate() {
        super.onCreate()
        Net.load(getSharedPreferences("m3u", MODE_PRIVATE))
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(a: Activity) {
                started++
                if (started == 1) BrowserService.stop(this@App)   // tətbiqə qayıdıldı → bildiriş silinir
            }
            override fun onActivityStopped(a: Activity) {
                if (a.isChangingConfigurations) return
                started = (started - 1).coerceAtLeast(0)
                if (started == 0 && MiniBrowser.isOpen()) BrowserService.start(this@App)
            }
            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityResumed(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }
}

/** Açıq Mini brauzer activity-sinə qlobal istinad. */
object MiniBrowser {
    private var ref: WeakReference<Activity>? = null
    fun register(a: Activity) { ref = WeakReference(a) }
    fun unregister(a: Activity) { if (ref?.get() === a) ref = null }
    fun isOpen(): Boolean { val a = ref?.get(); return a != null && !a.isFinishing && !a.isDestroyed }
    /** "Brauzeri bağla": brauzer activity-si bağlanır. */
    fun close() {
        val a = ref?.get() ?: return
        Handler(Looper.getMainLooper()).post { if (!a.isFinishing) a.finish() }
    }
}

/**
 * Mini brauzer açıqkən istifadəçi tətbiqdən çıxanda prosesi canlı saxlayan ön plan xidməti.
 * Bildiriş: "Brauzer işləyir" + "Brauzeri bağla" düyməsi.
 */
class BrowserService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_CLOSE) {
            MiniBrowser.close()
            stopForegroundCompat()
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "Brauzer", NotificationManager.IMPORTANCE_LOW))
        }
        val closePi = PendingIntent.getService(this, 1,
            Intent(this, BrowserService::class.java).setAction(ACTION_CLOSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val openPi = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else @Suppress("DEPRECATION") Notification.Builder(this)
        b.setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Brauzer işləyir")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(null, "Brauzeri bağla", closePi).build())
        val n = b.build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(ID, n)
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
        else @Suppress("DEPRECATION") stopForeground(true)
    }

    companion object {
        const val ACTION_CLOSE = "az.m3u.sinayici.CLOSE_BROWSER"
        private const val CH = "browser_bg"
        private const val ID = 4201

        fun start(c: Context) {
            try {
                val i = Intent(c, BrowserService::class.java)
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) { }
        }
        fun stop(c: Context) { try { c.stopService(Intent(c, BrowserService::class.java)) } catch (e: Exception) { } }
    }
}
