plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.callrec"
    compileSdk = 34
    defaultConfig { applicationId = "com.example.callrec"; minSdk = 31; targetSdk = 34; versionCode = 3; versionName = "3.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.kotlin_module") }
}
dependencies {
    // Daxili ADB müştərisi (cütləşdirmə + qoşulma). Mümkünsə JitPack-də konkret tag ilə əvəz edin.
    implementation("com.github.MuntashirAkon:libadb-android:master-SNAPSHOT")
    implementation("org.conscrypt:conscrypt-android:2.5.2")
    // X.509 sertifikat yaratmaq üçün (Android-in öz BouncyCastle-ı ilə toqquşmasın deyə SpongyCastle)
    implementation("com.madgag.spongycastle:prov:1.54.0.0")
    implementation("com.madgag.spongycastle:pkix:1.54.0.0")
}
