package az.videyabax.app

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {
    private lateinit var playerView: PlayerView
    private lateinit var info: TextView
    private var player: ExoPlayer? = null
    private var server: VideoServer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        playerView=findViewById(R.id.player_view)
        info=findViewById(R.id.info)

        val ip=getLocalIp()
        info.text="Videoya bax\n\nTelefonda brauzerdə aç:\nhttp://$ip:3169"
        server=VideoServer(3169) { url ->
            runOnUiThread { play(url) }
        }
        server!!.start()
    }

    private fun play(url:String) {
        if(player==null) {
            player=ExoPlayer.Builder(this).build()
            playerView.player=player
        }
        player!!.setMediaItem(MediaItem.fromUri(url))
        player!!.prepare()
        player!!.playWhenReady=true
        info.visibility=View.GONE
    }

    private fun getLocalIp():String {
        return try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
                ?.hostAddress ?: "TV-IP"
        } catch(e:Exception) { "TV-IP" }
    }

    override fun onDestroy() {
        server?.stop()
        player?.release()
        super.onDestroy()
    }
}
