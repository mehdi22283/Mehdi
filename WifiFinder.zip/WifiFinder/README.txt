WiFi Finder - Kotlin Android layihəsi
GitHub Actions ilə qur: bu zip-i repoya olduğu kimi yüklə + .github/workflows/build.yml

Yeniliklər:
- Wi-Fi RTT (802.11mc, Android 9+): dəstəkləyən AP-lər üçün real məsafə ölçülür.
- AR və Kompasda bütün şəbəkələr görünür, hər birinin məsafəsi (metr) yazılır.
- Seçilmiş şəbəkə qızılı rəng, ★ işarəsi və böyük marker ilə fərqlənir.
- Kompasda radar görünüşü (yaxın = mərkəzə yaxın), altda və AR-da məsafə siyahısı.

Qeydlər:
- RTT üçün həm telefon, həm də router 802.11mc dəstəkləməlidir; Wi-Fi və Məkan açıq olmalıdır.
- Digər şəbəkələrin istiqaməti üçün telefonla yavaş 360° dönmək lazımdır.
  Android skanı məhdudlaşdırır: Developer options > "Wi-Fi scan throttling" söndürsəniz daha sürətli olur.
