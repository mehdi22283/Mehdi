package com.mehdi.keymapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class KeepAliveService : Service() {

    companion object {
        @Volatile
        var running: Boolean = false
    }

    override fun onCreate() {
        super.onCreate()
        val id = "keepalive"
        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(id, "Key Mapper", NotificationManager.IMPORTANCE_MIN))
            builder = Notification.Builder(this, id)
        } else {
            builder = Notification.Builder(this)
        }
        builder.setContentTitle("Key Mapper TV aktivdir")
        builder.setSmallIcon(android.R.drawable.ic_media_play)
        builder.setOngoing(true)
        startForeground(1, builder.build())
        running = true
        Adb.connect()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }
}
