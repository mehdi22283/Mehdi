package az.zeng.yazici;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static class Rec {
        String path, src, dir, label;
        long ts;
        int dur;
        boolean live;
    }

    static class VH {
        TextView play, time;
        SeekBar seek;
        String path;
        int dur;
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Rec> recs = new ArrayList<>();
    private SharedPreferences p;
    private TextView status;
    private Adapter ad;
    private MediaPlayer mp;
    private String curPath, sig = "";
    private VH curVH;
    private boolean resumed;

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (!resumed) return;
            reload(false);
            h.postDelayed(this, 4000);
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("st", 0);
        Notif.init(this);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(dp(16), dp(24), dp(16), dp(8));

        TextView title = new TextView(this);
        title.setText("Zəng Yazıcı");
        title.setTextSize(24);
        title.setTextColor(Color.BLACK);
        head.addView(title);

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, dp(8), 0, dp(8));
        head.addView(status);

        head.addView(btn("1. İcazələri ver", v -> askPerms()));
        head.addView(btn("2. Cütləşdir (Wireless debugging)", v -> pairing()));
        head.addView(btn("3. Yazıcı prosesi başlat", v -> startProc()));
        head.addView(btn("4. WhatsApp üçün bildiriş girişi", v ->
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))));
        head.addView(btn("5. Avtostart (Xiaomi)", v -> autostart()));
        head.addView(btn("6. 6 saniyəlik sınaq yazısı", v -> test()));
        head.addView(btn("Jurnal (xəta olsa mənə göndər)", v -> showLog()));

        Switch sw = new Switch(this);
        sw.setText("Telefon zəngi: mikrofon + dinamik rejimi (VOICE_CALL işləməsə)");
        sw.setPadding(0, dp(12), 0, dp(12));
        sw.setChecked(p.getInt("ph_mode", 0) == 1);
        sw.setOnCheckedChangeListener((v, on) -> p.edit().putInt("ph_mode", on ? 1 : 0).apply());
        head.addView(sw);

        Switch sw2 = new Switch(this);
        sw2.setText("Yazıcı proses söndükdə zəng zamanı avtomatik başlat (Wi-Fi + Wireless debugging lazımdır)");
        sw2.setPadding(0, dp(4), 0, dp(12));
        sw2.setChecked(p.getBoolean("auto_adb", true));
        sw2.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean("auto_adb", on).apply());
        head.addView(sw2);

        TextView lt = new TextView(this);
        lt.setText("Yazılar");
        lt.setTextSize(18);
        lt.setTextColor(Color.BLACK);
        lt.setPadding(0, dp(8), 0, dp(4));
        head.addView(lt);

        ListView list = new ListView(this);
        list.addHeaderView(head, null, false);
        ad = new Adapter();
        list.setAdapter(ad);
        list.setOnItemLongClickListener((par, v, pos, id) -> {
            int i = pos - 1;
            if (i >= 0 && i < recs.size()) confirmDelete(recs.get(i));
            return true;
        });
        setContentView(list);

    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        refresh();
        reload(true);
        h.postDelayed(poll, 4000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        h.removeCallbacks(poll);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlayer();
    }

    private boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void refresh() {
        new Thread(() -> {
            final boolean up = RecorderClient.ping(this);
            runOnUiThread(() -> {
                StringBuilder s = new StringBuilder();
                s.append(up ? "✔ Yazıcı proses işləyir\n" : "✖ Yazıcı proses işləmir (2 və 3-cü düymələr)\n");
                s.append(AdbMgr.paired(this) ? "✔ Wireless debugging ilə cütləşib\n" : "✖ Hələ cütləşməyib\n");
                boolean ph = has(Manifest.permission.READ_PHONE_STATE) && has(Manifest.permission.READ_CALL_LOG)
                        && has(Manifest.permission.PROCESS_OUTGOING_CALLS);
                s.append(ph ? "✔ Telefon icazələri verilib\n" : "✖ Telefon icazələri çatmır\n");
                String en = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
                boolean nl = en != null && en.contains(getPackageName());
                s.append(nl ? "✔ WhatsApp üçün bildiriş girişi aktivdir" : "✖ WhatsApp üçün bildiriş girişi söndürülüb");
                status.setText(s.toString());
            });
        }).start();
    }

    private void askPerms() {
        List<String> need = new ArrayList<>(Arrays.asList(
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.PROCESS_OUTGOING_CALLS));
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(need.toArray(new String[0]), 1);
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] pm, int[] r) {
        super.onRequestPermissionsResult(c, pm, r);
        refresh();
    }

    private void pairing() {
        Notif.pairPrompt(this, "Developer options > Wireless debugging > \"Pair device with pairing code\" pəncərəsini açın və göstərilən 6 rəqəmli kodu bura yazın.");
        Toast.makeText(this, "Bildiriş panelini açıb kodu yazın", Toast.LENGTH_LONG).show();
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
        } catch (Throwable t) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void startProc() {
        Toast.makeText(this, "Başladılır…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String msg;
            try {
                AdbStarter.startDaemon(this);
                Thread.sleep(1200);
                msg = RecorderClient.ping(this) ? "Yazıcı proses işləyir" : "Başladılmadı, Jurnala baxın";
            } catch (Throwable t) {
                msg = "Xəta: " + t.getMessage();
            }
            final String fm = msg;
            runOnUiThread(() -> {
                Toast.makeText(this, fm, Toast.LENGTH_LONG).show();
                refresh();
            });
        }).start();
    }

    private void autostart() {
        try {
            Intent i = new Intent();
            i.setComponent(new ComponentName("com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            startActivity(i);
        } catch (Throwable t) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void test() {
        RecorderClient.begin(this, "ph", "out", "Sinaq", null);
        h.postDelayed(() -> RecorderClient.end(this, "ph", () -> reload(true)), 6000);
    }

    private void showLog() {
        final String[] out = {""};
        RecorderClient.run(this, r -> out[0] = r.log(), err -> new AlertDialog.Builder(this)
                .setTitle("Jurnal")
                .setMessage((err != null ? "Xəta: " + err.getMessage() + "\n" : "") + (p.getString("adb_err", "").isEmpty() ? "" : "adb: " + p.getString("adb_err", "") + "\n") + (out[0].isEmpty() ? "" : out[0]))
                .setPositiveButton("Bağla", null)
                .show());
    }

    private void confirmDelete(final Rec r) {
        new AlertDialog.Builder(this)
                .setMessage("Bu yazı silinsin?\n" + r.label)
                .setPositiveButton("Sil", (d, w) -> {
                    if (r.path.equals(curPath)) stopPlayer();
                    new File(r.path).delete();
                    reload(true);
                })
                .setNegativeButton("Ləğv et", null)
                .show();
    }

    // ---------- siyahı ----------

    private File mediaDir() {
        File[] ds = getExternalMediaDirs();
        return ds != null && ds.length > 0 ? ds[0] : null;
    }

    private void reload(boolean force) {
        File d = mediaDir();
        File[] fs = d == null ? null : d.listFiles((x, n) -> n.endsWith(".wav"));
        if (fs == null) fs = new File[0];
        Arrays.sort(fs, (a, b) -> b.getName().compareTo(a.getName()));
        boolean active = p.getBoolean("active", false);
        String ap = p.getString("path", "");
        String s = fs.length + "|" + (fs.length > 0 ? fs[0].getName() : "") + "|" + active;
        if (!force && s.equals(sig)) return;
        sig = s;
        recs.clear();
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        for (File x : fs) {
            String n = x.getName().substring(0, x.getName().length() - 4);
            String[] a = n.split("__", 4);
            if (a.length < 4) continue;
            Rec r = new Rec();
            r.path = x.getAbsolutePath();
            r.src = a[1];
            r.dir = a[2];
            r.label = a[3].replace('_', ' ');
            try {
                r.ts = f.parse(a[0]).getTime();
            } catch (Exception e) {
                r.ts = x.lastModified();
            }
            r.live = active && r.path.equals(ap);
            r.dur = r.live ? 0 : durationOf(x);
            recs.add(r);
        }
        ad.notifyDataSetChanged();
    }

    private static int durationOf(File f) {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            if (f.length() <= 44) return 0;
            r.seek(24);
            byte[] b = new byte[4];
            r.readFully(b);
            int rate = (b[0] & 255) | ((b[1] & 255) << 8) | ((b[2] & 255) << 16) | ((b[3] & 255) << 24);
            if (rate <= 0) return 0;
            return (int) ((f.length() - 44) / (rate * 2L));
        } catch (Exception e) {
            return 0;
        }
    }

    private static String fmt(int sec) {
        return String.format(Locale.US, "%d:%02d", sec / 60, sec % 60);
    }

    // ---------- player ----------

    private void stopPlayer() {
        if (mp != null) {
            try {
                mp.release();
            } catch (Throwable ignored) {
            }
            mp = null;
        }
        curPath = null;
        curVH = null;
    }

    private void toggle(VH v, Rec r) {
        try {
            if (r.path.equals(curPath) && mp != null) {
                if (mp.isPlaying()) {
                    mp.pause();
                    v.play.setText("▶");
                } else {
                    mp.start();
                    v.play.setText("⏸");
                    tick();
                }
                return;
            }
            stopPlayer();
            mp = new MediaPlayer();
            mp.setDataSource(r.path);
            mp.prepare();
            mp.setOnCompletionListener(m -> {
                stopPlayer();
                ad.notifyDataSetChanged();
            });
            mp.start();
            curPath = r.path;
            curVH = v;
            v.play.setText("⏸");
            tick();
        } catch (Throwable t) {
            Toast.makeText(this, "Oxutmaq olmadı: " + t.getMessage(), Toast.LENGTH_LONG).show();
            stopPlayer();
        }
    }

    private final Runnable ticker = this::tick;

    private void tick() {
        h.removeCallbacks(ticker);
        if (mp == null || curVH == null) return;
        try {
            if (curPath != null && curPath.equals(curVH.path)) {
                int d = mp.getDuration(), c = mp.getCurrentPosition();
                curVH.seek.setMax(Math.max(d, 1));
                curVH.seek.setProgress(c);
                curVH.time.setText(fmt(c / 1000) + " / " + fmt(d / 1000));
            }
            if (mp.isPlaying()) h.postDelayed(ticker, 300);
        } catch (Throwable ignored) {
        }
    }

    // ---------- adapter ----------

    private class Adapter extends BaseAdapter {
        @Override
        public int getCount() {
            return recs.size();
        }

        @Override
        public Object getItem(int i) {
            return recs.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View cv, ViewGroup par) {
            final Rec r = recs.get(pos);
            LinearLayout root;
            TextView badge, arrow, name, when;
            VH v;
            if (cv == null) {
                root = new LinearLayout(MainActivity.this);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setPadding(dp(16), dp(10), dp(16), dp(10));

                LinearLayout top = new LinearLayout(MainActivity.this);
                top.setGravity(Gravity.CENTER_VERTICAL);
                badge = new TextView(MainActivity.this);
                badge.setTextColor(Color.WHITE);
                badge.setTextSize(11);
                badge.setPadding(dp(8), dp(2), dp(8), dp(2));
                arrow = new TextView(MainActivity.this);
                arrow.setTextSize(20);
                arrow.setPadding(dp(8), 0, dp(8), 0);
                name = new TextView(MainActivity.this);
                name.setTextSize(16);
                name.setTextColor(Color.BLACK);
                name.setSingleLine(true);
                when = new TextView(MainActivity.this);
                when.setTextSize(12);
                top.addView(badge);
                top.addView(arrow);
                top.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                top.addView(when);
                root.addView(top);

                LinearLayout bar = new LinearLayout(MainActivity.this);
                bar.setGravity(Gravity.CENTER_VERTICAL);
                v = new VH();
                v.play = new TextView(MainActivity.this);
                v.play.setTextSize(24);
                v.play.setPadding(dp(4), dp(4), dp(12), dp(4));
                v.seek = new SeekBar(MainActivity.this);
                v.time = new TextView(MainActivity.this);
                v.time.setTextSize(12);
                v.time.setPadding(dp(8), 0, 0, 0);
                bar.addView(v.play);
                bar.addView(v.seek, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                bar.addView(v.time);
                root.addView(bar);
                root.setTag(new Object[]{v, badge, arrow, name, when, bar});
                final VH fv = v;
                v.seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar s, int pr, boolean user) {
                        if (user && mp != null && fv.path != null && fv.path.equals(curPath)) mp.seekTo(pr);
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar s) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar s) {
                    }
                });
            } else {
                root = (LinearLayout) cv;
            }
            Object[] t = (Object[]) root.getTag();
            v = (VH) t[0];
            badge = (TextView) t[1];
            arrow = (TextView) t[2];
            name = (TextView) t[3];
            when = (TextView) t[4];
            View bar = (View) t[5];

            boolean wa = "wa".equals(r.src);
            boolean in = "in".equals(r.dir);
            badge.setText(wa ? "WhatsApp" : "Telefon");
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(10));
            bg.setColor(wa ? 0xFF25A244 : 0xFF455A64);
            badge.setBackground(bg);
            arrow.setText(in ? "↙" : "↗");
            arrow.setTextColor(in ? 0xFF2E7D32 : 0xFF1565C0);
            name.setText(r.label);
            when.setText(new SimpleDateFormat("dd.MM HH:mm", Locale.US).format(new Date(r.ts)));

            v.path = r.path;
            v.dur = r.dur;
            if (r.live) {
                v.play.setText("●");
                v.play.setTextColor(0xFFE53935);
                v.seek.setVisibility(View.INVISIBLE);
                v.time.setText("yazılır…");
                v.play.setOnClickListener(null);
            } else {
                v.play.setTextColor(Color.BLACK);
                v.seek.setVisibility(View.VISIBLE);
                v.play.setOnClickListener(x -> toggle(v0(x), r));
                if (r.path.equals(curPath) && mp != null) {
                    curVH = v;
                    v.play.setText(mp.isPlaying() ? "⏸" : "▶");
                    tick();
                } else {
                    v.play.setText("▶");
                    v.seek.setMax(Math.max(r.dur * 1000, 1));
                    v.seek.setProgress(0);
                    v.time.setText("0:00 / " + fmt(r.dur));
                }
            }
            root.setOnLongClickListener(x -> {
                confirmDelete(r);
                return true;
            });
            return root;
        }

        private VH v0(View playView) {
            LinearLayout root = (LinearLayout) ((View) playView.getParent()).getParent();
            return (VH) ((Object[]) root.getTag())[0];
        }
    }
}
