package com.example.callrec

import android.app.NotificationManager
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PairReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val txt = RemoteInput.getResultsFromIntent(i)?.getCharSequence("pair")?.toString() ?: return
        val p = txt.trim().split(Regex("\\s+"))
        val pr = goAsync()
        Thread {
            var ok = false
            try {
                if (p.size >= 2) {
                    AdbConnectionManager.getInstance(c).pair("127.0.0.1", p[0].toInt(), p[1])
                    ok = true
                }
            } catch (_: Throwable) {}
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.cancel(5)
            if (ok) { Prefs.setPaired(c); Notif.info(c, 6, "Cütləşdirildi ✔", "Yazıcı avtomatik qoşulacaq") }
            else { Notif.info(c, 6, "Cütləşdirmə alınmadı", "Port/kodu yoxlayın"); Notif.pairPrompt(c) }
            pr.finish()
        }.start()
    }
}
