ZƏNG YAZICI - quraşdırma (hamısı telefonda, kompüter və Shizuku lazım deyil)

Qısa iş prinsipi: tətbiq telefonun öz Wireless debugging xidməti ilə (pairing kodu) cütləşir, sonra shell icazəsi ilə kiçik yazıcı proses (Daemon) başladır. Proses başlayandan sonra Wi-Fi sönsə də işləyir. Telefon yenidən başlayanda proses bağlanır; Wi-Fi + Wireless debugging açıq olanda tətbiq onu zəng zamanı özü yenidən başlada bilər (3-cü düymə də var).

1) Tətbiqi açın, "1. İcazələri ver" düyməsini basın.
2) Wi-Fi-a qoşulun. Settings > About phone > MIUI/HyperOS versiyasına 7 dəfə toxunun. Developer options > Wireless debugging açın.
3) "2. Cütləşdir" düyməsini basın: bildiriş çıxacaq. Wireless debugging ekranında "Pair device with pairing code" seçin (pəncərə açıq qalsın), göstərilən 6 rəqəmi bildiriş panelindəki sahəyə yazın. Pəncərə bağlanarsa pairing dayanır, ona görə ekranı bölünmüş rejimdə və ya üstdən bildirişi açmaqla edin.
4) Bildiriş "Hazırdır" deyəndən sonra "4. WhatsApp üçün bildiriş girişi" və "5. Avtostart" düymələrini işlədin.
5) "6. 6 saniyəlik sınaq yazısı" ilə yoxlayın. Alınmasa "Jurnal" mətnini mənə göndərin.

Yazılar: /sdcard/Android/media/az.zeng.yazici/ (WAV)
