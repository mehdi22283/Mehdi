package az.market.endirim

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

/**
 * Jurnalların bütün səhifələrini OCR ilə oxuyub yalnız məhsul adlarını çıxarır.
 *  - PDF: hər səhifə render edilib oxunur;
 *  - şəkil albomu (Al Market): şəkillər endirilib oxunur;
 *  - veb-jurnal (Bravo flipbook): gizli WebView-da səhifələr ekran görüntüsü ilə oxunur (sınaqsız, ən zəif hissə).
 */
object ProductScanner {
    private const val PDF_W = 1600
    private const val MAX_H = 3400
    private const val MAX_IMG_W = 1800
    private const val MAX_WEB_PAGES = 60
    private val http = OkHttpClient()

    /** Jurnalın "barmaq izi": PDF üçün serverin ETag/Last-Modified/ölçüsü, digərləri üçün linklər. Dəyişəndə yenidən skan olunur. */
    fun sigFor(ctx: Context, c: Catalog): String? {
        return if (c.kind == Kind.PDF) Downloader.storedSig(ctx, c.urls[0]) else "u:" + c.urls.joinToString("|").hashCode()
    }

    /** onPartial — hər səhifə oxunandan sonra bu jurnaldan indiyə qədər tapılan məhsullar (axtarışda dərhal görünsün deyə). */
    suspend fun scan(
        act: Activity, c: Catalog,
        onProgress: (page: Int, total: Int) -> Unit,
        onPartial: (List<Product>) -> Unit = {}
    ): List<Product> {
        appCtx = act.applicationContext
        return dedupe(
            when (c.kind) {
                Kind.PDF -> scanPdf(act.applicationContext, c, onProgress, onPartial)
                Kind.IMAGES -> scanImages(c, onProgress, onPartial)
                Kind.WEB -> scanWeb(act, c, onProgress, onPartial)
            }
        )
    }

    /** Ümumi skan faizi üçün jurnalın təxmini səhifə sayı (PDF — dəqiq, şəkil albomu — şəkil sayı, veb-jurnal — təxmini 20). */
    suspend fun estimatePages(ctx: Context, c: Catalog): Int = when (c.kind) {
        Kind.IMAGES -> c.urls.size.coerceAtLeast(1)
        Kind.WEB -> 20
        Kind.PDF -> try {
            withContext(Dispatchers.IO) {
                val f = Downloader.ensure(ctx, c.urls[0])
                val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                val r = PdfRenderer(pfd)
                try { r.pageCount.coerceAtLeast(1) } finally { r.close(); pfd.close() }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            10
        }
    }

    /** Eyni anda oxunan səhifə sayı: CPU nüvələri qədər (2–4). Yalnız ML Kit işlədiyi üçün nüvələr tam yüklənir. */
    private fun workers(@Suppress("UNUSED_PARAMETER") ctx: Context): Int =
        Runtime.getRuntime().availableProcessors().coerceIn(2, 4)

    private fun dedupe(list: List<Product>): List<Product> {
        val seen = HashSet<String>()
        return list.filter { !ProductParser.hasParens(it.name) && !ProductParser.isSentence(it.name) && !AzText.hasCyrillic(it.name) && seen.add(it.key) }
    }

    private lateinit var appCtx: Context

    private suspend fun mlKitLines(bmp: Bitmap): List<OLine> =
        Ocr.recognizeText(bmp).textBlocks.flatMap { it.lines }.mapNotNull { ln ->
            ln.boundingBox?.let { OLine(ln.text, it.left, it.top, it.right, it.bottom) }
        }

    /** Yeganə OCR mühərriki — ML Kit (oflayn, sürətli). Sətirlərdən yalnız məhsul adları çıxarılır. */
    private suspend fun pageProducts(bmp: Bitmap, c: Catalog, pageNo: Int): List<Product> {
        val lines = mlKitLines(bmp)
        val found = withContext(Dispatchers.Default) { ProductParser.parseNames(lines, bmp.height) }
        return found.mapNotNull {
            val nm = AzText.fix(it)          // reklam sözləri silinir; ə/ı/ş/ç/ö/ü/ğ bərpası, kirill-latın qarışığı, böyük hərf; brendlərə toxunulmur
            if (nm.isBlank()) null else Product(nm, c.market, c.urls[0], pageNo, Categorizer.classify(nm))
        }
    }

    // ---------------- Səhifələrin paralel oxunması ----------------
    /**
     * Səhifələri paralel oxuyur: səhifənin hazırlanması (PDF render / şəkil endirmə) ardıcıl gedir — PdfRenderer eyni anda yalnız
     * bir səhifə açır — OCR isə eyni anda `workers` səhifədə işləyir. Hazır olan səhifənin məhsulları dərhal onPartial ilə verilir
     * (axtarışda skan davam etdikcə görünür). Bütün geri çağırışlar əsas axında (Main) çağrılır.
     * tolerant=false: bir səhifə oxunmasa jurnal "oxunmadı" sayılır (yarımçıq nəticə yadda qalmasın, növbəti dəfə yenidən cəhd olunsun).
     */
    private suspend fun scanPages(
        n: Int, c: Catalog, tolerant: Boolean, serialLoad: Boolean,
        load: suspend (Int) -> Bitmap,
        onProgress: (Int, Int) -> Unit, onPartial: (List<Product>) -> Unit
    ): List<Product> {
        val gate = Semaphore(workers(appCtx))
        val loadLock = Mutex()            // PdfRenderer eyni anda yalnız bir səhifə açır
        val pages = arrayOfNulls<List<Product>>(n)
        var done = 0
        var failed = 0
        onProgress(1, n)
        coroutineScope {
            for (i in 0 until n) {
                gate.acquire()
                // səhifənin yüklənməsi (render / endirmə) də OCR kimi paralel gedir; eyni anda ən çox `workers` səhifə
                launch(Dispatchers.Default) {
                    var list: List<Product>? = null
                    try {
                        val bmp: Bitmap? = try {
                            if (serialLoad) loadLock.withLock { load(i) } else load(i)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            null
                        }
                        if (bmp != null) {
                            try {
                                list = pageProducts(bmp, c, i + 1)
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                            } finally {
                                bmp.recycle()
                            }
                        }
                    } finally {
                        gate.release()
                    }
                    val got = list
                    withContext(Dispatchers.Main) {
                        done++
                        if (got != null) pages[i] = got else failed++
                        onProgress(minOf(done + 1, n), n)
                        if (got != null) onPartial(dedupe(pages.filterNotNull().flatten()))
                    }
                }
            }
        }
        if (n > 0 && (failed == n || (failed > 0 && !tolerant))) throw IOException("Səhifələr oxunmadı")
        return pages.filterNotNull().flatten()
    }

    // ---------------- PDF ----------------
    private suspend fun scanPdf(ctx: Context, c: Catalog, onProgress: (Int, Int) -> Unit, onPartial: (List<Product>) -> Unit): List<Product> {
        val file = Downloader.ensure(ctx, c.urls[0])
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try {
            return scanPages(r.pageCount, c, false, true, { i -> withContext(Dispatchers.IO) { renderPage(r, i) } }, onProgress, onPartial)
        } finally {
            r.close()
            pfd.close()
        }
    }

    private fun renderPage(r: PdfRenderer, i: Int): Bitmap {
        val p = r.openPage(i)
        try {
            var w = PDF_W
            var h = (w.toFloat() * p.height / p.width).toInt()
            if (h > MAX_H) {
                w = (w.toFloat() * MAX_H / h).toInt()
                h = MAX_H
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            p.close()
        }
    }

    // ---------------- Şəkil albomu ----------------
    private suspend fun scanImages(c: Catalog, onProgress: (Int, Int) -> Unit, onPartial: (List<Product>) -> Unit): List<Product> =
        scanPages(c.urls.size, c, true, false, { i -> withContext(Dispatchers.IO) { download(c.urls[i]) } }, onProgress, onPartial)

    private fun download(url: String): Bitmap {
        val req = Request.Builder().url(url).header("User-Agent", Insta.UA).build()
        val bytes = http.newCall(req).execute().use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            it.body!!.bytes()
        }
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / sample > MAX_IMG_W) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2) ?: throw IOException("Şəkil açılmadı")
    }

    // ---------------- Veb-jurnal (Bravo flipbook) ----------------
    private suspend fun scanWeb(act: Activity, c: Catalog, onProgress: (Int, Int) -> Unit, onPartial: (List<Product>) -> Unit): List<Product> {
        val root = act.findViewById<ViewGroup>(android.R.id.content)
        val w = (act.resources.displayMetrics.widthPixels * 1.8f).toInt()    // böyük ölçü → kiçik yazılar da oxunur
        val h = (w * 1.45f).toInt()
        val web = WebView(act)
        val out = ArrayList<Product>()
        try {
            web.settings.javaScriptEnabled = true
            web.settings.domStorageEnabled = true
            web.translationX = -w.toFloat()          // ekranın kənarında, görünmür
            root.addView(web, FrameLayout.LayoutParams(w, h))
            web.loadUrl(c.urls[0])
            delay(8000)

            val seen = HashSet<String>()
            var method = 0
            var stale = 0
            var pages = 0
            for (n in 1..MAX_WEB_PAGES) {
                onProgress(n, 0)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                web.draw(Canvas(bmp))
                try {
                    val text = try { Ocr.recognizeText(bmp) } catch (e: Exception) { null }
                    val sig = Categorizer.norm(text?.text ?: "").filter { it.isLetterOrDigit() }.take(300)
                    if (text != null && sig.length >= 20 && seen.add(sig)) {
                        stale = 0
                        pages++
                        out.addAll(pageProducts(bmp, c, pages))
                        onPartial(dedupe(out))
                    } else {
                        stale++
                        if (stale >= 4) break
                        method = (method + 1) % 3     // səhifə dəyişmədi — başqa keçid üsulu sına
                    }
                } finally {
                    bmp.recycle()
                }
                advance(web, w, h, method)
                delay(2500)
            }
        } finally {
            root.removeView(web)
            web.destroy()
        }
        return out
    }

    /** Növbəti səhifəyə keç: 0 = klaviatura →, 1 = "next" düyməsinə klik, 2 = sola sürüşdürmə. */
    private fun advance(web: WebView, w: Int, h: Int, method: Int) {
        when (method) {
            0 -> {
                web.requestFocus()
                val t = SystemClock.uptimeMillis()
                web.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT, 0))
                web.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_RIGHT, 0))
            }
            1 -> web.evaluateJavascript(
                "(function(){var e=document.querySelector('[class*=\"next\" i],[class*=\"Next\"],[aria-label*=\"ext\" i],[title*=\"ext\" i]');if(e){e.click();}})()",
                null
            )
            else -> {
                val t0 = SystemClock.uptimeMillis()
                val y = h * 0.5f
                val x0 = w * 0.8f
                val x1 = w * 0.2f
                fun ev(action: Int, x: Float, dt: Long) =
                    MotionEvent.obtain(t0, t0 + dt, action, x, y, 0).also { web.dispatchTouchEvent(it); it.recycle() }
                ev(MotionEvent.ACTION_DOWN, x0, 0)
                for (i in 1..6) ev(MotionEvent.ACTION_MOVE, x0 + (x1 - x0) * i / 6f, i * 25L)
                ev(MotionEvent.ACTION_UP, x1, 175)
            }
        }
    }
}
