package az.m3u.sinayici

import android.net.Uri
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Serverlər fərqli oynadıcıları fərqli qəbul edir (bəziləri brauzer UA-sını, bəziləri VLC-ni, bəziləri Referer-i rədd edir).
 * Ona görə hər link bir neçə "profil"lə sınanır; işləyən profil yadda saxlanılır.
 */
object Net {
    const val CHROME = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    class Target(val url: String, val headers: Map<String, String>, val name: String)

    // ---------------------------------------------------------------- 🪣 BUFER (vedrə) vəziyyəti
    // Player panelindəki 🪣 ilə Media3 yoxlayıcısı EYNİ qaydadan istifadə edir:
    //   🔴 hazır deyil / bufer ≤ 100 ms · 🟠 bufer < 2 san · 🟡 bufer azalır · 🟢 bufer ≥ 2 san və azalmır
    // Yoxlayıcıda kanal 🔴-dən 🟢-ə keçirsə işləyir, keçmirsə işləmir.
    const val B_RED = 0
    const val B_ORANGE = 1
    const val B_YELLOW = 2
    const val B_GREEN = 3
    fun bucket(ready: Boolean, aheadMs: Long, prevAheadMs: Long): Int = when {
        !ready || aheadMs <= 100 -> B_RED
        aheadMs < 2000 -> B_ORANGE
        prevAheadMs >= 0 && aheadMs - prevAheadMs < -200 -> B_YELLOW
        else -> B_GREEN
    }
    fun bucketEmoji(b: Int): String = when (b) { B_RED -> "🔴"; B_ORANGE -> "🟠"; B_YELLOW -> "🟡"; else -> "🟢" }

    private val good = ConcurrentHashMap<String, String>()
    fun markGood(url: String, name: String) { good[url] = name }

    /**
     * ExoPlayer bütün profillərlə xəta verən kanallar (açar = playlistdəki xam link).
     * Belə kanal yoxlamada həmişə 🔴 sayılır; ExoPlayer onu sonradan uğurla oynadanda siyahıdan çıxır.
     */
    private val exoFailed = ConcurrentHashMap.newKeySet<String>()
    private var prefs: android.content.SharedPreferences? = null
    fun load(sp: android.content.SharedPreferences) {
        prefs = sp
        sp.getStringSet("exoFailed", emptySet())?.let { exoFailed.addAll(it) }
    }
    private fun saveExo() { prefs?.edit()?.putStringSet("exoFailed", HashSet(exoFailed))?.apply() }
    fun exoFail(url: String) { dropCache(url); if (url.isNotEmpty() && exoFailed.add(url)) saveExo() }
    fun exoOk(url: String) { dropCache(url); clearReason(url); if (exoFailed.remove(url)) saveExo() }

    // ---------------------------------------------------------------- NİYƏ AÇILMIR (səbəb)
    /** Kanal 🔴 olanda səbəb (açar = playlistdəki xam link). JS kanal adının yanında qırmızı mötərizədə göstərir. */
    private val reasons = ConcurrentHashMap<String, Why.R>()
    fun reasonOf(url: String): String = reasons[url]?.text ?: ""
    /** HTTP 500/502 alan kanallar təkrar yoxlanmır (nə HTTP, nə Media3): nəticə dərhal 🔴 qaytarılır. */
    private val NO_RETRY = Regex("^HTTP (500|502)\\b")
    fun isNoRetry(text: String?): Boolean = !text.isNullOrEmpty() && NO_RETRY.containsMatchIn(text)
    /** Rank-lı yazı: daha konkret (yüksək rank) səbəb ümumi səbəbi əvəz edir. */
    fun setReason(url: String, r: Why.R) {
        if (url.isEmpty()) return
        if (reasons.size > 20000) reasons.clear()
        val o = reasons[url]
        if (o == null || r.rank >= o.rank) reasons[url] = r
    }
    fun forceReason(url: String, r: Why.R) { if (url.isNotEmpty()) reasons[url] = r }
    fun clearReason(url: String) { reasons.remove(url) }
    /** Cari axındakı (thread) son uğursuzluq səbəbi: yoxlama funksiyaları bunu doldurur, probeRaw toplayır. */
    private val whyTl = ThreadLocal<Why.R?>()
    private fun no(r: Why.R): Boolean { whyTl.set(r); return false }
    private fun dead(r: Why.R): String { whyTl.set(r); return "dead" }
    fun exoFailedList(): List<String> = exoFailed.toList()

    private fun canon(k: String): String = when (k.trim().lowercase()) {
        "user-agent" -> "User-Agent"
        "referer", "referrer" -> "Referer"
        "origin" -> "Origin"
        else -> k.trim()
    }

    fun profiles(raw: String, hdrJson: String): List<Target> {
        val parts = raw.split("|", limit = 2)
        val url = parts[0].trim()
        val ex = LinkedHashMap<String, String>()
        if (parts.size > 1) parts[1].split("&").forEach { kv ->
            val i = kv.indexOf('=')
            if (i > 0) ex[canon(kv.substring(0, i))] = Uri.decode(kv.substring(i + 1))
        }
        try {
            val o = JSONObject(hdrJson)
            for (k in o.keys()) ex[canon(k)] = o.getString(k)
        } catch (e: Exception) { }
        val u = Uri.parse(url)
        val origin = if (u.scheme != null && u.host != null) u.scheme + "://" + u.authority else ""
        fun mk(name: String, ua: String?, ref: Boolean): Target {
            val h = LinkedHashMap(ex)
            if (ua != null && !h.containsKey("User-Agent")) h["User-Agent"] = ua
            if (ref && origin.isNotEmpty()) {
                if (!h.containsKey("Referer")) h["Referer"] = "$origin/"
                if (!h.containsKey("Origin")) h["Origin"] = origin
            }
            return Target(url, h, name)
        }
        val l = ArrayList<Target>()
        if (ex.isNotEmpty()) l.add(mk("özəl", null, false))
        l.add(mk("VLC", "VLC/3.0.20 LibVLC/3.0.20", false))
        l.add(mk("standart", null, false))
        l.add(mk("okhttp", "okhttp/4.12.0", false))
        l.add(mk("Chrome", CHROME, true))
        val g = good[url]
        val gi = l.indexOfFirst { it.name == g }
        if (gi > 0) l.add(0, l.removeAt(gi))
        return l
    }

    /** Qarışıq protokollu (http↔https) yönləndirmələri də izləyir. */
    fun connect(t: Target, range: String?, timeout: Int): HttpURLConnection {
        var cur = t.url
        val cookies = LinkedHashMap<String, String>()   // yönləndirici linklər tez-tez Set-Cookie ilə token verir
        repeat(10) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.connectTimeout = timeout; c.readTimeout = timeout; c.instanceFollowRedirects = false
            for ((k, v) in t.headers) c.setRequestProperty(k, v)
            if (cookies.isNotEmpty() && !t.headers.containsKey("Cookie"))
                c.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { it.key + "=" + it.value })
            if (range != null) c.setRequestProperty("Range", range)
            val code = c.responseCode
            if (code in 300..399 && code != 304) {
                c.headerFields["Set-Cookie"]?.forEach { sc ->
                    val kv = sc.substringBefore(';'); val i = kv.indexOf('=')
                    if (i > 0) cookies[kv.substring(0, i).trim()] = kv.substring(i + 1).trim()
                }
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc == null) throw IOException("redirect without location")
                cur = URL(URL(cur), loc).toString()
            } else return c
        }
        throw IOException("too many redirects")
    }

    /** Eyni link bir neçə kanalda təkrarlanırsa və ya yoxlama təzəcə bitibsə, nəticə yenidən sorğulanmır. */
    private val cache = ConcurrentHashMap<String, Pair<Long, String>>()
    private val inflight = ConcurrentHashMap<String, java.util.concurrent.CompletableFuture<String>>()
    private const val CACHE_MS = 20_000L

    /** Player (Media3/VLC) nəticəsi dəyişəndə həmin linkin köhnə yoxlama nəticəsi atılır. */
    private fun dropCache(url: String) { cache.keys.removeAll { it.startsWith(url) } }

    /** Cihaz internetə qoşuludur? Oflayn halda uğursuzluq saxlanmır (əks halda bütün kanallar yalandan 🔴 qalardı). */
    fun online(ctx: android.content.Context): Boolean = try {
        val cm = ctx.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val nc = cm.getNetworkCapabilities(cm.activeNetwork)
        nc != null && nc.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (e: Exception) { true }

    /**
     * Heç bir profil 2xx qaytarmırsa (qoşulma xətası və ya hər hansı HTTP xətası) "dead", əks halda "ok".
     * verifyHls=true olduqda .m3u8 linklərinin məzmunu da yoxlanılır (#EXTM3U ilə başlamalıdır).
     * Sürət: nəticə 20 san keşlənir, eyni link eyni anda yalnız bir dəfə yoxlanılır.
     */
    fun probe(raw: String, hdrJson: String, verifyHls: Boolean = true): String {
        if (exoFailed.contains(raw)) return "dead"   // player-lər bu kanaldan xəta alıb
        if (isNoRetry(reasonOf(raw))) return "dead"  // əvvəlki yoxlamada 500/502 alıb → təkrar yoxlanmır
        val key = raw + "\u0000" + hdrJson + verifyHls
        val now = System.currentTimeMillis()
        cache[key]?.let { if (now - it.first < CACHE_MS) return it.second }
        var mine = false
        val f = inflight.computeIfAbsent(key) { mine = true; java.util.concurrent.CompletableFuture<String>() }
        if (!mine) return try { f.get(90, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Exception) { "unknown" }
        var r = "dead"
        try {
            r = probeRaw(raw, hdrJson, verifyHls)
            if (r == "ok") {   // yalnız uğurlu nəticə keşlənir: 🔴 hər dəfə təzədən, tam yoxlanır
                if (cache.size > 20000) cache.clear()
                cache[key] = Pair(System.currentTimeMillis(), r)
            }
        } catch (t: Throwable) { r = "unknown" } finally {
            f.complete(r); inflight.remove(key)
        }
        return r
    }

    /** Cihaz internetdədir? (MainActivity yoxlamadan əvvəl yeniləyir). Oflayn halda heç bir kanal 🔴 olmur. */
    @Volatile var deviceOnline = true

    private const val PROBE_TIMEOUT = 5000      // 1-ci mərhələ sürətlidir: cavab verməyən/xarab kanal sonda VLC ilə təsdiqlənir


    private fun readBody(c: HttpURLConnection, max: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val b = ByteArray(8192)
        c.inputStream.use { st ->
            while (out.size() < max) { val n = st.read(b, 0, minOf(b.size, max - out.size())); if (n < 0) break; out.write(b, 0, n) }
        }
        return out.toByteArray()
    }

    private fun resolve(base: String, ref: String): String = try { URL(URL(base), ref.trim()).toString() } catch (e: Exception) { ref.trim() }

    // ================================================================ DƏRİN HTTP YOXLAMASI
    // Əvvəl yalnız "cavab 200 gəldi, ilk baytlar HTML deyil" yoxlanırdı. İndi real media baytları da yoxlanır:
    //   HLS  : master → variant (2-yə qədər) → media manifest → şifrə açarı (16 bayt) → init seqmenti (fMP4) → ən yeni seqmentin baytları
    //   Axın : ≥ 8 KB real məlumat axmalı və TS / FLV / MP4 / MKV / MP3 / AAC / OGG … imzası uyğun gəlməlidir

    /** Cavabın ilk baytları: status, content-type, oxunan məlumat, axın bitdimi. */
    private class Head(val code: Int, val ct: String, val data: ByteArray, val eof: Boolean, val url: String = "")

    /** Hədəfdən ən çoxu [max] bayt oxuyur (Range ilə; server Range-i rədd edərsə Range-siz təkrar). [windowMs] bitəndə oxunan qədəri qaytarır. */
    private fun readHead(t: Target, max: Int, timeout: Int, windowMs: Long): Head {
        var rng: String? = "bytes=0-${max - 1}"
        var lastCode = 0
        repeat(2) {
            val c = connect(t, rng, timeout)
            try {
                val code = c.responseCode
                lastCode = code
                if (rng != null && (code == 416 || code == 400 || code == 405 || code == 501)) { rng = null; return@repeat }
                val ct = (c.contentType ?: "").lowercase()
                if (code !in 200..299) return Head(code, ct, ByteArray(0), false, c.url.toString())
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var eof = false
                val t0 = System.currentTimeMillis()
                try {
                    c.inputStream.use { st ->
                        while (out.size() < max) {
                            val n = st.read(buf, 0, minOf(buf.size, max - out.size()))
                            if (n < 0) { eof = true; break }
                            out.write(buf, 0, n)
                            if (System.currentTimeMillis() - t0 > windowMs) break
                        }
                    }
                } catch (e: IOException) { }   // axın yarıda kəsildi / dayandı → oxunan qədəri ilə qiymətləndirilir
                return Head(code, ct, out.toByteArray(), eof, c.url.toString())   // c.url = yönləndirmələrdən sonrakı SON ünvan
            } finally { try { c.disconnect() } catch (e: Exception) { } }
        }
        return Head(lastCode, "", ByteArray(0), false)
    }

    /** İlk baytlar mətn kimidir (HTML/JSON/manifest/xəta mesajı)? Media baytları belə olmur. */
    private fun isTextLike(d: ByteArray, n: Int): Boolean {
        val m = minOf(n, 512)
        if (m == 0) return true
        var p = 0
        for (i in 0 until m) { val v = d[i].toInt() and 0xFF; if (v == 9 || v == 10 || v == 13 || v in 32..126) p++ }
        return p * 100 / m >= 95
    }

    private fun junk(d: ByteArray, n: Int): Boolean =
        isTextLike(d, n) || (n >= 2 && d[0] == 0x1F.toByte() && d[1] == 0x8B.toByte())   // mətn və ya gzip (sıxılmış xəta səhifəsi)

    /** MPEG-TS: 188 baytlıq paketlərin hər birinin əvvəlində 0x47 — ən azı 2 ardıcıl sinxron bayt eyni addımda olmalıdır. */
    private fun tsAligned(d: ByteArray, n: Int): Boolean {
        val sync = 0x47.toByte()
        val lim = minOf(188, n - 189)
        for (o in 0..lim) {
            if (d[o] != sync) continue
            var k = 1; var good = true
            while (k <= 3 && o + k * 188 < n) { if (d[o + k * 188] != sync) { good = false; break }; k++ }
            if (good) return true
        }
        return false
    }

    private val MP4_BOXES = setOf("ftyp", "moov", "mdat", "styp", "moof", "free", "wide", "sidx", "skip")

    /** Tanınan media imzası: TS, FLV, MP4/fMP4, MKV/WebM, OGG, MP3/AAC(ADTS), ID3, RIFF, FLAC, MPEG-PS, ASF. */
    private fun knownMedia(d: ByteArray, n: Int): Boolean {
        if (n < 4) return false
        if (tsAligned(d, n)) return true
        fun b(i: Int) = d[i].toInt() and 0xFF
        val s = String(d, 0, minOf(n, 12), Charsets.ISO_8859_1)
        if (s.startsWith("FLV") || s.startsWith("OggS") || s.startsWith("ID3") || s.startsWith("RIFF") || s.startsWith("fLaC")) return true
        if (n >= 8 && s.substring(4, 8) in MP4_BOXES) return true
        if (b(0) == 0x1A && b(1) == 0x45 && b(2) == 0xDF && b(3) == 0xA3) return true
        if (b(0) == 0 && b(1) == 0 && b(2) == 1 && (b(3) == 0xBA || b(3) == 0xB3)) return true
        if (b(0) == 0x30 && b(1) == 0x26 && b(2) == 0xB2 && b(3) == 0x75) return true
        if (b(0) == 0xFF && (b(1) and 0xE0) == 0xE0) return true
        return false
    }

    private class Pl(val master: Boolean, val variants: List<String>, val segs: List<String>,
                     val mapUri: String?, val keyUri: String?, val encrypted: Boolean)

    private fun attrUri(line: String): String? {
        val i = line.indexOf("URI=\"")
        if (i < 0) return null
        val s = i + 5
        val e = line.indexOf('"', s)
        return if (e > s) line.substring(s, e) else null
    }

    private fun parsePlaylist(text: String): Pl {
        val variants = ArrayList<String>(); val media = ArrayList<String>(); val segs = ArrayList<String>()
        var master = false; var map: String? = null; var key: String? = null; var enc = false
        var wantVariant = false
        for (raw in text.lineSequence()) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#")) {
                when {
                    l.startsWith("#EXT-X-STREAM-INF") -> { master = true; wantVariant = true }
                    l.startsWith("#EXT-X-MEDIA:") -> { master = true; attrUri(l)?.let { media.add(it) } }
                    l.startsWith("#EXT-X-MAP:") -> { if (map == null) map = attrUri(l) }
                    l.startsWith("#EXT-X-KEY:") -> {
                        val m = Regex("METHOD=([A-Z0-9-]+)").find(l)?.groupValues?.get(1) ?: "NONE"
                        enc = m != "NONE"
                        key = if (m == "AES-128") attrUri(l) else null
                    }
                }
                continue
            }
            if (wantVariant) { variants.add(l); wantVariant = false } else if (!master) segs.add(l)
        }
        return Pl(master, if (variants.isNotEmpty()) variants else media, segs, map, key, enc)
    }

    private class Txt(val text: String, val url: String)

    private fun fetchText(t: Target, timeout: Int): Txt? {
        val c = connect(t, null, timeout)
        try {
            if (c.responseCode !in 200..299) { whyTl.set(Why.http(c.responseCode, "manifest: ")); return null }
            if ((c.contentType ?: "").lowercase().startsWith("text/html")) { whyTl.set(Why.R("manifest əvəzinə HTML səhifə gəlir", 2)); return null }
            val txt = String(readBody(c, 262144), Charsets.UTF_8).trimStart('\uFEFF', ' ', '\t', '\r', '\n')
            return Txt(txt, c.url.toString())
        } finally { try { c.disconnect() } catch (e: Exception) { } }
    }

    /** AES-128 açarı: tam 16 bayt gəlməlidir (HTML/boş cavab = yayım açılmaz). */
    private fun keyOk(t: Target, timeout: Int): Boolean {
        val h = readHead(t, 64, timeout, 2000)
        if (h.code !in 200..299) { whyTl.set(Why.http(h.code, "şifrə açarı: ")); return false }
        if (h.data.size != 16) { whyTl.set(Why.R("şifrə açarı düzgün deyil", 2)); return false }
        return true
    }

    /** fMP4 init seqmenti (#EXT-X-MAP): mətn olmayan real baytlar gəlməlidir. */
    private fun initOk(t: Target, timeout: Int): Boolean {
        val h = readHead(t, 4096, timeout, 2000)
        if (h.code !in 200..299) return no(Why.http(h.code, "init seqmenti: "))
        if (h.ct.startsWith("text/html")) return no(Why.R("init seqmenti əvəzinə HTML gəlir", 2))
        if (h.data.size < 8 || junk(h.data, h.data.size)) return no(Why.R("init seqmenti boş/düzgün deyil", 2))
        return true
    }

    /** Seqmentin real baytları: status 2xx, HTML/mətn deyil, tanınan media imzası (şifrəli seqmentdə yalnız real binar məlumat). */
    private fun segmentOk(t: Target, timeout: Int, enc: Boolean): Boolean {
        val h = readHead(t, 16384, timeout, 3000)
        if (h.code !in 200..299) return no(Why.http(h.code, "seqment: "))
        if (h.ct.startsWith("text/html")) return no(Why.R("seqment əvəzinə HTML gəlir", 2))
        val d = h.data; val n = d.size
        if (n < 16) return no(Why.R("seqment boşdur", 2))
        if (junk(d, n)) return no(Why.R("seqment əvəzinə mətn/xəta gəlir", 2))
        if (enc) return (n >= 1024 || h.eof) || no(Why.R("şifrəli seqment çox qısadır", 2))
        return knownMedia(d, n) || n >= 8192 || no(Why.R("seqment media formatında deyil", 2))
    }

    private fun deepHls(p: Target, timeout: Int): Boolean {
        val ok = try { hlsLevel(p, p.url, 0, timeout) } catch (e: Exception) { no(Why.ofThrowable(e)) }
        if (!ok && whyTl.get() == null) whyTl.set(Why.R("HLS seqmentləri açılmır", 2))
        return ok
    }

    private fun hlsLevel(p: Target, url0: String, depth: Int, timeout: Int): Boolean {
        if (depth > 2) return false
        val tx = fetchText(Target(url0, p.headers, p.name), timeout) ?: return false
        val text = tx.text
        val url = tx.url                                  // yönləndirmədən sonrakı son ünvan: nisbi linklər buna görə həll olunur
        if (!text.startsWith("#EXT")) return no(Why.R("manifest düzgün deyil (#EXTM3U yoxdur)", 2))
        val pl = parsePlaylist(text)
        if (pl.master) {
            // ilk variant ölüdürsə növbətisi də yoxlanır (ən çox 2)
            for (v in pl.variants.take(2)) {
                val ok = try { hlsLevel(p, resolve(url, v), depth + 1, timeout) } catch (e: Exception) { false }
                if (ok) return true
            }
            return false
        }
        if (pl.segs.isEmpty()) return no(Why.R("manifest boşdur (seqment yoxdur)", 2))          // boş manifest (restream stub)
        pl.keyUri?.let { if (!keyOk(Target(resolve(url, it), p.headers, p.name), timeout)) return false }
        pl.mapUri?.let { if (!initOk(Target(resolve(url, it), p.headers, p.name), timeout)) return false }
        // ən yeni seqment; hələ dərc olunmayıbsa bir əvvəlkisi
        val last = pl.segs.size - 1
        for (i in intArrayOf(last, last - 1)) {
            if (i < 0) continue
            if (segmentOk(Target(resolve(url, pl.segs[i]), p.headers, p.name), timeout, pl.encrypted)) return true
        }
        return false
    }

    /**
     * .ts üçün sərt yoxlama: 188 baytlıq paketlərin ≥ 97%-i 0x47 ilə başlamalı, ən azı 8 paket olmalı və
     * ya PAT (PID 0), ya da audio/video PES başlanğıcı (00 00 01) görünməlidir.
     */
    private fun tsStrong(d: ByteArray, n: Int): Boolean {
        val sync = 0x47.toByte()
        var off = -1
        for (o in 0..minOf(187, n - 189)) {
            if (d[o] == sync && d[o + 188] == sync && (o + 376 >= n || d[o + 376] == sync)) { off = o; break }
        }
        if (off < 0) return false
        var pk = 0; var bad = 0; var pat = false; var pes = false
        var i = off
        while (i + 188 <= n) {
            pk++
            if (d[i] != sync) bad++
            else {
                val pid = ((d[i + 1].toInt() and 0x1F) shl 8) or (d[i + 2].toInt() and 0xFF)
                val pusi = (d[i + 1].toInt() and 0x40) != 0
                if (pid == 0) pat = true
                if (pusi && pid != 0 && pid != 0x1FFF) {
                    val afc = (d[i + 3].toInt() shr 4) and 3
                    var pl = i + 4
                    if ((afc and 2) != 0) pl += 1 + (d[i + 4].toInt() and 0xFF)
                    if ((afc and 1) != 0 && pl + 3 < i + 188 && d[pl] == 0.toByte() && d[pl + 1] == 0.toByte() && d[pl + 2] == 1.toByte()) pes = true
                }
            }
            i += 188
        }
        return pk >= 8 && bad * 100 / pk <= 3 && (pat || pes)
    }

    // ---------------------------------------------------------------- DASH (.mpd)
    private fun attr(tag: String, name: String): String? =
        Regex("(?:^|\\s)" + name + "=\"([^\"]*)\"").find(tag)?.groupValues?.get(1)

    private fun pad(v: Long, w: String): String = if (w.isEmpty()) v.toString() else v.toString().padStart(w.toInt(), '0')

    private fun tmpl(s: String, id: String, bw: String, num: Long, time: Long): String =
        Regex("\\$(RepresentationID|Number|Bandwidth|Time)(?:%0(\\d+)d)?\\$").replace(s) { m ->
            when (m.groupValues[1]) {
                "RepresentationID" -> id
                "Bandwidth" -> bw
                "Number" -> pad(num, m.groupValues[2])
                else -> pad(time, m.groupValues[2])
            }
        }

    private fun deepMpd(p: Target, timeout: Int): Boolean {
        val ok = try { mpdCheck(p, timeout) } catch (e: Exception) { no(Why.ofThrowable(e)) }
        if (!ok && whyTl.get() == null) whyTl.set(Why.R("DASH manifest/seqmentləri açılmır", 2))
        return ok
    }

    /**
     * DASH manifestini dərin yoxlayır: <MPD/<Period olmalı; ilk Representation üçün init seqmenti (və statik MPD-də ilk media seqmenti)
     * real media baytları verməlidir. Seqmenti müəyyən etmək mümkün olmazsa (mürəkkəb quruluş) 🟢 verilmir — qərarı Media3 verir.
     */
    private fun mpdCheck(p: Target, timeout: Int): Boolean {
        val tx = fetchText(p, timeout) ?: return false
        val text = tx.text
        if (!text.contains("<MPD") || !text.contains("<Period")) return false
        val baseTag = Regex("<BaseURL[^>]*>([^<]+)</BaseURL>").find(text)?.groupValues?.get(1)?.trim()
        val base = if (baseTag != null) resolve(tx.url, baseTag) else tx.url
        val dynamic = text.contains("type=\"dynamic\"")
        val rep = Regex("<Representation\\b[^>]*>").find(text)?.value ?: ""
        val id = attr(rep, "id") ?: ""
        val bw = attr(rep, "bandwidth") ?: ""
        fun seg(u: String) = segmentOk(Target(resolve(base, u), p.headers, p.name), timeout, false)

        val stm = Regex("<SegmentTemplate\\b[^>]*>").find(text)
        if (stm != null) {
            val tag = stm.value
            val init = attr(tag, "initialization")
            val media = attr(tag, "media")
            val start = attr(tag, "startNumber")?.toLongOrNull() ?: 1L
            val t0 = Regex("<S\\b[^>]*\\bt=\"(\\d+)\"").find(text, stm.range.last)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            if (init != null) {
                if (!seg(tmpl(init, id, bw, start, t0))) return false
                if (dynamic || media == null) return true          // canlı MPD: ilk nömrə köhnələ bilər → init kifayətdir
                return seg(tmpl(media, id, bw, start, t0))
            }
            if (media != null) return seg(tmpl(media, id, bw, start, t0))
            return false
        }
        if (text.contains("<SegmentList")) {
            val init = Regex("<Initialization\\b[^>]*>").find(text)?.value?.let { attr(it, "sourceURL") }
            val first = Regex("<SegmentURL\\b[^>]*>").find(text)?.value?.let { attr(it, "media") }
            if (init != null && !seg(init)) return false
            return if (first != null) seg(first) else init != null
        }
        if (baseTag != null && text.contains("<SegmentBase")) return segmentOk(Target(base, p.headers, p.name), timeout, false)
        return false
    }

    /** HLS olmayan axın: ≥ 8 KB real məlumat axmalı (donmuş/yarımçıq axın 🔴), imza media ilə uyğun olmalıdır. */
    private fun streamCheck(p: Target, timeout: Int, ext: String): String {
        val tsExt = ext == "ts"
        val h = readHead(p, if (tsExt) 65536 else 49152, timeout, if (tsExt) 5000 else 4000)
        if (h.code == 404 || h.code == 410) { whyTl.set(Why.http(h.code)); return "gone" }
        if (h.code !in 200..299) return dead(Why.http(h.code))
        if (h.ct.startsWith("text/html")) return dead(Why.HTML)
        val d = h.data; val n = d.size
        if (n < 8192 && !(h.eof && n >= 1024)) return dead(Why.R("yayım axmır (çox az məlumat gəlir)", 2))   // axın dayandı / çox az məlumat
        if (junk(d, n)) return dead(Why.R("yayım əvəzinə mətn/xəta səhifəsi gəlir", 2))
        if (tsAligned(d, n)) return if (tsStrong(d, n)) "ok" else dead(Why.R("TS paketləri pozuqdur", 2))   // MPEG-TS: sərt paket/PAT/PES yoxlaması
        if (tsExt && !knownMedia(d, n)) return dead(Why.R("fayl media formatında deyil (.ts)", 2))          // .ts adı var, amma nə TS, nə tanınan media
        return if (knownMedia(d, n) || n >= 8192) "ok" else dead(Why.R("tanınmayan media formatı", 2))
    }

    /** Bir profil üçün nəticə: "ok" | "dead" (server cavab verdi, yayım yoxdur) | "gone" (404/410) | "err" (şəbəkə xətası / vaxt aşımı). */
    private fun extOf(url: String): String = try {
        (Uri.parse(url).path ?: "").lowercase().substringAfterLast('/').let { if (it.contains('.')) it.substringAfterLast('.') else "" }
    } catch (e: Exception) { "" }

    /** Yönləndirici linklər üçün: SON ünvana və məzmuna görə növ — 0 avto/TS/progressiv, 1 HLS, 2 DASH. */
    fun sniffKind(t: Target): Int {
        val h = readHead(t, 2048, 4000, 2500)
        if (h.code !in 200..299) return 0
        if (h.data.isNotEmpty()) {
            val txt = String(h.data, 0, h.data.size, Charsets.UTF_8).trimStart('\uFEFF', ' ', '\t', '\r', '\n')
            return if (txt.startsWith("#EXT")) 1 else if (txt.contains("<MPD")) 2 else 0
        }
        return when (extOf(if (h.url.isNotEmpty()) h.url else t.url)) { "m3u8", "m3u" -> 1; "mpd" -> 2; else -> 0 }
    }

    private fun tryOne(p0: Target, hls: Boolean, ext0: String, timeout: Int): String {
        val h = readHead(p0, 1024, timeout, 2500)
        if (h.code == 404 || h.code == 410) { whyTl.set(Why.http(h.code)); return "gone" }
        if (h.code !in 200..299) return dead(Why.http(h.code))
        if (h.ct.startsWith("text/html")) return dead(Why.HTML)            // HTML xəta/giriş səhifəsi yayım deyil
        val n = h.data.size
        if (n == 0) return dead(Why.EMPTY)                                   // 200, amma boş cavab
        // Yönləndirici link (məs. .../136.ts → başqa server/ünvan): sonrakı yoxlamalar SON ünvana və son uzantıya görə aparılır
        val fin = if (h.url.isNotEmpty()) h.url else p0.url
        val p = if (fin != p0.url) Target(fin, p0.headers, p0.name) else p0
        val fe = extOf(fin)
        val ext = if (fe.isNotEmpty()) fe else ext0
        val head = String(h.data, 0, minOf(n, 64), Charsets.UTF_8).trimStart('\uFEFF', ' ', '\t', '\r', '\n')
        if (head.startsWith("<")) {                                 // HTML / XML: yalnız DASH manifesti (.mpd) yayım ola bilər
            val txt = String(h.data, 0, n, Charsets.UTF_8)
            if (ext == "mpd" || txt.contains("<MPD")) return if (deepMpd(p, timeout)) "ok" else "dead"
            return dead(Why.R("yayım əvəzinə HTML/XML səhifə gəlir", 2))
        }
        if (head.startsWith("#EXT")) return if (deepHls(p, timeout)) "ok" else "dead"   // HLS: manifest → seqment baytları
        if (hls && ext == "m3u8") return dead(Why.R("manifest düzgün deyil (#EXTM3U yoxdur)", 2))                    // .m3u8 deyilsə manifest deyil
        if (h.ct.contains("mpegurl")) return dead(Why.R("manifest elan olunur, amma #EXT yoxdur", 2))                 // manifest elan edir, amma #EXT yoxdur
        return streamCheck(p, timeout, ext)
    }

    private fun probeRaw(raw: String, hdrJson: String, verifyHls: Boolean): String {
        val path = try { Uri.parse(raw.split("|", limit = 2)[0].trim()).path?.lowercase() ?: "" } catch (e: Exception) { "" }
        val hls = verifyHls && path.endsWith(".m3u8")
        val ext = path.substringAfterLast('.', "")
        // Dəqiqlik: BÜTÜN profillər sınanır (VLC, standart, okhttp, Chrome+Referer). 🔴 yalnız hamısı uğursuz olanda verilir.
        val all = profiles(raw, hdrJson)
        // sürət: 1-ci mərhələdə 2 profil (ilk + Chrome+Referer); 🔴 qalanlar sonda Media3 ilə BÜTÜN profillərlə təsdiqlənir
        val ps = if (all.size <= 2) all else listOf(all[0], all.last())
        var gone = 0
        var sawServer = false
        var best: Why.R? = null
        reasons.remove(raw)                      // yeni yoxlama: köhnə səbəb atılır
        for (p in ps) {
            whyTl.set(null)
            var res = try { tryOne(p, hls, ext, PROBE_TIMEOUT) } catch (e: Exception) { whyTl.set(Why.ofThrowable(e)); "err" }
            when (res) {
                "ok" -> { markGood(p.url, p.name); reasons.remove(raw); return "ok" }
                "gone" -> { sawServer = true; gone++ }                   // bəzi serverlər yanlış UA-ya 404 verir → yalnız 2 profil də 404 deyəndə bitir
                "dead" -> sawServer = true
            }
            val w = whyTl.get()
            if (w != null && isNoRetry(w.text)) { setReason(raw, w); return "dead" }   // 500/502: digər profillər sınanmır
            if (w != null && (best == null || w.rank > best.rank)) best = w   // ən konkret səbəb (eyni rankda ilk profilinki)
            if (gone >= 2 && gone == ps.indexOf(p) + 1) { best?.let { setReason(raw, it) }; return "dead" }
        }
        // Heç bir profil yayım almadı. Cihaz oflayndırsa 🔴 verilmir ("bilinmir" 🟡, sonra yenidən yoxlanır); onlayndırsa 🔴.
        if (sawServer || deviceOnline) { best?.let { setReason(raw, it) }; return "dead" }
        return "unknown"
    }
}
