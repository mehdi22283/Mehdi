package az.m3u.sinayici

import androidx.media3.common.PlaybackException
import androidx.media3.datasource.HttpDataSource
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

/**
 * Kanalın NİYƏ açılmadığını qısa Azərbaycan dilində izah edir (kanal adının yanında qırmızı mötərizədə göstərilir).
 * rank: 3 = konkret səbəb (HTTP kodu, DNS, SSL, qoşulma rədd), 2 = məzmun səbəbi (HTML, boş, format), 1 = ümumi (vaxt aşımı, yayım gəlmir).
 * Bir kanal üçün bir neçə səbəb toplananda ən yüksək rank saxlanılır.
 */
object Why {
    class R(val text: String, val rank: Int)

    val NO_STREAM = R("yayım gəlmir (bufer dolmadı)", 1)
    val HTML = R("yayım əvəzinə HTML səhifə gəlir", 2)
    val EMPTY = R("boş cavab gəlir", 2)

    fun http(code: Int, pre: String = ""): R {
        if (code <= 0) return R(pre + "server cavab vermədi", 1)
        val t = when (code) {
            400 -> "HTTP 400 – yanlış sorğu"
            401 -> "HTTP 401 – giriş tələb olunur"
            403 -> "HTTP 403 – icazə yoxdur"
            404 -> "HTTP 404 – link tapılmadı"
            405 -> "HTTP 405 – metod qadağandır"
            406 -> "HTTP 406 – qəbul edilmir"
            410 -> "HTTP 410 – link silinib"
            429 -> "HTTP 429 – çox sorğu"
            451 -> "HTTP 451 – hüquqi səbəbdən bağlıdır"
            in 500..599 -> "HTTP $code – server xətası"
            else -> "HTTP $code"
        }
        return R(pre + t, 3)
    }

    /** Xəta zəncirini gəzib ən konkret səbəbi tapır. */
    fun ofThrowable(e: Throwable?): R {
        var c: Throwable? = e
        var depth = 0
        while (c != null && depth < 8) {
            when {
                c is HttpDataSource.InvalidResponseCodeException -> return http(c.responseCode)
                c is UnknownHostException -> return R("domen tapılmadı (DNS)", 3)
                c is SocketTimeoutException -> return R("cavab vermir (vaxt aşımı)", 1)
                c is ConnectException -> return R("server qoşulmanı rədd edir", 3)
                c is NoRouteToHostException -> return R("serverə yol yoxdur", 3)
                c is SSLException -> return R("SSL/sertifikat xətası", 3)
                c is SocketException -> return R("bağlantı kəsildi", 1)
            }
            val m = c.message ?: ""
            if (m.contains("too many redirects")) return R("sonsuz yönləndirmə", 2)
            if (m.contains("redirect without location")) return R("yönləndirmə xətalıdır", 2)
            c = c.cause
            depth++
        }
        return R("şəbəkə xətası", 1)
    }

    /** Media3 (ExoPlayer) xətasını səbəbə çevirir. */
    fun fromPlayback(e: PlaybackException): R {
        val chain = ofThrowable(e.cause)
        return when (e.errorCode) {
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> if (chain.rank >= 3) chain else R("HTTP xətası", 3)
            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> R("fayl tapılmadı", 3)
            PlaybackException.ERROR_CODE_IO_NO_PERMISSION -> R("icazə yoxdur", 3)
            PlaybackException.ERROR_CODE_IO_CLEARTEXT_NOT_PERMITTED -> R("şifrəsiz (http) bağlantı bloklanıb", 3)
            PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE -> R("server yanlış məzmun növü qaytarır", 2)
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED -> if (chain.rank >= 2) chain else R("serverə qoşulmaq alınmır", 2)
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
            PlaybackException.ERROR_CODE_TIMEOUT -> R("cavab vermir (vaxt aşımı)", 1)
            PlaybackException.ERROR_CODE_IO_UNSPECIFIED -> if (chain.rank >= 3) chain else R("yayım gəlmir (IO xətası)", 1)
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED -> R("yayım formatı pozuqdur", 2)
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED -> R("yayım formatı dəstəklənmir", 2)
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED -> R("kodek açılmadı", 2)
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> R("video kodeki dəstəklənmir", 2)
            PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED -> R("audio açılmadı", 1)
            PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW -> R("canlı yayım geridə qaldı", 1)
            else -> R(e.errorCodeName, 1)
        }
    }
}
