# Lokal Zəng Yazıcı (Android)

Android Studio/Gradle layihəsi. GitHub Actions `app-debug.apk` faylını avtomatik build edib artifact kimi saxlayır.

## Daxil olanlar

- Telefon zəngi aktiv olanda mikrofon yazısını başlatmaq, zəng bitəndə faylı bağlamaq üçün foreground service.
- Xidmət işləyərkən dayanmayan bildiriş; yazma başlayanda və bitəndə ayrıca bildiriş.
- Gələn, gedən və bütün telefon zənglərinə aid filtr.
- WhatsApp-ın davam edən zəng bildirişini mətndən təxmin edən (heuristik) notification listener.
- IP və port (`5555` standart) üçün TCP əlaqə yoxlaması.
- Yazıların siyahısı və Android telefon zəng jurnalının göstərilməsi.

## Mühüm texniki sərhədlər

**Bu, tam ADB klienti deyil.** IP/port düyməsi TCP portunun əlçatan olub-olmadığını yoxlayır. O, ADB AUTH protokolunu icra etmir, shell açmır və özbaşına ADB səlahiyyəti əldə etmir. Android-də adətən 5555 portu USB ADB ilə `adb tcpip 5555` əmri işlədildikdən sonra, yaxud cihazın Wireless debugging funksiyası ilə açılır. Öz tətbiqinə ADB icazəsi vermək standart Android tətbiqi üçün adi TCP socket ilə mümkün deyil.

**Zəng audiosu zəmanətli deyil.** Bu layihə `MediaRecorder.AudioSource.MIC` ilə mikrofon girişini yazır; `VOICE_CALL`, `VOICE_UPLINK`, `VOICE_DOWNLINK` və ya `CAPTURE_AUDIO_OUTPUT` imtiyazlarını istifadə etmir. Müasir Android versiyalarında adi üçüncü tərəf tətbiqləri mobil zəngin daxili audiosunu etibarlı şəkildə oxuya bilmir; aktiv zəng zamanı mikrofon girişinin səssizləşdirilməsi də mümkündür. ADB IP:port bağlantısı bu məhdudiyyəti aradan qaldırmır. Fayl yaransa belə, qarşı tərəfin səsi və ya hər iki tərəf eşidilməyə bilər. Tam ikitərəfli audio üçün model/firmware dəstəyi, sistem/privileged tətbiq, uyğun xüsusi ROM və ya root kimi ayrıca cihaz səviyyəli şərtlər tələb oluna bilər.

WhatsApp aşkarlanması bildiriş mətninə bağlıdır və bütün WhatsApp versiyalarında/dillərində işləməsinə zəmanət verilmir. WhatsApp çağırışları sistem telefon zəng jurnalında görünməyə bilər. WhatsApp üçün “gələn/gedən” filtri etibarlı istiqamət olmadığına görə yalnız “Bütün zənglər” filtrində işlədilir.

## GitHub-da APK build etmək

1. Bu ZIP-i açın və içindəki `LocalCallRecorder` qovluğunun məzmununu yeni GitHub repository-yə yükləyin (root-da `settings.gradle.kts`, `build.gradle.kts`, `app/` və `.github/` görünməlidir).
2. Repository-də **Actions** bölməsini açın. `Build Android APK` workflow-u push zamanı avtomatik başlayır; **Run workflow** ilə də başladmaq olar.
3. Build uğurlu olduqda workflow run səhifəsinin **Artifacts** hissəsindən `lokal-zeng-yazici-debug-apk` faylını endirin. İçində `app-debug.apk` var.
4. APK test üçündür və debug imzası ilə build olunur. Quraşdırarkən Android xəbərdarlıq verə bilər; yalnız öz build etdiyiniz, mənbəyinə güvəndiyiniz APK-nı quraşdırın.

## Telefonda istifadə

1. APK-nı quraşdırın və açın.
2. **Xidməti başlat** düyməsini basıb mikrofon, telefon vəziyyəti və bildiriş icazələrini verin. Zəng siyahısı üçün Call log icazəsi də istənir.
3. WhatsApp üçün **WhatsApp müşahidəsini aktiv et** düyməsini basıb sistem ayarlarında bu tətbiqə bildiriş girişini verin.
4. Android-də batareya optimizasiyası xidməti dayandırırsa, tətbiq üçün batareya məhdudiyyətlərini istehsalçının ayarlarından uyğunlaşdırın.
5. Yazılar `Android/data/az.local.callrecorder/files/Music/Recordings/` qovluğunda, tətbiqin şəxsi yaddaşında saxlanır. Android versiyasından asılı olaraq fayllara fayl menecerindən baxmaq məhdud ola bilər.

## Hüquq və məxfilik

Zəng yazmazdan əvvəl yerli qanunları və danışıq iştirakçılarının razılığını nəzərə alın. Tətbiq audionu buluda göndərmir; yazılar cihazda saxlanır.
