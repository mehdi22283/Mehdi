package com.zengyazici;

import android.media.AudioFormat;
import android.media.AudioRecord;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * ADB shell (uid 2000) icazələri ilə app_process vasitəsilə işə salınır:
 * CLASSPATH=<apk> app_process /system/bin com.zengyazici.Rec <port> <planlar>
 * planlar: "4;3+2;3+1;1" — ";" ilə ayrılmış planlar, "+" ilə eyni anda yazılan mənbələr (qarışdırılır).
 * Hər plan sınanır; ilk 1.2 saniyədə tam sıfır (səssiz) gələn plan rədd edilir.
 * Audio 16 kHz mono PCM kimi tətbiqin loopback soketinə göndərilir.
 */
public class Rec {
    static final int RATE = 16000, CH = AudioFormat.CHANNEL_IN_MONO, ENC = AudioFormat.ENCODING_PCM_16BIT;
    static final int CHUNK = 1600;

    static void err(String s) { System.err.println(s); }

    static AudioRecord open(int src) {
        try {
            int min = AudioRecord.getMinBufferSize(RATE, CH, ENC);
            int size = Math.max(min, RATE) * 4;
            AudioRecord r = new AudioRecord(src, RATE, CH, ENC, size);
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                err("Menbe " + src + ": INITIALIZED deyil"); r.release(); return null;
            }
            r.startRecording();
            if (r.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                err("Menbe " + src + ": baslamadi"); r.release(); return null;
            }
            return r;
        } catch (Throwable e) {
            err("Menbe " + src + ": " + e);
            return null;
        }
    }

    static List<AudioRecord> openPlan(String plan) {
        List<AudioRecord> l = new ArrayList<>();
        for (String x : plan.split("\\+")) {
            AudioRecord r = null;
            try { r = open(Integer.parseInt(x.trim())); } catch (Throwable e) { err("plan " + plan + ": " + e); }
            if (r == null) { release(l); return null; }
            l.add(r);
        }
        return l;
    }

    static void release(List<AudioRecord> l) {
        for (AudioRecord r : l) { try { r.stop(); } catch (Throwable e) { } try { r.release(); } catch (Throwable e) { } }
    }

    static boolean readFully(AudioRecord r, short[] b) {
        int off = 0;
        while (off < b.length) {
            int k = r.read(b, off, b.length - off);
            if (k < 0) return false;
            off += k;
        }
        return true;
    }

    /** Bir hissə oxuyub qarışdırır; peak[0]-a maksimum amplitudu yazır. */
    static boolean chunk(List<AudioRecord> recs, short[] out, int[] peak) {
        short[] tmp = new short[out.length];
        int[] sum = new int[out.length];
        for (AudioRecord r : recs) {
            if (!readFully(r, tmp)) return false;
            for (int i = 0; i < tmp.length; i++) {
                sum[i] += tmp[i];
                int ab = Math.abs((int) tmp[i]);
                if (ab > peak[0]) peak[0] = ab;
            }
        }
        for (int i = 0; i < out.length; i++) out[i] = (short) Math.max(-32768, Math.min(32767, sum[i]));
        return true;
    }

    static void write(OutputStream o, short[] s) throws Exception {
        byte[] b = new byte[s.length * 2];
        for (int i = 0; i < s.length; i++) { b[2 * i] = (byte) (s[i] & 0xff); b[2 * i + 1] = (byte) ((s[i] >> 8) & 0xff); }
        o.write(b);
    }

    public static void main(String[] a) {
        try {
            int port = Integer.parseInt(a[0]);
            String[] plans = a[1].split(";");
            List<AudioRecord> chosen = null;
            int chosenIdx = -1;
            ByteArrayOutputStream probe = new ByteArrayOutputStream();
            int fallbackIdx = -1;

            for (int pi = 0; pi < plans.length && chosen == null; pi++) {
                List<AudioRecord> l = openPlan(plans[pi]);
                if (l == null) { err("Plan " + plans[pi] + ": acilmadi"); continue; }
                if (fallbackIdx < 0) fallbackIdx = pi;
                int[] peak = {0};
                short[] buf = new short[CHUNK];
                ByteArrayOutputStream pr = new ByteArrayOutputStream();
                boolean ok = true;
                for (int k = 0; k < 12 && ok; k++) {
                    ok = chunk(l, buf, peak);
                    if (ok) write(pr, buf);
                }
                err("Plan " + plans[pi] + ": peak=" + peak[0]);
                if (ok && peak[0] > 2) {
                    chosen = l; chosenIdx = pi; probe = pr;
                } else {
                    release(l);
                }
            }

            if (chosen == null && fallbackIdx >= 0) {
                err("Butun planlar sessizdir; " + plans[fallbackIdx] + " ile davam edilir");
                chosen = openPlan(plans[fallbackIdx]);
                chosenIdx = fallbackIdx;
            }
            if (chosen == null) {
                err("Hec bir audio menbeyi acilmadi");
                System.exit(2);
            }
            err("Secilen plan: " + plans[chosenIdx]);

            Socket sock = new Socket("127.0.0.1", port);
            OutputStream o = sock.getOutputStream();
            o.write(chosenIdx);
            o.write(probe.toByteArray());
            short[] buf = new short[CHUNK];
            int[] peak = {0};
            while (true) {
                if (!chunk(chosen, buf, peak)) break;
                write(o, buf);
            }
        } catch (Throwable e) {
            err("Rec: " + e);
            System.exit(1);
        }
        System.exit(0);
    }
}
