package az.zengyazici

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput

class PairReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val code = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(AdbAuto.KEY_CODE)?.toString() ?: return
        val app = context.applicationContext
        Thread { AdbAuto.pairAndFinish(app, code) }.start()
    }
}
