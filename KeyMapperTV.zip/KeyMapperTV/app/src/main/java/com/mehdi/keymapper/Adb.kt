package com.mehdi.keymapper

import android.content.Context
import android.provider.Settings
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object Adb {
    /** TV-də şəbəkə ADB portu həmişə 5555-dir. */
    const val PORT = 5555

    private const val INJ_PORT = 34567
    private const val INJ_VER = 1
    private const val INJ_LOG = "/data/local/tmp/km_injector.log"

    enum class State { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

    @Volatile
    var state: State = State.DISCONNECTED

    @Volatile
    var error: String? = null

    @Volatile
    var usedHost: String = ""

    /** true = düymələr daimi injector prosesi ilə göndərilir (çox aşağı gecikmə) */
    @Volatile
    var fast: Boolean = false

    @Volatile
    var fastError: String? = null

    val listeners = CopyOnWriteArrayList<Runnable>()

    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val inj: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile
    private var dadb: Dadb? = null

    @Volatile
    private var sock: Socket? = null

    @Volatile
    private var out: OutputStream? = null

    private var ctx: Context? = null

    fun init(c: Context) {
        ctx = c.applicationContext
    }

    private fun notifyChange() {
        for (l in listeners) {
            try {
                l.run()
            } catch (e: Exception) {
            }
        }
    }

    private fun setState(s: State, e: String?) {
        state = s
        error = e
        notifyChange()
    }

    fun connect(force: Boolean = false) {
        if (!force && (state == State.CONNECTING || state == State.CONNECTED)) return
        io.execute(Runnable { doConnect() })
    }

    private fun closeSocket() {
        try {
            out?.close()
        } catch (e: Exception) {
        }
        try {
            sock?.close()
        } catch (e: Exception) {
        }
        out = null
        sock = null
    }

    private fun doConnect(): Boolean {
        val c = ctx ?: return false
        setState(State.CONNECTING, null)
        fast = false
        closeSocket()
        try {
            dadb?.close()
        } catch (e: Exception) {
        }
        dadb = null

        val hosts = LinkedHashSet<String>()
        hosts.add(Store.host)
        hosts.add("127.0.0.1")
        var last: String? = null
        for (h in hosts) {
            try {
                val priv = File(c.filesDir, "adbkey")
                val pub = File(c.filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val d = Dadb.create(h, PORT, AdbKeyPair.read(priv, pub))
                val r = d.shell("echo ok")
                if (!r.output.contains("ok")) throw RuntimeException("cavab yoxdur")
                dadb = d
                usedHost = h
                setState(State.CONNECTED, null)
                startInjector()
                afterConnect()
                return true
            } catch (e: Throwable) {
                last = e.message ?: e.javaClass.simpleName
            }
        }
        setState(State.ERROR, last)
        return false
    }

    private fun exec(cmd: String): String {
        val d = dadb ?: throw IllegalStateException("ADB qoşulmayıb")
        return d.shell(cmd).output
    }

    // ---------------- Sürətli düymə göndərici ----------------

    private fun tryAttach(): Boolean {
        val sk = Socket()
        try {
            sk.tcpNoDelay = true
            sk.connect(InetSocketAddress("127.0.0.1", INJ_PORT), 300)
            sk.soTimeout = 1500
            val o = sk.getOutputStream()
            o.write((Store.token + "\n").toByteArray())
            o.flush()
            val line = BufferedReader(InputStreamReader(sk.getInputStream())).readLine()
            if (line == "OK " + INJ_VER) {
                sk.soTimeout = 0
                sock = sk
                out = o
                return true
            }
            sk.close()
        } catch (e: Throwable) {
            try {
                sk.close()
            } catch (e2: Throwable) {
            }
        }
        return false
    }

    private fun startInjector() {
        fast = false
        fastError = null
        closeSocket()
        try {
            if (!tryAttach()) {
                try {
                    exec("pkill -f 'com.mehdi.keymapper.Injecto[r]'")
                } catch (e: Throwable) {
                }
                val apk = ctx!!.applicationInfo.sourceDir
                exec(
                    "CLASSPATH=" + apk + " nohup app_process /system/bin com.mehdi.keymapper.Injector " +
                        INJ_PORT + " " + Store.token + " >" + INJ_LOG + " 2>&1 </dev/null &"
                )
                var ok = false
                var i = 0
                while (i < 25 && !ok) {
                    Thread.sleep(200)
                    ok = tryAttach()
                    i++
                }
                if (!ok) {
                    fastError = exec("head -c 300 " + INJ_LOG).trim()
                }
            }
        } catch (e: Throwable) {
            fastError = e.message
        }
        fast = out != null
        notifyChange()
    }

    fun keyDown(code: Int, repeat: Int) {
        send("D " + code + " " + repeat)
    }

    fun keyUp(code: Int) {
        send("U " + code)
    }

    fun tap(code: Int) {
        send("T " + code)
    }

    private fun send(line: String) {
        inj.execute(Runnable {
            val o = out
            if (fast && o != null) {
                try {
                    o.write((line + "\n").toByteArray())
                    o.flush()
                    return@Runnable
                } catch (e: Throwable) {
                    fast = false
                    closeSocket()
                    notifyChange()
                    io.execute(Runnable {
                        if (state == State.CONNECTED) startInjector()
                    })
                }
            }
            // ehtiyat rejim (yavaş): input keyevent
            val p = line.split(" ")
            val isFirstDown = p[0] == "D" && (p.size < 3 || p[2] == "0")
            if (p[0] == "T" || isFirstDown) {
                shell("input keyevent " + p[1])
            }
        })
    }

    // ---------------- Ümumi ADB əmrləri ----------------

    fun shell(cmd: String) {
        io.execute(Runnable {
            try {
                if (dadb == null && !doConnect()) return@Runnable
                try {
                    exec(cmd)
                } catch (e: Throwable) {
                    if (!doConnect()) return@Runnable
                    exec(cmd)
                }
            } catch (e: Throwable) {
                setState(State.ERROR, e.message ?: e.javaClass.simpleName)
            }
        })
    }

    fun ping() {
        if (state != State.CONNECTED) return
        io.execute(Runnable {
            try {
                exec("echo ok")
            } catch (e: Throwable) {
                doConnect()
            }
        })
    }

    /** Əlçatımlılıq servisini ayarlara girmədən ADB ilə aktiv edir. */
    private fun enableAccessibility() {
        val pkg = ctx!!.packageName
        val cn = pkg + "/" + pkg + ".KeyMapperService"
        val cur = exec("settings get secure enabled_accessibility_services").trim()
        if (!cur.contains(pkg + "/")) {
            val v = if (cur.isEmpty() || cur == "null") cn else cur + ":" + cn
            exec("settings put secure enabled_accessibility_services " + v)
        }
        exec("settings put secure accessibility_enabled 1")
    }

    fun enableAccessibilityAsync() {
        io.execute(Runnable {
            try {
                if (dadb == null && !doConnect()) return@Runnable
                enableAccessibility()
            } catch (e: Throwable) {
                setState(State.ERROR, e.message ?: e.javaClass.simpleName)
            }
        })
    }

    private fun afterConnect() {
        try {
            val c = ctx!!
            val pkg = c.packageName
            val on = Settings.Secure.getString(
                c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            if (!on.contains(pkg + "/") || !KeyMapperService.running) enableAccessibility()
            exec("dumpsys deviceidle whitelist +" + pkg)
            exec("cmd appops set " + pkg + " RUN_IN_BACKGROUND allow")
            exec("cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND allow")
        } catch (e: Throwable) {
        }
    }
}
