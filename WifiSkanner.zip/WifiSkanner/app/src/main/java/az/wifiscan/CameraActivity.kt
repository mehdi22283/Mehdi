package az.wifiscan

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource

/** RTSP (port 554) canlı video. Yalnız öz/icazəli kameralarınız üçün istifadə edin. */
class CameraActivity : Activity() {
    private var player: ExoPlayer? = null
    private var full = false
    private lateinit var form: View
    private lateinit var videoBox: FrameLayout
    private lateinit var status: TextView
    private lateinit var surface: SurfaceView
    private lateinit var u: Ui

    private fun videoHeight(): Int {
        val dm = resources.displayMetrics
        return minOf(dm.widthPixels, dm.heightPixels) * 9 / 16
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        u = Ui(this)
        window.statusBarColor = u.BG; window.navigationBarColor = u.BG
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val ip0 = intent.getStringExtra("ip") ?: ""
        val vendor = (intent.getStringExtra("vendor") ?: "").lowercase()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(u.BG); setPadding(0, u.dp(24), 0, 0) }
        videoBox = FrameLayout(this).apply { setBackgroundColor(0xFF111111.toInt()) }
        surface = SurfaceView(this)
        videoBox.addView(surface, FrameLayout.LayoutParams(-1, -1))
        status = u.tv("Hazırdır", 13f, u.ACC, true).apply { setPadding(u.dp(10), u.dp(6), u.dp(10), u.dp(6)); setBackgroundColor(0x88000000.toInt()) }
        videoBox.addView(status, FrameLayout.LayoutParams(-2, -2))
        root.addView(videoBox, LinearLayout.LayoutParams(-1, videoHeight()))

        val sv = ScrollView(this)
        val f = u.vbox(); f.setPadding(u.dp(12), u.dp(8), u.dp(12), u.dp(16))
        sv.addView(f); form = sv
        f.addView(u.tv("📹 Kamera (RTSP)", 20f, u.ACC, true))
        val ip = u.edit("IP", ip0); f.addView(ip)
        val port = u.edit("Port", "554").apply { inputType = InputType.TYPE_CLASS_NUMBER; setTextColor(u.TXT) }; f.addView(port)
        val user = u.edit("İstifadəçi adı (lazım olsa)", ""); f.addView(user)
        val pass = u.edit("Parol (lazım olsa)", "").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }; f.addView(pass)

        val labels = Rtsp.PATHS.entries.toList()
        val spin = u.spinner(labels.map { "${it.key}  ${it.value}" }); f.addView(spin)
        val path = u.edit("Yol (path)", labels[0].value); f.addView(path)
        val pref = when {
            vendor.contains("hik") -> 0
            vendor.contains("dahua") || vendor.contains("amcrest") -> 2
            vendor.contains("reolink") -> 4
            vendor.contains("uniview") -> 6
            vendor.contains("axis") -> 7
            else -> 0
        }
        spin.setSelection(pref); path.setText(labels[pref].value)
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { path.setText(labels[pos].value) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        val tcp = CheckBox(this).apply { text = "TCP üzərindən (daha etibarlı)"; setTextColor(u.TXT); isChecked = true }
        f.addView(tcp)
        val res = u.tv("", 12f, u.SUB, false, true).apply { setTextIsSelectable(true) }

        fun uri(): Uri {
            val us = user.text.toString().trim()
            val cred = if (us.isNotEmpty()) Uri.encode(us) + ":" + Uri.encode(pass.text.toString()) + "@" else ""
            var pt = path.text.toString().trim(); if (!pt.startsWith("/")) pt = "/$pt"
            val pn = port.text.toString().trim().ifEmpty { "554" }
            return Uri.parse("rtsp://$cred${ip.text.toString().trim()}:$pn$pt")
        }

        fun play() {
            release()
            if (ip.text.toString().isBlank()) { u.toast("IP yazın"); return }
            status.text = "⏳ Qoşulur…"
            val src = RtspMediaSource.Factory().setForceUseRtpTcp(tcp.isChecked).setTimeoutMs(10000)
                .createMediaSource(MediaItem.fromUri(uri()))
            val pl = ExoPlayer.Builder(this).build()
            pl.setVideoSurfaceView(surface)
            pl.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    when (state) {
                        Player.STATE_BUFFERING -> status.text = "⏳ Yüklənir…"
                        Player.STATE_READY -> status.text = "🔴 CANLI"
                        Player.STATE_ENDED -> status.text = "Yayım bitdi"
                        else -> {}
                    }
                }
                override fun onPlayerError(error: PlaybackException) {
                    val m = (error.cause?.message ?: error.message ?: "").ifEmpty { error.errorCodeName }
                    status.text = "❌ " + when {
                        m.contains("401") || m.contains("Unauthorized", true) -> "Parol tələb olunur və ya səhvdir (401)"
                        m.contains("404") -> "Yol (path) səhvdir (404)"
                        m.contains("461") -> "Transport dəstəklənmir (TCP seçimini dəyişin)"
                        else -> m.take(120)
                    }
                }
            })
            pl.setMediaSource(src); pl.prepare(); pl.playWhenReady = true
            player = pl
        }

        fun find() {
            val host = ip.text.toString().trim(); if (host.isEmpty()) return
            val pn = port.text.toString().trim().toIntOrNull() ?: 554
            val us = user.text.toString().trim(); val pw = pass.text.toString()
            res.text = "Yollar yoxlanılır…"
            Thread {
                val sb = StringBuilder()
                var found: String? = null
                var auth401 = 0
                var noReply = 0
                for ((name, pth) in Rtsp.PATHS) {
                    val r = Rtsp.describe(host, pn, pth, us, pw)
                    val mark = when (r.code) {
                        200 -> "✔ 200 (işləyir)"
                        401 -> { auth401++; if (us.isEmpty()) "🔑 401 (parol lazımdır)" else "🔑 401 (parol səhv ola bilər)" }
                        403 -> "⛔ 403"
                        404 -> "✖ 404"
                        -1 -> "… cavab yoxdur"
                        else -> "? ${r.code}"
                    }
                    sb.append("$mark  $name  $pth\n")
                    if (r.code == 200 && found == null) found = pth
                    if (r.code == -1) noReply++ else noReply = 0
                    if (noReply >= 3 && found == null) { sb.append("… kamera RTSP cavabı vermir, yoxlama dayandırıldı\n"); break }
                }
                val head = when {
                    found != null -> "✅ İşləyən yol tapıldı: $found\n\n"
                    auth401 > 0 && us.isEmpty() -> "🔑 Kamera giriş tələb edir. İstifadəçi/parol yazıb yenidən yoxlayın.\n\n"
                    auth401 > 0 -> "🔑 Parol qəbul olunmadı. İstifadəçi/parolu yoxlayın.\n\n"
                    else -> "❌ Standart yollar tapılmadı. Kameranın RTSP yolunu istehsalçı təlimatından yoxlayın.\n\n"
                }
                u.post {
                    res.text = head + sb.toString()
                    found?.let { path.setText(it); u.toast("Yol seçildi: $it") }
                }
            }.start()
        }

        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(u.btn("▶ Başla") { play() }, LinearLayout.LayoutParams(0, -2, 1f))
        r1.addView(u.btn("⏹ Dayandır") { release(); status.text = "Dayandırıldı" }, LinearLayout.LayoutParams(0, -2, 1f))
        f.addView(r1)
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(u.btn("🔍 Yolu tap") { find() }, LinearLayout.LayoutParams(0, -2, 1f))
        r2.addView(u.btn("⛶ Tam ekran") { setFull(true) }, LinearLayout.LayoutParams(0, -2, 1f))
        f.addView(r2)
        f.addView(res)
        f.addView(u.tv("Yalnız öz kameralarınıza və icazəniz olan cihazlara qoşulun.", 11f, u.SUB))
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun setFull(on: Boolean) {
        full = on
        form.visibility = if (on) View.GONE else View.VISIBLE
        videoBox.layoutParams = LinearLayout.LayoutParams(-1, if (on) -1 else videoHeight())
        requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.decorView.systemUiVisibility = if (on) (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY) else 0
    }

    private fun release() {
        player?.let { try { it.stop(); it.release() } catch (e: Exception) {} }
        player = null
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (full) setFull(false) else super.onBackPressed()
    }

    override fun onPause() { super.onPause(); release() }
    override fun onDestroy() { release(); super.onDestroy() }
}
