# IPTV Player – sürətli açılış və şəbəkə sabitliyi

- VLC şəbəkə və canlı yayım keşləri 2 saniyədir: ilkin açılışı sürətləndirmək və qısa şəbəkə dalğalanmalarına bir qədər ehtiyat saxlamaq üçün balans.
- VLC-də gecikmiş kadrları zorla saxlama seçimi çıxarıldı; gecikmə yarananda pleyer kadrları ata bilər və canlı yayım daha axıcı qala bilər.
- ExoPlayer bufer hədləri (80 Mbit internet): 10 saniyə minimum, 20 saniyə maksimum, ilkin oynatma üçün 2 saniyə, yenidən başlama üçün 4 saniyə. VLC: network-caching 2 saniyə, live-caching 1.5 saniyə. Köhnə bufer kanal dəyişəndə dərhal məhv edilir.
- HTTP bağlantı timeout-u 2.5 saniyə, oxuma timeout-u 4.5 saniyədir; cavab verməyən mənbədən daha tez alternativ pleyerə keçməyə kömək edir.
- Axın başlamasa və ya buffering uzun çəksə, 10 saniyədən sonra alternativ pleyerə keçid edilir.
- Sürətli kanal dəyişmələrində son seçim üstün tutulur; əvvəlki 350 ms gözləmə 100 ms edilib.
- Kanal dəyişmə nəsli ilə köhnə player hadisələri filtrlənir; HTTP reconnect aktivdir.

Qeyd: Daha qısa bufer ilk görüntünü tezləşdirə bilər, lakin zəif internetdə donma ehtimalını artıra bilər. Real nəticə IPTV mənbəyindən, kodekdən və bağlantıdan asılıdır. Android SDK/Gradle və canlı IPTV axınları ilə cihaz testi bu mühitdə aparılmayıb.
