package az.yvok

import android.app.Activity
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout

class MainActivity : Activity() {

    // ---- Ayarlar ----
    private val URL = "https://e-belediyye.gov.az/tax-debts"
    private val INPUT_LEN = 5          // yazılan simvol sayı
    private val PREFIX = "10011"       // önə əlavə olunan
    private val TOTAL_LEN = 12         // son mətnin uzunluğu
    private val FILLER = "0"           // PREFIX + FILLER... + yazılan = TOTAL_LEN
    private val BUTTON_TEXT = "yoxla"  // düymənin mətni (böyük/kiçik fərq etmir)
    // -----------------

    private lateinit var web: WebView
    private var pageReady = false
    private var pending: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = EditText(this).apply {
            hint = "YVÖK DAXİL EDİN"
            maxLines = 1
            filters = arrayOf(InputFilter.LengthFilter(INPUT_LEN))
            textSize = 18f
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    pageReady = true
                    pending?.let { run(it); pending = null }
                }
            }
            loadUrl(URL)
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 0)
            addView(box, LinearLayout.LayoutParams(-1, -2))
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        })

        box.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
                if (s.length == INPUT_LEN) {
                    val padLen = (TOTAL_LEN - PREFIX.length - INPUT_LEN).coerceAtLeast(0)
                    val value = PREFIX + FILLER.repeat(padLen) + s.toString()
                    if (pageReady) run(value) else pending = value
                }
            }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        })
    }

    private fun run(value: String) {
        val safe = value.replace("\\", "").replace("'", "")
        val js = """
        (function(v){
          var n=0;
          function fill(){
            var inp=[].slice.call(document.querySelectorAll('input')).filter(function(i){
              return ['hidden','checkbox','radio','button','submit'].indexOf(i.type)<0 && i.offsetParent!==null;
            })[0];
            if(!inp){ if(n++<20) setTimeout(fill,500); return; }
            var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
            setter.call(inp,v);
            inp.dispatchEvent(new Event('input',{bubbles:true}));
            inp.dispatchEvent(new Event('change',{bubbles:true}));
            var k=0;
            (function click(){
              var b=[].slice.call(document.querySelectorAll('button,input[type=submit],a')).filter(function(x){
                return (x.innerText||x.value||'').toLowerCase().indexOf('$BUTTON_TEXT')>=0;
              })[0];
              if(b && !b.disabled){ b.click(); }
              else if(k++<10){ setTimeout(click,300); }
            })();
          }
          fill();
        })('$safe');
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
