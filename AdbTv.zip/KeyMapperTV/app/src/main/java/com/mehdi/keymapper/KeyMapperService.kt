package com.mehdi.keymapper

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File
import java.util.concurrent.Executors

class KeyMapperService : AccessibilityService() {

    companion object {
        const val ADB_HOST = "192.168.31.220"
        const val ADB_PORT = 5555
        const val OTT_PKG = "es.ottplayer.tv"
        const val LONG_MS = 600L
    }

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var adb: Dadb? = null
    @Volatile private var fgPkg: String? = null

    private var longFired = false
    private var pending: Runnable? = null

    // ---- ADB ----
    private fun connection(): Dadb {
        adb?.let { return it }
        val priv = File(filesDir, "adbkey")
        val pub = File(filesDir, "adbkey.pub")
        if (!priv.exists()) AdbKeyPair.generate(priv, pub)
        val d = Dadb.create(ADB_HOST, ADB_PORT, AdbKeyPair.read(priv, pub))
        adb = d
        return d
    }

    private fun shell(cmd: String) = io.execute {
        try {
            connection().shell(cmd)
        } catch (e: Exception) {
            try { adb?.close() } catch (_: Exception) {}
            adb = null
            try { connection().shell(cmd) } catch (_: Exception) { adb = null }
        }
    }

    private fun sendKey(code: Int) = shell("input keyevent $code")

    override fun onServiceConnected() {
        super.onServiceConnected()
        io.execute { try { connection() } catch (_: Exception) {} }
    }

    // ---- Foreground app tracking ----
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val p = e?.packageName?.toString() ?: return
        if (p == packageName) return
        val skip = listOf("launcher", "tvhome", "systemui", "inputmethod", "settings")
        if (skip.any { p.contains(it, true) }) return
        fgPkg = p
    }

    override fun onInterrupt() {}

    // ---- Key handling ----
    override fun onKeyEvent(ev: KeyEvent): Boolean {
        return when (ev.keyCode) {
            KeyEvent.KEYCODE_BUTTON_6 -> { if (ev.action == KeyEvent.ACTION_DOWN) sendKey(KeyEvent.KEYCODE_DPAD_LEFT); true }
            KeyEvent.KEYCODE_BUTTON_7 -> { if (ev.action == KeyEvent.ACTION_DOWN) sendKey(KeyEvent.KEYCODE_DPAD_RIGHT); true }
            KeyEvent.KEYCODE_BUTTON_5 -> { longPress(ev, { sendKey(KeyEvent.KEYCODE_DPAD_CENTER) }, { openOtt() }); true }
            KeyEvent.KEYCODE_HOME -> {
                longPress(ev,
                    { performGlobalAction(GLOBAL_ACTION_HOME) },
                    { forceStopCurrent() })
                true
            }
            else -> false
        }
    }

    private fun longPress(ev: KeyEvent, short: () -> Unit, long: () -> Unit) {
        when (ev.action) {
            KeyEvent.ACTION_DOWN -> if (ev.repeatCount == 0) {
                longFired = false
                pending?.let { ui.removeCallbacks(it) }
                pending = Runnable { longFired = true; long() }.also { ui.postDelayed(it, LONG_MS) }
            }
            KeyEvent.ACTION_UP -> {
                pending?.let { ui.removeCallbacks(it) }
                pending = null
                if (!longFired) short()
            }
        }
    }

    private fun openOtt() {
        packageManager.getLaunchIntentForPackage(OTT_PKG)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }

    private fun forceStopCurrent() {
        val p = fgPkg ?: return
        if (p == packageName) return
        shell("am force-stop $p")
        performGlobalAction(GLOBAL_ACTION_HOME)
        fgPkg = null
    }

    override fun onDestroy() {
        try { adb?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
