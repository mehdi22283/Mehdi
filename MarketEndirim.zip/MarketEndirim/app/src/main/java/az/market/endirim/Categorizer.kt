package az.market.endirim

import java.util.Locale

/** Məhsul adına görə kateqoriya təyin edir və axtarış üçün mətni normallaşdırır (ə→e, ı→i, ş→s ...). */
object Categorizer {

    const val OTHER = "Digər"

    /** Bu sıra ilə yoxlanılır (əvvəlkilər üstünlük təşkil edir: məs. "Fairy limon" → Təmizlik, "Süd şokoladı" → Şirniyyat). */
    private val RULES: List<Pair<String, List<String>>> = listOf(
        "Uşaq məhsulları" to listOf("usaq", "pampers", "huggies", "bebek", "baby", "bebelac", "nutrilon", "hipp", "pyure", "mamalac", "uşaq"),
        "Təmizlik və məişət" to listOf(
            "persil", "ariel", "tide", "fairy", "domestos", "javel", "yuyucu", "tozu", "temizlik", "salfet", "pecetka",
            "kagiz", "pakel", "folqa", "sunger", "aerozol", "sprey", "losyon", "lenor", "comfort", "vanish", "pemolux", "mayesi", "oyuncaq"
        ),
        "Şəxsi gigiyena" to listOf(
            "sampun", "sabun", "dezodorant", "deodorant", "krem", "tiras", "gigiyenik", "parfum", "maska", "colgate",
            "nivea", "dove", "always", "ped", "diş", "firca", "pasta", "shampoo", "gel", "tualet"
        ),
        "Dondurulmuş məhsullar" to listOf("dondurulmus", "donmus", "pelmen", "nugget", "frozen", "manti"),
        "Şirniyyat və qənnadı" to listOf(
            "sokolad", "konfet", "pecenye", "biskvit", "vafli", "tort", "keks", "halva", "paxlava", "saqqiz", "dondurma",
            "cips", "cerez", "qoz", "findiq", "badam", "snickers", "bounty", "mars", "twix", "milka", "oreo", "nutella",
            "krujka", "draje", "marmelad", "zefir", "napoleon", "roll", "bar", "cokolad"
        ),
        "İçkilər" to listOf(
            "cola", "coca", "kola", "fanta", "sprite", "pepsi", "cappy", "mirinda", "schweppes", "sire", "limonad", "nektar",
            "kompot", "icki", "su", "mineral", "nabran", "sirab", "badamli", "qazli", "pive", "sarab", "araq", "konyak",
            "viski", "vodka", "enerji", "energy", "redbull", "burn", "flash", "tonik", "kvas", "sok", "juice", "icecek"
        ),
        "Çay və qəhvə" to listOf("cay", "qehve", "nescafe", "jacobs", "lipton", "ahmad", "akbar", "kakao", "kofe", "coffee", "tea"),
        "Süd məhsulları və yumurta" to listOf(
            "sud", "qaymaq", "qatiq", "ayran", "pendir", "kefir", "yogurt", "jogurt", "yumurta", "kere", "smetana", "danone",
            "activia", "milk", "marqarin", "motal", "suzme"
        ),
        "Ət və ət məhsulları" to listOf(
            "et", "mal", "qoyun", "toyuq", "quş", "qus", "kolbasa", "sosis", "sucuk", "kabab", "qiyma", "dana", "hind",
            "vetchina", "sosiska", "qanad", "file", "kotlet", "pastrami", "ciyer", "bud"
        ),
        "Balıq və dəniz məhsulları" to listOf("baliq", "qizilbaliq", "siyenek", "kalmar", "krevet", "ikra", "tuna", "sardina", "hamsi", "kilka", "xalvar"),
        "Çörək və un məmulatları" to listOf("corek", "lavas", "tendir", "bulka", "xemir", "baton", "kruasan", "simit", "toast", "bagel"),
        "Bakaliya" to listOf(
            "duyu", "makaron", "spagetti", "yarma", "mercimek", "lobya", "noxud", "un", "seker", "duz", "yag", "gunebaxan",
            "sirke", "ketcap", "mayonez", "sous", "konserv", "bal", "murebbe", "edviyyat", "qarabogday", "bulqur", "noodle",
            "dosirak", "fasilye", "zeytun", "turşu", "tursu", "pasta", "chips", "ceviz", "kisamis", "gogerti"
        ),
        "Meyvə və tərəvəz" to listOf(
            "alma", "armud", "banan", "portagal", "mandarin", "limon", "uzum", "nar", "xiyar", "pomidor", "kartof", "sogan",
            "sarimsaq", "kelem", "yerkoku", "biber", "badimcan", "qarpiz", "yemis", "meyve", "terevez", "ispanaq", "cilek",
            "albali", "gilas", "heyva", "ayva", "avokado", "ananas", "kivi", "gavali", "xurma", "enar", "sitrus", "yasil"
        )
    )

    /** Kateqoriyaların göstərilmə sırası (Digər sonda). */
    val ORDER: List<String> = listOf(
        "İçkilər", "Çay və qəhvə", "Süd məhsulları və yumurta", "Ət və ət məhsulları", "Balıq və dəniz məhsulları",
        "Meyvə və tərəvəz", "Çörək və un məmulatları", "Bakaliya", "Şirniyyat və qənnadı", "Dondurulmuş məhsullar",
        "Təmizlik və məişət", "Şəxsi gigiyena", "Uşaq məhsulları", OTHER
    )

    private val RULES_NORM: List<Pair<String, List<String>>> =
        RULES.map { (c, kws) -> c to kws.map { norm(it) }.distinct() }

    fun norm(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s.lowercase(Locale.ROOT)) {
            when (ch) {
                'ə' -> sb.append('e')
                'ı' -> sb.append('i')
                'ö' -> sb.append('o')
                'ü' -> sb.append('u')
                'ş' -> sb.append('s')
                'ç' -> sb.append('c')
                'ğ' -> sb.append('g')
                '\u0307' -> {}            // "İ" → "i̇" birləşən nöqtə
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /** BÜTÖV BÖYÜK HƏRFLİ OCR adlarını oxunaqlı hala gətirir: "COCA COLA 0.5L" → "Coca Cola 0.5L". */
    fun pretty(name: String): String {
        if (name.any { it.isLowerCase() }) return name
        return name.split(' ').filter { it.isNotEmpty() }.joinToString(" ") { w ->
            if (w.any { it.isDigit() } || w.length <= 2) w
            else w.lowercase(Locale.ROOT).replaceFirstChar { it.uppercase(Locale.ROOT) }
        }
    }

    fun classify(name: String): String {
        val tokens = norm(name).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return OTHER
        for ((cat, kws) in RULES_NORM) {
            for (kw in kws) {
                val hit = if (kw.length <= 3) tokens.any { it == kw } else tokens.any { it.startsWith(kw) }
                if (hit) return cat
            }
        }
        return OTHER
    }
}
