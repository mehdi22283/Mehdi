ZƏNG YAZICI - quraşdırma (hamısı telefonda, kompüter lazım deyil)

1) Shizuku tətbiqini quraşdırın (Google Play və ya github.com/RikkaApps/Shizuku).
2) Telefon ayarları > Haqqında > MIUI/HyperOS versiyasına 7 dəfə toxunun > Developer options > "Wireless debugging" açın (Wi-Fi-a qoşulu olun).
3) Shizuku > "Pairing" ilə cütləşdirin (kodu bildirişə yazın) > "Start" düyməsi. Shizuku işə düşəndən sonra Wi-Fi sönsə də işləməyə davam edir; yalnız telefon yenidən başlayanda təkrar start lazımdır.
4) Bu tətbiqi açın və yuxarıdan aşağı 1-4 düymələrini ardıcıl basın.
5) "6 saniyəlik sınaq yazısı" ilə yoxlayın. Alınmasa "Jurnal" düyməsindəki mətni mənə göndərin.

Yazılar: /sdcard/Android/media/az.zeng.yazici/ (WAV)
