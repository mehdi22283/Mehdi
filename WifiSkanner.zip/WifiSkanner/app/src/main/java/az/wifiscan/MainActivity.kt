package az.wifiscan

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.osmdroid.config.Configuration
import java.io.File

class MainActivity : Activity() {
    private lateinit var pages: Array<Page>
    private lateinit var tabBtns: Array<TextView>
    private var current = 0
    private val MAP_PAGE = 3

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val cfg = Configuration.getInstance()
        cfg.userAgentValue = packageName
        cfg.osmdroidBasePath = File(cacheDir, "osmdroid")
        cfg.osmdroidTileCache = File(cacheDir, "osmdroid/tiles")

        val u = Ui(this)
        window.statusBarColor = u.BG; window.navigationBarColor = u.BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(u.BG); setPadding(0, u.dp(24), 0, 0) }
        val content = FrameLayout(this)
        pages = arrayOf(scanPage(u), portPage(u), pingPage(u), tracePage(u), speedPage(u), toolsPage(u))
        pages.forEach { content.addView(it.view, FrameLayout.LayoutParams(-1, -1)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(u.CARD) }
        val names = arrayOf("📡\nSkan", "🔌\nPort", "🏓\nPing", "🧭\nTrace", "⚡\nSürət", "🛠\nAlət")
        tabBtns = Array(names.size) { i ->
            u.tv(names[i], 11f, u.SUB, true).apply { gravity = Gravity.CENTER; setPadding(0, u.dp(10), 0, u.dp(10)); setOnClickListener { select(i, u) } }
        }
        tabBtns.forEach { bar.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        u.go = { i, h -> select(i, u); pages[i].open(h) }
        select(0, u)
        Thread { try { Oui.load(applicationContext) } catch (e: Throwable) {} }.start()
    }

    private fun select(i: Int, u: Ui) {
        current = i
        pages.forEachIndexed { j, p -> p.view.visibility = if (i == j) View.VISIBLE else View.GONE }
        tabBtns.forEachIndexed { j, t -> t.setTextColor(if (i == j) u.ACC else u.SUB) }
    }

    override fun onResume() { super.onResume(); if (::pages.isInitialized) pages[MAP_PAGE].resume() }
    override fun onPause() { if (::pages.isInitialized) pages[MAP_PAGE].pause(); super.onPause() }
}
