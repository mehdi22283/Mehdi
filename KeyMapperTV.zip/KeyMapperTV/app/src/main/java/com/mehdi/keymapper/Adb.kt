package com.mehdi.keymapper

import android.content.Context
import android.provider.Settings
import dadb.AdbKeyPair
import dadb.AdbShellPacket
import dadb.AdbShellStream
import dadb.Dadb
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

object Adb {
    enum class State { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

    @Volatile var state = State.DISCONNECTED
        private set
    @Volatile var error: String? = null
        private set
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    private val io = Executors.newSingleThreadExecutor()
    private val fast = Executors.newSingleThreadExecutor()
    @Volatile private var dadb: Dadb? = null
    @Volatile private var inj: AdbShellStream? = null
    @Volatile private var starting = false
    private lateinit var app: Context

    val fastReady: Boolean get() = inj != null

    fun init(c: Context) { app = c.applicationContext }

    private fun notifyChange() {
        listeners.forEach { try { it() } catch (_: Exception) {} }
    }

    private fun set(s: State, e: String? = null) {
        state = s
        error = e
        notifyChange()
    }

    fun connect(force: Boolean = false) {
        if (!force && (state == State.CONNECTING || state == State.CONNECTED)) return
        io.execute { doConnect() }
    }

    private fun doConnect(): Boolean {
        set(State.CONNECTING)
        val oldInj = inj
        inj = null
        try { oldInj?.close() } catch (_: Exception) {}
        try { dadb?.close() } catch (_: Exception) {}
        dadb = null
        return try {
            val priv = File(app.filesDir, "adbkey")
            val pub = File(app.filesDir, "adbkey.pub")
            if (!priv.exists()) AdbKeyPair.generate(priv, pub)
            val d = Dadb.create(Store.host, Store.port, AdbKeyPair.read(priv, pub))
            val r = d.shell("echo ok")
            if (!r.output.contains("ok")) throw RuntimeException("cavab yoxdur")
            dadb = d
            set(State.CONNECTED)
            startInjector()
            afterConnect()
            true
        } catch (e: Throwable) {
            dadb = null
            set(State.ERROR, e.message ?: e.javaClass.simpleName)
            false
        }
    }

    private fun exec(cmd: String): String {
        val d = dadb ?: throw IllegalStateException("ADB qoşulmayıb")
        return d.shell(cmd).output
    }

    fun shell(cmd: String, cb: ((String) -> Unit)? = null) {
        io.execute {
            try {
                if (dadb == null && !doConnect()) return@execute
                val out = try { exec(cmd) } catch (e: Throwable) {
                    if (!doConnect()) return@execute
                    exec(cmd)
                }
                cb?.invoke(out)
            } catch (e: Throwable) {
                set(State.ERROR, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun ping() {
        if (state != State.CONNECTED) return
        io.execute {
            try {
                exec("echo ok")
                if (inj == null) startInjector()
            } catch (e: Throwable) { doConnect() }
        }
    }

    // ---------- Sürətli düymə inyeksiyası ----------

    /** Cihazda daimi işləyən Injector prosesini başladır (bir dəfə). */
    private fun startInjector() {
        if (starting || inj != null) return
        starting = true
        try {
            val d = dadb ?: return
            val pkg = app.packageName
            val apk = exec("pm path $pkg").lines()
                .firstOrNull { it.startsWith("package:") }
                ?.removePrefix("package:")?.trim() ?: return
            exec("pkill -f [c]om.mehdi.keymapper.Injector")
            val s = d.openShell("CLASSPATH=$apk app_process /system/bin com.mehdi.keymapper.Injector")
            inj = s
            notifyChange()
            Thread {
                try {
                    while (true) {
                        val p = s.read()
                        if (p is AdbShellPacket.Exit) break
                    }
                } catch (_: Throwable) {}
                if (inj === s) {
                    inj = null
                    notifyChange()
                    try { Thread.sleep(2000) } catch (_: Exception) {}
                    io.execute { startInjector() }
                }
            }.start()
        } catch (_: Throwable) {
            inj = null
        } finally {
            starting = false
        }
    }

    fun keyDown(code: Int, repeat: Int) = send("D $code $repeat")
    fun keyUp(code: Int) = send("U $code")
    fun tap(code: Int) = send("K $code")

    private fun send(line: String) {
        fast.execute {
            val s = inj
            if (s != null) {
                try {
                    s.write(line + "\n")
                    return@execute
                } catch (_: Throwable) {
                    inj = null
                }
            }
            // ehtiyat yol: yavaş, amma işləyir
            val p = line.split(" ")
            if (p[0] == "K" || (p[0] == "D" && p.getOrNull(2) == "0")) shell("input keyevent ${p[1]}")
            io.execute { startInjector() }
        }
    }

    // ---------- Əlçatımlılıq ----------

    private fun enableAccessibility() {
        val pkg = app.packageName
        val cn = "$pkg/$pkg.KeyMapperService"
        val cur = exec("settings get secure enabled_accessibility_services").trim()
        if (!cur.contains("$pkg/")) {
            val v = if (cur.isEmpty() || cur == "null") cn else "$cur:$cn"
            exec("settings put secure enabled_accessibility_services $v")
        }
        exec("settings put secure accessibility_enabled 1")
    }

    fun enableAccessibilityAsync() {
        io.execute {
            try {
                if (dadb == null && !doConnect()) return@execute
                enableAccessibility()
            } catch (e: Throwable) {
                set(State.ERROR, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun afterConnect() {
        try {
            val pkg = app.packageName
            val on = Settings.Secure.getString(
                app.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            if (!on.contains("$pkg/") || !KeyMapperService.running) enableAccessibility()
            exec("dumpsys deviceidle whitelist +$pkg")
            exec("cmd appops set $pkg RUN_IN_BACKGROUND allow")
            exec("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow")
        } catch (_: Throwable) {}
    }
}
