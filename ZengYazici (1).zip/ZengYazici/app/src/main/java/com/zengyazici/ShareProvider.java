package com.zengyazici;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** Yazını paylaşmaq üçün: yalnız cache/share qovluğundakı fayllara oxumaq icazəsi verir. */
public class ShareProvider extends ContentProvider {
    public static String authority(android.content.Context c) { return c.getPackageName() + ".files"; }

    private File resolve(Uri u) throws FileNotFoundException {
        try {
            File dir = new File(getContext().getCacheDir(), "share").getCanonicalFile();
            File f = new File(dir, u.getLastPathSegment()).getCanonicalFile();
            if (!f.getPath().startsWith(dir.getPath() + File.separator) || !f.isFile()) throw new FileNotFoundException();
            return f;
        } catch (FileNotFoundException e) {
            throw e;
        } catch (Exception e) {
            throw new FileNotFoundException(String.valueOf(e));
        }
    }

    @Override public boolean onCreate() { return true; }

    @Override public ParcelFileDescriptor openFile(Uri u, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(resolve(u), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Cursor query(Uri u, String[] p, String sel, String[] args, String sort) {
        try {
            File f = resolve(u);
            MatrixCursor c = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
            c.addRow(new Object[]{f.getName(), f.length()});
            return c;
        } catch (Exception e) { return null; }
    }

    @Override public String getType(Uri u) { return "audio/x-wav"; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
