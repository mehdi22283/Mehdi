package az.market.endirim

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.FloatBuffer
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Oflayn ən güclü mühərrik: PaddleOCR PP-OCRv5 (mobil) — ONNX Runtime ilə telefonda işləyir.
 *  1) detektor mətn sətirlərini tapır (DB: ehtimal xəritəsi → bağlı sahələr → qutular);
 *  2) tanıyıcı hər qutunu oxuyur (CTC, "greedy" açma).
 * Modellər (~21 MB) ilk istifadədə bir dəfə endirilir; endirilməsə / xəta olsa mühərrik söndürülür, qalan OCR-lar işləyir.
 */
object PaddleOcr {
    private const val BASE = "https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/"
    private const val DET_URL = BASE + "PP-OCRv5_mobile_det_onnx_infer.tar"
    private const val REC_URL = BASE + "PP-OCRv5_mobile_rec_onnx_infer.tar"
    private const val DET_SIDE = 1280          // böyük tərəf (kiçik yazılar üçün PaddleOCR-ın 960-ından yüksək)
    private const val BIN_THRESH = 0.3f
    private const val BOX_THRESH = 0.6f
    private const val UNCLIP = 1.5f
    private const val REC_H = 48

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    private var env: OrtEnvironment? = null
    private var det: OrtSession? = null
    private var rec: OrtSession? = null
    private var dict: List<String> = emptyList()
    @Volatile private var failed = false

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("paddle", Context.MODE_PRIVATE)
    fun switchedOn(ctx: Context): Boolean = prefs(ctx).getBoolean("on", true)
    fun save(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean("on", on).apply()
        if (on) failed = false
    }

    private fun dir(ctx: Context) = File(ctx.filesDir, "paddle").apply { mkdirs() }
    private fun f(ctx: Context, n: String) = File(dir(ctx), n)

    /** Qoşulubdur və (hələ) xəta verməyib. */
    fun enabled(ctx: Context): Boolean = switchedOn(ctx) && !failed

    /** Modellər artıq endirilib (sığnatura üçün: yalnız hazır olanda skan imzası dəyişir). */
    fun ready(ctx: Context): Boolean = enabled(ctx) && f(ctx, "det.onnx").exists() && f(ctx, "rec.onnx").exists() && f(ctx, "rec.yml").exists()

    // ---------------- endirmə və yükləmə ----------------

    private fun toast(ctx: Context, msg: String) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    private fun readFully(i: InputStream, b: ByteArray): Boolean {
        var n = 0
        while (n < b.size) {
            val r = i.read(b, n, b.size - n)
            if (r < 0) return false
            n += r
        }
        return true
    }

    private fun copyN(i: InputStream, o: OutputStream, n: Long) {
        val buf = ByteArray(64 * 1024)
        var left = n
        while (left > 0) {
            val r = i.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (r < 0) throw IOException("tar kəsildi")
            o.write(buf, 0, r)
            left -= r
        }
    }

    private fun skipN(i: InputStream, n: Long) {
        var left = n
        val buf = ByteArray(64 * 1024)
        while (left > 0) {
            val r = i.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (r < 0) return
            left -= r
        }
    }

    /** .tar (və ya .tar.gz) arxivindən *.onnx və inference.yml faylları <prefix>.onnx / <prefix>.yml adı ilə çıxarılır. */
    private fun fetchTar(url: String, outDir: File, prefix: String) {
        val req = Request.Builder().url(url).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            var ins: InputStream = BufferedInputStream(r.body!!.byteStream(), 128 * 1024)
            ins.mark(2)
            val b0 = ins.read()
            val b1 = ins.read()
            ins.reset()
            if (b0 == 0x1f && b1 == 0x8b) ins = GZIPInputStream(ins)
            val hdr = ByteArray(512)
            while (true) {
                if (!readFully(ins, hdr)) break
                if (hdr.all { it.toInt() == 0 }) break
                var n = 0
                while (n < 100 && hdr[n].toInt() != 0) n++
                val name = String(hdr, 0, n, Charsets.UTF_8)
                val sizeStr = String(hdr, 124, 12, Charsets.US_ASCII).trim { it == ' ' || it == '\u0000' }
                val size = if (sizeStr.isEmpty()) 0L else sizeStr.toLong(8)
                val type = hdr[156].toInt().toChar()
                val padded = (size + 511) / 512 * 512
                val isFile = type == '0' || type == '\u0000'
                val ext = when {
                    isFile && name.endsWith(".onnx") -> "onnx"
                    isFile && name.endsWith("inference.yml") -> "yml"
                    else -> null
                }
                if (ext != null) {
                    val tmp = File(outDir, "$prefix.$ext.part")
                    tmp.outputStream().use { o -> copyN(ins, o, size) }
                    skipN(ins, padded - size)
                    tmp.renameTo(File(outDir, "$prefix.$ext"))
                } else {
                    skipN(ins, padded)
                }
            }
        }
    }

    private fun unquote(s: String): String {
        if (s.length >= 2 && s.first() == '\'' && s.last() == '\'') return s.substring(1, s.length - 1).replace("''", "'")
        if (s.length >= 2 && s.first() == '"' && s.last() == '"') return s.substring(1, s.length - 1).replace("\\\\", "\\").replace("\\\"", "\"")
        return s
    }

    /** inference.yml içindəki "character_dict:" siyahısı. */
    private fun loadDict(file: File): List<String> {
        val out = ArrayList<String>()
        var inside = false
        for (raw in file.readLines(Charsets.UTF_8)) {
            if (!inside) {
                if (raw.trimStart().startsWith("character_dict:")) inside = true
                continue
            }
            val t = raw.trim()
            if (t.startsWith("- ")) out.add(unquote(t.substring(2)))
            else if (t.isEmpty()) continue
            else break
        }
        return out
    }

    private fun ensure(ctx: Context): Boolean {
        if (failed) return false
        if (det != null && rec != null) return true
        return try {
            val d = dir(ctx)
            if (!f(ctx, "det.onnx").exists()) {
                toast(ctx, "PaddleOCR modelləri endirilir (~21 MB, bir dəfə)…")
                fetchTar(DET_URL, d, "det")
            }
            if (!f(ctx, "rec.onnx").exists() || !f(ctx, "rec.yml").exists()) fetchTar(REC_URL, d, "rec")
            if (!f(ctx, "det.onnx").exists() || !f(ctx, "rec.onnx").exists() || !f(ctx, "rec.yml").exists()) throw IOException("model faylları tapılmadı")
            val dc = loadDict(f(ctx, "rec.yml"))
            if (dc.size < 50) throw IOException("lüğət oxunmadı")
            val e = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
            val ds = e.createSession(f(ctx, "det.onnx").absolutePath, opts)
            val rs = e.createSession(f(ctx, "rec.onnx").absolutePath, OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) })
            env = e; det = ds; rec = rs; dict = dc
            true
        } catch (e: Exception) {
            failed = true
            // yarımçıq/zədəli fayllar silinir ki, növbəti açılışda təzədən endirilsin
            for (n in listOf("det.onnx", "rec.onnx", "rec.yml")) f(ctx, n).delete()
            toast(ctx, "PaddleOCR işə düşmədi — yerli OCR ilə davam edir")
            false
        }
    }

    // ---------------- oxuma ----------------

    private class Box(val l: Int, val t: Int, val r: Int, val b: Int)

    /** Səhifədəki bütün sətirləri (səhifə koordinatlarında) qaytarır; mühərrik işləməsə null. */
    suspend fun lines(ctx: Context, bmp: Bitmap): List<OLine>? {
        if (!enabled(ctx)) return null
        return withContext(Dispatchers.Default) {
            synchronized(this@PaddleOcr) {
                if (!ensure(ctx)) return@synchronized null
                try {
                    val boxes = detect(bmp)
                    val out = ArrayList<OLine>()
                    for (bx in boxes) {
                        val txt = recognize(bmp, bx) ?: continue
                        out.add(OLine(txt, bx.l, bx.t, bx.r, bx.b))
                    }
                    out
                } catch (e: Exception) {
                    null
                }
            }
        }
    }

    /** DB detektoru: ehtimal xəritəsi → eşik → bağlı sahələr → bir qədər genişləndirilmiş qutular. */
    private fun detect(bmp: Bitmap): List<Box> {
        val e = env!!
        val s = det!!
        val w = bmp.width
        val h = bmp.height
        val sc = minOf(1f, DET_SIDE.toFloat() / maxOf(w, h))
        val nw = (((w * sc) / 32f).roundToInt() * 32).coerceAtLeast(32)
        val nh = (((h * sc) / 32f).roundToInt() * 32).coerceAtLeast(32)
        val sb = Bitmap.createScaledBitmap(bmp, nw, nh, true)
        val px = IntArray(nw * nh)
        sb.getPixels(px, 0, nw, 0, 0, nw, nh)
        if (sb !== bmp) sb.recycle()
        val plane = nw * nh
        val data = FloatArray(3 * plane)
        // PaddleOCR/OpenCV kimi BGR sırası; ImageNet orta/sapma
        for (i in 0 until plane) {
            val c = px[i]
            val r = ((c shr 16) and 0xFF) / 255f
            val g = ((c shr 8) and 0xFF) / 255f
            val b = (c and 0xFF) / 255f
            data[i] = (b - 0.485f) / 0.229f
            data[plane + i] = (g - 0.456f) / 0.224f
            data[2 * plane + i] = (r - 0.406f) / 0.225f
        }
        var prob: Array<FloatArray>? = null
        OnnxTensor.createTensor(e, FloatBuffer.wrap(data), longArrayOf(1, 3, nh.toLong(), nw.toLong())).use { t ->
            s.run(mapOf(s.inputNames.first() to t)).use { res ->
                @Suppress("UNCHECKED_CAST")
                val v = res[0].value as Array<Array<Array<FloatArray>>>
                prob = v[0][0]
            }
        }
        val p = prob ?: return emptyList()
        val ph = p.size
        val pw = p[0].size
        val seen = BooleanArray(pw * ph)
        val stack = IntArray(pw * ph)
        val sx = w.toFloat() / pw
        val sy = h.toFloat() / ph
        val boxes = ArrayList<Box>()
        for (start in 0 until pw * ph) {
            if (seen[start] || p[start / pw][start % pw] <= BIN_THRESH) continue
            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var minx = pw; var maxx = -1; var miny = ph; var maxy = -1
            var sum = 0f; var cnt = 0
            while (sp > 0) {
                val q = stack[--sp]
                val qx = q % pw
                val qy = q / pw
                sum += p[qy][qx]; cnt++
                if (qx < minx) minx = qx
                if (qx > maxx) maxx = qx
                if (qy < miny) miny = qy
                if (qy > maxy) maxy = qy
                if (qx > 0) { val n = q - 1; if (!seen[n] && p[qy][qx - 1] > BIN_THRESH) { seen[n] = true; stack[sp++] = n } }
                if (qx < pw - 1) { val n = q + 1; if (!seen[n] && p[qy][qx + 1] > BIN_THRESH) { seen[n] = true; stack[sp++] = n } }
                if (qy > 0) { val n = q - pw; if (!seen[n] && p[qy - 1][qx] > BIN_THRESH) { seen[n] = true; stack[sp++] = n } }
                if (qy < ph - 1) { val n = q + pw; if (!seen[n] && p[qy + 1][qx] > BIN_THRESH) { seen[n] = true; stack[sp++] = n } }
            }
            val bw = maxx - minx + 1
            val bh = maxy - miny + 1
            if (minOf(bw, bh) < 3 || cnt < 12) continue
            if (sum / cnt < BOX_THRESH) continue
            // DB "unclip": məsafə = sahə * nisbət / perimetr
            val d = (bw * bh * UNCLIP) / (2f * (bw + bh))
            val l = ((minx - d) * sx).toInt().coerceIn(0, w - 1)
            val t = ((miny - d) * sy).toInt().coerceIn(0, h - 1)
            val r = (((maxx + 1) + d) * sx).toInt().coerceIn(l + 1, w)
            val b = (((maxy + 1) + d) * sy).toInt().coerceIn(t + 1, h)
            boxes.add(Box(l, t, r, b))
        }
        return boxes.sortedWith(compareBy({ it.t / 20 }, { it.l }))
    }

    /** Tanıyıcı: qutu kəsilir, hündürlüyü 48-ə gətirilir, CTC çıxışı açılır. Əminlik aşağıdırsa null. */
    private fun recognize(bmp: Bitmap, bx: Box): String? {
        val e = env!!
        val s = rec!!
        val w = bx.r - bx.l
        val h = bx.b - bx.t
        if (w < 6 || h < 6) return null
        if (h > 1.5f * w) return null          // şaquli yazı — atılır
        val crop = Bitmap.createBitmap(bmp, bx.l, bx.t, w, h)
        val tw = ceil(REC_H.toFloat() * w / h).toInt().coerceIn(16, 2000)
        val sb = Bitmap.createScaledBitmap(crop, tw, REC_H, true)
        if (sb !== crop) crop.recycle()
        val px = IntArray(tw * REC_H)
        sb.getPixels(px, 0, tw, 0, 0, tw, REC_H)
        sb.recycle()
        val plane = tw * REC_H
        val data = FloatArray(3 * plane)
        for (i in 0 until plane) {
            val c = px[i]
            data[i] = ((c and 0xFF) / 255f - 0.5f) / 0.5f                       // B
            data[plane + i] = (((c shr 8) and 0xFF) / 255f - 0.5f) / 0.5f        // G
            data[2 * plane + i] = (((c shr 16) and 0xFF) / 255f - 0.5f) / 0.5f   // R
        }
        var steps: Array<FloatArray>? = null
        OnnxTensor.createTensor(e, FloatBuffer.wrap(data), longArrayOf(1, 3, REC_H.toLong(), tw.toLong())).use { t ->
            s.run(mapOf(s.inputNames.first() to t)).use { res ->
                @Suppress("UNCHECKED_CAST")
                val v = res[0].value as Array<Array<FloatArray>>
                steps = v[0]
            }
        }
        val out = steps ?: return null
        if (out.isEmpty()) return null
        val classes = out[0].size
        if (classes != dict.size + 2 && classes != dict.size + 1) {
            failed = true            // lüğət çıxışa uyğun deyil — səhv mətn əvəzinə mühərrik söndürülür
            return null
        }
        val sbd = StringBuilder()
        var prev = -1
        var confSum = 0f
        var confN = 0
        for (row in out) {
            var best = 0
            var bv = row[0]
            for (k in 1 until row.size) if (row[k] > bv) { bv = row[k]; best = k }
            if (best != 0 && best != prev) {
                val idx = best - 1
                sbd.append(if (idx < dict.size) dict[idx] else " ")
                confSum += bv; confN++
            }
            prev = best
        }
        if (confN == 0) return null
        val txt = sbd.toString().trim()
        if (txt.isEmpty() || confSum / confN < 0.45f) return null
        return txt
    }
}
