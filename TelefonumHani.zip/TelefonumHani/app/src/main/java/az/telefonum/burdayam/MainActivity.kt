package az.telefonum.burdayam

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var phrase: EditText
    private var pendingTest = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(24), px(48), px(24), px(24))
            setBackgroundColor(Color.parseColor("#0F1B2D"))
        }

        root.addView(TextView(this).apply {
            text = "📱"
            textSize = 64f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Telefonum hanı?"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Başlayın və telefonunuzu axtararkən \"Telefonum hanıı?\" deyə qışqırın. " +
                "Telefon səssiz və ən aşağı səsdə olsa belə \"Burdayaaaam!\" deyə cavab verəcək."
            textSize = 15f
            setTextColor(Color.parseColor("#B0BEC5"))
            gravity = Gravity.CENTER
            setPadding(0, px(12), 0, px(20))
        })

        status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, px(16))
        }
        root.addView(status)

        toggle = Button(this).apply {
            textSize = 18f
            setOnClickListener { onToggle() }
        }
        root.addView(toggle, LinearLayout.LayoutParams(-1, px(60)))

        root.addView(Button(this).apply {
            text = "🔊 Test et (Burdayam de)"
            setOnClickListener { onTest() }
        }, LinearLayout.LayoutParams(-1, px(52)).apply { topMargin = px(12) })

        root.addView(TextView(this).apply {
            text = "Öz açar sözünüz (istəyə bağlı):"
            setTextColor(Color.parseColor("#B0BEC5"))
            setPadding(0, px(24), 0, px(4))
        })
        phrase = EditText(this).apply {
            hint = "məs: telefon harda"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT
            setText(getSharedPreferences("p", MODE_PRIVATE).getString("phrase", ""))
        }
        root.addView(phrase)

        root.addView(Button(this).apply {
            text = "🔋 Batareya məhdudiyyətini söndür"
            setOnClickListener { askIgnoreBattery() }
        }, LinearLayout.LayoutParams(-1, px(52)).apply { topMargin = px(20) })

        root.addView(TextView(this).apply {
            text = "Xiaomi/Redmi: Ayarlar → Tətbiqlər → bu tətbiq → \"Avtomatik başlama\" açın və " +
                "batareya rejimini \"Məhdudiyyət yoxdur\" edin ki, sistem tətbiqi bağlamasın.\n\n" +
                "Qeyd: Dinləmə üçün internet lazım ola bilər (Google səs tanıma)."
            textSize = 12f
            setTextColor(Color.parseColor("#78909C"))
            setPadding(0, px(16), 0, 0)
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F1B2D"))
            addView(root)
        })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        if (ListenService.running) {
            status.text = "🟢 Dinləyir..."
            status.setTextColor(Color.parseColor("#66BB6A"))
            toggle.text = "⏹ Dayandır"
        } else {
            status.text = "🔴 Dayanıb"
            status.setTextColor(Color.parseColor("#EF5350"))
            toggle.text = "▶ Dinləməyə başla"
        }
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissions(): Boolean {
        if (hasMic()) return true
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(list.toTypedArray(), 1)
        return false
    }

    private fun onToggle() {
        if (ListenService.running) {
            startForegroundService(Intent(this, ListenService::class.java).setAction(ListenService.ACTION_STOP))
            ListenService.running = false
            refresh()
        } else {
            pendingTest = false
            if (!ensurePermissions()) return
            startListeningService()
        }
    }

    private fun startListeningService() {
        getSharedPreferences("p", MODE_PRIVATE).edit()
            .putString("phrase", phrase.text.toString().trim()).apply()
        startForegroundService(Intent(this, ListenService::class.java))
        ListenService.running = true
        refresh()
    }

    private fun onTest() {
        pendingTest = true
        if (!ensurePermissions()) return
        startForegroundService(Intent(this, ListenService::class.java).setAction(ListenService.ACTION_TEST))
        ListenService.running = true
        refresh()
    }

    private fun askIgnoreBattery() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) {
                Toast.makeText(this, "Artıq söndürülüb ✅", Toast.LENGTH_SHORT).show()
                return
            }
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasMic()) {
            if (pendingTest) onTest() else startListeningService()
        } else {
            Toast.makeText(this, "Mikrofon icazəsi lazımdır", Toast.LENGTH_LONG).show()
        }
    }
}
