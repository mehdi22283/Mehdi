# Mehdi Key Mapper — Xiaomi TV Box 2 / Android TV

Package: `com.mehdi.keymapper`

## Mapping

- `KEYCODE_BUTTON_6` → `KEYCODE_DPAD_LEFT`
- `KEYCODE_BUTTON_5` → `KEYCODE_DPAD_CENTER` (Select / OK)
- `KEYCODE_BUTTON_7` → `KEYCODE_DPAD_RIGHT`
- Long press `KEYCODE_BUTTON_5` → open `es.ottplayer.tv`
- Long press `KEYCODE_HOME` → force-stop the app that was active before HOME

BUTTON_6 and BUTTON_7 preserve the original DOWN/UP times, repeat count, source and meta state when re-injected, so normal tap and hold/repeat behavior is retained.

## Why Shizuku is included

Android Accessibility can observe/filter hardware key events, but a normal third-party app does not automatically have the privileged ability to inject arbitrary key events into other applications. This project therefore uses Accessibility only as the low-latency event filter and a Shizuku UserService as the privileged injector. Shizuku can expose shell/root identity to the UserService.

The app itself also contains:

- permanent foreground notification service (`specialUse` type)
- `BOOT_COMPLETED`, `LOCKED_BOOT_COMPLETED` and package-replaced receiver
- periodic Accessibility re-enable watchdog when `WRITE_SECURE_SETTINGS` is granted
- ADB/setup commands for background limits and Doze allowlist
- fixed endpoint display: `192.168.31.220:5555`

## Important Android limits

A normal app cannot silently grant itself Accessibility access or signature-level system permissions. The included ADB script performs the secure-setting/background setup that is available through ADB.

The app cannot magically start an ADB server on itself. `192.168.31.220:5555` is treated as the ADB endpoint used for setup/Shizuku. On Android 11+, Shizuku itself may need its own ADB/wireless-debugging startup after boot unless the device/ROM supports an auto-start method.

## Build

Use Android Studio or GitHub Actions. The repository includes a workflow that builds `assembleDebug`.

### GitHub Actions

Push this folder to GitHub. The workflow in `.github/workflows/build.yml` installs Android SDK 35 and builds `app-debug.apk`.

### Host ADB setup

After downloading the debug APK to the same directory as `adb_setup.sh`:

```bash
adb connect 192.168.31.220:5555
adb install -r app-debug.apk
adb shell pm grant com.mehdi.keymapper android.permission.WRITE_SECURE_SETTINGS
adb shell settings put global app_standby_enabled 0
adb shell cmd appops set com.mehdi.keymapper RUN_IN_BACKGROUND allow
adb shell cmd appops set com.mehdi.keymapper RUN_ANY_IN_BACKGROUND allow
adb shell dumpsys deviceidle whitelist +com.mehdi.keymapper
adb shell settings put secure enabled_accessibility_services com.mehdi.keymapper/com.mehdi.keymapper.KeyMapperAccessibilityService
adb shell settings put secure accessibility_enabled 1
adb shell am start -n com.mehdi.keymapper/.MainActivity
```

Then start/configure Shizuku and grant this app Shizuku permission once. The injector status in the app must show `READY` for cross-app DPAD injection and Force Stop to work.

## Notes on "no delay"

BUTTON_6/7 and HOME inject their DOWN event immediately. BUTTON_5 also injects CENTER DOWN immediately; a 400 ms timer is used only to distinguish the long-press action. On a long BUTTON_5 press, the already-sent CENTER event is canceled before OTTPlayer is launched, preventing a completed OK click in typical Android TV controls.

No software-only Android Accessibility implementation can guarantee identical behavior on every OEM/ROM because input interception and privileged injection are system-level facilities.

## Yeni UI funksiyaları
- Açılışda Program / Foreground Service / Accessibility / Shizuku / Injector statusu göstərilir.
- `ADB ilə qoşul / yoxla` düyməsi `192.168.31.220:5555` portunu yoxlayır və WRITE_SECURE_SETTINGS verilibsə Accessibility-i ayrıca settings ekranı açmadan aktivləşdirir.
- Düymələr tətbiqin içindən əlavə edilə, redaktə edilə, silinə və əvəz edilə bilər.
- Mapping-lər SharedPreferences-də saxlanılır və servis tərəfindən canlı oxunur.

### Vacib Android məhdudiyyəti
Adi Android tətbiqi öz-özünə ADB serverinə `adb shell` sessiyası aça və Accessibility icazəsini ilk dəfə səssiz şəkildə verə bilməz. İlk quraşdırmada ADB ilə `WRITE_SECURE_SETTINGS` grantı və input injector üçün Shizuku/shell səlahiyyəti lazımdır. Bundan sonra tətbiq Accessibility-ni öz daxilindən avtomatik aktiv saxlaya və boot-da servisi başlada bilər.
