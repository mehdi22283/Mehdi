package com.mehdi.keymapper;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.KeyEvent;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class MappingStore {
    public static final class Mapping {
        public int source, target;
        public boolean enabled;
        public Mapping(int source, int target, boolean enabled) { this.source=source; this.target=target; this.enabled=enabled; }
        public String sourceName(){ return KeyEvent.keyCodeToString(source).replace("KEYCODE_", ""); }
        public String targetName(){ return KeyEvent.keyCodeToString(target).replace("KEYCODE_", ""); }
    }
    private static final String PREF="mappings";
    private static final String JSON="list";
    private final SharedPreferences p;
    public MappingStore(Context c){ p=c.getSharedPreferences(PREF, Context.MODE_PRIVATE); ensureDefaults(); }
    private void ensureDefaults(){ if(p.contains(JSON)) return; List<Mapping> l=new ArrayList<>(); l.add(new Mapping(KeyEvent.KEYCODE_BUTTON_6,KeyEvent.KEYCODE_DPAD_LEFT,true)); l.add(new Mapping(KeyEvent.KEYCODE_BUTTON_5,KeyEvent.KEYCODE_DPAD_CENTER,true)); l.add(new Mapping(KeyEvent.KEYCODE_BUTTON_7,KeyEvent.KEYCODE_DPAD_RIGHT,true)); save(l); }
    public synchronized List<Mapping> get(){
        List<Mapping> out=new ArrayList<>();
        try { JSONArray a=new JSONArray(p.getString(JSON,"[]")); for(int i=0;i<a.length();i++){ JSONObject o=a.getJSONObject(i); out.add(new Mapping(o.getInt("s"),o.getInt("t"),o.optBoolean("e",true))); } } catch(Exception ignored){}
        return out;
    }
    public synchronized void save(List<Mapping> list){ try{ JSONArray a=new JSONArray(); for(Mapping m:list){ JSONObject o=new JSONObject(); o.put("s",m.source); o.put("t",m.target); o.put("e",m.enabled); a.put(o); } p.edit().putString(JSON,a.toString()).apply(); }catch(Exception ignored){} }
    public synchronized void add(Mapping m){ List<Mapping> l=get(); l.add(m); save(l); }
    public synchronized void update(int i, Mapping m){ List<Mapping> l=get(); if(i>=0&&i<l.size()){l.set(i,m);save(l);} }
    public synchronized void delete(int i){ List<Mapping> l=get(); if(i>=0&&i<l.size()){l.remove(i);save(l);} }
    public static int parseKey(String value){ String s=value.trim().toUpperCase(); if(!s.startsWith("KEYCODE_")) s="KEYCODE_"+s; try{return KeyEvent.class.getField(s).getInt(null);}catch(Exception e){try{return Integer.parseInt(value.trim());}catch(Exception x){return -1;}} }
}
