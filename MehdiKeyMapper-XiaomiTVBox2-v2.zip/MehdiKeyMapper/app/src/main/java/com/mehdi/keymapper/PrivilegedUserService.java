package com.mehdi.keymapper;

import android.hardware.input.InputManager;
import android.os.IBinder;
import android.os.SystemClock;
import android.view.KeyEvent;

import java.lang.reflect.Method;

/**
 * Runs as Shizuku shell/root identity. This is the privileged boundary that
 * allows real cross-application KeyEvent injection without using Accessibility
 * as a fake injector.
 */
public class PrivilegedUserService extends IKeyInjector.Stub {
    private Method injectInputEvent;
    private Object inputManager;

    public PrivilegedUserService() {
        initInputManager();
    }

    private void initInputManager() {
        try {
            Method getInstance = InputManager.class.getDeclaredMethod("getInstance");
            getInstance.setAccessible(true);
            inputManager = getInstance.invoke(null);
            injectInputEvent = InputManager.class.getDeclaredMethod(
                    "injectInputEvent", android.view.InputEvent.class, int.class);
            injectInputEvent.setAccessible(true);
        } catch (Throwable t) {
            inputManager = null;
            injectInputEvent = null;
        }
    }

    @Override
    public boolean ping() {
        return inputManager != null && injectInputEvent != null;
    }

    @Override
    public synchronized boolean inject(KeyEvent event) {
        if (event == null) return false;
        try {
            if (inputManager == null || injectInputEvent == null) initInputManager();
            if (inputManager == null || injectInputEvent == null) return false;
            Object result = injectInputEvent.invoke(inputManager, event, 0 /* async */);
            return result instanceof Boolean && (Boolean) result;
        } catch (Throwable ignored) {
            return false;
        }
    }

    @Override
    public synchronized String exec(String command) {
        if (command == null || command.trim().isEmpty()) return "";
        try {
            Process process = Runtime.getRuntime().exec(new String[]{"sh", "-c", command});
            // Most commands used here are intentionally fire-and-forget. Give
            // them a small window to start, then return any immediately useful text.
            process.waitFor();
            byte[] out = process.getInputStream().readAllBytes();
            return new String(out).trim();
        } catch (Throwable ignored) {
            return "";
        }
    }

    @Override
    public void destroyService() {
        System.exit(0);
    }
}
