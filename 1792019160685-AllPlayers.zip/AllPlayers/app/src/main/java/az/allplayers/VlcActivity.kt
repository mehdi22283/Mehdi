package az.allplayers

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

class VlcActivity : AppCompatActivity() {
    private var lib: LibVLC? = null
    private var mp: MediaPlayer? = null
    private lateinit var layout: VLCVideoLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        layout = VLCVideoLayout(this)
        setContentView(layout)
    }

    override fun onStart() {
        super.onStart()
        val url = intent.getStringExtra("url") ?: return finish()
        lib = LibVLC(this, arrayListOf("--network-caching=1500"))
        mp = MediaPlayer(lib).also {
            it.attachViews(layout, null, false, false)
            it.media = Media(lib, Uri.parse(url)).apply { setHWDecoderEnabled(true, false) }
            it.play()
        }
    }

    override fun onStop() {
        super.onStop()
        mp?.stop(); mp?.detachViews(); mp?.release(); lib?.release()
        mp = null; lib = null
    }
}
