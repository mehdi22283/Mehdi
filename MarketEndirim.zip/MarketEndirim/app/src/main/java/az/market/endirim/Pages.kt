package az.market.endirim

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import kotlin.math.sqrt
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.github.chrisbanes.photoview.PhotoView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class PageVH(val img: PhotoView) : RecyclerView.ViewHolder(img) {
    var job: Job? = null
}

private fun newPhotoView(parent: ViewGroup) = PhotoView(parent.context).apply {
    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    scaleType = ImageView.ScaleType.FIT_CENTER
    // yüksək keyfiyyətli səhifədə xırda yazılara qədər yaxınlaşdırmaq olsun
    mediumScale = 2.5f
    maximumScale = 6f
}

class ImageAdapter(private val urls: List<String>) : RecyclerView.Adapter<PageVH>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PageVH(newPhotoView(parent))
    override fun getItemCount() = urls.size
    override fun onBindViewHolder(holder: PageVH, position: Int) {
        // şəkil ekran ölçüsünə kiçildilmir — orijinal keyfiyyətdə (4096 px-ə qədər) yüklənir
        holder.img.load(urls[position]) {
            crossfade(true)
            size(4096)
        }
    }
}

/**
 * PDF səhifələrini slayd kimi göstərir (PdfRenderer, səhifə-səhifə).
 * Keyfiyyət: səhifə öz ölçüsünün ən azı 2 qatı (144 dpi) və ən azı widthPx enində render edilir;
 * yalnız GPU/yaddaş həddi (uzun tərəf 4096 px, ~9 milyon piksel) aşılanda kiçildilir.
 * Faylın özünə toxunulmur — diskdə serverdən gələn orijinal PDF saxlanır.
 */
class PdfAdapter(file: File, private val widthPx: Int, private val scope: CoroutineScope) :
    RecyclerView.Adapter<PageVH>() {

    private companion object {
        const val MAX_SIDE = 4096f
        const val MAX_PIXELS = 9_000_000f
    }

    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)

    // keş bayt ilə ölçülür (böyük bitmap-lər üçün "3 səhifə" sayı yaddaşı doldururdu)
    private val cache = object : LruCache<Int, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8).coerceIn(32L shl 20, Int.MAX_VALUE.toLong()).toInt()
    ) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.allocationByteCount
    }
    private var closed = false

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PageVH(newPhotoView(parent))
    override fun getItemCount() = renderer.pageCount

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        holder.job?.cancel()
        val cached = cache.get(position)
        if (cached != null) {
            holder.img.setImageBitmap(cached)
            return
        }
        holder.img.setImageDrawable(null)
        holder.job = scope.launch {
            val bmp = withContext(Dispatchers.IO) { render(position) } ?: return@launch
            cache.put(position, bmp)
            if (holder.bindingAdapterPosition == position) holder.img.setImageBitmap(bmp)
        }
    }

    override fun onViewRecycled(holder: PageVH) {
        holder.job?.cancel()
    }

    private fun render(i: Int): Bitmap? = synchronized(renderer) {
        if (closed) return null
        val page = renderer.openPage(i)
        try {
            // yaddaş çatmasa ölçü 30% azaldılıb təkrar cəhd olunur (tətbiq çökmür)
            var k = 1f
            var out: Bitmap? = null
            var attempt = 0
            while (out == null && attempt < 3) {
                try {
                    out = draw(page, k)
                } catch (e: OutOfMemoryError) {
                    k *= 0.7f
                }
                attempt++
            }
            out
        } finally {
            page.close()
        }
    }

    private fun draw(page: PdfRenderer.Page, shrink: Float): Bitmap {
        var w = maxOf(widthPx, page.width * 2).toFloat()
        var h = w * page.height / page.width
        var k = shrink
        val side = maxOf(w, h) * k
        if (side > MAX_SIDE) k *= MAX_SIDE / side
        val px = w * h * k * k
        if (px > MAX_PIXELS) k *= sqrt(MAX_PIXELS / px)
        w *= k
        h *= k
        val bmp = Bitmap.createBitmap(maxOf(w.toInt(), 1), maxOf(h.toInt(), 1), Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        return bmp
    }

    fun close() {
        synchronized(renderer) {
            if (closed) return
            closed = true
            renderer.close()
            pfd.close()
        }
    }
}
