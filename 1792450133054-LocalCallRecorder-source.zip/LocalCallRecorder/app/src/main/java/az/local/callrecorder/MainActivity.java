package az.local.callrecorder;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.Color;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity {
    public static final String PREFS = "local_recorder_prefs";
    public static final String KEY_FILTER = "call_filter";
    private static final int REQUEST_PERMISSIONS = 800;
    private LinearLayout root;
    private EditText ipInput, portInput;
    private TextView adbStatus, serviceStatus, recordsText, callsText, whatsappStatus;
    private Spinner filterSpinner;
    private String[] filterLabels = {"Bütün zənglər", "Gələn zənglər", "Gedən zənglər"};
    private String[] filterValues = {"all", "incoming", "outgoing"};
    private final int blue = Color.rgb(29, 77, 142);
    private final int dark = Color.rgb(31, 41, 55);
    private final int muted = Color.rgb(91, 102, 116);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        refreshInfo();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(32));
        root.setBackgroundColor(Color.rgb(247, 249, 252));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Lokal Zəng Yazıcı");
        title.setTextColor(dark); title.setTextSize(26); title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Telefon zəngləri · WhatsApp aşkarlanması · lokal fayllar");
        subtitle.setTextSize(14); subtitle.setTextColor(muted); subtitle.setPadding(0, dp(6), 0, dp(18));
        root.addView(subtitle);

        addSection("1. ADB portu");
        addLabel("Telefonun IP ünvanı");
        ipInput = new EditText(this); ipInput.setSingleLine(true); ipInput.setText("127.0.0.1"); ipInput.setHint("192.168.1.50");
        ipInput.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI );
        styleInput(ipInput); root.addView(ipInput);
        addLabel("Port");
        portInput = new EditText(this); portInput.setSingleLine(true); portInput.setText("5555");
        portInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); styleInput(portInput); root.addView(portInput);
        Button testAdb = button("ADB portunu yoxla"); root.addView(testAdb);
        adbStatus = addStatus("ADB portu hələ yoxlanmayıb.");
        testAdb.setOnClickListener(v -> checkAdbPort());
        TextView adbNote = addNote("Bu yoxlama yalnız IP:port TCP bağlantısını sınayır. ADB açar autentifikasiyası və shell icazəsi yaratmır. Adətən Android-də 5555 portunu əvvəlcədən USB ADB və ya Wireless debugging vasitəsilə aktivləşdirmək lazımdır.");
        root.addView(adbNote);

        addSection("2. Yazıcı xidməti");
        serviceStatus = addStatus("Xidmət dayandırılıb.");
        Button start = button("Xidməti başlat"); root.addView(start);
        start.setOnClickListener(v -> requestPermissionsAndStart());
        Button stop = button("Xidməti dayandır"); root.addView(stop);
        stop.setOnClickListener(v -> {
            startService(new Intent(this, RecordingService.class).setAction(RecordingService.ACTION_STOP));
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("service_started", false).apply();
            serviceStatus.setText("Xidmət dayandırılır.");
        });

        addSection("3. WhatsApp zəngləri");
        whatsappStatus = addStatus(whatsappAccessEnabled() ? "Bildiriş girişi aktivdir." : "Bildiriş girişi aktiv edilməyib.");
        Button access = button("WhatsApp müşahidəsini aktiv et"); root.addView(access);
        access.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
            catch (Exception e) { toast("Bildiriş ayarları açıla bilmədi."); }
        });
        root.addView(addNote("WhatsApp aşkarlanması bildiriş mətnindən asılı olan heuristikadır. Dəstəklənən mətn tapılmasa zəng aşkarlanmaya bilər; əvvəlcə xidməti başladın və Android ayarlarında bildiriş girişinə icazə verin."));

        addSection("4. Zəng filtri");
        filterSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, filterLabels);
        filterSpinner.setAdapter(adapter);
        String filter = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_FILTER, "all");
        filterSpinner.setSelection(indexForFilter(filter));
        root.addView(filterSpinner);
        filterSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_FILTER, filterValues[position]).apply();
                refreshCallLog();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        root.addView(addNote("Gələn/gedən filtri telefon zənglərinin istiqamətini izləyir. WhatsApp zəngində istiqamət bildirişdən etibarlı müəyyən edilmədiyinə görə yalnız “Bütün zənglər” filtri WhatsApp səsini yazmağa icazə verir."));

        addSection("Son telefon zəngləri");
        callsText = addStatus("Zəng siyahısı yüklənir…");
        Button reloadCalls = button("Zəng siyahısını yenilə"); root.addView(reloadCalls);
        reloadCalls.setOnClickListener(v -> refreshCallLog());

        addSection("Saxlanılmış yazılar");
        recordsText = addStatus("Hələ yazı yoxdur.");
        Button reloadFiles = button("Yazıları yenilə"); root.addView(reloadFiles);
        reloadFiles.setOnClickListener(v -> refreshRecordings());

        TextView footer = addNote("Məxfilik: fayllar bu tətbiqin şəxsi yaddaşında saxlanır. Telefon/WhatsApp zənginin iki tərəfli audiosunu adi Android tətbiqi ADB portu ilə zəmanətli yaza bilmir. Android və istehsalçı məhdudiyyətinə görə mikrofon audiosu səssiz qala bilər; tam zəng audiosu üçün cihaz səviyyəsində imtiyaz və ya xüsusi ROM/root tələb oluna bilər. Səs yazmadan əvvəl yerli qanunlara və iştirakçıların razılığına əməl edin.");
        footer.setPadding(0, dp(18), 0, 0);
        root.addView(footer);
    }

    private void requestPermissionsAndStart() {
        List<String> missing = new ArrayList<>();
        String[] required = {Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE};
        for (String p : required) if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS);
        // Call log is optional: it only populates the history list.
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.READ_CALL_LOG);
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
            return;
        }
        startRecorderService();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_PERMISSIONS) return;
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean phone = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
        if (!mic || !phone) {
            new AlertDialog.Builder(this).setTitle("İcazələr lazımdır")
                    .setMessage("Yazma üçün mikrofon, telefon zəngini aşkar etmək üçün Telefon vəziyyəti icazəsi tələb olunur.")
                    .setPositiveButton("Bağla", null).show();
        } else startRecorderService();
        refreshInfo();
    }

    private void startRecorderService() {
        Intent i = new Intent(this, RecordingService.class).setAction(RecordingService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("service_started", true).apply();
            serviceStatus.setText("Xidmət başladılıb. Daimi bildiriş görünməlidir.");
            toast("Zəng yazıcı xidməti başladıldı.");
        } catch (RuntimeException e) {
            serviceStatus.setText("Xidmət başlaya bilmədi. Tətbiqi ön plana gətirib yenidən yoxlayın.");
        }
    }

    private void checkAdbPort() {
        String host = ipInput.getText().toString().trim();
        String portString = portInput.getText().toString().trim();
        if (host.isEmpty() || portString.isEmpty()) { toast("IP və port daxil edin."); return; }
        int port;
        try { port = Integer.parseInt(portString); if (port < 1 || port > 65535) throw new NumberFormatException(); }
        catch (NumberFormatException e) { toast("Port 1–65535 aralığında olmalıdır."); return; }
        adbStatus.setText("TCP bağlantısı yoxlanılır…");
        new Thread(() -> {
            String result;
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(host, port), 2500);
                result = "TCP port açıqdır. ADB autentifikasiyası təsdiqlənməyib.";
            } catch (Exception e) {
                result = "Bağlantı alınmadı: " + e.getClass().getSimpleName() + ". IP, port, eyni şəbəkə və ADB ayarlarını yoxlayın.";
            }
            String finalResult = result;
            runOnUiThread(() -> adbStatus.setText(finalResult));
        }).start();
    }

    private void refreshInfo() {
        serviceStatus.setText("Xidmət vəziyyəti: " + (isServiceStartedPref() ? "son dəfə başladılıb" : "başladılma təsdiqlənməyib") + ". Bildiriş panelini yoxlayın.");
        whatsappStatus.setText(whatsappAccessEnabled() ? "Bildiriş girişi aktivdir." : "Bildiriş girişi aktiv edilməyib.");
        refreshCallLog();
        refreshRecordings();
    }

    private boolean isServiceStartedPref() { return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("service_started", false); }

    private boolean whatsappAccessEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return enabled != null && enabled.contains(getPackageName());
    }

    private void refreshCallLog() {
        if (callsText == null) return;
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            callsText.setText("Zəng siyahısı üçün READ_CALL_LOG icazəsi verilməyib."); return;
        }
        String filter = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_FILTER, "all");
        List<String> rows = new ArrayList<>();
        String[] projection = {CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.TYPE};
        try (Cursor c = getContentResolver().query(CallLog.Calls.CONTENT_URI, projection, null, null, CallLog.Calls.DATE + " DESC")) {
            if (c != null) {
                int n = 0;
                while (c.moveToNext() && n < 100) {
                    String number = c.getString(0);
                    long date = c.getLong(1);
                    long duration = c.getLong(2);
                    int type = c.getInt(3);
                    boolean incoming = type == CallLog.Calls.INCOMING_TYPE || type == CallLog.Calls.MISSED_TYPE || type == CallLog.Calls.REJECTED_TYPE || type == CallLog.Calls.BLOCKED_TYPE;
                    boolean outgoing = type == CallLog.Calls.OUTGOING_TYPE;
                    if ("incoming".equals(filter) && !incoming) continue;
                    if ("outgoing".equals(filter) && !outgoing) continue;
                    String kind = incoming ? "Gələn" : outgoing ? "Gedən" : "Digər";
                    String when = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(date));
                    rows.add(kind + " · " + (number == null ? "Naməlum nömrə" : number) + "\n" + when + " · " + duration + " san.");
                    n++;
                    if (rows.size() >= 20) break;
                }
            }
        } catch (SecurityException e) {
            callsText.setText("Zəng jurnalına giriş rədd edildi."); return;
        } catch (Exception e) {
            callsText.setText("Zəng jurnalı oxuna bilmədi."); return;
        }
        callsText.setText(rows.isEmpty() ? "Bu filtr üzrə zəng tapılmadı." : android.text.TextUtils.join("\n\n", rows));
    }

    private void refreshRecordings() {
        if (recordsText == null) return;
        File base = getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC);
        File folder = base == null ? null : new File(base, "Recordings");
        File[] files = folder != null ? folder.listFiles((dir, name) -> name.endsWith(".m4a")) : null;
        if (files == null || files.length == 0) { recordsText.setText("Hələ yazı yoxdur. Fayllar tətbiqin şəxsi Recordings qovluğunda saxlanır."); return; }
        List<File> sorted = new ArrayList<>(); Collections.addAll(sorted, files);
        Collections.sort(sorted, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < Math.min(15, sorted.size()); i++) {
            File f = sorted.get(i);
            text.append(f.getName()).append("\n").append(String.format(java.util.Locale.getDefault(), "%.1f KB", f.length() / 1024.0)).append("\n\n");
        }
        recordsText.setText(text.toString().trim());
    }

    private int indexForFilter(String value) {
        for (int i = 0; i < filterValues.length; i++) if (filterValues[i].equals(value)) return i;
        return 0;
    }

    private void addSection(String text) {
        TextView tv = new TextView(this); tv.setText(text); tv.setTextSize(18); tv.setTypeface(null, Typeface.BOLD); tv.setTextColor(blue);
        tv.setPadding(0, dp(22), 0, dp(8)); root.addView(tv);
    }
    private void addLabel(String text) {
        TextView tv = new TextView(this); tv.setText(text); tv.setTextColor(dark); tv.setTextSize(14); tv.setPadding(0, dp(6), 0, dp(4)); root.addView(tv);
    }
    private TextView addStatus(String text) {
        TextView tv = new TextView(this); tv.setText(text); tv.setTextSize(14); tv.setTextColor(dark); tv.setPadding(dp(12), dp(10), dp(12), dp(10));
        tv.setBackgroundColor(Color.WHITE); root.addView(tv, fullWidth()); return tv;
    }
    private TextView addNote(String text) {
        TextView tv = new TextView(this); tv.setText(text); tv.setTextSize(12); tv.setTextColor(muted); tv.setPadding(0, dp(8), 0, dp(8)); return tv;
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        LinearLayout.LayoutParams lp = fullWidth(); lp.topMargin = dp(8); lp.bottomMargin = dp(4); b.setLayoutParams(lp); return b;
    }
    private void styleInput(EditText e) {
        e.setTextSize(16); e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        LinearLayout.LayoutParams lp = fullWidth(); lp.bottomMargin = dp(4); e.setLayoutParams(lp);
    }
    private LinearLayout.LayoutParams fullWidth() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); }
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }

    @Override protected void onResume() { super.onResume(); if (root != null) refreshInfo(); }
}
