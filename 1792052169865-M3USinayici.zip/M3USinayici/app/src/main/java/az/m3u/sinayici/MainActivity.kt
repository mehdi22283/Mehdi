package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.provider.OpenableColumns
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var prevLogin = ""
    private val pool = Executors.newFixedThreadPool(24)
    /** Yoxlama (tester) üçün ayrıca geniş axın hovuzu: digər işləri (fayl, GitHub) gözlətmir. */
    private val probePool = Executors.newFixedThreadPool(160)
    private val probeOut = java.util.concurrent.ConcurrentLinkedQueue<String>()
    private val probeFlush = java.util.concurrent.atomic.AtomicBoolean(false)

    /** Nəticələr toplanıb ~40 ms-də bir dəfə JS-ə göndərilir (hər kanal üçün ayrıca çağırış WebView-u yavaşladırdı). */
    private fun pushProbe(id: Int, r: String) {
        probeOut.add("[$id,'$r']")
        if (probeFlush.compareAndSet(false, true)) web.postDelayed({
            probeFlush.set(false)
            val sb = StringBuilder()
            while (true) { val x = probeOut.poll() ?: break; if (sb.isNotEmpty()) sb.append(','); sb.append(x) }
            if (sb.isNotEmpty()) web.evaluateJavascript("if(window.__probeBatch)__probeBatch([$sb])", null)
        }, 25)
    }
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var ghCfg: JSONObject? = null
    private var pendingName = ""
    private var pendingText = ""
    /** Xarici tətbiqdən (fayl meneceri, Paylaş) gələn .m3u/.m3u8 faylları: JS götürənə qədər burada gözləyir. */
    private val pendingExt = ArrayList<Pair<String, String>>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("m3u", MODE_PRIVATE)
        prevLogin = sp.getString("lastLogin", "") ?: ""
        sp.edit().putString("lastLogin", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())).apply()
        web = WebView(this); setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = true
            allowFileAccessFromFileURLs = true; allowUniversalAccessFromFileURLs = true
        }
        web.addJavascriptInterface(Bridge(), "Android")
        ApkWatchService.listener = { t, pct -> runOnUiThread { web.evaluateJavascript("if(window.ghApkStatus)ghApkStatus(" + JSONObject.quote(t) + "," + pct + ")", null) } }
        if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                val pick = Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                if (p?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                startActivityForResult(pick, 2)
                return true
            }
            override fun onJsAlert(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r?.confirm() }
                    .setOnCancelListener { r?.cancel() }.show(); return true
            }
            override fun onJsConfirm(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r?.confirm() }
                    .setNegativeButton("Ləğv et") { _, _ -> r?.cancel() }.setOnCancelListener { r?.cancel() }.show(); return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        if (b == null) handleExternalIntent(intent)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (PlayerPanel.handleBack()) return; super.onBackPressed() }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        if (i != null) { setIntent(i); handleExternalIntent(i) }
    }

    /** .m3u/.m3u8 faylı başqa tətbiqdən "Bununla aç" / "Paylaş" ilə gələndə oxuyub 2-ci playlistə yükləməyə hazırlayır. */
    @Suppress("DEPRECATION")
    private fun handleExternalIntent(i: Intent?) {
        if (i == null) return
        if ((i.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) return
        if (i.hasExtra("importList")) {
            val n = i.getIntExtra("importList", 1); i.removeExtra("importList")
            web.postDelayed({ web.evaluateJavascript("ottImportFromNative($n)", null) }, 1200)
            return
        }
        val link = i.data
        if (i.action == Intent.ACTION_VIEW && link != null && (link.scheme == "http" || link.scheme == "https")) {
            openExternalLink(link.toString()); return
        }
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_VIEW -> i.data?.let { uris.add(it) }
            Intent.ACTION_SEND -> (if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> (if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM))?.let { uris.addAll(it) }
            else -> return
        }
        if (uris.isEmpty()) return
        pool.execute {
            var added = 0
            for (u in uris) {
                try {
                    var name = ""
                    if (u.scheme == "content") {
                        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                            if (c.moveToFirst()) name = c.getString(0) ?: ""
                        }
                    }
                    if (name.isEmpty()) name = u.lastPathSegment?.substringAfterLast('/') ?: "playlist.m3u"
                    val bytes = contentResolver.openInputStream(u)?.use { it.readBytes() } ?: continue
                    if (bytes.size > 30 * 1024 * 1024) continue
                    var text = String(bytes, Charsets.UTF_8)
                    if (text.startsWith("\uFEFF")) text = text.substring(1)
                    synchronized(pendingExt) { pendingExt.add(Pair(name, text)) }
                    added++
                } catch (e: Exception) { /* oxunmayan fayl keçilir */ }
            }
            runOnUiThread {
                if (added == 0) Toast.makeText(this, "Fayl oxunmadı", Toast.LENGTH_LONG).show()
                else web.evaluateJavascript("if(window.loadExternalPlaylists)loadExternalPlaylists()", null)
            }
        }
    }

    /** Xarici yerdən gələn http(s) .m3u8 linki: yayımdırsa tətbiqin playerində açır; kanal siyahısıdırsa playlist kimi yükləyir. */
    private fun openExternalLink(url: String) {
        Toast.makeText(this, "Link açılır...", Toast.LENGTH_SHORT).show()
        pool.execute {
            var isList = false
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                c.setRequestProperty("User-Agent", Net.CHROME)
                val b = ByteArray(65536); var n = 0
                c.inputStream.use { ins -> while (n < b.size) { val r = ins.read(b, n, b.size - n); if (r < 0) break; n += r } }
                c.disconnect()
                val head = String(b, 0, n, Charsets.UTF_8)
                isList = head.contains("#EXTINF") && !head.contains("#EXT-X-")
                if (isList) {
                    val c2 = URL(url).openConnection() as HttpURLConnection
                    c2.connectTimeout = 10000; c2.readTimeout = 30000
                    c2.setRequestProperty("User-Agent", Net.CHROME)
                    var text = c2.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
                    c2.disconnect()
                    if (text.startsWith("\uFEFF")) text = text.substring(1)
                    val nm = Uri.decode(Uri.parse(url).lastPathSegment ?: "playlist.m3u8")
                    synchronized(pendingExt) { pendingExt.add(Pair(nm, text)) }
                }
            } catch (e: Exception) { isList = false }      // yoxlanmadısa yenə də playerdə açılır
            runOnUiThread {
                if (isList) web.evaluateJavascript("if(window.loadExternalPlaylists)loadExternalPlaylists()", null)
                else {
                    val name = Uri.decode(Uri.parse(url).lastPathSegment ?: url)
                    PlayQueue.items = listOf(QItem(name, url, "{}")); PlayQueue.index = 0
                    PlayerPanel.open(this)
                }
            }
        }
    }

    override fun onDestroy() {
        ApkWatchService.listener = null
        try { Media3Verifier.cancel() } catch (e: Exception) { }
        probePool.shutdownNow(); pool.shutdown()
        try { web.removeJavascriptInterface("Android"); web.stopLoading(); (web.parent as? android.view.ViewGroup)?.removeView(web); web.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("if(window.syncLast)syncLast();if(window.syncExo)syncExo();if(window.loadExternalPlaylists)loadExternalPlaylists()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq == 2) {
            var res: Array<Uri>? = null
            if (rs == RESULT_OK && d != null) {
                val cd = d.clipData
                res = if (cd != null && cd.itemCount > 0) Array(cd.itemCount) { k -> cd.getItemAt(k).uri }
                      else d.data?.let { arrayOf(it) }
            }
            fileCb?.onReceiveValue(res); fileCb = null
        } else if (rq == 1 && rs == RESULT_OK) web.evaluateJavascript("ottImportFromNative(" + (d?.getIntExtra("list", 1) ?: 1) + ")", null)
        else if (rq == 4 && rs == RESULT_OK && d?.data != null) ghUpload(d.data!!)
    }

    /** Playlisti Downloads qovluğuna yazır (Android 10+: MediaStore, əvvəlki: birbaşa fayl). */
    private fun writeToDownloads(name: String, text: String) {
        try {
            val bytes = text.toByteArray(Charsets.UTF_8)
            val shown: String
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "audio/x-mpegurl")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: throw java.io.IOException("Fayl yaradıla bilmədi")
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                shown = name
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                var f = File(dir, name); var i = 1
                while (f.exists()) { f = File(dir, name.substringBeforeLast('.') + " ($i)." + name.substringAfterLast('.')); i++ }
                f.writeBytes(bytes)
                shown = f.name
            }
            DlNotif(this, shown, bytes.size.toLong()).finish(shown)
            Toast.makeText(this, "Downloads qovluğuna yazıldı: $shown", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            DlNotif(this, name, 0).fail(e.message ?: e.toString())
            Toast.makeText(this, "İxrac xətası: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportPlaylist(name: String, text: String) {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingName = name; pendingText = text
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 3)
        } else writeToDownloads(name, text)
    }

    override fun onRequestPermissionsResult(rq: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(rq, p, g)
        if (rq == 3) {
            if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) writeToDownloads(pendingName, pendingText)
            else Toast.makeText(this, "İcazə verilmədi", Toast.LENGTH_LONG).show()
            pendingText = ""
        }
    }

    // ---------- GitHub: fayl seç və yüklə (native) ----------
    private fun encPath(p: String) = p.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    private fun apkStatus(text: String, pct: Int = -1) {
        runOnUiThread { web.evaluateJavascript("if(window.ghApkStatus)ghApkStatus(" + JSONObject.quote(text) + "," + pct + ")", null) }
    }

    private fun upProgress(pct: Int, text: String) {
        runOnUiThread { web.evaluateJavascript("if(window.ghUpProgress)ghUpProgress(" + pct + "," + JSONObject.quote(text) + ")", null) }
    }

    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 6)
    }

    private fun startApkWatch(repo: String, token: String, since: Long) {
        askNotifPermission()
        ApkWatchService.watch(this, repo, token, since)
        apkStatus("⏳ Actions izlənir — APK hazır olanda bildiriş gələcək")
    }

    /** "APK yüklə": son action-a baxır. Hazırdırsa APK-nı Downloads-a endirir, gedirsə izləyib xəbər edir. */
    private fun apkCheck(cfgJson: String) {
        val cfg = try { JSONObject(cfgJson) } catch (e: Exception) { apkStatus("❌ GitHub ayarları oxunmadı"); return }
        val repo = cfg.optString("repo", "").trim().trim('/').ifEmpty { "mehdi22283/Mehdi" }
        val token = cfg.optString("token", "")
        askNotifPermission()
        apkStatus("🔎 Son action yoxlanır...")
        Thread {
            try {
                val run = ApkTool.latestRun(repo, token, 0L)
                if (run == null) { apkStatus("⚠️ Actions-da heç bir build tapılmadı"); return@Thread }
                val st = run.optString("status")
                if (st != "completed") {
                    runOnUiThread { ApkWatchService.watch(this, repo, token, ApkTool.epoch(run.optString("created_at")) - 1000) }
                    apkStatus("⏳ Build gedir ($st) — hazır olanda bildiriş gələcək"); return@Thread
                }
                val concl = run.optString("conclusion")
                if (concl != "success") { apkStatus("❌ Son build uğursuz oldu ($concl)"); return@Thread }
                val art = ApkTool.artifact(repo, token, run.getLong("id"))
                if (art == null) { apkStatus("⚠️ Son build-də APK artifact tapılmadı (vaxtı bitmiş ola bilər)"); return@Thread }
                runOnUiThread { ApkWatchService.download(this, repo, token, art.getLong("id"), art.optLong("size_in_bytes", 0L)) }
                apkStatus("⬇️ ${art.optString("name")}.zip endirilir — faiz bildirişdə də görünür")
            } catch (e: Exception) { apkStatus("❌ " + (e.message ?: e.toString())) }
        }.start()
    }

    private fun ghUpload(uri: Uri) {
        val cfg = ghCfg ?: return
        var name = "file"; var size = -1L
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst()) {
                name = it.getString(0) ?: name
                if (!it.isNull(1)) size = it.getLong(1)
            }
        }
        ghUploadStream(cfg, name, size) { contentResolver.openInputStream(uri) ?: throw IOException("Fayl oxuna bilmədi") }
    }

    /** İxrac: playlisti Downloads-a yox, yalnız GitHub "Fayl seç və yüklə" bölməsinin repo qoşulmasına yükləyir. */
    private fun ghUploadText(cfgJson: String, name: String, text: String) {
        val cfg = try { JSONObject(cfgJson) } catch (e: Exception) {
            Toast.makeText(this, "GitHub ayarları oxunmadı", Toast.LENGTH_LONG).show(); return
        }
        val bytes = text.toByteArray(Charsets.UTF_8)
        ghUploadStream(cfg, name, bytes.size.toLong()) { java.io.ByteArrayInputStream(bytes) }
    }

    /**
     * Maksimum sürətli yükləmə: fayl yaddaşa tam oxunmur və base64 mətni də yaddaşda yığılmır.
     * HTTP gövdəsi (JSON + base64) sabit uzunluqlu axınla (setFixedLengthStreamingMode) birbaşa şəbəkəyə yazılır,
     * HttpURLConnection-un bütün gövdəni bufer etməsi söndürülür. GitHub Contents API limiti: 100 MB.
     */
    private fun ghUploadStream(cfg: JSONObject, name: String, size: Long, open: () -> java.io.InputStream) {
        web.evaluateJavascript("if(window.ghNativeBusy)ghNativeBusy()", null)
        Thread {
            val res = JSONObject()
            try {
                if (size > 75L * 1024 * 1024) throw IOException("Fayl çox böyükdür (GitHub API limiti: base64 ilə ~100 MB, yəni fayl maks. ~75 MB)")
                val repo = cfg.getString("repo").trim().trim('/')
                val branch = cfg.optString("branch", "main").ifEmpty { "main" }
                val folder = cfg.optString("folder", "").trim().trim('/')
                val safe = name.replace(Regex("[^\\w.\\-]+"), "_")
                val stamped = "${System.currentTimeMillis()}-$safe"
                val path = if (folder.isNotEmpty()) "$folder/$stamped" else stamped
                val head = ("{\"message\":" + JSONObject.quote("M3U Sınayıcı: \"$name\" yükləndi") +
                    ",\"branch\":" + JSONObject.quote(branch) + ",\"content\":\"").toByteArray(Charsets.UTF_8)
                val tail = "\"}".toByteArray(Charsets.UTF_8)
                // faktiki ölçü: ölçü məlum deyilsə əvvəlcə say
                val len = if (size >= 0) size else open().use { ins -> var n = 0L; val b = ByteArray(256 * 1024); while (true) { val r = ins.read(b); if (r < 0) break; n += r }; n }
                if (len > 75L * 1024 * 1024) throw IOException("Fayl çox böyükdür (maks. ~75 MB)")
                val b64len = 4L * ((len + 2) / 3)
                val c = URL("https://api.github.com/repos/$repo/contents/${encPath(path)}").openConnection() as HttpURLConnection
                c.requestMethod = "PUT"; c.doOutput = true
                c.connectTimeout = 20000; c.readTimeout = 120000
                c.setFixedLengthStreamingMode(head.size + b64len + tail.size)
                val tk = cfg.getString("token").replace(Regex("(?i)^\\s*(bearer|token)\\s+"), "").replace(Regex("[\\s\"']+"), "")
                c.setRequestProperty("Authorization", "Bearer $tk")
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Accept-Encoding", "identity")
                c.setRequestProperty("User-Agent", "M3USinayici")
                val t0 = System.currentTimeMillis(); var lastT = 0L; var lastPct = -1
                c.outputStream.buffered(256 * 1024).use { out ->
                    out.write(head)
                    // 3 baytın qatı olan hissələrlə base64 (şəbəkəyə birbaşa axır)
                    val chunk = 3 * 85_000                         // ~255 KB
                    val buf = ByteArray(chunk)
                    var sent = 0L
                    open().use { ins ->
                        while (true) {
                            var n = 0
                            while (n < chunk) { val r = ins.read(buf, n, chunk - n); if (r < 0) break; n += r }
                            if (n == 0) break
                            out.write(Base64.encode(buf, 0, n, Base64.NO_WRAP))
                            sent += n
                            val now = System.currentTimeMillis()
                            val pct = if (len > 0) ((sent * 100) / len).toInt().coerceIn(0, 100) else 100
                            if (pct != lastPct && now - lastT > 250) {
                                lastT = now; lastPct = pct
                                val sp = sent / 1048576.0 / maxOf(0.001, (now - t0) / 1000.0)
                                upProgress(pct, String.format(Locale.US, "%d%% — %.1f / %.1f MB · %.1f MB/s", pct, sent / 1048576.0, len / 1048576.0, sp))
                            }
                            if (n < chunk) break
                        }
                    }
                    out.write(tail)
                }
                upProgress(100, "Server cavabı gözlənilir...")
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                c.disconnect()
                val j = try { JSONObject(txt) } catch (e: Exception) { JSONObject() }
                if (code == 401) throw IOException("Token yanlışdır, vaxtı bitib və ya ləğv edilib (401). GitHub-da yeni token yaradıb \"GitHub-a daxil ol\" bölməsində yeniləyin.")
                if (code == 403 || code == 404) throw IOException(j.optString("message", "HTTP $code") + " — token bu repoya yazma icazəsinə (Contents: Read and write) malik olmaya bilər, ya da repo adı səhvdir.")
                if (code !in 200..299) throw IOException(j.optString("message", "GitHub xətası (HTTP $code)"))
                val content = j.getJSONObject("content")
                val p = content.getString("path")
                res.put("ok", true).put("name", name).put("path", p).put("sha", content.getString("sha"))
                    .put("rawUrl", "https://raw.githubusercontent.com/$repo/$branch/${encPath(p)}")
                    .put("blobUrl", "https://github.com/$repo/blob/$branch/${encPath(p)}")
                if (name.endsWith(".zip", true)) {
                    val since = try { ApkTool.epoch(j.getJSONObject("commit").getJSONObject("committer").getString("date")) - 5000 }
                        catch (e: Exception) { System.currentTimeMillis() - 60000 }
                    res.put("apkWatch", true)
                    runOnUiThread { startApkWatch(repo, tk, since) }
                }
            } catch (e: Exception) {
                res.put("ok", false).put("error", e.message ?: e.toString())
            }
            runOnUiThread { web.evaluateJavascript("ghNativeDone(" + JSONObject.quote(res.toString()) + ")", null) }
        }.start()
    }

    inner class Bridge {
        /** JS çağırır: xarici tətbiqdən gələn faylları [{name,text}] kimi qaytarır və növbəni təmizləyir. */
        @JavascriptInterface fun takeExternalFiles(): String {
            val out = JSONArray()
            synchronized(pendingExt) {
                pendingExt.forEach { out.put(JSONObject().put("name", it.first).put("text", it.second)) }
                pendingExt.clear()
            }
            return out.toString()
        }
        @JavascriptInterface fun openChannelSearch(n: Int, json: String) {
            val arr = JSONArray(json)
            val chans = ArrayList<ChannelSearch.Ch>(arr.length())
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                chans.add(ChannelSearch.Ch(a.getString(0), a.optString(1).ifEmpty { "Digər" }, a.getString(2), a.optJSONObject(3)?.toString() ?: "{}", n))
            }
            runOnUiThread { ChannelSearch.show(this@MainActivity, n, chans) }
        }
        @JavascriptInterface fun openOtt() = runOnUiThread { startActivityForResult(Intent(this@MainActivity, BrowserActivity::class.java), 1) }
        /** Mini brauzer: ünvan qutusu olan sərbəst brauzer. */
        @JavascriptInterface fun openMini() = runOnUiThread {
            if (MiniBrowser.isOpen()) Toast.makeText(this@MainActivity, "Mini brauzer artıq açıqdır", Toast.LENGTH_SHORT).show()
            else startActivityForResult(Intent(this@MainActivity, BrowserActivity::class.java).putExtra("mini", true), 1)
        }
        /** ExoPlayer-in xəta verdiyi kanalların linkləri (JSON massiv). */
        @JavascriptInterface fun getExoFailed(): String = JSONArray(Net.exoFailedList()).toString()
        @JavascriptInterface fun playQueue(json: String, index: Int) {
            val arr = JSONArray(json)
            val list = ArrayList<QItem>(arr.length())
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                list.add(QItem(a.getString(0), a.getString(1), a.optJSONObject(2)?.toString() ?: "{}"))
            }
            PlayQueue.items = list; PlayQueue.index = index
            runOnUiThread { PlayerPanel.open(this@MainActivity) }
        }
        /** Tester bitəndən sonra 🔴 kanalı ExoPlayer ilə yoxla (nəticə: __verifyDone(id, true/false)). */
        @JavascriptInterface fun verifyExo(url: String, hdr: String, id: Int) {
            Media3Verifier.add(this@MainActivity, url, hdr) { ok ->
                web.evaluateJavascript("__verifyDone($id,$ok)", null)
            }
        }
        @JavascriptInterface fun verifyCancel() { Media3Verifier.cancel() }
        /** Playlist nömrəsi (tag) ilə: iki playlist paralel yoxlanır, ləğv də ayrı-ayrılıqdadır. */
        @JavascriptInterface fun verifyExoT(url: String, hdr: String, id: Int, tag: Int) {
            Media3Verifier.add(this@MainActivity, url, hdr, tag) { ok ->
                web.evaluateJavascript("__verifyDone($id,$ok)", null)
            }
        }
        @JavascriptInterface fun verifyCancelT(tag: Int) { Media3Verifier.cancel(tag) }
        @JavascriptInterface fun probe(url: String, hdr: String, id: Int) {
            probePool.execute {
                val r = try { Net.probe(url, hdr) } catch (e: Throwable) { "dead" }
                pushProbe(id, r)
            }
        }
        @JavascriptInterface fun getSavedPlaylist(): String {
            val f = File(filesDir, "playlist1.m3u"); return if (f.exists()) f.readText() else ""
        }
        @JavascriptInterface fun getSavedPlaylist2(): String {
            val f = File(filesDir, "playlist2.m3u"); return if (f.exists()) f.readText() else ""
        }
        @JavascriptInterface fun getSavedPlaylist2Url(): String {
            val f = File(filesDir, "playlist2.url"); return if (f.exists()) f.readText().trim() else ""
        }
        @JavascriptInterface fun getLastLogin(): String = prevLogin
        /** GitHub axtarışı üçün daxili brauzer: tapılan playlist [list]-ci siyahıya yüklənir; token API limiti üçündür. */
        @JavascriptInterface fun openBrowser(url: String, list: Int, token: String) = runOnUiThread {
            startActivityForResult(Intent(this@MainActivity, BrowserActivity::class.java)
                .putExtra("url", url).putExtra("list", list).putExtra("token", token), 1)
        }
        /** "APK yüklə": Actions səhifəsi; orada endirilən zip faylı açılıb Downloads-a yazılır. */
        @JavascriptInterface fun apkCheck(cfgJson: String) = runOnUiThread { this@MainActivity.apkCheck(cfgJson) }
        /** Son endirilmiş APK-nı quraşdırır (yoxdursa false). */
        @JavascriptInterface fun apkInstall(): Boolean { runOnUiThread { askNotifPermission() }; return ApkWatchService.install(this@MainActivity) }
        @JavascriptInterface fun apkHasFile(): Boolean = ApkTool.lastApk(this@MainActivity) != null
        @JavascriptInterface fun openApkPage(url: String) = runOnUiThread {
            startActivityForResult(Intent(this@MainActivity, BrowserActivity::class.java)
                .putExtra("url", url).putExtra("list", 2).putExtra("apk", true), 1)
        }
        @JavascriptInterface fun ghPick(cfgJson: String) = runOnUiThread {
            try {
                ghCfg = JSONObject(cfgJson)
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 4)
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "Fayl seçici açılmadı: ${e.message}", Toast.LENGTH_LONG).show() }
        }
        @JavascriptInterface fun ghExport(cfgJson: String, name: String, text: String) = runOnUiThread {
            try { ghUploadText(cfgJson, name, text) }
            catch (e: Exception) { Toast.makeText(this@MainActivity, "İxrac xətası: ${e.message}", Toast.LENGTH_LONG).show() }
        }
        @JavascriptInterface fun getLastUrl(): String = getSharedPreferences("m3u", MODE_PRIVATE).getString("lastUrl", "") ?: ""
        @JavascriptInterface fun saveToDownloads(name: String, text: String) = runOnUiThread { exportPlaylist(name, text) }
    }
}
