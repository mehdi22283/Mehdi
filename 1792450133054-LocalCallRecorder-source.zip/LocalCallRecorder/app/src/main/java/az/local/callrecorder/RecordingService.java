package az.local.callrecorder;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.Settings;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecordingService extends Service {
    public static final String ACTION_START = "az.local.callrecorder.START";
    public static final String ACTION_STOP = "az.local.callrecorder.STOP";
    public static final String ACTION_WA_START = "az.local.callrecorder.WHATSAPP_START";
    public static final String ACTION_WA_STOP = "az.local.callrecorder.WHATSAPP_STOP";
    public static final String CHANNEL_SERVICE = "recorder_service";
    public static final String CHANNEL_EVENTS = "recorder_events";
    private static final int ONGOING_ID = 4101;
    private static final int EVENT_ID = 4102;

    private TelephonyManager telephonyManager;
    private PhoneStateListener phoneStateListener;
    private MediaRecorder recorder;
    private File activeFile;
    private boolean isRecording = false;
    private String currentSource = "Telefon";
    private String currentDirection = "unknown";
    private String pendingPhoneDirection = "unknown";

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels();
        startForegroundNow("Xidmət aktivdir — zəng gözlənilir");
        registerPhoneListener();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopCapture(true);
            unregisterPhoneListener();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        } else if (ACTION_WA_START.equals(action)) {
            startCapture("WhatsApp", "unknown");
        } else if (ACTION_WA_STOP.equals(action)) {
            if ("WhatsApp".equals(currentSource)) stopCapture(true);
            updateOngoing(isRecording ? recordingText() : "Xidmət aktivdir — zəng gözlənilir");
        } else if (ACTION_START.equals(action)) {
            startForegroundNow(isRecording ? recordingText() : "Xidmət aktivdir — zəng gözlənilir");
        }
        return START_STICKY;
    }

    private void registerPhoneListener() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return;
        telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if (telephonyManager == null) return;
        phoneStateListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                if (state == TelephonyManager.CALL_STATE_RINGING) {
                    pendingPhoneDirection = "incoming";
                } else if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
                    if ("unknown".equals(pendingPhoneDirection)) pendingPhoneDirection = "outgoing";
                    startCapture("Telefon", pendingPhoneDirection);
                } else if (state == TelephonyManager.CALL_STATE_IDLE) {
                    if ("Telefon".equals(currentSource)) stopCapture(true);
                    pendingPhoneDirection = "unknown";
                    updateOngoing(isRecording ? recordingText() : "Xidmət aktivdir — zəng gözlənilir");
                }
            }
        };
        try {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        } catch (SecurityException ignored) {
            // Permission may have been revoked in Settings while the service was alive.
        }
    }

    private void unregisterPhoneListener() {
        if (telephonyManager != null && phoneStateListener != null) {
            try { telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE); }
            catch (Exception ignored) { }
        }
    }

    private boolean filterAllows(String direction) {
        String filter = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getString(MainActivity.KEY_FILTER, "all");
        if ("all".equals(filter)) return true;
        if ("incoming".equals(filter)) return "incoming".equals(direction);
        if ("outgoing".equals(filter)) return "outgoing".equals(direction);
        return true;
    }

    private void startCapture(String source, String direction) {
        if (isRecording) return;
        if (!filterAllows(direction)) {
            updateOngoing("Filtr səbəbilə yazılmır: " + directionLabel(direction));
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            updateOngoing("Mikrofon icazəsi yoxdur");
            return;
        }
        currentSource = source;
        currentDirection = direction;
        File baseFolder = getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (baseFolder == null) {
            updateOngoing("Yaddaş qovluğuna giriş yoxdur");
            return;
        }
        File folder = new File(baseFolder, "Recordings");
        if (!folder.exists() && !folder.mkdirs()) {
            updateOngoing("Qovluq yaradıla bilmədi");
            return;
        }
        String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date());
        activeFile = new File(folder, source.toLowerCase(Locale.ROOT) + "_" + stamp + ".m4a");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) recorder = new MediaRecorder(this);
            else recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(96000);
            recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(activeFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            isRecording = true;
            updateOngoing(recordingText());
            showEvent("Yazma başladı", source + " zəngi üçün mikrofon yazısı başladıldı");
        } catch (Exception e) {
            releaseRecorder();
            if (activeFile != null && activeFile.exists()) activeFile.delete();
            activeFile = null;
            isRecording = false;
            updateOngoing("Yazma başlaya bilmədi — mikrofon əlçatan deyil");
            showEvent("Yazma başlamadı", "Android mikrofon yazısını blokladı və ya cihaz dəstəkləmir");
        }
    }

    private void stopCapture(boolean notifyIfSaved) {
        if (!isRecording) return;
        File saved = activeFile;
        boolean valid = false;
        try {
            recorder.stop();
            valid = saved != null && saved.exists() && saved.length() > 1024;
        } catch (RuntimeException ignored) {
            // MediaRecorder.stop() throws if no valid audio frames were captured.
        } finally {
            releaseRecorder();
            isRecording = false;
            activeFile = null;
        }
        if (valid) {
            String message = "Mikrofon yazısı saxlanıldı: " + saved.getName();
            if (notifyIfSaved) showEvent("Zəng yazıldı", message);
            getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                    .putString("last_recording", saved.getAbsolutePath()).apply();
        } else if (notifyIfSaved) {
            showEvent("Yazı saxlanılmadı", "Etibarlı audio yaranmadı. Android zəng zamanı mikrofonu bloklamış ola bilər.");
        }
        currentSource = "Telefon";
        currentDirection = "unknown";
    }

    private void releaseRecorder() {
        if (recorder != null) {
            try { recorder.reset(); } catch (Exception ignored) { }
            try { recorder.release(); } catch (Exception ignored) { }
            recorder = null;
        }
    }

    private String recordingText() {
        return "YAZILIR: " + currentSource + " — " + directionLabel(currentDirection);
    }

    private String directionLabel(String direction) {
        if ("incoming".equals(direction)) return "gələn zəng";
        if ("outgoing".equals(direction)) return "gedən zəng";
        return "istiqamət naməlum";
    }

    private void startForegroundNow(String text) {
        Notification n = buildOngoing(text);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                startForeground(ONGOING_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } catch (Exception e) {
                startForeground(ONGOING_ID, n);
            }
        } else {
            startForeground(ONGOING_ID, n);
        }
    }

    private void updateOngoing(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(ONGOING_ID, buildOngoing(text));
    }

    private Notification buildOngoing(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 1, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stopIntent = new Intent(this, RecordingService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 2, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, CHANNEL_SERVICE)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Lokal Zəng Yazıcı")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text + ". Audio yalnız mikrofon vasitəsilə yazılır."))
                .setContentIntent(openPending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(null, "Dayandır", stopPending).build());
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) b.setPriority(Notification.PRIORITY_LOW);
        return b.build();
    }

    private void showEvent(String title, String message) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 3, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, CHANNEL_EVENTS)
                .setSmallIcon(android.R.drawable.ic_menu_save)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(message))
                .setContentIntent(openPending)
                .setAutoCancel(true);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) b.setPriority(Notification.PRIORITY_HIGH);
        nm.notify(EVENT_ID, b.build());
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel ongoing = new NotificationChannel(CHANNEL_SERVICE, "Daimi xidmət", NotificationManager.IMPORTANCE_LOW);
        ongoing.setDescription("Zəng yazıcı işləyərkən daimi görünən bildiriş");
        NotificationChannel events = new NotificationChannel(CHANNEL_EVENTS, "Yazı hadisələri", NotificationManager.IMPORTANCE_HIGH);
        events.setDescription("Yazma başlayanda və yazı bitəndə bildirişlər");
        nm.createNotificationChannel(ongoing);
        nm.createNotificationChannel(events);
    }

    @Override
    public void onDestroy() {
        stopCapture(false);
        unregisterPhoneListener();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
