package com.zengyazici;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.IBinder;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
import android.provider.CallLog;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyManager;
import io.github.muntashirakon.adb.AdbStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RecService extends Service {
    public static final String CH_FG = "fg", CH_EV = "ev";
    public static final String A_STOP = "stop", A_WA_ON = "wa_on", A_WA_OFF = "wa_off";
    public static volatile boolean running;
    public static volatile android.content.Context appCtx;
    public static final StringBuilder LOG = new StringBuilder();

    public static void log(String s) {
        synchronized (LOG) {
            LOG.append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date())).append(' ').append(s).append('\n');
            if (LOG.length() > 20000) LOG.delete(0, 5000);
        }
    }

    private NotificationManager nm;
    private AdbMgr mgr;
    private TelephonyManager tm;
    private Object cb;
    private boolean listening, ringing, stopping;
    private volatile boolean rec;
    private String app = "", dir = "in", num = "";
    private long t0;
    private File file;
    private ServerSocket ss;
    private AdbStream st;
    private Thread wt;
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final ExecutorService connEx = Executors.newSingleThreadExecutor();
    private boolean permLogged;
    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private boolean lastFail;
    private volatile boolean micOnly;
    private boolean spkChanged, spkPrev;
    private AudioManager am;
    private int lastMode = -1, voipTicks, endTicks;
    private volatile boolean pollRec;
    private final Runnable modePoll = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try { pollMode(); } catch (Throwable e) { log("Rejim: " + e); }
            h.postDelayed(this, 1000);
        }
    };
    private int ticks;
    private WindowManager wm;
    private TextView ov;
    private final Runnable ovTick = new Runnable() {
        @Override public void run() {
            if (ov == null) return;
            int sec = (int) ((System.currentTimeMillis() - t0) / 1000);
            ov.setText("🔴 Zəng yazılır · " + app + " · " + fmt(sec));
            h.postDelayed(this, 1000);
        }
    };
    private String fgText = "Zəng gözlənilir";
    private volatile boolean connecting;
    private ConnectivityManager.NetworkCallback netCb;
    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try {
                boolean has = false;
                for (android.service.notification.StatusBarNotification n : nm.getActiveNotifications()) if (n.getId() == 1) has = true;
                if (!has) startFg(fgText);
            } catch (Throwable e) { }
            if (ticks++ % 6 == 0) scheduleRestart(90000);
            reconnectIfNeeded();
            listen();
            h.postDelayed(this, 10000);
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        scheduleRestart(1500);
        try { startForegroundService(new Intent(this, RecService.class)); } catch (Throwable e) { }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        appCtx = getApplicationContext();
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_FG, "Xidmət", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CH_EV, "Zəng yazıları", NotificationManager.IMPORTANCE_HIGH));
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        String a = i == null ? null : i.getAction();
        if (!running) {
            running = true;
            startFg("Zəng gözlənilir");
            listen();
            connEx.execute(this::tryConnect);
            h.postDelayed(watchdog, 10000);
            h.postDelayed(modePoll, 1000);
            watchNetwork();
        }
        if ("test".equals(a) && !rec) {
            startRec("Test", "out", "Test (mikrofon)");
            h.postDelayed(() -> { if (rec && "Test".equals(app)) stopRec(); }, 9000);
        }
        if (A_WA_ON.equals(a)) startRec("WhatsApp", i.getStringExtra("dir"), i.getStringExtra("name"));
        if (A_WA_OFF.equals(a) && "WhatsApp".equals(app)) stopRec();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacks(watchdog);
        h.removeCallbacks(modePoll);
        h.removeCallbacks(ovTick);
        try { if (ov != null && wm != null) wm.removeView(ov); } catch (Throwable e) { }
        ov = null;
        scheduleRestart(2000);
        try { if (netCb != null) ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCb); } catch (Throwable e) { }
        release();
        try {
            if (cb != null && tm != null) {
                if (Build.VERSION.SDK_INT >= 31) tm.unregisterTelephonyCallback((TelephonyCallback) cb);
                else tm.listen((PhoneStateListener) cb, PhoneStateListener.LISTEN_NONE);
            }
        } catch (Throwable e) { }
        ex.shutdown();
        connEx.shutdown();
        super.onDestroy();
    }

    // ---------- bildirişlər ----------
    private PendingIntent openApp() {
        return PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification fgNotif(String text) {
        return new Notification.Builder(this, CH_FG)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Zəng Yazıcı işləyir")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(openApp())
                .build();
    }

    private void startFg(String text) {
        fgText = text;
        Notification n = fgNotif(text);
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    private void updateFg(String text) { fgText = text; nm.notify(1, fgNotif(text)); }

    private void notifyEv(int id, String title, String text, boolean ongoing) {
        nm.notify(id, new Notification.Builder(this, CH_EV)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(ongoing)
                .setAutoCancel(!ongoing)
                .setCategory(Notification.CATEGORY_STATUS)
                .setContentIntent(openApp())
                .build());
    }

    // ---------- tətbiqlərin üstündə göstərici ----------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void showOverlay() {
        h.post(() -> {
            try {
                if (ov != null) return;
                if (!Settings.canDrawOverlays(this)) { log("Üstündə göstərmə icazəsi yoxdur — göstərici açılmadı"); return; }
                wm = (WindowManager) getSystemService(WINDOW_SERVICE);
                TextView t = new TextView(this);
                t.setTextColor(Color.WHITE); t.setTextSize(13); t.setTypeface(null, Typeface.BOLD);
                t.setPadding(dp(14), dp(7), dp(14), dp(7));
                GradientDrawable g = new GradientDrawable();
                g.setColor(0xE6D32F2F); g.setCornerRadius(dp(20));
                t.setBackground(g);
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                lp.y = dp(36);
                wm.addView(t, lp);
                ov = t;
                h.removeCallbacks(ovTick);
                h.post(ovTick);
            } catch (Throwable e) {
                log("Göstərici: " + e);
                ov = null;
            }
        });
    }

    private void hideOverlay() {
        h.post(() -> {
            h.removeCallbacks(ovTick);
            try { if (ov != null && wm != null) wm.removeView(ov); } catch (Throwable e) { }
            ov = null;
        });
    }

    // ---------- ADB ----------
    private void ensureConnected() throws Exception {
        if (mgr == null) mgr = AdbMgr.get(this);
        Conn.ensure(this);
    }

    private static String modeName(int m) {
        return m == 0 ? "NORMAL" : m == 1 ? "RINGTONE" : m == 2 ? "IN_CALL" : m == 3 ? "IN_COMMUNICATION" : String.valueOf(m);
    }

    /** Zəngi telefonun audio rejimindən də tanıyır (zəng callback-i işləməsə belə). */
    private void pollMode() {
        if (am == null) am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int m = am.getMode();
        if (m != lastMode) { log("Audio rejimi: " + modeName(m)); lastMode = m; }
        if (m == AudioManager.MODE_RINGTONE) ringing = true;
        if (m == AudioManager.MODE_IN_CALL) {
            endTicks = 0; voipTicks = 0;
            if (!rec && !stopping) { startRec("Telefon", ringing ? "in" : "out", ""); if (rec) pollRec = true; }
        } else if (m == AudioManager.MODE_IN_COMMUNICATION) {
            endTicks = 0;
            voipTicks++;
            if (voipTicks >= 3 && !rec && !stopping) {
                boolean wa = System.currentTimeMillis() - WaListener.lastCallNotif < 180000;
                startRec(wa ? "WhatsApp" : "İnternet zəngi", WaListener.wasIncoming() ? "in" : "out", WaListener.lastName());
                if (rec) pollRec = true;
            }
        } else {
            voipTicks = 0;
            if (rec && (pollRec || "Telefon".equals(app)) && !stopping) {
                if (++endTicks >= (pollRec ? 3 : 6)) { endTicks = 0; stopRec(); }
            } else {
                endTicks = 0;
            }
            if (m == AudioManager.MODE_NORMAL && !rec) ringing = false;
        }
    }

    private void reconnectIfNeeded() {
        if (!rec && !connecting && (mgr == null || !mgr.isConnected())) connEx.execute(this::tryConnect);
    }

    private void watchNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network n) { h.postDelayed(RecService.this::reconnectIfNeeded, 2000); }
            };
            cm.registerDefaultNetworkCallback(netCb);
        } catch (Throwable e) { log("Şəbəkə izləmə: " + e); }
    }

    private void tryConnect() {
        if (connecting) return;
        connecting = true;
        if (!rec) updateFg("ADB-yə qoşulur…");
        try {
            ensureConnected();
            if (lastFail) log("ADB yenidən qoşuldu");
            lastFail = false;
            updateFg("ADB qoşulub (" + Conn.mode + ") · zəng gözlənilir");
            AdbPerms.apply(this, false);
        } catch (Throwable e) {
            if (!lastFail) log("ADB: " + e);
            lastFail = true;
            updateFg("ADB qoşulmayıb — yenidən cəhd edilir");
        } finally {
            connecting = false;
        }
    }

    // ---------- zəng izləmə ----------
    private void listen() {
        if (listening) return;
        if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            if (!permLogged) { log("READ_PHONE_STATE icazəsi yoxdur — zənglər tanınmır"); permLogged = true; }
            updateFg("Telefon icazəsi verilməyib: Menyu → İcazələr");
            return;
        }
        try {
            tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            if (Build.VERSION.SDK_INT >= 31) {
                cb = new Cb31();
                tm.registerTelephonyCallback(getMainExecutor(), (TelephonyCallback) cb);
            } else {
                PhoneStateListener l = new PhoneStateListener() {
                    @Override public void onCallStateChanged(int s, String n) { onState(s); }
                };
                cb = l;
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE);
            }
            listening = true;
            log("Zəng dinləyicisi aktiv");
        } catch (Throwable e) {
            log("Dinləyici: " + e);
        }
    }

    @android.annotation.TargetApi(31)
    private class Cb31 extends TelephonyCallback implements TelephonyCallback.CallStateListener {
        @Override public void onCallStateChanged(int s) { onState(s); }
    }

    private void onState(int s) {
        log("Zəng vəziyyəti: " + (s == 0 ? "IDLE" : s == 1 ? "RINGING" : "OFFHOOK"));
        if (s == TelephonyManager.CALL_STATE_RINGING) {
            ringing = true;
        } else if (s == TelephonyManager.CALL_STATE_OFFHOOK) {
            if (!rec) startRec("Telefon", ringing ? "in" : "out", "");
        } else if (s == TelephonyManager.CALL_STATE_IDLE) {
            ringing = false;
            if (rec && "Telefon".equals(app)) stopRec();
        }
    }

    // ---------- yazı ----------
    private String label() {
        return app + " · " + ("out".equals(dir) ? "gedən" : "gələn") + (num.isEmpty() ? "" : " · " + num);
    }

    private static String fmt(int s) { return String.format(Locale.US, "%d:%02d", s / 60, s % 60); }

    private void startRec(String a, String d, String n) {
        if (rec) return;
        rec = true;
        micOnly = false;
        app = a;
        dir = d == null || d.isEmpty() ? "in" : d;
        num = n == null ? "" : n;
        t0 = System.currentTimeMillis();
        try {
            if (wl == null) wl = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zengyazici:rec");
            wl.acquire(4 * 60 * 60 * 1000L);
        } catch (Throwable e) { }
        ex.execute(() -> {
            try {
                ensureConnected();
                File dirF = new File(getFilesDir(), "rec");
                dirF.mkdirs();
                final File f = new File(dirF, "rec_" + t0 + ".wav");
                file = f;
                final ServerSocket s = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
                ss = s;
                s.setSoTimeout(20000);
                String src = "Telefon".equals(app) ? "4;3+1;3+2;7;1"
                        : "Test".equals(app) ? "1;7" : "8+1;7;1";
                final AdbStream stream = mgr.openStream("shell:CLASSPATH=" + getPackageCodePath()
                        + " app_process /system/bin com.zengyazici.Rec " + s.getLocalPort() + " " + src);
                st = stream;
                Thread rt = new Thread(() -> {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(stream.openInputStream()))) {
                        String l;
                        while ((l = br.readLine()) != null) {
                            log("rec: " + l);
                            if (l.contains("FAR=none")) { micOnly = true; h.post(this::autoSpeaker); }
                            if (l.contains("FAR=ok")) micOnly = false;
                        }
                    } catch (Exception e) { }
                });
                rt.setDaemon(true);
                rt.start();
                wt = new Thread(() -> pump(s, f));
                wt.setDaemon(true);
                wt.start();
                notifyEv(2, "🔴 Zəng yazılır", label(), true);
                updateFg("Yazılır: " + label());
                showOverlay();
            } catch (Throwable e) {
                log("Yazı başlamadı: " + e);
                rec = false;
                release();
                hideOverlay();
                notifyEv(4, "Zəng yazıla bilmədi", String.valueOf(e.getMessage()), false);
            }
        });
    }

    /** Başqa komponentlərdən (əlçatımlılıq, bildiriş dinləyicisi, alarm) xidməti qaldırır. */
    public static void ensure(android.content.Context c) {
        if (running) return;
        try {
            c.startForegroundService(new Intent(c, RecService.class));
        } catch (Throwable e) {
            try { c.startService(new Intent(c, RecService.class)); } catch (Throwable e2) { log("ensure: " + e2); }
        }
    }

    private void scheduleRestart(long delay) {
        try {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            PendingIntent pi = PendingIntent.getBroadcast(this, 7, new Intent(this, RestartReceiver.class),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            long at = System.currentTimeMillis() + delay;
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } catch (Throwable e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (Throwable e) {
            log("Alarm: " + e);
        }
    }

    /** Qarşı tərəfin səsi birbaşa tutulmursa, dinamiki açır ki, səs mikrofona düşsün. */
    private void autoSpeaker() {
        if ("Test".equals(app) || !rec) return;
        if (!getSharedPreferences("cfg", 0).getBoolean("autospeaker", true)) return;
        try {
            AudioManager a = (AudioManager) getSystemService(AUDIO_SERVICE);
            spkPrev = a.isSpeakerphoneOn();
            if (!spkPrev) {
                a.setSpeakerphoneOn(true);
                spkChanged = true;
                log("Dinamik avtomatik açıldı (qarşı tərəfin səsi mikrofona düşsün)");
            }
        } catch (Throwable e) {
            log("Dinamik: " + e);
        }
    }

    private void restoreSpeaker() {
        if (!spkChanged) return;
        try {
            ((AudioManager) getSystemService(AUDIO_SERVICE)).setSpeakerphoneOn(spkPrev);
        } catch (Throwable e) { }
        spkChanged = false;
    }

    private void release() {
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable e) { }
    }

    private void pump(ServerSocket s, File f) {
        long total = 0;
        try (RandomAccessFile r = new RandomAccessFile(f, "rw")) {
            r.write(new byte[44]);
            try {
                Socket c = s.accept();
                InputStream in = c.getInputStream();
                int src = in.read();
                log("Audio planı #" + src);
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) > 0) { r.write(b, 0, n); total += n; }
            } catch (Exception e) {
                log("Audio axını: " + e);
            }
            header(r, total);
        } catch (Exception e) {
            log("Fayl: " + e);
        }
    }

    private static void header(RandomAccessFile r, long n) throws Exception {
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes()).putInt((int) (36 + n)).put("WAVE".getBytes()).put("fmt ".getBytes())
                .putInt(16).putShort((short) 1).putShort((short) 1).putInt(16000).putInt(32000)
                .putShort((short) 2).putShort((short) 16).put("data".getBytes()).putInt((int) n);
        r.seek(0);
        r.write(b.array());
    }

    private void stopRec() {
        if (!rec || stopping) return;
        stopping = true;
        ex.execute(() -> {
            try {
                try { if (st != null) st.close(); } catch (Throwable e) { }
                try { if (ss != null) ss.close(); } catch (Throwable e) { }
                try { if (wt != null) wt.join(5000); } catch (Throwable e) { }
                st = null; ss = null; wt = null;
                nm.cancel(2);
                int dur = (int) ((System.currentTimeMillis() - t0) / 1000);
                File f = file;
                if (f != null && f.length() > 8000) {
                    resolve();
                    Db.Item it = new Db.Item();
                    it.path = f.getAbsolutePath();
                    it.num = num;
                    it.app = app;
                    it.dir = dir;
                    it.ts = t0;
                    it.dur = dur;
                    it.note = !micOnly || "Test".equals(app) ? "" : spkChanged ? "Mikrofonla yazıldı (dinamik avtomatik açıldı)" : "Yalnız mikrofon: qarşı tərəfin səsi tutulmadı";
                    Db.add(this, it);
                    notifyEv(3, "✅ Zəng yazıldı", label() + " · " + fmt(dur), false);
                } else {
                    if (f != null) f.delete();
                    notifyEv(4, "Zəng yazıla bilmədi", "Audio alınmadı — Log-a baxın", false);
                }
            } catch (Throwable e) {
                log("Yazını bitirmə xətası: " + e);
            } finally {
                rec = false;
                stopping = false;
                pollRec = false;
                hideOverlay();
                restoreSpeaker();
                release();
                if (running) updateFg("ADB qoşulub (" + Conn.mode + ") · zəng gözlənilir");
            }
        });
    }

    /** Nömrə/ad və istiqaməti zəng jurnalından dəqiqləşdirir. */
    private void resolve() {
        if (!"Telefon".equals(app)) {
            if (num.isEmpty()) num = "WhatsApp";
            return;
        }
        try { Thread.sleep(1200); } catch (Exception e) { }
        try {
            Bundle b = new Bundle();
            b.putInt(ContentResolver.QUERY_ARG_LIMIT, 1);
            b.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, new String[]{CallLog.Calls.DATE});
            b.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING);
            Cursor c = getContentResolver().query(CallLog.Calls.CONTENT_URI,
                    new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE}, b, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        String nu = c.getString(0), na = c.getString(1);
                        int ty = c.getInt(2);
                        if (na != null && !na.isEmpty()) num = na;
                        else if (nu != null && !nu.isEmpty()) num = nu;
                        if (ty == CallLog.Calls.OUTGOING_TYPE) dir = "out";
                        else if (ty == CallLog.Calls.INCOMING_TYPE) dir = "in";
                    }
                } finally { c.close(); }
            }
        } catch (Throwable e) {
            log("Zəng jurnalı: " + e);
        }
        if (num.isEmpty()) num = "Naməlum";
    }
}
