# IPTVPlayer build and playback

- ExoPlayer (AndroidX Media3 1.11.1) is the only playback engine.
- Media3 dependencies all use the same version and cover progressive playback, HLS, DASH, SmoothStreaming and RTSP.
- The player's default LoadControl and HTTP timeout behaviour is used; no custom buffer sizes are configured.
- A channel generation counter prevents delayed requests from replacing the most recently selected channel.
- A black cover hides stale video frames until the newly selected channel renders its first frame.
- If playback does not open or the first frame does not arrive, the app shows a diagnostic status instead of switching engines.
- Build versions: Android Gradle Plugin 8.13.2, Gradle 8.13, Kotlin 2.4.21, JDK 17, compileSdk 36.
