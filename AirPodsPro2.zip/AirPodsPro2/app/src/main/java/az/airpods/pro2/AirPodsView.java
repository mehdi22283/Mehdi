package az.airpods.pro2;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;

/** AirPods Pro 2 qabı (açılan qapaq, çıxan qulaqlıqlar) + Sol / Sağ / Qab batareya halqaları. */
public class AirPodsView extends View {
    private static final int GREEN = 0xFF30D158, RED = 0xFFFF453A, AMBER = 0xFFFF9F0A, BLUE = 0xFF0A84FF;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Path path = new Path();

    private float lid = 0f, lidTarget = -1f, pulse = 0f;
    private final float[] shown = new float[3];
    private final boolean[] known = new boolean[3];
    private final boolean[] chg = new boolean[3];
    private final boolean[] ear = new boolean[2];
    private boolean live = false;
    private boolean singleMode = false;

    private ValueAnimator lidAnim, pulseAnim;
    private final ValueAnimator[] barAnim = new ValueAnimator[3];

    public AirPodsView(Context c) { super(c); init(); }
    public AirPodsView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        tp.setTextAlign(Paint.Align.CENTER);
    }

    // ---------- məlumat ----------
    public void setData(PodsState s, boolean active) {
        live = active;
        if (s == null) {
            singleMode = false;
            for (int i = 0; i < 3; i++) { known[i] = false; chg[i] = false; animBar(i, 0f); }
            ear[0] = ear[1] = false;
            animLid(false);
            invalidate();
            return;
        }
        singleMode = s.generic && s.left < 0 && s.right < 0 && s.caseLevel < 0;
        if (singleMode) {
            known[0] = s.single >= 0;
            known[1] = false;
            known[2] = false;
            chg[0] = false; chg[1] = false; chg[2] = false;
            animBar(0, known[0] ? s.single / 100f : 0f);
            animBar(1, 0f);
            animBar(2, 0f);
            ear[0] = false; ear[1] = false;
            animLid(active);
            invalidate();
            return;
        }
        int[] v = {s.left, s.right, s.caseLevel};
        boolean[] c = {s.chgL, s.chgR, s.chgC};
        for (int i = 0; i < 3; i++) {
            known[i] = v[i] >= 0;
            chg[i] = c[i] && active;
            animBar(i, known[i] ? v[i] / 100f : 0f);
        }
        ear[0] = s.inL && active;
        ear[1] = s.inR && active;
        animLid(active);
        invalidate();
    }

    private void animBar(final int i, float target) {
        if (Math.abs(shown[i] - target) < 0.001f) return;
        if (barAnim[i] != null) barAnim[i].cancel();
        ValueAnimator a = ValueAnimator.ofFloat(shown[i], target);
        a.setDuration(900);
        a.setInterpolator(new DecelerateInterpolator(1.6f));
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator va) {
                shown[i] = (float) va.getAnimatedValue();
                invalidate();
            }
        });
        barAnim[i] = a;
        a.start();
    }

    private void animLid(boolean open) {
        float t = open ? 1f : 0f;
        if (lidTarget == t) return;
        lidTarget = t;
        if (lidAnim != null) lidAnim.cancel();
        ValueAnimator a = ValueAnimator.ofFloat(lid, t);
        a.setDuration(open ? 750 : 450);
        a.setInterpolator(open ? new OvershootInterpolator(1.4f) : new AccelerateDecelerateInterpolator());
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator va) {
                lid = (float) va.getAnimatedValue();
                invalidate();
            }
        });
        lidAnim = a;
        a.start();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        pulseAnim = ValueAnimator.ofFloat(0f, 1f);
        pulseAnim.setDuration(1600);
        pulseAnim.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnim.setInterpolator(new LinearInterpolator());
        pulseAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator va) {
                pulse = (float) va.getAnimatedValue();
                if (chg[0] || chg[1] || chg[2]) invalidate();
            }
        });
        pulseAnim.start();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (pulseAnim != null) pulseAnim.cancel();
        if (lidAnim != null) lidAnim.cancel();
        for (ValueAnimator a : barAnim) if (a != null) a.cancel();
        lidTarget = -1f;
    }

    // ---------- çəkmə ----------
    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float heroH = h * 0.56f;
        drawHero(c, w, heroH);
        drawGauges(c, w, heroH, h);
    }

    private void drawHero(Canvas c, float w, float heroH) {
        float bw = Math.min(w * 0.46f, heroH * 0.82f);
        float bh = bw * 0.78f;
        float cx = w / 2f;
        float bottom = heroH * 0.94f;
        float top = bottom - bh;
        float lidClosed = bh * 0.40f;
        float seam = top + lidClosed;
        float r = bw * 0.30f;
        float rs = bw * 0.05f;
        float l = cx - bw / 2f, rt = cx + bw / 2f;
        float o = lid;

        p.setStyle(Paint.Style.FILL);

        // parıltı
        if (o > 0.02f) {
            int a = (int) (0x38 * Math.min(1f, o));
            p.setShader(new RadialGradient(cx, seam, bw * 1.1f, (a << 24) | 0xFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            c.drawCircle(cx, seam, bw * 1.1f, p);
            p.setShader(null);
        }

        // qabın alt hissəsi
        p.setShader(new LinearGradient(0, seam, 0, bottom, 0xFFF4F4F8, 0xFFD2D2D8, Shader.TileMode.CLAMP));
        path.reset();
        rf.set(l, seam, rt, bottom);
        path.addRoundRect(rf, new float[]{rs, rs, rs, rs, r, r, r, r}, Path.Direction.CW);
        c.drawPath(path, p);
        p.setShader(null);

        // içəri boşluq
        if (o > 0.02f) {
            p.setColor(0xFF2C2C2E);
            p.setAlpha((int) (255 * Math.min(1f, o * 1.5f)));
            rf.set(cx - bw * 0.43f, seam - bh * 0.04f, cx + bw * 0.43f, seam + bh * 0.13f);
            c.drawRoundRect(rf, bh * 0.07f, bh * 0.07f, p);
            p.setAlpha(255);
        }

        // qulaqlıqlar qabdan yuxarı çıxır
        if (o > 0.02f) {
            float br = bw * 0.12f;
            float clipB = seam + bh * 0.04f;
            float rise = o * bw * 0.30f;
            float cy = clipB + br + bw * 0.01f - rise;
            c.save();
            c.clipRect(0, 0, w, clipB);
            drawBud(c, cx - bw * 0.19f, cy, br, false);
            drawBud(c, cx + bw * 0.19f, cy, br, true);
            c.restore();
        }

        // qapaq (açıldıqca yığılır)
        float lidH = lidClosed * (1f - 0.8f * Math.min(o, 1.15f));
        if (lidH < 2f) lidH = 2f;
        float rr = Math.min(r, lidH);
        int c1 = mix(0xFFFFFFFF, 0xFFD2D2D8, o);
        int c2 = mix(0xFFE9E9EE, 0xFFBDBDC4, o);
        p.setShader(new LinearGradient(0, seam - lidH, 0, seam, c1, c2, Shader.TileMode.CLAMP));
        path.reset();
        rf.set(l, seam - lidH, rt, seam);
        path.addRoundRect(rf, new float[]{rr, rr, rr, rr, rs, rs, rs, rs}, Path.Direction.CW);
        c.drawPath(path, p);
        p.setShader(null);

        // qapaq xətti
        if (o < 0.25f) {
            p.setColor(0xFF9A9AA0);
            p.setAlpha((int) (255 * (1f - o * 4f)));
            float ln = Math.max(1f, bw * 0.008f);
            c.drawRect(l + rs, seam - ln, rt - rs, seam + ln * 0.6f, p);
            p.setAlpha(255);
        }

        // status işığı
        int led = !live ? 0xFF6E6E73 : (chg[2] ? AMBER : GREEN);
        p.setColor(led);
        c.drawCircle(cx, seam + bh * 0.17f, bw * 0.02f, p);
    }

    private void drawBud(Canvas c, float x, float cy, float br, boolean right) {
        float sw = br * 0.9f;
        c.save();
        c.rotate(right ? 8 : -8, x, cy);
        p.setColor(0xFFF2F2F7);
        rf.set(x - sw / 2f, cy, x + sw / 2f, cy + br * 2.9f);
        c.drawRoundRect(rf, sw / 2f, sw / 2f, p);
        c.restore();
        p.setColor(0xFFFFFFFF);
        c.drawCircle(x, cy, br, p);
        float dx = (right ? -1 : 1) * br * 0.25f;
        p.setColor(0xFFD9D9DE);
        c.drawCircle(x + dx, cy - br * 0.1f, br * 0.5f, p);
        p.setColor(0xFF3A3A3C);
        c.drawCircle(x + dx, cy - br * 0.1f, br * 0.16f, p);
    }

    private void drawGauges(Canvas c, float w, float heroH, float h) {
        float colW = w / 3f;
        float R = Math.min(colW * 0.36f, (h - heroH) * 0.30f) * (singleMode ? 1.25f : 1f);
        float cy = heroH + (h - heroH) * 0.40f;
        float sw = R * 0.17f;
        String[] names = {singleMode ? "Batareya" : "Sol", "Sağ", "Qab"};
        int alpha = live ? 255 : 150;

        for (int i = 0; i < (singleMode ? 1 : 3); i++) {
            float cx = singleMode ? w / 2f : colW * (i + 0.5f);
            float f = shown[i];

            // iz
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(sw);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0x33FFFFFF);
            c.drawCircle(cx, cy, R, p);

            // irəliləyiş
            if (known[i] && f > 0.005f) {
                rf.set(cx - R, cy - R, cx + R, cy + R);
                int col = f <= 0.2f ? RED : GREEN;
                if (chg[i]) {
                    p.setColor(col);
                    p.setAlpha((int) (80 * (0.5f + 0.5f * (float) Math.sin(pulse * 6.2832f))));
                    p.setStrokeWidth(sw * 1.9f);
                    c.drawArc(rf, -90, 360f * f, false, p);
                    p.setStrokeWidth(sw);
                }
                p.setColor(col);
                p.setAlpha(alpha);
                c.drawArc(rf, -90, 360f * f, false, p);
            }

            p.setStyle(Paint.Style.FILL);
            p.setStrokeCap(Paint.Cap.BUTT);

            // faiz
            if (known[i]) {
                tp.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
                tp.setTextSize(R * 0.54f);
                tp.setColor(Color.WHITE);
                tp.setAlpha(alpha);
                float base = cy + (chg[i] ? R * 0.10f : R * 0.20f);
                c.drawText(Math.round(f * 100f) + "%", cx, base, tp);
                if (chg[i]) bolt(c, cx, cy + R * 0.55f, R * 0.17f, GREEN, alpha);
            } else {
                tp.setTypeface(Typeface.DEFAULT);
                tp.setTextSize(R * 0.6f);
                tp.setColor(Color.WHITE);
                tp.setAlpha(100);
                c.drawText("—", cx, cy + R * 0.2f, tp);
            }

            // ad
            float labelY = cy + R + sw / 2f + R * 0.42f;
            tp.setTypeface(Typeface.DEFAULT);
            tp.setTextSize(R * 0.34f);
            tp.setColor(Color.WHITE);
            tp.setAlpha((int) (alpha * 0.72f));
            c.drawText(names[i], cx, labelY, tp);

            // alt yazı
            String sub = null;
            int sc = 0;
            if (known[i] && chg[i]) { sub = "Şarj olur"; sc = GREEN; }
            else if (i < 2 && ear[i]) { sub = "Qulaqda"; sc = BLUE; }
            if (sub != null) {
                tp.setTextSize(R * 0.28f);
                tp.setColor(sc);
                c.drawText(sub, cx, labelY + R * 0.38f, tp);
            }
        }
    }

    private void bolt(Canvas c, float bx, float by, float u, int color, int alpha) {
        path.reset();
        path.moveTo(bx + 0.15f * u, by - u);
        path.lineTo(bx - 0.5f * u, by + 0.1f * u);
        path.lineTo(bx - 0.05f * u, by + 0.1f * u);
        path.lineTo(bx - 0.15f * u, by + u);
        path.lineTo(bx + 0.5f * u, by - 0.1f * u);
        path.lineTo(bx + 0.05f * u, by - 0.1f * u);
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setAlpha(alpha);
        c.drawPath(path, p);
    }

    private static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
