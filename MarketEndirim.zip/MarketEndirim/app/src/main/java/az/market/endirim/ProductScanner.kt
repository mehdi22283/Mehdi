package az.market.endirim

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.regex.Pattern
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Jurnal PDF-lərindən məhsul + endirimli qiymət indeksini yaradır.
 *
 * Qiymət nümunələri:
 *  12.99 ₼, 12,99 ₼, 2.50₼, 9 ₼
 * Yəni həm XX.XX, X.XX, həm də tək X rəqəmli manat qiymətləri tanınır.
 */
object ProductScanner {
    private val pricePattern = Pattern.compile(
        """(?<![\d.,])(\d{1,3}(?:[.,]\d{1,2})?)\s*₼"""
    )

    private val categoryWords = setOf(
        "ƏRZAQ", "İÇKİLƏR", "SÜD MƏHSULLARI", "ƏT MƏHSULLARI", "ŞİRİNLİKLƏR",
        "QƏLYANALTI", "MEYVƏ", "TƏRƏVƏZ", "TƏMİZLİK", "GİGİYENA", "KOSMETİKA",
        "UŞAQ", "HEYVAN", "MƏTBƏX", "EV", "DONDURULMUŞ", "KONSERV", "MAKARON",
        "YAĞ", "ŞAMPUN", "SABUN", "DIŞ", "QƏHVƏ", "ÇAY", "QƏND", "UN",
        "KOLBASA", "PENDİR", "YOQURT", "SÜD", "BİSKVİT", "ŞOKOLAD"
    )

    suspend fun scan(ctx: Context, catalog: Catalog, file: File): List<ProductHit> =
        withContext(Dispatchers.IO) {
            val out = ArrayList<ProductHit>()
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                PdfRenderer(pfd).use { renderer ->
                    for (pageNo in 0 until renderer.pageCount) {
                        val page = renderer.openPage(pageNo)
                        try {
                            val width = 1800
                            val height = (width.toFloat() * page.height / page.width).toInt()
                            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            val text = recognizeBlocking(bmp)
                            out += parse(catalog.market, catalog.urls.first(), pageNo + 1, text)
                            bmp.recycle()
                        } finally {
                            page.close()
                        }
                    }
                }
            }
            dedupe(out)
        }

    private suspend fun recognize(bmp: Bitmap): String = suspendCancellableCoroutine { c ->
        val rec = com.google.mlkit.vision.text.TextRecognition
            .getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(com.google.mlkit.vision.common.InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { c.resume(it.text) }
            .addOnFailureListener { c.resumeWithException(it) }
    }

    // Scanner coroutine-u IO kontekstində işləyir, ML Kit isə öz thread-lərində işləyir.
    private fun recognizeBlocking(bmp: Bitmap): String {
        // sadə və təhlükəsiz körpü: ML Kit nəticəsini bloklamadan digər səhifəyə keçmirik
        return kotlinx.coroutines.runBlocking { recognize(bmp) }
    }

    private fun parse(market: String, url: String, page: Int, raw: String): List<ProductHit> {
        val lines = raw.lines().map { clean(it) }.filter { it.isNotBlank() }
        var category = "Digər"
        var previousText: String? = null
        val result = ArrayList<ProductHit>()

        for (line0 in lines) {
            val line = line0.replace(Regex("""\s+"""), " ").trim()
            val matcher = pricePattern.matcher(line)
            val prices = ArrayList<Pair<String, Double>>()
            var product = line
            while (matcher.find()) {
                val shown = matcher.group(1).replace(',', '.')
                val value = shown.toDoubleOrNull() ?: continue
                prices += "${matcher.group(1)} ₼" to value
            }

            // Qiymətsiz sətirlər: başlıqdırsa kateqoriyanı dəyiş, əks halda
            // sonrakı qiymət sətirində məhsul adı kimi istifadə oluna bilər.
            if (prices.isEmpty()) {
                val upper = line.uppercase(Locale("az", "AZ"))
                if (isCategory(upper)) {
                    category = normalizeCategory(line)
                    previousText = null
                } else if (validProductName(line)) {
                    previousText = line
                }
                continue
            }

            product = product.replace(pricePattern.toRegex(), " ")
                .replace(Regex("""[|•·]+"""), " ")
                .replace(Regex("""\s+"""), " ").trim()

            // Broşürlərdə məhsul adı bir sətirdə, "9.99 ₼" isə növbəti sətirdə
            // ola bilər. Belə halda əvvəlki OCR sətirini məhsul adı kimi birləşdir.
            if (!validProductName(product) && previousText != null) product = previousText!!
            previousText = null

            if (!validProductName(product)) continue

            // Bir sətirdə köhnə + yeni qiymət varsa, daha aşağı olanı endirimli qiymət kimi götür.
            val discounted = prices.minByOrNull { it.second } ?: continue
            result += ProductHit(
                market = market,
                category = category,
                name = product,
                price = discounted.first,
                value = discounted.second,
                sourceUrl = url,
                page = page
            )
        }
        return result
    }

    private fun clean(s: String): String =
        s.replace('\u00A0', ' ').replace("₾", "₼").trim()

    private fun validProductName(s: String): Boolean {
        if (s.length < 3) return false
        if (s.count { it.isLetter() } < 2) return false
        if (s.length > 120) return false
        if (s.matches(Regex("""[\d\s.,:/\-]+"""))) return false
        return true
    }

    private fun isCategory(s: String): Boolean {
        if (s.length !in 3..45) return false
        if (categoryWords.any { s.contains(it) }) return true
        val letters = s.filter { it.isLetter() }
        return letters.isNotEmpty() && letters.length >= 5 &&
            letters.count { it.isUpperCase() } >= letters.length * .75
    }

    private fun normalizeCategory(s: String): String =
        s.trim().replace(Regex("""\s+"""), " ").trim(' ', '-', ':', '•')

    private fun dedupe(list: List<ProductHit>): List<ProductHit> {
        val seen = HashSet<String>()
        return list.filter {
            val k = "${it.market}|${it.category}|${it.name.lowercase(Locale("az","AZ"))}|${it.price}|${it.page}"
            seen.add(k)
        }
    }
}

object ProductStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "products.json")

    fun save(ctx: Context, products: List<ProductHit>) {
        try {
            val a = JSONArray()
            products.forEach {
                a.put(JSONObject().apply {
                    put("market", it.market)
                    put("category", it.category)
                    put("name", it.name)
                    put("price", it.price)
                    put("value", it.value)
                    put("sourceUrl", it.sourceUrl)
                    put("page", it.page)
                })
            }
            val f = file(ctx)
            val tmp = File(f.path + ".part")
            tmp.writeText(a.toString())
            tmp.renameTo(f)
        } catch (_: Exception) {}
    }

    fun load(ctx: Context): List<ProductHit> {
        val out = ArrayList<ProductHit>()
        try {
            val f = file(ctx)
            if (!f.exists()) return out
            val a = JSONArray(f.readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out += ProductHit(
                    o.getString("market"), o.getString("category"), o.getString("name"),
                    o.getString("price"), o.getDouble("value"), o.getString("sourceUrl"),
                    o.getInt("page")
                )
            }
        } catch (_: Exception) {}
        return out
    }
}
