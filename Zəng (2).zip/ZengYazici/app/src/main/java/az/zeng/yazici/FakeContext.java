package az.zeng.yazici;

import android.annotation.SuppressLint;
import android.content.AttributionSource;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.os.Looper;
import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Shell (uid 2000) prosesində AudioRecord yaratmaq üçün saxta kontekst.
 * Yanaşma scrcpy-nin audio tutma üsuluna əsaslanır.
 */
@SuppressLint({"NewApi", "PrivateApi", "DiscouragedPrivateApi"})
final class FakeContext extends ContextWrapper {
    private static final String TAG = "ZengRec";
    private static final String PKG = "com.android.shell";
    private static FakeContext inst;
    private static boolean tried;
    static String lastError = "";

    static synchronized Context get() {
        if (!tried) {
            tried = true;
            try {
                exemptHiddenApis();
                Context sys = systemContext();
                if (sys != null) inst = new FakeContext(sys);
            } catch (Throwable t) {
                lastError = String.valueOf(t);
                Log.e(TAG, "FakeContext", t);
            }
        }
        return inst;
    }

    private FakeContext(Context base) {
        super(base);
    }

    public String getPackageName() {
        return PKG;
    }

    public String getOpPackageName() {
        return PKG;
    }

    public Context getApplicationContext() {
        return this;
    }

    public AttributionSource getAttributionSource() {
        if (Build.VERSION.SDK_INT >= 31) {
            return new AttributionSource.Builder(2000).setPackageName(PKG).build();
        }
        return null;
    }

    private static void exemptHiddenApis() {
        try {
            Method forName = Class.class.getDeclaredMethod("forName", String.class);
            Method getDeclaredMethod = Class.class.getDeclaredMethod("getDeclaredMethod", String.class, Class[].class);
            Class<?> vm = (Class<?>) forName.invoke(null, "dalvik.system.VMRuntime");
            Method getRuntime = (Method) getDeclaredMethod.invoke(vm, "getRuntime", null);
            Method setExempt = (Method) getDeclaredMethod.invoke(vm, "setHiddenApiExemptions", new Class[]{String[].class});
            Object rt = getRuntime.invoke(null);
            setExempt.invoke(rt, new Object[]{new String[]{"L"}});
        } catch (Throwable t) {
            Log.w(TAG, "hidden api exempt: " + t);
        }
    }

    private static Context systemContext() throws Exception {
        Class<?> at = Class.forName("android.app.ActivityThread");
        Object thread = at.getMethod("currentActivityThread").invoke(null);
        if (thread == null) {
            if (Looper.getMainLooper() == null) {
                try {
                    Looper.prepareMainLooper();
                } catch (Throwable ignored) {
                }
            }
            Constructor<?> c = at.getDeclaredConstructor();
            c.setAccessible(true);
            thread = c.newInstance();
            Field f = at.getDeclaredField("sCurrentActivityThread");
            f.setAccessible(true);
            f.set(null, thread);
            Field s = at.getDeclaredField("mSystemThread");
            s.setAccessible(true);
            s.setBoolean(thread, true);
        }
        return (Context) at.getMethod("getSystemContext").invoke(thread);
    }
}
