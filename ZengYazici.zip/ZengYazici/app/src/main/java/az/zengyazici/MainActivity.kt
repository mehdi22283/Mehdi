package az.zengyazici

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.*
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var list: LinearLayout
    private var pendingAuto = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply { text = "Zəng Yazıcı"; textSize = 24f })
        status = TextView(this).apply { textSize = 15f; setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(status)

        fun btn(t: String, onClick: () -> Unit) = root.addView(Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { onClick() }
        })

        btn("▶ Avtomatik quraşdır (Shizuku lazım deyil)") { auto() }
        btn("Xidməti BAŞLAT") { startSvc() }
        btn("Xidməti DAYANDIR") { stopService(Intent(this, RecorderService::class.java)); root.postDelayed({ refresh() }, 600) }
        btn("Yazıları göstər") { loadRecordings() }

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)

        logView = TextView(this).apply { textSize = 12f; setTextIsSelectable(true); setPadding(0, pad, 0, 0) }
        root.addView(logView)
        AdbAuto.logger = { m -> runOnUiThread { logView.append(m + "\n") } }

        root.addView(TextView(this).apply {
            textSize = 12f
            text = "\nİlk dəfə: Developer options → Wireless debugging-i yandırın, “Pair device with pairing code” seçin. " +
                "Bildirişdəki “Kodu yaz” düyməsinə 6 rəqəmli kodu daxil edin. Bundan sonra hər şey avtomatikdir " +
                "(yenidən başladıqdan sonra da, WRITE_SECURE_SETTINGS sayəsində Wireless debugging özü yanır).\n\n" +
                "Qeyd: Android 10+ zəng səsini birbaşa yazmağa icazə vermir. Qarşı tərəfin səsi üçün dinamiki açın."
        })
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent) }

    override fun onResume() {
        super.onResume()
        refresh()
        if (intent.getBooleanExtra("autostart", false)) {
            intent.removeExtra("autostart")
            if (granted(Manifest.permission.RECORD_AUDIO)) startSvc()
            moveTaskToBack(true)
        }
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun startSvc() {
        ContextCompat.startForegroundService(this, Intent(this, RecorderService::class.java))
        status.postDelayed({ refresh() }, 600)
    }

    private fun accessibilityOn(): Boolean {
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return cur.contains("$packageName/$packageName.WhatsAppWatcherService")
    }

    private fun refresh() {
        val ok = { b: Boolean -> if (b) "✔" else "✘" }
        status.text = "Xidmət: ${ok(RecorderService.running)}\n" +
            "Mikrofon: ${ok(granted(Manifest.permission.RECORD_AUDIO))}   Telefon: ${ok(granted(Manifest.permission.READ_PHONE_STATE))}\n" +
            "WhatsApp aşkarlama: ${ok(accessibilityOn())}\n" +
            "ADB icazəsi (WRITE_SECURE_SETTINGS): ${ok(granted(Manifest.permission.WRITE_SECURE_SETTINGS))}"
    }

    private fun auto() {
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        val missing = need.filter { !granted(it) }
        if (missing.isNotEmpty()) { pendingAuto = true; requestPermissions(missing.toTypedArray(), 1); return }
        runAuto()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        refresh()
        if (pendingAuto) { pendingAuto = false; runAuto() }
    }

    private fun runAuto() {
        val app = applicationContext
        logView.text = ""
        Thread {
            AdbAuto.log("Wireless debugging yandırılır…")
            if (!AdbAuto.enableWirelessDebugging(app)) AdbAuto.log("(İlk dəfə: əl ilə yandırın)")
            if (AdbAuto.connect(app, 2)) {
                AdbAuto.log("ADB-yə qoşuldu, quraşdırılır…")
                AdbAuto.finishSetup(app)
            } else {
                AdbAuto.log("Cütləşmə lazımdır. “Pair device with pairing code” pəncərəsini açın, sonra bildirişə kodu yazın.")
                AdbAuto.startPairing(app)
                runOnUiThread { try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (e: Exception) { } }
            }
        }.start()
    }

    private fun loadRecordings() {
        list.removeAllViews()
        val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME)
        val c = contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
            "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?", arrayOf("Music/${RecorderService.FOLDER}%"),
            "${MediaStore.Audio.Media.DATE_ADDED} DESC") ?: return
        c.use {
            var n = 0
            while (it.moveToNext() && n < 20) {
                val id = it.getLong(0); val name = it.getString(1); n++
                list.addView(TextView(this).apply {
                    text = "▶ $name"; textSize = 15f; setPadding(0, 16, 0, 16)
                    setOnClickListener {
                        val u = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
                        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "audio/mp4")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    }
                })
            }
            if (n == 0) list.addView(TextView(this).apply { text = "Hələ yazı yoxdur" })
        }
    }
}
