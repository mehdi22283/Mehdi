package az.mirror.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Outline
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var holder: FrameLayout
    private lateinit var preview: PreviewView
    private lateinit var btnMirror: Button
    private lateinit var btnLight: Button
    private lateinit var btnAf: Button
    private lateinit var focusRing: View
    private lateinit var expoBox: LinearLayout
    private lateinit var expoSeek: SeekBar
    private lateinit var expoLabel: TextView

    private var camera: Camera? = null
    private var expoMin = 0
    private var reversed = false
    private var lightOn = false

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera()
            else Toast.makeText(this, "Kamera icazəsi lazımdır", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        holder = findViewById(R.id.holder)
        preview = findViewById(R.id.preview)
        btnMirror = findViewById(R.id.btnMirror)
        btnLight = findViewById(R.id.btnLight)
        btnAf = findViewById(R.id.btnAf)
        focusRing = findViewById(R.id.focusRing)
        expoBox = findViewById(R.id.expoBox)
        expoSeek = findViewById(R.id.expoSeek)
        expoLabel = findViewById(R.id.expoLabel)

        preview.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        preview.scaleType = PreviewView.ScaleType.FILL_CENTER

        holder.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val r = if (lightOn) 28 * resources.displayMetrics.density else 0f
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        holder.clipToOutline = true

        btnMirror.setOnClickListener { toggleReverse() }
        btnLight.setOnClickListener { toggleLight() }
        btnAf.setOnClickListener { autoFocus() }

        expoBox.visibility = View.GONE
        expoSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val idx = p + expoMin
                camera?.cameraControl?.setExposureCompensationIndex(idx)
                expoLabel.text = "☀️ " + (if (idx > 0) "+$idx" else "$idx")
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        setupGestures()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else permLauncher.launch(Manifest.permission.CAMERA)

        Toast.makeText(
            this,
            "Toxun: fokus • Sağa/sola sürüşdür: tərs/düz • 2 dəfə toxun: işıq",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun setupGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                manualFocus(e)
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                toggleLight()
                return true
            }

            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float
            ): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dx) > 120 && abs(dx) > abs(dy) * 1.5f && abs(vx) > 600) {
                    toggleReverse()
                    return true
                }
                return false
            }
        })
        preview.setOnTouchListener { _, ev ->
            detector.onTouchEvent(ev)
            true
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val prev = Preview.Builder().build().also {
                it.setSurfaceProvider(preview.surfaceProvider)
            }
            provider.unbindAll()
            try {
                val cam = provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, prev)
                camera = cam
                setupExposure(cam)
            } catch (e: Exception) {
                Toast.makeText(this, "Ön kamera açılmadı", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setupExposure(cam: Camera) {
        val st = cam.cameraInfo.exposureState
        if (!st.isExposureCompensationSupported) {
            expoBox.visibility = View.GONE
            return
        }
        val range = st.exposureCompensationRange
        expoMin = range.lower
        expoSeek.max = range.upper - range.lower
        expoSeek.progress = -range.lower
        expoBox.visibility = View.VISIBLE
    }

    // Toxunulan yerə əllə fokus (AF + AE), "Avto fokus" düyməsinə qədər saxlanılır
    private fun manualFocus(e: MotionEvent) {
        val cam = camera ?: return
        val point = preview.meteringPointFactory.createPoint(e.x, e.y)
        val action = FocusMeteringAction.Builder(
            point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        ).disableAutoCancel().build()
        cam.cameraControl.startFocusAndMetering(action)
        showRing(e.rawX, e.rawY)
    }

    private fun autoFocus() {
        camera?.cameraControl?.cancelFocusAndMetering()
        focusRing.animate().cancel()
        focusRing.visibility = View.GONE
        Toast.makeText(this, "Avto fokus", Toast.LENGTH_SHORT).show()
    }

    private fun showRing(rawX: Float, rawY: Float) {
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        focusRing.animate().cancel()
        focusRing.x = rawX - loc[0] - focusRing.width / 2f
        focusRing.y = rawY - loc[1] - focusRing.height / 2f
        focusRing.alpha = 1f
        focusRing.scaleX = 1.5f
        focusRing.scaleY = 1.5f
        focusRing.visibility = View.VISIBLE
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            focusRing.animate().alpha(0.5f).setStartDelay(1000).setDuration(400).start()
        }.start()
    }

    // Normal selfi = güzgü kimi. Tərs güzgü = başqalarının səni gördüyü kimi
    private fun toggleReverse() {
        reversed = !reversed
        preview.scaleX = if (reversed) -1f else 1f
        btnMirror.text = if (reversed) "🔄 Tərs: AÇIQ" else "🔄 Tərs"
    }

    // Xiaomi stili: parlaqlıq maksimum, qıraqlar ağ işıq
    private fun toggleLight() {
        lightOn = !lightOn
        val d = resources.displayMetrics.density
        val m = ((if (lightOn) 64 else 0) * d).toInt()
        val bottom = m + if (lightOn) (40 * d).toInt() else 0
        val lp = holder.layoutParams as FrameLayout.LayoutParams
        lp.setMargins(m, m, m, bottom)
        holder.layoutParams = lp
        holder.invalidateOutline()
        root.setBackgroundColor(if (lightOn) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())

        val attrs = window.attributes
        attrs.screenBrightness =
            if (lightOn) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = attrs
        btnLight.text = if (lightOn) "💡 Işıq: AÇIQ" else "💡 Işıq"
    }
}
