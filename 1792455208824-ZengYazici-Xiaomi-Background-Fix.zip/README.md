# Zəng Yazıcı

Android project for the Zəng Yazıcı app.

## Background operation on Xiaomi / HyperOS

The app starts `RecService` as an ongoing foreground service, returns `START_STICKY`, does not stop the service when its launcher task is removed, and opts into restart after device boot once the app has been launched at least once. Android and Xiaomi firmware can still stop apps after a force-stop or under vendor-specific restrictions.

After opening the app on Xiaomi / HyperOS:

1. Open **Parametrlər və fon qoruması → Xiaomi fon qoruması**.
2. Enable **Autostart / Avtomatik başlatma** for Zəng Yazıcı.
3. Set the app's battery policy to **No restrictions / Məhdudiyyət yoxdur**.
4. If your firmware offers a lock on the app card in Recents, lock Zəng Yazıcı there.
5. Keep its ongoing service notification enabled.

## Build

Open this folder in Android Studio or run `gradle assembleDebug` with JDK 17 and Android SDK Platform 34 installed. The included GitHub Actions workflow also builds a debug APK on push or manual dispatch.
