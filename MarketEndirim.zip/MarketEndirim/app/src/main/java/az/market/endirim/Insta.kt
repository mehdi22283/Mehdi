package az.market.endirim

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

/**
 * Instagram linkini açır. Telefonda paket adı "com.insta" ilə başlayan tətbiqlər
 * (rəsmi Instagram, Lite, klonlar və s.) tapılır və seçim təklif olunur.
 *  - 0 tətbiq  → sistemin standart açılışı (brauzer)
 *  - 1 tətbiq  → birbaşa həmin tətbiqlə açılır
 *  - 2+ tətbiq → seçim pəncərəsi (+ "Brauzerdə aç")
 */
object Insta {
    private const val PREFIX = "com.insta"

    private class App(val pkg: String, val label: CharSequence, val icon: Drawable)

    fun open(ctx: Context, url: String) {
        val pm = ctx.packageManager
        val apps = LinkedHashMap<String, App>()
        try {
            val view = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(view, 0) + pm.queryIntentActivities(main, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg.startsWith(PREFIX) && pkg !in apps) apps[pkg] = App(pkg, ri.loadLabel(pm), ri.loadIcon(pm))
            }
        } catch (e: Exception) {
        }
        val list = apps.values.sortedBy { it.pkg }
        when {
            list.isEmpty() -> openDefault(ctx, url)
            list.size == 1 || ctx !is Activity -> launch(ctx, list[0].pkg, url)
            else -> chooser(ctx, list, url)
        }
    }

    private fun chooser(ctx: Context, list: List<App>, url: String) {
        val dens = ctx.resources.displayMetrics.density
        val adapter = object : ArrayAdapter<App>(ctx, android.R.layout.simple_list_item_1, list) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(ctx).apply {
                    textSize = 16f
                    gravity = Gravity.CENTER_VERTICAL
                    val p = (14 * dens).toInt()
                    setPadding(p, p, p, p)
                    compoundDrawablePadding = (14 * dens).toInt()
                }
                val a = getItem(position)!!
                val size = (40 * dens).toInt()
                a.icon.setBounds(0, 0, size, size)
                tv.setCompoundDrawables(a.icon, null, null, null)
                tv.text = a.label.toString() + "\n" + a.pkg
                return tv
            }
        }
        AlertDialog.Builder(ctx)
            .setTitle("Instagram-ı bununla aç")
            .setAdapter(adapter) { _, which -> launch(ctx, list[which].pkg, url) }
            .setNeutralButton("Brauzerdə aç") { _, _ -> openDefault(ctx, url) }
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun launch(ctx: Context, pkg: String, url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg))
        } catch (e: ActivityNotFoundException) {
            // klon linki qəbul etmirsə, tətbiqi sadəcə aç
            val li = ctx.packageManager.getLaunchIntentForPackage(pkg)
            if (li != null) ctx.startActivity(li) else openDefault(ctx, url)
        }
    }

    private fun openDefault(ctx: Context, url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Link açılmadı", Toast.LENGTH_SHORT).show()
        }
    }
}
