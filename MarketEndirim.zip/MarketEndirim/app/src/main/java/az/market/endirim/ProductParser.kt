package az.market.endirim

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** OCR sətri və koordinatları. */
data class OLine(val text: String, val l: Int, val t: Int, val r: Int, val b: Int) {
    val w get() = r - l
    val h get() = b - t
}

data class RawProduct(val name: String, val price: Double, val old: Double?, val promo: Boolean = false)

/**
 * OCR sətirlərindən "məhsul adı + qiymət" cütlərini çıxarır (evristika):
 *  1) qiymət sətirləri (2.49, 2,49 ₼, 2 49 AZN) ayrılır;
 *  2) qalan mətn sətirləri bir-birinə yaxın olduqda (üst-üstə) məhsul adına birləşdirilir;
 *  3) hər qiymət ən yaxın ad qrupuna bağlanır; iki qiymət varsa kiçiyi yeni, böyüyü köhnə qiymətdir.
 */
object ProductParser {

    private const val UNITS = "q|l|lt|ltr|litr|litre|ml|cl|kq|kg|qr|gr|g|mq|mg|ədəd|eded|əd|ed|sm|mm|m|pc|pcs|шт|кг|г|гр|л|мл|уп"
    private val PRICE = Regex("""(?iu)(?<![\d.,])(\d{1,3})\s?[.,]\s?(\d{2})(?![\d]|[.,]\d)(?!\s?(?:$UNITS)(?![\p{L}\d]))""")
    private val PRICE_INT = Regex("""(?i)(?<![\d.,])(\d{1,3})\s?(?:₼|azn|man\b)""")
    private val PRICE_SPLIT = Regex("""(?i)^\s*(\d{1,2})\s(\d{2})\s*(?:₼|azn|man\.?|qəp\.?|qep\.?)?\s*$""")

    private val STOP = listOf(
        "endirim", "aksiya", "kampaniya", "qiymet", "tarix", "unvan", "www", "http", "instagram", "facebook", "whatsapp",
        "kataloq", "jurnal", "supermarket", "magaza", "bonus", "kassa", "hediyye", "mehsullar", "tel", "mob", "filial",
        "bitir", "baslayir", "yeni", "super", "teklif", "sertlerle", "qaydalar", "oktyabr", "noyabr", "dekabr", "yanvar",
        "fevral", "mart", "aprel", "may", "iyun", "iyul", "avqust", "sentyabr"
    )

    /** Faiz ifadələri (-30%, 30 %, %30, 12,5%) qiymət deyil — mətndən çıxarılır. */
    private val PERCENT = Regex("""(?:[-–−+]\s?)?(?:\d{1,3}(?:[.,]\d+)?\s?%|%\s?\d{1,3}(?:[.,]\d+)?)""")

    private fun stripPercent(text: String): String = text.replace(PERCENT, " ")

    private val DATE = Regex("""\d{1,2}\s?[./-]\s?\d{1,2}\s?[./-]\s?\d{2,4}""")
    private val ZERO_CENTS = Regex("""(?i)^\s*0\s?(\d{2})\s*(?:₼|azn|man\.?|qəp\.?|qep\.?)?\s*$""")

    fun findPrices(text: String): List<Double> {
        val t = stripPercent(text)
        // telefon, tarix, barkod — qiymət deyil
        if (t.count { it.isDigit() } > 8 || DATE.containsMatchIn(t)) return emptyList()
        val out = ArrayList<Double>()
        // "079" / "0 79 ₼" — böyük 0 + kiçik qəpik yazılışı, 0.79-dur (79 deyil)
        ZERO_CENTS.matchEntire(t)?.let { m ->
            out.add("0.${m.groupValues[1]}".toDouble())
            return out
        }
        PRICE_SPLIT.matchEntire(t)?.let { m ->
            out.add("${m.groupValues[1]}.${m.groupValues[2]}".toDouble())
            return out
        }
        for (m in PRICE.findAll(t)) out.add("${m.groupValues[1]}.${m.groupValues[2]}".toDouble())
        if (out.isEmpty()) for (m in PRICE_INT.findAll(t)) out.add(m.groupValues[1].toDouble())
        return out.filter { it in 0.05..999.0 }
    }

    private val LONE_INT = Regex("^\\s*(\\d{1,2})\\s*$")
    private val BIG_DIGIT = Regex("^\\s*(\\d{1,2})\\s*$")
    private val CENTS = Regex("""(?i)^\s*(\d{2})\s*(?:₼|azn|man\.?|qəp\.?|qep\.?)?\s*$""")

    /**
     * Qiymət tez-tez böyük tam hissə + yuxarı sağda kiçik qəpik kimi çəkilir ("0" və "79" ayrı sətir).
     * Belə cütlər bir sətirə ("0.79 ₼") birləşdirilir; yoxsa "79" tək qalıb 79 ₼ kimi oxunurdu.
     */
    private fun mergeSuper(lines: List<OLine>): List<OLine> {
        val used = BooleanArray(lines.size)
        val merged = ArrayList<OLine>()
        for (i in lines.indices) {
            val big = lines[i]
            if (used[i] || !BIG_DIGIT.matches(big.text) || big.h < 8) continue
            var bestJ = -1
            var bestGap = Int.MAX_VALUE
            for (j in lines.indices) {
                if (j == i || used[j]) continue
                val c = lines[j]
                if (!CENTS.matches(c.text)) continue
                if (c.h >= 0.9f * big.h) continue                                  // qəpik daha kiçik yazılır
                val gapX = c.l - big.r
                if (gapX < -0.3f * big.w || gapX > 1.0f * big.h) continue          // tam hissənin sağında
                val cyC = (c.t + c.b) / 2
                val cyB = (big.t + big.b) / 2
                if (cyC >= cyB) continue                                           // yuxarıda dayanır
                if (c.t < big.t - 0.6f * big.h || c.b > big.b) continue
                if (gapX < bestGap) { bestGap = gapX; bestJ = j }
            }
            if (bestJ < 0) continue
            val c = lines[bestJ]
            used[i] = true; used[bestJ] = true
            val whole = BIG_DIGIT.matchEntire(big.text)!!.groupValues[1].toInt()
            val cents = CENTS.matchEntire(c.text)!!.groupValues[1]
            merged.add(OLine("$whole.$cents ₼", minOf(big.l, c.l), minOf(big.t, c.t), maxOf(big.r, c.r), maxOf(big.b, c.b)))
        }
        if (merged.isEmpty()) return lines
        return lines.filterIndexed { k, _ -> !used[k] } + merged
    }

    /** Sətir qiymətə oxşayırmı (nişan içində OCR nəticəsini yoxlamaq üçün). */
    fun looksLikePrice(text: String): Boolean = findPrices(text).isNotEmpty() || LONE_INT.matches(text)

    /** Sətirdə yalnız bir-iki rəqəm varsa ("5") — Bravo-da tam qiymətdir (səhifə kənarındakı nömrələr istisna). */
    private fun loneInt(ln: OLine, pageH: Int, pct: List<OLine>): List<Double> {
        val m = LONE_INT.matchEntire(ln.text) ?: return emptyList()
        if (ln.t < 0.04f * pageH || ln.b > 0.96f * pageH) return emptyList()
        // yanında "%" işarəsi olan ədəd (məs. "30" + "%") endirim faizidir, qiymət deyil
        if (pct.any { p ->
                val dx = max(0, max(p.l - ln.r, ln.l - p.r))
                val dy = max(0, max(p.t - ln.b, ln.t - p.b))
                dx <= ln.h && dy <= 0.6f * ln.h
            }) return emptyList()
        val v = m.groupValues[1].toDouble()
        return if (v >= 1) listOf(v) else emptyList()
    }

    private fun stripPrices(text: String): String =
        stripPercent(text).replace(PRICE, " ").replace(PRICE_INT, " ").replace("₼", " ")
            .replace(Regex("(?i)\\bazn\\b|\\bman\\.?\\b|\\bqəp\\.?"), " ")

    private fun cleanName(raw: String): String =
        raw.replace(Regex("[|_•*«»\"“”]+"), " ").replace(Regex("\\s+"), " ").trim(' ', '-', '.', ',', ':', ';', '/')

    private fun isValidName(n: String): Boolean {
        val letters = n.count { it.isLetter() }
        if (letters < 3 || n.length > 90) return false
        if (letters.toFloat() / n.count { !it.isWhitespace() }.coerceAtLeast(1) < 0.6f) return false
        val tokens = Categorizer.norm(n).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return false
        // bütün sözlər texniki/reklam sözüdürsə — məhsul deyil
        return tokens.any { tk -> tk.length >= 3 && STOP.none { sw -> tk == sw || (sw.length >= 5 && tk.startsWith(sw)) } }
    }

    private class Group(val lines: MutableList<OLine>) {
        var l = Int.MAX_VALUE; var t = Int.MAX_VALUE; var r = 0; var b = 0
        fun fit() { lines.forEach { l = min(l, it.l); t = min(t, it.t); r = max(r, it.r); b = max(b, it.b) } }
    }

    private fun related(a: OLine, b: OLine): Boolean {
        val minH = min(a.h, b.h).coerceAtLeast(1)
        val maxH = max(a.h, b.h)
        val vgap = max(a.t, b.t) - min(a.b, b.b)
        val ox = min(a.r, b.r) - max(a.l, b.l)
        val minW = min(a.w, b.w).coerceAtLeast(1)
        return vgap >= -0.25f * minH && vgap <= 0.9f * minH && ox >= 0.35f * minW && maxH <= 1.7f * minH
    }

    /**
     * framed(ln) — qiymət sətri çərçivə (qırmızı kənarlı qutu) içindədirsə true.
     * Çərçivəli qiymət = endirimli (yeni) qiymət; çərçivəsiz yanındakı ədədlər köhnə qiymət və ya təsadüfi rəqəmdir.
     */
    fun parse(rawLines: List<OLine>, pageW: Int, pageH: Int, framed: (OLine) -> Boolean = { false }, struck: (OLine) -> Boolean = { false }): List<RawProduct> {
        val lines = mergeSuper(rawLines)
        val priceLines = ArrayList<Pair<OLine, List<Double>>>()
        val framedSet = HashSet<OLine>()
        val struckSet = HashSet<OLine>()      // üstündən xətt çəkilmiş = köhnə (endirimsiz) qiymət
        val nameLines = ArrayList<OLine>()
        val result = ArrayList<RawProduct>()
        val pct = lines.filter { it.text.contains('%') }

        for (ln in lines) {
            // tək rəqəm ("5", "99") yalnız qiymət nişanı/çərçivəsi içindədirsə qiymət sayılır — əks halda təsadüfi ədəddir
            val prices = findPrices(ln.text).ifEmpty {
                if (LONE_INT.matches(ln.text) && framed(ln)) loneInt(ln, pageH, pct) else emptyList()
            }
            if (prices.isEmpty()) {
                if (ln.text.count { it.isLetter() } >= 3) nameLines.add(ln)
                continue
            }
            val rest = cleanName(stripPrices(ln.text))
            if (rest.count { it.isLetter() } <= 5) {
                priceLines.add(ln to prices)
                if (struck(ln)) struckSet.add(ln) else if (framed(ln)) framedSet.add(ln)
            } else if (isValidName(rest)) {
                result.add(makeRaw(rest, prices))     // ad və qiymət eyni sətirdə
            }
        }

        // ad sətirlərini qruplaşdır (union-find)
        val parent = IntArray(nameLines.size) { it }
        fun find(x: Int): Int { var a = x; while (parent[a] != a) { parent[a] = parent[parent[a]]; a = parent[a] }; return a }
        for (i in nameLines.indices) for (j in i + 1 until nameLines.size) {
            if (related(nameLines[i], nameLines[j])) parent[find(i)] = find(j)
        }
        val byRoot = LinkedHashMap<Int, Group>()
        for (i in nameLines.indices) byRoot.getOrPut(find(i)) { Group(ArrayList()) }.lines.add(nameLines[i])
        val groups = byRoot.values.toList()
        groups.forEach { g -> g.lines.sortBy { it.t }; g.fit() }

        // yaxın qiymət sətirləri (yeni + köhnə) bir "qiymət qrupu" olur: eyni pəncərənin qiymətləri
        val pp = IntArray(priceLines.size) { it }
        fun pf(x: Int): Int { var a = x; while (pp[a] != a) { pp[a] = pp[pp[a]]; a = pp[a] }; return a }
        for (i in priceLines.indices) for (j in i + 1 until priceLines.size) {
            val a = priceLines[i].first; val b = priceLines[j].first
            val maxH = max(a.h, b.h).coerceAtLeast(1)
            val maxW = max(a.w, b.w).coerceAtLeast(1)
            val dcx = kotlin.math.abs((a.l + a.r) / 2 - (b.l + b.r) / 2)
            val dcy = kotlin.math.abs((a.t + a.b) / 2 - (b.t + b.b) / 2)
            if (dcx <= 1.7f * maxW && dcy <= 2.4f * maxH) pp[pf(i)] = pf(j)
        }
        class PG { var l = Int.MAX_VALUE; var t = Int.MAX_VALUE; var r = 0; var b = 0; val prices = ArrayList<Double>(); val inFrame = ArrayList<Double>(); val plain = ArrayList<Double>(); val struckP = ArrayList<Double>() }
        val pgs = LinkedHashMap<Int, PG>()
        for (i in priceLines.indices) {
            val (ln, prices) = priceLines[i]
            val g = pgs.getOrPut(pf(i)) { PG() }
            g.l = min(g.l, ln.l); g.t = min(g.t, ln.t); g.r = max(g.r, ln.r); g.b = max(g.b, ln.b)
            g.prices.addAll(prices)
            when {
                ln in struckSet -> g.struckP.addAll(prices)
                ln in framedSet -> g.inFrame.addAll(prices)
                else -> g.plain.addAll(prices)
            }
        }

        // Hər qiymət YALNIZ öz xanasındakı ada bağlanır: namizədlər məsafəyə görə düzülür, ad və qiymət qrupu
        // hər biri ən çoxu bir dəfə istifadə olunur (qonşu xananın qiyməti götürülmür, eyni qiymət iki adda təkrarlanmır).
        class Cand(val pg: PG, val g: Group, val d: Double)
        val cands = ArrayList<Cand>()
        for (pg in pgs.values) {
            val pw = (pg.r - pg.l).coerceAtLeast(1)
            for (g in groups) {
                val gw = (g.r - g.l).coerceAtLeast(1)
                val dx = max(0, max(g.l - pg.r, pg.l - g.r))
                val dy = max(0, max(g.t - pg.b, pg.t - g.b))
                if (dx > 0.18f * pageW || dy > 0.12f * pageH) continue
                if (dx > 0.6f * max(gw, pw)) continue          // yan sütun/yan xana — başqa məhsuldur
                var d = hypot(dx.toDouble(), dy * 1.3)
                if (pg.b < g.t) d *= 1.6                       // qiymət adın üstündədirsə — az ehtimal
                cands.add(Cand(pg, g, d))
            }
        }
        cands.sortBy { it.d }
        val usedP = HashSet<PG>()
        val usedG = HashSet<Group>()
        for (cd in cands) {
            if (cd.pg in usedP || cd.g in usedG) continue
            val name = cleanName(cd.g.lines.take(3).joinToString(" ") { it.text })
            if (!isValidName(name)) continue
            usedP.add(cd.pg); usedG.add(cd.g)
            result.add(makeFramed(name, cd.pg.inFrame, cd.pg.plain, cd.pg.struckP, cd.pg.prices))
        }
        return result
    }

    /** Çərçivəli qiymət varsa — o yeni qiymətdir; köhnə qiymət çərçivəsizlərdən seçilir. */
    private fun makeFramed(name: String, inFrame: List<Double>, plain: List<Double>, struckP: List<Double>, all: List<Double>): RawProduct {
        // üstündən xətt çəkilmiş ədəd = köhnə qiymət; yeni qiymət — çərçivəli, yoxdursa digər ədədlərin ən kiçiyi
        if (struckP.isNotEmpty()) {
            val fresh = if (inFrame.isNotEmpty()) inFrame else plain
            val lo = fresh.minOrNull()
            val old = if (lo != null) struckP.maxOrNull()?.takeIf { it > lo * 1.02 && it <= lo * 10 } else null
            if (lo != null && old != null) return RawProduct(name, lo, old, true)
        }
        if (inFrame.isEmpty()) return makeRaw(name, all)                       // çərçivəsiz — adi (endirimsiz) qiymət
        if (plain.isEmpty()) return makeRaw(name, inFrame).copy(promo = true)
        val lo = inFrame.minOrNull() ?: return makeRaw(name, all)
        val old = plain.filter { it > lo * 1.02 && it <= lo * 6 }.maxOrNull()
        return RawProduct(name, lo, old, true)
    }

    private fun makeRaw(name: String, prices: List<Double>): RawProduct {
        val lo = prices.minOrNull() ?: 0.0
        val hi = prices.maxOrNull() ?: lo
        val old = if (prices.size >= 2 && hi > lo * 1.02 && hi <= lo * 6) hi else null
        return RawProduct(name, lo, old, old != null)
    }
}
