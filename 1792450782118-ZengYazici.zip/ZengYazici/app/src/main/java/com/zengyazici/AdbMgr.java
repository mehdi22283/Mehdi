package com.zengyazici;

import android.content.Context;
import android.os.Build;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import java.util.Random;
import sun.security.x509.AlgorithmId;
import sun.security.x509.CertificateAlgorithmId;
import sun.security.x509.CertificateExtensions;
import sun.security.x509.CertificateIssuerName;
import sun.security.x509.CertificateSerialNumber;
import sun.security.x509.CertificateSubjectName;
import sun.security.x509.CertificateValidity;
import sun.security.x509.CertificateVersion;
import sun.security.x509.CertificateX509Key;
import sun.security.x509.KeyIdentifier;
import sun.security.x509.PrivateKeyUsageExtension;
import sun.security.x509.SubjectKeyIdentifierExtension;
import sun.security.x509.X500Name;
import sun.security.x509.X509CertImpl;
import sun.security.x509.X509CertInfo;

/** Lokal ADB bağlantısı. Açar bir dəfə yaradılır və saxlanılır (yenidən icazə soruşulmasın deyə). */
public class AdbMgr extends AbsAdbConnectionManager {
    private static AdbMgr I;

    public static synchronized AdbMgr get(Context c) throws Exception {
        if (I == null) I = new AdbMgr(c.getApplicationContext());
        return I;
    }

    public static AdbMgr peek() { return I; }

    private PrivateKey pk;
    private Certificate cert;

    private AdbMgr(Context c) throws Exception {
        setApi(Build.VERSION.SDK_INT);
        File kf = new File(c.getFilesDir(), "adb.key");
        File cf = new File(c.getFilesDir(), "adb.crt");
        if (kf.exists() && cf.exists()) {
            try {
                pk = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(kf.toPath())));
                cert = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(Files.readAllBytes(cf.toPath())));
            } catch (Exception e) { pk = null; cert = null; }
        }
        if (pk == null) {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048, SecureRandom.getInstance("SHA1PRNG"));
            KeyPair kp = g.generateKeyPair();
            PublicKey pub = kp.getPublic();
            pk = kp.getPrivate();
            String alg = "SHA512withRSA";
            Date nb = new Date();
            Date na = new Date(System.currentTimeMillis() + 3650L * 86400000L);
            CertificateExtensions ext = new CertificateExtensions();
            ext.set("SubjectKeyIdentifier", new SubjectKeyIdentifierExtension(new KeyIdentifier(pub).getIdentifier()));
            X500Name name = new X500Name("CN=ZengYazici");
            ext.set("PrivateKeyUsage", new PrivateKeyUsageExtension(nb, na));
            X509CertInfo info = new X509CertInfo();
            info.set("version", new CertificateVersion(2));
            info.set("serialNumber", new CertificateSerialNumber(new Random().nextInt() & Integer.MAX_VALUE));
            info.set("algorithmID", new CertificateAlgorithmId(AlgorithmId.get(alg)));
            info.set("subject", new CertificateSubjectName(name));
            info.set("key", new CertificateX509Key(pub));
            info.set("validity", new CertificateValidity(nb, na));
            info.set("issuer", new CertificateIssuerName(name));
            info.set("extensions", ext);
            X509CertImpl impl = new X509CertImpl(info);
            impl.sign(pk, alg);
            cert = impl;
            Files.write(kf.toPath(), pk.getEncoded());
            Files.write(cf.toPath(), cert.getEncoded());
        }
    }

    public PrivateKey getPrivateKey() { return pk; }
    public Certificate getCertificate() { return cert; }
    public String getDeviceName() { return "ZengYazici"; }
}
