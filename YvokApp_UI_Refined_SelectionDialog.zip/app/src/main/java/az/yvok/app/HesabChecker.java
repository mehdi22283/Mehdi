package az.yvok.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Əsas yoxlama mənbəyi: hesab.az. Bütün YVÖK yoxlamaları bu səhifə üzərindən aparılır.
 * Abonent -> Ad, Soyad, Atasının adı; Balans -> Borc ("+" ilə başlayırsa Borc 0).
 * Bütün callback-lər UI axınında çağırılır.
 */
public class HesabChecker {
    public interface Callback {
        void onResult(String name, String debt);
        void onFail();
    }

    private static final String BASE_URL =
            "https://hesab.az/unregistered/#/direct-pay/government/gppbelediyye/parameters/?portalPay=kommunal_az&lang=az&yvok=";
    private static final int FIRST_POLL_MS = 1200;
    private static final int POLL_MS = 400;
    private static final int MAX_TRIES = 55;          // ~ 23 saniyə
    private static final int MAX_JOBS_PER_VIEW = 15;  // bu qədər sorğudan sonra gizli səhifə təzələnir

    private static final String[] BLOCKED_EXT = {".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".avif", ".bmp", ".ico",
            ".woff", ".woff2", ".ttf", ".otf", ".eot", ".mp4", ".webm", ".mp3", ".ogg", ".wav"};
    private static final String[] BLOCKED_HOST = {"google-analytics", "googletagmanager", "doubleclick", "facebook", "yandex",
            "hotjar", "fonts.googleapis", "fonts.gstatic", "clarity.ms", "youtube"};

    private static class Req {
        final String code; final Callback cb;
        Req(String code, Callback cb) { this.code = code; this.cb = cb; }
    }

    private class Slot {
        WebView wv; Req cur; int session = 0; int tries = 0; int jobs = 0;
    }

    private final Activity act;
    private final FrameLayout host;
    private final int index, width, height, maxParallel;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ArrayDeque<Req> queue = new ArrayDeque<>();
    private final ArrayList<Slot> slots = new ArrayList<>();
    private final String js;
    private boolean destroyed = false;

    public HesabChecker(Activity act, FrameLayout host, int index, int width, int height, int maxParallel) {
        this.act = act; this.host = host; this.index = index; this.width = width; this.height = height;
        this.maxParallel = Math.max(1, maxParallel);
        this.js = readAsset("hesab.js");
    }

    private String readAsset(String name) {
        try (InputStream in = act.getAssets().open(name)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[4096]; int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return bo.toString("UTF-8");
        } catch (Exception e) { return "''"; }
    }

    /** YVÖK-ü hesab.az-da yoxlayır (növbəyə qoyulur, eyni anda maxParallel qədəri işləyir) */
    public void check(String code, Callback cb) {
        if (destroyed) { cb.onFail(); return; }
        queue.addLast(new Req(code, cb));
        pump();
    }

    /** növbəni və işləyənləri ləğv edir (callback çağırılmır) */
    public void clear() {
        queue.clear();
        for (Slot s : slots) { s.session++; s.cur = null; }
    }

    /** növbədə gözləyənləri onFail() ilə bağlayır (artıq işləyənlər başa çatır): "Dayandır" üçün */
    public void cancelPending() {
        ArrayList<Req> l = new ArrayList<>(queue);
        queue.clear();
        for (Req r : l) r.cb.onFail();
    }

    public void destroy() {
        destroyed = true;
        queue.clear();
        h.removeCallbacksAndMessages(null);
        for (Slot s : slots) destroyView(s);
        slots.clear();
    }

    private void destroyView(Slot s) {
        try { s.wv.stopLoading(); host.removeView(s.wv); s.wv.destroy(); } catch (Exception ignored) { }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private Slot newSlot() {
        final Slot s = new Slot();
        WebView wv = new WebView(act);
        wv.setFocusable(false);
        wv.setFocusableInTouchMode(false);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setDomStorageEnabled(true);
        wv.getSettings().setLoadsImagesAutomatically(false);
        wv.getSettings().setBlockNetworkImage(true);
        wv.setAlpha(0.01f);
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return block(r); }
        });
        host.addView(wv, index, new FrameLayout.LayoutParams(width, height));
        s.wv = wv;
        slots.add(s);
        return s;
    }

    private void pump() {
        while (!queue.isEmpty() && !destroyed) {
            Slot s = null;
            for (Slot x : slots) if (x.cur == null) { s = x; break; }
            if (s == null && slots.size() < maxParallel) s = newSlot();
            if (s == null) return;
            start(s, queue.pollFirst());
        }
    }

    private void start(final Slot s, final Req r) {
        if (s.jobs >= MAX_JOBS_PER_VIEW) {            // yaddaş yığılmasın: səhifə təzələnir
            slots.remove(s); destroyView(s);
            final Slot ns = newSlot();
            start(ns, r);
            return;
        }
        s.jobs++;
        s.cur = r; s.tries = 0;
        final int ses = ++s.session;
        // hash-route eyni səhifədə dəyişməsin deyə əvvəlcə boş səhifə yüklənir
        s.wv.loadUrl("about:blank");
        h.postDelayed(() -> {
            if (s.session != ses || destroyed) return;
            s.wv.loadUrl(BASE_URL + Uri.encode(r.code));
            h.postDelayed(() -> poll(s, ses), FIRST_POLL_MS);
        }, 120);
    }

    private void poll(final Slot s, final int ses) {
        if (s.session != ses || destroyed) return;
        s.tries++;
        s.wv.evaluateJavascript(js, raw -> {
            if (s.session != ses || destroyed) return;
            String abonent = "", yvok = "", balans = "";
            try {
                Object v = new JSONTokener(raw == null ? "null" : raw).nextValue();
                if (v instanceof String) {
                    JSONObject o = new JSONObject((String) v);
                    abonent = o.optString("abonent").trim();
                    yvok = o.optString("yvok").trim();
                    balans = o.optString("balans").trim();
                }
            } catch (Exception ignored) { }
            final Req r = s.cur;
            if (r == null) return;
            boolean yvokOk = yvok.isEmpty() || yvok.replaceAll("\\s", "").equalsIgnoreCase(r.code.replaceAll("\\s", ""));
            String debt = balans.isEmpty() ? null : debtFromBalans(balans);
            if (!abonent.isEmpty() && debt != null && yvokOk) {
                finish(s, r, abonent.replaceAll("\\s+", " "), debt);
            } else if (s.tries >= MAX_TRIES) {
                finish(s, r, null, null);
            } else {
                h.postDelayed(() -> poll(s, ses), POLL_MS);
            }
        });
    }

    private void finish(Slot s, Req r, String name, String debt) {
        s.session++; s.cur = null;
        if (name != null) r.cb.onResult(name, debt); else r.cb.onFail();
        pump();
    }

    /** Balans -> Borc: "+" ilə başlayırsa 0; "-" varsa mütləq qiymət; rəqəm tapılmırsa null */
    static String debtFromBalans(String balans) {
        String t = balans.trim().replace('\u2212', '-').replace('\u2013', '-');
        if (t.startsWith("+")) return "0";
        Matcher m = Pattern.compile("\\d[\\d\\s\\u00A0]*(?:[.,]\\d{1,2})?").matcher(t);
        if (!m.find()) return null;
        try {
            double d = Math.abs(Double.parseDouble(m.group().replaceAll("[\\s\\u00A0]", "").replace(',', '.')));
            if (d == Math.floor(d)) return String.valueOf((long) d);
            return String.format(Locale.US, "%.2f", d);
        } catch (Exception e) { return null; }
    }

    private static WebResourceResponse block(WebResourceRequest r) {
        if (r == null || r.getUrl() == null || r.isForMainFrame()) return null;
        String path = r.getUrl().getPath() == null ? "" : r.getUrl().getPath().toLowerCase();
        String host = r.getUrl().getHost() == null ? "" : r.getUrl().getHost().toLowerCase();
        String accept = "";
        if (r.getRequestHeaders() != null && r.getRequestHeaders().get("Accept") != null)
            accept = r.getRequestHeaders().get("Accept").toLowerCase();
        boolean b = accept.startsWith("image/") || accept.startsWith("video/") || accept.startsWith("audio/") || accept.startsWith("font/");
        for (String e : BLOCKED_EXT) if (path.endsWith(e)) { b = true; break; }
        for (String x : BLOCKED_HOST) if (host.contains(x)) { b = true; break; }
        return b ? new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0])) : null;
    }
}
