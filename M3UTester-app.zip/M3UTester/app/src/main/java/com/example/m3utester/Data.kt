package com.example.m3utester

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Ch(val name: String, val url: String, var ok: Boolean? = null)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("m3u", 0)
    fun save(c: Context, l: List<Ch>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("n", it.name).put("u", it.url).put("o", it.ok ?: JSONObject.NULL)) }
        p(c).edit().putString("list", a.toString()).apply()
    }
    fun load(c: Context): MutableList<Ch> {
        val s = p(c).getString("list", null) ?: return mutableListOf()
        val a = JSONArray(s)
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Ch(o.getString("n"), o.getString("u"), if (o.isNull("o")) null else o.getBoolean("o"))
        }
    }
}

fun parseM3u(t: String): MutableList<Ch> {
    val r = mutableListOf<Ch>(); var n: String? = null
    for (l in t.lines().map { it.trim() }) {
        if (l.startsWith("#EXTINF")) n = l.substringAfterLast(",").trim()
        else if (l.isNotEmpty() && !l.startsWith("#")) { r.add(Ch(n ?: l, l)); n = null }
    }
    return r
}

private val http = OkHttpClient.Builder()
    .connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()

fun alive(u: String): Boolean = try {
    http.newCall(Request.Builder().url(u).build()).execute().use {
        it.isSuccessful && (it.body?.source()?.request(1) ?: false)
    }
} catch (e: Exception) { false }

suspend fun testAll(l: List<Ch>, onEach: () -> Unit = {}) = coroutineScope {
    val s = Semaphore(10)
    l.map { ch ->
        async(Dispatchers.IO) {
            s.withPermit { ch.ok = alive(ch.url) }
            withContext(Dispatchers.Main) { onEach() }
        }
    }.awaitAll()
}

fun alarm(c: Context, title: String, text: String, id: Int) {
    val nm = c.getSystemService(NotificationManager::class.java)
    val ch = NotificationChannel("alarm", "Kanal alarmları", NotificationManager.IMPORTANCE_HIGH).apply {
        setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        enableVibration(true)
    }
    nm.createNotificationChannel(ch)
    nm.notify(id, NotificationCompat.Builder(c, "alarm")
        .setSmallIcon(android.R.drawable.ic_dialog_alert)
        .setContentTitle(title).setContentText(text)
        .setCategory(NotificationCompat.CATEGORY_ALARM)
        .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build())
}

data class Ev(val t: Long, val name: String, val url: String, val ok: Boolean)

object History {
    private fun p(c: Context) = c.getSharedPreferences("m3u", 0)
    fun load(c: Context): List<Ev> {
        val s = p(c).getString("hist", null) ?: return emptyList()
        val a = JSONArray(s)
        return List(a.length()) {
            val o = a.getJSONObject(it)
            Ev(o.getLong("t"), o.getString("n"), o.getString("u"), o.getBoolean("o"))
        }
    }
    fun add(c: Context, e: List<Ev>) {
        if (e.isEmpty()) return
        val all = (load(c) + e).takeLast(5000)
        val a = JSONArray()
        all.forEach { a.put(JSONObject().put("t", it.t).put("n", it.name).put("u", it.url).put("o", it.ok)) }
        p(c).edit().putString("hist", a.toString()).apply()
    }
}

fun diff(old: List<Boolean?>, l: List<Ch>): List<Ev> =
    l.indices.filter { old[it] != null && l[it].ok != null && old[it] != l[it].ok }
        .map { Ev(System.currentTimeMillis(), l[it].name, l[it].url, l[it].ok == true) }
