package az.videoyabax;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * TV-də işləyən kiçik HTTP server.
 *
 * Video TV-nin yaddaşına YAZILMIR. Telefondakı səhifə faylı özündə saxlayır, player (VLC) isə
 * 127.0.0.1-dəki /stream ünvanından oxuyur. Server yalnız kiçik dairəvi RAM buferi saxlayır:
 *  - player bufer daxilində oxuyursa, telefon ardıcıl göndərməyə davam edir;
 *  - player başqa yerə atlayırsa (irəli/geri), server telefona "buradan göndər" əmri verir.
 * Bufer dolanda server telefondan oxumağı dayandırır, TCP özü telefonun göndərməsini yavaşladır.
 */
public class VideoServer {
    public static final int PORT = 3169;

    static final int RING = 8 * 1024 * 1024;   // RAM-da saxlanan maksimum həcm
    static final int BACK = 1024 * 1024;       // player-in arxasında saxlanan hissə (kiçik geri atlamalar üçün)
    static final long STALL_MS = 60000;        // telefondan bu qədər müddət data gəlməsə, oxuma dayandırılır

    public interface Listener { void onNewVideo(); }

    public static volatile Listener listener;
    public static volatile int gen = 0;
    public static volatile boolean hasVideo = false;
    public static volatile String name = "";

    private static final Object LOCK = new Object();
    private static long total = 0;
    private static byte[] ring;
    private static long winStart, winEnd;   // ring-də [winStart, winEnd) aralığındakı baytlar var
    private static int feedId;              // hər yeni "buradan göndər" əmrində artır
    private static long feedOff;            // telefonun göndərməli olduğu mövqe
    private static int sid;                 // ən son /stream bağlantısının nömrəsi (köhnələr dayanır)

    private final String page;
    private ServerSocket ss;
    private volatile boolean running;

    public VideoServer(Context c) {
        String p = "";
        try {
            InputStream is = c.getAssets().open("index.html");
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] b = new byte[8192];
                int n;
                while ((n = is.read(b)) > 0) bo.write(b, 0, n);
                p = bo.toString("UTF-8");
            } finally {
                is.close();
            }
        } catch (IOException ignored) { }
        page = p;
    }

    public void start() {
        running = true;
        new Thread(() -> {
            while (running) {
                try {
                    if (ss == null || ss.isClosed()) {
                        ss = new ServerSocket();
                        ss.setReuseAddress(true);
                        ss.bind(new InetSocketAddress(PORT));
                    }
                    final Socket s = ss.accept();
                    new Thread(() -> handle(s)).start();
                } catch (Exception e) {
                    try { Thread.sleep(1000); } catch (Exception ignored) { }
                }
            }
        }).start();
    }

    public void stop() {
        running = false;
        try { if (ss != null) ss.close(); } catch (Exception ignored) { }
    }

    private void handle(Socket s) {
        try {
            s.setTcpNoDelay(true);
            s.setSoTimeout(30000);
            InputStream in = new BufferedInputStream(s.getInputStream(), 65536);
            OutputStream out = s.getOutputStream();
            String line = readLine(in);
            if (line == null) return;
            String[] p = line.split(" ");
            if (p.length < 2) return;
            String method = p[0], target = p[1];
            Map<String, String> h = new HashMap<>();
            String l;
            while ((l = readLine(in)) != null && !l.isEmpty()) {
                int i = l.indexOf(':');
                if (i > 0) h.put(l.substring(0, i).trim().toLowerCase(), l.substring(i + 1).trim());
            }
            String path = target, query = "";
            int q = target.indexOf('?');
            if (q >= 0) { path = target.substring(0, q); query = target.substring(q + 1); }

            if (method.equals("POST") && path.equals("/open")) {
                open(out, query);
            } else if (path.equals("/cmd")) {
                cmd(out, query);
            } else if ((method.equals("PUT") || method.equals("POST")) && path.equals("/feed")) {
                feed(in, out, h, query);
            } else if (path.startsWith("/stream")) {
                stream(method, h, out);
            } else {
                send(out, 200, "text/html; charset=utf-8", page);
            }
        } catch (Exception ignored) {
        } finally {
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    // ---------------------------------------------------------------- telefon tərəfi

    /** Telefon yeni video seçdi: yalnız ad və ölçü gəlir, heç nə saxlanmır. */
    private void open(OutputStream out, String query) throws IOException {
        long size = num(query, "size");
        if (size <= 0) { send(out, 400, "text/plain; charset=utf-8", "Fayl boşdur"); return; }
        String nm = param(query, "name");
        boolean oom = false;
        int g = 0;
        synchronized (LOCK) {
            if (ring == null) {
                try { ring = new byte[RING]; } catch (OutOfMemoryError e) { oom = true; }
            }
            if (!oom) {
                gen++;
                g = gen;
                sid++;
                winStart = 0; winEnd = 0;
                feedId++; feedOff = 0;
                name = nm; total = size; hasVideo = true;
                LOCK.notifyAll();
            }
        }
        if (oom) { send(out, 507, "text/plain; charset=utf-8", "TV-də RAM kifayət etmir"); return; }
        Listener ls = listener;
        if (ls != null) ls.onNewVideo();
        send(out, 200, "text/plain; charset=utf-8", String.valueOf(g));
    }

    /** Telefon burada gözləyir; player başqa yerdən oxumaq istəyəndə "S offset id" alır. */
    private void cmd(OutputStream out, String query) throws IOException {
        long g = num(query, "g"), f = num(query, "f");
        long until = System.currentTimeMillis() + 20000;
        String reply = "N";
        synchronized (LOCK) {
            while (true) {
                if (g != gen || !hasVideo) { reply = "X"; break; }
                if (feedId != f) { reply = "S " + feedOff + " " + feedId; break; }
                long left = until - System.currentTimeMillis();
                if (left <= 0) break;
                try { LOCK.wait(left); } catch (InterruptedException e) { break; }
            }
        }
        send(out, 200, "text/plain; charset=utf-8", reply);
    }

    /** Telefon faylın offset-dən sonuna qədər olan hissəsini göndərir; ring-ə yazılır. */
    private void feed(InputStream in, OutputStream out, Map<String, String> h, String query) throws IOException {
        long g = num(query, "g"), f = num(query, "f"), off = num(query, "off");
        long len;
        try { len = Long.parseLong(h.get("content-length")); }
        catch (Exception e) { send(out, 411, "text/plain; charset=utf-8", "Content-Length yoxdur"); return; }
        synchronized (LOCK) {
            if (g != gen || !hasVideo || f != feedId || off != feedOff || off != winEnd) {
                send(out, 409, "text/plain; charset=utf-8", "Köhnəlmiş sorğu");
                return;
            }
        }
        byte[] buf = new byte[65536];
        long rem = len;
        boolean stale = false;
        try {
            while (rem > 0) {
                int n = in.read(buf, 0, (int) Math.min(buf.length, rem));
                if (n < 0) break;
                synchronized (LOCK) {
                    while (true) {
                        if (g != gen || f != feedId) { stale = true; break; }
                        if (RING - (winEnd - winStart) >= n) break;
                        try { LOCK.wait(200); } catch (InterruptedException e) { stale = true; break; }
                    }
                    if (stale) break;
                    put(buf, n);
                    LOCK.notifyAll();
                }
                rem -= n;
            }
        } catch (IOException ignored) {
            // şəbəkə qırıldı: aşağıda davam etdirilir
        }
        if (stale) return;
        synchronized (LOCK) {
            if (g == gen && f == feedId && rem > 0) {
                // yarımçıq qaldı: telefondan qaldığımız yerdən davam etməsini istə
                feedId++;
                feedOff = winEnd;
                LOCK.notifyAll();
            }
        }
        try { send(out, 200, "text/plain; charset=utf-8", "OK"); } catch (Exception ignored) { }
    }

    // ---------------------------------------------------------------- player tərəfi

    private void stream(String method, Map<String, String> h, OutputStream out) throws IOException {
        final long g;
        final int mySid;
        final long tot;
        synchronized (LOCK) {
            if (!hasVideo || total <= 0) { send(out, 404, "text/plain; charset=utf-8", "Video yoxdur"); return; }
            g = gen;
            tot = total;
            if (!method.equals("HEAD")) sid++;   // ən yeni bağlantı qalib gəlir
            mySid = sid;
        }
        long start = 0, end = tot - 1;
        boolean partial = false;
        String r = h.get("range");
        if (r != null && r.startsWith("bytes=")) {
            try {
                String[] pr = r.substring(6).split(",")[0].trim().split("-", -1);
                if (pr[0].isEmpty()) start = Math.max(0, tot - Long.parseLong(pr[1]));
                else {
                    start = Long.parseLong(pr[0]);
                    if (pr.length > 1 && !pr[1].isEmpty()) end = Math.min(end, Long.parseLong(pr[1]));
                }
                partial = true;
            } catch (Exception ignored) { }
        }
        if (start >= tot || start > end) {
            out.write(("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */" + tot + "\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
            out.flush();
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(partial ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n");
        sb.append("Content-Type: application/octet-stream\r\nAccept-Ranges: bytes\r\n");
        sb.append("Content-Length: ").append(end - start + 1).append("\r\n");
        if (partial) sb.append("Content-Range: bytes ").append(start).append("-").append(end).append("/").append(tot).append("\r\n");
        sb.append("Connection: close\r\n\r\n");
        out.write(sb.toString().getBytes("UTF-8"));
        out.flush();
        if (method.equals("HEAD")) return;

        long pos = start;
        byte[] buf = new byte[65536];
        while (pos <= end) {
            int n;
            long deadline = System.currentTimeMillis() + STALL_MS;
            synchronized (LOCK) {
                while (true) {
                    if (g != gen || mySid != sid || !hasVideo) return;
                    if (pos >= winStart && pos < winEnd) break;
                    if (pos != winEnd) seekTo(pos);   // bufer xaricindədir: telefon buradan göndərsin
                    long left = deadline - System.currentTimeMillis();
                    if (left <= 0) return;
                    try { LOCK.wait(Math.min(left, 1000)); } catch (InterruptedException e) { return; }
                }
                n = take(pos, buf, (int) Math.min(buf.length, end - pos + 1));
                long keep = pos + n - BACK;
                if (keep > winStart) winStart = Math.min(keep, winEnd);
                LOCK.notifyAll();
            }
            out.write(buf, 0, n);
            pos += n;
        }
        out.flush();
    }

    /** Videonu bağlayır, buferi azad edir, telefonu dayandırır. */
    public static void discard() {
        synchronized (LOCK) {
            gen++;
            hasVideo = false;
            name = "";
            total = 0;
            ring = null;
            winStart = 0; winEnd = 0;
            feedId++;
            LOCK.notifyAll();
        }
    }

    // ---------------------------------------------------------------- ring bufer (LOCK altında çağırılır)

    private static void seekTo(long pos) {
        feedId++;
        feedOff = pos;
        winStart = pos;
        winEnd = pos;
        LOCK.notifyAll();
    }

    private static void put(byte[] b, int n) {
        int at = (int) (winEnd % RING);
        int first = Math.min(n, RING - at);
        System.arraycopy(b, 0, ring, at, first);
        if (first < n) System.arraycopy(b, first, ring, 0, n - first);
        winEnd += n;
    }

    private static int take(long pos, byte[] b, int max) {
        int n = (int) Math.min(max, winEnd - pos);
        int at = (int) (pos % RING);
        int first = Math.min(n, RING - at);
        System.arraycopy(ring, at, b, 0, first);
        if (first < n) System.arraycopy(ring, 0, b, first, n - first);
        return n;
    }

    // ---------------------------------------------------------------- köməkçilər

    private static String param(String query, String key) {
        for (String kv : query.split("&")) {
            if (kv.startsWith(key + "=")) {
                try { return URLDecoder.decode(kv.substring(key.length() + 1), "UTF-8"); }
                catch (Exception e) { return ""; }
            }
        }
        return "";
    }

    private static long num(String query, String key) {
        try { return Long.parseLong(param(query, key)); } catch (Exception e) { return -1; }
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
            if (b.size() > 16384) break;
        }
        if (c == -1 && b.size() == 0) return null;
        return b.toString("UTF-8");
    }

    private static void send(OutputStream out, int code, String type, String body) throws IOException {
        byte[] b = body.getBytes("UTF-8");
        String hd = "HTTP/1.1 " + code + (code == 200 ? " OK" : " Error") + "\r\nContent-Type: " + type
                + "\r\nContent-Length: " + b.length + "\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";
        out.write(hd.getBytes("UTF-8"));
        out.write(b);
        out.flush();
    }
}
