package az.mehdi.callrec

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Rec(val file: String, val number: String, val app: String,
               val incoming: Boolean, val time: Long, val dur: Long)

object Store {
    private fun f(c: Context) = File(c.filesDir, "recs.json")

    @Synchronized
    fun all(c: Context): List<Rec> = try {
        val a = JSONArray(f(c).readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Rec(o.getString("file"), o.getString("number"), o.getString("app"),
                o.getBoolean("in"), o.getLong("time"), o.getLong("dur"))
        }.sortedByDescending { it.time }
    } catch (e: Exception) { emptyList() }

    @Synchronized
    private fun save(c: Context, l: List<Rec>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("file", it.file).put("number", it.number).put("app", it.app)
                .put("in", it.incoming).put("time", it.time).put("dur", it.dur))
        }
        f(c).writeText(a.toString())
    }

    fun add(c: Context, r: Rec) = save(c, all(c) + r)
    fun remove(c: Context, file: String) = save(c, all(c).filter { it.file != file })
}
