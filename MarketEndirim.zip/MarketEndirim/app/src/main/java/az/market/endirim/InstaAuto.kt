package az.market.endirim

import android.view.View
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock

/**
 * Tətbiqə daxil olanda: bu gün hələ yenilənməyən marketlərin Instagram səhifələrini və son 15 postun
 * içini (video olmadan) gizli WebView-da offline arxivə yazır. Gündə 1 dəfə (təqvim günü) işləyir.
 * Giriş lazım olarsa dayanır; mini brauzerdə daxil olandan sonra növbəti girişdə davam edir.
 */
object InstaAuto {
    private var job: Job? = null

    fun start(act: AppCompatActivity) {
        if (job?.isActive == true) return
        val app = act.applicationContext
        val todo = InstaSaver.users().filter { !InstaSaver.doneToday(app, it.second) }
        if (todo.isEmpty() || !Store.online(app)) return
        if (InstaSaver.needLogin(app) && !InstaSaver.loggedIn()) return   // əvvəlcə brauzerdə daxil olunmalıdır
        job = act.lifecycleScope.launch {
            if (!InstaSaver.lock.tryLock()) return@launch
            val web = WebView(app)
            try {
                web.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    userAgentString = InstaSaver.UA
                    mediaPlaybackRequiresUserGesture = true
                }
                CookieManager.getInstance().setAcceptCookie(true)
                // ekransız WebView-un ölçüsü olmalıdır, yoxsa sürüşdürmə post yükləmir
                web.measure(View.MeasureSpec.makeMeasureSpec(1080, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(1920, View.MeasureSpec.EXACTLY))
                web.layout(0, 0, 1080, 1920)
                val saver = InstaSaver(app, web)
                web.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        saver.pageDone?.complete(Unit)
                    }

                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                        InstaSaver.blockVideo(request) ?: super.shouldInterceptRequest(view, request)
                }
                for ((_, user) in todo) {
                    if (saver.saveUser(user) { } == InstaSaver.Res.LOGIN) break
                }
                CookieManager.getInstance().flush()
            } finally {
                InstaSaver.lock.unlock()
                (web.parent as? android.view.ViewGroup)?.removeView(web)
                web.destroy()
            }
        }
    }
}
