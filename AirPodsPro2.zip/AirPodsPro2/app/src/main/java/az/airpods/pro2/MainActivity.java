package az.airpods.pro2;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private TextView title, status, overlayHint, tip;
    private AirPodsView pods;
    private Button btn;
    private Switch swPopup, swBoot;

    private final PodsStore.Listener lis = new PodsStore.Listener() {
        @Override public void onChange() { refresh(); }
    };

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(20), dp(16), dp(20), dp(24));
        root.setBackgroundColor(Color.BLACK);

        title = new TextView(this);
        title.setText("AirPods Pro 2");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-2, dp(0), 0));

        status = new TextView(this);
        status.setTextColor(0xFF8E8E93);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        root.addView(status, lp(-2, dp(6), 0));

        pods = new AirPodsView(this);
        root.addView(pods, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(400)));

        btn = new Button(this);
        btn.setAllCaps(false);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(16);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggle(); }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        bp.topMargin = dp(8);
        root.addView(btn, bp);

        swPopup = sw("Qabı açanda pop-up kart göstər", Prefs.popup(this));
        swPopup.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) {
                Prefs.set(MainActivity.this, "popup", on);
                if (on && !Settings.canDrawOverlays(MainActivity.this)) askOverlay();
                refresh();
            }
        });
        root.addView(swPopup, lp(-1, dp(14), 0));

        swBoot = sw("Telefon açılanda avtomatik başlat", Prefs.boot(this));
        swBoot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) {
                Prefs.set(MainActivity.this, "boot", on);
            }
        });
        root.addView(swBoot, lp(-1, dp(6), 0));

        overlayHint = new TextView(this);
        overlayHint.setText("Pop-up üçün \"Digər tətbiqlərin üzərində göstər\" icazəsi lazımdır — toxunun.");
        overlayHint.setTextColor(0xFF0A84FF);
        overlayHint.setTextSize(13);
        overlayHint.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { askOverlay(); }
        });
        root.addView(overlayHint, lp(-1, dp(8), 0));

        tip = new TextView(this);
        tip.setText("Qeyd: AirPods yalnız qapaq açıq olanda və ya qulaqlıq qabdan çıxarılanda batareya məlumatı yayır. "
                + "Məlumat gəlmirsə Bluetooth açıq olmalıdır (Android 11 və aşağıda Məkan da).");
        tip.setTextColor(0xFF636366);
        tip.setTextSize(12);
        root.addView(tip, lp(-1, dp(14), 0));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(Color.BLACK);
        sv.addView(root);
        setContentView(sv);
    }

    private Switch sw(String text, boolean on) {
        Switch s = new Switch(this);
        s.setText(text);
        s.setTextColor(Color.WHITE);
        s.setTextSize(15);
        s.setChecked(on);
        return s;
    }

    private LinearLayout.LayoutParams lp(int w, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                w == -2 ? ViewGroup.LayoutParams.WRAP_CONTENT : ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = top;
        p.bottomMargin = bottom;
        return p;
    }

    @Override protected void onStart() {
        super.onStart();
        PodsStore.add(lis);
        if (hasPerm() && !PodsStore.running && Prefs.wantRun(this)) startPods();
        refresh();
    }

    @Override protected void onStop() {
        PodsStore.remove(lis);
        super.onStop();
    }

    private void toggle() {
        if (PodsStore.running) {
            Prefs.set(this, "run", false);
            stopService(new Intent(this, PodsService.class));
            PodsStore.running = false;
            PodsStore.active = false;
            refresh();
        } else if (hasPerm()) {
            startPods();
        } else {
            askPerm();
        }
    }

    private void startPods() {
        Prefs.set(this, "run", true);
        try {
            startForegroundService(new Intent(this, PodsService.class));
        } catch (Exception e) {
            Toast.makeText(this, "Xidmət başladıla bilmədi", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean hasPerm() {
        String p = Build.VERSION.SDK_INT >= 31
                ? Manifest.permission.BLUETOOTH_SCAN : Manifest.permission.ACCESS_FINE_LOCATION;
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void askPerm() {
        List<String> l = new ArrayList<>();
        l.add(Build.VERSION.SDK_INT >= 31 ? Manifest.permission.BLUETOOTH_SCAN : Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(l.toArray(new String[0]), 7);
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (hasPerm()) startPods();
        else Toast.makeText(this, "Axtarış üçün icazə lazımdır", Toast.LENGTH_LONG).show();
    }

    private void askOverlay() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) { }
    }

    private void refresh() {
        PodsState s = PodsStore.state;
        boolean run = PodsStore.running;
        pods.setData(s, run && PodsStore.active);
        title.setText(s != null ? s.name : "AirPods Pro 2");

        String st;
        if (!run) st = "Axtarış dayandırılıb";
        else if (PodsStore.btOff) st = "Bluetooth söndürülüb";
        else if (PodsStore.active && s != null) st = (s.inL || s.inR) ? "Yaxındadır · qulaqdadır" : "Yaxındadır";
        else if (s != null) st = "Qab bağlıdır · son məlumat";
        else st = "AirPods axtarılır… Qabı yaxınlaşdırıb qapağı açın";
        status.setText(st);

        btn.setText(run ? "Dayandır" : "Başlat");
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(26));
        g.setColor(run ? 0xFF3A3A3C : 0xFF0A84FF);
        btn.setBackground(g);

        overlayHint.setVisibility(Prefs.popup(this) && !Settings.canDrawOverlays(this) ? View.VISIBLE : View.GONE);
    }
}
