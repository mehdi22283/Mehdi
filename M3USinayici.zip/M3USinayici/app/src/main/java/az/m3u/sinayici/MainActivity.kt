package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import org.json.JSONArray
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var prevLogin = ""
    private val pool = Executors.newFixedThreadPool(24)
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingName = ""
    private var pendingText = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("m3u", MODE_PRIVATE)
        prevLogin = sp.getString("lastLogin", "") ?: ""
        sp.edit().putString("lastLogin", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())).apply()
        web = WebView(this); setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = true
            allowFileAccessFromFileURLs = true; allowUniversalAccessFromFileURLs = true
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 2)
                return true
            }
            override fun onJsAlert(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r?.confirm() }
                    .setOnCancelListener { r?.cancel() }.show(); return true
            }
            override fun onJsConfirm(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r?.confirm() }
                    .setNegativeButton("Ləğv et") { _, _ -> r?.cancel() }.setOnCancelListener { r?.cancel() }.show(); return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("if(window.syncLast)syncLast()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq == 2) {
            val u = d?.data
            fileCb?.onReceiveValue(if (rs == RESULT_OK && u != null) arrayOf(u) else null); fileCb = null
        } else if (rq == 1 && rs == RESULT_OK) web.evaluateJavascript("ottImportFromNative()", null)
    }

    /** Playlisti Downloads qovluğuna yazır (Android 10+: MediaStore, əvvəlki: birbaşa fayl). */
    private fun writeToDownloads(name: String, text: String) {
        try {
            val bytes = text.toByteArray(Charsets.UTF_8)
            val shown: String
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "audio/x-mpegurl")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: throw java.io.IOException("Fayl yaradıla bilmədi")
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                shown = name
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                var f = File(dir, name); var i = 1
                while (f.exists()) { f = File(dir, name.substringBeforeLast('.') + " ($i)." + name.substringAfterLast('.')); i++ }
                f.writeBytes(bytes)
                shown = f.name
            }
            Toast.makeText(this, "Downloads qovluğuna yazıldı: $shown", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "İxrac xətası: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportPlaylist(name: String, text: String) {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingName = name; pendingText = text
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 3)
        } else writeToDownloads(name, text)
    }

    override fun onRequestPermissionsResult(rq: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(rq, p, g)
        if (rq == 3) {
            if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) writeToDownloads(pendingName, pendingText)
            else Toast.makeText(this, "İcazə verilmədi", Toast.LENGTH_LONG).show()
            pendingText = ""
        }
    }

    inner class Bridge {
        @JavascriptInterface fun openOtt() = runOnUiThread { startActivityForResult(Intent(this@MainActivity, BrowserActivity::class.java), 1) }
        @JavascriptInterface fun playQueue(json: String, index: Int) {
            val arr = JSONArray(json)
            val list = ArrayList<QItem>(arr.length())
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                list.add(QItem(a.getString(0), a.getString(1), a.optJSONObject(2)?.toString() ?: "{}"))
            }
            PlayQueue.items = list; PlayQueue.index = index
            runOnUiThread { startActivity(Intent(this@MainActivity, PlayerActivity::class.java)) }
        }
        @JavascriptInterface fun probe(url: String, hdr: String, id: Int) {
            pool.execute {
                val r = Net.probe(url, hdr)
                runOnUiThread { web.evaluateJavascript("__probeDone($id,'$r')", null) }
            }
        }
        @JavascriptInterface fun getSavedPlaylist(): String {
            val f = File(filesDir, "playlist1.m3u"); return if (f.exists()) f.readText() else ""
        }
        @JavascriptInterface fun getLastLogin(): String = prevLogin
        @JavascriptInterface fun getLastUrl(): String = getSharedPreferences("m3u", MODE_PRIVATE).getString("lastUrl", "") ?: ""
        @JavascriptInterface fun saveToDownloads(name: String, text: String) = runOnUiThread { exportPlaylist(name, text) }
    }
}
