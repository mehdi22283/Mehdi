package az.yvok.app;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/**
 * Google Cloud Vision (DOCUMENT_TEXT_DETECTION) ilə onlayn OCR (tətbiqdə yeganə OCR mühərriki).
 */
final class CloudVision {
    // Açar index.html-də "Toplu yoxlama" yanındakı xanadan daxil edilir, SharedPreferences-də saxlanır.
    static volatile String apiKey = "";

    // Google sorğu həddi ~10 MB JSON-dur; base64 4/3 dəfə böyütdüyü üçün bu rəqəm təhlükəsiz yuxarı sərhəddir
    private static final int MAX_B64 = 9_000_000;
    private static final int MAX_READ = 40_000_000;   // bundan böyük fayl yaddaşa oxunmur, yenidən kodlanır


    private CloudVision() { }

    static volatile String lastError = null;

    static final int FREE_LIMIT = 33;   // sayğacın aylıq limiti (istifadəçi tələbi ilə 33)

    // Google hesablaşma ayı Pacific vaxtı ilə sıfırlanır; sayğac telefonda saxlanılır (təxmini)
    private static String monthKey() {
        java.util.Calendar cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Los_Angeles"));
        return cal.get(java.util.Calendar.YEAR) + "-" + (cal.get(java.util.Calendar.MONTH) + 1);
    }

    static synchronized int left(Context c) {
        android.content.SharedPreferences sp = c.getSharedPreferences("yvok", Context.MODE_PRIVATE);
        int used = monthKey().equals(sp.getString("vision_month", "")) ? sp.getInt("vision_used", 0) : 0;
        return Math.max(0, FREE_LIMIT - used);
    }

    private static synchronized void bump(Context c) {
        android.content.SharedPreferences sp = c.getSharedPreferences("yvok", Context.MODE_PRIVATE);
        String mk = monthKey();
        int used = mk.equals(sp.getString("vision_month", "")) ? sp.getInt("vision_used", 0) : 0;
        sp.edit().putString("vision_month", mk).putInt("vision_used", used + 1).apply();
    }

    static boolean enabled() { return !apiKey.isEmpty(); }

    /** Şəkildəki bütün mətni qaytarır; xəta və ya internet yoxdursa null. Yalnız arxa thread-də çağırılır. */
    static String detect(Context c, Uri uri) {
        lastError = null;
        if (!enabled()) { lastError = "Vision API açarı yoxdur"; return null; }
        try {
            String img64 = prepare(c, uri);

            JSONObject req = new JSONObject()
                    .put("image", new JSONObject().put("content", img64))
                    .put("features", new JSONArray().put(new JSONObject().put("type", "DOCUMENT_TEXT_DETECTION")))
                    .put("imageContext", new JSONObject().put("languageHints", new JSONArray().put("en").put("az")));
            byte[] body = new JSONObject().put("requests", new JSONArray().put(req)).toString().getBytes("UTF-8");

            HttpURLConnection h = (HttpURLConnection) new URL("https://vision.googleapis.com/v1/images:annotate?key=" + apiKey).openConnection();
            h.setRequestMethod("POST");
            h.setConnectTimeout(8000);
            h.setReadTimeout(45000);
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            h.setRequestProperty("X-Android-Package", c.getPackageName());
            String sha = certSha1(c);
            if (sha != null) h.setRequestProperty("X-Android-Cert", sha);
            try (OutputStream os = h.getOutputStream()) { os.write(body); }
            int code = h.getResponseCode();
            if (code != 200) {
                lastError = (code == 400 || code == 403) ? "Vision açarı qəbul olunmadı (" + code + "): açarı və API-nin aktiv olduğunu yoxlayın"
                        : "Vision xətası (" + code + ")";
                return null;
            }
            bump(c);   // uğurlu sorğu = 1 vahid
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = h.getInputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            JSONObject r = new JSONObject(out.toString("UTF-8")).getJSONArray("responses").getJSONObject(0);
            JSONObject full = r.optJSONObject("fullTextAnnotation");
            return full == null ? null : full.optString("text", null);
        } catch (java.io.IOException t) {
            lastError = "İnternet yoxdur və ya Google-a qoşulmaq olmadı";
            return null;
        } catch (Throwable t) {
            lastError = "Vision cavabı oxunmadı";
            return null;
        }
    }

    /**
     * Maksimum keyfiyyət: şəkil limitə sığırsa ORİJİNAL fayl baytları olduğu kimi göndərilir (heç bir kiçiltmə
     * və ya təkrar sıxma yoxdur). Çox böyükdürsə, tam ölçüdə JPEG 100-dən başlayaraq yalnız lazım qədər azaldılır.
     */
    private static String prepare(Context c, Uri uri) throws IOException {
        byte[] raw = readCapped(c, uri);
        if (raw != null && (long) raw.length * 4 / 3 + 1000 <= MAX_B64) {
            return Base64.encodeToString(raw, Base64.NO_WRAP);
        }
        raw = null;
        Bitmap bmp = OcrImage.load(c, uri);
        int q = 100;
        try {
            while (true) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, q, bos);
                if ((long) bos.size() * 4 / 3 + 1000 <= MAX_B64 || Math.max(bmp.getWidth(), bmp.getHeight()) < 800) {
                    return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
                }
                if (q > 85) {
                    q -= 5;
                } else {
                    Bitmap t = Bitmap.createScaledBitmap(bmp, Math.round(bmp.getWidth() * 0.85f), Math.round(bmp.getHeight() * 0.85f), true);
                    if (t != bmp) bmp.recycle();
                    bmp = t;
                    q = 95;
                }
            }
        } finally {
            bmp.recycle();
        }
    }

    private static byte[] readCapped(Context c, Uri uri) {
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) return null;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > MAX_READ) return null;
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }

    @SuppressWarnings("deprecation")
    private static String certSha1(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNATURES);
            byte[] d = MessageDigest.getInstance("SHA-1").digest(pi.signatures[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02X", x));
            return sb.toString();
        } catch (Throwable t) {
            return null;
        }
    }
}
