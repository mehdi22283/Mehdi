package az.market.endirim

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Məhsul adının səhifədəki qutusu. */
data class NameBox(val name: String, val l: Int, val t: Int, val r: Int, val b: Int) {
    val w get() = r - l
    val h get() = b - t
}

/** Ad + tapılmış qiymət. price = endirimli (ən böyük şriftli) qiymət, old = köhnə qiymət. */
data class Priced(val name: String, val price: String?, val old: String?)

/**
 * Səhifədəki qiymətləri tapıb məhsul adları ilə uyğunlaşdırır.
 *
 * Qiymət = yanında ₼ işarəsi olan tək rəqəm (5 ₼) və ya XX.XX / X.XX (2.49 ₼). Hər qiymət qutusunun ətrafındakı fon rəngi də
 * ölçülür (qırmızı / sarı / yaşıl / narıncı): Bravo-da qırmızı kvadratda ağ qiymət, Rahat-da sarı fonda qiymət ₼ olmasa da qəbul edilir.
 * Bir məhsulun yanında 2 qiymət varsa: ən böyük şriftli = endirimli, kiçik və daha bahalı olan = köhnə.
 *
 * Qiymət məhsula bağlananda çərçivələr nəzərə alınır: ad ilə qiymət arasında nazik sərhəd xətti və ya fon rənginin
 * kəskin dəyişməsi (başqa çərçivə / başqa xana) varsa, həmin qiymət o məhsula YAZILMIR.
 */
object PriceFinder {

    /** true: başqa xanadakı qiymət heç vaxt bağlanmır. false: yalnız böyük cərimə alır (yanlış kəsmə çox olsa bunu sına). */
    private const val STRICT_SEPARATION = true

    private enum class Bg { RED, YELLOW, GREEN, ORANGE, OTHER }

    private class PBox(
        val value: String, val l: Int, val t: Int, val r: Int, val b: Int,
        val cur: Boolean
    ) {
        var bg: Bg = Bg.OTHER
        val h get() = b - t
        val num get() = value.toDoubleOrNull() ?: 0.0
        val cx get() = (l + r) / 2
        val cy get() = (t + b) / 2
    }

    private class Group(val now: PBox, val old: PBox?) {
        val l = min(now.l, old?.l ?: now.l)
        val t = min(now.t, old?.t ?: now.t)
        val r = max(now.r, old?.r ?: now.r)
        val b = max(now.b, old?.b ?: now.b)
    }

    // 5 | 5₼ | 2.49 | 2,49 ₼ | 12.90 AZN | 249 (böyük 2 + kiçik 49 yuxarıda)
    private val NUM = Regex("""^(\d{1,4})(?:\s?[.,·]\s?(\d{1,2}))?\s?(₼|azn|man|м|m|a)?\.?$""", RegexOption.IGNORE_CASE)
    private val CUR_ONLY = Regex("""^(₼|azn|man|м|m|a)\.?$""", RegexOption.IGNORE_CASE)
    private val DEC_ONLY = Regex("""^\d{1,2}$""")

    // ----------------------------------------------------------------------------------------------------------------
    fun attach(bmp: Bitmap, lines: List<OLine>, names: List<NameBox>): List<Priced> {
        if (names.isEmpty()) return emptyList()
        val boxes = try { priceBoxes(bmp, lines) } catch (e: Exception) { emptyList() }
        if (boxes.isEmpty()) return names.map { Priced(it.name, null, null) }
        val groups = groupPrices(boxes)
        val assigned = try { assign(bmp, names, groups) } catch (e: Exception) { emptyMap() }
        return names.mapIndexed { i, n ->
            val g = assigned[i]
            if (g == null) Priced(n.name, null, null) else Priced(n.name, g.now.value, g.old?.value)
        }
    }

    // ---------------- 1) Qiymət qutularını tap ----------------
    private fun norm(s: String) = s.replace('\n', ' ').trim()

    private fun priceBoxes(bmp: Bitmap, lines: List<OLine>): List<PBox> {
        val curLines = lines.filter { CUR_ONLY.matches(norm(it.text)) }
        val used = BooleanArray(lines.size)
        val out = ArrayList<PBox>()
        for (i in lines.indices) {
            if (used[i]) continue
            val ln = lines[i]
            if (ln.h < 8 || ln.h > 0.12f * bmp.height) continue
            val m = NUM.matchEntire(norm(ln.text)) ?: continue
            var ip = m.groupValues[1]
            var dp = m.groupValues[2]
            val curIn = m.groupValues[3].isNotEmpty()
            var l = ln.l; var t = ln.t; var r = ln.r; var b = ln.b

            if (dp.isEmpty()) {
                // "249" — böyük 2 + kiçik 49 ola bilər; yazının eni/hündürlüyü ilə ayırd edilir (eyni ölçülü rəqəm ≈ 0.55·h en tutur)
                val wDigits = ln.w - (if (curIn) 0.7f * ln.h else 0f)
                val ratio = wDigits / ln.h.toFloat()
                if (ip.length == 3 && ratio < 1.4f) { dp = ip.substring(1); ip = ip.substring(0, 1) }
                else if (ip.length == 4 && ratio < 1.9f) { dp = ip.substring(2); ip = ip.substring(0, 2) }
                else if (ip.length == 4) continue
            }
            if (dp.isEmpty() && ip.length <= 3) {
                // kiçik rəqəmlər ayrı sətir kimi oxunubsa (sağda, yuxarı hissədə) birləşdirilir
                for (j in lines.indices) {
                    if (j == i || used[j]) continue
                    val d = lines[j]
                    if (!DEC_ONLY.matches(norm(d.text))) continue
                    if (d.h > 0.8f * ln.h || d.h < 0.25f * ln.h) continue
                    if (d.l < ln.r - 0.25f * ln.w || d.l > ln.r + 1.5f * ln.h) continue
                    val dc = (d.t + d.b) / 2f
                    if (dc < ln.t - 0.2f * ln.h || dc > ln.t + 0.65f * ln.h) continue
                    dp = norm(d.text); used[j] = true
                    r = max(r, d.r); t = min(t, d.t)
                    break
                }
            }
            val value = buildValue(ip, dp) ?: continue
            val box = PBox(value, l, t, r, b, curIn || curNear(l, t, r, b, curLines))
            box.bg = ringBg(bmp, l, t, r, b)
            if (box.cur || box.bg != Bg.OTHER) { out.add(box); used[i] = true }
        }
        return out
    }

    private fun buildValue(ip: String, dp: String): String? {
        val i = ip.trimStart('0').ifEmpty { "0" }
        if (i.length > 3) return null
        val v = if (dp.isEmpty()) i else i + "." + (if (dp.length == 1) dp + "0" else dp)
        val d = v.toDoubleOrNull() ?: return null
        return if (d <= 0.0 || d >= 1000.0) null else v
    }

    /** ₼ işarəsi qiymətin sağında, sağ-yuxarıda və ya altında dayanırsa. */
    private fun curNear(l: Int, t: Int, r: Int, b: Int, cur: List<OLine>): Boolean {
        val h = (b - t).coerceAtLeast(1)
        for (c in cur) {
            val cy = (c.t + c.b) / 2
            val right = c.l >= r - 0.3f * h && c.l <= r + 1.6f * h && cy >= t - 0.3f * h && cy <= b + 0.6f * h
            val below = c.t >= b - 0.3f * h && c.t <= b + 1.0f * h && (c.l + c.r) / 2 in l..(r + (0.5f * h).toInt())
            if (right || below) return true
        }
        return false
    }

    // ---------------- 2) Fon rəngi ----------------
    private fun classify(c: Int): Bg {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        val h = hsv[0]; val s = hsv[1]; val v = hsv[2]
        if (v < 0.35f || s < 0.45f) return Bg.OTHER
        return when {
            h < 14f || h > 340f -> Bg.RED
            h < 38f -> Bg.ORANGE
            h in 38f..68f -> Bg.YELLOW
            h in 85f..160f -> Bg.GREEN
            else -> Bg.OTHER
        }
    }

    private fun px(bmp: Bitmap, x: Int, y: Int): Int =
        bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1))

    /** Qiymət yazısının ətrafındakı halqadan fon rəngi: nöqtələrin əksəriyyəti qırmızı/sarı/yaşıl/narıncıdırsa — rəngli çərçivə. */
    private fun ringBg(bmp: Bitmap, l: Int, t: Int, r: Int, b: Int): Bg {
        val pad = max(3, ((b - t) * 0.25f).toInt())
        val x0 = l - pad; val x1 = r + pad; val y0 = t - pad; val y1 = b + pad
        val votes = IntArray(Bg.values().size)
        var total = 0
        fun vote(x: Int, y: Int) {
            if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) return
            votes[classify(px(bmp, x, y)).ordinal]++; total++
        }
        val n = 10
        for (k in 0..n) {
            val x = x0 + (x1 - x0) * k / n
            val y = y0 + (y1 - y0) * k / n
            vote(x, y0); vote(x, y1); vote(x0, y); vote(x1, y)
        }
        if (total == 0) return Bg.OTHER
        var best = Bg.OTHER; var bestV = 0
        for (bg in Bg.values()) if (bg != Bg.OTHER && votes[bg.ordinal] > bestV) { best = bg; bestV = votes[bg.ordinal] }
        return if (bestV * 100 >= total * 45) best else Bg.OTHER
    }

    // ---------------- 3) Endirimli / köhnə qiymət ----------------
    private fun groupPrices(boxes: List<PBox>): List<Group> {
        // ən böyük şrift = endirimli qiymət (bərabərlikdə rəngli fon üstün)
        val sorted = boxes.sortedWith(compareByDescending<PBox> { it.h + if (it.bg != Bg.OTHER) 3 else 0 })
        val taken = BooleanArray(sorted.size)
        val out = ArrayList<Group>()
        for (i in sorted.indices) {
            if (taken[i]) continue
            taken[i] = true
            val now = sorted[i]
            var old: PBox? = null
            var bestD = Int.MAX_VALUE
            for (j in i + 1 until sorted.size) {
                if (taken[j]) continue
                val o = sorted[j]
                if (o.h > 0.9f * now.h) continue                   // köhnə qiymət daha kiçik şriftlə yazılır
                if (o.num <= now.num || o.num > now.num * 6) continue
                val dx = abs(o.cx - now.cx); val dy = abs(o.cy - now.cy)
                if (dx > 4.5f * now.h + now.h * 2 || dy > 3.5f * now.h) continue
                val d = dx + dy
                if (d < bestD) { bestD = d; old = o }
            }
            if (old != null) taken[sorted.indexOf(old)] = true
            out.add(Group(now, old))
        }
        return out
    }

    // ---------------- 4) Ad ↔ qiymət ----------------
    private fun gap(a0: Int, a1: Int, b0: Int, b1: Int) = max(0, max(a0, b0) - min(a1, b1))

    private fun assign(bmp: Bitmap, names: List<NameBox>, groups: List<Group>): Map<Int, Group> {
        val maxDy = 0.16f * bmp.height
        val maxDx = 0.35f * bmp.width
        class Cand(val n: Int, val g: Int, val cost: Float)
        val pairs = ArrayList<Cand>()
        for ((ni, n) in names.withIndex()) {
            for ((gi, g) in groups.withIndex()) {
                val dy = gap(n.t, n.b, g.t, g.b).toFloat()
                val dx = gap(n.l, n.r, g.l, g.r).toFloat()
                if (dy > maxDy || dx > maxDx) continue
                val above = g.b <= n.t + 0.3f * n.h
                var cost = dy * (if (above) 1.4f else 1.0f) + dx * 1.6f + abs((n.l + n.r) / 2 - (g.l + g.r) / 2) * 0.25f
                if (separated(bmp, n, g)) {
                    if (STRICT_SEPARATION) continue
                    cost += 0.25f * bmp.height
                }
                pairs.add(Cand(ni, gi, cost))
            }
        }
        pairs.sortBy { it.cost }
        val nameDone = BooleanArray(names.size)
        val groupDone = BooleanArray(groups.size)
        val out = HashMap<Int, Group>()
        for (p in pairs) {
            if (nameDone[p.n] || groupDone[p.g]) continue
            nameDone[p.n] = true; groupDone[p.g] = true
            out[p.n] = groups[p.g]
        }
        return out
    }

    // ---------------- 5) Çərçivə / sərhəd yoxlaması ----------------
    private fun dist(a: Int, b: Int): Int =
        max(abs(Color.red(a) - Color.red(b)), max(abs(Color.green(a) - Color.green(b)), abs(Color.blue(a) - Color.blue(b))))

    private class Win(val mean: Int, val dev: Int)

    private fun win(s: IntArray, from: Int, to: Int): Win {
        var rs = 0; var gs = 0; var bs = 0
        var rMin = 255; var rMax = 0; var gMin = 255; var gMax = 0; var bMin = 255; var bMax = 0
        val n = to - from + 1
        for (k in from..to) {
            val c = s[k]
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            rs += r; gs += g; bs += b
            if (r < rMin) rMin = r; if (r > rMax) rMax = r
            if (g < gMin) gMin = g; if (g > gMax) gMax = g
            if (b < bMin) bMin = b; if (b > bMax) bMax = b
        }
        return Win(Color.rgb(rs / n, gs / n, bs / n), max(rMax - rMin, max(gMax - gMin, bMax - bMin)))
    }

    /**
     * Ad və qiymət arasında başqa çərçivə / xana var?
     * Ad qutusundan qiymətə düz xətt çəkilir (başlanğıc və son hissə — adın və qiymətin öz çərçivəsi — atılır), xətt boyu piksellər oxunur:
     *  (a) hər iki tərəfi bərabər rəngli sahə olan kəskin fon dəyişməsi (məs. çəhrayı xana → ağ xana);
     *  (b) iki bərabər rəngli sahə arasında nazik tünd/rəngli xətt (sərhəd).
     * Şəkil (fotoşəkil) üzərindən keçən hissələr bərabər rəngli olmadığı üçün nəticəyə təsir etmir.
     */
    private fun separated(bmp: Bitmap, n: NameBox, g: Group): Boolean {
        // adın qutusunda qiymətin mərkəzinə ən yaxın nöqtə
        val gx = (g.l + g.r) / 2; val gy = (g.t + g.b) / 2
        val ax = gx.coerceIn(n.l, n.r); val ay = gy.coerceIn(n.t, n.b)
        val bx = ax.coerceIn(g.l, g.r); val by = ay.coerceIn(g.t, g.b)
        val dx = (bx - ax).toFloat(); val dy = (by - ay).toFloat()
        val len = kotlin.math.sqrt(dx * dx + dy * dy)
        val h = max(n.h, g.now.h).coerceAtLeast(10)
        if (len < 2.5f * h) return false                 // praktiki olaraq bitişikdir
        val trim = max(0.2f * len, 1.0f * h)
        if (len - 2 * trim < 24f) return false
        val step = 2f
        val cnt = ((len - 2 * trim) / step).toInt()
        if (cnt < 14) return false
        val s = IntArray(cnt) { k ->
            val tt = (trim + k * step) / len
            px(bmp, (ax + dx * tt).toInt(), (ay + dy * tt).toInt())
        }
        val ownBg = g.now.bg
        for (k in 6 until cnt - 6) {
            // (a) kəskin fon dəyişməsi
            val w1 = win(s, k - 5, k - 1)
            val w2 = win(s, k, k + 4)
            if (w1.dev <= 24 && w2.dev <= 24 && dist(w1.mean, w2.mean) >= 80) {
                // qiymətin öz rəngli çərçivəsinə girmək xana dəyişməsi sayılmır
                val ownFrame = ownBg != Bg.OTHER && (classify(w1.mean) == ownBg || classify(w2.mean) == ownBg)
                if (!ownFrame) return true
            }
            // (b) nazik sərhəd xətti (2–10 px)
            for (m in 1..5) {
                if (k + m + 4 >= cnt) break
                val before = win(s, k - 5, k - 2)
                val line = win(s, k - 1, k + m - 2)
                val after = win(s, k + m + 1, k + m + 4)
                if (before.dev <= 24 && after.dev <= 24 && line.dev <= 40 &&
                    dist(before.mean, after.mean) <= 45 && dist(line.mean, before.mean) >= 90
                ) {
                    val ownFrame = ownBg != Bg.OTHER && classify(line.mean) == ownBg
                    if (!ownFrame) return true
                }
            }
        }
        return false
    }
}
