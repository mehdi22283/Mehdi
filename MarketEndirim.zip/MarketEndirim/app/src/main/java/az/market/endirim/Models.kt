package az.market.endirim

import java.io.Serializable

enum class Kind { PDF, IMAGES, WEB }

/** urls: PDF -> [pdf url], IMAGES -> şəkil linkləri, WEB -> [səhifə linki] */
data class Catalog(
    val market: String,
    val title: String,
    val date: String?,
    val kind: Kind,
    val urls: List<String>,
    val note: String? = null
) : Serializable

data class MarketResult(val market: String, val catalogs: List<Catalog>, val error: String?)

/** OCR ilə tapılmış məhsul adı (market, jurnal və səhifə ilə). */
data class Product(
    val name: String,
    val market: String,
    val catalogUrl: String,
    val page: Int,
    val cat: String,
    /** Endirimli qiymət (ən böyük şriftlə yazılan): "5", "2.49", "12.90" — tapılmayıbsa null. */
    val price: String? = null,
    /** Köhnə (endirimsiz) qiymət — tapılmayıbsa null. */
    val old: String? = null
) {
    val display: String = Categorizer.pretty(name)
    /** Axtarış açarı: kiçik hərf, ə→e, ı→i, ş→s ... (əvvəlcədən hesablanır ki, axtarış sürətli olsun). */
    val key: String = Categorizer.norm(name)
    /** Siyahıda əlifba sırası üçün açar. */
    val sortKey: String = display.lowercase(AzText.AZ)
}

data class Row(
    val type: Int,
    val market: String,
    val title: String,
    val date: String?,
    val sub: String?,
    val catalog: Catalog?,
    val catalogs: List<Catalog> = emptyList(),
    val selected: Set<String> = emptySet(),
    val tick: Int = 0,
    val product: Product? = null,
    val count: Int = 0,
    val open: Boolean = false
) {
    companion object {
        const val HEADER = 0
        const val ITEM = 1
        const val VIEWER = 2
        const val STRIP = 3
        const val PCAT = 4        // kateqoriya başlığı (title + count)
        const val HINT = 5
        const val TITLE = 6
        const val PMARKET = 7     // kateqoriya daxilində market nişanı (title = market, count = məhsul sayı)
        const val PROD = 8        // bir məhsul sətri
        const val PMORE = 9       // "Hamısını göstər" / "Daha az göstər" (title = kateqoriya, open = açıqdır)
    }
}

/** Qiymətin ekranda yazılışı: 2.49 ₼ */
fun priceText(v: String?): String = if (v.isNullOrEmpty()) "" else "$v ₼"
