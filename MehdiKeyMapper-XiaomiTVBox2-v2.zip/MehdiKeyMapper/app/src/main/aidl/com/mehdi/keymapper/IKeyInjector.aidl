package com.mehdi.keymapper;

import android.view.KeyEvent;

interface IKeyInjector {
    boolean ping();
    boolean inject(in KeyEvent event);
    String exec(String command);
    void destroyService();
}
