package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.*
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.File
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Daxili qaranlıq brauzer (Ottplayer və GitHub axtarışı üçün).
 * - Endirilən M3U fayl filesDir/playlist<N>.m3u kimi saxlanılır (Ottplayer: 1, GitHub: 2).
 * - Media linkinə (m3u8, ts, mp4 …) toxunduqda və ya linkə uzun basdıqda link tətbiqin playerində açılır.
 */
class BrowserActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private lateinit var swipe: SwipeRefreshLayout
    @Volatile private var pageAtTop = true
    private val OTT_HOME = "https://ottplayer.tv/playlist/original"
    private var copyBar: LinearLayout? = null
    private val hideCopyBar = Runnable { copyBar?.let { root.removeView(it) }; copyBar = null }
    private var listNo = 1
    private var ghToken = ""
    private val pool = Executors.newFixedThreadPool(12)
    private var touchX = 0f
    private var touchY = 0f
    /** "Yeni səhifədə aç" ilə açılmış fayl səhifəsi: linkə toxun → player, basıb saxla → kopyala. */
    private var fileMode = false
    /** Mini brauzer: yuxarıda ünvan qutusu olan sərbəst brauzer; açıqkən tətbiqdən çıxılsa fon xidməti işləyir. */
    private var mini = false
    private var fileCb: android.webkit.ValueCallback<Array<Uri>>? = null
    private var customView: android.view.View? = null
    private var customCb: android.webkit.WebChromeClient.CustomViewCallback? = null
    private var urlBox: android.widget.EditText? = null
    private fun inFilePage() = fileMode && (web.url ?: "").contains("/blob/")

    private val mediaExt = setOf("m3u8", "m3u", "ts", "mp4", "mkv", "mpd", "flv", "avi", "mov", "webm",
        "mp3", "aac", "m4a", "m4v", "3gp", "mpg", "mpeg")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        listNo = intent.getIntExtra("list", 1)
        ghToken = intent.getStringExtra("token") ?: ""
        fileMode = intent.getBooleanExtra("file", false)
        mini = intent.getBooleanExtra("mini", false)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        root = FrameLayout(this)
        swipe = SwipeRefreshLayout(this)
        swipe.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        swipe.setProgressBackgroundColorSchemeColor(Color.parseColor("#161B22"))
        swipe.setColorSchemeColors(Color.parseColor("#2EA043"))
        swipe.isEnabled = !mini && intent.getStringExtra("url") == null   // yalnız Ottplayer ekranında
        swipe.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 || !pageAtTop }
        swipe.setOnRefreshListener {
            web.loadUrl(OTT_HOME)
            swipe.postDelayed({ swipe.isRefreshing = false }, 6000)
        }
        root.addView(swipe, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        if (mini) {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
            col.addView(buildUrlBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            col.addView(root, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            setContentView(col)
            MiniBrowser.register(this)
            // fonda da səhifə işləməyə davam etsin
            if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 5)
        } else setContentView(root)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; javaScriptCanOpenWindowsAutomatically = true }
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        web.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, cb: android.webkit.ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try {
                    val i = Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                    startActivityForResult(Intent.createChooser(i, "Fayl seç"), 9); true
                } catch (e: Exception) { fileCb = null; false }
            }
            override fun onShowCustomView(v: android.view.View?, cb: CustomViewCallback?) {
                if (customView != null) { cb?.onCustomViewHidden(); return }
                customView = v; customCb = cb
                (window.decorView as FrameLayout).addView(v, FrameLayout.LayoutParams(-1, -1))
            }
            override fun onHideCustomView() {
                customView?.let { (window.decorView as FrameLayout).removeView(it) }
                customView = null; customCb?.onCustomViewHidden(); customCb = null
            }
        }
        enableDark()
        CookieManager.getInstance().setAcceptCookie(true)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try { WebViewCompat.addDocumentStartJavaScript(web, NO_PTR_JS, setOf("*")) } catch (e: Exception) { }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.host == "github.com" && v.url?.contains("github.com/search") == true &&
                    u.path?.contains("/blob/") == true && u.fragment?.matches(Regex("L\\d+.*")) == true) return true
                return handleLink(u.toString())
            }
            override fun onPageStarted(v: WebView, url: String?, f: android.graphics.Bitmap?) {
                super.onPageStarted(v, url, f)
                showUrl(url)
                v.evaluateJavascript(NO_PTR_JS, null)
            }
            override fun onPageFinished(v: WebView, url: String?) {
                super.onPageFinished(v, url)
                showUrl(url)
                swipe.isRefreshing = false
                v.evaluateJavascript(NO_PTR_JS, null)
                if (url != null && Uri.parse(url).host?.endsWith("github.com") == true) {
                    v.evaluateJavascript("window.__m3uFile=" + (if (inFilePage()) "true" else "false"), null)
                    v.evaluateJavascript(MARK_JS, null)
                }
            }
        }
        web.addJavascriptInterface(object {
            /** GitHub (Turbo) səhifələrində klikləri tutmaq üçün: true qaytarsa link brauzerdə açılmır, native işlənir. */
            @JavascriptInterface fun link(url: String, text: String): Boolean {
                val u = Uri.parse(url)
                if (isRepoLink(u)) {
                    // repo yalnız adına (owner/repo və ya repo) toxunduqda yoxlanılır
                    if (!isRepoName(u, text)) return false
                    runOnUiThread { testRepo(u.pathSegments[0], u.pathSegments[1]) }
                    return true
                }
                if (!intercepts(url)) return false
                runOnUiThread { handleLink(url) }
                return true
            }
            /** Axtarış nəticəsində toxunulan .m3u8 linki birbaşa playerdə açılır. */
            @JavascriptInterface fun play(raw: String) { runOnUiThread { playStream(raw) } }
            /** Fayl səhifəsində: faylın xam mətnindəki bütün .m3u8 linkləri tapılır (ekranda görünməyənlər də). */
            @JavascriptInterface fun rawScan(rawUrl: String) {
                if (Uri.parse(rawUrl).host != "raw.githubusercontent.com") return
                pool.execute {
                    try {
                        val c = URL(rawUrl).openConnection() as HttpURLConnection
                        c.connectTimeout = 15000; c.readTimeout = 30000
                        c.setRequestProperty("User-Agent", "M3USinayici")
                        val txt = c.inputStream.use { it.readBytes() }.let { String(it, Charsets.UTF_8) }
                        c.disconnect()
                        val hls = Regex("\\.m3u8(\\?|#|\\||\$)", RegexOption.IGNORE_CASE)
                        val set = LinkedHashSet<String>()
                        Regex("https?://[^\\s\"'<>`\\\\]+").findAll(txt).forEach { m ->
                            val u = m.value.trimEnd(')', ',', '.', ';', ']', '}')
                            if (set.size < 3000 && hls.containsMatchIn(u)) set.add(u)
                        }
                        val arr = JSONArray(set.toList())
                        runOnUiThread { web.evaluateJavascript("window.__m3uBulk&&__m3uBulk($arr)", null) }
                    } catch (e: Exception) { }
                }
            }
            @JavascriptInterface fun check(id: Int, url: String) {
                pool.execute {
                    val r = try { Net.probe(url, "{}", true) } catch (e: Exception) { "dead" }
                    runOnUiThread { web.evaluateJavascript("window.__m3uStat&&__m3uStat($id,'$r')", null) }
                }
            }
        }, "M3UProbe")
        web.addJavascriptInterface(object {
            @JavascriptInterface fun top(b: Boolean) { pageAtTop = b }
        }, "PtrBridge")
        web.setOnTouchListener { _, e ->
            if (e.action == android.view.MotionEvent.ACTION_DOWN) { touchX = e.x; touchY = e.y }
            false
        }
        web.setOnLongClickListener {
            val hit = web.hitTestResult
            val link = hit.extra
            if (inFilePage()) {
                // fayl səhifəsi: linkə basıb saxla → linki kopyala
                if ((hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                    && link != null && link.startsWith("http") && !link.contains("github.com")) { copyLink(link); return@setOnLongClickListener true }
                findUrlAtTouch { copyLink(it) }
                return@setOnLongClickListener false
            }
            if ((hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                && link != null && link.startsWith("http")) {
                val lu = Uri.parse(link)
                when {
                    isRepoLink(lu) -> showFullLink(link)
                    lu.host == "github.com" && lu.pathSegments.size >= 5 && lu.pathSegments[2] == "blob" -> showFileMenu(link)
                    else -> askPlay(link)
                }
                true
            } else {
                // GitHub axtarış nəticələrində linklər sadə mətndir: toxunulan yerdəki linki tapır
                findUrlAtTouch { askPlay(it) }
                false
            }
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun saveBase64(s: String) = save(Base64.decode(s, Base64.DEFAULT))
        }, "NativeSave")
        web.setDownloadListener { url, ua, cd, mime, _ ->
            val fname = android.webkit.URLUtil.guessFileName(url, cd, mime)
            val m3uLike = Regex("\\.(m3u8?|txt)$", RegexOption.IGNORE_CASE).containsMatchIn(fname) || (mime ?: "").contains("mpegurl", true)
            if (mini && !m3uLike && url.startsWith("http")) { dl(url, ua, fname, mime); return@setDownloadListener }
            Toast.makeText(this, "Yüklənir...", Toast.LENGTH_SHORT).show()
            when {
                url.startsWith("blob:") -> web.evaluateJavascript(
                    "fetch('$url').then(r=>r.blob()).then(b=>{var f=new FileReader();f.onload=function(){NativeSave.saveBase64(f.result.split(',')[1]);};f.readAsDataURL(b);});", null)
                url.startsWith("data:") -> save(Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT))
                else -> Thread {
                    try {
                        val c = URL(url).openConnection() as HttpURLConnection
                        c.setRequestProperty("User-Agent", ua)
                        CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                        save(c.inputStream.readBytes(), url)
                    } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() } }
                }.start()
            }
        }
        if (mini) {
            urlBox?.postDelayed({
                urlBox?.requestFocus()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                    .showSoftInput(urlBox, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }, 300)
        } else {
            if (intent.getStringExtra("url") == null) addSearchFab()
            web.loadUrl(intent.getStringExtra("url") ?: "https://ottplayer.tv/playlist/original")
        }
    }

    // ---------- Mini brauzer: ünvan qutusu ----------
    private fun buildUrlBar(): LinearLayout {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val input = android.widget.EditText(this).apply {
            hint = "Sayt ünvanı və ya axtarış"; setHintTextColor(Color.parseColor("#8B949E")); setTextColor(Color.WHITE)
            textSize = 16f; isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0D1117")); cornerRadius = dp(8).toFloat(); setStroke(dp(1), Color.parseColor("#30363D"))
            }
            setOnEditorActionListener { _, id, ev ->
                if (id == android.view.inputmethod.EditorInfo.IME_ACTION_GO ||
                    (ev != null && ev.keyCode == android.view.KeyEvent.KEYCODE_ENTER && ev.action == android.view.KeyEvent.ACTION_DOWN)) { goUrl(); true } else false
            }
        }
        urlBox = input
        val go = TextView(this).apply {
            text = "→"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            setPadding(dp(16), dp(6), dp(16), dp(6))
            background = GradientDrawable().apply { setColor(Color.parseColor("#238636")); cornerRadius = dp(8).toFloat() }
            setOnClickListener { goUrl() }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#161B22")); setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(go, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        }
    }

    private fun goUrl() {
        val box = urlBox ?: return
        val t = box.text.toString().trim()
        if (t.isEmpty()) return
        val u = when {
            Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*").matches(t) -> t
            !t.contains(' ') && Regex("^(localhost|\\d{1,3}(\\.\\d{1,3}){3}|[\\w-]+\\.(local|lan|home)|[\\w.-]+:\\d{1,5})(:\\d{1,5})?([/?#].*)?$", RegexOption.IGNORE_CASE).matches(t) -> "http://$t"
            !t.contains(' ') && t.contains('.') -> "https://$t"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(t, "UTF-8")
        }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
            .hideSoftInputFromWindow(box.windowToken, 0)
        box.clearFocus()
        web.requestFocus()
        web.loadUrl(u)
    }

    private fun showUrl(url: String?) {
        val box = urlBox ?: return
        if (url == null || url == "about:blank" || box.hasFocus()) return
        box.setText(url)
    }

    private var findBar: LinearLayout? = null
    private var findFab: TextView? = null

    /** Ottplayer ekranında sağ aşağıda 🔍 düyməsi: basanda ən aşağıda axtarış paneli açılır (mətn qutusu + ▲ ▼ oxlar). */
    private fun addSearchFab() {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val fab = TextView(this).apply {
            text = "🔍"; textSize = 24f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#238636")) }
            elevation = dp(8).toFloat()
            setOnClickListener { showFindBar() }
        }
        val lp = FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END)
        lp.setMargins(0, 0, dp(16), dp(24))
        root.addView(fab, lp)
        findFab = fab
    }

    private fun showFindBar() {
        if (findBar != null) return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        val count = TextView(this).apply { setTextColor(Color.parseColor("#8B949E")); textSize = 13f; setPadding(dp(6), 0, dp(6), 0) }
        val input = android.widget.EditText(this).apply {
            hint = "Səhifədə axtar"; setHintTextColor(Color.parseColor("#8B949E")); setTextColor(Color.WHITE)
            textSize = 16f; isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0D1117")); cornerRadius = dp(8).toFloat(); setStroke(dp(1), Color.parseColor("#30363D"))
            }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val q = s?.toString() ?: ""
                    if (q.isEmpty()) { web.clearMatches(); count.text = "" } else web.findAllAsync(q)
                }
            })
            setOnEditorActionListener { _, id, _ ->
                if (id == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) { web.findNext(true); true } else false
            }
        }
        web.setFindListener { active, total, done ->
            if (done) count.text = if (input.text.isEmpty()) "" else if (total == 0) "0" else "${active + 1}/$total"
        }
        fun arrow(t: String, fwd: Boolean) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { web.findNext(fwd) }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#161B22")); setPadding(dp(8), dp(8), dp(8), dp(8)); elevation = dp(12).toFloat()
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(count)
            addView(arrow("▲", false)); addView(arrow("▼", true))
            addView(TextView(this@BrowserActivity).apply {
                text = "✕"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
                setPadding(dp(14), dp(6), dp(14), dp(6)); setOnClickListener { hideFindBar() }
            })
        }
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        findBar = bar
        findFab?.visibility = android.view.View.GONE
        input.requestFocus()
        imm.showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideFindBar() {
        val b = findBar ?: return
        web.clearMatches(); web.setFindListener(null)
        (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
            .hideSoftInputFromWindow(b.windowToken, 0)
        root.removeView(b); findBar = null
        findFab?.visibility = android.view.View.VISIBLE
    }


    /** Fayl linkinə basıb saxlayanda: yeni səhifədə aç (orada .m3u8 linkləri də yoxlanılır). */
    private fun showFileMenu(link: String) {
        val d = AlertDialog.Builder(this).setTitle("Fayl").setMessage(link)
            .setPositiveButton("🌐 Yeni səhifədə aç") { _, _ -> openNewPage(link.substringBefore('#')) }
            .setNeutralButton("📋 Kopyala") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", link))
                Toast.makeText(this, "Link kopyalandı", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Bağla", null).show()
        d.findViewById<android.widget.TextView>(android.R.id.message)?.setTextIsSelectable(true)
    }

    private fun openNewPage(url: String) {
        startActivityForResult(Intent(this, BrowserActivity::class.java)
            .putExtra("url", url).putExtra("list", listNo).putExtra("token", ghToken).putExtra("file", true), 7)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rc: Int, data: Intent?) {
        super.onActivityResult(rq, rc, data)
        // yeni səhifədə playlist yadda saxlanıbsa, nəticə əsas ekrana ötürülür
        if (rq == 7 && rc == RESULT_OK) { setResult(RESULT_OK, data); finish() }
        if (rq == 9) { fileCb?.onReceiveValue(android.webkit.WebChromeClient.FileChooserParams.parseResult(rc, data)); fileCb = null }
    }

    private fun askPlay(link: String) {
        AlertDialog.Builder(this).setTitle("Link").setMessage(link)
            .setPositiveButton("▶ Playerdə aç") { _, _ -> playStream(link) }
            .setNegativeButton("Bağla", null).show()
            .findViewById<android.widget.TextView>(android.R.id.message)?.setTextIsSelectable(true)
    }

    /** Repo adına basıb saxlayanda linkin tam görünməsi (kəsilmədən) + kopyalama. */
    private fun showFullLink(link: String) {
        val d = AlertDialog.Builder(this).setTitle("Repo linki").setMessage(link)
            .setPositiveButton("📋 Kopyala") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", link))
                Toast.makeText(this, "Link kopyalandı", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("🌐 Yeni səhifədə aç") { _, _ -> web.loadUrl(link) }
            .setNegativeButton("Bağla", null).show()
        d.findViewById<android.widget.TextView>(android.R.id.message)?.setTextIsSelectable(true)
    }

    /** Uzun basılan yerdəki mətndən http(s) linkini çıxarır (GitHub kod axtarışı nəticələri link deyil, mətndir). */
    private fun copyLink(link: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", link))
        showCopiedPopup(link)
    }

    /** "Link kopyalandı" popupı: kopyalanan linki göstərir; düyməyə basanda yalnız bu link playerdə açılır. */
    private fun showCopiedPopup(link: String) {
        copyBar?.let { root.removeView(it) }
        root.removeCallbacks(hideCopyBar)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2161B22")); cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            elevation = dp(8).toFloat()
        }
        bar.addView(TextView(this).apply {
            text = "📋 Link kopyalandı"; setTextColor(Color.WHITE); textSize = 14f
        })
        bar.addView(TextView(this).apply {
            text = link; setTextColor(Color.parseColor("#8B949E")); textSize = 12f
            maxLines = 4; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            setTextIsSelectable(true)
            setPadding(0, dp(6), 0, dp(8))
        })
        bar.addView(TextView(this).apply {
            text = "▶ Playerdə aç"; setTextColor(Color.WHITE); textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply { setColor(Color.parseColor("#238636")); cornerRadius = dp(8).toFloat() }
            setOnClickListener { root.removeCallbacks(hideCopyBar); hideCopyBar.run(); playStream(link) }
        })
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        lp.setMargins(dp(12), 0, dp(12), dp(64))
        root.addView(bar, lp)
        copyBar = bar
        root.postDelayed(hideCopyBar, 8000)
    }

    private fun findUrlAtTouch(onUrl: (String) -> Unit) {
        @Suppress("DEPRECATION")
        var sc = web.scale
        if (sc <= 0f) sc = resources.displayMetrics.density
        val x = touchX / sc; val y = touchY / sc
        val js = """
(function(x,y){
  try{
    if(window.__m3uUrlAt){ var q0=window.__m3uUrlAt(x,y); if(q0) return q0; }
    var r=document.caretRangeFromPoint?document.caretRangeFromPoint(x,y):null; if(!r) return '';
    var n=r.startContainer, o=r.startOffset;
    var el=n.nodeType===3?n.parentElement:n, root=el;
    for(var i=0;i<8&&el;i++){ if((el.textContent||'').indexOf('http')>=0){ root=el; break; } el=el.parentElement; }
    if(!root) return '';
    var tw=document.createTreeWalker(root,NodeFilter.SHOW_TEXT), pos=0, caret=-1, t;
    while((t=tw.nextNode())){ if(t===n){ caret=pos+o; } pos+=t.nodeValue.length; }
    var text=root.textContent||'';
    var re=/https?:\/\/[^\s"'<>`\\]+/g, m, best='', bd=1e9;
    while((m=re.exec(text))){
      var u=m[0].replace(/[),.;\]}]+$/,''), s=m.index, e=s+u.length;
      var d=(caret>=s&&caret<=e)?0:Math.min(Math.abs(caret-s),Math.abs(caret-e));
      if(d<bd){ bd=d; best=u; }
    }
    return bd<=200?best:'';
  }catch(e){ return ''; }
})($x,$y)
"""
        web.evaluateJavascript(js) { v ->
            val u = try { org.json.JSONTokener(v ?: "").nextValue() as? String } catch (e: Exception) { null }
            if (!u.isNullOrEmpty() && u.startsWith("http")) onUrl(u)
        }
    }

    private fun enableDark() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, true)
        } else if (Build.VERSION.SDK_INT >= 29) {
            @Suppress("DEPRECATION")
            web.settings.forceDark = WebSettings.FORCE_DARK_ON
        }
    }

    /** Bu link native işlənməlidirmi (repo / media / GitHub-dakı M3U faylı)? */
    private fun intercepts(raw: String): Boolean {
        val u = Uri.parse(raw)
        if (u.scheme != "http" && u.scheme != "https") return false
        if (isRepoLink(u)) return false
        val ext = (u.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        if (ext !in mediaExt) return false
        if (u.host == "github.com") {
            val seg = u.pathSegments
            return (ext == "m3u" || ext == "m3u8") && seg.size >= 5 && seg[2] == "blob"
        }
        return true
    }

    /** true qaytarsa naviqasiya brauzerdə baş vermir (link ya playerdə açılır, ya da playlist kimi yadda saxlanılır). */
    private fun handleLink(raw: String): Boolean {
        val u = Uri.parse(raw)
        if (u.scheme != "http" && u.scheme != "https") return false
        if (isRepoLink(u)) return false
        val ext = (u.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        if (ext !in mediaExt) return false
        var url = raw
        if (u.host == "github.com") {
            val seg = u.pathSegments
            if (ext != "m3u" && ext != "m3u8") return false
            if (seg.size >= 5 && seg[2] == "blob") url = "https://raw.githubusercontent.com/${seg[0]}/${seg[1]}/${seg.drop(3).joinToString("/")}"
            else return false
        }
        if (ext == "m3u" || ext == "m3u8") {
            // kanal siyahısıdır, yoxsa canlı yayım (HLS)?
            Toast.makeText(this, "Yoxlanılır...", Toast.LENGTH_SHORT).show()
            val target = url
            Thread {
                var bytes: ByteArray? = null
                try {
                    val t = Net.Target(target, mapOf("User-Agent" to "VLC/3.0.20 LibVLC/3.0.20"), "brauzer")
                    val c = Net.connect(t, null, 10000)
                    bytes = c.inputStream.use { it.readBytes() }
                    c.disconnect()
                } catch (e: Exception) { }
                val text = bytes?.let { String(it, Charsets.UTF_8) } ?: ""
                val isList = bytes != null && text.contains("#EXTINF") && !text.contains("#EXT-X-")
                runOnUiThread { if (isList) save(bytes!!, target) else playStream(target) }
            }.start()
        } else playStream(url)
        return true
    }

    private fun playStream(url: String) {
        val base = url.split("|", limit = 2)[0].trim()
        val name = Uri.decode(Uri.parse(base).lastPathSegment ?: base)
        PlayQueue.items = listOf(QItem(name, url, "{}")); PlayQueue.index = 0
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun dl(url: String, ua: String?, name: String, mime: String?) {
        try {
            val r = android.app.DownloadManager.Request(Uri.parse(url))
            r.setTitle(name)
            if (!mime.isNullOrEmpty()) r.setMimeType(mime)
            ua?.let { r.addRequestHeader("User-Agent", it) }
            web.url?.let { r.addRequestHeader("Referer", it) }
            CookieManager.getInstance().getCookie(url)?.let { r.addRequestHeader("Cookie", it) }
            r.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as android.app.DownloadManager).enqueue(r)
            Toast.makeText(this, "Yükləmə başladı: $name", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun saveToDownloads(bytes: ByteArray, name: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = android.content.ContentValues().apply { put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name) }
                val u = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(u)!!.use { it.write(bytes) }
            } else {
                File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), name).writeBytes(bytes)
            }
            runOnUiThread { Toast.makeText(this, "Yükləmələr qovluğuna yazıldı: $name", Toast.LENGTH_LONG).show() }
        } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() } }
    }

    private fun save(bytes: ByteArray, src: String? = null) {
        val t = if (bytes.size > 5_000_000) "" else String(bytes, Charsets.UTF_8)
        if (mini && !t.contains("#EXTINF") && !t.contains("#EXTM3U")) { saveToDownloads(bytes, "yukleme_" + System.currentTimeMillis()); return }
        runOnUiThread {
            if (!t.contains("#EXTINF") && !t.contains("#EXTM3U")) {
                Toast.makeText(this, "Endirilən fayl M3U deyil", Toast.LENGTH_LONG).show(); return@runOnUiThread
            }
            File(filesDir, "playlist$listNo.m3u").writeText(t)
            File(filesDir, "playlist$listNo.url").writeText(src ?: "")
            setResult(RESULT_OK, Intent().putExtra("list", listNo)); finish()
        }
    }

    // ---------- GitHub repo: M3U fayllarını tap, 2-ci playlistdə yoxla ----------
    private val reserved = setOf("search", "settings", "orgs", "topics", "marketplace", "features", "login", "signup",
        "explore", "notifications", "sponsors", "collections", "trending", "pricing", "about", "contact", "issues", "pulls",
        "codespaces", "new", "join", "site", "enterprise", "readme", "security", "apps", "users", "organizations")

    private fun isRepoLink(u: Uri): Boolean {
        if (u.host != "github.com") return false
        val seg = u.pathSegments
        return seg.size == 2 && seg[0].lowercase() !in reserved
    }

    private fun isRepoName(u: Uri, text: String): Boolean {
        val t = text.replace(Regex("\\s+"), "").lowercase()
        val owner = u.pathSegments[0].lowercase(); val repo = u.pathSegments[1].lowercase()
        return t == "$owner/$repo" || t == repo
    }

    private fun gh(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "M3USinayici")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        if (ghToken.isNotEmpty()) c.setRequestProperty("Authorization", "token $ghToken")
        return c
    }

    private fun encSeg(p: String) = p.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    private fun testRepo(owner: String, repo: String) {
        Toast.makeText(this, "$owner/$repo yoxlanılır...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val c = gh("https://api.github.com/repos/$owner/$repo/git/trees/HEAD?recursive=1")
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                c.disconnect()
                val j = JSONObject(txt)
                if (code !in 200..299) throw java.io.IOException(j.optString("message", "GitHub xətası (HTTP $code)"))
                val tree = j.getJSONArray("tree")
                val files = ArrayList<String>()
                for (i in 0 until tree.length()) {
                    val o = tree.getJSONObject(i)
                    val path = o.getString("path")
                    val low = path.lowercase()
                    if (o.getString("type") == "blob" && (low.endsWith(".m3u") || low.endsWith(".m3u8")) && o.optLong("size", 0) < 30L * 1024 * 1024) files.add(path)
                }
                files.sort()
                runOnUiThread {
                    when {
                        files.isEmpty() -> Toast.makeText(this, "Bu repoda M3U fayl tapılmadı", Toast.LENGTH_LONG).show()
                        files.size == 1 -> loadRepoFile(owner, repo, files[0])
                        else -> AlertDialog.Builder(this).setTitle("$owner/$repo — fayl seçin")
                            .setItems(files.take(60).toTypedArray()) { _, w -> loadRepoFile(owner, repo, files[w]) }.show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Repo xətası: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun loadRepoFile(owner: String, repo: String, path: String) {
        Toast.makeText(this, "Yüklənir: $path", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val c = URL("https://raw.githubusercontent.com/$owner/$repo/HEAD/${encSeg(path)}").openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 60000
                c.setRequestProperty("User-Agent", "M3USinayici")
                val bytes = c.inputStream.use { it.readBytes() }
                c.disconnect()
                val t = String(bytes, Charsets.UTF_8)
                if (!t.contains("#EXTINF")) runOnUiThread { Toast.makeText(this, "Bu fayl kanal siyahısı deyil", Toast.LENGTH_LONG).show() }
                else save(bytes, "https://raw.githubusercontent.com/$owner/$repo/HEAD/${encSeg(path)}")
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Yükləmə xətası: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    override fun onDestroy() {
        pool.shutdownNow()
        if (mini) {
            MiniBrowser.unregister(this)
            BrowserService.stop(this)
            try { web.stopLoading(); web.loadUrl("about:blank"); (web.parent as? ViewGroup)?.removeView(web); web.destroy() } catch (e: Exception) { }
        }
        super.onDestroy()
    }

    companion object {
        /** Səhifənin ən yuxarıda olub-olmadığını native tərəfə bildirir (yuxarıdan sürüşdürüb yeniləmə üçün); GitHub səhifələrinə toxunmur. */
        val NO_PTR_JS = """(function(){
try{ if(String(location.hostname).slice(-10)==='github.com') return; }catch(e){ return; }
if(window.__noPtr) return; window.__noPtr=true;
try{
  var st=document.createElement('style');
  st.textContent='html,body{overscroll-behavior-y:none!important;}';
  (document.head||document.documentElement).appendChild(st);
}catch(e){}
function canScrollUp(el){
  while(el && el.nodeType===1){
    try{
      var cs=getComputedStyle(el);
      if(/(auto|scroll)/.test(cs.overflowY) && el.scrollHeight>el.clientHeight && el.scrollTop>0) return true;
    }catch(e){}
    el=el.parentElement;
  }
  return false;
}
window.addEventListener('touchstart',function(e){
  var top=window.pageYOffset||(document.scrollingElement&&document.scrollingElement.scrollTop)||0;
  try{ PtrBridge.top(top<=0 && !canScrollUp(e.target)); }catch(x){}
},{capture:true,passive:true});
})();"""

        /** GitHub səhifəsində mətn şəklindəki linklərin yanına 🟢/🔴 qoyur (yoxlama native aparılır). */
        val MARK_JS = """(function(){
if(window.__m3uInit){ if(window.__m3uScan) window.__m3uScan(); return; }
window.__m3uInit=true;
var state={}, cur={}, curPath='', rawDone='', ids={}, nid=0, total=0, MAX=2000, auto=false, lastNew=Date.now(), lastNext='', lastClick=0, saveT=null;
try{ state=JSON.parse(sessionStorage.getItem('m3uAll')||'{}')||{}; auto=sessionStorage.getItem('m3uAuto')==='1'; }catch(e){ state={}; }
var skipHost=/(^|\.)(github\.com|githubusercontent\.com|githubassets\.com|githubapp\.com)#SP#/i;
var media=/\.(m3u8?|ts|mp4|mkv|mpd|flv|avi|mov|webm|mp3|aac|m4a|m4v|3gp|mpg|mpeg)#SP#/i;
var re=/https?:\/\/[^\s"'<>`\\]+/g;
var INLINE={SPAN:1,MARK:1,EM:1,B:1,STRONG:1,I:1,A:1,CODE:1,U:1,S:1,SMALL:1};
function cleanEnd(u){ return u.replace(/[),.;\]}]+#SP#/,''); }
function good(u){ try{ var x=new URL(u.split('|')[0]); if(skipHost.test(x.hostname)) return false;
  var p=x.pathname; return !!x.port || media.test(p) || p.split('/').filter(Boolean).length>=2; }catch(e){ return false; } }
function paint(sp,st){ sp.textContent = st==='ok' ? ' \uD83D\uDFE2' : st==='dead' ? ' \uD83D\uDD34' : ' \u23F3'; }
function persist(){ clearTimeout(saveT); saveT=setTimeout(function(){ try{
  var o={}; for(var k in state){ if(state[k]==='ok'||state[k]==='dead') o[k]=state[k]; }
  sessionStorage.setItem('m3uAll',JSON.stringify(o)); }catch(e){} },800); }
window.__m3uStat=function(id,st){
  var u=ids[id]; if(!u) return; state[u]=st;
  var all=document.querySelectorAll('span.m3u-st');
  for(var i=0;i<all.length;i++){ if(all[i].getAttribute('data-url')===u) paint(all[i],st); }
  persist(); bar();
};
function mark(u){
  var sp=document.createElement('span'); sp.className='m3u-st'; sp.setAttribute('data-url',u);
  sp.style.cssText='user-select:none;-webkit-user-select:none';
  cur[u]=1;
  if(state[u]===undefined){ state[u]='pending'; lastNew=Date.now(); var id=++nid; ids[id]=u; try{ M3UProbe.check(id,u); }catch(e){} }
  paint(sp, state[u]==='pending' ? '' : state[u]);
  return sp;
}
/* Eyni sətirdəki mətn qovşaqlarını birləşdirir: axtarış sözü <mark> ilə seçildikdə link bir neçə qovşağa bölünür */
function processGroup(nodes){
  var text='', starts=[], i;
  for(i=0;i<nodes.length;i++){ starts.push(text.length); text+=nodes[i].nodeValue; }
  if(text.indexOf('http')<0) return;
  var m, found=[]; re.lastIndex=0;
  while((m=re.exec(text))){ var u=cleanEnd(m[0]); if(good(u)) found.push({u:u,end:m.index+u.length}); }
  for(var k=found.length-1;k>=0;k--){
    if(total>=MAX) return;
    var f=found[k], idx=nodes.length-1;
    while(idx>0 && starts[idx]>=f.end) idx--;
    var node=nodes[idx], par=node.parentNode; if(!par) continue;
    var off=f.end-starts[idx];
    if(off>=node.nodeValue.length){
      var nx=node.nextSibling; if(nx && nx.nodeType===1 && nx.className==='m3u-st') continue;
      par.insertBefore(mark(f.u), node.nextSibling);
    } else {
      var rest=node.splitText(off); par.insertBefore(mark(f.u), rest);
    }
    total++;
  }
}
window.__m3uBulk=function(list){
  for(var i=0;i<list.length;i++){ var u=list[i]; if(!good(u)) continue; cur[u]=1;
    if(state[u]===undefined){ state[u]='pending'; lastNew=Date.now(); var id=++nid; ids[id]=u; try{ M3UProbe.check(id,u); }catch(e){} } }
  bar();
};
function fileStyle(){
  if(window.__m3uFile && document.head && !document.getElementById('m3u-nosel')){
    var st=document.createElement('style'); st.id='m3u-nosel';
    st.textContent='*{-webkit-user-select:none!important;user-select:none!important;-webkit-touch-callout:none!important}';
    document.head.appendChild(st);
  }
}
function scan(){
  if(!document.body) return;
  fileStyle();
  if(curPath!==location.pathname){ curPath=location.pathname; cur={}; rawDone=''; }
  if(rawDone!==location.pathname){
    var mm=location.pathname.match(/^\/([^\/]+)\/([^\/]+)\/blob\/(.+)#SP#/);
    if(mm){ rawDone=location.pathname; try{ M3UProbe.rawScan('https://raw.githubusercontent.com/'+mm[1]+'/'+mm[2]+'/'+mm[3]); }catch(e){} }
  }
  var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode:function(n){
    var p=n.parentNode; if(!p) return 2; var t=p.nodeName;
    if(t==='SCRIPT'||t==='STYLE'||t==='TEXTAREA'||t==='NOSCRIPT') return 2;
    if(p.className==='m3u-st') return 2;
    if(p.closest && p.closest('#m3u-bar')) return 2;
    return 1; }});
  var groups=[], cur=null, curRoot=null, n;
  while((n=w.nextNode())){
    var r=n.parentNode; while(r && INLINE[r.nodeName]) r=r.parentNode;
    if(r!==curRoot){ curRoot=r; cur=[]; groups.push(cur); }
    cur.push(n);
  }
  groups.forEach(processGroup);
  bar();
}
window.__m3uScan=scan;
/* ---- alt panel: say + növbəti səhifə + avtomatik rejim ---- */
function nextLink(){
  var a=document.querySelector('a[rel="next"]'); if(a) return a;
  var all=document.querySelectorAll('a[href*="p="]');
  for(var i=0;i<all.length;i++){
    var l=((all[i].getAttribute('aria-label')||'')+' '+(all[i].textContent||'')).toLowerCase();
    if(/next/.test(l) && all[i].getAttribute('aria-disabled')!=='true') return all[i];
  }
  return null;
}
function counts(){
  var ok=0, dead=0, pend=0, k, s;
  if(/^\/search/.test(location.pathname)){
    for(k in state){ s=state[k]; if(s==='ok') ok++; else if(s==='dead') dead++; else pend++; }
  } else if(/\/blob\//.test(location.pathname)){
    for(k in cur){ s=state[k]; if(s==='ok') ok++; else if(s==='dead') dead++; else pend++; }
  } else {
    var seen={}, sp=document.querySelectorAll('span.m3u-st');
    for(var i=0;i<sp.length;i++){ k=sp[i].getAttribute('data-url'); if(seen[k]) continue; seen[k]=1;
      s=state[k]; if(s==='ok') ok++; else if(s==='dead') dead++; else pend++; }
  }
  return {ok:ok,dead:dead,pend:pend};
}
function bar(){
  var b=document.getElementById('m3u-bar');
  var isS=/^\/search/.test(location.pathname);
  var isB=/\/blob\//.test(location.pathname);
  if(!isS && !(isB && Object.keys(cur).length) && !document.querySelector('span.m3u-st')){ if(b) b.style.display='none'; return; }
  if(!b){
    b=document.createElement('div'); b.id='m3u-bar';
    b.style.cssText='position:fixed;left:0;right:0;bottom:0;z-index:2147483647;background:#161b22;color:#e6edf3;border-top:1px solid #30363d;padding:6px 8px;font:13px sans-serif;display:flex;align-items:center;gap:6px;flex-wrap:wrap';
    var c=document.createElement('span'); c.id='m3u-cnt'; c.style.cssText='flex:1;min-width:140px'; b.appendChild(c);
    function btn(id,t,fn){ var x=document.createElement('button'); x.id=id; x.textContent=t;
      x.style.cssText='background:#238636;color:#fff;border:0;border-radius:6px;padding:6px 10px;font-size:13px'; x.onclick=fn; b.appendChild(x); return x; }
    btn('m3u-auto','',function(){ auto=!auto; try{ sessionStorage.setItem('m3uAuto',auto?'1':'0'); }catch(e){} lastNew=Date.now(); lastNext=''; bar(); });
    btn('m3u-next','\u25B6 N\u00F6vb\u0259ti',function(){ var n=nextLink(); if(n) n.click(); });
    document.body.appendChild(b);
  }
  b.style.display='flex';
  document.getElementById('m3u-auto').style.display = isS ? '' : 'none';
  document.getElementById('m3u-next').style.display = isS ? '' : 'none';
  var q=counts(), done=!!(isS && auto && !nextLink() && q.pend===0);
  document.getElementById('m3u-cnt').textContent='\uD83D\uDFE2 '+q.ok+'  \uD83D\uDD34 '+q.dead+'  \u23F3 '+q.pend+(done?'  \u2705 Bitdi':'');
  document.getElementById('m3u-auto').textContent = auto ? '\u23F9 Dayan' : '\u25B6\u25B6 Avto: b\u00FCt\u00FCn s\u0259hif\u0259l\u0259r';
}
setInterval(function(){
  if(!auto || !/^\/search/.test(location.pathname)) return;
  scan();
  if(counts().pend>0 || Date.now()-lastNew<3000) return;
  var n=nextLink();
  if(!n){ auto=false; try{ sessionStorage.setItem('m3uAuto','0'); }catch(e){} bar(); return; }
  if(n.href===lastNext && Date.now()-lastClick<12000) return;
  lastNext=n.href; lastClick=Date.now(); lastNew=Date.now(); n.click();
},1500);
function blockRootOf(n){ var r=n.parentNode; while(r && INLINE[r.nodeName]) r=r.parentNode; return r; }
/* Toxunulan nöqtədəki http(s) linkini mətndən tapır (yalnız hərfin üstünə toxunulubsa) */
/* Fayl səhifəsində kodun üstündə şəffaf textarea/örtük olur: onu müvəqqəti keçib altındakı mətni tapır */
function caretAt(x,y){
  var saved=[], rg=null;
  try{
    for(var i=0;i<6;i++){
      var el=document.elementFromPoint(x,y); if(!el) break;
      var overlay = el.nodeName==='TEXTAREA' || (!el.firstElementChild && !/\S/.test(el.textContent||''));
      if(!overlay) break;
      saved.push([el,el.style.pointerEvents]); el.style.pointerEvents='none';
    }
    rg=document.caretRangeFromPoint?document.caretRangeFromPoint(x,y):null;
  }catch(e){}
  for(var j=saved.length-1;j>=0;j--) saved[j][0].style.pointerEvents=saved[j][1];
  return rg;
}
function urlAt(x,y){
  try{
    var rg=caretAt(x,y); if(!rg) return '';
    var n=rg.startContainer, o=rg.startOffset; if(n.nodeType!==3) return '';
    if(n.parentNode && n.parentNode.className==='m3u-st') return '';
    var hit=false, L=n.nodeValue.length, pairs=[[o-1,o],[o,o+1]];
    for(var k=0;k<2&&!hit;k++){
      var p=pairs[k]; if(p[0]<0||p[1]>L) continue;
      var r2=document.createRange(); r2.setStart(n,p[0]); r2.setEnd(n,p[1]);
      var rs=r2.getClientRects();
      for(var i=0;i<rs.length;i++){ var q=rs[i]; if(x>=q.left-4&&x<=q.right+4&&y>=q.top-4&&y<=q.bottom+4) hit=true; }
    }
    if(!hit) return '';
    var root=blockRootOf(n), w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT), t, text='', pos=0, caret=-1;
    while((t=w.nextNode())){
      var pp=t.parentNode; if(pp && pp.className==='m3u-st') continue;
      if(blockRootOf(t)!==root) continue;
      if(t===n) caret=pos+o;
      text+=t.nodeValue; pos+=t.nodeValue.length;
    }
    if(caret<0) return '';
    var m, rr=/https?:\/\/[^\s"'<>`\\]+/g;
    while((m=rr.exec(text))){ var u=cleanEnd(m[0]); if(caret>=m.index && caret<=m.index+u.length) return u; }
  }catch(e){}
  return '';
}
window.__m3uUrlAt=urlAt;
function inPreview(el){
  try{ return !!(el && el.closest && el.closest('table,pre,code,[class*="snippet" i],[class*="blob-code"],[class*="code-list"],[data-testid*="snippet" i]')); }catch(e){ return false; }
}
function isBlobPage(){ return /\/blob\//.test(location.pathname); }
function block(e){ e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); }
document.addEventListener('click',function(e){
  var tg=e.target; if(tg && tg.closest && tg.closest('#m3u-bar')) return;
  var onSearch=/^\/search/.test(location.pathname);
  var u=urlAt(e.clientX,e.clientY);
  if(u && (/\.m3u8(\?|#|\||#SP#)/i.test(u) || (window.__m3uFile && isBlobPage() && good(u)))){ block(e); try{ M3UProbe.play(u); }catch(x){} return; }
  var a=tg&&tg.closest?tg.closest('a[href]'):null;
  if(a && a.href){
    try{ if(M3UProbe.link(a.href,(a.textContent||'').trim())){ block(e); return; } }catch(x){}
    if(onSearch && (inPreview(a) || /\/blob\/[^#]*#L\d+/.test(a.href))) block(e);
    return;
  }
  if(onSearch && inPreview(tg)) block(e);
},true);
var timer=null;
new MutationObserver(function(){ clearTimeout(timer); timer=setTimeout(scan,700); }).observe(document.body,{childList:true,subtree:true});
scan();
})();""".replace("#SP#", "$")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (customView != null) { web.webChromeClient?.onHideCustomView(); return }; if (findBar != null) { hideFindBar(); return }; if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
