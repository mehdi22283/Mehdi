package az.m3u.sinayici

import android.app.Activity
import android.app.Application
import android.app.Dialog
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.LoadEventInfo
import androidx.media3.exoplayer.source.MediaLoadData
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.lang.ref.WeakReference
import kotlin.math.abs

class QItem(val name: String, val url: String, val hdr: String)
object PlayQueue { var items: List<QItem> = emptyList(); var index = 0 }

/**
 * Tətbiqdaxili PiP (Android sistem PiP-i YOXDUR).
 * Player tək bir View-dur: kiçik rejimdə (MINI) tətbiqin hazırkı ekranının üstündə sürüklənən pəncərə kimi durur,
 * "Böyüt" düyməsi ilə tam ekran (FULL) olur, "Kiçilt" ilə geri qayıdır. Activity-lər arasında (əsas ekran ↔ brauzer)
 * və axtarış dialoqunun üstündə qalır. Tətbiqdən çıxanda dayanır, qayıdanda davam edir.
 */
class PlayerPanel private constructor(private val ctx: Context) : FrameLayout(ctx) {
    private val h = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("m3u", Context.MODE_PRIVATE)
    private val pv = PlayerView(ctx)
    private val vl = VLCVideoLayout(ctx)
    private var exo: ExoPlayer? = null
    private var vlcLib: LibVLC? = null
    private var vlc: MediaPlayer? = null
    private lateinit var statsTv: TextView
    private lateinit var nameTv: TextView
    private lateinit var miniNameTv: TextView
    private lateinit var miniStatsTv: TextView
    private lateinit var engExo: TextView
    private lateinit var engVlc: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var miniPlay: ImageButton
    private lateinit var miniEng: TextView
    private lateinit var bottomBox: LinearLayout
    private lateinit var miniTop: LinearLayout
    private lateinit var miniCtl: LinearLayout
    private var engine = "exo"
    private var url = ""
    private var curName = ""
    @Volatile private var target = Net.Target("", emptyMap(), "")
    private var profiles: List<Net.Target> = emptyList()
    private var pIdx = 0
    private var msg = ""
    private var gen = 0
    private var latency = -1L
    private var speedBps = -1L
    private var prevAhead = -1L
    private var vlcBuf = 100f
    private var vlcPlaying = false
    private var speed = 1f
    private var resizeIdx = 0
    private var alive = true
    private var full = false
    private var userPaused = false
    private var resumeOnFg = false
    private var lastIcon = 0
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var startTx = 0f
    private var startTy = 0f
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var lockedAct: WeakReference<Activity>? = null
    private var prevOrient = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private val hideCtl = Runnable { miniCtl.visibility = View.GONE }
    private val glowCache = HashMap<Int, Drawable>()   // init-dən əvvəl elan olunmalıdır
    private val RED_GLOW = 0xFFFF1A1A.toInt()

    companion object {
        private var inst: PlayerPanel? = null
        private var actRef: WeakReference<Activity>? = null
        private var dlgRef: WeakReference<Dialog>? = null
        private var hostCount = 0
        private var started = 0
        private var posFx = 1f
        private var posFy = 0.88f

        private fun isHost(a: Activity) = a is MainActivity || a is BrowserActivity
        private fun inFg() = started > 0

        /** App.onCreate-də bir dəfə çağırılır. */
        fun install(app: Application) {
            app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
                override fun onActivityCreated(a: Activity, b: Bundle?) { if (isHost(a)) hostCount++ }
                override fun onActivityStarted(a: Activity) {
                    if (!isHost(a)) return
                    started++
                    if (started == 1) inst?.onForeground()
                }
                override fun onActivityResumed(a: Activity) {
                    if (!isHost(a)) return
                    actRef = WeakReference(a)
                    inst?.attachHost()
                }
                override fun onActivityPaused(a: Activity) {}
                override fun onActivityStopped(a: Activity) {
                    if (!isHost(a)) return
                    started = (started - 1).coerceAtLeast(0)
                    if (started == 0) inst?.onBackground()
                }
                override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
                override fun onActivityDestroyed(a: Activity) {
                    if (!isHost(a)) return
                    hostCount = (hostCount - 1).coerceAtLeast(0)
                    val p = inst ?: return
                    if (hostCount == 0) {
                        if (a.isChangingConfigurations) { actRef = null; p.detach() }   // activity yenidən yaranır, pleyer qalır
                        else p.closePlayer()
                        return
                    }
                    val cur = actRef?.get()
                    if (cur == null || cur === a) { actRef = null; p.detach() }
                }
            })
        }

        /** PlayQueue hazırlandıqdan sonra çağırılır: kiçik pəncərə açılır / kanal dəyişir. [d] axtarış dialoqudursa pəncərə onun üstündə qalır. */
        fun open(a: Activity, d: Dialog? = null) {
            actRef = WeakReference(a)
            dlgRef = if (d != null) WeakReference(d) else null
            var p = inst
            if (p == null) { p = PlayerPanel(a.applicationContext); inst = p }
            p.attachHost()
            p.loadCurrent()
        }

        /** Dialoq bağlananda pəncərə yenidən activity-yə qayıdır. */
        fun dialogGone(d: Dialog) {
            if (dlgRef?.get() === d) { dlgRef = null; inst?.attachHost() }
        }

        /** "Geri" düyməsi: tam ekrandırsa kiçildir (true qaytarır). */
        fun handleBack(): Boolean = inst?.backPressed() ?: false
    }

    init {
        buildUi()
        applyMode()
        tick(); probeLoop()
    }

    // ---------- interfeys ----------
    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
    }

    private fun iconBtn(res: Int, f: () -> Unit): ImageButton = ImageButton(ctx).apply {
        setImageResource(res)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = rounded(0xFF2563EB.toInt(), 36)
        setOnClickListener { f() }
    }

    /** İkonun öz kənarları boyunca qırmızı kölgə (glow) çəkilmiş drawable; fon yoxdur, tam şəffafdır. */
    private fun glowIcon(res: Int): Drawable = glowCache.getOrPut(res) {
        val src = ctx.getDrawable(res)!!.mutate()
        val sz = dp(24) * 3
        val pad = dp(5) * 3 / 2
        val icon = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
        src.setBounds(0, 0, sz, sz); src.draw(Canvas(icon))
        val out = Bitmap.createBitmap(sz + pad * 2, sz + pad * 2, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val blur = Paint(Paint.ANTI_ALIAS_FLAG).apply { maskFilter = BlurMaskFilter(dp(3) * 1.5f, BlurMaskFilter.Blur.NORMAL) }
        val off = IntArray(2)
        val alpha = icon.extractAlpha(blur, off)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = RED_GLOW }
        repeat(3) { c.drawBitmap(alpha, (pad + off[0]).toFloat(), (pad + off[1]).toFloat(), fill) }
        c.drawBitmap(icon, pad.toFloat(), pad.toFloat(), null)
        BitmapDrawable(ctx.resources, out)
    }

    private fun miniBtn(res: Int, f: () -> Unit): ImageButton = ImageButton(ctx).apply {
        setImageDrawable(glowIcon(res))
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(2), dp(2), dp(2), dp(2))
        setBackgroundColor(Color.TRANSPARENT)
        setOnClickListener { f(); keepCtl() }
    }

    private fun segment(t: String, f: () -> Unit): TextView = TextView(ctx).apply {
        text = t; textSize = 18f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setOnClickListener { f() }
    }

    private fun buildUi() {
        keepScreenOn = true
        setBackgroundColor(Color.BLACK)
        engine = prefs.getString("engine", "exo") ?: "exo"
        pv.useController = false
        pv.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)

        statsTv = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(Color.BLACK)
        }
        nameTv = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER; maxLines = 2
            typeface = Typeface.DEFAULT_BOLD
        }
        engExo = segment("ExoPlayer") { setEngine("exo") }
        engVlc = segment("VLC") { setEngine("vlc") }
        val seg = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(0xFF1F2937.toInt(), 28)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(engExo, LinearLayout.LayoutParams(0, dp(50), 1f))
            addView(engVlc, LinearLayout.LayoutParams(0, dp(50), 1f))
        }
        playBtn = iconBtn(R.drawable.ic_pause) { togglePause() }
        val nav = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(iconBtn(R.drawable.ic_prev) { step(-1) }, LinearLayout.LayoutParams(dp(72), dp(72)))
            addView(playBtn, LinearLayout.LayoutParams(dp(84), dp(84)).apply { setMargins(dp(28), 0, dp(28), 0) })
            addView(iconBtn(R.drawable.ic_next) { step(1) }, LinearLayout.LayoutParams(dp(72), dp(72)))
        }
        val minBtn = TextView(ctx).apply {
            text = "▼ Kiçilt"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(0xFF2563EB.toInt(), 24)
            setOnClickListener { setFull(false) }
        }
        val closeBtn = TextView(ctx).apply {
            text = "✖ Bağla"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(0xFF4B5563.toInt(), 24)
            setOnClickListener { closePlayer() }
        }
        val actRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(minBtn, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(6) })
            addView(closeBtn, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(6) })
        }
        bottomBox = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(14), dp(8), dp(14), dp(18))
            addView(nameTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(8) })
            addView(nav)
            addView(seg, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
            addView(actRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
        }

        // kiçik rejim: yuxarıda kanal adı + ✕, toxunanda aşağıda idarə düymələri
        miniNameTv = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 11f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(4), dp(4), dp(4))
            setShadowLayer(dp(4).toFloat(), 0f, 0f, RED_GLOW)
        }
        miniStatsTv = TextView(ctx).apply {
            setTextColor(0xFFE5E7EB.toInt()); textSize = 9f; maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(4), dp(3))
            setShadowLayer(dp(4).toFloat(), 0f, 0f, RED_GLOW)
        }
        val miniInfo = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(miniNameTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(miniStatsTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        val miniClose = TextView(ctx).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(dp(12), dp(2), dp(12), dp(2))
            setShadowLayer(dp(5).toFloat(), 0f, 0f, RED_GLOW)
            setOnClickListener { closePlayer() }
        }
        miniTop = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
            addView(miniInfo, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(miniClose, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        }
        miniPlay = miniBtn(R.drawable.ic_pause) { togglePause() }
        miniEng = TextView(ctx).apply {
            textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setBackgroundColor(Color.TRANSPARENT)
            setShadowLayer(dp(5).toFloat(), 0f, 0f, RED_GLOW)
            setOnClickListener { setEngine(if (engine == "exo") "vlc" else "exo"); keepCtl() }
        }
        miniCtl = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(4), dp(2), dp(4), dp(2))
            addView(miniBtn(R.drawable.ic_prev) { step(-1) }, LinearLayout.LayoutParams(dp(34), dp(34)))
            addView(miniPlay, LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(6), 0, dp(6), 0) })
            addView(miniBtn(R.drawable.ic_next) { step(1) }, LinearLayout.LayoutParams(dp(34), dp(34)))
            addView(miniEng, LinearLayout.LayoutParams(dp(40), dp(28)).apply { setMargins(dp(8), 0, dp(4), 0) })
            addView(miniBtn(R.drawable.ic_expand) { setFull(true) }, LinearLayout.LayoutParams(dp(34), dp(34)))
            visibility = View.GONE
        }

        pv.setOnClickListener { if (full) togglePause() else toggleCtl() }
        vl.setOnClickListener { if (full) togglePause() else toggleCtl() }
        val videoBox = FrameLayout(ctx).apply {
            addView(pv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(vl, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(miniTop, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.TOP))
            addView(miniCtl, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(statsTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(videoBox, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(bottomBox, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        addView(col, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        applyEngineViews()
    }

    // ---------- kiçik / tam ekran rejimi ----------
    private fun miniW(): Int {
        val dm = ctx.resources.displayMetrics
        return minOf(dp(300), (minOf(dm.widthPixels, dm.heightPixels) * 0.62f).toInt())
    }

    private fun makeLp(): FrameLayout.LayoutParams =
        if (full) FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        else FrameLayout.LayoutParams(miniW(), miniW() * 9 / 16, Gravity.TOP or Gravity.START)

    private fun applyMode() {
        val vis = if (full) View.VISIBLE else View.GONE
        statsTv.visibility = vis
        bottomBox.visibility = vis
        miniTop.visibility = if (full) View.GONE else View.VISIBLE
        h.removeCallbacks(hideCtl)
        miniCtl.visibility = View.GONE
        if (full) {
            translationX = 0f; translationY = 0f; foreground = null
        } else {
            foreground = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(2), 0xFF2563EB.toInt()) }
        }
        if (parent != null) layoutParams = makeLp()
        updatePlayIcon()
    }

    private fun setFull(on: Boolean) {
        if (on == full) return
        full = on
        if (on) {   // tam ekran dialoqun altında qalmasın
            val d = dlgRef?.get()
            if (d != null && d.isShowing) d.dismiss()
        }
        applyMode()
        attachHost()
        lockPortrait(on)
    }

    private fun backPressed(): Boolean {
        if (full) { setFull(false); return true }
        return false
    }

    /** Tam ekranda portret (köhnə player kimi); kiçiləndə əvvəlki istiqamət qaytarılır. */
    private fun lockPortrait(on: Boolean) {
        if (on) {
            val a = actRef?.get() ?: return
            if (lockedAct?.get() !== a) { prevOrient = a.requestedOrientation; lockedAct = WeakReference(a) }
            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            val la = lockedAct?.get()
            if (la != null && !la.isFinishing) la.requestedOrientation = prevOrient
            lockedAct = null
        }
    }

    // ---------- yerləşmə (activity / dialoq) ----------
    private fun pickContainer(): ViewGroup? {
        if (!full) {
            val d = dlgRef?.get()
            if (d != null && d.isShowing) {
                val c = d.window?.decorView?.findViewById<ViewGroup>(android.R.id.content)
                if (c != null) return c
            }
        }
        val a = actRef?.get() ?: return null
        if (a.isFinishing || a.isDestroyed) return null
        return a.findViewById<ViewGroup>(android.R.id.content)
    }

    fun attachHost() {
        if (!alive) return
        val c = pickContainer() ?: return
        if (parent === c) { bringToFront(); return }
        (parent as? ViewGroup)?.removeView(this)
        c.addView(this, makeLp())
        bringToFront()
    }

    fun detach() { (parent as? ViewGroup)?.removeView(this) }

    private fun placeMini() {
        if (full) return
        val p = parent as? View ?: return
        if (p.width <= 0 || p.height <= 0) return
        val freeX = (p.width - width).coerceAtLeast(0)
        val freeY = (p.height - height).coerceAtLeast(0)
        translationX = posFx.coerceIn(0f, 1f) * freeX
        translationY = posFy.coerceIn(0f, 1f) * freeY
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (!dragging) placeMini()
    }

    // ---------- sürükləmə / toxunma ----------
    private fun startDrag(ev: MotionEvent) {
        downX = ev.rawX; downY = ev.rawY
        startTx = translationX; startTy = translationY
        dragging = false
    }

    private fun moveTo(ev: MotionEvent) {
        val p = parent as? View ?: return
        val maxX = (p.width - width).coerceAtLeast(0).toFloat()
        val maxY = (p.height - height).coerceAtLeast(0).toFloat()
        translationX = (startTx + ev.rawX - downX).coerceIn(0f, maxX)
        translationY = (startTy + ev.rawY - downY).coerceIn(0f, maxY)
    }

    private fun savePos() {
        val p = parent as? View ?: return
        val freeX = (p.width - width).coerceAtLeast(0)
        val freeY = (p.height - height).coerceAtLeast(0)
        posFx = if (freeX > 0) translationX / freeX else 1f
        posFy = if (freeY > 0) translationY / freeY else 1f
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (full) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> startDrag(ev)
            MotionEvent.ACTION_MOVE -> if (!dragging && (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)) {
                dragging = true
                return true
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (full) return super.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { startDrag(ev); return true }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)) dragging = true
                if (dragging) moveTo(ev)
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) savePos() else toggleCtl()
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; return true }
        }
        return true
    }

    private fun toggleCtl() {
        h.removeCallbacks(hideCtl)
        if (miniCtl.visibility == View.VISIBLE) miniCtl.visibility = View.GONE
        else { miniCtl.visibility = View.VISIBLE; h.postDelayed(hideCtl, 3500) }
    }

    private fun keepCtl() { h.removeCallbacks(hideCtl); h.postDelayed(hideCtl, 3500) }

    // ---------- tətbiq fona keçəndə / qayıdanda ----------
    fun onBackground() {
        if (!alive) return
        resumeOnFg = !userPaused
        gen++                                   // gözləyən təkrar cəhdlər ləğv olunur
        if (engine == "vlc") vlc?.stop() else exo?.stop()
    }

    fun onForeground() {
        if (!alive || !resumeOnFg) return
        resumeOnFg = false
        if (profiles.isNotEmpty()) begin()      // canlı yayım üçün təzədən qoşulur (köhnə mövqedən yox)
    }

    fun closePlayer() {
        if (!alive) return
        alive = false
        h.removeCallbacksAndMessages(null)
        lockPortrait(false)
        releaseExo(); releaseVlc()
        (parent as? ViewGroup)?.removeView(this)
        if (inst === this) inst = null
    }

    private fun setEngine(e: String) {
        if (e == engine) return
        engine = e
        prefs.edit().putString("engine", engine).apply()
        gen++
        releaseExo(); releaseVlc()
        applyEngineViews()
        loadCurrent()
    }

    private fun applyEngineViews() {
        pv.visibility = if (engine == "exo") View.VISIBLE else View.GONE
        vl.visibility = if (engine == "vlc") View.VISIBLE else View.GONE
        val on = rounded(0xFF2563EB.toInt(), 24); val off = rounded(0x00000000, 24)
        miniEng.text = if (engine == "vlc") "VLC" else "Exo"
        engExo.background = if (engine == "exo") on else off
        engVlc.background = if (engine == "vlc") on else off
        engExo.setTextColor(if (engine == "exo") Color.WHITE else 0xFF9CA3AF.toInt())
        engVlc.setTextColor(if (engine == "vlc") Color.WHITE else 0xFF9CA3AF.toInt())
    }

    // ---------- kanal naviqasiyası ----------
    fun loadCurrent() {
        val cur = PlayQueue.items.getOrNull(PlayQueue.index) ?: return
        curName = cur.name
        nameTv.text = "${PlayQueue.index + 1}/${PlayQueue.items.size}  ${cur.name}"
        miniNameTv.text = "📺 " + cur.name
        url = cur.url
        prefs.edit().putString("lastUrl", cur.url).apply()
        profiles = Net.profiles(cur.url, cur.hdr); pIdx = 0
        msg = ""; prevAhead = -1; latency = -1; speedBps = -1; vlcBuf = 100f; vlcPlaying = false
        userPaused = false; resumeOnFg = false
        begin()
    }

    private fun step(d: Int) {
        val n = PlayQueue.items.size
        if (n == 0) return
        PlayQueue.index = (PlayQueue.index + d + n) % n
        loadCurrent()
    }

    // ---------- ortaq başlatma / xəta ----------
    private fun begin() {
        val t = profiles[pIdx]; target = t
        gen++
        val my = gen
        prevAhead = -1
        if (engine == "vlc") startVlc(t)
        else Thread {
            val hls = try { Net.isHls(t) } catch (e: Exception) { false }
            h.post { if (alive && my == gen && engine == "exo") startExo(t, hls) }
        }.start()
    }

    private fun onEngineError(d: String) {
        if (pIdx < profiles.size - 1) {
            pIdx++; msg = "🔁 Profil: ${profiles[pIdx].name} ($d)"; begin()
        } else {
            msg = "❌ $d"; pIdx = 0
            if (engine == "exo") Net.exoFail(url)   // ExoPlayer xəta mesajı verdi → siyahıda kanal 🔴
            val g = gen
            h.postDelayed({ if (alive && g == gen) begin() }, 5000)
        }
    }

    // ---------- ExoPlayer (Media3) ----------
    private fun ensureExo(): ExoPlayer {
        exo?.let { return it }
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000).setReadTimeoutMs(10000)
        val ds = ResolvingDataSource.Factory(http, ResolvingDataSource.Resolver { spec -> spec.withAdditionalHeaders(target.headers) })
        val p = ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { msg = ""; Net.markGood(target.url, target.name); Net.exoOk(url) }
            }
            override fun onPlayerError(e: PlaybackException) { onEngineError(errText(e)) }
        })
        p.addAnalyticsListener(object : AnalyticsListener {
            override fun onLoadCompleted(t: AnalyticsListener.EventTime, i: LoadEventInfo, d: MediaLoadData) {
                if (i.loadDurationMs > 0) speedBps = i.bytesLoaded * 8000 / i.loadDurationMs
            }
        })
        p.setPlaybackSpeed(speed)
        pv.player = p
        pv.resizeMode = intArrayOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM)[resizeIdx]
        exo = p
        return p
    }

    private fun startExo(t: Net.Target, hls: Boolean) {
        val p = ensureExo()
        val mi = MediaItem.Builder().setUri(t.url)
        if (hls) mi.setMimeType(MimeTypes.APPLICATION_M3U8)
        p.setMediaItem(mi.build()); p.prepare(); p.playWhenReady = true
    }

    private fun errText(e: PlaybackException): String {
        var c: Throwable? = e.cause
        var code = ""
        while (c != null) {
            if (c is HttpDataSource.InvalidResponseCodeException) { code = " HTTP " + c.responseCode; break }
            c = c.cause
        }
        return e.errorCodeName + code + (e.cause?.message?.let { " – $it" } ?: "")
    }

    private fun releaseExo() { pv.player = null; exo?.release(); exo = null }

    // ---------- LibVLC ----------
    private fun startVlc(t: Net.Target) {
        val lib = vlcLib ?: LibVLC(ctx, arrayListOf("--http-reconnect", "--network-caching=2000")).also { vlcLib = it }
        val p = vlc ?: MediaPlayer(lib).also { vp ->
            vp.attachViews(vl, null, false, false)
            vp.setEventListener(object : MediaPlayer.EventListener {
                override fun onEvent(event: MediaPlayer.Event) { onVlcEvent(event) }
            })
            vlc = vp
        }
        val m = Media(lib, Uri.parse(t.url))
        t.headers["User-Agent"]?.let { m.addOption(":http-user-agent=$it") }
        t.headers["Referer"]?.let { m.addOption(":http-referrer=$it") }
        m.addOption(":network-caching=2000")
        p.setMedia(m)
        m.release()
        p.play()
        p.setRate(speed)
        applyResize()
    }

    private fun onVlcEvent(e: MediaPlayer.Event) {
        when (e.type) {
            MediaPlayer.Event.Playing -> { vlcPlaying = true; msg = ""; Net.markGood(target.url, target.name) }
            MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> vlcPlaying = false
            MediaPlayer.Event.Buffering -> vlcBuf = e.buffering
            MediaPlayer.Event.EncounteredError -> { vlcPlaying = false; onEngineError("VLC xətası") }
            else -> {}
        }
    }

    private fun releaseVlc() {
        vlc?.let { it.setEventListener(null); it.stop(); it.detachViews(); it.release() }
        vlcLib?.release()
        vlc = null; vlcLib = null
    }

    private fun togglePause() {
        if (engine == "vlc") {
            val p = vlc ?: return
            if (p.isPlaying) { p.pause(); userPaused = true } else { p.play(); userPaused = false }
        } else {
            val p = exo ?: return
            if (p.playWhenReady) { p.pause(); userPaused = true } else { p.play(); userPaused = false }
        }
        updatePlayIcon()
    }

    private fun updatePlayIcon() {
        val playing = if (engine == "vlc") (vlc?.isPlaying == true) else (exo?.playWhenReady == true)
        val res = if (playing) R.drawable.ic_pause else R.drawable.ic_play
        if (res == lastIcon) return
        lastIcon = res
        playBtn.setImageResource(res)
        miniPlay.setImageDrawable(glowIcon(res))
    }

    private fun applyResize() {
        val st = arrayOf(MediaPlayer.ScaleType.SURFACE_BEST_FIT, MediaPlayer.ScaleType.SURFACE_FILL, MediaPlayer.ScaleType.SURFACE_FIT_SCREEN)
        vlc?.setVideoScale(st[resizeIdx])
    }

    // ---------- statistika ----------
    private fun fmt(bps: Long) = when {
        bps <= 0 -> "naməlum"; bps >= 1_000_000 -> "%.2f Mbps".format(bps / 1e6); else -> "${bps / 1000} kbps"
    }

    private fun tick() {
        if (!alive) return
        var res = "naməlum"
        var br = -1L
        val lab: String
        if (engine == "vlc") {
            val vt = vlc?.getCurrentVideoTrack()
            if (vt != null && vt.width > 0) res = "${vt.width}×${vt.height}"
            if (vt != null && vt.bitrate > 0) br = vt.bitrate.toLong()
            lab = if (!vlcPlaying) "🔴" else if (vlcBuf < 100f) "🟠" else "🟢"
        } else {
            val p = exo
            val f = p?.videoFormat
            if (f != null && f.width > 0) res = "${f.width}×${f.height}"
            if (f != null) br = (if (f.bitrate > 0) f.bitrate else f.averageBitrate).toLong()
            val ahead = p?.totalBufferedDuration ?: 0L
            lab = when {
                p == null || p.playbackState != Player.STATE_READY || ahead <= 100 -> "🔴"
                ahead < 2000 -> "🟠"
                prevAhead >= 0 && ahead - prevAhead < -200 -> "🟡"
                else -> "🟢"
            }
            prevAhead = ahead
        }
        val lat = if (latency >= 0) "$latency ms" else "naməlum"
        if (full) {
            val ready = if (engine == "vlc") vlcPlaying else (exo?.playbackState == Player.STATE_READY)
            val head = if (msg.isNotEmpty() && !ready) msg + "\n" else ""
            statsTv.text = head + "🔲 $res   ⚡ ${fmt(br)}\n🛰 $lat   ⬇ ${fmt(speedBps)}   🪣 $lab"
        } else {
            // kiçik pəncərədə eyni ölçmələr kompakt şəkildə
            miniNameTv.text = "$lab $curName"
            miniStatsTv.text = "🔲 $res  ⚡ ${fmt(br)}\n🛰 $lat  ⬇ ${fmt(speedBps)}"
        }
        updatePlayIcon()
        h.postDelayed({ tick() }, 1000)
    }

    /** Gecikmə (ilk bayta qədər) və VLC üçün təxmini endirmə sürəti; hər 6 saniyədə bir (kiçik və tam ekranda). */
    private fun probeOnce() {
        val t = target
        Thread {
            try {
                val t0 = System.nanoTime()
                val c = Net.connect(t, "bytes=0-262143", 8000)
                val s = c.inputStream
                if (s.read() >= 0) {
                    latency = (System.nanoTime() - t0) / 1_000_000
                    var total = 1L
                    val buf = ByteArray(16384)
                    while (total < 262144) { val n = s.read(buf); if (n < 0) break; total += n }
                    val ms = (System.nanoTime() - t0) / 1_000_000
                    if (engine == "vlc" && ms > 0 && total >= 65536) speedBps = total * 8000 / ms
                }
                c.disconnect()
            } catch (e: Exception) { }
        }.start()
    }

    private fun probeLoop() {
        if (!alive) return
        if (inFg()) probeOnce()
        h.postDelayed({ probeLoop() }, 6000)
    }
}
