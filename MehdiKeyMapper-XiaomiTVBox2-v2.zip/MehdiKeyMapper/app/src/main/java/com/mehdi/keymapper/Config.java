package com.mehdi.keymapper;

public final class Config {
    private Config() {}

    public static final String PACKAGE_NAME = "com.mehdi.keymapper";
    public static final String ACCESSIBILITY_CLASS = "com.mehdi.keymapper.KeyMapperAccessibilityService";
    public static final String ACCESSIBILITY_COMPONENT = PACKAGE_NAME + "/" + ACCESSIBILITY_CLASS;

    public static final String OTT_PACKAGE = "es.ottplayer.tv";
    public static final String ADB_HOST = "192.168.31.220";
    public static final int ADB_PORT = 5555;

    // 400 ms is below the usual Android key repeat delay, preserving natural taps
    // while giving the special long-press actions enough time to trigger.
    public static final long LONG_PRESS_MS = 400L;

    public static final int NOTIFICATION_ID = 21001;
    public static final String NOTIFICATION_CHANNEL = "keymapper_service";
}
