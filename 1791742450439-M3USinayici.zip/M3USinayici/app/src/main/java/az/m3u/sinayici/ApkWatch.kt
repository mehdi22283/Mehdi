package az.m3u.sinayici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.ZipFile

/** GitHub Actions: son run-u tapır, artifact zip-ini PARALEL bağlantılarla endirir, APK-nı çıxarıb quraşdırır. */
object ApkTool {
    private const val BUF = 256 * 1024
    private const val PARTS = 6

    fun clean(t: String) = t.replace(Regex("(?i)^\\s*(bearer|token)\\s+"), "").replace(Regex("[\\s\"']+"), "")

    fun epoch(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(s)?.time ?: 0L
    } catch (e: Exception) { 0L }

    private fun open(url: String, token: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 60000; c.instanceFollowRedirects = false
        c.setRequestProperty("Authorization", "Bearer " + clean(token))
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "M3USinayici")
        return c
    }

    private fun fail(code: Int, body: String): IOException {
        val msg = try { JSONObject(body).optString("message", "") } catch (e: Exception) { "" }
        return when (code) {
            401 -> IOException("Token yanlışdır və ya vaxtı bitib (401)")
            403, 404 -> IOException(msg.ifEmpty { "HTTP $code" } + " — token bu repoda Actions oxuma icazəsinə (Actions: Read) malik olmaya bilər")
            else -> IOException(msg.ifEmpty { "GitHub xətası (HTTP $code)" })
        }
    }

    private fun getJson(url: String, token: String): JSONObject {
        val c = open(url, token)
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        c.disconnect()
        if (code !in 200..299) throw fail(code, txt)
        return JSONObject(txt)
    }

    /** since>0: bu vaxtdan sonra yaranan ən yeni run; since<=0: ən son run. */
    fun latestRun(repo: String, token: String, since: Long): JSONObject? {
        val arr = getJson("https://api.github.com/repos/$repo/actions/runs?per_page=10", token).getJSONArray("workflow_runs")
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            if (since <= 0 || epoch(r.optString("created_at")) >= since) return r
        }
        return null
    }

    fun artifact(repo: String, token: String, runId: Long): JSONObject? {
        val arr = getJson("https://api.github.com/repos/$repo/actions/runs/$runId/artifacts", token).getJSONArray("artifacts")
        val list = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { !it.optBoolean("expired", false) }
        return list.firstOrNull { it.optString("name").contains("app-debug-apk", true) }
            ?: list.firstOrNull { it.optString("name").contains("apk", true) }
            ?: list.firstOrNull { it.optString("name").contains("debug", true) }
            ?: list.firstOrNull()
    }

    private fun raw(url: String, range: String?): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 30000
        c.setRequestProperty("Accept-Encoding", "identity")      // zip onsuz sıxılıb: gzip yükü yoxdur, Content-Length dəqiqdir
        c.setRequestProperty("User-Agent", "M3USinayici")
        if (range != null) c.setRequestProperty("Range", range)
        return c
    }

    /** İmzalı linki alır (token yalnız GitHub API-yə gedir, imzalı linkə yox). */
    fun resolveUrlPublic(repo: String, token: String, artifactId: Long): String {
        val c = open("https://api.github.com/repos/$repo/actions/artifacts/$artifactId/zip", token)
        val code = c.responseCode
        if (code in 300..399) {
            val loc = c.getHeaderField("Location") ?: throw IOException("Endirmə linki alınmadı")
            c.disconnect(); return loc
        }
        val body = (if (code in 200..299) "" else c.errorStream?.bufferedReader()?.readText() ?: "")
        c.disconnect()
        throw fail(code, body)
    }

    /**
     * Maksimum sürət: server Range dəstəkləyirsə fayl PARTS hissəyə bölünüb paralel endirilir,
     * yoxsa tək axınla (256 KB bufer). Hər hissə kəsilərsə qaldığı yerdən 3 dəfə davam edir.
     */
    fun fetch(url: String, hint: Long, dest: File, onProgress: (Long, Long) -> Unit) {
        dest.parentFile?.mkdirs(); if (dest.exists()) dest.delete()
        var total = -1L
        var ranges = false
        try {
            val p = raw(url, "bytes=0-0")
            val code = p.responseCode
            if (code == 206) {
                val cr = p.getHeaderField("Content-Range") ?: ""
                total = cr.substringAfter('/', "").trim().toLongOrNull() ?: -1L
                ranges = total > 0
            } else if (code in 200..299) total = p.contentLengthLong
            p.disconnect()
        } catch (e: Exception) { }
        if (total <= 0) total = hint
        val done = AtomicLong(0)
        val failed = AtomicBoolean(false)
        var err: Exception? = null
        val stop = AtomicBoolean(false)
        fun report() = onProgress(done.get(), total)

        if (ranges && total > 2L * 1024 * 1024) {
            RandomAccessFile(dest, "rw").use { it.setLength(total) }
            val part = (total + PARTS - 1) / PARTS
            val threads = (0 until PARTS).map { idx ->
                Thread {
                    val start = idx * part
                    val end = minOf(total - 1, start + part - 1)
                    var pos = start
                    var tries = 0
                    while (pos <= end && !failed.get()) {
                        try {
                            val c = raw(url, "bytes=$pos-$end")
                            if (c.responseCode != 206) throw IOException("Server hissəli endirməni rədd etdi (HTTP ${c.responseCode})")
                            RandomAccessFile(dest, "rw").use { f ->
                                f.seek(pos)
                                val buf = ByteArray(BUF)
                                c.inputStream.use { ins ->
                                    while (pos <= end) {
                                        val n = ins.read(buf, 0, minOf(buf.size.toLong(), end - pos + 1).toInt())
                                        if (n < 0) break
                                        f.write(buf, 0, n); pos += n; done.addAndGet(n.toLong())
                                    }
                                }
                            }
                            c.disconnect()
                            if (pos <= end) throw IOException("Bağlantı yarımçıq kəsildi")
                        } catch (e: Exception) {
                            if (++tries >= 3) { err = e; failed.set(true) }
                        }
                    }
                }.also { it.start() }
            }
            while (threads.any { it.isAlive }) { report(); try { Thread.sleep(300) } catch (e: InterruptedException) { } }
            report()
            if (failed.get()) throw (err ?: IOException("Endirmə uğursuz oldu"))
        } else {
            val c = raw(url, null)
            if (c.responseCode !in 200..299) throw IOException("Endirmə xətası (HTTP ${c.responseCode})")
            if (total <= 0) total = c.contentLengthLong
            var last = 0L
            c.inputStream.use { ins ->
                dest.outputStream().buffered(BUF).use { out ->
                    val buf = ByteArray(BUF)
                    while (true) {
                        val n = ins.read(buf); if (n < 0) break
                        out.write(buf, 0, n); done.addAndGet(n.toLong())
                        val now = System.currentTimeMillis()
                        if (now - last > 300) { last = now; report() }
                    }
                }
            }
            c.disconnect(); report()
        }
        if (stop.get()) throw IOException("Dayandırıldı")
    }

    /** Zip-in içindən .apk faylını (yoxdursa ilk faylı) cache/apk qovluğuna çıxarır. */
    fun extractApk(ctx: Context, zip: File): File {
        val dir = File(ctx.cacheDir, "apk"); dir.mkdirs()
        dir.listFiles()?.filter { it.name.endsWith(".apk") }?.forEach { it.delete() }
        ZipFile(zip).use { z ->
            val entries = z.entries().toList().filter { !it.isDirectory }
            val e = entries.firstOrNull { it.name.endsWith(".apk", true) }
                ?: throw IOException("Artifact içində APK tapılmadı")
            val out = File(dir, File(e.name).name)
            z.getInputStream(e).use { ins -> out.outputStream().buffered(BUF).use { ins.copyTo(it, BUF) } }
            return out
        }
    }

    fun lastApk(ctx: Context): File? =
        File(ctx.cacheDir, "apk").listFiles()?.filter { it.name.endsWith(".apk") }?.maxByOrNull { it.lastModified() }

    /** Sistem quraşdırıcısını açır. "Naməlum mənbə" icazəsi yoxdursa, əvvəlcə həmin ayar səhifəsini açır. */
    fun install(ctx: Context, apk: File): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                false
            } else {
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", apk)
                ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            }
        } catch (e: Exception) { false }
    }

    fun writeDownload(ctx: Context, name: String, w: (java.io.OutputStream) -> Unit) {
        if (Build.VERSION.SDK_INT >= 29) {
            val ext = name.substringAfterLast('.', "").lowercase()
            val mt = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: if (ext == "apk") "application/vnd.android.package-archive" else "application/octet-stream"
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mt)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            ctx.contentResolver.openOutputStream(u)!!.use(w)
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            File(dir, name).outputStream().use(w)
        }
    }
}

/** Fon xidməti: Actions-ı izləyir; hazır olanda bildiriş göndərir. Bildirişə toxunanda APK endirilir (faizlə), sonra quraşdırılır. */
class ApkWatchService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH_WORK, "APK izləmə / endirmə", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_DONE, "APK hazırdır", NotificationManager.IMPORTANCE_HIGH))
        }
        if (i?.action == ACTION_INSTALL) {           // bildirişdən "Quraşdır"
            val f = ApkTool.lastApk(this)
            if (f != null) ApkTool.install(this, f)
            nm.cancel(ID_DONE)
            stopSelf(); return START_NOT_STICKY
        }
        val repo = i?.getStringExtra("repo") ?: ""
        val token = i?.getStringExtra("token") ?: ""
        if (repo.isEmpty() || token.isEmpty()) { stopSelf(); return START_NOT_STICKY }
        when (i?.action) {
            ACTION_DL -> {
                startFg(workNotif("APK endirilir...", -1))
                val art = i.getLongExtra("artifact", 0L)
                val size = i.getLongExtra("size", 0L)
                Thread { download(nm, repo, token, art, size) }.start()
            }
            else -> {
                startFg(workNotif("Actions izlənir: build gedir...", -1))
                val since = i?.getLongExtra("since", 0L) ?: 0L
                Thread { watch(nm, repo, token, since) }.start()
            }
        }
        return START_NOT_STICKY
    }

    private fun mb(b: Long) = String.format(Locale.US, "%.1f MB", b / 1048576.0)

    private fun download(nm: NotificationManager, repo: String, token: String, art: Long, size: Long) {
        try {
            status("⬇️ Endirmə başlayır...", -1)
            val url = ApkTool.resolveUrlPublic(repo, token, art)
            val zip = File(cacheDir, "apk/artifact.zip")
            var lastPct = -1; var lastT = System.currentTimeMillis(); var lastB = 0L; var speed = 0.0
            ApkTool.fetch(url, size, zip) { done, total ->
                val now = System.currentTimeMillis()
                if (now - lastT >= 500) {
                    speed = (done - lastB) * 1000.0 / (now - lastT) / 1048576.0
                    lastT = now; lastB = done
                }
                val pct = if (total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else -1
                if (pct != lastPct) {
                    lastPct = pct
                    val txt = if (pct >= 0) "$pct% — ${mb(done)} / ${mb(total)} · " + String.format(Locale.US, "%.1f MB/s", speed)
                              else mb(done) + " endirildi"
                    nm.notify(ID_WORK, workNotif(txt, pct))
                    status("⬇️ $txt", pct)
                }
            }
            nm.notify(ID_WORK, workNotif("Açılır...", -1))
            status("📦 Zip açılır...", 100)
            val apk = ApkTool.extractApk(this, zip)
            zip.delete()
            status("✅ APK hazırdır (" + mb(apk.length()) + ") — quraşdırma açılır", 100)
            installNotif(nm, apk)
            ApkTool.install(this, apk)               // tətbiq önplandadırsa dərhal açılır; yoxsa bildirişə toxunmaq kifayətdir
            try { ApkTool.writeDownload(this, apk.name) { out -> apk.inputStream().use { it.copyTo(out, 256 * 1024) } } } catch (e: Exception) { }
        } catch (e: Exception) {
            val m = e.message ?: e.toString()
            status("❌ " + m, -1)
            done(nm, "❌ Endirmə xətası", m, null)
            return
        }
        stopForeground(true); stopSelf()
    }

    private fun installNotif(nm: NotificationManager, apk: File) {
        val inst = Intent(this, ApkWatchService::class.java).setAction(ACTION_INSTALL)
        val pi = if (Build.VERSION.SDK_INT >= 26)
            PendingIntent.getForegroundService(this, 8, inst, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        else PendingIntent.getService(this, 8, inst, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val txt = apk.name + " (" + mb(apk.length()) + ") — quraşdırmaq üçün toxunun"
        val b = builder(CH_DONE).setSmallIcon(R.drawable.ic_notif).setContentTitle("✅ APK endirildi").setContentText(txt)
            .setStyle(Notification.BigTextStyle().bigText(txt)).setAutoCancel(true).setContentIntent(pi)
        b.addAction(Notification.Action.Builder(null, "📲 Quraşdır", pi).build())
        nm.notify(ID_DONE, b.build())
    }

    private fun watch(nm: NotificationManager, repo: String, token: String, since: Long) {
        val t0 = System.currentTimeMillis()
        var errors = 0
        while (System.currentTimeMillis() - t0 < 40 * 60_000L) {
            try {
                val run = ApkTool.latestRun(repo, token, since)
                errors = 0
                if (run == null) {
                    if (System.currentTimeMillis() - t0 > 3 * 60_000L) {
                        done(nm, "⚠️ Yeni action tapılmadı", "3 dəqiqə ərzində Actions-da yeni build başlamadı.", null); return
                    }
                } else if (run.optString("status") == "completed") {
                    val concl = run.optString("conclusion")
                    if (concl != "success") { done(nm, "❌ Build uğursuz oldu", "Nəticə: $concl", null); return }
                    val art = ApkTool.artifact(repo, token, run.getLong("id"))
                    if (art == null) { done(nm, "⚠️ Build bitdi, amma APK artifact tapılmadı", "", null); return }
                    status("✅ Build hazırdır — bildirişə toxunub endirin", -1)
                    done(nm, "✅ APK hazırdır", art.optString("name") + ".zip — endirib quraşdırmaq üçün toxunun",
                        art.getLong("id"), repo, token, art.optLong("size_in_bytes", 0L)); return
                } else {
                    nm.notify(ID_WORK, workNotif("Actions izlənir: ${run.optString("status")}...", -1))
                }
            } catch (e: Exception) {
                if (++errors >= 8) { done(nm, "❌ Actions yoxlanmadı", e.message ?: e.toString(), null); return }
            }
            try { Thread.sleep(15_000) } catch (e: InterruptedException) { }
        }
        done(nm, "⚠️ Gözləmə vaxtı bitdi", "40 dəqiqə ərzində build bitmədi.", null)
    }

    private fun builder(ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else @Suppress("DEPRECATION") Notification.Builder(this)

    private fun openPi(): PendingIntent? = packageManager.getLaunchIntentForPackage(packageName)?.let {
        PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** pct >= 0: faiz çubuğu; pct < 0: qeyri-müəyyən (animasiyalı). */
    private fun workNotif(text: String, pct: Int): Notification {
        val b = builder(CH_WORK).setSmallIcon(R.drawable.ic_notif).setContentTitle(if (pct >= 0) "APK endirilir" else "APK")
            .setContentText(text).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(openPi())
        if (pct >= 0) b.setProgress(100, pct, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun startFg(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID_WORK, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(ID_WORK, n)
        } catch (e: Exception) { }
    }

    private fun done(nm: NotificationManager, title: String, text: String, art: Long?, repo: String = "", token: String = "", size: Long = 0L) {
        val b = builder(CH_DONE).setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(openPi())
        if (art != null && repo.isNotEmpty()) {
            val dl = Intent(this, ApkWatchService::class.java).setAction(ACTION_DL)
                .putExtra("repo", repo).putExtra("token", token).putExtra("artifact", art).putExtra("size", size)
            val pi = if (Build.VERSION.SDK_INT >= 26)
                PendingIntent.getForegroundService(this, 7, dl, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            else PendingIntent.getService(this, 7, dl, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.setContentIntent(pi)
            b.addAction(Notification.Action.Builder(null, "⬇️ Endir və quraşdır", pi).build())
        }
        nm.notify(ID_DONE, b.build())
        stopForeground(true)
        stopSelf()
    }

    companion object {
        const val ACTION_DL = "az.m3u.sinayici.APK_DL"
        const val ACTION_INSTALL = "az.m3u.sinayici.APK_INSTALL"
        private const val CH_WORK = "apk_work"
        private const val CH_DONE = "apk_done"
        private const val ID_WORK = 4301
        private const val ID_DONE = 4302

        /** Tətbiqin GitHub bölməsinə canlı vəziyyət (mətn, faiz) ötürür; MainActivity təyin edir. */
        @Volatile var listener: ((String, Int) -> Unit)? = null
        private fun status(t: String, pct: Int) { try { listener?.invoke(t, pct) } catch (e: Exception) { } }

        private fun go(c: Context, i: Intent) {
            try { if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i) } catch (e: Exception) { }
        }
        fun watch(c: Context, repo: String, token: String, since: Long) =
            go(c, Intent(c, ApkWatchService::class.java).putExtra("repo", repo).putExtra("token", token).putExtra("since", since))
        fun download(c: Context, repo: String, token: String, artifactId: Long, size: Long) =
            go(c, Intent(c, ApkWatchService::class.java).setAction(ACTION_DL).putExtra("repo", repo).putExtra("token", token)
                .putExtra("artifact", artifactId).putExtra("size", size))
        fun install(c: Context): Boolean = ApkTool.lastApk(c)?.let { ApkTool.install(c, it) } ?: false
    }
}
