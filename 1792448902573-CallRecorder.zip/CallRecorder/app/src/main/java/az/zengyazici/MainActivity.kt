package az.zengyazici

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private var filter = "all"
    private lateinit var list: ListView
    private var player: MediaPlayer? = null
    private var shown = listOf<File>()
    private val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE, Manifest.permission.POST_NOTIFICATIONS)

    private fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { a() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        root.addView(btn("1) Mikrofon / Telefon / Bildiriş icazələri") { requestPermissions(perms, 1) })
        root.addView(btn("2) WhatsApp zəng aşkarlama (bildiriş girişi)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        root.addView(btn("3) Batareya məhdudiyyətini söndür") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) })
        root.addView(btn("Yazıları Download/ZengYazici-yə köçür") { export() })
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("all" to "Hamısı", "in" to "Gələn", "out" to "Gedən").forEach { (k, t) ->
            rg.addView(RadioButton(this).apply { text = t; id = k.hashCode(); isChecked = k == "all"
                setOnClickListener { filter = k; refresh() } })
        }
        list = ListView(this)
        list.setOnItemClickListener { _, _, i, _ ->
            player?.release()
            player = MediaPlayer().apply { setDataSource(shown[i].absolutePath); prepare(); start() }
        }
        root.addView(rg); root.addView(list); setContentView(root)
        if (perms.all { checkSelfPermission(it) == 0 }) go() else requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { if (r.all { it == 0 }) go() }
    private fun go() { startForegroundService(Intent(this, CallService::class.java)) }
    override fun onResume() { super.onResume(); refresh() }

    private fun export() {
        var n = 0
        shown.forEach { f ->
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/ZengYazici")
            }
            contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)?.let { u ->
                contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } }; n++
            }
        }
        Toast.makeText(this, "$n fayl köçürüldü", Toast.LENGTH_SHORT).show()
    }

    private fun refresh() {
        val all = File(getExternalFilesDir(null), "calls").listFiles()?.sortedByDescending { it.name } ?: emptyList()
        shown = all.filter { filter == "all" || it.name.split("_").getOrNull(1) == filter }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, shown.map {
            val p = it.name.removeSuffix(".m4a").split("_")
            "${if (p[0] == "phone") "📞" else "💬"} ${if (p[1] == "in") "⬇ Gələn" else "⬆ Gedən"}  ${p[2].chunked(4).let { d -> d[0] + "-" + d[1].chunked(2).joinToString("-") }} ${p[3].chunked(2).joinToString(":")}"
        })
    }
}
