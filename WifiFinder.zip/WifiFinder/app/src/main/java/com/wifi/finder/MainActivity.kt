package com.wifi.finder

import android.Manifest
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

@Suppress("DEPRECATION")
class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var wifi: WifiManager
    private lateinit var sm: SensorManager
    private lateinit var prefs: SharedPreferences
    private lateinit var overlay: OverlayView
    private lateinit var graph: GraphView
    private lateinit var preview: PreviewView
    private lateinit var distText: TextView
    private lateinit var infoText: TextView
    private lateinit var hintText: TextView
    private lateinit var btnAr: Button
    private lateinit var btnSound: Button
    private lateinit var btnModel: Button
    private val handler = Handler(Looper.getMainLooper())

    private var targetBssid: String? = null
    private var targetSsid = ""
    private var targetFreq = 2437
    private var ema: Double? = null
    private val history = ArrayList<Float>()
    private val trend = ArrayList<Pair<Long, Double>>()
    private val binVal = DoubleArray(36)
    private val binCnt = IntArray(36)
    private var heading = 0f
    private var headingInit = false
    private var bestBearing = Float.NaN
    private var lastDist = Double.NaN

    private var txAt1m = -40.0
    private var nExp = 2.7
    private var useFspl = false
    private var sound = false
    private var arMode = false
    private var wantAr = false
    private var tone: ToneGenerator? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res[Manifest.permission.CAMERA] == true && wantAr) {
                wantAr = false
                setAr(true)
            }
            if (targetBssid == null) autoPickConnected()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        loadPrefs()
        buildUi()
        requestBasePerms()
        if (targetBssid == null) autoPickConnected()
        refreshUi()
    }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 11f; isAllCaps = false
        setOnClickListener { f() }
    }

    private fun row(vararg b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setBackgroundColor(Color.parseColor("#101820"))
        b.forEach { addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        preview = PreviewView(this)
        preview.visibility = View.GONE
        root.addView(preview, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        distText = TextView(this).apply {
            textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#101820"))
            setPadding(dp(8), dp(30), dp(8), dp(4))
        }
        col.addView(distText, LinearLayout.LayoutParams(-1, -2))

        overlay = OverlayView(this)
        overlay.setBackgroundColor(Color.parseColor("#101820"))
        col.addView(overlay, LinearLayout.LayoutParams(-1, 0, 1f))

        hintText = TextView(this).apply {
            textSize = 14f; setTextColor(Color.parseColor("#FFD54F")); gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#101820")); setPadding(dp(8), dp(4), dp(8), dp(2))
        }
        col.addView(hintText, LinearLayout.LayoutParams(-1, -2))

        infoText = TextView(this).apply {
            textSize = 12f; setTextColor(Color.parseColor("#B0BEC5")); gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#101820")); setPadding(dp(8), dp(2), dp(8), dp(4))
        }
        col.addView(infoText, LinearLayout.LayoutParams(-1, -2))

        graph = GraphView(this)
        col.addView(graph, LinearLayout.LayoutParams(-1, dp(80)))

        btnAr = btn("") { toggleAr() }
        btnSound = btn("") { sound = !sound; savePrefs(); updateButtons() }
        btnModel = btn("") { useFspl = !useFspl; savePrefs(); updateButtons(); refreshUi() }

        col.addView(row(
            btn("📶 Şəbəkə seç") { showPicker() },
            btnAr,
            btnSound,
            btn("🔄 Sıfırla") { clearData() }
        ))
        col.addView(row(
            btn("🎯 Kalibrə (1m)") { calibrate() },
            btn("n −") { nExp = max(1.5, ((nExp - 0.1) * 10).roundToInt() / 10.0); savePrefs(); refreshUi() },
            btn("n +") { nExp = minOf(4.0, ((nExp + 0.1) * 10).roundToInt() / 10.0); savePrefs(); refreshUi() },
            btnModel
        ))
        updateButtons()
        setContentView(root)
    }

    private fun updateButtons() {
        btnAr.text = if (arMode) "🧭 Kompas" else "📷 AR"
        btnSound.text = if (sound) "🔊 Səs: ON" else "🔇 Səs: OFF"
        btnModel.text = if (useFspl) "Model: FSPL" else "Model: Log"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- Permissions ----------
    private fun hasLoc() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestBasePerms() {
        val need = ArrayList<String>()
        need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        val missing = need.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    // ---------- AR / camera ----------
    private fun toggleAr() {
        if (!arMode) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                wantAr = true
                permLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                return
            }
            setAr(true)
        } else setAr(false)
    }

    private fun setAr(on: Boolean) {
        arMode = on
        overlay.ar = on
        overlay.setBackgroundColor(if (on) Color.TRANSPARENT else Color.parseColor("#101820"))
        preview.visibility = if (on) View.VISIBLE else View.GONE
        if (on) startCamera() else stopCamera()
        updateButtons()
        overlay.invalidate()
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                val p = f.get()
                val pv = Preview.Builder().build()
                pv.setSurfaceProvider(preview.surfaceProvider)
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv)
            } catch (e: Exception) {
                toast("Kamera açılmadı")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try { f.get().unbindAll() } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(this))
    }

    // ---------- Prefs ----------
    private fun loadPrefs() {
        txAt1m = prefs.getFloat("tx", -40f).toDouble()
        nExp = prefs.getFloat("n", 2.7f).toDouble()
        useFspl = prefs.getBoolean("fspl", false)
        sound = prefs.getBoolean("sound", false)
        targetBssid = prefs.getString("bssid", null)
        targetSsid = prefs.getString("ssid", "") ?: ""
        targetFreq = prefs.getInt("freq", 2437)
    }

    private fun savePrefs() {
        prefs.edit()
            .putFloat("tx", txAt1m.toFloat())
            .putFloat("n", nExp.toFloat())
            .putBoolean("fspl", useFspl)
            .putBoolean("sound", sound)
            .putString("bssid", targetBssid)
            .putString("ssid", targetSsid)
            .putInt("freq", targetFreq)
            .apply()
    }

    // ---------- Target selection ----------
    private fun showPicker() {
        if (!hasLoc()) {
            requestBasePerms(); toast("Məkan icazəsi verin"); return
        }
        try { wifi.startScan() } catch (_: Exception) {}
        val list: List<ScanResult> = try { wifi.scanResults } catch (e: SecurityException) { emptyList() }
        val items = list.filter { it.BSSID != null }
            .groupBy { it.BSSID }.map { it.value.first() }
            .sortedByDescending { it.level }
        if (items.isEmpty()) {
            toast("Şəbəkə tapılmadı. Məkan (GPS) xidmətini açın"); return
        }
        val labels = items.map {
            val n = if (it.SSID.isNullOrEmpty()) "(gizli)" else it.SSID
            "$n\n${it.level} dBm • ${it.frequency} MHz"
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("WiFi seçin")
            .setItems(labels) { _, i -> selectTarget(items[i]) }.show()
    }

    private fun selectTarget(r: ScanResult) {
        targetBssid = r.BSSID
        targetSsid = if (r.SSID.isNullOrEmpty()) "(gizli)" else r.SSID
        targetFreq = r.frequency
        clearData()
        savePrefs()
        processSample(r.level)
    }

    private fun autoPickConnected() {
        if (!hasLoc()) return
        try {
            val i = wifi.connectionInfo ?: return
            val b = i.bssid ?: return
            if (i.networkId == -1 || b.startsWith("02:00:00")) return
            targetBssid = b
            targetSsid = (i.ssid ?: "").trim('"')
            targetFreq = i.frequency
            savePrefs()
        } catch (_: SecurityException) {}
    }

    private fun isConnectedTo(b: String) = try {
        wifi.connectionInfo?.bssid.equals(b, true)
    } catch (_: SecurityException) { false }

    private fun clearData() {
        ema = null
        history.clear(); trend.clear()
        binVal.fill(0.0); binCnt.fill(0)
        bestBearing = Float.NaN
        lastDist = Double.NaN
        overlay.rel = Float.NaN
        refreshUi()
    }

    private fun calibrate() {
        val e = ema
        if (e == null) { toast("Əvvəl WiFi seçin"); return }
        txAt1m = e
        useFspl = false
        savePrefs(); updateButtons(); refreshUi()
        toast("Kalibrə edildi: 1 m = ${e.roundToInt()} dBm")
    }

    // ---------- Signal processing ----------
    private fun processSample(raw: Int) {
        val e = ema?.let { it * 0.7 + raw * 0.3 } ?: raw.toDouble()
        ema = e
        history.add(e.toFloat()); if (history.size > 90) history.removeAt(0)
        trend.add(SystemClock.elapsedRealtime() to e); if (trend.size > 40) trend.removeAt(0)
        if (headingInit) {
            val b = (heading / 10f).toInt().coerceIn(0, 35)
            binVal[b] = if (binCnt[b] == 0) raw.toDouble() else binVal[b] * 0.5 + raw * 0.5
            binCnt[b]++
            computeBest()
        }
        refreshUi()
    }

    private fun computeBest() {
        var filled = 0
        for (i in 0 until 36) if (binCnt[i] > 0) filled++
        if (filled < 3) { bestBearing = Float.NaN; return }
        var bestI = -1
        var bestS = -1e9
        for (i in 0 until 36) {
            if (binCnt[i] == 0) continue
            var s = binVal[i] * 2.0
            var w = 2.0
            val l = (i + 35) % 36
            val r = (i + 1) % 36
            if (binCnt[l] > 0) { s += binVal[l]; w += 1.0 }
            if (binCnt[r] > 0) { s += binVal[r]; w += 1.0 }
            val sc = s / w
            if (sc > bestS) { bestS = sc; bestI = i }
        }
        bestBearing = bestI * 10f + 5f
    }

    private fun distanceOf(rssi: Double): Double {
        val d = if (useFspl)
            10.0.pow((15.0 - rssi + 27.55 - 20.0 * log10(targetFreq.toDouble())) / 20.0)
        else
            10.0.pow((txAt1m - rssi) / (10.0 * nExp))
        return d.coerceIn(0.1, 200.0)
    }

    private fun fmt(d: Double) = if (d < 10) String.format("%.1f", d) else String.format("%.0f", d)

    private fun channel(f: Int) = when {
        f == 2484 -> 14
        f in 2412..2472 -> (f - 2407) / 5
        f in 5160..5885 -> (f - 5000) / 5
        f in 5955..7115 -> (f - 5950) / 5
        else -> 0
    }

    private fun refreshUi() {
        if (!::distText.isInitialized) return
        val e = ema
        if (e == null || targetBssid == null) {
            distText.text = "WiFi seçin"
            hintText.text = "«📶 Şəbəkə seç» düyməsinə basın"
            infoText.text = ""
            graph.data = emptyList(); graph.invalidate()
            overlay.label = ""; overlay.ssid = ""; overlay.invalidate()
            return
        }
        val d = distanceOf(e)
        lastDist = d
        val dt = "≈ ${fmt(d)} m"
        distText.text = dt
        overlay.label = dt
        overlay.ssid = targetSsid

        val now = SystemClock.elapsedRealtime()
        val old = trend.lastOrNull { now - it.first >= 3000 }
        val tr = if (old == null) "" else {
            val delta = e - old.second
            if (delta > 1.5) "🔥 İsti – yaxınlaşırsan"
            else if (delta < -1.5) "❄ Soyuq – uzaqlaşırsan"
            else "➡ Sabit"
        }
        val dir = if (bestBearing.isNaN()) "Telefonla yavaş 360° dönün" else "Ox ən güclü siqnalı göstərir"
        hintText.text = if (d < 1.0) "✅ Tapıldı! Router çox yaxındadır" else "$tr\n$dir".trim()

        infoText.text = "$targetSsid • ${e.roundToInt()} dBm • ${targetFreq} MHz • kanal ${channel(targetFreq)}\n" +
            "n=${"%.1f".format(nExp)} • 1 m-də ${txAt1m.roundToInt()} dBm"
        graph.data = history.toList()
        graph.invalidate()
        overlay.invalidate()
    }

    // ---------- Loops ----------
    private val fastRun = object : Runnable {
        override fun run() {
            if (targetBssid == null) autoPickConnected()
            val tb = targetBssid
            if (tb != null) {
                try {
                    val info = wifi.connectionInfo
                    if (info != null && info.bssid.equals(tb, true) && info.rssi > -127) {
                        targetFreq = info.frequency
                        processSample(info.rssi)
                    }
                } catch (_: SecurityException) {}
            }
            handler.postDelayed(this, 400)
        }
    }

    private val scanRun = object : Runnable {
        override fun run() {
            val tb = targetBssid
            if (tb != null && hasLoc() && !isConnectedTo(tb)) {
                try { wifi.startScan() } catch (_: Exception) {}
            }
            handler.postDelayed(this, 4000)
        }
    }

    private val soundRun = object : Runnable {
        override fun run() {
            val d = lastDist
            var delay = 800L
            if (sound && !d.isNaN() && ema != null) {
                try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 50) } catch (_: Exception) {}
                if (d < 1.0) vibrateShort()
                delay = (d * 250).toLong().coerceIn(150L, 2000L)
            }
            handler.postDelayed(this, delay)
        }
    }

    private fun vibrateShort() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        v?.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val tb = targetBssid ?: return
            try {
                val r = wifi.scanResults.firstOrNull { it.BSSID.equals(tb, true) } ?: return
                targetFreq = r.frequency
                if (!isConnectedTo(tb)) processSample(r.level)
            } catch (_: SecurityException) {}
        }
    }

    // ---------- Lifecycle ----------
    override fun onResume() {
        super.onResume()
        val s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (s == null) toast("Cihazda kompas sensoru yoxdur")
        else sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
        ContextCompat.registerReceiver(
            this, scanReceiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        try { tone = ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Exception) {}
        handler.post(fastRun); handler.post(scanRun); handler.post(soundRun)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacksAndMessages(null)
        sm.unregisterListener(this)
        try { unregisterReceiver(scanReceiver) } catch (_: Exception) {}
        tone?.release(); tone = null
    }

    // ---------- Compass ----------
    override fun onSensorChanged(event: SensorEvent) {
        val rm = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(rm, event.values)
        val rm2 = FloatArray(9)
        if (abs(rm[8]) < 0.7f) {
            SensorManager.remapCoordinateSystem(rm, SensorManager.AXIS_X, SensorManager.AXIS_Z, rm2)
        } else {
            System.arraycopy(rm, 0, rm2, 0, 9)
        }
        val o = FloatArray(3)
        SensorManager.getOrientation(rm2, o)
        var az = Math.toDegrees(o[0].toDouble()).toFloat()
        if (az < 0) az += 360f
        if (!headingInit) {
            heading = az; headingInit = true
        } else {
            val diff = ((az - heading + 540f) % 360f) - 180f
            heading = (heading + diff * 0.2f + 360f) % 360f
        }
        overlay.heading = heading
        overlay.rel = if (bestBearing.isNaN()) Float.NaN else ((bestBearing - heading + 540f) % 360f) - 180f
        overlay.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
