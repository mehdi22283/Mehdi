package az.yvok

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {

    private val URL = "https://gpp.yelo.az/search-to-pay/db6ed060-63f2-4085-88eb-c2f8fdb05b40"
    private val PREFIX = "10011"

    private lateinit var input: EditText
    private lateinit var tvPayer: TextView
    private lateinit var tvYvok: TextView
    private lateinit var tvAmount: TextView
    private lateinit var tvStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var web: WebView
    private var currentCode = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }

        input = EditText(this).apply {
            hint = "7 simvol yazın"
            textSize = 22f
            filters = arrayOf(InputFilter.LengthFilter(7))
            setSingleLine()
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2))

        progress = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(dp(36), dp(36)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12)
        })

        tvStatus = TextView(this).apply { textSize = 14f; setTextColor(0xFF888888.toInt()) }
        root.addView(tvStatus, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        tvPayer = resultView(root, "Ödəyən")
        tvYvok = resultView(root, "YVÖK")
        tvAmount = resultView(root, "Məbləğ (AZN)")
        tvAmount.textSize = 28f
        tvAmount.setTypeface(null, Typeface.BOLD)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                if (currentCode.isNotEmpty()) {
                    view.evaluateJavascript(JS.replace("__CODE__", currentCode), null)
                }
            }
        }
        // 1dp-lik görünməz WebView (JS işləsin deyə)
        root.addView(web, LinearLayout.LayoutParams(dp(1), dp(1)))
        setContentView(root)

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val t = s?.toString().orEmpty()
                if (t.length == 7) {
                    search(PREFIX + t)
                } else {
                    currentCode = ""
                    clearResults()
                }
            }
        })
    }

    private fun resultView(root: LinearLayout, label: String): TextView {
        val l = TextView(this).apply { text = label; textSize = 12f; setTextColor(0xFF888888.toInt()) }
        root.addView(l, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        val v = TextView(this).apply { textSize = 20f; text = "—"; setTextColor(0xFF111111.toInt()) }
        root.addView(v, LinearLayout.LayoutParams(-1, -2))
        return v
    }

    private fun clearResults() {
        tvPayer.text = "—"; tvYvok.text = "—"; tvAmount.text = "—"
        tvStatus.text = ""; progress.visibility = View.GONE
    }

    private fun search(code: String) {
        currentCode = code
        clearResults()
        tvYvok.text = code
        tvStatus.text = "Axtarılır..."
        progress.visibility = View.VISIBLE
        web.loadUrl(URL)
    }

    inner class Bridge {
        @JavascriptInterface
        fun onResult(code: String, payer: String, yvok: String, amount: String, err: String) {
            runOnUiThread {
                if (code != currentCode) return@runOnUiThread
                progress.visibility = View.GONE
                if (err.isNotEmpty()) {
                    tvStatus.text = err
                    return@runOnUiThread
                }
                tvStatus.text = ""
                tvPayer.text = payer.ifEmpty { "—" }
                tvYvok.text = yvok.ifEmpty { code }
                var v = amount.replace(",", ".").trim().toDoubleOrNull() ?: 0.0
                if (v < 0) v = 0.0 // mənfi dəyər 0 kimi qəbul olunur
                tvAmount.text = String.format(Locale.US, "%.2f", v)
            }
        }
    }

    private val JS = """
(function(code){
  window.__sent = false;
  var tries = 0, field = null;
  var iv = setInterval(function(){
    tries++;
    if (tries > 120) { clearInterval(iv); Android.onResult(code,'','','','Cavab alınmadı (vaxt bitdi)'); return; }
    if (!window.__sent) {
      var inputs = [].slice.call(document.querySelectorAll('input')).filter(function(i){
        var t = (i.type||'text').toLowerCase();
        return !i.readOnly && !i.disabled && i.offsetParent !== null &&
          (t==='text'||t==='search'||t==='tel'||t==='number');
      });
      if (!inputs.length) return;
      var f = inputs[0];
      for (var k=0;k<inputs.length;k++){
        var h = ((inputs[k].placeholder||'')+(inputs[k].name||'')+(inputs[k].id||'')+(inputs[k].getAttribute('aria-label')||'')).toLowerCase();
        if (h.indexOf('yv')>=0 || h.indexOf('code')>=0) { f = inputs[k]; break; }
      }
      field = f;
      var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
      f.focus(); setter.call(f, code);
      f.dispatchEvent(new Event('input',{bubbles:true}));
      f.dispatchEvent(new Event('change',{bubbles:true}));
      var btns = [].slice.call(document.querySelectorAll('button,input[type=submit],input[type=button],[role=button],a.btn'));
      var b = null;
      for (var j=0;j<btns.length;j++){
        var t = ((btns[j].innerText||btns[j].value||'')+'').toLowerCase();
        if (t.indexOf('axtar')>=0) { b = btns[j]; break; }
      }
      if (!b) { for (var j2=0;j2<btns.length;j2++){ if ((btns[j2].type||'')==='submit'){ b=btns[j2]; break; } } }
      if (b && !b.disabled) { b.click(); window.__sent = true; }
      return;
    }
    var txt = document.body.innerText || '';
    var pm = txt.match(/Ödəyən\s*:?\s*([^\n]+)/i);
    if (!pm || txt.indexOf(code) < 0) return;
    var amount = null, all = document.querySelectorAll('input');
    for (var a=0;a<all.length;a++){
      var el = all[a];
      if (el === field) continue;
      var val = (el.value||'').trim();
      if (!/^-?\d+([.,]\d+)?$/.test(val) || val === code) continue;
      var p = el, hit = false;
      for (var d=0; d<4 && p; d++){ p = p.parentElement; if (p && (p.innerText||'').toLowerCase().indexOf('məbləğ')>=0){ hit = true; break; } }
      if (hit) { amount = val; break; }
      if (amount === null) amount = val;
    }
    if (amount === null) return;
    clearInterval(iv);
    Android.onResult(code, pm[1].trim(), code, amount, '');
  }, 250);
})('__CODE__');
"""
}
