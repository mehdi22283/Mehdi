package az.market.endirim

import android.content.Context
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Bravo üçün istifadəçinin özünün yüklədiyi PDF.
 * PDF yüklənəndə slaydın (WebView) yerinə keçir; endirim günü bitəndə
 * (və ya Bravo yeni slayd linki verəndə) silinir və slayd yenidən açılır.
 */
object BravoManual {
    const val MARKET = "Bravo Market"
    private const val SCHEME = "file://"

    private fun dir(ctx: Context) = File(ctx.filesDir, "bravo").apply { mkdirs() }
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("bravopdf", Context.MODE_PRIVATE)

    private fun file(ctx: Context): File? =
        prefs(ctx).getString("name", null)?.let { File(dir(ctx), it) }?.takeIf { it.exists() && it.length() > 0 }

    /** Yüklənmiş PDF-in linki ("file://..."), yoxdursa null. */
    fun url(ctx: Context): String? = file(ctx)?.let { SCHEME + it.path }

    fun isLocal(url: String) = url.startsWith(SCHEME)

    fun localFile(url: String) = File(url.removePrefix(SCHEME))

    /** PDF-i seçilmiş fayldan kopyalayır və yoxlayır. Uğurlu olarsa yeni fayl qaytarılır. */
    suspend fun save(ctx: Context, uri: Uri, slideUrl: String?): File? = withContext(Dispatchers.IO) {
        val name = "bravo_${System.currentTimeMillis()}.pdf"
        val f = File(dir(ctx), name)
        try {
            val input = ctx.contentResolver.openInputStream(uri) ?: return@withContext null
            input.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            // həqiqətən PDF-dirmi?
            ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                val r = PdfRenderer(pfd)
                try { if (r.pageCount < 1) throw IllegalStateException("boş PDF") } finally { r.close() }
            }
        } catch (e: Exception) {
            f.delete()
            return@withContext null
        }
        val p = prefs(ctx)
        p.getString("name", null)?.let { File(dir(ctx), it).delete() }   // köhnə PDF silinir
        p.edit().putString("name", name).putString("slide", slideUrl).remove("date").apply()
        f
    }

    fun setDate(ctx: Context, date: String?) {
        prefs(ctx).edit().apply { if (date != null) putString("date", date) else remove("date") }.apply()
    }

    fun slideUrl(ctx: Context): String? = prefs(ctx).getString("slide", null)

    fun clear(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
        prefs(ctx).edit().clear().apply()
    }

    /** Yüklənmiş PDF-dən jurnal (slaydın yerinə keçən). */
    fun catalog(ctx: Context, fallbackDate: String?): Catalog? {
        val u = url(ctx) ?: return null
        return Catalog(MARKET, "Endirim jurnalı", prefs(ctx).getString("date", null) ?: fallbackDate, Kind.PDF, listOf(u), "PDF (əl ilə)")
    }

    /**
     * Sayt nəticəsinə tətbiq edir: etibarlı PDF varsa slaydın yerinə qoyur.
     * Endirim günü bitibsə və ya Bravo yeni slayd linki veribsə PDF silinir, slayd qalır.
     */
    fun apply(ctx: Context, fresh: List<Catalog>): List<Catalog> {
        if (url(ctx) == null) return fresh
        val slide = fresh.firstOrNull { it.kind == Kind.WEB }
        val saved = slideUrl(ctx)
        val linkChanged = slide != null && saved != null && slide.urls[0] != saved
        val cat = catalog(ctx, null)
        val expired = cat?.date?.let { DateUtil.info(it).state == 4 } == true
        if (cat == null || linkChanged || expired) {
            clear(ctx)
            return fresh
        }
        return listOf(cat)
    }
}
