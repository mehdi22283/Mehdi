package az.zengyazi

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Boş köməkçi xidmət. Heç bir ekran məzmunu oxumur.
 * Yeganə məqsədi: Xiaomi/MIUI-nin tətbiqi arxa fonda öldürməsinin və
 * mikrofonu bağlamasının qarşısını almağa kömək etməkdir.
 */
class HelperService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
