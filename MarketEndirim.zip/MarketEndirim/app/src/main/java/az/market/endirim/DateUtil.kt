package az.market.endirim

object DateUtil {
    private const val MONTHS = "yanvar|fevral|mart|aprel|may|iyun|iyul|avqust|sentyabr|oktyabr|noyabr|dekabr"
    private val IC = RegexOption.IGNORE_CASE

    private val full = Regex("""(\d{1,2})[./](\d{1,2})[./](\d{2,4})\s*[-–—]\s*(\d{1,2})[./](\d{1,2})[./](\d{2,4})""")
    private val NAMES = listOf("yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avqust", "sentyabr", "oktyabr", "noyabr", "dekabr")

    private fun fullYear(s: String): Int = if (s.length == 2) 2000 + s.toInt() else s.toInt()
    private val twoMonths = Regex("""(\d{1,2})\s*($MONTHS)\s*[-–—]\s*(\d{1,2})\s*($MONTHS)""", IC)
    private val oneMonth = Regex("""(\d{1,2})\s*[-–—_~]\s*(\d{1,2})\s*\(?\s*($MONTHS)""", IC)
    private val until = Regex("""(\d{1,2})\s*($MONTHS)\s*(?:adək|ədək|dək|qədər)""", IC)

    private val nameTwo = Regex("""(\d{1,2}) ($MONTHS) (\d{1,2}) ($MONTHS)""")
    private val nameOne = Regex("""(\d{1,2}) (\d{1,2}) ($MONTHS)""")

    /** Mətndən endirim tarixini tapır (səhifə mətni, slayd altındakı yazı, OCR). */
    fun find(text: String): String? {
        val t = text.replace('\u00A0', ' ')
        full.find(t)?.let {
            val g = it.groupValues
            val d1 = g[1].toInt(); val m1 = g[2].toInt(); val y1 = fullYear(g[3])
            val d2 = g[4].toInt(); val m2 = g[5].toInt(); val y2 = fullYear(g[6])
            if (m1 in 1..12 && m2 in 1..12) {
                val a = "$d1 ${NAMES[m1 - 1]}"
                val b = "$d2 ${NAMES[m2 - 1]}"
                return if (y1 == y2) "$a - $b $y2" else "$a $y1 - $b $y2"
            }
            return it.value.replace(Regex("""\s+"""), " ")
        }
        twoMonths.find(t)?.let {
            val g = it.groupValues
            return "${g[1]} ${g[2].lowercase()} - ${g[3]} ${g[4].lowercase()}"
        }
        oneMonth.find(t)?.let {
            val g = it.groupValues
            return "${g[1]}-${g[2]} ${g[3].lowercase()}"
        }
        until.find(t)?.let {
            val g = it.groupValues
            return "${g[1]} ${g[2].lowercase()} tarixinədək"
        }
        return null
    }

    /** Fayl adından, məs: 19-sentyabr_2-oktyabr  və ya  rahat_market_15_20_sentyabr */
    fun fromFileName(name: String): String? {
        val n = name.lowercase().replace('_', ' ').replace('-', ' ')
        nameTwo.find(n)?.let {
            val g = it.groupValues
            return "${g[1]} ${g[2]} - ${g[3]} ${g[4]}"
        }
        nameOne.find(n)?.let {
            val g = it.groupValues
            return "${g[1]}-${g[2]} ${g[3]}"
        }
        return null
    }

    // ---------- oxunaqlı göstəriş ----------
    /** state: 0 = status yoxdur, 1 = aktiv, 2 = tezliklə bitir, 3 = tezliklə başlayır, 4 = bitib */
    data class Info(val label: String, val status: String?, val state: Int, val endMs: Long = 0L)

    private val rangeRe = Regex("""(\d{1,2})\s+($MONTHS)(?:\s+(\d{4}))?\s*[-–—]\s*(\d{1,2})\s+($MONTHS)(?:\s+(\d{4}))?""", IC)
    private val sameMonthRe = Regex("""(\d{1,2})\s*[-–—]\s*(\d{1,2})\s+($MONTHS)(?:\s+(\d{4}))?""", IC)
    private val untilRe = Regex("""(\d{1,2})\s+($MONTHS)(?:\s+(\d{4}))?\s+tarixinədək""", IC)

    private fun cal(y: Int, m0: Int, d: Int): java.util.Calendar =
        java.util.Calendar.getInstance().apply { clear(); set(y, m0, d) }

    private fun mi(name: String) = NAMES.indexOf(name.lowercase())

    private fun daysBetween(a: java.util.Calendar, b: java.util.Calendar): Int =
        Math.round((b.timeInMillis - a.timeInMillis) / 86_400_000.0).toInt()

    private fun daysWord(n: Int) = "$n gün"

    /** "15 sentyabr - 20 oktyabr" → "15 sentyabr – 20 oktyabr" + "Aktivdir · 7 gün qalıb" */
    fun info(raw: String): Info {
        val t = raw.replace('\u00A0', ' ').trim()
        val now = java.util.Calendar.getInstance()
        val today = cal(now.get(java.util.Calendar.YEAR), now.get(java.util.Calendar.MONTH), now.get(java.util.Calendar.DAY_OF_MONTH))
        val cur = today.get(java.util.Calendar.YEAR)

        var start: java.util.Calendar? = null
        var end: java.util.Calendar? = null
        var label: String? = null

        rangeRe.find(t)?.let {
            val g = it.groupValues
            val sd = g[1].toInt(); val sm = mi(g[2]); val ed = g[4].toInt(); val em = mi(g[5])
            var ys = g[3].toIntOrNull(); var ye = g[6].toIntOrNull()
            if (ys == null && ye == null) {
                if (em < sm) { if (today.get(java.util.Calendar.MONTH) <= em) { ys = cur - 1; ye = cur } else { ys = cur; ye = cur + 1 } }
                else { ys = cur; ye = cur }
            } else if (ys == null) {
                ys = if (sm > em) ye!! - 1 else ye
            } else if (ye == null) {
                ye = if (em < sm) ys + 1 else ys
            }
            start = cal(ys!!, sm, sd); end = cal(ye!!, em, ed)
            val yr = g[6].ifEmpty { g[3] }
            label = "$sd ${NAMES[sm]} – $ed ${NAMES[em]}" + if (yr.isNotEmpty()) " $yr" else ""
        } ?: sameMonthRe.find(t)?.let {
            val g = it.groupValues
            val sd = g[1].toInt(); val ed = g[2].toInt(); val m = mi(g[3])
            val y = g[4].toIntOrNull() ?: cur
            start = cal(y, m, sd); end = cal(y, m, ed)
            label = "$sd–$ed ${NAMES[m]}" + if (g[4].isNotEmpty()) " ${g[4]}" else ""
        } ?: untilRe.find(t)?.let {
            val g = it.groupValues
            val ed = g[1].toInt(); val m = mi(g[2])
            end = cal(g[3].toIntOrNull() ?: cur, m, ed)
            label = "$ed ${NAMES[m]} tarixinədək"
        }

        val e = end ?: return Info(t, null, 0)
        val s = start
        val lbl = label ?: t
        if (s != null && today.before(s)) {
            val d = daysBetween(today, s)
            return Info(lbl, if (d == 1) "Sabah başlayır" else "${daysWord(d)} sonra başlayır", 3, e.timeInMillis)
        }
        if (!today.after(e)) {
            val d = daysBetween(today, e)
            return when (d) {
                0 -> Info(lbl, "Aktivdir · bu gün bitir", 2, e.timeInMillis)
                1 -> Info(lbl, "Aktivdir · sabah bitir", 2, e.timeInMillis)
                2, 3 -> Info(lbl, "Aktivdir · ${daysWord(d)} qalıb", 2, e.timeInMillis)
                else -> Info(lbl, "Aktivdir · ${daysWord(d)} qalıb", 1, e.timeInMillis)
            }
        }
        return Info(lbl, "Müddəti bitib", 4, e.timeInMillis)
    }

    fun stateColor(state: Int): Int = when (state) {
        1 -> 0xFF43A047.toInt()
        2 -> 0xFFF57C00.toInt()
        3 -> 0xFF1E88E5.toInt()
        4 -> 0xFFE53935.toInt()
        else -> 0xFF607D8B.toInt()
    }
}
