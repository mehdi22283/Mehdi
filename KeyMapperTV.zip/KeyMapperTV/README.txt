1) Build APK (GitHub Actions ve ya Android Studio).
2) TV-de: Ayarlar > Cihaz > Developer options > USB debugging ve Network/ADB debugging (port 5555) aciq olsun.
3) Tetbiqi acin -> "ADB ile qosul" (ilk defe TV-de "Always allow" secin).
   Qosulanda elcatimliliq xidmeti avtomatik ADB ile aktiv olunur, ayarlara girmek lazim deyil.
4) Duymeleri tetbiqin daxilinde elave/redakte/sil ede bilersiniz.
