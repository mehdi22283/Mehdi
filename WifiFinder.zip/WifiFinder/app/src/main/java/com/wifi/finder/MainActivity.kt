package com.wifi.finder

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

@SuppressLint("NewApi")
@Suppress("DEPRECATION")
class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var wifi: WifiManager
    private lateinit var sm: SensorManager
    private lateinit var prefs: SharedPreferences
    private lateinit var overlay: OverlayView
    private lateinit var graph: GraphView
    private lateinit var preview: PreviewView
    private lateinit var distText: TextView
    private lateinit var infoText: TextView
    private lateinit var hintText: TextView
    private lateinit var btnAr: Button
    private lateinit var btnSound: Button
    private val handler = Handler(Looper.getMainLooper())

    private var targetBssid: String? = null
    private var targetSsid = ""
    private var targetFreq = 2437
    private var ema: Double? = null
    private val history = ArrayList<Float>()
    private val trend = ArrayList<Pair<Long, Double>>()
    private val binVal = DoubleArray(36)
    private val binCnt = IntArray(36)
    private val binTime = LongArray(36)
    private var heading = 0f
    private var headingInit = false
    private var bestBearing = Float.NaN
    private var dispBearing = Float.NaN
    private var lastDist = Double.NaN

    // Bütün şəbəkələr + RTT
    private val nets = HashMap<String, Net>()
    private var netArr: List<Net> = emptyList()
    private var lastScan: List<ScanResult> = emptyList()
    private var rttHelper: RttHelper? = null
    private var rttStatus = ""
    private var rttBusySince = 0L

    private var txAt1m = -40.0
    private var nExp = 2.7
    private var useFspl = false
    private var sound = false
    private var arMode = false
    private var wantAr = false
    private var tone: ToneGenerator? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res[Manifest.permission.CAMERA] == true && wantAr) {
                wantAr = false
                setAr(true)
            }
            if (targetBssid == null) autoPickConnected()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        loadPrefs()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_RTT)
        ) rttHelper = RttHelper(this)
        rttStatus = if (rttHelper == null) "RTT: cihaz dəstəkləmir" else "RTT: hazırlanır..."
        buildUi()
        requestBasePerms()
        if (targetBssid == null) autoPickConnected()
        refreshUi()
    }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 11f; isAllCaps = false
        setOnClickListener { f() }
    }

    private fun row(vararg b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setBackgroundColor(Color.parseColor("#101820"))
        b.forEach { addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        preview = PreviewView(this)
        preview.visibility = View.GONE
        root.addView(preview, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        distText = TextView(this).apply {
            textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#101820"))
            setPadding(dp(8), dp(30), dp(8), dp(4))
        }
        col.addView(distText, LinearLayout.LayoutParams(-1, -2))

        overlay = OverlayView(this)
        overlay.setBackgroundColor(Color.parseColor("#101820"))
        col.addView(overlay, LinearLayout.LayoutParams(-1, 0, 1f))

        hintText = TextView(this).apply {
            textSize = 14f; setTextColor(Color.parseColor("#FFD54F")); gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#101820")); setPadding(dp(8), dp(4), dp(8), dp(2))
        }
        col.addView(hintText, LinearLayout.LayoutParams(-1, -2))

        infoText = TextView(this).apply {
            textSize = 12f; setTextColor(Color.parseColor("#B0BEC5")); gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#101820")); setPadding(dp(8), dp(2), dp(8), dp(4))
        }
        col.addView(infoText, LinearLayout.LayoutParams(-1, -2))

        graph = GraphView(this)
        col.addView(graph, LinearLayout.LayoutParams(-1, dp(80)))

        btnAr = btn("") { toggleAr() }
        btnSound = btn("") { sound = !sound; savePrefs(); updateButtons() }

        col.addView(row(
            btn("📶 Şəbəkə seç") { showPicker() },
            btnAr,
            btnSound,
            btn("🔄 Sıfırla") { clearData() }
        ))
        updateButtons()
        setContentView(root)
    }

    private fun updateButtons() {
        btnAr.text = if (arMode) "🧭 Kompas" else "📷 AR"
        btnSound.text = if (sound) "🔊 Səs: ON" else "🔇 Səs: OFF"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- Permissions ----------
    private fun hasLoc() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestBasePerms() {
        val need = ArrayList<String>()
        need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        val missing = need.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    // ---------- AR / camera ----------
    private fun toggleAr() {
        if (!arMode) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                wantAr = true
                permLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                return
            }
            setAr(true)
        } else setAr(false)
    }

    private fun setAr(on: Boolean) {
        arMode = on
        overlay.ar = on
        overlay.setBackgroundColor(if (on) Color.TRANSPARENT else Color.parseColor("#101820"))
        preview.visibility = if (on) View.VISIBLE else View.GONE
        if (on) startCamera() else stopCamera()
        updateButtons()
        overlay.invalidate()
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                val p = f.get()
                val pv = Preview.Builder().build()
                pv.setSurfaceProvider(preview.surfaceProvider)
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv)
            } catch (e: Exception) {
                toast("Kamera açılmadı")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try { f.get().unbindAll() } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(this))
    }

    // ---------- Prefs ----------
    private fun loadPrefs() {
        txAt1m = prefs.getFloat("tx", -40f).toDouble()
        nExp = prefs.getFloat("n", 2.7f).toDouble()
        useFspl = prefs.getBoolean("fspl", false)
        sound = prefs.getBoolean("sound", false)
        targetBssid = prefs.getString("bssid", null)
        targetSsid = prefs.getString("ssid", "") ?: ""
        targetFreq = prefs.getInt("freq", 2437)
    }

    private fun savePrefs() {
        prefs.edit()
            .putFloat("tx", txAt1m.toFloat())
            .putFloat("n", nExp.toFloat())
            .putBoolean("fspl", useFspl)
            .putBoolean("sound", sound)
            .putString("bssid", targetBssid)
            .putString("ssid", targetSsid)
            .putInt("freq", targetFreq)
            .apply()
    }

    // ---------- Target selection ----------
    private fun showPicker() {
        if (!hasLoc()) {
            requestBasePerms(); toast("Məkan icazəsi verin"); return
        }
        try { wifi.startScan() } catch (_: Exception) {}
        val list: List<ScanResult> = try { wifi.scanResults } catch (e: SecurityException) { emptyList() }
        val items = list.filter { it.BSSID != null }
            .groupBy { it.BSSID }.map { it.value.first() }
            .sortedByDescending { it.level }
        if (items.isEmpty()) {
            toast("Şəbəkə tapılmadı. Məkan (GPS) xidmətini açın"); return
        }
        val labels = items.map {
            val n = if (it.SSID.isNullOrEmpty()) "(gizli)" else it.SSID
            "$n\n${it.level} dBm • ${it.frequency} MHz" +
                if (it.is80211mcResponder()) " • RTT ✓" else ""
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("WiFi seçin")
            .setItems(labels) { _, i -> selectTarget(items[i]) }.show()
    }

    private fun selectTarget(r: ScanResult) {
        targetBssid = r.BSSID
        targetSsid = if (r.SSID.isNullOrEmpty()) "(gizli)" else r.SSID
        targetFreq = r.frequency
        clearData()
        savePrefs()
        processSample(r.level)
    }

    private fun autoPickConnected() {
        if (!hasLoc()) return
        try {
            val i = wifi.connectionInfo ?: return
            val b = i.bssid ?: return
            if (i.networkId == -1 || b.startsWith("02:00:00")) return
            targetBssid = b
            targetSsid = (i.ssid ?: "").trim('"')
            targetFreq = i.frequency
            savePrefs()
        } catch (_: SecurityException) {}
    }

    private fun isConnectedTo(b: String) = try {
        wifi.connectionInfo?.bssid.equals(b, true)
    } catch (_: SecurityException) { false }

    private fun clearData() {
        ema = null
        history.clear(); trend.clear()
        binVal.fill(0.0); binCnt.fill(0); binTime.fill(0L)
        bestBearing = Float.NaN
        dispBearing = Float.NaN
        lastDist = Double.NaN
        overlay.rel = Float.NaN
        nets.values.forEach { it.resetBins(); it.rttM = Double.NaN }
        refreshUi()
    }

    // ---------- Signal processing ----------
    private fun processSample(raw: Int) {
        val e = ema?.let { it * 0.7 + raw * 0.3 } ?: raw.toDouble()
        ema = e
        history.add(e.toFloat()); if (history.size > 90) history.removeAt(0)
        trend.add(SystemClock.elapsedRealtime() to e); if (trend.size > 40) trend.removeAt(0)
        if (headingInit) {
            val b = (heading / 10f).toInt().coerceIn(0, 35)
            binVal[b] = if (binCnt[b] == 0) raw.toDouble() else binVal[b] * 0.5 + raw * 0.5
            binCnt[b]++
            binTime[b] = SystemClock.elapsedRealtime()
            computeBest()
        }
        refreshUi()
    }

    private fun bearingFrom(
        v: DoubleArray, cnt: IntArray, tm: LongArray,
        window: Long, decay: Double, minBins: Int
    ): Float {
        val now = SystemClock.elapsedRealtime()
        var mx = -1e9
        var mn = 1e9
        var c = 0
        for (i in 0 until 36) {
            if (cnt[i] == 0 || now - tm[i] > window) continue
            c++
            mx = max(mx, v[i]); mn = minOf(mn, v[i])
        }
        if (c < minBins || mx - mn < 3.0) return Float.NaN
        var sx = 0.0
        var sy = 0.0
        for (i in 0 until 36) {
            val age = now - tm[i]
            if (cnt[i] == 0 || age > window) continue
            val wt = exp((v[i] - mx) / 2.5) * exp(-age / decay)
            val th = Math.toRadians(i * 10.0 + 5.0)
            sx += wt * sin(th); sy += wt * cos(th)
        }
        val b = Math.toDegrees(atan2(sx, sy)).toFloat()
        return (b + 360f) % 360f
    }

    private fun computeBest() {
        bestBearing = bearingFrom(binVal, binCnt, binTime, 25000, 15000.0, 4)
    }

    private fun feedBins(n: Net, rssi: Double) {
        if (!headingInit) return
        val b = (heading / 10f).toInt().coerceIn(0, 35)
        n.binVal[b] = if (n.binCnt[b] == 0) rssi else n.binVal[b] * 0.5 + rssi * 0.5
        n.binCnt[b]++
        n.binTime[b] = SystemClock.elapsedRealtime()
        n.bearing = bearingFrom(n.binVal, n.binCnt, n.binTime, 60000, 30000.0, 3)
    }

    private fun updRssi(n: Net, v: Double) {
        n.rssi = if (!n.hasRssi) v else n.rssi * 0.5 + v * 0.5
        n.hasRssi = true
    }

    private fun distanceOf(rssi: Double, freq: Int): Double {
        val d = if (useFspl)
            10.0.pow((15.0 - rssi + 27.55 - 20.0 * log10(freq.toDouble())) / 20.0)
        else
            10.0.pow((txAt1m - rssi) / (10.0 * nExp))
        return d.coerceIn(0.1, 200.0)
    }

    /** Şəbəkənin məsafəsi: təzə RTT varsa o, yoxsa RSSI modeli. */
    private fun netDist(n: Net): Pair<Double, Boolean> {
        val now = SystemClock.elapsedRealtime()
        if (!n.rttM.isNaN() && now - n.rttTime < 8000) return n.rttM.coerceIn(0.0, 200.0) to true
        return distanceOf(n.rssi, n.freq) to false
    }

    private fun bandTag(f: Int) = when {
        f >= 5925 -> " (6G)"
        f >= 4900 -> " (5G)"
        else -> ""
    }

    // ---------- Bütün şəbəkələr ----------
    private fun ingestScan() {
        if (!hasLoc()) return
        val list = try { wifi.scanResults } catch (e: SecurityException) { return }
        lastScan = list
        val now = SystemClock.elapsedRealtime()
        val tb = targetBssid
        for (r in list) {
            val b = r.BSSID?.lowercase() ?: continue
            val age = (now - r.timestamp / 1000).coerceAtLeast(0)
            if (age > 60000) continue
            val n = nets.getOrPut(b) { Net(b) }
            n.ssid = r.SSID ?: ""
            n.freq = r.frequency
            n.mc = r.is80211mcResponder()
            n.lastSeen = now - age
            if (r.timestamp != n.lastTs) {
                n.lastTs = r.timestamp
                if (!b.equals(tb, true)) {
                    updRssi(n, r.level.toDouble())
                    feedBins(n, r.level.toDouble())
                }
            }
        }
        refreshUi()
    }

    private fun updateItems() {
        val now = SystemClock.elapsedRealtime()
        val tb = targetBssid
        val e = ema
        if (tb != null && e != null) {
            val tn = nets.getOrPut(tb.lowercase()) { Net(tb.lowercase()) }
            if (tn.ssid.isEmpty() && targetSsid != "(gizli)") tn.ssid = targetSsid
            tn.freq = targetFreq
            tn.rssi = e; tn.hasRssi = true
            tn.lastSeen = now
        }
        val iter = nets.values.iterator()
        while (iter.hasNext()) {
            val n = iter.next()
            if (now - n.lastSeen > 60000 && !n.bssid.equals(tb, true)) iter.remove()
        }
        val arr = ArrayList<Net>()
        for (n in nets.values) {
            if (!n.hasRssi && n.rttM.isNaN()) continue
            val (d, viaRtt) = netDist(n)
            val base = if (n.ssid.isEmpty()) "(gizli ${n.bssid.takeLast(5)})" else n.ssid
            n.item.name = base + bandTag(n.freq)
            n.item.dist = d
            n.item.rtt = viaRtt
            n.item.selected = n.bssid.equals(tb, true)
            arr.add(n)
        }
        arr.sortWith(compareByDescending<Net> { it.item.selected }.thenBy { it.item.dist })
        netArr = arr
        overlay.items = arr.map { it.item }
    }

    // ---------- RTT ----------
    private fun doRtt() {
        val h = rttHelper
        if (h == null) { rttStatus = "RTT: cihaz dəstəkləmir"; return }
        if (!hasLoc()) { rttStatus = "RTT: məkan icazəsi lazımdır"; return }
        val now = SystemClock.elapsedRealtime()
        if (h.busy && now - rttBusySince > 10000) h.busy = false
        if (h.busy) return
        if (!h.available()) { rttStatus = "RTT: Wi-Fi və Məkan (GPS) açıq olmalıdır"; return }
        if (lastScan.isEmpty()) {
            lastScan = try { wifi.scanResults } catch (e: SecurityException) { emptyList() }
        }
        val tb = targetBssid
        val cands = lastScan
            .filter { it.BSSID != null && it.is80211mcResponder() }
            .groupBy { it.BSSID.lowercase() }.map { it.value.first() }
            .sortedWith(compareByDescending<ScanResult> { it.BSSID.equals(tb, true) }
                .thenByDescending { it.level })
            .take(minOf(h.maxPeers(), 8))
        if (cands.isEmpty()) { rttStatus = "RTT: 802.11mc dəstəkləyən AP tapılmadı"; refreshUi(); return }
        rttBusySince = now
        h.range(cands) { res, err -> onRtt(res, err, cands.size) }
    }

    private fun onRtt(res: List<RttSample>?, err: String?, asked: Int) {
        val now = SystemClock.elapsedRealtime()
        if (res == null) {
            rttStatus = "RTT xətası" + (if (err.isNullOrEmpty()) "" else " ($err)")
            refreshUi(); return
        }
        rttStatus = if (res.isEmpty()) "RTT: AP cavab vermədi (0/$asked)" else "RTT aktiv (${res.size}/$asked AP)"
        val tb = targetBssid
        for (s in res) {
            val n = nets.getOrPut(s.bssid) { Net(s.bssid) }
            n.mc = true
            val m = s.meters.coerceAtLeast(0.0)
            n.rttM = if (n.rttM.isNaN() || now - n.rttTime > 8000) m else n.rttM * 0.5 + m * 0.5
            n.rttStd = s.stdM
            n.rttTime = now
            n.lastSeen = now
            if (s.rssi in -120..-1) {
                if (s.bssid.equals(tb, true)) {
                    if (isConnectedTo(s.bssid) != true) processSample(s.rssi)
                } else {
                    updRssi(n, s.rssi.toDouble())
                    feedBins(n, s.rssi.toDouble())
                }
            }
        }
        refreshUi()
    }

    private fun fmt(d: Double) = if (d < 10) String.format("%.1f", d) else String.format("%.0f", d)

    private fun channel(f: Int) = when {
        f == 2484 -> 14
        f in 2412..2472 -> (f - 2407) / 5
        f in 5160..5885 -> (f - 5000) / 5
        f in 5955..7115 -> (f - 5950) / 5
        else -> 0
    }

    private fun refreshUi() {
        if (!::distText.isInitialized) return
        updateItems()
        val e = ema
        val tb = targetBssid
        if (e == null || tb == null) {
            distText.text = "WiFi seçin"
            hintText.text = "«📶 Şəbəkə seç» düyməsinə basın"
            infoText.text = rttStatus
            graph.data = emptyList(); graph.invalidate()
            overlay.label = ""; overlay.ssid = ""; overlay.invalidate()
            return
        }
        val tn = nets[tb.lowercase()]
        val rssiD = distanceOf(e, targetFreq)
        val (d, viaRtt) = if (tn != null) netDist(tn) else (rssiD to false)
        lastDist = d
        val dt = if (viaRtt) "${fmt(d)} m (RTT)" else "≈ ${fmt(d)} m"
        distText.text = dt
        overlay.label = if (viaRtt) "${fmt(d)} m RTT" else "≈ ${fmt(d)} m"
        overlay.ssid = targetSsid

        val now = SystemClock.elapsedRealtime()
        val old = trend.lastOrNull { now - it.first >= 3000 }
        val tr = if (old == null) "" else {
            val delta = e - old.second
            if (delta > 1.5) "🔥 İsti – yaxınlaşırsan"
            else if (delta < -1.5) "❄ Soyuq – uzaqlaşırsan"
            else "➡ Sabit"
        }
        val dir = if (bestBearing.isNaN()) "Telefonla yavaş 360° dönün" else "Ox ən güclü siqnalı göstərir"
        hintText.text = if (d < 1.0) "✅ Tapıldı! Router çox yaxındadır" else "$tr\n$dir".trim()

        val line2 = if (viaRtt && tn != null) {
            val sd = if (tn.rttStd.isNaN()) "" else " ±${String.format("%.1f", tn.rttStd)}"
            "📏 RTT: ${fmt(d)} m$sd • RSSI təxmini: ≈${fmt(rssiD)} m"
        } else "$rttStatus • RSSI təxmini: ≈${fmt(rssiD)} m"
        infoText.text = "$targetSsid • ${e.roundToInt()} dBm • ${targetFreq} MHz • kanal ${channel(targetFreq)}\n$line2"
        graph.data = history.toList()
        graph.invalidate()
        overlay.invalidate()
    }

    // ---------- Loops ----------
    private val fastRun = object : Runnable {
        override fun run() {
            if (targetBssid == null) autoPickConnected()
            val tb = targetBssid
            if (headingInit) computeBest()
            for (n in netArr) {
                if (n.bssid.equals(tb, true)) continue
                n.bearing = bearingFrom(n.binVal, n.binCnt, n.binTime, 60000, 30000.0, 3)
            }
            if (tb != null) {
                try {
                    val info = wifi.connectionInfo
                    if (info != null && info.bssid.equals(tb, true) && info.rssi > -127) {
                        targetFreq = info.frequency
                        processSample(info.rssi)
                    }
                } catch (_: SecurityException) {}
            }
            handler.postDelayed(this, 400)
        }
    }

    private val scanRun = object : Runnable {
        override fun run() {
            val tb = targetBssid
            if (hasLoc()) {
                try { wifi.startScan() } catch (_: Exception) {}
            }
            handler.postDelayed(this, 4000)
        }
    }

    private val rttRun = object : Runnable {
        override fun run() {
            try { doRtt() } catch (_: Exception) {}
            handler.postDelayed(this, 1000)
        }
    }

    private val soundRun = object : Runnable {
        override fun run() {
            val d = lastDist
            var delay = 800L
            if (sound && !d.isNaN() && ema != null) {
                try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 50) } catch (_: Exception) {}
                if (d < 1.0) vibrateShort()
                delay = (d * 250).toLong().coerceIn(150L, 2000L)
            }
            handler.postDelayed(this, delay)
        }
    }

    private fun vibrateShort() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        v?.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            ingestScan()
            val tb = targetBssid ?: return
            try {
                val r = wifi.scanResults.firstOrNull { it.BSSID.equals(tb, true) } ?: return
                targetFreq = r.frequency
                if (!isConnectedTo(tb)) processSample(r.level)
            } catch (_: SecurityException) {}
        }
    }

    // ---------- Lifecycle ----------
    override fun onResume() {
        super.onResume()
        val s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (s == null) toast("Cihazda kompas sensoru yoxdur")
        else sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
        ContextCompat.registerReceiver(
            this, scanReceiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        try { tone = ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Exception) {}
        ingestScan()
        handler.post(fastRun); handler.post(scanRun); handler.post(soundRun); handler.post(rttRun)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacksAndMessages(null)
        sm.unregisterListener(this)
        try { unregisterReceiver(scanReceiver) } catch (_: Exception) {}
        tone?.release(); tone = null
    }

    // ---------- Compass ----------
    override fun onSensorChanged(event: SensorEvent) {
        val rm = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(rm, event.values)
        val rm2 = FloatArray(9)
        if (abs(rm[8]) < 0.7f) {
            SensorManager.remapCoordinateSystem(rm, SensorManager.AXIS_X, SensorManager.AXIS_Z, rm2)
        } else {
            System.arraycopy(rm, 0, rm2, 0, 9)
        }
        val o = FloatArray(3)
        SensorManager.getOrientation(rm2, o)
        var az = Math.toDegrees(o[0].toDouble()).toFloat()
        if (az < 0) az += 360f
        if (!headingInit) {
            heading = az; headingInit = true
        } else {
            val diff = ((az - heading + 540f) % 360f) - 180f
            heading = (heading + diff * (if (arMode) 0.4f else 0.2f) + 360f) % 360f
        }
        overlay.heading = heading
        val el = Math.toDegrees(asin((-rm[8]).coerceIn(-1f, 1f).toDouble())).toFloat()
        overlay.elev = overlay.elev + (el - overlay.elev) * 0.3f
        if (bestBearing.isNaN()) {
            dispBearing = Float.NaN
            overlay.rel = Float.NaN
        } else {
            dispBearing = if (dispBearing.isNaN()) bestBearing else
                (dispBearing + (((bestBearing - dispBearing + 540f) % 360f) - 180f) * 0.08f + 360f) % 360f
            overlay.rel = ((dispBearing - heading + 540f) % 360f) - 180f
        }
        // Digər şəbəkələrin istiqaməti
        val tb = targetBssid
        for (n in netArr) {
            if (n.bssid.equals(tb, true)) { n.item.rel = overlay.rel; continue }
            if (n.bearing.isNaN()) {
                n.dispBearing = Float.NaN
                n.item.rel = Float.NaN
            } else {
                n.dispBearing = if (n.dispBearing.isNaN()) n.bearing else
                    (n.dispBearing + (((n.bearing - n.dispBearing + 540f) % 360f) - 180f) * 0.08f + 360f) % 360f
                n.item.rel = ((n.dispBearing - heading + 540f) % 360f) - 180f
            }
        }
        overlay.invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
