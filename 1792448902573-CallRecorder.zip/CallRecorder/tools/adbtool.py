#!/usr/bin/env python3
"""Lokal ADB idarəetməsi. İstifadə:
  python adbtool.py setup [app-debug.apk]   # quraşdır + icazələr + başlat
  python adbtool.py list [all|in|out]       # telefondakı yazıları göstər
  python adbtool.py pull [all|in|out]       # kompüterə yüklə (./recordings)
"""
import subprocess, sys, os
P = "az.zengyazici"
REMOTE = f"/sdcard/Android/data/{P}/files/calls"
def adb(*a): return subprocess.run(["adb", *a], capture_output=True, text=True).stdout.strip()
def files(flt):
    out = [f for f in adb("shell", "ls", REMOTE).splitlines() if f.endswith(".m4a")]
    return [f for f in out if flt == "all" or f.split("_")[1] == flt]
def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "list"
    arg = sys.argv[2] if len(sys.argv) > 2 else None
    if "device" not in adb("devices").replace("List of devices attached", ""):
        sys.exit("Cihaz tapılmadı. USB debugging-i yoxlayın.")
    if cmd == "setup":
        apk = arg or "app/build/outputs/apk/debug/app-debug.apk"
        print(adb("install", "-r", apk))
        for p in ["RECORD_AUDIO", "READ_PHONE_STATE", "POST_NOTIFICATIONS"]:
            adb("shell", "pm", "grant", P, f"android.permission.{p}")
        adb("shell", "cmd", "notification", "allow_listener", f"{P}/{P}.WaListener")
        adb("shell", "dumpsys", "deviceidle", "whitelist", f"+{P}")
        adb("shell", "appops", "set", P, "RUN_ANY_IN_BACKGROUND", "allow")
        adb("shell", "am", "start", "-n", f"{P}/.MainActivity")
        print("Hazırdır: tətbiq işləyir.")
    elif cmd == "list":
        for f in files(arg or "all"): print(f)
    elif cmd == "pull":
        os.makedirs("recordings", exist_ok=True)
        for f in files(arg or "all"):
            adb("pull", f"{REMOTE}/{f}", "recordings/"); print("yükləndi:", f)
main()
