package az.m3u.sinayici

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory

/**
 * HTTP yoxlamasından sonra 🔴 qalan kanalları səssiz (görüntüsüz) Media3 (ExoPlayer) ilə yenidən yoxlayır.
 * VLC yoxlamada İSTİFADƏ OLUNMUR.
 *
 * Qərar qaydası (player panelindəki 🪣 ilə eynidir, bax Net.bucket):
 *   kanal açılan kimi bufer 🔴 olur; bufer 🔴 → 🟢 keçsə (≥ 2 san bufer, azalmır) kanal İŞLƏYİR;
 *   vaxt bitənə qədər 🟢-ə keçmirsə (və ya xəta gəlirsə) növbəti profil, sonda kanal İŞLƏMİR.
 * Eyni anda PAR kanal paralel yoxlanır.
 */
object Media3Verifier {
    private const val PAR = 16               // əvvəl 40: çox paralel ExoPlayer tətbiqi çökdürürdü
    private const val PAR_OTT = 16          // əvvəl 48          // qrup ▶️ yoxlaması üçün ayrıca paralel limit — standart yoxlamanı yavaşlatmır
    private fun ottOnly(t: Int) = t == 3 || t == 4          // 3/4 = tester və qrup ▶️ (HTTP JS tərəfdə artıq aparılıb)
    private const val ATTEMPT_MS = 12000L   // bir profil üçün: bufer bu müddətdə 🟢 olmalıdır (yavaş serverlər yalan 🔴 olmasın)
    private const val ATTEMPT_OTT_MS = 9000L
    private const val POLL_MS = 200L        // bufer vəziyyəti hər 200 ms yoxlanır

    private const val K_AUTO = 0   // progressiv / TS / avtomatik
    private const val K_HLS = 1
    private const val K_DASH = 2

    private val TS_FLAGS = DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
        DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS

    private class Job(val url: String, val hdr: String, val tag: Int, val done: (Boolean) -> Unit) {
        var player: ExoPlayer? = null
        var timeout: Runnable? = null
        var finished = false
        var why: Why.R? = null            // 🔴 olarsa niyə: ən konkret səbəb (rank-a görə) saxlanır
        val retried = HashSet<Int>()       // keçici şəbəkə xətasında hər profil bir dəfə təkrar sınanır
        var modes: List<Int>? = null   // Ott (3/4): HTTP-siz cəhd rejimləri (K_AUTO / K_HLS / K_DASH)
        val extra = ArrayList<(Boolean) -> Unit>()   // eyni linkli digər kanallar: bir dəfə yoxlanır, nəticə hamıya verilir
        val key get() = "$tag|$url"
    }

    private val h = Handler(Looper.getMainLooper())
    private fun note(j: Job, r: Why.R) { val o = j.why; if (o == null || r.rank >= o.rank) j.why = r }
    private val index = HashMap<String, Job>()
    private val queue = ArrayDeque<Job>()
    private val active = HashSet<Job>()
    private var gen = 0

    /** tag = playlist nömrəsi (1/2) və ya 3/4 (Ott): playlistlər eyni anda, bir-birini gözlətmədən yoxlanır. */
    fun add(ctx: Context, url: String, hdr: String, tag: Int = 0, done: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        h.post {
            val rs = Net.reasonOf(url)
            if (Regex("^HTTP (403|404|500|502)\\b").containsMatchIn(rs)) { done(false); return@post }   // 403/404/500/502: Media3 ilə yoxlanmır
            val k = "$tag|$url"
            val ex = index[k]
            if (ex != null && !ex.finished) { ex.extra.add(done); return@post }
            val j = Job(url, hdr, tag, done)
            index[k] = j
            queue.addLast(j); pump(app)
        }
    }

    /** tag verilərsə yalnız o playlistin yoxlaması ləğv olunur, digəri davam edir. */
    fun cancel(tag: Int? = null) {
        h.post {
            if (tag == null) {
                gen++
                queue.clear(); index.clear()
                active.toList().forEach { stop(it) }
                active.clear()
            } else {
                queue.removeAll { it.tag == tag }
                index.values.removeAll { it.tag == tag }
                active.filter { it.tag == tag }.forEach { stop(it); active.remove(it) }
            }
            // boşalan yerlərə digər playlistin növbədəki kanalları keçir
            appCtx?.let { pump(it) }
        }
    }

    private var appCtx: Context? = null

    /** Növbədən növbəti kanalı seç: aktiv işi ən az olan playlistdən (ədalətli bölgü). */
    private const val HOST_MAX = 2   // eyni domendə eyni anda ən çox 2 player (503 / vaxt aşımının qarşısı)
    private fun hostOf(u: String): String = try { Uri.parse(u.split("|", limit = 2)[0].trim()).host ?: "" } catch (e: Exception) { "" }
    private fun nextJob(otherOk: Boolean, ottOk: Boolean): Job? {
        val busy = HashMap<String, Int>()
        active.forEach { a -> val h = hostOf(a.url); busy[h] = (busy[h] ?: 0) + 1 }
        val cand = queue.filter { (if (ottOnly(it.tag)) ottOk else otherOk) && (busy[hostOf(it.url)] ?: 0) < HOST_MAX }
        if (cand.isEmpty()) return null
        val tags = cand.map { it.tag }.distinct()
        val best = tags.minByOrNull { t -> active.count { it.tag == t } } ?: return null
        val j = cand.first { it.tag == best }
        queue.remove(j)
        return j
    }

    private fun stop(j: Job) {
        j.finished = true
        j.timeout?.let { h.removeCallbacks(it) }; j.timeout = null
        val p = j.player; j.player = null
        if (p != null) h.post { try { p.release() } catch (e: Exception) { } }
    }

    private fun pump(app: Context) {
        appCtx = app
        while (true) {
            // yaddaş 80%-dən çoxdursa yeni player açılmır (OutOfMemory çökməsinin qarşısı)
            val rt = Runtime.getRuntime()
            if (rt.totalMemory() - rt.freeMemory() > rt.maxMemory() * 0.8) { h.postDelayed({ pump(app) }, 800); return }
            val ottActive = active.count { ottOnly(it.tag) }
            val j = nextJob(active.size - ottActive < PAR, ottActive < PAR_OTT) ?: return
            active.add(j)
            val my = gen
            Thread {
                val all = Net.profiles(j.url, j.hdr)
                // Dəqiqlik: BÜTÜN profillər sınanır (özəl/VLC-UA, standart, okhttp, Chrome+Referer)
                var m3 = all
                if (ottOnly(j.tag)) {
                    val path = try { Uri.parse(all[0].url).path?.lowercase() ?: "" } catch (e: Exception) { "" }
                    val modes: List<Int> = when {
                        path.endsWith(".m3u8") || path.endsWith(".m3u") -> listOf(K_HLS)
                        path.endsWith(".mpd") -> listOf(K_DASH)
                        // .ts və s.: yönləndirici link son ünvanda HLS çıxa bilər → HTTP-siz ehtiyat cəhd kimi HLS də sınanır
                        path.endsWith(".ts") || path.endsWith(".mp4") || path.endsWith(".mkv") || path.endsWith(".flv") ||
                            path.endsWith(".aac") || path.endsWith(".mp3") -> listOf(K_AUTO, K_HLS)
                        else -> listOf(K_AUTO, K_HLS, K_DASH)
                    }
                    // 🔴 təsdiqi: eyni rejimlər ikinci dəfə fərqli (Chrome+Referer) profillə təkrarlanır
                    j.modes = if (all.size > 1) modes + modes else modes
                    m3 = modes.map { all[0] } + (if (all.size > 1) modes.map { all.last() } else emptyList())
                }
                h.post { if (my == gen && !j.finished) attempt(app, j, m3, 0, my) }
            }.start()
        }
    }

    private fun end(app: Context, j: Job, ok: Boolean, my: Int) {
        if (j.finished || my != gen) return
        if (!ok && !Net.online(app)) {   // internet yoxdursa nəticə "açılmır" sayılmır: iş bir az sonra yenidən növbəyə qoyulur
            stop(j); active.remove(j); index.remove(j.key)
            val nj = Job(j.url, j.hdr, j.tag, j.done); nj.extra.addAll(j.extra)
            index[nj.key] = nj
            h.postDelayed({ if (my == gen && index[nj.key] === nj) { queue.addLast(nj); pump(app) } }, 3000)
            pump(app)
            return
        }
        stop(j); active.remove(j)
        if (ok) Net.exoOk(j.url) else Net.exoFail(j.url)   // Media3 nəticəsi yadda saxlanır (oflayn hal yuxarıda ayrıca işlənir)
        if (!ok) {   // səbəb JS-ə getReason ilə çatır (done çağırılmadan ƏVVƏL yazılır)
            val r = j.why ?: Why.NO_STREAM
            Net.forceReason(j.url, r)   // ƏN SON Media3 yoxlamasının səbəbi köhnə HTTP səbəbini əvəz edir
        }
        index.remove(j.key)
        j.done(ok); j.extra.forEach { it(ok) }
        pump(app)
    }

    // ---------------------------------------------------------------- Media3 mərhələsi
    private fun attempt(app: Context, j: Job, ps: List<Net.Target>, i: Int, my: Int) {
        if (j.finished || my != gen) return
        j.timeout?.let { h.removeCallbacks(it) }; j.timeout = null
        val old = j.player; j.player = null
        if (old != null) try { old.release() } catch (e: Exception) { }
        if (i >= ps.size) { end(app, j, false, my); return }    // bütün profillərdə bufer 🟢 olmadı → kanal işləmir
        val t = ps[i]
        val fixed = j.modes
        if (fixed != null) { start(app, j, ps, i, t, fixed[i], my); return }   // 3/4: əlavə HTTP sorğusu yoxdur
        Thread {
            val kind = try { quickKind(t) } catch (e: Exception) { K_AUTO }
            h.post { if (my == gen && !j.finished) start(app, j, ps, i, t, kind, my) }
        }.start()
    }

    /** Uzantıdan bəlli olursa əlavə şəbəkə sorğusu atılmır (sürət); yalnız qeyri-müəyyən linklərdə məzmun yoxlanır. */
    private fun quickKind(t: Net.Target): Int {
        val path = try { Uri.parse(t.url).path?.lowercase() ?: "" } catch (e: Exception) { "" }
        if (path.endsWith(".m3u8") || path.endsWith(".m3u")) return K_HLS
        if (path.endsWith(".mpd")) return K_DASH
        // .ts və s. dahil: yönləndirməni izləyib SON ünvanın/məzmunun növünü müəyyən edir (yönləndirici link HLS/DASH-a çıxa bilər)
        return when (Net.sniffKind(t)) { 1 -> K_HLS; 2 -> K_DASH; else -> K_AUTO }
    }

    private fun start(app: Context, j: Job, ps: List<Net.Target>, i: Int, t: Net.Target, kind: Int, my: Int) {
        val hls = kind == K_HLS
        val ott = ottOnly(j.tag)
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(if (ott) 5000 else 4000).setReadTimeoutMs(if (ott) 5000 else 4000)
        val ds = ResolvingDataSource.Factory(http, ResolvingDataSource.Resolver { spec -> spec.withAdditionalHeaders(t.headers) })
        val policy = DefaultLoadErrorHandlingPolicy(if (ott) 0 else 1)   // xətada uzun təkrar cəhdlər yoxdur → tez nəticə
        val msf: MediaSource.Factory = if (hls)
            HlsMediaSource.Factory(ds)
                .setExtractorFactory(DefaultHlsExtractorFactory(TS_FLAGS, true))
                .setLoadErrorHandlingPolicy(policy)
        else
            DefaultMediaSourceFactory(ds, DefaultExtractorsFactory().setTsExtractorFlags(TS_FLAGS).setConstantBitrateSeekingEnabled(true))
                .setLoadErrorHandlingPolicy(policy)
        // Bufer 🟢 üçün ≥ 2 san lazımdır → hədd 2.5 san-dən aşağı olmamalıdır (yoxsa bufer heç vaxt 🟢 olmaz).
        // Oynamağa 0.5 san bufer ilə başlayır, sonra bufer 5 saniyəyə qədər dolur.
        val lc = DefaultLoadControl.Builder().setBufferDurationsMs(2500, 5000, 500, 1000).build()
        val p = ExoPlayer.Builder(app, DefaultRenderersFactory(app).setEnableDecoderFallback(true))
            .setLoadControl(lc)
            .setMediaSourceFactory(msf)
            .build()
        p.volume = 0f
        j.player = p
        p.addListener(object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                if (j.player !== p) return
                note(j, Why.fromPlayback(e))
                // keçici xəta (şəbəkə, 40 paralel player-də dekoder/audio resursu, canlı pəncərə): eyni profil bir dəfə təkrar
                val transient = Media3Cfg.transient(e.errorCode) || e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW
                if (transient && j.retried.add(i)) attempt(app, j, ps, i, my)
                else attempt(app, j, ps, i + 1, my)
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && j.player === p) {   // yayım dərhal bitdi → canlı kanal deyil
                    note(j, Why.R("yayım dərhal bitir (canlı deyil)", 2))
                    attempt(app, j, ps, i + 1, my)
                }
            }
        })

        // 🪣 bufer izlənir. Başlanğıcda hazır deyil → 🔴. 🔴 → 🟢 keçid = kanal işləyir.
        val t0 = SystemClock.uptimeMillis()
        val limit = if (ott) ATTEMPT_OTT_MS else ATTEMPT_MS
        var prev = -1L

        lateinit var poll: Runnable
        poll = Runnable {
            if (j.player !== p || j.finished || my != gen) return@Runnable
            val ahead = p.totalBufferedDuration
            val b = Net.bucket(p.playbackState == Player.STATE_READY, ahead, prev)
            prev = ahead
            // Vedrə 🟢 oldusa kanal işləyir
            if (b == Net.B_GREEN) { Net.markGood(t.url, t.name); end(app, j, true, my) }
            else if (SystemClock.uptimeMillis() - t0 >= limit) {   // bufer 🟢 olmadı → növbəti profil / 🔴
                note(j, if (p.playbackState == Player.STATE_READY) Why.R("bufer dolmur (yayım çox yavaş/kəsik axır)", 1) else Why.NO_STREAM)
                attempt(app, j, ps, i + 1, my)
            }
            else { j.timeout = poll; h.postDelayed(poll, POLL_MS) }
        }
        j.timeout = poll
        h.postDelayed(poll, POLL_MS)

        val mi = MediaItem.Builder().setUri(t.url)
        if (kind == K_HLS) mi.setMimeType(MimeTypes.APPLICATION_M3U8)
        else if (kind == K_DASH) mi.setMimeType(MimeTypes.APPLICATION_MPD)
        p.setMediaItem(mi.build()); p.prepare(); p.playWhenReady = true
    }
}
