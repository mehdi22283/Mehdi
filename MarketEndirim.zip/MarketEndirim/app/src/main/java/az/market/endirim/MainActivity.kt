package az.market.endirim

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

class MainActivity : AppCompatActivity() {

    private class Src(val name: String, val fn: suspend () -> List<Catalog>)

    private val order = listOf("Bravo Market", "Araz Market", "Al Market", "Rahat Market", "Tamstore")
    private val results = HashMap<String, MarketResult>()
    private lateinit var adapter: CatalogAdapter
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var status: TextView
    private var loadJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        swipe = findViewById(R.id.swipe)
        status = findViewById(R.id.status)
        adapter = CatalogAdapter { c ->
            startActivity(Intent(this, ViewerActivity::class.java).putExtra("catalog", c))
        }
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        swipe.setOnRefreshListener { load() }
        load()
    }

    private fun load() {
        loadJob?.cancel()
        results.clear()
        render()
        swipe.isRefreshing = true
        status.text = "Jurnallar axtarılır…"
        loadJob = lifecycleScope.launch {
            val sources = listOf(
                Src("Bravo Market") { Sources.bravo() },
                Src("Araz Market") { Sources.araz() },
                Src("Al Market") { Sources.al() },
                Src("Rahat Market") { Sources.rahat() },
                Src("Tamstore") { Sources.tamstore() }
            )
            sources.map { s ->
                async {
                    val r = try {
                        MarketResult(s.name, s.fn(), null)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        MarketResult(s.name, emptyList(), e.message ?: e.javaClass.simpleName)
                    }
                    results[s.name] = r
                    render()
                }
            }.awaitAll()
            swipe.isRefreshing = false
            launch { fillBravoDate() }
            downloadPdfs()
        }
    }

    /** Tətbiqə girəndə bütün PDF-ləri endirir; tarixi olmayanlar üçün OCR edir. */
    private suspend fun downloadPdfs() {
        val pdfs = results.values.flatMap { it.catalogs }.filter { it.kind == Kind.PDF }.map { it.urls[0] }.distinct()
        if (pdfs.isEmpty()) {
            status.text = ""
            return
        }
        var done = 0
        var failed = 0
        status.text = "PDF-lər yüklənir (0/${pdfs.size})"
        val sem = Semaphore(3)
        coroutineScope {
            pdfs.map { url ->
                async {
                    sem.withPermit {
                        try {
                            val f = Downloader.ensure(applicationContext, url)
                            fillDateByOcr(url, f)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            failed++
                        }
                    }
                    done++
                    status.text = "PDF-lər yüklənir ($done/${pdfs.size})"
                }
            }.awaitAll()
        }
        Downloader.cleanup(applicationContext, pdfs)
        status.text = "PDF-lər yükləndi" + if (failed > 0) " ($failed uğursuz)" else ""
    }

    private suspend fun fillDateByOcr(url: String, f: java.io.File) {
        val entry = results.entries.firstOrNull { e -> e.value.catalogs.any { it.urls[0] == url && it.date == null } } ?: return
        val market = entry.key
        val d = Ocr.pdfDate(applicationContext, f)
        val isTam = market == "Tamstore"
        if (d == null && !isTam) return
        val cur = results[market] ?: return
        results[market] = cur.copy(
            catalogs = if (d == null) cur.catalogs.filter { it.urls[0] != url }   // Tamstore: tarixi tapılmayanlar silinir
            else cur.catalogs.map { if (it.urls[0] == url) it.copy(date = d) else it }
        )
        render()
    }

    /** Bravo: tarix slaydın içindədir; səhifəni gizli WebView-da açıb ekran görüntüsündən OCR ilə oxuyur. */
    private suspend fun fillBravoDate() {
        val r = results["Bravo Market"] ?: return
        val c = r.catalogs.firstOrNull { it.kind == Kind.WEB && it.date == null } ?: return
        val d = try {
            BravoDate.read(this, c.urls[0])
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        } ?: return
        val cur = results["Bravo Market"] ?: return
        results["Bravo Market"] = cur.copy(catalogs = cur.catalogs.map { if (it.urls[0] == c.urls[0]) it.copy(date = d) else it })
        render()
    }

    private fun render() {
        val rows = order.flatMap { name ->
            val r = results[name]
            when {
                r == null -> listOf(Row(name, null, "Yüklənir…", null))
                r.error != null -> listOf(Row(name, null, "Yüklənmədi: ${r.error}", null))
                r.catalogs.isEmpty() -> listOf(Row(name, null, "Jurnal tapılmadı", null))
                else -> r.catalogs.map {
                    val sub = listOfNotNull(it.title, it.note, if (it.date == null) (if (name == "Tamstore" || it.kind == Kind.WEB) "tarix oxunur…" else "tarix tapılmadı") else null)
                        .joinToString(" • ")
                    Row(name, it.date, sub, it)
                }
            }
        }
        adapter.submit(rows)
    }
}

class CatalogAdapter(private val onClick: (Catalog) -> Unit) : RecyclerView.Adapter<CatalogAdapter.VH>() {
    private var rows: List<Row> = emptyList()

    class VH(v: android.view.View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.tvTitle)
        val sub: TextView = v.findViewById(R.id.tvSub)
    }

    fun submit(r: List<Row>) {
        rows = r
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_catalog, parent, false))

    override fun getItemCount() = rows.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val row = rows[position]
        val sb = SpannableStringBuilder(row.market)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, 0)
        val d = row.date
        if (d != null) {
            val start = sb.length
            sb.append("  •  ").append(d)
            sb.setSpan(ForegroundColorSpan(h.itemView.context.getColor(R.color.accent)), start, sb.length, 0)
        }
        h.title.text = sb
        h.sub.text = row.sub ?: ""
        val c = row.catalog
        h.itemView.setOnClickListener { if (c != null) onClick(c) }
        h.itemView.isClickable = c != null
    }
}
