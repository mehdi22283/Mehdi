package com.mehdi.keymapper

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class KeyMapperAccessibilityService : AccessibilityService() {

    private lateinit var repository: MappingRepository
    private val handler = Handler(Looper.getMainLooper())
    private var currentPackageName: String = ""

    private var pendingLongPressRunnable: Runnable? = null
    private var isLongPressHandled = false
    private val LONG_PRESS_TIMEOUT = 450L // 450 ms response threshold

    companion object {
        var isServiceRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        repository = MappingRepository(this)
        isServiceRunning = true
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            event.packageName?.let {
                currentPackageName = it.toString()
            }
        }
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val action = event.action

        val mappings = repository.getMappings()
        val shortMapping = mappings.find { it.triggerKeyCode == keyCode && !it.isLongPress }
        val longMapping = mappings.find { it.triggerKeyCode == keyCode && it.isLongPress }

        // If no custom mapping registered, delegate directly for zero latency
        if (shortMapping == null && longMapping == null) {
            return super.onKeyEvent(event)
        }

        if (action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) {
                isLongPressHandled = false

                if (longMapping != null) {
                    pendingLongPressRunnable = Runnable {
                        isLongPressHandled = true
                        executeAction(longMapping)
                    }
                    handler.postDelayed(pendingLongPressRunnable!!, LONG_PRESS_TIMEOUT)
                }
            }

            // Immediate execution if no long press is defined
            if (longMapping == null && shortMapping != null && shortMapping.actionType == ActionType.KEY_REMAP) {
                injectKeyEvent(shortMapping.targetKeyCode, KeyEvent.ACTION_DOWN)
                return true
            }
            return true
        }

        if (action == KeyEvent.ACTION_UP) {
            pendingLongPressRunnable?.let {
                handler.removeCallbacks(it)
                pendingLongPressRunnable = null
            }

            if (!isLongPressHandled) {
                if (shortMapping != null) {
                    executeAction(shortMapping)
                }
            }
            isLongPressHandled = false
            return true
        }

        return super.onKeyEvent(event)
    }

    private fun executeAction(mapping: KeyMapping) {
        when (mapping.actionType) {
            ActionType.KEY_REMAP -> {
                injectKeyEvent(mapping.targetKeyCode, KeyEvent.ACTION_DOWN)
                injectKeyEvent(mapping.targetKeyCode, KeyEvent.ACTION_UP)
            }
            ActionType.LAUNCH_APP -> {
                mapping.targetPackage?.let { pkg ->
                    val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(launchIntent)
                    }
                }
            }
            ActionType.FORCE_STOP_CURRENT_APP -> {
                if (currentPackageName.isNotEmpty() && currentPackageName != packageName) {
                    AdbManager.executeCommand("am force-stop $currentPackageName")
                }
            }
        }
    }

    private fun injectKeyEvent(keyCode: Int, action: Int) {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> performGlobalAction(GLOBAL_ACTION_BACK)
            KeyEvent.KEYCODE_HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            else -> {
                AdbManager.executeCommand("input keyevent $keyCode")
            }
        }
    }
}
