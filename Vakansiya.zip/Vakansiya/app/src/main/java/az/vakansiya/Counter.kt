package az.vakansiya

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener
import java.util.Calendar

/** Saytları gizli brauzerdə ardıcıl açıb bu gün / dünən tarixli elanları təxmini sayır. */
class Counter(
    private val ctx: Context,
    private val sites: List<Site>,
    private val onUpdate: (Int) -> Unit,
    private val onDone: () -> Unit
) {
    private val h = Handler(Looper.getMainLooper())
    private val wvs = mutableListOf<WebView>()
    private val finished = BooleanArray(sites.size)
    private var left = sites.size
    var stopped = false

    // ay adları: azərbaycanca, qısaltma, ingiliscə, rusca
    private val months = arrayOf(
        "yanvar|yan|january|jan|января",
        "fevral|fev|february|feb|февраля",
        "mart|mar|march|марта",
        "aprel|apr|april|апреля",
        "may|мая",
        "iyun|iyn|june|jun|июня",
        "iyul|iyl|july|jul|июля",
        "avqust|avq|august|aug|августа",
        "sentyabr|sen|september|sep|сентября",
        "oktyabr|okt|october|oct|октября",
        "noyabr|noy|november|nov|ноября",
        "dekabr|dek|december|dec|декабря"
    )
    private val end = "\$"
    private val nb = "(^|[^0-9])"
    private val na = "([^0-9]|$end)"

    private fun datePat(c: Calendar): String {
        val d = c.get(Calendar.DAY_OF_MONTH)
        val m = c.get(Calendar.MONTH) + 1
        val y = c.get(Calendar.YEAR)
        val yy = y % 100
        val mn = months[m - 1]
        return listOf(
            // 11.10.2026  11/10/2026  11-10-2026  11.10.26
            "${nb}0?$d[./-]0?$m[./-]($y|$yy)$na",
            // 2026-10-11  2026.10.11  2026/10/11
            "$y[./-]0?$m[./-]0?$d$na",
            // 11 oktyabr  11 Oktyabr 2026  11 okt.
            "${nb}0?$d[ .]*($mn)",
            // oct 11, 2026
            "($mn)[ .]*0?$d$na"
        ).joinToString("|")
    }

    private val tw = "bu gün|bugün|bu gun|bugun|today|сегодня|indicə|az əvvəl|just now"
    private val yw = "dünən|dunen|yesterday|вчера|${nb}(1|bir)[ ]*(gün|gun)[ ]*(əvvəl|evvel|öncə)|1 day ago"
    private val hr = "([0-9]+|bir)[ ]*(saat|hour|hr|час)[a-zəöüçşğı.]*[ ]*(əvvəl|evvel|öncə|ago|назад)"
    private val mn = "([0-9]+)[ ]*(dəq|dəqiqə|min|мин)[a-zəöüçşğı.]*[ ]*(əvvəl|evvel|öncə|ago|назад)"

    private fun js(careful: Boolean): String {
        val cal = Calendar.getInstance()
        val td = datePat(cal)
        cal.add(Calendar.DAY_OF_MONTH, -1)
        val yd = datePat(cal)
        return """(function(){
var L=JSON.parse(${Links.js(careful)});
var careful=$careful;
var TW=new RegExp("$tw"),YW=new RegExp("$yw"),TD=new RegExp("$td"),YD=new RegExp("$yd"),HR=new RegExp("$hr"),MN=new RegExp("$mn");
var now=new Date(),mins=now.getHours()*60+now.getMinutes();
function cls(x){x=x.toLowerCase().replace(/\s+/g,' ');
if(YW.test(x))return 2;if(TW.test(x))return 1;
var m=x.match(HR);if(m){var n=(m[1]=='bir')?1:parseInt(m[1]);return n*60>mins?2:1}
m=x.match(MN);if(m){return parseInt(m[1])>mins?2:1}
if(TD.test(x))return 1;if(YD.test(x))return 2;return 0}
function lineCount(){var lines=(document.body?document.body.innerText:'').split('\n'),t=0,y=0,p='';
for(var i=0;i<lines.length;i++){var l=lines[i].replace(/\s+/g,' ').trim().toLowerCase();if(l.length<3||l===p)continue;p=l;var r=cls(l);if(r==1)t++;else if(r==2)y++}
return [t,y]}
function cardCount(){
var A=[],hs=document.querySelectorAll('h1 a[href],h2 a[href],h3 a[href],h4 a[href]');
for(var i=0;i<hs.length;i++){if(hs[i].innerText.trim().length>3&&hs[i].href.indexOf('http')==0)A.push(hs[i])}
if(A.length<3){
 for(var pass=0;pass<2&&A.length<3;pass++){A=[];var all=document.querySelectorAll('a[href]'),sig={},c=[];
  for(var i=0;i<all.length;i++){var a=all[i],u;try{u=new URL(a.href)}catch(e){continue}
   if(u.origin!==location.origin)continue;var seg=u.pathname.split('/').filter(Boolean);
   if(seg.length<1)continue;if(pass==0?!/[0-9]{3,}/.test(u.pathname):seg.length<2)continue;
   if(a.innerText.trim().length<4)continue;sig[seg[0]]=(sig[seg[0]]||0)+1;c.push([seg[0],a])}
  var best='',bn=0;for(var k in sig){if(sig[k]>bn){bn=sig[k];best=k}}
  for(var i=0;i<c.length;i++){if(c[i][0]===best)A.push(c[i][1])}}}
var seen={},t=0,y=0,n=0;
function dh(el){var d={},m=0;for(var i=0;i<A.length;i++){if(el.contains(A[i])&&!d[A[i].href]){d[A[i].href]=1;m++}}return m}
for(var i=0;i<A.length;i++){var h=A[i].href;if(seen[h])continue;seen[h]=1;n++;
 var el=A[i],card=A[i];
 for(var k=0;k<8&&el.parentElement&&el.parentElement!==document.body;k++){el=el.parentElement;if(dh(el)>1)break;card=el}
 var r=cls(card.innerText||'');if(r==1)t++;else if(r==2)y++}
return [t,y,n]}
var res=null;
if(careful){res=cardCount();if(res[2]<3||res[0]+res[1]==0)res=null}
if(!res)res=lineCount();
return JSON.stringify({t:res[0],y:res[1],l:L});})()"""
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    fun start() {
        if (sites.isEmpty()) { onDone(); return }
        sites.forEachIndexed { i, site ->
            val w = WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(v: WebView, u: String) {
                        h.postDelayed({
                            if (!stopped && !finished[i]) {
                                v.evaluateJavascript(js(Store.careful(site.url))) { r ->
                                    if (!stopped && !finished[i]) {
                                        try {
                                            val o = JSONObject(JSONTokener(r).nextValue() as String)
                                            site.today = o.getInt("t")
                                            site.yest = o.getInt("y")
                                            val arr = o.getJSONArray("l")
                                            site.links = List(arr.length()) { arr.getString(it) }
                                        } catch (e: Exception) { }
                                        finish(i)
                                    }
                                }
                            }
                        }, if (Store.careful(site.url)) 6000L else 3500L)
                    }
                }
            }
            wvs.add(w)
            w.loadUrl(site.url)
            // hər sayt üçün ayrıca vaxt limiti
            h.postDelayed({ if (!stopped && !finished[i]) finish(i) }, 25000)
        }
    }

    private fun finish(i: Int) {
        if (finished[i]) return
        finished[i] = true
        try { wvs[i].destroy() } catch (e: Exception) { }
        onUpdate(i)
        left--
        if (left == 0 && !stopped) onDone()
    }

    fun stop() {
        stopped = true
        h.removeCallbacksAndMessages(null)
        wvs.forEachIndexed { i, w ->
            if (!finished[i]) { finished[i] = true; try { w.destroy() } catch (e: Exception) { } }
        }
    }
}
