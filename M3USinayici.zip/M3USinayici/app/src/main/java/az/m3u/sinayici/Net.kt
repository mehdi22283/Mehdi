package az.m3u.sinayici

import android.net.Uri
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Serverlər fərqli oynadıcıları fərqli qəbul edir (bəziləri brauzer UA-sını, bəziləri VLC-ni, bəziləri Referer-i rədd edir).
 * Ona görə hər link bir neçə "profil"lə sınanır; işləyən profil yadda saxlanılır.
 */
object Net {
    const val CHROME = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    class Target(val url: String, val headers: Map<String, String>, val name: String)

    private val good = ConcurrentHashMap<String, String>()
    fun markGood(url: String, name: String) { good[url] = name }

    private fun canon(k: String): String = when (k.trim().lowercase()) {
        "user-agent" -> "User-Agent"
        "referer", "referrer" -> "Referer"
        "origin" -> "Origin"
        else -> k.trim()
    }

    fun profiles(raw: String, hdrJson: String): List<Target> {
        val parts = raw.split("|", limit = 2)
        val url = parts[0].trim()
        val ex = LinkedHashMap<String, String>()
        if (parts.size > 1) parts[1].split("&").forEach { kv ->
            val i = kv.indexOf('=')
            if (i > 0) ex[canon(kv.substring(0, i))] = Uri.decode(kv.substring(i + 1))
        }
        try {
            val o = JSONObject(hdrJson)
            for (k in o.keys()) ex[canon(k)] = o.getString(k)
        } catch (e: Exception) { }
        val u = Uri.parse(url)
        val origin = if (u.scheme != null && u.host != null) u.scheme + "://" + u.authority else ""
        fun mk(name: String, ua: String?, ref: Boolean): Target {
            val h = LinkedHashMap(ex)
            if (ua != null && !h.containsKey("User-Agent")) h["User-Agent"] = ua
            if (ref && origin.isNotEmpty()) {
                if (!h.containsKey("Referer")) h["Referer"] = "$origin/"
                if (!h.containsKey("Origin")) h["Origin"] = origin
            }
            return Target(url, h, name)
        }
        val l = ArrayList<Target>()
        if (ex.isNotEmpty()) l.add(mk("özəl", null, false))
        l.add(mk("VLC", "VLC/3.0.20 LibVLC/3.0.20", false))
        l.add(mk("standart", null, false))
        l.add(mk("okhttp", "okhttp/4.12.0", false))
        l.add(mk("Chrome", CHROME, true))
        val g = good[url]
        val gi = l.indexOfFirst { it.name == g }
        if (gi > 0) l.add(0, l.removeAt(gi))
        return l
    }

    /** Qarışıq protokollu (http↔https) yönləndirmələri də izləyir. */
    fun connect(t: Target, range: String?, timeout: Int): HttpURLConnection {
        var cur = t.url
        repeat(6) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.connectTimeout = timeout; c.readTimeout = timeout; c.instanceFollowRedirects = false
            for ((k, v) in t.headers) c.setRequestProperty(k, v)
            if (range != null) c.setRequestProperty("Range", range)
            val code = c.responseCode
            if (code in 300..399 && code != 304) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc == null) throw IOException("redirect without location")
                cur = URL(URL(cur), loc).toString()
            } else return c
        }
        throw IOException("too many redirects")
    }

    /** Məzmun #EXTM3U ilə başlayırsa HLS-dir (uzantısı olmayan linklər üçün). */
    fun isHls(t: Target): Boolean {
        val c = connect(t, "bytes=0-31", 8000)
        try {
            val b = ByteArray(7); var r = 0
            c.inputStream.use { s ->
                while (r < 7) { val n = s.read(b, r, 7 - r); if (n < 0) break; r += n }
            }
            return String(b, 0, r) == "#EXTM3U"
        } finally { c.disconnect() }
    }

    /** Cavab gövdəsi HLS manifestidir (#EXT ilə başlayır)? HTML xəta səhifəsini "işləyir" saymamaq üçün. */
    private fun looksLikeHls(c: HttpURLConnection): Boolean {
        val b = ByteArray(16); var r = 0
        c.inputStream.use { s ->
            while (r < b.size) { val n = s.read(b, r, b.size - r); if (n < 0) break; r += n }
        }
        return String(b, 0, r, Charsets.UTF_8).trimStart('\uFEFF', ' ', '\t', '\r', '\n').startsWith("#EXT")
    }

    /**
     * Heç bir profil 2xx qaytarmırsa (qoşulma xətası və ya hər hansı HTTP xətası) "dead", əks halda "ok".
     * verifyHls=true olduqda .m3u8 linklərinin məzmunu da yoxlanılır (#EXTM3U ilə başlamalıdır).
     */
    fun probe(raw: String, hdrJson: String, verifyHls: Boolean = false): String {
        val path = try { Uri.parse(raw.split("|", limit = 2)[0].trim()).path?.lowercase() ?: "" } catch (e: Exception) { "" }
        val hls = verifyHls && path.endsWith(".m3u8")
        for (p in profiles(raw, hdrJson)) {
            try {
                val c = connect(p, "bytes=0-64", 9000)
                val code = c.responseCode
                var ok = code in 200..299
                if (ok && hls) ok = try { looksLikeHls(c) } catch (e: Exception) { false }
                c.disconnect()
                if (ok) { markGood(p.url, p.name); return "ok" }
            } catch (e: Exception) { return "dead" }
        }
        return "dead"
    }
}
