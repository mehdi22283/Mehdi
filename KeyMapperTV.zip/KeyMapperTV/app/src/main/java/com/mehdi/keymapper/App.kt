package com.mehdi.keymapper

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Adb.init(this)
    }
}
