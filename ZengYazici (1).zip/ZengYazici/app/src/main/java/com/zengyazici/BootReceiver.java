package com.zengyazici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Telefon yenidən başlayanda xidməti avtomatik işə salır (istifadəçi dayandırmayıbsa). */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!c.getSharedPreferences("cfg", 0).getBoolean("autostart", false)) return;
        try {
            c.startForegroundService(new Intent(c, RecService.class));
        } catch (Throwable e) {
            RecService.log("Boot: " + e);
        }
    }
}
