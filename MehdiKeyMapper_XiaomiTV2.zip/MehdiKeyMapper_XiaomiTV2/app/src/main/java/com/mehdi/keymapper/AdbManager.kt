package com.mehdi.keymapper

import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import kotlin.concurrent.thread

object AdbManager {
    const val TARGET_IP = "192.168.31.220"
    const val TARGET_PORT = 5555

    fun connectAndSetup(onResult: (Boolean, String) -> Unit) {
        val mainHandler = Handler(Looper.getMainLooper())
        thread {
            try {
                // Try executing root shell first if available
                val process = Runtime.getRuntime().exec("su")
                val os: OutputStream = process.outputStream

                val commands = arrayOf(
                    "settings put global app_standby_enabled 0",
                    "cmd appops set com.mehdi.keymapper RUN_IN_BACKGROUND allow",
                    "cmd appops set com.mehdi.keymapper RUN_ANY_IN_BACKGROUND allow",
                    "settings put secure enabled_accessibility_services com.mehdi.keymapper/.KeyMapperAccessibilityService",
                    "settings put secure accessibility_enabled 1"
                )

                for (cmd in commands) {
                    os.write("$cmd
".toByteArray())
                }
                os.write("exit
".toByteArray())
                os.flush()
                process.waitFor()

                mainHandler.post {
                    onResult(true, "ADB Qoşuldu & İcazələr verilmişdir ($TARGET_IP:$TARGET_PORT)")
                }
            } catch (e: Exception) {
                // Fallback to direct TCP connection command
                executeAdbOverTcp(mainHandler, onResult)
            }
        }
    }

    private fun executeAdbOverTcp(handler: Handler, onResult: (Boolean, String) -> Unit) {
        try {
            val process = Runtime.getRuntime().exec("adb connect $TARGET_IP:$TARGET_PORT")
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()

            handler.post {
                if (output.contains("connected") || process.exitValue() == 0) {
                    onResult(true, "ADB Şəbəkəyə qoşuldu ($TARGET_IP:$TARGET_PORT)")
                } else {
                    onResult(false, "ADB Xətası: $output")
                }
            }
        } catch (e: Exception) {
            handler.post {
                onResult(false, "ADB Qoşulma Xətası: ${e.localizedMessage}")
            }
        }
    }

    fun executeCommand(command: String) {
        thread {
            try {
                Runtime.getRuntime().exec(command)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
