1) Android Studio -> Open -> KeyMapperTV -> Build > Build APK(s)
2) adb connect 192.168.31.220:5555
   adb install -r app/build/outputs/apk/debug/app-debug.apk
3) TV: Settings > Accessibility > Downloaded apps > Key Mapper TV > ON
4) Ilk qosulmada TV-de "USB debugging icazesi" cixsa: "Always allow" secin.
