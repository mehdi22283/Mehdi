package az.callrec

import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class Rec(val file: File, val app: String, val dir: String, val label: String, val ts: Long, val dur: Int)

class RecAdapter(private val ctx: Context, private val onEmpty: (Boolean) -> Unit) : RecyclerView.Adapter<RecAdapter.VH>() {
    private var items = listOf<Rec>()
    private var mp: MediaPlayer? = null
    private var cur = -1
    private var dragging = false
    private val h = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

    private val tick = object : Runnable {
        override fun run() {
            val m = mp ?: return
            if (cur >= 0 && !dragging) notifyItemChanged(cur, "p")
            if (m.isPlaying) h.postDelayed(this, 300)
        }
    }

    fun reload() {
        Thread {
            val list = RecorderService.dir(ctx).listFiles { f -> f.name.endsWith(".m4a") }.orEmpty().mapNotNull { f ->
                val p = f.name.removeSuffix(".m4a").split("__")
                if (p.size < 4) return@mapNotNull null
                val d = try {
                    val mr = MediaMetadataRetriever()
                    mr.setDataSource(f.absolutePath)
                    val x = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toInt() ?: 0
                    mr.release(); x
                } catch (e: Exception) { 0 }
                Rec(f, p[1], p[2], p[3], p[0].toLongOrNull() ?: f.lastModified(), d)
            }.sortedByDescending { it.ts }
            Handler(Looper.getMainLooper()).post { items = list; notifyDataSetChanged(); onEmpty(list.isEmpty()) }
        }.start()
    }

    fun stop() { mp?.release(); mp = null; cur = -1; h.removeCallbacks(tick) }

    private fun toggle(pos: Int) {
        if (pos < 0) return
        if (pos == cur && mp != null) {
            val m = mp!!
            if (m.isPlaying) m.pause() else { m.start(); h.post(tick) }
            notifyItemChanged(pos, "p"); return
        }
        val old = cur
        stop()
        try {
            mp = MediaPlayer().apply {
                setDataSource(items[pos].file.absolutePath); prepare(); start()
                setOnCompletionListener { notifyItemChanged(pos, "p") }
            }
            cur = pos; h.post(tick)
        } catch (e: Exception) { }
        if (old >= 0) notifyItemChanged(old, "p")
        notifyItemChanged(pos, "p")
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val dir = v.findViewById<ImageView>(R.id.dir); val label = v.findViewById<TextView>(R.id.label)
        val app = v.findViewById<TextView>(R.id.app); val date = v.findViewById<TextView>(R.id.date)
        val play = v.findViewById<ImageButton>(R.id.play); val seek = v.findViewById<SeekBar>(R.id.seek)
        val time = v.findViewById<TextView>(R.id.time)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(LayoutInflater.from(p.context).inflate(R.layout.item_rec, p, false))
    override fun getItemCount() = items.size

    override fun onBindViewHolder(v: VH, pos: Int, payloads: MutableList<Any>) {
        val r = items[pos]
        val m = mp
        val active = pos == cur && m != null
        v.seek.max = r.dur.coerceAtLeast(1)
        v.seek.progress = if (active) m!!.currentPosition else 0
        v.play.setImageResource(if (active && m!!.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        v.time.text = "${mmss(if (active) m!!.currentPosition else 0)} / ${mmss(r.dur)}"
        if (payloads.isNotEmpty()) return
        v.label.text = r.label; v.app.text = r.app; v.date.text = fmt.format(Date(r.ts))
        v.dir.setImageResource(if (r.dir == "in") R.drawable.ic_in else R.drawable.ic_out)
        v.play.setOnClickListener { toggle(v.adapterPosition) }
        v.seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { if (user && v.adapterPosition == cur) mp?.seekTo(p) }
            override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar) { dragging = false }
        })
        v.itemView.setOnLongClickListener {
            AlertDialog.Builder(ctx).setMessage("Bu yazı silinsin?").setPositiveButton("Sil") { _, _ ->
                stop(); r.file.delete(); reload() }.setNegativeButton("Ləğv et", null).show(); true
        }
    }

    override fun onBindViewHolder(v: VH, pos: Int) = onBindViewHolder(v, pos, mutableListOf())
    private fun mmss(ms: Int) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)
}
