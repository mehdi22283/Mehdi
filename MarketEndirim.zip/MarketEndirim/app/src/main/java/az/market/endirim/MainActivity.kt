package az.market.endirim

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.view.View
import android.net.ConnectivityManager
import android.net.Network
import android.widget.Button
import androidx.activity.OnBackPressedCallback
import android.widget.EditText
import android.text.Editable
import android.text.TextWatcher
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import okhttp3.OkHttpClient
import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.recyclerview.widget.DiffUtil
import androidx.viewpager2.widget.ViewPager2
import kotlinx.coroutines.CoroutineScope
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette
import coil.Coil
import coil.ImageLoader
import coil.decode.SvgDecoder
import coil.load
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

class MainActivity : AppCompatActivity() {

    private companion object {
        const val PER_MARKET = 4   // bağlı kateqoriyada hər marketdən göstərilən məhsul sayı
        const val MAX_SHOWN = 300  // açıq kateqoriyada hər marketdən maksimum göstərilən məhsul sayı
        const val PER_CAT = 5      // PDF-in altındakı panelda hər kateqoriyada göstərilən məhsul sayı ("Daha çox" ilə hamısı)
    }

    private class Src(val name: String, val fn: suspend () -> List<Catalog>)

    private val order = listOf("Bravo Market", "Araz Market", "Oba Market", "Al Market", "Rahat Market", "Tamstore", "Bolmart")
    /** Jurnal mənbəyi olan marketlər (Bolmart-da yalnız başlıq + sosial linklər qalır). */
    private val withSource = setOf("Bravo Market", "Araz Market", "Oba Market", "Al Market", "Rahat Market", "Tamstore")
    /** Tarixi PDF-dən OCR ilə oxunan marketlər (tarixi tapılmayan jurnal siyahıdan silinir). */
    private val ocrDated = setOf("Tamstore", "Oba Market")

    /** Məhsul skanı bu sırayla gedir; siyahıda olmayan marketlər (Rahat və s.) axırda. */
    private val scanOrder = listOf("Araz Market", "Bravo Market", "Oba Market", "Al Market", "Tamstore")
    private fun scanRank(market: String): Int = scanOrder.indexOf(market).let { if (it < 0) scanOrder.size else it }
    /** Bravo PDF-i istifadəçi özü yükləyir — PDF olmayanda (yalnız slayd) flipbook-un yavaş skanı atlanır. */
    private val skipBravoWebScan = true
    private var seenBravoStamp = 0L

    /** Müddəti bitmiş jurnal (tarixi məlumdursa və artıq bitibsə) — yüklənmir, skan olunmur. */
    private fun isExpired(c: Catalog): Boolean = c.date?.let { DateUtil.info(it).state == 4 } == true
    private val results = HashMap<String, MarketResult>()
    private lateinit var adapter: CatalogAdapter
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var status: TextView
    private var loadJob: Job? = null
    private val expanded = LinkedHashSet<String>()
    private val cached = HashMap<String, List<Catalog>>()
    private val offline = HashSet<String>()
    private var thumbTick = 0
    private lateinit var search: EditText
    private lateinit var scanStatus: TextView
    private var products: List<Product> = emptyList()
    private var query = ""
    private val expandedCats = HashSet<String>()
    /** Bağlanmış başlıqlar: "g|Əsas kateqoriya", "c|Alt kateqoriya"; PDF panelində əvvəlinə "jurnalLinki|" qoyulur. */
    private val collapsed = HashSet<String>()
    // PDF-in altındakı panel (hər jurnal üçün ayrıca): axtarış mətni, açılmış kateqoriyalar, oxunmayan jurnallar
    private val panelQuery = HashMap<String, String>()
    private val panelOpen = HashSet<String>()          // "jurnalLinki|kateqoriya"
    private val scanFailed = HashSet<String>()
    private var panelJob: Job? = null
    private var scanJob: Job? = null
    private var scanning = false
    /** Skan gedən jurnalların hələ tam bitməmiş məhsulları (jurnal linki → indiyə qədər tapılanlar). */
    private val partial = HashMap<String, List<Product>>()
    private var scanPct = 0

    /** Yadda saxlanmış + skan gedən jurnalların indiyə qədər tapılmış məhsulları. */
    private fun refreshProducts() {
        products = if (partial.isEmpty()) ProductStore.all()
        else ProductStore.all().filter { it.catalogUrl !in partial.keys } + partial.values.flatten()
    }
    private var rescanNeeded = false
    private var searchFocused = false
    private var searchJob: Job? = null
    private var renderJob: Job? = null
    private var scanWanted = false      // istifadəçi mətn qutusuna toxunub — skana icazə var
    private lateinit var listView: RecyclerView
    private var scrollTopPending = false
    private var lastPartialRender = 0L
    private var netCb: ConnectivityManager.NetworkCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brand.init(applicationContext)
        Insta.purgeSaved(applicationContext)   // köhnə offline Instagram şəkilləri silinir
        // şəkillər diskdə 30 gün saxlanır ki, offline də açılsın
        val http = OkHttpClient.Builder().addNetworkInterceptor { chain ->
            chain.proceed(chain.request()).newBuilder()
                .removeHeader("Pragma").header("Cache-Control", "public, max-age=2592000").build()
        }.build()
        Coil.setImageLoader(ImageLoader.Builder(this).okHttpClient(http).components { add(SvgDecoder.Factory()) }.build())
        cached.putAll(Store.load(applicationContext))
        setContentView(R.layout.activity_main)
        swipe = findViewById(R.id.swipe)
        status = findViewById(R.id.status)
        adapter = CatalogAdapter(
            scope = lifecycleScope,
            onToggle = { c ->
                val u = c.urls[0]
                if (expanded.remove(u)) {
                    resetPanel(u)
                } else {
                    expanded.add(u)
                    startScan(scanWanted)      // açılan jurnalın məhsulları hələ yoxdursa yalnız o skan olunur
                }
                render()
            },
            onFull = { c ->
                startActivity(Intent(this, ViewerActivity::class.java).putExtra("catalog", c))
            },
            onProduct = { p -> openProduct(p) },
            onCat = { name ->
                if (!expandedCats.remove(name)) expandedCats.add(name)
                render()
            },
            onInsta = { startActivity(Intent(this, InstaBrowserActivity::class.java)) },
            onBravoPdf = { seenBravoStamp = BravoPdf.stamp; onBravoPdf() },
            onAll = {
                val urls = results.values.flatMap { it.catalogs }.map { it.urls[0] }
                if (urls.isNotEmpty() && expanded.containsAll(urls)) {
                    expanded.clear()
                    urls.forEach { resetPanel(it) }
                } else {
                    expanded.addAll(urls)
                    startScan(scanWanted)
                }
                render()
            },
            queryOf = { url -> panelQuery[url] ?: "" },
            onQuery = { url, q ->
                if (q.isEmpty()) panelQuery.remove(url) else panelQuery[url] = q
                panelJob?.cancel()
                panelJob = lifecycleScope.launch {
                    delay(120)
                    render()
                }
            },
            onCatMore = { url, cat ->
                val k = "$url|$cat"
                if (!panelOpen.remove(k)) panelOpen.add(k)
                render()
            },
            onCatProduct = { c, p -> openInPanel(c, p) },
            onSection = { k ->
                if (!collapsed.remove(k)) collapsed.add(k)
                render()
            }
        )
        val list = findViewById<RecyclerView>(R.id.list)
        listView = list
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        swipe.setOnRefreshListener { load() }
        swipe.setProgressBackgroundColorSchemeColor(0xFF1A1A1A.toInt())
        swipe.setColorSchemeColors(0xFFE53935.toInt())
        // məhsul axtarışı: qutuya toxunanda jurnallar skan edilir
        products = ProductStore.load(applicationContext)
        lifecycleScope.launch { ProductStore.rewriteIfNeeded(applicationContext) }
        search = findViewById(R.id.search)
        scanStatus = findViewById(R.id.scanStatus)
        search.setOnFocusChangeListener { _, has ->
            searchFocused = has
            scrollTopPending = true        // həmişə ən başdan göstər (siyahı qurulandan sonra)
            render()
            if (has) startScan()      // skan YALNIZ mətn qutusuna toxunanda başlayır
        }
        // toxunuşdan əvvəl artıq açıq idisə, təkrar toxunuş axtarışı bağlayır
        var focusedBeforeTouch = false
        search.setOnTouchListener { _, ev ->
            if (ev.action == android.view.MotionEvent.ACTION_DOWN) focusedBeforeTouch = search.hasFocus()
            false
        }
        search.setOnClickListener { if (focusedBeforeTouch) closeSearch() else startScan() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (searchFocused) {
                    closeSearch()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                searchJob?.cancel()
                searchJob = lifecycleScope.launch {
                    delay(60)
                    render()
                }
            }
        })
        search.setOnEditorActionListener { v, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
                true
            } else false
        }
        // internet qayıdanda avtomatik yenilə
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        netCb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread { if (offline.isNotEmpty()) load() }
            }
        }
        try { cm.registerDefaultNetworkCallback(netCb!!) } catch (e: Exception) { netCb = null }
        // logolar bir dəfə yüklənib yaddaşa yazılır — sonra offline işləyir
        lifecycleScope.launch { Brand.logos.keys.forEach { Brand.ensureLogo(applicationContext, it) } }
        load()
    }

    /** Məhsul axtarışını bağlayır: klaviatura gizlənir, yalnız jurnallar görünür. */
    private fun closeSearch() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
        findViewById<View>(R.id.root).requestFocus()
    }

    /** Jurnal bağlananda onun panel vəziyyəti (axtarış mətni, açılmış kateqoriyalar, səhifə) sıfırlanır. */
    private fun resetPanel(url: String) {
        panelQuery.remove(url)
        panelOpen.removeAll { it.startsWith("$url|") }
        collapsed.removeAll { it.startsWith("$url|") }
        adapter.forgetPage(url)
    }

    /** PDF-in altındakı məhsula toxunanda: həmin jurnal həmin səhifəyə keçir və ekranda göstərilir. */
    private fun openInPanel(c: Catalog, p: Product) {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(listView.windowToken, 0)
        currentFocus?.clearFocus()
        findViewById<View>(R.id.root).requestFocus()
        val url = c.urls[0]
        adapter.jumpTo(url, (p.page - 1).coerceAtLeast(0))
        listView.post {
            val pos = adapter.viewerPosition(url)
            if (pos >= 0) (listView.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(pos, 0)
        }
    }

    override fun onDestroy() {
        netCb?.let { try { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } catch (e: Exception) {} }
        adapter.releaseAll()
        super.onDestroy()
    }

    private fun load() {
        loadJob?.cancel()
        results.clear()
        offline.clear()
        // əvvəlki nəticələr dərhal göstərilir, yenisi gələndə əvəz olunur
        for ((m, cats0) in cached.entries.toList()) if (cats0.isNotEmpty()) {
            val cats = if (m == BravoPdf.MARKET) BravoPdf.apply(applicationContext, cats0).also { cached[m] = it } else cats0
            results[m] = MarketResult(m, cats, null)
        }
        render()
        swipe.isRefreshing = true
        status.text = if (Store.online(applicationContext)) "Jurnallar yenilənir…" else "Oflayn — son nəticələr göstərilir"
        loadJob = lifecycleScope.launch {
            val sources = listOf(
                Src("Bravo Market") { Sources.bravo() },
                Src("Araz Market") { Sources.araz() },
                Src("Oba Market") { Sources.oba() },
                Src("Al Market") { Sources.al() },
                Src("Rahat Market") { Sources.rahat() },
                Src("Tamstore") { Sources.tamstore() }
            )
            sources.map { s ->
                async {
                    val old = cached[s.name] ?: emptyList()
                    val r = try {
                        // tarixi əvvəlki nəticədən saxla (OCR təkrarlanmasın)
                        val fresh0 = s.fn().map { c ->
                            if (c.date != null) c else c.copy(date = old.firstOrNull { it.urls[0] == c.urls[0] }?.date)
                        }
                        // Bravo: yüklənmiş PDF varsa slaydın yerinə keçir; endirim bitibsə slayd qayıdır
                        val fresh = if (s.name == BravoPdf.MARKET) BravoPdf.apply(applicationContext, fresh0) else fresh0
                        cached[s.name] = fresh
                        offline.remove(s.name)
                        MarketResult(s.name, fresh, null)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        if (old.isNotEmpty()) {
                            offline.add(s.name)   // yeniləmək alınmadı — son nəticə qalır
                            MarketResult(s.name, if (s.name == BravoPdf.MARKET) BravoPdf.apply(applicationContext, old) else old, null)
                        } else MarketResult(s.name, emptyList(), e.message ?: e.javaClass.simpleName)
                    }
                    results[s.name] = r
                    persist()
                    render()
                }
            }.awaitAll()
            swipe.isRefreshing = false
            if (offline.isNotEmpty()) status.text = "Oflayn — son yadda saxlanan nəticələr göstərilir"
            launch { fillBravoDate() }
            downloadPdfs()
            startScan(scanWanted)    // ümumi skan yalnız mətn qutusuna toxunandan sonra; açıq jurnallar isə dərhal
        }
    }

    /** Tətbiqə girəndə bütün PDF-ləri endirir; tarixi olmayanlar üçün OCR edir. */
    private suspend fun downloadPdfs() {
        val pdfs = results.values.flatMap { it.catalogs }.filter { it.kind == Kind.PDF && !isExpired(it) }.map { it.urls[0] }.distinct()
        if (pdfs.isEmpty()) {
            status.text = ""
            return
        }
        var done = 0
        var failed = 0
        status.text = "PDF-lər yüklənir (0/${pdfs.size})"
        val sem = Semaphore(3)
        coroutineScope {
            pdfs.map { url ->
                async {
                    sem.withPermit {
                        try {
                            // eyni linkdə PDF dəyişibsə köhnəsi silinir, yenisi yüklənir və yenidən skan olunur
                            if (Store.online(applicationContext) && Downloader.refreshIfChanged(applicationContext, url)) onPdfChanged(url)
                            val f = Downloader.ensure(applicationContext, url)
                            fillDateByOcr(url, f)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            failed++
                        }
                    }
                    done++
                    status.text = "PDF-lər yüklənir ($done/${pdfs.size})"
                }
            }.awaitAll()
        }
        Downloader.cleanup(applicationContext, pdfs)
        Thumbs.cleanup(applicationContext, results.values.flatMap { it.catalogs }.map { it.urls[0] })
        status.text = if (offline.isNotEmpty()) "Oflayn — son yadda saxlanan nəticələr göstərilir"
        else "PDF-lər yükləndi" + if (failed > 0) " ($failed uğursuz)" else ""
    }

    private fun onPdfChanged(url: String) {
        products = ProductStore.all()
        val entry = results.entries.firstOrNull { e -> e.value.catalogs.any { it.urls[0] == url } }
        if (entry != null && entry.key in ocrDated) {
            // Tamstore/Oba tarixi OCR ilə oxunur — köhnə tarix atılır
            results[entry.key] = entry.value.copy(catalogs = entry.value.catalogs.map { if (it.urls[0] == url) it.copy(date = null) else it })
        }
        thumbTick++
        render()
    }

    private suspend fun fillDateByOcr(url: String, f: java.io.File) {
        val entry = results.entries.firstOrNull { e -> e.value.catalogs.any { it.urls[0] == url && it.date == null } } ?: return
        val market = entry.key
        val d = Ocr.pdfDate(applicationContext, f)
        if (d != null && market == BravoPdf.MARKET) BravoPdf.setDate(applicationContext, d)
        val isTam = market == "Tamstore"
        if (d == null && !isTam) return
        val cur = results[market] ?: return
        results[market] = cur.copy(
            catalogs = if (d == null) cur.catalogs.filter { it.urls[0] != url }   // Tamstore: tarixi tapılmayanlar silinir (Oba istisnadır — tarixi olmasa da qalır)
            else cur.catalogs.map { if (it.urls[0] == url) it.copy(date = d) else it }
        )
        persist()
        render()
    }

    override fun onResume() {
        super.onResume()
        // tam ekran slayddan (ViewerActivity) PDF yüklənib qayıdıbsa — siyahı yenilənir
        if (BravoPdf.stamp != seenBravoStamp) {
            seenBravoStamp = BravoPdf.stamp
            onBravoPdf()
        }
    }

    /** Bravo PDF-i yüklənib: slayd PDF ilə əvəz olunur (açıq slayd bağlanmır), PDF yenidən skan olunur. */
    private fun onBravoPdf() {
        val name = BravoPdf.MARKET
        val cur = results[name]?.catalogs ?: cached[name] ?: return
        val oldUrls = cur.map { it.urls[0] }
        val fresh = BravoPdf.apply(applicationContext, cur)
        results[name] = MarketResult(name, fresh, null)
        persist()
        // slayd açıq idisə, PDF də açıq qalsın
        val newUrl = fresh.firstOrNull()?.urls?.get(0)
        if (newUrl != null && oldUrls.any { it in expanded && it != newUrl }) {
            expanded.removeAll(oldUrls.toSet())
            expanded.add(newUrl)
        }
        lifecycleScope.launch {
            ProductStore.forget(applicationContext, BravoPdf.LOCAL)   // köhnə PDF-in skanı atılır
            products = ProductStore.all()
            thumbTick++
            render()
            val f = BravoPdf.file(applicationContext)
            if (f.exists() && fresh.any { BravoPdf.isLocal(it) && it.date == null }) fillDateByOcr(BravoPdf.LOCAL, f)
            startScan(scanWanted)
        }
    }

    /** Bravo: tarix slaydın içindədir; səhifəni gizli WebView-da açıb ekran görüntüsündən OCR ilə oxuyur. */
    private suspend fun fillBravoDate() {
        val r = results["Bravo Market"] ?: return
        val c = r.catalogs.firstOrNull { it.kind == Kind.WEB && (it.date == null || !Thumbs.exists(applicationContext, it.urls[0])) } ?: return
        val d = try {
            BravoDate.read(this, c.urls[0])
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        } ?: return
        val cur = results["Bravo Market"] ?: return
        results["Bravo Market"] = cur.copy(catalogs = cur.catalogs.map { if (it.urls[0] == c.urls[0]) it.copy(date = d) else it })
        persist()
        thumbTick++   // miniatür hazırdır — zolağı yenilə
        render()
    }

    /** Tarixlər də daxil olmaqla cari nəticələri diskə yazır. */
    private fun persist() {
        for ((m, r) in results) if (r.error == null && r.catalogs.isNotEmpty()) cached[m] = r.catalogs
        Store.save(applicationContext, cached)
    }

    /** Başlıqda göstəriləcək tarix: bitməyənlərdən ən gec bitəni (hamısı bitibsə ən son bitəni). */
    private fun headerDate(cats: List<Catalog>): String? {
        val dated = cats.mapNotNull { c -> c.date?.let { it to DateUtil.info(it) } }
        if (dated.isEmpty()) return null
        val pool = dated.filter { it.second.state != 4 }.ifEmpty { dated }
        return pool.maxByOrNull { it.second.endMs }?.first
    }

    private fun render() {
        if (searchFocused) {          // axtarış açıqdırsa yalnız məhsul kateqoriyaları görünür
            renderSearch()
            return
        }
        renderJob?.cancel()
        val rows = ArrayList<Row>()
        val scanned = ProductStore.scannedUrls()
        val allUrls = results.values.flatMap { it.catalogs }.map { it.urls[0] }
        rows.add(
            Row(
                Row.TITLE, "", "Endirim jurnalları", null,
                if (allUrls.isEmpty()) null else if (expanded.containsAll(allUrls)) "Hamısını bağla" else "Hamısını aç",
                null
            )
        )
        for (name in order) {
            val r = results[name]
            val cats = r?.catalogs ?: emptyList()
            // market başlığı (logo + ad); tarix adın yanında: bir neçə jurnal olanda ən aktual olanın tarixi
            rows.add(Row(Row.HEADER, name, name, if (r != null && r.error == null) headerDate(cats) else null, null, null))
            when {
                name !in withSource -> Unit   // Bolmart: başlığın altında heç nə göstərilmir
                r == null -> rows.add(Row(Row.ITEM, name, "Yüklənir…", null, null, null))
                r.error != null -> rows.add(Row(Row.ITEM, name, "Yüklənmədi", null, r.error, null))
                cats.isEmpty() -> rows.add(Row(Row.ITEM, name, "Jurnal tapılmadı", null, null, null))
                else -> {
                    // yazı siyahısı əvəzinə miniatür zolağı
                    rows.add(
                        Row(
                            Row.STRIP, name, name, null, null, null,
                            catalogs = cats,
                            selected = cats.map { it.urls[0] }.filter { it in expanded }.toSet(),
                            tick = thumbTick
                        )
                    )
                    cats.forEach { c ->
                        if (c.urls[0] in expanded) {
                            rows.add(Row(Row.VIEWER, name, c.title, null, null, c))
                            rows.addAll(panelRows(c, scanned))      // PDF-in altında: axtarış + kateqoriyalar + məhsullar
                        }
                    }
                }
            }
        }
        adapter.submit(rows) { afterSubmit() }
    }

    /**
     * Açıq jurnalın PDF-inin altındakı panel: axtarış qutusu → kateqoriyalar → hər kateqoriyada ən çox PER_CAT məhsul
     * (qalanı "Daha çox" ilə). Məhsullar jurnaldakı səhifə sırası ilə gedir; toxunanda PDF həmin səhifəyə keçir.
     */
    private fun panelRows(c: Catalog, scannedUrls: Set<String>): List<Row> {
        val url = c.urls[0]
        val out = ArrayList<Row>()
        if (c.kind == Kind.WEB) {
            out.add(Row(Row.HINT, c.market, "Veb-jurnal üçün məhsul siyahısı yoxdur — PDF yüklədikdən sonra kateqoriyalar burada görünəcək.", null, null, c))
            return out
        }
        val mine = products.filter { it.catalogUrl == url && it.cat != Categorizer.OTHER }.distinctBy { it.dkey }
        val tokens = Categorizer.norm(panelQuery[url] ?: "").split(' ', '\t').filter { it.isNotEmpty() }
        val searching = tokens.isNotEmpty()
        val matched = if (!searching) mine else mine.filter { p -> tokens.all { p.key.contains(it) } }
        val isScanned = url in scannedUrls
        val busy = scanning && !isScanned          // skan gedir (və ya növbədədir)

        val info = when {
            busy -> "Məhsullar skan edilir… $scanPct%" + if (mine.isNotEmpty()) " · ${mine.size} məhsul tapıldı" else ""
            mine.isEmpty() -> null
            searching -> "${matched.size} / ${mine.size} məhsul"
            else -> "${mine.size} məhsul"
        }
        out.add(Row(Row.CSEARCH, c.market, "", null, info, c, count = mine.size))

        if (mine.isEmpty()) {
            val msg = when {
                busy -> null
                isExpired(c) -> "Müddəti bitmiş jurnal — məhsullar skan edilmir."
                url in scanFailed -> "Bu jurnaldan məhsul oxunmadı."
                isScanned -> "Bu jurnalda məhsul tapılmadı."
                else -> "Məhsul siyahısı hazırlanır…"
            }
            if (msg != null) out.add(Row(Row.HINT, c.market, msg, null, null, c))
            return out
        }
        if (matched.isEmpty()) {
            out.add(Row(Row.HINT, c.market, "“${(panelQuery[url] ?: "").trim()}” bu jurnalda tapılmadı", null, null, c))
            return out
        }

        val first = tokens.firstOrNull()
        fun rank(p: Product): Int = when {
            first == null -> 0
            p.key.startsWith(first) -> 0
            p.key.contains(" $first") -> 1
            else -> 2
        }
        val cmp = compareBy<Product>({ it.top }, { rank(it) }, { it.page }, { it.sortKey })
        val byCat = matched.groupBy { it.cat }
        for ((group, subs) in Categorizer.GROUPS) {
            val total = subs.sumOf { byCat[it]?.size ?: 0 }
            if (total == 0) continue
            val gClosed = "$url|g|$group" in collapsed
            out.add(Row(Row.GROUP, "", group, null, null, c, count = total, open = !gClosed))
            if (gClosed) continue
            for (cat in subs) {
                val list = byCat[cat] ?: continue
                val sorted = list.sortedWith(cmp)
                val open = "$url|$cat" in panelOpen
                val cClosed = "$url|c|$cat" in collapsed
                out.add(Row(Row.PCAT, "", cat, null, null, c, count = list.size, open = !cClosed))
                if (cClosed) continue
                for (p in (if (open) sorted else sorted.take(PER_CAT))) {
                    out.add(Row(Row.PROD, c.market, p.display, null, "səh. ${p.page}", c, product = p))
                }
                if (list.size > PER_CAT) {
                    out.add(Row(Row.PMORE, "", cat, null, "Daha çox (${list.size - PER_CAT})", c, count = list.size, open = open))
                }
            }
        }
        return out
    }

    private fun afterSubmit() {
        if (scrollTopPending) {
            scrollTopPending = false
            listView.scrollToPosition(0)
        }
    }

    // ---------------- məhsul axtarışı və skan ----------------

    private fun setScan(text: String) {
        scanStatus.text = text
        scanStatus.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    /** Axtarışı arxa axında hesablayır (yazı yazılarkən ekran donmasın); yeni sorğu gələndə köhnəsi ləğv olunur. */
    private fun renderSearch() {
        renderJob?.cancel()
        val snap = products
        val q = query
        val open = HashSet(expandedCats)
        val col = HashSet(collapsed)
        val sc = scanning
        val pct = scanPct
        renderJob = lifecycleScope.launch {
            val rows = withContext(Dispatchers.Default) { productRows(snap, q, open, col, sc, pct) }
            adapter.submit(rows) { afterSubmit() }
        }
    }

    /**
     * Axtarış YALNIZ məhsul adına görə gedir (kateqoriya adına görə yox): sözlərin hamısı adda olmalıdır.
     * Nəticə: kateqoriya → market → məhsul. Açar (Product.key) əvvəlcədən hesablanıb — ə→e, ı→i, ş→s... fərq etmir.
     */
    private fun productRows(src0: List<Product>, q: String, openCats: Set<String>, closed: Set<String>, sc: Boolean, pct: Int): List<Row> {
        val tokens = Categorizer.norm(q).split(' ', '\t').filter { it.isNotEmpty() }
        val searching = tokens.isNotEmpty()
        val seen = HashSet<String>()
        val src = ArrayList<Product>()
        for (p in src0) {
            if (p.cat == Categorizer.OTHER) continue      // "Digər" kateqoriyası göstərilmir
            if (searching) {
                var all = true
                for (t in tokens) if (!p.key.contains(t)) { all = false; break }
                if (!all) continue
            }
            if (seen.add(p.market + "|" + p.dkey)) src.add(p)      // eyni market + eyni ad (durğu/boşluq fərqi nəzərə alınmadan) bir dəfə
        }
        if (src.isEmpty()) {
            val msg = when {
                searching && sc -> "“${q.trim()}” hələ tapılmadı — skan davam edir ($pct%)…"
                searching -> "“${q.trim()}” tapılmadı"
                sc -> "Məhsullar skan edilir… $pct%"
                else -> "Hələ məhsul yoxdur — jurnallar yükləndikdən sonra avtomatik skan olunacaq."
            }
            return listOf(Row(Row.HINT, "", msg, null, null, null))
        }
        val rows = ArrayList<Row>(minOf(src.size, 2000) + 64)
        if (sc) rows.add(Row(Row.HINT, "", "Skan davam edir: $pct% · ${src0.size} məhsul tapıldı", null, null, null))
        val byCat = HashMap<String, MutableList<Product>>()
        for (p in src) byCat.getOrPut(p.cat) { ArrayList() }.add(p)
        val first = tokens.firstOrNull()
        // axtarışda adı sorğu ilə başlayanlar öndə, sonra söz başında olanlar, sonra qalanlar; sonra əlifba sırası
        fun rank(p: Product): Int = when {
            first == null -> 0
            p.key.startsWith(first) -> 0
            p.key.contains(" $first") -> 1
            else -> 2
        }
        val cmp = compareBy<Product>({ it.top }, { rank(it) }, { it.sortKey })
        for ((group, subs) in Categorizer.GROUPS) {
            val total = subs.sumOf { byCat[it]?.size ?: 0 }
            if (total == 0) continue
            val gClosed = "g|$group" in closed
            rows.add(Row(Row.GROUP, "", group, null, null, null, count = total, open = !gClosed))
            if (gClosed) continue
            for (cat in subs) {
                val list = byCat[cat] ?: continue
                val open = searching || cat in openCats
                val cClosed = "c|$cat" in closed
                rows.add(Row(Row.PCAT, "", cat, null, null, null, count = list.size, open = !cClosed))
                if (cClosed) continue
                val byMarket = list.groupBy { it.market }
                var overflow = false
                for (m in order) {
                    val ps = byMarket[m] ?: continue
                    if (ps.size > PER_MARKET) overflow = true
                    rows.add(Row(Row.PMARKET, m, m, null, cat, null, count = ps.size))
                    val shown = if (open) ps.sortedWith(cmp).take(MAX_SHOWN) else ps.sortedWith(cmp).take(PER_MARKET)
                    for (p in shown) rows.add(Row(Row.PROD, m, p.display, null, null, null, product = p))
                }
                if (!searching && overflow) rows.add(Row(Row.PMORE, "", cat, null, null, null, count = list.size, open = open))
            }
        }
        return rows
    }

    /** Məhsulun tapıldığı jurnalı həmin səhifədə açır. */
    private fun openProduct(p: Product) {
        val c = results.values.flatMap { it.catalogs }.firstOrNull { it.urls[0] == p.catalogUrl }
            ?: cached.values.flatten().firstOrNull { it.urls[0] == p.catalogUrl }
            ?: p.catalogUrl.let { u ->
                // jurnal siyahıda yoxdursa, PDF-lər linkdən bərpa olunur
                if (u == BravoPdf.LOCAL || u.substringBefore('?').endsWith(".pdf", true)) Catalog(p.market, p.market, null, Kind.PDF, listOf(u)) else null
            }
        if (c == null) {
            Toast.makeText(this, "Jurnal siyahıda tapılmadı — siyahını yeniləyin", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(
            Intent(this, ViewerActivity::class.java)
                .putExtra("catalog", c)
                .putExtra("page", p.page - 1)
                .putExtra("product", p.display)
        )
    }

    /** Hələ skan edilməmiş və ya dəyişmiş jurnalları OCR ilə oxuyur (nəticələr yadda qalır). */
    private fun startScan(all: Boolean = true) {
        // all=true — axtarış qutusuna toxunulub: bütün jurnallar; all=false — yalnız PDF-i açılmış jurnallar skan olunur
        if (all) scanWanted = true
        if (scanning) {
            rescanNeeded = true
            return
        }
        val cats = results.values.flatMap { it.catalogs }.filter { !isExpired(it) }.distinctBy { it.urls[0] }
        if (cats.isEmpty()) {
            // jurnallar var, amma hamısının müddəti bitib — köhnə skan nəticələri təmizlənir
            // (jurnal siyahısı hələ boşdursa — məs. oflayn — heç nə silinmir)
            if (results.values.any { it.catalogs.isNotEmpty() }) lifecycleScope.launch {
                ProductStore.cleanup(applicationContext, emptySet())
                products = ProductStore.all()
                render()
            }
            return
        }
        val done = ProductStore.scannedUrls()
        val todo = cats.filter { c ->
            val u = c.urls[0]
            u !in done || ProductScanner.sigFor(applicationContext, c).let { it != null && it != ProductStore.sigOf(u) }
        }.filter { !(skipBravoWebScan && it.kind == Kind.WEB) }
            .filter { scanWanted || it.urls[0] in expanded }
            // açıq jurnallar birinci, sonra: Araz → Bravo → Oba → Al → Tamstore → digərləri
            .sortedWith(compareBy<Catalog>({ if (it.urls[0] in expanded) 0 else 1 }, { scanRank(it.market) }))
        if (todo.isEmpty()) {
            setScan("")
            return
        }
        scanning = true
        scanJob = lifecycleScope.launch {
            var failed = 0
            try {
                scanPct = 0
                render()
                // ümumi faiz: bütün jurnalların səhifə sayına görə
                val totals = todo.map { ProductScanner.estimatePages(applicationContext, it) }
                val grand = totals.sum().coerceAtLeast(1)
                var doneBefore = 0
                val marketNames = todo.map { it.market }.distinct()
                for ((i, c) in todo.withIndex()) {
                    // marketlər ardıcıl skan olunur; hər marketin nəticəsi bitən kimi axtarışda görünür
                    val tag = "${c.market} (${marketNames.indexOf(c.market) + 1}/${marketNames.size})"
                    fun pct(page: Int): Int = ((doneBefore + minOf(page, totals[i])) * 100 / grand).coerceIn(0, 99)
                    scanPct = pct(0)
                    scanFailed.remove(c.urls[0])
                    setScan("Məhsullar skan edilir: $scanPct% · $tag")
                    try {
                        val list = ProductScanner.scan(this@MainActivity, c, { p, n ->
                            scanPct = pct(p - 1)
                            setScan("Məhsullar skan edilir: $scanPct% · $tag · səhifə $p" + if (n > 0) "/$n" else "")
                        }, { part ->
                            // səhifə oxunan kimi tapılan məhsullar axtarışda dərhal görünür
                            partial[c.urls[0]] = part
                            refreshProducts()
                            // hər səhifədən sonra deyil, ən çox 0,7 saniyədə bir dəfə yenilənir (axtarış donmasın)
                            val now = android.os.SystemClock.uptimeMillis()
                            if ((searchFocused || c.urls[0] in expanded) && now - lastPartialRender > 700) {
                                lastPartialRender = now
                                render()
                            }
                        })
                        if (c.kind == Kind.WEB && list.isEmpty()) {
                            failed++    // flipbook oxunmadı — növbəti dəfə yenidən cəhd olunsun
                            scanFailed.add(c.urls[0])
                        } else {
                            ProductStore.put(applicationContext, c.urls[0], c.market, list, ProductScanner.sigFor(applicationContext, c))
                            partial.remove(c.urls[0])
                            refreshProducts()
                            render()
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        failed++
                        scanFailed.add(c.urls[0])
                    }
                    partial.remove(c.urls[0])         // oxunmayan jurnalın yarımçıq nəticələri atılır
                    doneBefore += totals[i]
                    scanPct = (doneBefore * 100 / grand).coerceIn(0, 100)
                }
                partial.clear()
                // köhnə jurnalların məhsulları yalnız bütün marketlər uğurla yenilənibsə silinir —
                // oflayn / xətalı vəziyyətdə yadda saxlanmış nəticələr toxunulmaz qalır
                if (offline.isEmpty() && results.values.none { it.error != null }) {
                    ProductStore.cleanup(applicationContext, results.values.flatMap { it.catalogs }.filter { !isExpired(it) }.map { it.urls[0] }.toSet())
                }
                refreshProducts()
                scanPct = 100
                setScan(if (failed > 0) "Skan: $failed jurnal oxunmadı" else "")
            } finally {
                scanning = false
                if (partial.isNotEmpty()) { partial.clear(); refreshProducts() }
                render()
            }
            if (rescanNeeded) {
                rescanNeeded = false
                startScan(scanWanted)
            }
        }
    }
}

class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
    val card: com.google.android.material.card.MaterialCardView = v.findViewById(R.id.headerCard)
    val logo: android.widget.ImageView = v.findViewById(R.id.logo)
    val letter: TextView = v.findViewById(R.id.logoLetter)
    val name: TextView = v.findViewById(R.id.hName)
    val date: TextView = v.findViewById(R.id.hDate)
    val socials: android.widget.LinearLayout = v.findViewById(R.id.socials)
    var boundMarket: String = ""
}

class ItemVH(v: View) : RecyclerView.ViewHolder(v) {
    val title: TextView = v.findViewById(R.id.tvTitle)
    val sub: TextView = v.findViewById(R.id.tvSub)
    val dateRow: View = v.findViewById(R.id.dateRow)
    val date: TextView = v.findViewById(R.id.tvDate)
    val status: TextView = v.findViewById(R.id.tvStatus)
}

/** Başlığın altında açılan slayd: şəkil / PDF səhifələri / veb-jurnal. */
class ViewerVH(v: View) : RecyclerView.ViewHolder(v) {
    val box: View = v.findViewById(R.id.viewerBox)
    val pager: ViewPager2 = v.findViewById(R.id.vPager)
    val web: WebView = v.findViewById(R.id.vWeb)
    val progress: ProgressBar = v.findViewById(R.id.vProgress)
    val counter: TextView = v.findViewById(R.id.vCounter)
    val full: TextView = v.findViewById(R.id.vFull)
    var pdf: PdfAdapter? = null
    var job: Job? = null
    var pageCb: ViewPager2.OnPageChangeCallback? = null
    var boundUrl: String = ""      // hazırda bu slaydda açıq jurnalın linki (panelden səhifəyə keçid üçün)

    fun release() {
        job?.cancel()
        job = null
        pageCb?.let { pager.unregisterOnPageChangeCallback(it) }
        pageCb = null
        pager.adapter = null
        pdf?.close()
        pdf = null
        web.stopLoading()
        web.loadUrl("about:blank")
        web.visibility = View.GONE
        pager.visibility = View.VISIBLE
        progress.visibility = View.GONE
    }
}

class PCatVH(v: View) : RecyclerView.ViewHolder(v) {
    val title: TextView = v.findViewById(R.id.pcTitle)
}

class GroupVH(v: View) : RecyclerView.ViewHolder(v) {
    val title: TextView = v.findViewById(R.id.grTitle)
}

class PMarketVH(v: View) : RecyclerView.ViewHolder(v) {
    val name: TextView = v.findViewById(R.id.pmName)
}

class ProdVH(v: View) : RecyclerView.ViewHolder(v) {
    val name: TextView = v.findViewById(R.id.prodName)
}

class CSearchVH(v: View) : RecyclerView.ViewHolder(v) {
    val edit: EditText = v.findViewById(R.id.csEdit)
    val info: TextView = v.findViewById(R.id.csInfo)
    var watcher: TextWatcher? = null
}

class PMoreVH(v: View) : RecyclerView.ViewHolder(v) {
    val text: TextView = v.findViewById(R.id.pmoreText)
}

class HintVH(v: View) : RecyclerView.ViewHolder(v) {
    val text: TextView = v.findViewById(R.id.hintText)
}

class TitleVH(v: View) : RecyclerView.ViewHolder(v) {
    val insta: Button = v.findViewById(R.id.btnInsta)
    val all: Button = v.findViewById(R.id.btnAll)
}

class StripVH(v: View) : RecyclerView.ViewHolder(v) {
    val list: RecyclerView = v.findViewById(R.id.thumbs)
    lateinit var adapter: ThumbAdapter
}

class ThumbVH(v: View) : RecyclerView.ViewHolder(v) {
    val card: com.google.android.material.card.MaterialCardView = v.findViewById(R.id.thumbCard)
    val img: android.widget.ImageView = v.findViewById(R.id.thumbImg)
    val badge: View = v.findViewById(R.id.badge)
    val date: TextView = v.findViewById(R.id.bDate)
    val status: TextView = v.findViewById(R.id.bStatus)
    var job: Job? = null
    var boundUrl: String = ""
}

/** Bir marketin jurnallarının miniatürləri (üfüqi zolaq). */
class ThumbAdapter(
    private val scope: CoroutineScope,
    private val onClick: (Catalog) -> Unit
) : RecyclerView.Adapter<ThumbVH>() {
    private var items: List<Catalog> = emptyList()
    private var selected: Set<String> = emptySet()

    fun submit(list: List<Catalog>, sel: Set<String>) {
        items = list
        selected = sel
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ThumbVH(LayoutInflater.from(parent.context).inflate(R.layout.item_thumb, parent, false))

    override fun onViewRecycled(holder: ThumbVH) {
        holder.job?.cancel()
        holder.job = null
    }

    override fun onBindViewHolder(h: ThumbVH, position: Int) {
        val c = items[position]
        val ctx = h.itemView.context
        val dens = ctx.resources.displayMetrics.density
        h.job?.cancel()
        h.boundUrl = c.urls[0]
        val sel = c.urls[0] in selected
        h.card.strokeColor = if (sel) ctx.getColor(R.color.accent) else ctx.getColor(R.color.amoled_stroke)
        h.card.strokeWidth = ((if (sel) 3 else 1) * dens).toInt()
        h.itemView.setOnClickListener { onClick(c) }

        // tarix nişanı: tarix + rəngli status
        val d = c.date
        if (d != null) {
            val info = DateUtil.info(d)
            h.badge.visibility = View.VISIBLE
            h.date.text = info.label
            h.status.text = info.status ?: ""
            h.status.setTextColor(DateUtil.stateColor(info.state))
            h.status.visibility = if (info.status == null) View.GONE else View.VISIBLE
        } else {
            h.badge.visibility = View.GONE
        }

        // miniatür
        h.img.scaleType = android.widget.ImageView.ScaleType.CENTER
        h.img.setImageResource(R.drawable.ic_catalog)
        fun show(src: Any) {
            h.img.load(src) {
                crossfade(true)
                listener(onSuccess = { _, _ -> h.img.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP })
            }
        }
        when (c.kind) {
            Kind.IMAGES -> show(c.urls[0])
            else -> h.job = scope.launch {
                val f = Thumbs.get(ctx.applicationContext, c)
                if (f != null && h.boundUrl == c.urls[0]) show(f)
            }
        }
    }
}

class CatalogAdapter(
    private val scope: CoroutineScope,
    private val onToggle: (Catalog) -> Unit,
    private val onFull: (Catalog) -> Unit,
    private val onProduct: (Product) -> Unit,
    private val onCat: (String) -> Unit,
    private val onInsta: () -> Unit,
    private val onBravoPdf: () -> Unit,
    private val onAll: () -> Unit,
    private val queryOf: (String) -> String,
    private val onQuery: (String, String) -> Unit,
    private val onCatMore: (String, String) -> Unit,
    private val onCatProduct: (Catalog, Product) -> Unit,
    private val onSection: (String) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var rows: List<Row> = emptyList()
    private val viewers = HashSet<ViewerVH>()
    /** Hər açıq jurnalın hazırkı səhifəsi (slayd yenidən qurulanda və ya panelden keçəndə saxlanır). */
    private val pageOf = HashMap<String, Int>()

    fun forgetPage(url: String) { pageOf.remove(url) }

    fun viewerPosition(url: String): Int =
        rows.indexOfFirst { it.type == Row.VIEWER && it.catalog?.urls?.get(0) == url }

    /** Jurnalı verilən səhifəyə keçirir (0-dan başlayır). Slayd hələ yüklənməyibsə, yüklənəndə həmin səhifədən açılır. */
    fun jumpTo(url: String, page: Int) {
        pageOf[url] = page
        val h = viewers.firstOrNull { it.boundUrl == url } ?: return
        val a = h.pager.adapter ?: return
        if (page in 0 until a.itemCount) {
            h.pager.setCurrentItem(page, false)
            h.counter.text = "${page + 1}/${a.itemCount}"
        }
    }

    private fun scopeOf(r: Row) = r.catalog?.urls?.get(0) ?: ""

    private fun sectionKey(r: Row): String {
        val scope = r.catalog?.urls?.get(0)?.let { "$it|" } ?: ""
        return scope + (if (r.type == Row.GROUP) "g|" else "c|") + r.title
    }

    private fun key(r: Row) = when (r.type) {
        Row.HEADER -> "h|" + r.market
        Row.STRIP -> "s|" + r.market
        Row.ITEM -> "i|" + r.market + "|" + (r.catalog?.urls?.get(0) ?: r.title)
        Row.GROUP -> "gr|" + scopeOf(r) + "|" + r.title
        Row.PCAT -> "pc|" + scopeOf(r) + "|" + r.title
        Row.PMARKET -> "pm|" + r.sub + "|" + r.market
        Row.PROD -> "pp|" + scopeOf(r) + "|" + (r.product?.catalogUrl ?: "") + "|" + (r.product?.dkey ?: r.title)
        Row.PMORE -> "pmo|" + scopeOf(r) + "|" + r.title
        Row.HINT -> "ph|" + scopeOf(r)
        Row.CSEARCH -> "cs|" + scopeOf(r)
        Row.TITLE -> "t"
        else -> "v|" + r.market + "|" + (r.catalog?.urls?.get(0) ?: "")
    }

    private var submitGen = 0

    /**
     * Kiçik siyahılar dərhal, böyük (axtarış nəticələri) isə arxa axında müqayisə olunur — ekran donmur.
     * Yeni submit gələndə yarımçıq köhnəsi atılır. after — siyahı tətbiq olunandan sonra çağrılır.
     */
    fun submit(r: List<Row>, after: (() -> Unit)? = null) {
        val gen = ++submitGen
        val old = rows
        fun callback() = object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = r.size
            override fun areItemsTheSame(a: Int, b: Int) = key(old[a]) == key(r[b])
            // slayd sətri tarix dəyişəndə yenidən qurulmasın (səhifə sıfırlanmasın)
            override fun areContentsTheSame(a: Int, b: Int) =
                if (old[a].type == Row.VIEWER) true else old[a] == r[b]
        }
        if (old.size < 150 && r.size < 150) {
            val diff = DiffUtil.calculateDiff(callback())
            rows = r
            diff.dispatchUpdatesTo(this)
            after?.invoke()
            return
        }
        scope.launch {
            val diff = withContext(Dispatchers.Default) { DiffUtil.calculateDiff(callback(), false) }
            if (gen != submitGen) return@launch
            rows = r
            diff.dispatchUpdatesTo(this@CatalogAdapter)
            after?.invoke()
        }
    }

    fun releaseAll() {
        viewers.toList().forEach { it.release() }
        viewers.clear()
    }

    override fun getItemViewType(position: Int) = rows[position].type
    override fun getItemCount() = rows.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return when (viewType) {
            Row.HEADER -> HeaderVH(inf.inflate(R.layout.item_header, parent, false))
            Row.VIEWER -> ViewerVH(inf.inflate(R.layout.item_viewer, parent, false))
            Row.GROUP -> GroupVH(inf.inflate(R.layout.item_group, parent, false))
            Row.PCAT -> PCatVH(inf.inflate(R.layout.item_pcat, parent, false))
            Row.PMARKET -> PMarketVH(inf.inflate(R.layout.item_pmarket, parent, false))
            Row.PROD -> ProdVH(inf.inflate(R.layout.item_prod, parent, false))
            Row.PMORE -> PMoreVH(inf.inflate(R.layout.item_pmore, parent, false))
            Row.CSEARCH -> CSearchVH(inf.inflate(R.layout.item_csearch, parent, false)).also { vh ->
                vh.edit.setOnEditorActionListener { v, id, _ ->
                    if (id == EditorInfo.IME_ACTION_SEARCH) {
                        (v.context.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                            .hideSoftInputFromWindow(v.windowToken, 0)
                        true
                    } else false
                }
            }
            Row.HINT -> HintVH(inf.inflate(R.layout.item_hint, parent, false))
            Row.TITLE -> TitleVH(inf.inflate(R.layout.item_title, parent, false))
            Row.STRIP -> StripVH(inf.inflate(R.layout.item_strip, parent, false)).also { vh ->
                vh.list.layoutManager = LinearLayoutManager(parent.context, LinearLayoutManager.HORIZONTAL, false)
                vh.adapter = ThumbAdapter(scope, onToggle)
                vh.list.adapter = vh.adapter
            }
            else -> ItemVH(inf.inflate(R.layout.item_catalog, parent, false))
        }
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
        val row = rows[position]
        when (h) {
            is HeaderVH -> bindHeader(h, row)
            is ItemVH -> bindItem(h, row)
            is ViewerVH -> bindViewer(h, row)
            is StripVH -> h.adapter.submit(row.catalogs, row.selected)
            is GroupVH -> {
                h.title.text = (if (row.open) "▾  " else "▸  ") + Categorizer.withEmoji(row.title) + "  ·  " + row.count + " məhsul"
                h.itemView.setOnClickListener { onSection(sectionKey(row)) }
            }
            is PCatVH -> {
                h.title.text = (if (row.open) "▾  " else "▸  ") + Categorizer.withEmoji(row.title) + "  ·  " + row.count + " məhsul"
                h.itemView.setOnClickListener { onSection(sectionKey(row)) }
            }
            is PMarketVH -> bindPMarket(h, row)
            is ProdVH -> {
                val p = row.product
                val c = row.catalog
                if (c != null && row.sub != null) {
                    // PDF-in altındakı panel: adın yanında səhifə nömrəsi
                    val sb = SpannableStringBuilder(row.title)
                    val st = sb.length
                    sb.append("  ·  ").append(row.sub)
                    sb.setSpan(ForegroundColorSpan(0x99FFFFFF.toInt()), st, sb.length, 0)
                    sb.setSpan(android.text.style.RelativeSizeSpan(0.85f), st, sb.length, 0)
                    h.name.text = sb
                } else {
                    h.name.text = row.title
                }
                h.itemView.setOnClickListener {
                    if (p != null) { if (c != null) onCatProduct(c, p) else onProduct(p) }
                }
            }
            is PMoreVH -> {
                val c = row.catalog
                if (c != null) {
                    h.text.text = if (row.open) "Daha az göstər" else (row.sub ?: "Daha çox")
                    h.itemView.setOnClickListener { onCatMore(c.urls[0], row.title) }
                } else {
                    h.text.text = if (row.open) "Daha az göstər" else "Hamısını göstər (${row.count})"
                    h.itemView.setOnClickListener { onCat(row.title) }
                }
            }
            is CSearchVH -> bindCSearch(h, row)
            is HintVH -> h.text.text = row.title
            is TitleVH -> {
                h.insta.setOnClickListener { onInsta() }
                h.all.setOnClickListener { onAll() }
                h.all.visibility = if (row.sub == null) View.GONE else View.VISIBLE
                h.all.text = row.sub ?: ""
            }
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        if (holder is ViewerVH) {
            holder.release()
            viewers.remove(holder)
        }
    }

    private fun dp(v: View, n: Int) = (n * v.resources.displayMetrics.density).toInt()

    private fun pill(v: View, bg: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(v, 20).toFloat()
            setColor(bg)
        }

    /** Kateqoriya daxilində market nişanı (marketin rəngi + məhsul sayı). */
    private fun bindPMarket(h: PMarketVH, row: Row) {
        val col = Brand.colorOf(row.market)
        h.name.text = row.market + "  ·  " + row.count
        h.name.setTextColor(if (ColorUtils.calculateLuminance(col) > 0.5) Color.BLACK else Color.WHITE)
        h.name.background = pill(h.name, col)
    }

    private fun bindItem(h: ItemVH, row: Row) {
        val sb = SpannableStringBuilder(row.title)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, 0)
        h.title.text = sb
        val d = row.date
        if (d != null) {
            // oxunaqlı tarix "həbi" + rəngli status (aktiv / bitir / başlayır / bitib)
            val info = DateUtil.info(d)
            val col = DateUtil.stateColor(info.state)
            h.dateRow.visibility = View.VISIBLE
            h.date.text = "\uD83D\uDCC5  " + info.label
            h.date.setTextColor(col)
            h.date.background = pill(h.date, ColorUtils.setAlphaComponent(col, 0x2A))
            h.status.text = info.status ?: ""
            h.status.setTextColor(col)
            h.status.visibility = if (info.status == null) View.GONE else View.VISIBLE
        } else {
            h.dateRow.visibility = View.GONE
        }
        h.sub.text = row.sub ?: ""
        h.sub.visibility = if (row.sub == null) View.GONE else View.VISIBLE
        val c = row.catalog
        h.itemView.setOnClickListener { if (c != null) onToggle(c) }
        h.itemView.isClickable = c != null
    }

    /** Jurnal daxili axtarış qutusu: mətn yalnız fərqlidirsə yazılır (yazarkən kursor/fokus pozulmasın). */
    private fun bindCSearch(h: CSearchVH, row: Row) {
        val url = row.catalog?.urls?.get(0) ?: return
        h.watcher?.let { h.edit.removeTextChangedListener(it) }
        val q = queryOf(url)
        if (h.edit.text.toString() != q) {
            h.edit.setText(q)
            h.edit.setSelection(q.length)
        }
        val w = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { onQuery(url, s?.toString() ?: "") }
        }
        h.edit.addTextChangedListener(w)
        h.watcher = w
        h.info.text = row.sub ?: ""
        h.info.visibility = if (row.sub.isNullOrEmpty()) View.GONE else View.VISIBLE
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun bindViewer(h: ViewerVH, row: Row) {
        val c = row.catalog ?: return
        h.release()
        h.boundUrl = c.urls[0]
        viewers.add(h)
        val ctx = h.itemView.context
        h.box.layoutParams = h.box.layoutParams.also {
            it.height = (ctx.resources.displayMetrics.heightPixels * 0.72f).toInt()
        }
        h.full.setOnClickListener { onFull(c) }

        fun setPages(a: RecyclerView.Adapter<*>) {
            h.pager.adapter = a
            // panelden keçid və ya əvvəlki vəziyyət: yadda saxlanmış səhifədən açılır
            val start = (pageOf[c.urls[0]] ?: 0).coerceIn(0, (a.itemCount - 1).coerceAtLeast(0))
            h.counter.text = "${start + 1}/${a.itemCount}"
            if (start > 0) h.pager.setCurrentItem(start, false)
            val cb = object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    pageOf[c.urls[0]] = position
                    h.counter.text = "${position + 1}/${a.itemCount}"
                }
            }
            h.pageCb = cb
            h.pager.registerOnPageChangeCallback(cb)
        }

        when (c.kind) {
            Kind.IMAGES -> {
                h.web.visibility = View.GONE
                setPages(ImageAdapter(c.urls))
            }
            Kind.WEB -> {
                h.pager.visibility = View.GONE
                h.counter.text = ""
                h.web.visibility = View.VISIBLE
                h.web.settings.javaScriptEnabled = true
                h.web.settings.domStorageEnabled = true
                h.web.settings.cacheMode =
                    if (Store.online(ctx)) WebSettings.LOAD_DEFAULT else WebSettings.LOAD_CACHE_ELSE_NETWORK
                h.web.webViewClient = WebViewClient()
                // Bravo: slaydın içindəki "PDF yüklə" düyməsi tutulur — PDF slaydın yerinə keçir
                if (c.market == BravoPdf.MARKET) BravoPdf.attach(h.web, c.urls[0], c.date, scope) { ok -> if (ok) onBravoPdf() }
                // flipbook-un üfüqi sürüşdürməsi siyahı tərəfindən kəsilməsin
                h.web.setOnTouchListener { v, _ ->
                    v.parent.requestDisallowInterceptTouchEvent(true)
                    false
                }
                h.web.loadUrl(c.urls[0])
            }
            Kind.PDF -> {
                h.web.visibility = View.GONE
                h.counter.text = ""
                h.progress.visibility = View.VISIBLE
                h.job = scope.launch {
                    try {
                        val f = Downloader.ensure(ctx.applicationContext, c.urls[0])
                        val w = (ctx.resources.displayMetrics.widthPixels * 2f).toInt()
                        val a = PdfAdapter(f, w, scope)
                        h.pdf = a
                        setPages(a)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        h.counter.text = "PDF açılmadı"
                    } finally {
                        h.progress.visibility = View.GONE
                    }
                }
            }
        }
    }

    private fun bindHeader(h: HeaderVH, row: Row) {
        val ctx = h.itemView.context
        val market = row.market
        h.boundMarket = market
        h.letter.text = market.take(1)
        h.letter.visibility = View.VISIBLE
        h.name.text = market
        applyColor(h, Brand.colorOf(market))
        bindHeaderDate(h, row.date)
        bindSocials(h, market)

        // 1) tətbiqin içindəki logo, 2) yaddaşdakı (offline) logo, 3) şəbəkə (ilk dəfə)
        val res = Brand.bundledRes(ctx, market)
        val cached = if (res == 0) Brand.cachedFile(ctx, market) else null
        val src: Any = when {
            res != 0 -> res
            cached != null -> cached
            else -> Brand.logos[market] ?: return
        }
        h.logo.load(src) {
            allowHardware(false)
            listener(onSuccess = { _, result ->
                h.letter.visibility = View.GONE
                if (!Brand.hasColor(market)) {
                    val bmp = (result.drawable as? BitmapDrawable)?.bitmap
                    if (bmp != null) {
                        Palette.from(bmp).generate { p ->
                            val c = Brand.pick(p)
                            if (c != null) {
                                Brand.saveColor(market, c)
                                if (h.boundMarket == market) applyColor(h, c)
                            }
                        }
                    }
                }
            })
        }
    }

    /** Başlıqdakı tarix: ağ həb içində iri tarix + rəngli status. */
    private fun bindHeaderDate(h: HeaderVH, raw: String?) {
        if (raw == null) {
            h.date.visibility = View.GONE
            return
        }
        val info = DateUtil.info(raw)
        val sb = SpannableStringBuilder(info.label)
        sb.setSpan(ForegroundColorSpan(0xFF212121.toInt()), 0, sb.length, 0)
        if (info.status != null) {
            val st = sb.length + 1
            sb.append("\n").append(info.status)
            sb.setSpan(ForegroundColorSpan(DateUtil.stateColor(info.state)), st, sb.length, 0)
            sb.setSpan(android.text.style.RelativeSizeSpan(0.85f), st, sb.length, 0)
        }
        h.date.text = sb
        h.date.background = pill(h.date, Color.WHITE)
        h.date.visibility = View.VISIBLE
    }

    /** Adın altında yalnız Instagram və WhatsApp loqoları. */
    private fun bindSocials(h: HeaderVH, market: String) {
        h.socials.removeAllViews()
        val soc = Brand.socials[market]
        if (soc == null) {
            h.socials.visibility = View.GONE
            return
        }
        h.socials.visibility = View.VISIBLE
        val size = dp(h.itemView, 32)
        val gap = dp(h.itemView, 8)
        fun add(icon: Int, desc: String, url: String, insta: Boolean) {
            val v = android.widget.ImageView(h.itemView.context).apply {
                setImageResource(icon)
                contentDescription = desc
                val pad = dp(this, 3)
                setPadding(pad, pad, pad, pad)
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(Color.WHITE)
                }
                layoutParams = android.widget.LinearLayout.LayoutParams(size, size).apply { marginEnd = gap }
                setOnClickListener {
                    if (insta) {
                        Insta.open(context, url)   // com.insta* tətbiqi ilə (əvvəlki qayda)
                    } else {
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Link açılmadı", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            h.socials.addView(v)
        }
        soc.instagram?.let { add(R.drawable.ic_instagram, "Instagram", "https://www.instagram.com/$it/", true) }
        soc.whatsapp?.let { add(R.drawable.ic_whatsapp, "WhatsApp", it, false) }
    }

    private fun applyColor(h: HeaderVH, color: Int) {
        h.card.setCardBackgroundColor(color)
        val fg = if (ColorUtils.calculateLuminance(color) > 0.5) Color.BLACK else Color.WHITE
        h.name.setTextColor(fg)
    }
}
