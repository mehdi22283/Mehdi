package az.market.endirim

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import com.googlecode.tesseract.android.TessBaseAPI
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** PDF-in ilk 2 səhifəsindən OCR ilə tarix oxuyur (nəticə yadda saxlanır). */
object Ocr {
    suspend fun pdfDate(ctx: Context, file: File): String? {
        val prefs = ctx.getSharedPreferences("ocr", Context.MODE_PRIVATE)
        if (prefs.contains(file.name)) return prefs.getString(file.name, "")?.ifEmpty { null }
        return try {
            val sb = StringBuilder()
            for (i in 0..1) {
                val bmp = withContext(Dispatchers.IO) { renderPage(file, i) } ?: break
                sb.append(recognize(bmp)).append('\n')
            }
            val d = DateUtil.find(sb.toString())
            prefs.edit().putString(file.name, d ?: "").apply()
            d
        } catch (e: Exception) {
            null
        }
    }

    private fun renderPage(file: File, index: Int): Bitmap? = try {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            val r = PdfRenderer(pfd)
            try {
                if (index >= r.pageCount) null else {
                    val p = r.openPage(index)
                    try {
                        val w = 1600
                        val h = (w.toFloat() * p.height / p.width).toInt()
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bmp
                    } finally {
                        p.close()
                    }
                }
            } finally {
                r.close()
            }
        }
    } catch (e: Exception) {
        null
    }

    suspend fun recognize(bmp: Bitmap): String = suspendCancellableCoroutine { c ->
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { c.resume(it.text) }
            .addOnFailureListener { c.resumeWithException(it) }
    }

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /** Mətn + sətirlərin koordinatları (məhsul skanı üçün). */
    suspend fun recognizeText(bmp: Bitmap): Text = suspendCancellableCoroutine { c ->
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { c.resume(it) }
            .addOnFailureListener { c.resumeWithException(it) }
    }

    // ---------------- Rus dili (Tesseract) ----------------
    private val tessHttp = OkHttpClient()
    private var tess: TessBaseAPI? = null
    private var tessFailed = false

    private fun tessRoot(ctx: Context) = File(ctx.filesDir, "tess")

    /** rus + eng modelləri bir dəfə endirilir (~8 MB). Alınmasa rus oxunmur, qalan hər şey işləyir. */
    private fun ensureTess(ctx: Context): TessBaseAPI? {
        if (tessFailed) return null
        tess?.let { return it }
        return try {
            val dir = File(tessRoot(ctx), "tessdata").apply { mkdirs() }
            for (lang in listOf("rus", "eng")) {
                val f = File(dir, "$lang.traineddata")
                if (f.exists() && f.length() > 100_000) continue
                val req = Request.Builder().url("https://github.com/tesseract-ocr/tessdata_fast/raw/main/$lang.traineddata").build()
                tessHttp.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}")
                    val tmp = File(dir, "$lang.tmp")
                    r.body!!.byteStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    tmp.renameTo(f)
                }
            }
            val api = TessBaseAPI()
            if (!api.init(tessRoot(ctx).absolutePath, "rus+eng")) { api.recycle(); throw IllegalStateException("tess init") }
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT)
            tess = api
            api
        } catch (e: Exception) {
            tessFailed = true
            null
        }
    }

    /** Səhifədəki kirill hərfli sətirləri (mətn + koordinat) qaytarır. Model yoxdursa boş siyahı. */
    suspend fun cyrillicLines(ctx: Context, bmp: Bitmap): List<OLine> = withContext(Dispatchers.Default) {
        synchronized(this@Ocr) {
            val api = ensureTess(ctx) ?: return@synchronized emptyList<OLine>()
            val out = ArrayList<OLine>()
            try {
                api.setImage(bmp)
                api.getUTF8Text()                       // tanıma işə düşür
                val it = api.resultIterator ?: return@synchronized out
                val lvl = TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE
                it.begin()
                do {
                    val t = it.getUTF8Text(lvl)?.trim() ?: continue
                    val conf = it.confidence(lvl)
                    val r = it.getBoundingRect(lvl)
                    val cyr = t.count { ch -> ch in '\u0400'..'\u04FF' }
                    if (cyr >= 3 && conf >= 45f) out.add(OLine(t, r.left, r.top, r.right, r.bottom))
                } while (it.next(lvl))
                it.delete()
            } catch (e: Exception) {
            }
            out
        }
    }
}
