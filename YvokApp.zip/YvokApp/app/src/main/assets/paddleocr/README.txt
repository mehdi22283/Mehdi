PaddleOCR (lokal) modelləri ilk istifadədə İNTERNETDƏN AVTOMATİK endirilir (təxminən 13 MB, bir dəfə)
və tətbiqin öz yaddaşında saxlanır. Bu qovluğa heç nə qoymaq məcburi deyil.

Endirilən fayllar:
  det.onnx   - RapidOCR-dan PP-OCRv4 aşkarlama modeli (ch_PP-OCRv4_det_infer.onnx)
  rec.onnx   - PP-OCR ingilis/latın tanıma modeli (xberg-io/paddleocr-onnx-models, rec/english/model.onnx)
  keys.txt   - həmin rec modelinə aid lüğət (rec/english/dict.txt)

İstəyirsinizsə (internetsiz quraşdırma üçün) eyni adlı üç faylı bu qovluğa qoyun, onda endirmə tələb olunmur.
Lüğət mütləq rec modelinə aid olmalıdır, əks halda çıxan mətn səhv olacaq.
Endirilmiş fayl zədəli çıxsa tətbiq onu silib növbəti dəfə təzədən endirir.
