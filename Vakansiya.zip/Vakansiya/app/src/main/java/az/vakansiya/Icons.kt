package az.vakansiya

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Saytların favicon-larını yükləyir və cihazda saxlayır. */
object Icons {
    private val cache = LruCache<String, Bitmap>(60)
    private val ex = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    fun hostOf(url: String): String = Uri.parse(url).host ?: ""

    fun load(ctx: Context, url: String, cb: (Bitmap?) -> Unit) {
        val host = hostOf(url)
        if (host.isEmpty()) { cb(null); return }
        cache.get(host)?.let { cb(it); return }
        val dir = ctx.applicationContext.filesDir
        ex.execute {
            val f = File(dir, "ic_$host.png")
            var bm: Bitmap? = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
            if (bm == null) {
                for (u in listOf("https://www.google.com/s2/favicons?domain=$host&sz=64", "https://$host/favicon.ico")) {
                    try {
                        val c = URL(u).openConnection() as HttpURLConnection
                        c.connectTimeout = 6000; c.readTimeout = 6000; c.instanceFollowRedirects = true
                        val b = c.inputStream.use { BitmapFactory.decodeStream(it) }
                        if (b != null) {
                            bm = b
                            f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                            break
                        }
                    } catch (e: Exception) { }
                }
            }
            bm?.let { cache.put(host, it) }
            main.post { cb(bm) }
        }
    }
}
