package az.mehdi.iptvplayer

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File

class ChannelAdapter(
    private val logos: LogoStore,
    private val scope: CoroutineScope,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    var items: List<Channel> = emptyList()
    var playingUrl: String? = null

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val num: TextView = v.findViewById(R.id.num)
        val logo: ImageView = v.findViewById(R.id.logo)
        val name: TextView = v.findViewById(R.id.name)
        val group: TextView = v.findViewById(R.id.group)
        var job: Job? = null
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_channel, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val ch = items[pos]
        h.job?.cancel()
        h.num.text = ch.number.toString()
        h.name.text = ch.name
        h.group.text = ch.group
        h.logo.setImageDrawable(null)
        h.itemView.setBackgroundColor(if (ch.url == playingUrl) 0xFF2F3B52.toInt() else Color.TRANSPARENT)
        h.itemView.setOnClickListener { onClick(ch) }
        h.job = scope.launch {
            val bmp = logos.bitmapFor(ch)
            if (bmp != null) h.logo.setImageBitmap(bmp)
        }
    }

    override fun onViewRecycled(h: VH) {
        h.job?.cancel()
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var libVLC: LibVLC
    private lateinit var player: MediaPlayer
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var videoBox: FrameLayout
    private lateinit var topBar: View
    private lateinit var groupScroll: HorizontalScrollView
    private lateinit var groupBar: LinearLayout
    private lateinit var search: EditText
    private lateinit var list: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var nowPlaying: TextView
    private lateinit var adapter: ChannelAdapter
    private lateinit var logos: LogoStore

    private var all: List<Channel> = emptyList()
    private var currentGroup: String? = null
    private var query = ""
    private var current: Channel? = null
    private var fullscreen = false
    private var normalHeight = 0
    private val chips = ArrayList<Pair<TextView, String?>>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        topBar = findViewById(R.id.topBar)
        videoBox = findViewById(R.id.videoBox)
        videoLayout = findViewById(R.id.videoLayout)
        groupScroll = findViewById(R.id.groupScroll)
        groupBar = findViewById(R.id.groupBar)
        search = findViewById(R.id.search)
        list = findViewById(R.id.list)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        nowPlaying = findViewById(R.id.nowPlaying)

        normalHeight = resources.displayMetrics.widthPixels * 9 / 16
        videoBox.layoutParams.height = normalHeight

        logos = LogoStore(applicationContext, lifecycleScope)
        adapter = ChannelAdapter(logos, lifecycleScope) { play(it) }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        libVLC = LibVLC(this, arrayListOf("--network-caching=2000"))
        player = MediaPlayer(libVLC)
        player.setEventListener { ev ->
            runOnUiThread {
                when (ev.type) {
                    MediaPlayer.Event.Buffering ->
                        progress.visibility = if (ev.buffering < 100f) View.VISIBLE else View.GONE
                    MediaPlayer.Event.Playing -> { progress.visibility = View.GONE; status.visibility = View.GONE }
                    MediaPlayer.Event.EncounteredError -> {
                        progress.visibility = View.GONE
                        status.text = "Kanal açılmadı"
                        status.visibility = View.VISIBLE
                    }
                }
            }
        }

        findViewById<View>(R.id.btnRefresh).setOnClickListener { loadPlaylist() }
        findViewById<View>(R.id.btnFull).setOnClickListener { setFullscreen(!fullscreen) }
        findViewById<View>(R.id.btnNext).setOnClickListener { step(1) }
        findViewById<View>(R.id.btnPrev).setOnClickListener { step(-1) }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s?.toString().orEmpty(); applyFilter() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (fullscreen) setFullscreen(false) else finish() }
        })

        loadPlaylist() // hər açılışda playlist yenidən endirilir
    }

    private fun loadPlaylist() {
        status.text = "Playlist yüklənir…"
        status.visibility = View.VISIBLE
        progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val cache = File(filesDir, "playlist.m3u")
            var err: String? = null
            val text = withContext(Dispatchers.IO) {
                runCatching { downloadPlaylist(cache) }.onFailure { err = it.message }.getOrNull()
                    ?: cache.takeIf { it.exists() }?.readText()
            }
            progress.visibility = View.GONE
            if (text == null) {
                status.text = "Playlist yüklənmədi: ${err ?: "xəta"}"
                return@launch
            }
            if (err != null) Toast.makeText(this@MainActivity, "Offline: köhnə playlist açıldı", Toast.LENGTH_SHORT).show()
            all = withContext(Dispatchers.Default) { parsePlaylist(text) }
            status.visibility = View.GONE
            currentGroup = null
            buildGroups()
            applyFilter()
            if (current == null) {
                val last = getSharedPreferences("p", MODE_PRIVATE).getString("last", null)
                all.firstOrNull { it.url == last }?.let { play(it) }
            }
        }
    }

    private fun styleChip(tv: TextView, selected: Boolean) {
        tv.background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(if (selected) 0xFF3D8BFF.toInt() else 0xFF2E3440.toInt())
        }
    }

    private fun buildGroups() {
        groupBar.removeAllViews()
        chips.clear()
        val names = listOf<String?>(null) + all.map { it.group }.distinct()
        for (g in names) {
            val count = if (g == null) all.size else all.count { it.group == g }
            val tv = TextView(this).apply {
                text = "${g ?: "Hamısı"} ($count)"
                setTextColor(Color.WHITE)
                textSize = 14f
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { currentGroup = g; refreshChips(); applyFilter() }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(4), 0, dp(4), 0)
            groupBar.addView(tv, lp)
            chips.add(tv to g)
        }
        refreshChips()
    }

    private fun refreshChips() = chips.forEach { (tv, g) -> styleChip(tv, g == currentGroup) }

    private fun filtered(): List<Channel> = all.filter {
        (currentGroup == null || it.group == currentGroup) && (query.isBlank() || it.name.contains(query, true))
    }

    private fun applyFilter() {
        adapter.items = filtered()
        adapter.notifyDataSetChanged()
    }

    private fun play(ch: Channel) {
        current = ch
        adapter.playingUrl = ch.url
        adapter.notifyDataSetChanged()
        nowPlaying.text = "${ch.number}. ${ch.name}"
        getSharedPreferences("p", MODE_PRIVATE).edit().putString("last", ch.url).apply()
        status.visibility = View.GONE
        progress.visibility = View.VISIBLE
        val media = Media(libVLC, Uri.parse(ch.url))
        media.setHWDecoderEnabled(true, false)
        media.addOption(":network-caching=2000")
        player.media = media
        media.release()
        player.play()
    }

    private fun step(d: Int) {
        val l = filtered().ifEmpty { all }
        if (l.isEmpty()) return
        val i = l.indexOfFirst { it.url == current?.url }
        play(l[((if (i < 0) 0 else i + d) + l.size) % l.size])
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        val vis = if (on) View.GONE else View.VISIBLE
        topBar.visibility = vis; groupScroll.visibility = vis; search.visibility = vis; list.visibility = vis
        videoBox.layoutParams.height = if (on) ViewGroup.LayoutParams.MATCH_PARENT else normalHeight
        videoBox.requestLayout()
        requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onStart() {
        super.onStart()
        player.attachViews(videoLayout, null, false, false)
        current?.let { play(it) }
    }

    override fun onStop() {
        super.onStop()
        player.stop()
        player.detachViews()
    }

    override fun onDestroy() {
        super.onDestroy()
        player.release()
        libVLC.release()
    }
}
