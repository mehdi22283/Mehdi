# IPTVPlayer — build

This project uses ExoPlayer / AndroidX Media3 as its sole playback engine.

## Toolchain

- JDK: 17
- Gradle: 8.13
- Android Gradle Plugin: 8.13.2
- Kotlin Gradle Plugin: 2.4.21
- Android compile SDK: 36
- Media3 / ExoPlayer: 1.11.1

## Build a debug APK

From this project folder run:

```bash
./gradlew assembleDebug
```

On Windows:

```bat
gradlew.bat assembleDebug
```

The first Gradle start and dependency resolution require an internet connection. The Gradle distribution is SHA-256 checked before extraction. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.


## Playback engine

This project uses AndroidX Media3 modules only (`media3-exoplayer`, `media3-ui`, DASH, HLS, SmoothStreaming and RTSP). The `androidx.media3.exoplayer.ExoPlayer` class is the playback engine provided by Media3; it is not the legacy `com.google.android.exoplayer2` library. No VLC or legacy ExoPlayer 2 dependencies are included.
