package az.market.endirim

import kotlin.math.max
import kotlin.math.min

/** OCR sətri və koordinatları. */
data class OLine(val text: String, val l: Int, val t: Int, val r: Int, val b: Int) {
    val w get() = r - l
    val h get() = b - t
}

/**
 * OCR sətirlərindən yalnız məhsul ADLARINI çıxarır:
 *  1) reklam/xidmət sözləri, faiz və valyuta qalıqları təmizlənir;
 *  2) bir-birinin altında duran yaxın sətirlər (eyni ölçülü yazı) bir məhsul adına birləşdirilir;
 *  3) düzgün ad olmayanlar (rəqəm, qısa, çox uzun, bütün sözləri reklam sözü) atılır.
 */
object ProductParser {

    private val STOP = listOf(
        "endirim", "aksiya", "kampaniya", "qiymet", "tarix", "unvan", "www", "http", "instagram", "facebook", "whatsapp",
        "kataloq", "jurnal", "supermarket", "magaza", "bonus", "kassa", "hediyye", "mehsullar", "tel", "mob", "filial",
        "bitir", "baslayir", "yeni", "super", "teklif", "sertlerle", "qaydalar", "oktyabr", "noyabr", "dekabr", "yanvar",
        "fevral", "mart", "aprel", "may", "iyun", "iyul", "avqust", "sentyabr",
        "скидка", "акция", "цена", "каталог", "магазин", "бонус", "касса", "адрес", "новинка", "предложение"
    )
    private val STOP_NORM: List<String> = STOP.map { Categorizer.norm(it) }.distinct()

    /** Faiz ifadələri (-30%, 30 %, %30), valyuta işarələri və qalıqları ad mətnindən çıxarılır. */
    private val JUNK = Regex("""(?iu)(?:[-–−+]\s?)?(?:\d{1,3}(?:[.,]\d+)?\s?%|%\s?\d{1,3}(?:[.,]\d+)?)|₼|\bazn\b|\bman\.?(?![\p{L}])|\bqəp\.?(?![\p{L}])|\bкоп\.?(?![\p{L}])|\bруб\.?(?![\p{L}])""")
    private val NON_WORD_EDGES = charArrayOf('-', '.', ',', ':', ';', '/', ' ')
    private val SPLIT = Regex("[^\\p{L}\\p{N}]+")
    private val SPACES = Regex("\\s+")
    private val BAD_CHARS = Regex("[|_•*«»\"“”]+")

    private fun clean(raw: String): String =
        JUNK.replace(raw, " ").replace(BAD_CHARS, " ").replace(SPACES, " ").trim(*NON_WORD_EDGES)

    private fun isStopToken(tk: String): Boolean =
        STOP_NORM.any { sw -> tk == sw || (sw.length >= 5 && tk.startsWith(sw)) }

    /** Bütün sözləri reklam/xidmət sözü olan sətir ("Aksiya", "Oktyabr", "Yeni") ada qarışdırılmır. */
    private fun isNoiseLine(text: String): Boolean {
        val tokens = Categorizer.norm(clean(text)).split(SPLIT).filter { tk -> tk.length >= 3 && tk.any { it.isLetter() } }
        if (tokens.isEmpty()) return true
        return tokens.all { isStopToken(it) }
    }

    private fun isValidName(n: String): Boolean {
        val letters = n.count { it.isLetter() }
        if (letters < 3 || n.length > 70) return false
        if (letters.toFloat() / n.count { !it.isWhitespace() }.coerceAtLeast(1) < 0.6f) return false
        val tokens = Categorizer.norm(n).split(SPLIT).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return false
        return tokens.any { tk -> tk.length >= 3 && tk.any { it.isLetter() } && !isStopToken(tk) }
    }

    private fun related(a: OLine, b: OLine): Boolean {
        val minH = min(a.h, b.h).coerceAtLeast(1)
        val maxH = max(a.h, b.h)
        val vgap = max(a.t, b.t) - min(a.b, b.b)
        val ox = min(a.r, b.r) - max(a.l, b.l)
        val minW = min(a.w, b.w).coerceAtLeast(1)
        return vgap >= -0.25f * minH && vgap <= 0.9f * minH && ox >= 0.35f * minW && maxH <= 1.7f * minH
    }

    /** Səhifədəki məhsul adları (təkrarsız). */
    fun parseNames(lines0: List<OLine>, pageH: Int): List<String> = parseGroups(lines0, pageH).map { it.name }

    /** Səhifədəki məhsul adları və onların qutuları (qiymət uyğunlaşdırması üçün). */
    fun parseGroups(lines0: List<OLine>, pageH: Int): List<NameBox> {
        // yalnız ad ola biləcək sətirlər; dəyişməz səhifə başlıqları (çox iri yazı) atılır
        val lines = lines0.filter { ln ->
            ln.text.count { it.isLetter() } >= 3 && ln.h <= 0.07f * pageH && !isNoiseLine(ln.text)
        }.sortedBy { it.t }
        val n = lines.size
        if (n == 0) return emptyList()

        // union-find; yuxarıdan aşağı sıralandığı üçün yalnız yaxın qonşular yoxlanır (O(n·k), O(n²) yox)
        val parent = IntArray(n) { it }
        fun find(x: Int): Int { var a = x; while (parent[a] != a) { parent[a] = parent[parent[a]]; a = parent[a] }; return a }
        for (i in 0 until n) {
            val a = lines[i]
            val limit = a.b + 0.9f * a.h
            for (j in i + 1 until n) {
                val b = lines[j]
                if (b.t > limit) break
                if (related(a, b)) parent[find(i)] = find(j)
            }
        }
        val groups = LinkedHashMap<Int, MutableList<OLine>>()
        for (i in 0 until n) groups.getOrPut(find(i)) { ArrayList() }.add(lines[i])

        val out = LinkedHashMap<String, NameBox>()
        for (g in groups.values) {
            g.sortBy { it.t }
            val used = g.take(3)
            val name = clean(used.joinToString(" ") { it.text })
            if (isValidName(name) && !out.containsKey(name)) {
                out[name] = NameBox(name, used.minOf { it.l }, used.minOf { it.t }, used.maxOf { it.r }, used.maxOf { it.b })
            }
        }
        return out.values.toList()
    }
}
