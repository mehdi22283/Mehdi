package com.zengyazici;

import android.media.AudioFormat;
import android.media.AudioRecord;
import java.io.OutputStream;
import java.net.Socket;

/**
 * ADB shell (uid 2000) icazələri ilə app_process vasitəsilə işə salınır:
 * CLASSPATH=<apk> app_process /system/bin com.zengyazici.Rec <port> <mənbələr>
 * Audionu 16 kHz mono PCM kimi tətbiqin loopback soketinə göndərir.
 */
public class Rec {
    public static void main(String[] a) {
        try {
            int port = Integer.parseInt(a[0]);
            String[] srcs = a[1].split(",");
            int rate = 16000;
            int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int size = Math.max(min, rate) * 2;
            AudioRecord r = null;
            int used = -1;
            for (String x : srcs) {
                try {
                    int s = Integer.parseInt(x.trim());
                    AudioRecord t = new AudioRecord(s, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size);
                    if (t.getState() == AudioRecord.STATE_INITIALIZED) {
                        t.startRecording();
                        if (t.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) { r = t; used = s; break; }
                    }
                    System.err.println("Menbe " + s + " islemedi (state=" + t.getState() + ")");
                    t.release();
                } catch (Throwable e) {
                    System.err.println("Menbe " + x + ": " + e);
                }
            }
            if (r == null) {
                System.err.println("Hec bir audio menbeyi acilmadi");
                System.exit(2);
            }
            Socket sock = new Socket("127.0.0.1", port);
            OutputStream o = sock.getOutputStream();
            o.write(used);
            byte[] buf = new byte[4096];
            while (true) {
                int n = r.read(buf, 0, buf.length);
                if (n < 0) break;
                if (n > 0) o.write(buf, 0, n);
            }
        } catch (Throwable e) {
            System.err.println("Rec: " + e);
            System.exit(1);
        }
        System.exit(0);
    }
}
