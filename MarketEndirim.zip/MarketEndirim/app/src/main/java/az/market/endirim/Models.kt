package az.market.endirim

import java.io.Serializable

enum class Kind { PDF, IMAGES, WEB }

/** urls: PDF -> [pdf url], IMAGES -> şəkil linkləri, WEB -> [səhifə linki] */
data class Catalog(
    val market: String,
    val title: String,
    val date: String?,
    val kind: Kind,
    val urls: List<String>,
    val note: String? = null
) : Serializable

data class MarketResult(val market: String, val catalogs: List<Catalog>, val error: String?)

data class Row(
    val type: Int,
    val market: String,
    val title: String,
    val date: String?,
    val sub: String?,
    val catalog: Catalog?,
    val catalogs: List<Catalog> = emptyList(),
    val selected: Set<String> = emptySet(),
    val tick: Int = 0
) {
    companion object {
        const val HEADER = 0
        const val ITEM = 1
        const val VIEWER = 2
        const val STRIP = 3
    }
}
