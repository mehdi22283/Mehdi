package com.wifi.finder

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.ScanResult
import android.net.wifi.rtt.RangingRequest
import android.net.wifi.rtt.RangingResult
import android.net.wifi.rtt.RangingResultCallback
import android.net.wifi.rtt.WifiRttManager
import androidx.core.content.ContextCompat

/** Ekranda (AR / kompas / siyahı) çəkilən bir şəbəkənin məlumatı. */
class OverlayItem {
    var name = ""
    var rel = Float.NaN      // telefonun önünə nəzərən bucaq (NaN = istiqamət məlum deyil)
    var dist = 0.0           // metr
    var rtt = false          // məsafə RTT ilə ölçülüb?
    var selected = false     // istifadəçinin seçdiyi şəbəkə
}

/** Skan olunan hər BSSID üçün vəziyyət. */
class Net(val bssid: String) {
    var ssid = ""
    var freq = 2437
    var rssi = -100.0
    var hasRssi = false
    var lastSeen = 0L
    var lastTs = 0L
    var mc = false           // 802.11mc (RTT) dəstəkləyir

    val binVal = DoubleArray(36)
    val binCnt = IntArray(36)
    val binTime = LongArray(36)
    var bearing = Float.NaN
    var dispBearing = Float.NaN

    var rttM = Double.NaN
    var rttStd = Double.NaN
    var rttTime = 0L

    val item = OverlayItem()

    fun resetBins() {
        binVal.fill(0.0); binCnt.fill(0); binTime.fill(0L)
        bearing = Float.NaN; dispBearing = Float.NaN
        item.rel = Float.NaN
    }
}

data class RttSample(val bssid: String, val meters: Double, val stdM: Double, val rssi: Int)

/** Wi-Fi RTT (IEEE 802.11mc) – yalnız Android 9 (API 28) və yuxarı. */
/** Yalnız API 28+ cihazlarda yaradılır (MainActivity yoxlayır). */
@SuppressLint("NewApi")
class RttHelper(private val ctx: Context) {
    private val mgr = ctx.getSystemService(Context.WIFI_RTT_RANGING_SERVICE) as? WifiRttManager
    var busy = false

    fun supported() = mgr != null
    fun available() = mgr?.isAvailable == true
    fun maxPeers(): Int = RangingRequest.getMaxPeers()

    fun range(aps: List<ScanResult>, cb: (List<RttSample>?, String?) -> Unit) {
        val m = mgr ?: return
        if (busy || aps.isEmpty()) return
        val req = try {
            RangingRequest.Builder().apply { aps.forEach { addAccessPoint(it) } }.build()
        } catch (e: Exception) {
            cb(null, e.message); return
        }
        busy = true
        try {
            m.startRanging(req, ContextCompat.getMainExecutor(ctx), object : RangingResultCallback() {
                override fun onRangingFailure(code: Int) {
                    busy = false
                    cb(null, "kod $code")
                }

                override fun onRangingResults(results: List<RangingResult>) {
                    busy = false
                    val out = ArrayList<RttSample>()
                    for (r in results) {
                        if (r.status != RangingResult.STATUS_SUCCESS) continue
                        val mac = r.macAddress?.toString() ?: continue
                        out.add(
                            RttSample(
                                mac.lowercase(),
                                r.distanceMm / 1000.0,
                                r.distanceStdDevMm / 1000.0,
                                r.rssi
                            )
                        )
                    }
                    cb(out, null)
                }
            })
        } catch (e: SecurityException) {
            busy = false; cb(null, "icazə yoxdur")
        } catch (e: Exception) {
            busy = false; cb(null, e.message)
        }
    }
}
