package com.zengyazici;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.inputmethod.InputMethodManager;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int BG = 0xFF1F2026, ROW = 0xFF2C2D35, CARD = 0x22FFFFFF, PURPLE = 0xFF7C4DFF, BLUE = 0xFF2979FF, GREEN = 0xFF00C853, GRAY = 0xFFB8B3C7, RED = 0xFFE53935;
    LinearLayout rootView;

    TextView tvStatus;
    Button menuBtn;
    TextView[] fb = new TextView[3];
    ListView lv;
    Adapter ad;
    List<Db.Item> all = new ArrayList<>(), shown = new ArrayList<>();
    int filter = 0, lastRev = -1;
    Set<String> noted = new HashSet<>();
    java.util.Map<String, List<Notes.Entry>> notesBy = new java.util.HashMap<>();
    String query = "";
    EditText etSearch;
    MediaPlayer mp;
    String playing;
    boolean dragging;
    SharedPreferences cfg;
    final Handler h = new Handler(Looper.getMainLooper());

    final Runnable tick = new Runnable() {
        @Override public void run() {
            refreshStatus();
            if (mp != null && !dragging) ad.notifyDataSetChanged();
            if (Db.rev != lastRev) reload();
            h.postDelayed(this, 1000);
        }
    };

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    EditText field(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setHintTextColor(GRAY); e.setTextColor(Color.WHITE);
        e.setInputType(type); e.setSingleLine(true); e.setTextSize(24);
        e.setMinHeight(dp(72));
        return e;
    }

    Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextSize(17); b.setTextColor(Color.WHITE);
        b.setMinHeight(dp(54)); b.setMinimumHeight(dp(54)); b.setPadding(dp(18), dp(10), dp(18), dp(10));
        paint(b, PURPLE, 0xFF5E35B1);
        b.setOnClickListener(l);
        return b;
    }

    void paint(View b, int c1, int c2) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        g.setCornerRadius(dp(14));
        b.setBackground(g);
    }

    /** Vəziyyətə görə yaşıl (verilib) və ya qırmızı (verilməyib) fonlu düymə. */
    Button stateBtn(String t, boolean ok, View.OnClickListener l) {
        Button b = btn((ok ? "✔  " : "✘  ") + t, l);
        if (ok) paint(b, GREEN, 0xFF009624); else paint(b, RED, 0xFFB71C1C);
        return b;
    }

    LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    LinearLayout.LayoutParams w1() { return new LinearLayout.LayoutParams(0, -2, 1f); }

    int num(EditText e) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception x) { return 0; }
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        cfg = getSharedPreferences("cfg", 0);

        LinearLayout root = new LinearLayout(this);
        rootView = root;
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        root.setPadding(dp(14), dp(32), dp(14), dp(8));

        TextView title = new TextView(this);
        title.setText("🎙  Zəng Yazıcı"); title.setTextColor(Color.WHITE); title.setTextSize(20);
        title.setTypeface(null, Typeface.BOLD);
        LinearLayout titleRow = row();
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(title, new LinearLayout.LayoutParams(-2, -2));

        // sağ tərəf: Menyu düyməsi + «Xidmət işləyir» vəziyyəti
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.HORIZONTAL);
        right.setGravity(Gravity.CENTER_VERTICAL);
        menuBtn = btn("☰  Menyu", v -> showMenu());
        menuBtn.setTextSize(14); menuBtn.setMinHeight(dp(48)); menuBtn.setMinimumHeight(dp(48));
        menuBtn.setMinWidth(0); menuBtn.setMinimumWidth(0);
        menuBtn.setPadding(dp(10), dp(6), dp(10), dp(6));
        right.addView(menuBtn, new LinearLayout.LayoutParams(-2, -2));

        tvStatus = new TextView(this);
        tvStatus.setTextSize(11); tvStatus.setPadding(dp(8), dp(6), dp(8), dp(6));
        GradientDrawable sg = new GradientDrawable();
        sg.setColor(0x33FFFFFF); sg.setCornerRadius(dp(12));
        tvStatus.setBackground(sg);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, -2, 1f);
        slp.leftMargin = dp(6);
        right.addView(tvStatus, slp);

        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(0, -2, 1f);
        rlp.leftMargin = dp(10);
        titleRow.addView(right, rlp);
        root.addView(titleRow);

        // Qeydlər düyməsi (axtarış qutusunun üstündə)
        Button notesBtn = btn("📝  Qeydlər", v -> startActivity(new Intent(this, NotesActivity.class)));
        paint(notesBtn, 0xFF0D2F6B, 0xFF081F4A);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2);
        nlp.topMargin = dp(12);
        root.addView(notesBtn, nlp);

        // Axtarış: həmişə görünən böyük mətn qutusu (əvvəlki Menyu düyməsinin yerində)
        etSearch = field("🔍  Nömrə və ya ad ilə axtar…", InputType.TYPE_CLASS_TEXT);
        etSearch.setPadding(dp(20), dp(18), dp(20), dp(18));
        GradientDrawable eg = new GradientDrawable();
        eg.setColor(0x33FFFFFF); eg.setCornerRadius(dp(14));
        etSearch.setBackground(eg);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable e) { query = e.toString(); applyFilter(); }
        });
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-1, -2);
        elp.topMargin = dp(10);
        root.addView(etSearch, elp);

        LinearLayout fr = row();
        fr.setPadding(0, dp(10), 0, dp(6));
        String[] names = {"Hamısı", "Gələn", "Gedən"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(names[i]); t.setGravity(Gravity.CENTER); t.setTextSize(16);
            t.setPadding(0, dp(13), 0, dp(13));
            t.setOnClickListener(v -> setFilter(idx));
            LinearLayout.LayoutParams lp = w1();
            lp.setMargins(dp(3), 0, dp(3), 0);
            fr.addView(t, lp);
            fb[i] = t;
        }
        root.addView(fr);

        lv = new ListView(this);
        lv.setDividerHeight(0);
        ad = new Adapter();
        lv.setAdapter(ad);
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        setFilter(0);
        new Thread(() -> {
            try { AdbMgr.get(this); } catch (Throwable e) { RecService.log("Açar: " + e); }
        }).start();
        askPerms();
        if (!RecService.running) startSvc();
        if (Build.MANUFACTURER.toLowerCase().contains("xiaomi") || Build.MANUFACTURER.toLowerCase().contains("redmi") || Build.MANUFACTURER.toLowerCase().contains("poco")) {
            if (!cfg.getBoolean("xiaomi_shown", false)) {
                cfg.edit().putBoolean("xiaomi_shown", true).apply();
                h.postDelayed(this::showXiaomi, 800);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
        if (ad != null) ad.notifyDataSetChanged();
        h.removeCallbacks(tick);
        h.post(tick);
    }

    @Override
    protected void onPause() {
        h.removeCallbacks(tick);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacks(tick);
        stopPlay();
        super.onDestroy();
    }

    /** Nömrələrə bağlı qeyd və xatırlatmaları bir dəfə oxuyur (siyahı çəkilərkən təkrar oxunmasın). */
    void loadNotes() {
        noted = new HashSet<>(Notes.keys(this));
        java.util.Map<String, List<Notes.Entry>> m = new java.util.HashMap<>();
        for (Notes.Entry e : Notes.all(this)) {
            List<Notes.Entry> l = m.get(e.key);
            if (l == null) { l = new ArrayList<>(); m.put(e.key, l); }
            l.add(e);
        }
        notesBy = m;
    }

    // ---------- əməliyyatlar ----------
    void askPerms() {
        List<String> p = new ArrayList<>(Arrays.asList(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.RECORD_AUDIO));
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(p.toArray(new String[0]), 1);
    }

    void setStatus(String t) { runOnUiThread(() -> { tvStatus.setText(t); tvStatus.setTextColor(Color.WHITE); }); }

    void doPair() {
        startSvc();
        PairHelper.start(this);
        setStatus("Bildiriş göndərildi. Ayarlar → Developer options → Wireless debugging → «Pair device with pairing code» açın və kodu bildirişdəki xanaya yazın.");
    }

    void doConnect() {
        setStatus("Qoşulur…");
        new Thread(() -> {
            try {
                Conn.ensure(this);
                runOnUiThread(this::startSvc);
                AdbPerms.apply(this, false);
            } catch (Throwable e) {
                RecService.log("connect: " + e);
                setStatus("Qoşulmadı: " + e.getMessage());
            }
        }).start();
    }

    void startSvc() {
        cfg.edit().putBoolean("autostart", true).apply();
        startForegroundService(new Intent(this, RecService.class));
    }

    void openFirst(Intent... tries) {
        for (Intent i : tries) {
            try { startActivity(i); return; } catch (Throwable e) { }
        }
        Toast.makeText(this, "Bu ayar tapılmadı", Toast.LENGTH_SHORT).show();
    }

    Intent appInfo() {
        return new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
    }

    void showXiaomi() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(8), dp(16), dp(8));
        TextView t = new TextView(this);
        t.setText("Tətbiq son tətbiqlərdən silinəndə də qalsın deyə:\n\n"
                + "1) Autostart-ı açın.\n"
                + "2) Batareya rejimini «Məhdudiyyət yoxdur» edin.\n"
                + "3) Son tətbiqlər ekranını açın, Zəng Yazıcı kartını uzun basın (və ya aşağı çəkin) və 🔒 kilid işarəsinə basın. Kilidli tətbiq silinəndə bağlanmır, WhatsApp da bu cür qalır.\n"
                + "4) Menyudan Əlçatımlılığı və Bildiriş girişini aktiv edin: sistem tətbiqi bağlasa belə onları özü yenidən qaldırır.");
        t.setTextColor(Color.WHITE); t.setTextSize(14);
        l.addView(t);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
        blp.topMargin = dp(10);
        l.addView(btn("Autostart ayarı", v -> {
            Intent i = new Intent();
            i.setComponent(new android.content.ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            openFirst(i, appInfo());
        }), blp);
        l.addView(btn("Batareya: Məhdudiyyət yoxdur", v -> {
            Intent i = new Intent("miui.intent.action.HIDDEN_APPS_CONFIG_ACTIVITY");
            i.setComponent(new android.content.ComponentName("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"));
            i.putExtra("package_name", getPackageName());
            i.putExtra("package_label", "Zəng Yazıcı");
            openFirst(i, new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())), appInfo());
        }), blp);
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle("Xiaomi ayarları").setView(sv).setNegativeButton("Bağla", null).show();
    }

    void showMenu() {
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(8), dp(16), dp(8));

        // icazələrin ümumi siyahısı
        for (Perms.Row r : Perms.rows(this)) {
            TextView t = new TextView(this);
            t.setText((r.ok ? "✔  " : "✘  ") + r.name + " — " + (r.ok ? "verilib" : "verilməyib"));
            t.setTextColor(r.ok ? GREEN : RED);
            t.setTextSize(13);
            t.setPadding(0, dp(2), 0, dp(2));
            l.addView(t);
        }

        final Runnable[] acts = new Runnable[11];
        final String[] names = new String[11];
        final Boolean[] st = new Boolean[11];
        int i = 0;
        names[i] = "Cütləşdir (kod bildirişdən)"; acts[i] = this::doPair; i++;
        names[i] = "Qoşul"; st[i] = Perms.adb(); acts[i] = this::doConnect; i++;
        names[i] = "ADB ilə bütün icazələri ver"; acts[i] = this::doGrantAll; i++;
        names[i] = "İcazələr"; st[i] = Perms.runtime(this); acts[i] = this::askPerms; i++;
        names[i] = "Bildiriş girişi"; st[i] = Perms.listener(this);
        acts[i] = () -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); i++;
        names[i] = "Əlçatımlılıq (aktiv et)"; st[i] = Perms.accessibility(this);
        acts[i] = () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); i++;
        names[i] = "Tətbiqlərin üstündə göstərmə"; st[i] = Perms.overlay(this);
        acts[i] = () -> openFirst(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), appInfo()); i++;
        names[i] = "Xiaomi: arxa fonda qalsın"; st[i] = Perms.battery(this); acts[i] = this::showXiaomi; i++;
        names[i] = "Test yazı (mikrofon, 7 san)";
        acts[i] = () -> {
            startService(new Intent(this, RecService.class).setAction("test"));
            Toast.makeText(this, "Test başladı: 7 saniyə danışın", Toast.LENGTH_LONG).show();
        }; i++;
        names[i] = "Test (qulaq dinamiki, 15 san)";
        acts[i] = () -> {
            startService(new Intent(this, RecService.class).setAction("testEar"));
            Toast.makeText(this, "Qulaqcığı qulağınıza yaxınlaşdırın: 5s səs, 5s sükut, 5s səs", Toast.LENGTH_LONG).show();
        }; i++;
        names[i] = "Log"; acts[i] = this::showLog; i++;

        for (int k = 0; k < i; k++) {
            final int idx = k;
            View.OnClickListener ol = v -> { dlg[0].dismiss(); acts[idx].run(); };
            Button b = st[k] == null ? btn(names[k], ol) : stateBtn(names[k], st[k], ol);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
            blp.topMargin = dp(6);
            l.addView(b, blp);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        dlg[0] = new AlertDialog.Builder(this).setTitle("Əməliyyatlar").setView(sv).setNegativeButton("Bağla", null).create();
        dlg[0].show();
    }

    void refreshStatus() {
        boolean c = false;
        try { AdbMgr m = AdbMgr.peek(); c = m != null && m.isConnected(); } catch (Throwable e) { }
        tvStatus.setText("Xidmət: " + (RecService.running ? "işləyir" : "dayanıb") + "\nADB: " + (c ? "qoşulub" : "yoxdur"));
        tvStatus.setTextColor(c && RecService.running ? GREEN : 0xFFFF7043);
        boolean all = Perms.allOk(this);
        if (menuBtn != null && !Boolean.valueOf(all).equals(menuBtn.getTag())) {
            menuBtn.setTag(all);
            if (all) paint(menuBtn, GREEN, 0xFF009624); else paint(menuBtn, RED, 0xFFB71C1C);
        }
    }

    void doGrantAll() {
        setStatus("ADB ilə icazələr verilir…");
        Toast.makeText(this, "ADB ilə icazələr verilir…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                Conn.ensure(this);
                String r = AdbPerms.apply(this, true);
                runOnUiThread(() -> Toast.makeText(this, r == null ? "Hazırdır" : r, Toast.LENGTH_LONG).show());
            } catch (Throwable e) {
                RecService.log("icazə: " + e);
                runOnUiThread(() -> Toast.makeText(this, "ADB qoşulmayıb: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    void showLog() {
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        synchronized (RecService.LOG) { t.setText(RecService.LOG.length() == 0 ? "(boşdur)" : RecService.LOG.toString()); }
        t.setTextIsSelectable(true); t.setTextSize(11); t.setPadding(dp(12), dp(8), dp(12), dp(8));
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("Log").setView(sv).setPositiveButton("Bağla", null)
                .setNeutralButton("Kopyala", (d, w) -> {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("log", t.getText()));
                    Toast.makeText(this, "Log kopyalandı", Toast.LENGTH_SHORT).show();
                }).show();
    }

    // ---------- filter və siyahı ----------
    void setFilter(int f) {
        filter = f;
        int[] acc = {PURPLE, GREEN, BLUE};
        for (int i = 0; i < 3; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(20));
            g.setColor(i == f ? acc[i] : CARD);
            fb[i].setBackground(g);
            fb[i].setTextColor(i == f ? Color.WHITE : GRAY);
            fb[i].setTypeface(null, i == f ? Typeface.BOLD : Typeface.NORMAL);
        }
        applyFilter();
    }

    void reload() {
        all = Db.all(this);
        loadNotes();
        lastRev = Db.rev;
        applyFilter();
    }

    void applyFilter() {
        shown = new ArrayList<>();
        for (Db.Item it : all) {
            boolean dirOk = filter == 0 || (filter == 1 && "in".equals(it.dir)) || (filter == 2 && "out".equals(it.dir));
            if (dirOk && Search.match(it.num, query)) shown.add(it);
        }
        if (ad != null) ad.notifyDataSetChanged();
    }

    // ---------- pleyer ----------
    void stopPlay() {
        if (mp != null) { try { mp.release(); } catch (Exception e) { } mp = null; }
        playing = null;
    }

    void toggle(Db.Item it) {
        try {
            if (it.path.equals(playing) && mp != null) {
                if (mp.isPlaying()) mp.pause(); else mp.start();
            } else {
                stopPlay();
                mp = new MediaPlayer();
                mp.setDataSource(it.path);
                mp.prepare();
                mp.start();
                playing = it.path;
                mp.setOnCompletionListener(m -> { stopPlay(); ad.notifyDataSetChanged(); });
            }
        } catch (Exception e) {
            Toast.makeText(this, "Oxuna bilmədi: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        ad.notifyDataSetChanged();
    }

    void dial(String key) {
        try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + key))); } catch (Throwable x) { }
    }

    void wa(String key) {
        Uri u = Uri.parse("https://wa.me/" + NotesActivity.waDigits(key));
        for (String pkg : new String[]{"com.whatsapp", "com.whatsapp.w4b", null}) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, u);
                if (pkg != null) i.setPackage(pkg);
                startActivity(i);
                return;
            } catch (Throwable x) { }
        }
        Toast.makeText(this, "WhatsApp tapılmadı", Toast.LENGTH_SHORT).show();
    }

    Button actBtn(String t, int c1, int c2, View.OnClickListener l) {
        Button b = btn(t, l);
        b.setTextSize(15); b.setMinHeight(dp(46)); b.setMinimumHeight(dp(46));
        b.setMinWidth(0); b.setMinimumWidth(0);
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        paint(b, c1, c2);
        return b;
    }

    // ---------- paylaş / saxla ----------
    String niceName(Db.Item it) {
        StringBuilder b = new StringBuilder();
        String n = it.num == null ? "" : it.num;
        for (int i = 0; i < n.length() && b.length() < 40; i++) {
            char c = n.charAt(i);
            b.append(Character.isLetterOrDigit(c) || c == '+' ? c : '_');
        }
        if (b.length() == 0) b.append("zeng");
        return b + "_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date(it.ts)) + ".wav";
    }

    static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    void shareDialog(final Db.Item it) {
        List<String> o = new ArrayList<>();
        o.add("📤  Paylaş…");
        if (Build.VERSION.SDK_INT >= 29) o.add("💾  Telefona saxla (Music/ZengYazici)");
        new AlertDialog.Builder(this).setTitle(it.num)
                .setItems(o.toArray(new String[0]), (d, w) -> { if (w == 0) shareFile(it); else saveFile(it); })
                .setNegativeButton("Bağla", null).show();
    }

    void shareFile(final Db.Item it) {
        Toast.makeText(this, "Hazırlanır…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                File src = new File(it.path);
                if (!src.exists()) throw new Exception("fayl tapılmadı");
                File dir = new File(getCacheDir(), "share");
                dir.mkdirs();
                File[] old = dir.listFiles();
                if (old != null) for (File f : old) f.delete();
                File dst = new File(dir, niceName(it));
                try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) { copy(in, out); }
                Uri u = new Uri.Builder().scheme("content").authority(ShareProvider.authority(this)).appendPath(dst.getName()).build();
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("audio/x-wav");
                i.putExtra(Intent.EXTRA_STREAM, u);
                i.setClipData(ClipData.newRawUri("", u));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(() -> startActivity(Intent.createChooser(i, "Yazını paylaş")));
            } catch (Throwable e) {
                runOnUiThread(() -> Toast.makeText(this, "Paylaşmaq olmadı: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    void saveFile(final Db.Item it) {
        new Thread(() -> {
            try {
                String name = niceName(it);
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "audio/x-wav");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/ZengYazici");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri col = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri u = getContentResolver().insert(col, v);
                if (u == null) throw new Exception("fayl yaradılmadı");
                try (InputStream in = new FileInputStream(it.path); OutputStream out = getContentResolver().openOutputStream(u)) { copy(in, out); }
                v.clear();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(u, v, null, null);
                runOnUiThread(() -> Toast.makeText(this, "Saxlanıldı: Music/ZengYazici/" + name, Toast.LENGTH_LONG).show());
            } catch (Throwable e) {
                runOnUiThread(() -> Toast.makeText(this, "Saxlamaq olmadı: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    static String fmt(int ms) {
        int s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    class Adapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int p) { return shown.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int p, View cv, ViewGroup parent) {
            final Db.Item it = shown.get(p);
            final boolean out = "out".equals(it.dir);
            final boolean cur = it.path.equals(playing) && mp != null;

            LinearLayout wrap = new LinearLayout(MainActivity.this);
            wrap.setPadding(0, dp(5), 0, dp(5));
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(12), dp(12), dp(12));
            GradientDrawable rg = new GradientDrawable();
            rg.setColor(ROW);
            rg.setCornerRadius(dp(18));
            row.setBackground(rg);
            wrap.addView(row, new LinearLayout.LayoutParams(-1, -2));

            TextView ic = new TextView(MainActivity.this);
            ic.setText(out ? "↗" : "↙"); ic.setTextColor(Color.WHITE); ic.setTextSize(26); ic.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL); g.setColor(out ? BLUE : GREEN);
            ic.setBackground(g);
            row.addView(ic, new LinearLayout.LayoutParams(dp(54), dp(54)));

            LinearLayout col = new LinearLayout(MainActivity.this);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
            cl.leftMargin = dp(12);
            row.addView(col, cl);

            TextView t1 = new TextView(MainActivity.this);
            t1.setText(it.num); t1.setTextColor(Color.WHITE); t1.setTextSize(18); t1.setTypeface(null, Typeface.BOLD);
            LinearLayout nr = new LinearLayout(MainActivity.this);
            nr.setGravity(Gravity.CENTER_VERTICAL);
            nr.addView(t1, new LinearLayout.LayoutParams(0, -2, 1f));
            final String nk = Notes.norm(it.num);
            TextView nb = new TextView(MainActivity.this);
            nb.setText("📝"); nb.setTextSize(28);
            nb.setPadding(dp(14), dp(6), dp(6), dp(6));
            nb.setAlpha(noted.contains(nk) ? 1f : 0.4f);
            nb.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, NotesActivity.class).putExtra("key", nk)));
            nr.addView(nb);
            col.addView(nr);

            LinearLayout meta = new LinearLayout(MainActivity.this);
            meta.setGravity(Gravity.CENTER_VERTICAL);
            meta.setPadding(0, dp(3), 0, dp(2));
            TextView pill = new TextView(MainActivity.this);
            pill.setText(("WhatsApp".equals(it.app) ? "💬 " : "📞 ") + it.app);
            pill.setTextColor(Color.WHITE); pill.setTextSize(11);
            pill.setPadding(dp(8), dp(2), dp(8), dp(2));
            GradientDrawable pg = new GradientDrawable();
            pg.setColor(0x33FFFFFF); pg.setCornerRadius(dp(10));
            pill.setBackground(pg);
            meta.addView(pill);
            TextView t2 = new TextView(MainActivity.this);
            t2.setText("  " + (out ? "Gedən" : "Gələn") + " · " + new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(new Date(it.ts)));
            t2.setTextColor(GRAY); t2.setTextSize(12);
            meta.addView(t2);
            col.addView(meta);
            if (it.note != null && !it.note.isEmpty()) {
                TextView tn = new TextView(MainActivity.this);
                tn.setText("🎤 " + it.note); tn.setTextColor(0xFFFFB74D); tn.setTextSize(11);
                col.addView(tn);
            }

            List<Notes.Entry> ne = notesBy.get(nk);
            if (ne != null && !ne.isEmpty()) {
                List<Notes.Entry> rl = new ArrayList<>(), nl = new ArrayList<>();
                for (Notes.Entry e : ne) {
                    if (Notes.T_REM.equals(e.type)) { if (!e.done) rl.add(e); } else nl.add(e);
                }
                java.util.Collections.sort(rl, (x, y) -> Long.compare(x.due, y.due));
                java.util.Collections.sort(nl, (x, y) -> Long.compare(y.ts, x.ts));
                if (!rl.isEmpty() || !nl.isEmpty()) {
                    LinearLayout nb2 = new LinearLayout(MainActivity.this);
                    nb2.setOrientation(LinearLayout.VERTICAL);
                    nb2.setPadding(dp(10), dp(6), dp(10), dp(6));
                    GradientDrawable ng = new GradientDrawable();
                    ng.setColor(0x22FFB74D); ng.setCornerRadius(dp(10));
                    nb2.setBackground(ng);
                    SimpleDateFormat nf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US);
                    for (int k = 0; k < rl.size() && k < 2; k++) {
                        Notes.Entry e = rl.get(k);
                        TextView tr = new TextView(MainActivity.this);
                        tr.setText("⏰ " + nf.format(new Date(e.due)) + " · " + NotesActivity.leftText(e.due));
                        tr.setTextColor(0xFFFFB74D); tr.setTextSize(13); tr.setTypeface(null, Typeface.BOLD);
                        nb2.addView(tr);
                    }
                    for (int k = 0; k < nl.size() && k < 2; k++) {
                        TextView tn2 = new TextView(MainActivity.this);
                        tn2.setText("📝 " + nl.get(k).text);
                        tn2.setTextColor(Color.WHITE); tn2.setTextSize(13);
                        tn2.setMaxLines(2); tn2.setEllipsize(android.text.TextUtils.TruncateAt.END);
                        nb2.addView(tn2);
                    }
                    int more = Math.max(0, rl.size() - 2) + Math.max(0, nl.size() - 2);
                    if (more > 0) {
                        TextView tm = new TextView(MainActivity.this);
                        tm.setText("… daha " + more + " qeyd/xatırlatma"); tm.setTextColor(GRAY); tm.setTextSize(11);
                        nb2.addView(tm);
                    }
                    nb2.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, NotesActivity.class).putExtra("key", nk)));
                    LinearLayout.LayoutParams nlp2 = new LinearLayout.LayoutParams(-1, -2);
                    nlp2.topMargin = dp(4); nlp2.bottomMargin = dp(2);
                    col.addView(nb2, nlp2);
                }
            }

            LinearLayout bar = new LinearLayout(MainActivity.this);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            ImageButton pb = new ImageButton(MainActivity.this);
            pb.setBackgroundColor(0);
            pb.setImageResource(cur && mp.isPlaying() ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play);
            pb.setOnClickListener(v -> toggle(it));
            bar.addView(pb, new LinearLayout.LayoutParams(dp(54), dp(54)));

            SeekBar sb = new SeekBar(MainActivity.this);
            int total = cur ? mp.getDuration() : it.dur * 1000;
            sb.setMax(Math.max(total, 1));
            sb.setProgress(cur ? mp.getCurrentPosition() : 0);
            sb.setEnabled(cur);
            sb.setProgressTintList(ColorStateList.valueOf(out ? BLUE : GREEN));
            sb.setThumbTintList(ColorStateList.valueOf(out ? BLUE : GREEN));
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean u) { }
                @Override public void onStartTrackingTouch(SeekBar s) { dragging = true; }
                @Override public void onStopTrackingTouch(SeekBar s) {
                    if (mp != null && it.path.equals(playing)) mp.seekTo(s.getProgress());
                    dragging = false;
                }
            });
            bar.addView(sb, new LinearLayout.LayoutParams(0, -2, 1f));

            TextView tt = new TextView(MainActivity.this);
            tt.setText((cur ? fmt(mp.getCurrentPosition()) : "0:00") + " / " + fmt(total));
            tt.setTextColor(GRAY); tt.setTextSize(12);
            bar.addView(tt);
            ImageButton sh = new ImageButton(MainActivity.this);
            sh.setBackgroundColor(0);
            sh.setImageResource(android.R.drawable.ic_menu_share);
            sh.setColorFilter(Color.WHITE);
            sh.setOnClickListener(v -> shareDialog(it));
            bar.addView(sh, new LinearLayout.LayoutParams(dp(54), dp(54)));
            col.addView(bar);

            if (Notes.isNumber(nk)) {
                LinearLayout acts = new LinearLayout(MainActivity.this);
                acts.setPadding(0, dp(4), 0, 0);
                LinearLayout.LayoutParams a1 = new LinearLayout.LayoutParams(0, -2, 1f), a2 = new LinearLayout.LayoutParams(0, -2, 1f);
                a1.rightMargin = dp(5); a2.leftMargin = dp(5);
                acts.addView(actBtn("📞 Zəng et", GREEN, 0xFF009624, v -> dial(nk)), a1);
                acts.addView(actBtn("💬 WhatsApp", 0xFF25D366, 0xFF1DA851, v -> wa(nk)), a2);
                col.addView(acts);
            }

            row.setOnLongClickListener(v -> {
                new AlertDialog.Builder(MainActivity.this).setMessage("Bu yazı silinsin?")
                        .setNeutralButton("📝 Qeyd / xatırlatma", (d, w) ->
                                startActivity(new Intent(MainActivity.this, NotesActivity.class).putExtra("key", nk)))
                        .setPositiveButton("Sil", (d, w) -> {
                            if (it.path.equals(playing)) stopPlay();
                            new File(it.path).delete();
                            Db.remove(MainActivity.this, it);
                            reload();
                        }).setNegativeButton("Ləğv et", null).show();
                return true;
            });
            return wrap;
        }
    }
}
