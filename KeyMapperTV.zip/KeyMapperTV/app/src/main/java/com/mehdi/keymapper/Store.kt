package com.mehdi.keymapper

import android.content.Context
import android.content.SharedPreferences
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Action(val type: String = "NONE", val param: String = "") {
    fun describe(): String {
        val i = Actions.TYPES.indexOf(type)
        val name = if (i >= 0) Actions.LABELS[i] else type
        return if (param.isBlank() || type == "NONE") name else name + ": " + param
    }
}

data class Mapping(
    val key: Int,
    val onShort: Action,
    val onLong: Action,
    val onDouble: Action = Action()
)

object Actions {
    val TYPES: List<String> = listOf("NONE", "KEY", "KEY_LONG", "APP", "CLEAN_ALL", "HOME", "BACK", "SHELL")
    val LABELS: List<String> = listOf(
        "Heç nə", "Düymə göndər", "Düyməni uzun bas", "Tətbiq aç",
        "Cari və digər tətbiqləri bağla + RAM təmizlə",
        "Home", "Geri", "ADB əmri"
    )
    val HINTS: List<String> = listOf("", "KEYCODE_DPAD_LEFT", "KEYCODE_DPAD_CENTER", "es.ottplayer.tv", "", "", "", "input keyevent 4")
}

object Store {
    const val DEFAULT_HOST = "192.168.31.220"

    private lateinit var sp: SharedPreferences

    @Volatile
    var mappings: List<Mapping> = emptyList()

    @Volatile
    private var lookup: Map<Int, Mapping> = emptyMap()

    private fun fixType(t: String): String = if (t == "FORCE_STOP") "CLEAN_ALL" else t

    private fun readAction(o: JSONObject, t: String, p: String): Action =
        Action(fixType(o.optString(t, "NONE")), o.optString(p, ""))

    fun init(c: Context) {
        sp = c.applicationContext.getSharedPreferences("km", Context.MODE_PRIVATE)
        val saved = sp.getString("mappings", null)
        var list: List<Mapping> = defaults()
        if (saved != null) {
            try {
                val arr = JSONArray(saved)
                val tmp = ArrayList<Mapping>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    tmp.add(
                        Mapping(
                            o.getInt("k"),
                            readAction(o, "st", "sp"),
                            readAction(o, "lt", "lp"),
                            readAction(o, "dt", "dp")
                        )
                    )
                }
                list = tmp
            } catch (e: Exception) {
                list = defaults()
            }
        }

        // Köhnə quraşdırmadan miqrasiya: BUTTON_5 -> tək: CENTER, iki dəfə: CENTER uzun, uzun: tətbiq aç
        if (!sp.getBoolean("mig3", false)) {
            val fixed = ArrayList<Mapping>()
            for (m in list) {
                if (m.key == KeyEvent.KEYCODE_BUTTON_5 && m.onDouble.type != "KEY_LONG") {
                    var app: Action? = null
                    if (m.onLong.type == "APP") app = m.onLong
                    else if (m.onDouble.type == "APP") app = m.onDouble
                    if (app != null) {
                        fixed.add(Mapping(m.key, m.onShort, app, Action("KEY_LONG", "KEYCODE_DPAD_CENTER")))
                        continue
                    }
                }
                fixed.add(m)
            }
            list = fixed
            sp.edit().putBoolean("mig3", true).apply()
        }
        save(list)
    }

    var host: String
        get() = sp.getString("host", DEFAULT_HOST) ?: DEFAULT_HOST
        set(v) {
            sp.edit().putString("host", v).apply()
        }

    var repeatDelay: Long
        get() = sp.getLong("rd", 250L)
        set(v) {
            sp.edit().putLong("rd", v).apply()
        }

    var repeatInterval: Long
        get() = sp.getLong("ri", 40L)
        set(v) {
            sp.edit().putLong("ri", v).apply()
        }

    /** İki dəfə basma üçün gözləmə pəncərəsi (ms) */
    var doubleWindow: Long
        get() = sp.getLong("dw", 250L)
        set(v) {
            sp.edit().putLong("dw", v).apply()
        }

    val token: String
        get() {
            val cur = sp.getString("token", null)
            if (cur != null) return cur
            val n = UUID.randomUUID().toString().replace("-", "")
            sp.edit().putString("token", n).apply()
            return n
        }

    fun find(code: Int): Mapping? = lookup[code]

    private fun defaults(): List<Mapping> = listOf(
        Mapping(KeyEvent.KEYCODE_BUTTON_6, Action("KEY", "KEYCODE_DPAD_LEFT"), Action()),
        Mapping(KeyEvent.KEYCODE_BUTTON_7, Action("KEY", "KEYCODE_DPAD_RIGHT"), Action()),
        Mapping(
            KeyEvent.KEYCODE_BUTTON_5,
            Action("KEY", "KEYCODE_DPAD_CENTER"),
            Action("APP", "es.ottplayer.tv"),
            Action("KEY_LONG", "KEYCODE_DPAD_CENTER")
        ),
        Mapping(KeyEvent.KEYCODE_HOME, Action("HOME"), Action("CLEAN_ALL"))
    )

    private fun save(l: List<Mapping>) {
        mappings = l
        lookup = l.associateBy { it.key }
        val arr = JSONArray()
        for (m in l) {
            val o = JSONObject()
            o.put("k", m.key)
            o.put("st", m.onShort.type)
            o.put("sp", m.onShort.param)
            o.put("lt", m.onLong.type)
            o.put("lp", m.onLong.param)
            o.put("dt", m.onDouble.type)
            o.put("dp", m.onDouble.param)
            arr.put(o)
        }
        sp.edit().putString("mappings", arr.toString()).apply()
    }

    fun upsert(oldKey: Int?, m: Mapping) {
        val l = ArrayList<Mapping>()
        for (x in mappings) {
            if (x.key != m.key && (oldKey == null || x.key != oldKey)) l.add(x)
        }
        l.add(m)
        save(l)
    }

    fun remove(key: Int) {
        val l = ArrayList<Mapping>()
        for (x in mappings) {
            if (x.key != key) l.add(x)
        }
        save(l)
    }

    fun reset() {
        save(defaults())
    }

    fun keyName(code: Int): String = KeyEvent.keyCodeToString(code)

    fun parseKey(s: String): Int {
        val t = s.trim().uppercase()
        val n = t.toIntOrNull()
        if (n != null) return n
        var c = KeyEvent.keyCodeFromString(t)
        if (c == KeyEvent.KEYCODE_UNKNOWN) c = KeyEvent.keyCodeFromString("KEYCODE_" + t)
        return c
    }
}
