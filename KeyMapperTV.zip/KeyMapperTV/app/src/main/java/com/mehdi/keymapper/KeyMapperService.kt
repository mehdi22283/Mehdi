package com.mehdi.keymapper

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class KeyMapperService : AccessibilityService() {

    companion object {
        const val LONG_MS = 600L

        @Volatile
        var running: Boolean = false

        @Volatile
        var capture: ((Int) -> Unit)? = null

        @Volatile
        var swallowUp: Int = -1
    }

    private val ui = Handler(Looper.getMainLooper())

    @Volatile
    private var fgPkg: String? = null

    private var longFired = false
    private var pending: Runnable? = null

    // iki dəfə basma üçün gözləyən "tək basma" tapşırıqları
    private val singleTasks = HashMap<Int, Runnable>()

    // basılı saxlayanda sürətli təkrar
    private var holdCode = 0
    private var holdRepeat = 0

    private val repeater: Runnable = object : Runnable {
        override fun run() {
            if (holdCode == 0) return
            holdRepeat++
            if (holdRepeat > 800) {
                releaseHold()
                return
            }
            Adb.keyDown(holdCode, holdRepeat)
            ui.postDelayed(this, Store.repeatInterval)
        }
    }

    private fun releaseHold() {
        ui.removeCallbacks(repeater)
        if (holdCode != 0) Adb.keyUp(holdCode)
        holdCode = 0
        holdRepeat = 0
    }

    private fun clearSingles() {
        for (t in singleTasks.values) ui.removeCallbacks(t)
        singleTasks.clear()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        try {
            val k = Intent(this, KeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(k) else startService(k)
        } catch (e: Exception) {
        }
        Adb.connect()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        releaseHold()
        clearSingles()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        running = false
        releaseHold()
        clearSingles()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val p = e?.packageName?.toString() ?: return
        if (p == packageName) return
        val skip = listOf("launcher", "tvhome", "systemui", "inputmethod", "settings")
        for (s in skip) {
            if (p.contains(s, true)) return
        }
        fgPkg = p
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(ev: KeyEvent): Boolean {
        val cap = capture
        if (cap != null) {
            if (ev.action == KeyEvent.ACTION_DOWN) {
                capture = null
                swallowUp = ev.keyCode
                val code = ev.keyCode
                ui.post { cap(code) }
            }
            return true
        }
        if (ev.action == KeyEvent.ACTION_UP && ev.keyCode == swallowUp) {
            swallowUp = -1
            return true
        }

        val m = Store.find(ev.keyCode) ?: return false
        val hasLong = m.onLong.type != "NONE"
        val hasDouble = m.onDouble.type != "NONE"

        // 1) Uzun/ikiqat əməliyyat yoxdursa düymə real DPAD kimi davranır:
        //    basanda DOWN, buraxanda UP, basılı saxlayanda sürətli təkrar.
        if (!hasLong && !hasDouble && m.onShort.type == "KEY") {
            val code = Store.parseKey(m.onShort.param)
            if (code == 0) return true
            if (ev.action == KeyEvent.ACTION_DOWN) {
                if (ev.repeatCount == 0) {
                    if (holdCode != 0) releaseHold()
                    holdCode = code
                    holdRepeat = 0
                    Adb.keyDown(code, 0)
                    ui.postDelayed(repeater, Store.repeatDelay)
                }
            } else if (ev.action == KeyEvent.ACTION_UP) {
                ui.removeCallbacks(repeater)
                Adb.keyUp(code)
                holdCode = 0
                holdRepeat = 0
            }
            return true
        }

        // 2) İki dəfə basma tələb olunan düymə
        if (hasDouble) {
            handleWithDouble(ev, m, hasLong)
            return true
        }

        // 3) Qısa / uzun basma
        if (ev.action == KeyEvent.ACTION_DOWN) {
            if (ev.repeatCount == 0) {
                longFired = false
                val old = pending
                if (old != null) ui.removeCallbacks(old)
                pending = null
                if (hasLong) {
                    val r = Runnable {
                        longFired = true
                        perform(m.onLong)
                    }
                    pending = r
                    ui.postDelayed(r, LONG_MS)
                } else {
                    perform(m.onShort)
                }
            }
        } else if (ev.action == KeyEvent.ACTION_UP) {
            if (hasLong) {
                val old = pending
                if (old != null) ui.removeCallbacks(old)
                pending = null
                if (!longFired) perform(m.onShort)
            }
        }
        return true
    }

    private fun handleWithDouble(ev: KeyEvent, m: Mapping, hasLong: Boolean) {
        val key = m.key
        if (ev.action == KeyEvent.ACTION_DOWN) {
            if (ev.repeatCount != 0) return
            longFired = false
            val old = pending
            if (old != null) ui.removeCallbacks(old)
            pending = null
            if (hasLong) {
                val r = Runnable {
                    longFired = true
                    val w = singleTasks.remove(key)
                    if (w != null) ui.removeCallbacks(w)
                    perform(m.onLong)
                }
                pending = r
                ui.postDelayed(r, LONG_MS)
            }
        } else if (ev.action == KeyEvent.ACTION_UP) {
            val old = pending
            if (old != null) ui.removeCallbacks(old)
            pending = null
            if (longFired) {
                longFired = false
                return
            }
            val waiting = singleTasks.remove(key)
            if (waiting != null) {
                // ikinci basma pəncərə daxilində gəldi -> iki dəfə basma
                ui.removeCallbacks(waiting)
                perform(m.onDouble)
            } else {
                val t = Runnable {
                    singleTasks.remove(key)
                    perform(m.onShort)
                }
                singleTasks[key] = t
                ui.postDelayed(t, Store.doubleWindow)
            }
        }
    }

    /** Sistemdə düyməni uzun basılmış kimi göndərir (DOWN, gecikmiş təkrarlar, UP). */
    private fun pressLong(c: Int) {
        Adb.keyDown(c, 0)
        ui.postDelayed(Runnable { Adb.keyDown(c, 1) }, 700L)
        ui.postDelayed(Runnable { Adb.keyDown(c, 2) }, 760L)
        ui.postDelayed(Runnable { Adb.keyUp(c) }, 820L)
    }

    private fun launcherPackages(): Set<String> {
        val set = HashSet<String>()
        try {
            val i = Intent(Intent.ACTION_MAIN)
            i.addCategory(Intent.CATEGORY_HOME)
            for (ri in packageManager.queryIntentActivities(i, 0)) {
                set.add(ri.activityInfo.packageName)
            }
        } catch (e: Exception) {
        }
        return set
    }

    private fun perform(a: Action) {
        when (a.type) {
            "KEY" -> {
                val c = Store.parseKey(a.param)
                if (c != 0) Adb.tap(c)
            }
            "KEY_LONG" -> {
                val c = Store.parseKey(a.param)
                if (c != 0) pressLong(c)
            }
            "APP" -> {
                val i = packageManager.getLaunchIntentForPackage(a.param.trim())
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                }
            }
            "CLEAN_ALL" -> {
                val keep = HashSet<String>()
                keep.add(packageName)
                keep.addAll(launcherPackages())
                val cur = fgPkg
                performGlobalAction(GLOBAL_ACTION_HOME)
                Adb.cleanAll(keep, cur)
                fgPkg = null
            }
            "HOME" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "BACK" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "SHELL" -> {
                if (a.param.isNotBlank()) Adb.shell(a.param)
            }
            else -> {}
        }
    }
}
