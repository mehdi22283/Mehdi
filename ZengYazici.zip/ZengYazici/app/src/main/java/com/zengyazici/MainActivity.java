package com.zengyazici;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int BG = 0xFF0B0714, CARD = 0x22FFFFFF, PURPLE = 0xFF7C4DFF, BLUE = 0xFF2979FF, GREEN = 0xFF00C853, GRAY = 0xFFB8B3C7;
    LinearLayout rootView;

    TextView tvStatus;
    TextView[] fb = new TextView[3];
    ListView lv;
    Adapter ad;
    List<Db.Item> all = new ArrayList<>(), shown = new ArrayList<>();
    int filter = 0, lastCount = -1;
    MediaPlayer mp;
    String playing;
    boolean dragging;
    SharedPreferences cfg;
    final Handler h = new Handler(Looper.getMainLooper());

    final Runnable tick = new Runnable() {
        @Override public void run() {
            refreshStatus();
            if (mp != null && !dragging) ad.notifyDataSetChanged();
            if (Db.all(MainActivity.this).size() != lastCount) reload();
            h.postDelayed(this, 700);
        }
    };

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    EditText field(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setHintTextColor(GRAY); e.setTextColor(Color.WHITE);
        e.setInputType(type); e.setSingleLine(true); e.setTextSize(14);
        return e;
    }

    Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextSize(15); b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{PURPLE, 0xFF5E35B1});
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    LinearLayout.LayoutParams w1() { return new LinearLayout.LayoutParams(0, -2, 1f); }

    int num(EditText e) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception x) { return 0; }
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        cfg = getSharedPreferences("cfg", 0);

        LinearLayout root = new LinearLayout(this);
        rootView = root;
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(14), dp(32), dp(14), dp(8));

        TextView title = new TextView(this);
        title.setText("🎙  Zəng Yazıcı"); title.setTextColor(Color.WHITE); title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        tvStatus = new TextView(this);
        tvStatus.setTextSize(13); tvStatus.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable sg = new GradientDrawable();
        sg.setColor(0x33FFFFFF); sg.setCornerRadius(dp(14));
        tvStatus.setBackground(sg);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.topMargin = dp(8); slp.bottomMargin = dp(10);
        root.addView(tvStatus, slp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(0, 0, 0, 0);

        card.addView(btn("☰  Menyu", v -> showMenu()));
        root.addView(card);

        LinearLayout fr = row();
        fr.setPadding(0, dp(10), 0, dp(6));
        String[] names = {"Hamısı", "Gələn", "Gedən"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(names[i]); t.setGravity(Gravity.CENTER); t.setTextSize(14);
            t.setPadding(0, dp(8), 0, dp(8));
            t.setOnClickListener(v -> setFilter(idx));
            LinearLayout.LayoutParams lp = w1();
            lp.setMargins(dp(3), 0, dp(3), 0);
            fr.addView(t, lp);
            fb[i] = t;
        }
        root.addView(fr);

        lv = new ListView(this);
        lv.setDividerHeight(0);
        ad = new Adapter();
        lv.setAdapter(ad);
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        setFilter(0);
        new Thread(() -> {
            try { AdbMgr.get(this); } catch (Throwable e) { RecService.log("Açar: " + e); }
        }).start();
        askPerms();
        if (!RecService.running) startSvc();
        h.post(tick);
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacks(tick);
        stopPlay();
        super.onDestroy();
    }

    // ---------- əməliyyatlar ----------
    void askPerms() {
        List<String> p = new ArrayList<>(Arrays.asList(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG));
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(p.toArray(new String[0]), 1);
    }

    void setStatus(String t) { runOnUiThread(() -> { tvStatus.setText(t); tvStatus.setTextColor(Color.WHITE); }); }

    void doPair() {
        startSvc();
        PairHelper.start(this);
        setStatus("Bildiriş göndərildi. Ayarlar → Developer options → Wireless debugging → «Pair device with pairing code» açın və kodu bildirişdəki xanaya yazın.");
    }

    void doConnect() {
        setStatus("Qoşulur…");
        new Thread(() -> {
            try {
                Conn.ensure(this);
                runOnUiThread(this::startSvc);
            } catch (Throwable e) {
                RecService.log("connect: " + e);
                setStatus("Qoşulmadı: " + e.getMessage());
            }
        }).start();
    }

    void startSvc() {
        cfg.edit().putBoolean("autostart", true).apply();
        startForegroundService(new Intent(this, RecService.class));
    }

    void showMenu() {
        final AlertDialog[] dlg = new AlertDialog[1];
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(8), dp(16), dp(8));
        String[] names = {"Cütləşdir (kod bildirişdən)", "Qoşul", "İcazələr", "Bildiriş girişi", "Əlçatımlılıq (aktiv et)", "Batareya optimizasiyası", "Log"};
        final Runnable[] acts = {
                this::doPair,
                this::doConnect,
                this::askPerms,
                () -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)),
                () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)),
                () -> startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))),
                this::showLog
        };
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
            blp.topMargin = dp(6);
            l.addView(btn(names[i], v -> { dlg[0].dismiss(); acts[idx].run(); }), blp);
        }
        dlg[0] = new AlertDialog.Builder(this).setTitle("Əməliyyatlar").setView(l).setNegativeButton("Bağla", null).create();
        dlg[0].show();
    }

    void refreshStatus() {
        boolean c = false;
        try { AdbMgr m = AdbMgr.peek(); c = m != null && m.isConnected(); } catch (Throwable e) { }
        tvStatus.setText("Xidmət: " + (RecService.running ? "işləyir" : "dayanıb") + "  ·  ADB: " + (c ? "qoşulub (" + Conn.mode + ")" : "qoşulmayıb"));
        tvStatus.setTextColor(c && RecService.running ? GREEN : 0xFFFF7043);
    }

    void showLog() {
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        synchronized (RecService.LOG) { t.setText(RecService.LOG.length() == 0 ? "(boşdur)" : RecService.LOG.toString()); }
        t.setTextIsSelectable(true); t.setTextSize(11); t.setPadding(dp(12), dp(8), dp(12), dp(8));
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("Log").setView(sv).setPositiveButton("Bağla", null).show();
    }

    // ---------- filter və siyahı ----------
    void setFilter(int f) {
        filter = f;
        int[] acc = {PURPLE, GREEN, BLUE};
        for (int i = 0; i < 3; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(20));
            g.setColor(i == f ? acc[i] : CARD);
            fb[i].setBackground(g);
            fb[i].setTextColor(i == f ? Color.WHITE : GRAY);
            fb[i].setTypeface(null, i == f ? Typeface.BOLD : Typeface.NORMAL);
        }
        int[][] bg = {{0xFF2A1458, 0xFF0B0714}, {0xFF0D4A2B, 0xFF07130D}, {0xFF0F2F6B, 0xFF070E1F}};
        if (rootView != null) rootView.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, bg[f]));
        applyFilter();
    }

    void reload() {
        all = Db.all(this);
        lastCount = all.size();
        applyFilter();
    }

    void applyFilter() {
        shown = new ArrayList<>();
        for (Db.Item it : all) {
            if (filter == 0 || (filter == 1 && "in".equals(it.dir)) || (filter == 2 && "out".equals(it.dir))) shown.add(it);
        }
        if (ad != null) ad.notifyDataSetChanged();
    }

    // ---------- pleyer ----------
    void stopPlay() {
        if (mp != null) { try { mp.release(); } catch (Exception e) { } mp = null; }
        playing = null;
    }

    void toggle(Db.Item it) {
        try {
            if (it.path.equals(playing) && mp != null) {
                if (mp.isPlaying()) mp.pause(); else mp.start();
            } else {
                stopPlay();
                mp = new MediaPlayer();
                mp.setDataSource(it.path);
                mp.prepare();
                mp.start();
                playing = it.path;
                mp.setOnCompletionListener(m -> { stopPlay(); ad.notifyDataSetChanged(); });
            }
        } catch (Exception e) {
            Toast.makeText(this, "Oxuna bilmədi: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        ad.notifyDataSetChanged();
    }

    static String fmt(int ms) {
        int s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    class Adapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int p) { return shown.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int p, View cv, ViewGroup parent) {
            final Db.Item it = shown.get(p);
            final boolean out = "out".equals(it.dir);
            final boolean cur = it.path.equals(playing) && mp != null;

            LinearLayout wrap = new LinearLayout(MainActivity.this);
            wrap.setPadding(0, dp(5), 0, dp(5));
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(12), dp(12), dp(12));
            GradientDrawable rg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    out ? new int[]{0xFF2563EB, 0xFF1E3A8A} : new int[]{0xFF16A34A, 0xFF14532D});
            rg.setCornerRadius(dp(18));
            row.setBackground(rg);
            wrap.addView(row, new LinearLayout.LayoutParams(-1, -2));

            TextView ic = new TextView(MainActivity.this);
            ic.setText(out ? "↗" : "↙"); ic.setTextColor(Color.WHITE); ic.setTextSize(22); ic.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL); g.setColor(0x33FFFFFF);
            ic.setBackground(g);
            row.addView(ic, new LinearLayout.LayoutParams(dp(46), dp(46)));

            LinearLayout col = new LinearLayout(MainActivity.this);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
            cl.leftMargin = dp(12);
            row.addView(col, cl);

            TextView t1 = new TextView(MainActivity.this);
            t1.setText(it.num); t1.setTextColor(Color.WHITE); t1.setTextSize(17); t1.setTypeface(null, Typeface.BOLD);
            col.addView(t1);

            LinearLayout meta = new LinearLayout(MainActivity.this);
            meta.setGravity(Gravity.CENTER_VERTICAL);
            meta.setPadding(0, dp(3), 0, dp(2));
            TextView pill = new TextView(MainActivity.this);
            pill.setText(("WhatsApp".equals(it.app) ? "💬 " : "📞 ") + it.app);
            pill.setTextColor(Color.WHITE); pill.setTextSize(11);
            pill.setPadding(dp(8), dp(2), dp(8), dp(2));
            GradientDrawable pg = new GradientDrawable();
            pg.setColor(0x44000000); pg.setCornerRadius(dp(10));
            pill.setBackground(pg);
            meta.addView(pill);
            TextView t2 = new TextView(MainActivity.this);
            t2.setText("  " + (out ? "Gedən" : "Gələn") + " · " + new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(new Date(it.ts)));
            t2.setTextColor(0xFFE6E1F5); t2.setTextSize(12);
            meta.addView(t2);
            col.addView(meta);

            LinearLayout bar = new LinearLayout(MainActivity.this);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            ImageButton pb = new ImageButton(MainActivity.this);
            pb.setBackgroundColor(0);
            pb.setImageResource(cur && mp.isPlaying() ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play);
            pb.setOnClickListener(v -> toggle(it));
            bar.addView(pb, new LinearLayout.LayoutParams(dp(40), dp(40)));

            SeekBar sb = new SeekBar(MainActivity.this);
            int total = cur ? mp.getDuration() : it.dur * 1000;
            sb.setMax(Math.max(total, 1));
            sb.setProgress(cur ? mp.getCurrentPosition() : 0);
            sb.setEnabled(cur);
            sb.setProgressTintList(ColorStateList.valueOf(Color.WHITE));
            sb.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int v, boolean u) { }
                @Override public void onStartTrackingTouch(SeekBar s) { dragging = true; }
                @Override public void onStopTrackingTouch(SeekBar s) {
                    if (mp != null && it.path.equals(playing)) mp.seekTo(s.getProgress());
                    dragging = false;
                }
            });
            bar.addView(sb, new LinearLayout.LayoutParams(0, -2, 1f));

            TextView tt = new TextView(MainActivity.this);
            tt.setText((cur ? fmt(mp.getCurrentPosition()) : "0:00") + " / " + fmt(total));
            tt.setTextColor(0xFFE6E1F5); tt.setTextSize(11);
            bar.addView(tt);
            col.addView(bar);

            row.setOnLongClickListener(v -> {
                new AlertDialog.Builder(MainActivity.this).setMessage("Bu yazı silinsin?")
                        .setPositiveButton("Sil", (d, w) -> {
                            if (it.path.equals(playing)) stopPlay();
                            new File(it.path).delete();
                            Db.remove(MainActivity.this, it);
                            reload();
                        }).setNegativeButton("Ləğv et", null).show();
                return true;
            });
            return wrap;
        }
    }
}
