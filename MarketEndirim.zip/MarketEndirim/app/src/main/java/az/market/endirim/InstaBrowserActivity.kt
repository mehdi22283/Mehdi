package az.market.endirim

import android.annotation.SuppressLint
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Mini brauzer: bütün marketlərin Instagram səhifələri.
 *  - Onlayn: səhifə canlı açılır (giriş bir dəfə edilir, cookie yadda qalır).
 *  - "Hamısını offline yüklə": hər səhifə açılır, son 20 post yüklənənə qədər sürüşdürülür və
 *    WebView arxivi (.mht) kimi filesDir/insta-ya yazılır.
 *  - Oflayn: saxlanmış nüsxə (JS söndürülmüş halda) açılır.
 */
class InstaBrowserActivity : AppCompatActivity() {

    private companion object {
        const val TARGET = 20
        const val UA =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
    }

    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnSave: Button
    private val tabs = ArrayList<Button>()
    private val users: List<Pair<String, String>> =
        listOf("Bravo Market", "Araz Market", "Al Market", "Rahat Market", "Tamstore", "Bolmart")
            .mapNotNull { m -> Brand.socials[m]?.instagram?.let { m to it } }
    private var current = 0
    private var saving: Job? = null
    private var pageDone: CompletableDeferred<Unit>? = null

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun archive(user: String) = File(File(filesDir, "insta").apply { mkdirs() }, "$user.mht")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brand.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
        }
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        users.forEachIndexed { i, (market, _) ->
            val b = Button(this, null, 0, com.google.android.material.R.style.Widget_MaterialComponents_Button_TextButton).apply {
                text = market
                isAllCaps = false
                setOnClickListener { if (saving?.isActive != true) open(i, false) }
            }
            tabs.add(b)
            tabRow.addView(b)
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabRow)
        })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnSave = Button(this, null, 0, com.google.android.material.R.style.Widget_MaterialComponents_Button_TextButton).apply {
            text = "Hamısını offline yüklə"
            isAllCaps = false
            setOnClickListener { saveAll() }
        }
        val btnSaved = Button(this, null, 0, com.google.android.material.R.style.Widget_MaterialComponents_Button_TextButton).apply {
            text = "Saxlanmış nüsxə"
            isAllCaps = false
            setOnClickListener { if (saving?.isActive != true) open(current, true) }
        }
        actions.addView(btnSave)
        actions.addView(btnSaved)
        root.addView(actions)

        status = TextView(this).apply {
            textSize = 13f
            setPadding(dp(16), 0, dp(16), dp(4))
        }
        root.addView(status)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = UA
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val sc = request.url.scheme
                return sc != "http" && sc != "https" && sc != "file"
            }

            override fun onPageFinished(view: WebView, url: String?) {
                progress.visibility = View.GONE
                pageDone?.complete(Unit)
            }
        }
        web.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })
        open(0, false)
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        saving?.cancel()
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    private fun highlight(i: Int) {
        current = i
        tabs.forEachIndexed { k, b ->
            b.alpha = if (k == i) 1f else 0.55f
            b.setTypeface(null, if (k == i) Typeface.BOLD else Typeface.NORMAL)
            if (k == i) b.setTextColor(Brand.colorOf(users[k].first))
        }
    }

    private fun savedInfo(user: String): String {
        val f = archive(user)
        return if (f.exists() && f.length() > 0)
            "Saxlanıb: " + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(Date(f.lastModified()))
        else "Offline nüsxə yoxdur"
    }

    /** forceSaved=true → internet olsa belə saxlanmış nüsxə açılır. */
    private fun open(i: Int, forceSaved: Boolean) {
        highlight(i)
        val user = users[i].second
        val f = archive(user)
        val hasCopy = f.exists() && f.length() > 0
        if (forceSaved || !Store.online(this)) {
            if (!hasCopy) {
                web.loadUrl("about:blank")
                status.text = if (forceSaved) "Bu market üçün saxlanmış nüsxə yoxdur" else "Oflayn — saxlanmış nüsxə yoxdur"
                return
            }
            web.settings.javaScriptEnabled = false   // arxiv statik göstərilir (Instagram skriptləri oflayn səhifəni pozmasın)
            web.loadUrl("file://" + f.absolutePath)
            status.text = "Oflayn nüsxə · " + savedInfo(user)
        } else {
            web.settings.javaScriptEnabled = true
            web.loadUrl("https://www.instagram.com/$user/")
            status.text = "Canlı · " + savedInfo(user)
        }
    }

    private suspend fun evalInt(js: String): Int = suspendCoroutine { c ->
        web.evaluateJavascript(js) { c.resume(it?.trim('"')?.toIntOrNull() ?: 0) }
    }

    /** Səhifəni sürüşdürüb ən azı 20 post linki yüklənənə qədər gözləyir; 20-dən artığını gizlədir. */
    private suspend fun scrollForPosts(): Int {
        val count = "(function(){window.scrollTo(0,document.body.scrollHeight);var s={};" +
            "document.querySelectorAll('a[href*=\"/p/\"],a[href*=\"/reel/\"]').forEach(function(a){s[a.getAttribute('href')]=1});" +
            "return Object.keys(s).length;})()"
        var best = 0
        var stale = 0
        for (step in 0 until 30) {
            val n = evalInt(count)
            if (n > best) { best = n; stale = 0 } else stale++
            if (best >= TARGET || stale >= 4) break
            delay(1200)
        }
        if (best > 0) {
            evalInt(
                "(function(){var seen={},k=0;document.querySelectorAll('a[href*=\"/p/\"],a[href*=\"/reel/\"]').forEach(function(a){" +
                    "var h=a.getAttribute('href');if(!seen[h]){seen[h]=1;k++;}if(k>$TARGET){a.style.display='none';}});" +
                    "window.scrollTo(0,0);return k;})()"
            )
        }
        return best
    }

    private suspend fun saveArchive(user: String): Boolean = suspendCoroutine { c ->
        val f = archive(user)
        val tmp = File(f.path + ".part")
        tmp.delete()
        web.saveWebArchive(tmp.absolutePath, false) { path ->
            if (path != null && tmp.length() > 0 && tmp.renameTo(f)) c.resume(true)
            else {
                tmp.delete()
                c.resume(false)
            }
        }
    }

    private fun saveAll() {
        if (saving?.isActive == true) {
            saving?.cancel()
            btnSave.text = "Hamısını offline yüklə"
            status.text = "Dayandırıldı"
            return
        }
        if (!Store.online(this)) {
            status.text = "İnternet yoxdur — offline yükləmək olmur"
            return
        }
        btnSave.text = "Dayandır"
        saving = lifecycleScope.launch {
            web.settings.javaScriptEnabled = true
            var ok = 0
            var failed = 0
            var loginNeeded = false
            for ((i, p) in users.withIndex()) {
                highlight(i)
                status.text = "${i + 1}/${users.size} ${p.first} yüklənir…"
                val done = CompletableDeferred<Unit>()
                pageDone = done
                web.loadUrl("https://www.instagram.com/${p.second}/")
                val loaded = withTimeoutOrNull(30_000) { done.await(); true } ?: false
                if (!loaded) { failed++; continue }
                delay(2500)
                if (web.url?.contains("accounts/login") == true) {
                    loginNeeded = true
                    break
                }
                val n = scrollForPosts()
                if (n == 0) { failed++; continue }
                status.text = "${i + 1}/${users.size} ${p.first}: $n post saxlanılır…"
                delay(1500)
                if (saveArchive(p.second)) ok++ else failed++
            }
            btnSave.text = "Hamısını offline yüklə"
            status.text = when {
                loginNeeded -> "Instagram giriş tələb edir — aşağıda daxil olun, sonra yenidən \"Hamısını offline yüklə\" basın ($ok saxlanıb)"
                else -> "Bitdi: $ok saxlanıb" + if (failed > 0) ", $failed uğursuz" else ""
            }
        }
    }
}
