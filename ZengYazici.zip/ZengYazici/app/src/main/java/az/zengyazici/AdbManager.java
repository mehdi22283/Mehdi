package az.zengyazici;

import android.content.Context;
import android.os.Build;

import androidx.annotation.NonNull;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;

/** Tətbiqin öz-özünə Wireless ADB ilə qoşulması. Açar bir dəfə yaradılır və saxlanır (cütləşmə qalıcıdır). */
public class AdbManager extends AbsAdbConnectionManager {
    private static AdbManager INSTANCE;

    public static synchronized AdbManager get(Context c) throws Exception {
        if (INSTANCE == null) INSTANCE = new AdbManager(c.getApplicationContext());
        return INSTANCE;
    }

    private PrivateKey privateKey;
    private Certificate certificate;

    private AdbManager(Context c) throws Exception {
        setApi(Build.VERSION.SDK_INT);
        File kf = new File(c.getFilesDir(), "adb_key.pk8");
        File cf = new File(c.getFilesDir(), "adb_cert.der");
        if (kf.exists() && cf.exists()) {
            try {
                privateKey = KeyFactory.getInstance("RSA")
                        .generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(kf.toPath())));
                certificate = CertificateFactory.getInstance("X.509")
                        .generateCertificate(new ByteArrayInputStream(Files.readAllBytes(cf.toPath())));
            } catch (Exception e) {
                privateKey = null;
                certificate = null;
            }
        }
        if (privateKey == null || certificate == null) {
            Object[] kc = AdbKeys.generate();
            privateKey = (PrivateKey) kc[0];
            certificate = (Certificate) kc[1];
            try (FileOutputStream o = new FileOutputStream(kf)) { o.write(privateKey.getEncoded()); }
            try (FileOutputStream o = new FileOutputStream(cf)) { o.write(certificate.getEncoded()); }
        }
    }

    @NonNull @Override protected PrivateKey getPrivateKey() { return privateKey; }
    @NonNull @Override protected Certificate getCertificate() { return certificate; }
    @NonNull @Override protected String getDeviceName() { return "ZengYazici"; }

    /** shell əmrini icra edir və çıxışı qaytarır. */
    public String run(String cmd) throws Exception {
        AdbStream s = openStream("shell:" + cmd);
        try {
            InputStream in = s.openInputStream();
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            try {
                int n;
                while ((n = in.read(b)) > 0) o.write(b, 0, n);
            } catch (IOException ignored) { }
            return o.toString("UTF-8");
        } finally {
            try { s.close(); } catch (Exception ignored) { }
        }
    }
}
