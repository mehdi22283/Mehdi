# Zəng Yazıcı (Telefon + WhatsApp) — kompüter lazım deyil
1. APK-nı quraşdır və aç.
2. Ekrandakı 3 düyməni sıra ilə bas (icazələr, WhatsApp aşkarlama, batareya).
3. Tətbiq daimi bildirişlə arxa fonda işləyir. Yazı başlayanda və bitəndə bildiriş çıxır.
4. Filtr: Hamısı / Gələn / Gedən. Siyahıdan toxunub dinlə.
5. "Köçür" düyməsi yazıları Download/ZengYazici qovluğuna çıxarır.
Telefon yenidən başlayanda tətbiqi bir dəfə aç.
(İstəyə bağlı: tools/adbtool.py kompüterdən sürətli quraşdırma üçündür, məcburi deyil.)
