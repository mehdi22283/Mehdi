package az.wifiscan

import java.io.File
import java.net.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentSkipListSet

class Device(val ip: String) {
    @Volatile var mac = ""
    @Volatile var name = ""
    @Volatile var vendor = ""
    @Volatile var type = "❓ Naməlum"
    @Volatile var model = ""
    @Volatile var http = ""
    @Volatile var upnp = ""
    @Volatile var isSelf = false
    @Volatile var isGateway = false
    @Volatile var randomMac = false
    val ports = ConcurrentSkipListSet<Int>()
}

class Upnp(val friendly: String, val maker: String, val model: String, val server: String)

object Store {
    val devices = ConcurrentHashMap<String, Device>()
    val upnp = ConcurrentHashMap<String, Upnp>()
    @Volatile var gateway = ""
    @Volatile var localIp = ""
}

object Oui {
    private val raw = mapOf(
        "Apple" to "3C:07:54,F0:18:98,A4:5E:60,D0:03:4B,00:03:93,00:0A:95,28:CF:E9,AC:BC:32,F4:5C:89,BC:92:6B,DC:2B:2A,88:66:A5,14:98:77,70:56:81",
        "Samsung" to "FC:A1:3E,8C:77:12,5C:0A:5B,78:47:1D,E8:50:8B,CC:07:AB,94:35:0A,38:2D:E8,00:12:47",
        "Xiaomi" to "28:6C:07,F8:A4:5F,64:09:80,34:CE:00,50:64:2B,78:11:DC,8C:BE:BE,98:FA:E3,64:B4:73,9C:99:A0",
        "Huawei" to "00:E0:FC,48:46:FB,AC:E2:15,10:1B:54,00:9A:CD,70:72:3C,28:6E:D4,0C:37:DC",
        "Hikvision" to "44:19:B6,C0:56:E3,28:57:BE,4C:BD:8F,54:C4:15,BC:AD:28,A4:14:37,18:68:CB,24:0F:9B,8C:E7:48",
        "Dahua" to "3C:EF:8C,4C:11:BF,9C:8E:CD,E0:50:8B,90:02:A9,BC:32:5F,A0:BD:1D,38:AF:29",
        "TP-Link" to "50:C7:BF,98:DA:C4,F4:F2:6D,14:CC:20,EC:08:6B,A0:F3:C1,C0:25:E9,60:E3:27,1C:3B:F3,B0:4E:26,30:B5:C2,54:A7:03,10:FE:ED,D8:07:B6",
        "Ubiquiti" to "24:A4:3C,44:D9:E7,78:8A:20,FC:EC:DA,80:2A:A8,04:18:D6,F0:9F:C2,74:83:C2,68:D7:9A,B4:FB:E4,E0:63:DA,60:22:32,18:E8:29",
        "MikroTik" to "4C:5E:0C,64:D1:54,6C:3B:6B,CC:2D:E0,E4:8D:8C,D4:CA:6D,B8:69:F4,48:8F:5A,2C:C8:1B",
        "Espressif (IoT)" to "24:0A:C4,30:AE:A4,84:0D:8E,A4:CF:12,CC:50:E3,EC:FA:BC,24:6F:28,BC:DD:C2,7C:9E:BD,3C:71:BF",
        "Raspberry Pi" to "B8:27:EB,DC:A6:32,E4:5F:01,D8:3A:DD,28:CD:C1",
        "Google" to "F4:F5:D8,3C:5A:B4,54:60:09,1C:F2:9A,A4:77:33",
        "Intel" to "00:1B:21,3C:97:0E,8C:8D:28,A4:4C:C8,7C:B2:7D,F8:94:C2",
        "Cisco" to "00:1B:54,00:40:96,00:0C:85,F8:72:EA",
        "Netgear" to "00:14:6C,20:E5:2A,A0:63:91,9C:3D:CF",
        "D-Link" to "00:05:5D,1C:7E:E5,28:10:7B,C8:BE:19",
        "Tenda" to "C8:3A:35,04:95:E6,50:2B:73",
        "Sony" to "00:13:A9,FC:F1:52,54:42:49",
        "LG" to "00:1C:62,34:4D:F7,A8:23:FE",
        "Microsoft" to "00:50:F2,28:18:78,7C:ED:8D",
        "Amazon" to "44:65:0D,68:54:FD,FC:65:DE",
        "Dell" to "00:14:22,F8:BC:12,18:03:73",
        "HP" to "00:1B:78,3C:D9:2B,9C:B6:54",
        "Lenovo" to "00:59:07,54:E1:AD,98:FA:9B",
        "ASUS" to "00:1A:92,2C:56:DC,04:92:26"
    )
    private val map: Map<String, String> by lazy {
        val m = HashMap<String, String>()
        for ((v, l) in raw) for (p in l.split(",")) m[p.trim()] = v
        m
    }
    fun vendor(mac: String): String = if (mac.length >= 8) map[mac.substring(0, 8).uppercase()] ?: "" else ""
    fun isRandom(mac: String) = mac.length >= 2 && "26AE".indexOf(mac[1].uppercaseChar()) >= 0
}

object Net {
    val PORTS = linkedMapOf(
        21 to "FTP", 22 to "SSH", 23 to "Telnet", 53 to "DNS", 80 to "HTTP", 81 to "HTTP-alt", 135 to "RPC",
        139 to "NetBIOS", 443 to "HTTPS", 445 to "SMB", 515 to "LPD", 548 to "AFP", 554 to "RTSP (kamera)",
        631 to "IPP (printer)", 1883 to "MQTT", 3000 to "HTTP-alt", 3389 to "RDP", 4370 to "ZKTeco",
        5000 to "UPnP/NAS", 5060 to "SIP", 5555 to "ADB", 5900 to "VNC", 7000 to "AirPlay", 7547 to "TR-069",
        8000 to "HTTP-alt", 8001 to "Samsung TV", 8002 to "Samsung TV", 8008 to "Chromecast", 8009 to "Chromecast",
        8080 to "HTTP-proxy", 8081 to "HTTP-alt", 8090 to "HTTP-alt", 8291 to "MikroTik Winbox", 8443 to "HTTPS-alt",
        8728 to "MikroTik API", 8883 to "MQTT-TLS", 8899 to "Kamera (ONVIF)", 9000 to "HTTP-alt",
        9100 to "Printer RAW", 32400 to "Plex", 34567 to "DVR", 37777 to "Dahua", 49152 to "UPnP", 62078 to "iPhone sync"
    )

    fun toInt(ip: String): Int {
        val p = ip.split(".")
        return (p[0].toInt() shl 24) or (p[1].toInt() shl 16) or (p[2].toInt() shl 8) or p[3].toInt()
    }
    fun fromInt(v: Int) = "${(v ushr 24) and 255}.${(v ushr 16) and 255}.${(v ushr 8) and 255}.${v and 255}"

    fun open(ip: String, port: Int, timeout: Int = 600): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(ip, port), timeout) }; true
    } catch (e: Exception) { false }

    fun alive(ip: String): Boolean {
        try { if (InetAddress.getByName(ip).isReachable(300)) return true } catch (e: Exception) {}
        for (p in intArrayOf(80, 443, 445, 22, 8080, 554, 139, 53, 62078, 5555, 8000, 7000)) {
            try { Socket().use { it.connect(InetSocketAddress(ip, p), 250) }; return true }
            catch (e: ConnectException) { if ((e.message ?: "").contains("refused", true)) return true }
            catch (e: Exception) {}
        }
        return false
    }

    fun arp(ip: String): String {
        try {
            for (l in File("/proc/net/arp").readLines()) {
                val f = l.trim().split(Regex("\\s+"))
                if (f.size >= 4 && f[0] == ip && f[2] == "0x2" && f[3] != "00:00:00:00:00:00") return f[3].uppercase()
            }
        } catch (e: Exception) {}
        return ""
    }

    fun dns(ip: String): String = try {
        val n = InetAddress.getByName(ip).canonicalHostName
        if (n == ip) "" else n
    } catch (e: Exception) { "" }

    fun netbios(ip: String): String {
        try {
            val q = ByteArray(50)
            q[0] = 0x82.toByte(); q[1] = 0x28; q[5] = 1; q[12] = 0x20
            val nm = "CKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
            for (i in nm.indices) q[13 + i] = nm[i].code.toByte()
            q[47] = 0x21; q[49] = 1
            val s = DatagramSocket(); s.soTimeout = 600
            s.send(DatagramPacket(q, q.size, InetAddress.getByName(ip), 137))
            val r = ByteArray(1024); val pk = DatagramPacket(r, r.size)
            s.receive(pk); s.close()
            if (pk.length < 57 || (r[56].toInt() and 255) == 0) return ""
            return String(r, 57, 15).filter { it.code in 32..126 }.trim()
        } catch (e: Exception) { return "" }
    }

    fun http(ip: String, port: Int): String {
        try {
            val c = URL("http://$ip:$port/").openConnection() as HttpURLConnection
            c.connectTimeout = 800; c.readTimeout = 1200; c.instanceFollowRedirects = false
            val code = c.responseCode
            val server = c.getHeaderField("Server") ?: ""
            val realm = (c.getHeaderField("WWW-Authenticate") ?: "").substringAfter("realm=", "").trim('"', ' ')
            var title = ""
            try {
                val s = if (code >= 400) c.errorStream else c.inputStream
                if (s != null) {
                    val b = ByteArray(4096); val n = s.read(b)
                    val body = String(b, 0, maxOf(n, 0))
                    title = Regex("(?i)<title[^>]*>(.*?)</title>", RegexOption.DOT_MATCHES_ALL).find(body)?.groupValues?.get(1)?.trim() ?: ""
                }
            } catch (e: Exception) {}
            c.disconnect()
            return listOf(title, realm, server).filter { it.isNotBlank() }.joinToString(" | ").take(80)
        } catch (e: Exception) { return "" }
    }

    fun classify(d: Device) {
        val u = Store.upnp[d.ip]
        if (!d.isSelf) {
            if (u != null) {
                if (d.vendor.isBlank()) d.vendor = u.maker
                if (d.name.isBlank()) d.name = u.friendly
                d.upnp = listOf(u.friendly, u.server).filter { it.isNotBlank() }.joinToString(" | ")
            }
            d.model = when {
                u != null && u.model.isNotBlank() -> "${u.maker} ${u.model}".trim()
                d.http.isNotBlank() -> d.http
                else -> ""
            }
        }
        val t = listOf(d.name, d.vendor, d.model, d.http, d.upnp).joinToString(" ").lowercase()
        val p = d.ports
        fun k(vararg w: String) = w.any { t.contains(it) }
        fun hp(vararg x: Int) = x.any { p.contains(it) }
        d.type = when {
            d.isSelf -> "📱 Bu cihaz (Telefon)"
            d.isGateway -> "🌐 Router / Gateway"
            k("hikvision", "dahua", "reolink", "uniview", "amcrest", "foscam", "ipcam", "ip camera", "netcam", "dvr", "nvr", "onvif") || hp(554, 37777, 34567, 8899) -> "📷 IP Kamera / NVR"
            k("zkteco", "suprema", "anviz", "access control", "attendance", "turnstile") || hp(4370) -> "🚪 Access Control"
            hp(9100, 631, 515) || k("printer", "laserjet", "epson", "brother") -> "🖨 Printer"
            k("mikrotik", "routeros") || hp(8291, 8728) -> "🌐 Router (MikroTik)"
            k("access point", "unifi", "ubiquiti", "omada", "aruba", "ruijie") -> "📡 Access Point"
            k("smart tv", "bravia", "webos", "tizen", "roku", "chromecast", "android tv") || hp(8001, 8002, 8008, 8009) -> "📺 TV / Media"
            k("iphone", "ipad", "android", "galaxy", "redmi", "xiaomi", "huawei", "oppo", "vivo", "realme", "poco", "pixel") || hp(62078) -> "📱 Telefon / Planşet"
            k("espressif", "tuya", "shelly", "sonoff") || hp(1883) -> "💡 IoT cihaz"
            hp(445, 3389, 135, 139) || k("dell", "lenovo", "asus", "intel", "microsoft", "hp") -> "💻 Kompüter"
            k("raspberry") || hp(22) -> "🖥 Server / Linux"
            k("tp-link", "d-link", "tenda", "netgear", "zyxel", "cisco") -> "📡 Şəbəkə cihazı (AP/Switch)"
            d.randomMac -> "📱 Telefon (təsadüfi MAC)"
            else -> "❓ Naməlum"
        }
    }
}
