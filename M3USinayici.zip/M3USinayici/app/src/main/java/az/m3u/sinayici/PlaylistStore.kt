package az.m3u.sinayici

import android.content.Context
import java.io.File
import java.io.FileOutputStream

/**
 * Playlistlərin daimi yaddaşı (filesDir):
 *  playlist<N>.m3u      - əsas fayl (N=1 Ottplayer, N=2 digər mənbələr)
 *  playlist<N>.bak.m3u  - əvvəlki versiyanın ehtiyat nüsxəsi (əsas fayl itərsə/boş qalarsa oradan oxunur)
 *  playlist<N>.url      - mənbə linki, playlist<N>.name - fayl adı
 * SharedPreferences "m3u": lastList = ən son yüklənən playlistin nömrəsi (tətbiq açılanda o test olunmağa başlayır).
 */
object PlaylistStore {
    private fun main(c: Context, n: Int) = File(c.filesDir, "playlist$n.m3u")
    private fun bak(c: Context, n: Int) = File(c.filesDir, "playlist$n.bak.m3u")

    @Synchronized
    fun write(c: Context, n: Int, text: String, src: String?, name: String?) {
        val m = main(c, n)
        val tmp = File(c.filesDir, "playlist$n.m3u.tmp")
        FileOutputStream(tmp).use { it.write(text.toByteArray(Charsets.UTF_8)); it.fd.sync() }   // tam diskə yazılır
        try { if (m.exists() && m.length() > 0) m.copyTo(bak(c, n), overwrite = true) } catch (e: Exception) { }
        if (!tmp.renameTo(m)) { m.writeBytes(tmp.readBytes()); tmp.delete() }
        File(c.filesDir, "playlist$n.url").writeText(src ?: "")
        val nf = File(c.filesDir, "playlist$n.name")
        if (!name.isNullOrEmpty()) nf.writeText(name) else nf.delete()
        // commit(): tətbiq dərhal bağlansa da "son playlist" itməsin
        c.getSharedPreferences("m3u", Context.MODE_PRIVATE).edit()
            .putInt("lastList", n).putLong("lastListAt", System.currentTimeMillis()).commit()
    }

    @Synchronized
    fun read(c: Context, n: Int): String {
        for (f in listOf(main(c, n), bak(c, n))) {
            try { if (f.exists() && f.length() > 0) return f.readText() } catch (e: Exception) { }
        }
        return ""
    }

    fun readUrl(c: Context, n: Int): String =
        try { File(c.filesDir, "playlist$n.url").takeIf { it.exists() }?.readText()?.trim() ?: "" } catch (e: Exception) { "" }

    fun readName(c: Context, n: Int): String =
        try { File(c.filesDir, "playlist$n.name").takeIf { it.exists() }?.readText()?.trim() ?: "" } catch (e: Exception) { "" }

    fun lastList(c: Context): Int {
        val sp = c.getSharedPreferences("m3u", Context.MODE_PRIVATE)
        val v = sp.getInt("lastList", 0)
        if (v in 1..2 && read(c, v).isNotEmpty()) return v
        return if (read(c, 1).isNotEmpty()) 1 else if (read(c, 2).isNotEmpty()) 2 else 1
    }
}
