package az.market.endirim

import android.annotation.SuppressLint
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Mini brauzer: bütün marketlərin Instagram səhifələri.
 *  - Onlayn: səhifə canlı açılır (giriş bir dəfə edilir, cookie yadda qalır).
 *  - Offline nüsxə avtomatik yazılır (InstaAuto): tətbiqə daxil olanda gündə 1 dəfə, son 15 post, video yoxdur.
 *  - Oflayn: saxlanmış nüsxə (JS söndürülmüş halda) açılır.
 */
class InstaBrowserActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private val tabs = ArrayList<Button>()
    private val users: List<Pair<String, String>> = InstaSaver.users()
    private var viewingSaved = false
    private lateinit var tabScroll: HorizontalScrollView
    private var current = 0

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun archive(user: String) = InstaSaver.archive(this, user)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Brand.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
        }
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        users.forEachIndexed { i, (market, _) ->
            val b = Button(this, null, 0, com.google.android.material.R.style.Widget_MaterialComponents_Button_TextButton).apply {
                text = market
                isAllCaps = false
                setOnClickListener { open(i) }
            }
            tabs.add(b)
            tabRow.addView(b)
        }
        tabScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabRow)
        }
        root.addView(tabScroll)

        status = TextView(this).apply {
            textSize = 13f
            setPadding(dp(16), 0, dp(16), dp(4))
        }
        root.addView(status)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        // sağa/sola sürüşdürmə: digər marketin Instagram səhifəsinə keç
        var downX = 0f
        var downY = 0f
        var multi = false
        web.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> { downX = ev.x; downY = ev.y; multi = false }
                android.view.MotionEvent.ACTION_POINTER_DOWN -> multi = true
                android.view.MotionEvent.ACTION_UP -> {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (!multi && Math.abs(dx) > dp(90) && Math.abs(dx) > Math.abs(dy) * 2) {
                        val next = if (dx < 0) current + 1 else current - 1
                        if (next in users.indices) open(next)
                    }
                }
            }
            false   // WebView özü də toxunuşu işləsin
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = InstaSaver.UA
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val sc = u.scheme
                // offline nüsxədə post/profil linkləri yaddaşdakı nüsxələrə yönləndirilir
                if (viewingSaved && (u.host ?: "").endsWith("instagram.com")) {
                    val path = u.path ?: ""
                    val m = Regex("/(?:p|reel)/([^/?#]+)").find(path)
                    val user = users[current].second
                    val target = when {
                        m != null -> InstaSaver.postFile(this@InstaBrowserActivity, user, m.groupValues[1])
                        path.trim('/').equals(user, true) -> archive(user)
                        else -> null
                    }
                    if (target != null && target.exists() && target.length() > 0) {
                        view.loadUrl("file://" + target.absolutePath)
                    } else {
                        status.text = "Bu post offline saxlanmayıb (video ola bilər)"
                    }
                    return true
                }
                return sc != "http" && sc != "https" && sc != "file"
            }

            override fun onPageFinished(view: WebView, url: String?) {
                progress.visibility = View.GONE
            }
        }
        web.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })
        val start = users.indexOfFirst { it.first == intent.getStringExtra("market") }.coerceAtLeast(0)
        open(start)
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    private fun highlight(i: Int) {
        current = i
        tabs.forEachIndexed { k, b ->
            b.alpha = if (k == i) 1f else 0.55f
            b.setTypeface(null, if (k == i) Typeface.BOLD else Typeface.NORMAL)
            if (k == i) b.setTextColor(Brand.colorOf(users[k].first))
        }
        tabScroll.post { tabScroll.smoothScrollTo((tabs[i].left - dp(48)).coerceAtLeast(0), 0) }
    }

    private fun savedInfo(user: String): String {
        val f = archive(user)
        return if (f.exists() && f.length() > 0)
            "Saxlanıb: " + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).format(Date(f.lastModified()))
        else "Offline nüsxə yoxdur"
    }

    /** İnternet varsa canlı, yoxdursa avtomatik saxlanmış nüsxə açılır. */
    private fun open(i: Int) {
        highlight(i)
        val user = users[i].second
        val f = archive(user)
        val hasCopy = f.exists() && f.length() > 0
        viewingSaved = !Store.online(this)
        if (viewingSaved) {
            if (!hasCopy) {
                web.loadUrl("about:blank")
                status.text = "Oflayn — bu market üçün saxlanmış nüsxə yoxdur"
                return
            }
            web.settings.javaScriptEnabled = false   // arxiv statik göstərilir (Instagram skriptləri oflayn səhifəni pozmasın)
            web.loadUrl("file://" + f.absolutePath)
            status.text = "Oflayn nüsxə · " + savedInfo(user)
        } else {
            web.settings.javaScriptEnabled = true
            web.loadUrl("https://www.instagram.com/$user/")
            status.text = "Canlı · " + savedInfo(user) +
                when {
                    InstaSaver.needLogin(this) && !InstaSaver.loggedIn() -> " · Avtomatik yükləmə üçün burada Instagram-a daxil olun"
                    InstaSaver.lock.isLocked -> " · Offline nüsxə yenilənir…"
                    else -> ""
                }
        }
    }
}
