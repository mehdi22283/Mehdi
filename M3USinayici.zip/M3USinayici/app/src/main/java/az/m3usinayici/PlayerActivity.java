package az.m3usinayici;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.ui.PlayerView;

/** ExoPlayer (Media3) ilə tam ekran oynadıcı. */
public class PlayerActivity extends Activity {

    private PlayerView playerView;
    private TextView titleView;
    private TextView errorView;
    private ExoPlayer player;
    private DefaultHttpDataSource.Factory http;
    private String url;
    private String title;
    private int attempt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_player);

        playerView = findViewById(R.id.player_view);
        titleView = findViewById(R.id.title_view);
        errorView = findViewById(R.id.error_view);

        url = getIntent().getStringExtra("url");
        title = getIntent().getStringExtra("title");
        if (url == null) {
            finish();
            return;
        }
        titleView.setText(title == null || title.isEmpty() ? url : title);

        playerView.setControllerVisibilityListener(new PlayerView.ControllerVisibilityListener() {
            @Override
            public void onVisibilityChanged(int visibility) {
                titleView.setVisibility(visibility == View.VISIBLE ? View.VISIBLE : View.GONE);
            }
        });

        errorView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                errorView.setVisibility(View.GONE);
                attempt = 0;
                startPlayback();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (url == null) return;
        http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000)
                .setUserAgent(NativeBridge.UA);
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(this)
                .setEnableDecoderFallback(true);
        player = new ExoPlayer.Builder(this, renderers)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(http))
                .build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                if (attempt < 2) {
                    attempt++;
                    startPlayback();
                    return;
                }
                errorView.setText("Oynatmaq mümkün olmadı\n" + error.getErrorCodeName()
                        + "\n\nYenidən cəhd üçün toxunun");
                errorView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    errorView.setVisibility(View.GONE);
                }
            }
        });
        attempt = 0;
        startPlayback();
    }

    /**
     * 0-cı cəhd: ExoPlayer özü formatı seçir. Alınmasa 1-ci cəhd əks formatı məcburi sınayır
     * (uzantısız HLS linkləri və ya .m3u8 adlı, əslində TS axını olan linklər üçün).
     */
    private void startPlayback() {
        if (player == null) return;
        MediaItem item = MediaItem.fromUri(url);
        boolean hlsByExt = url.toLowerCase().contains(".m3u8");
        if (attempt == 0) {
            player.setMediaItem(item);
        } else {
            boolean useHls = (attempt == 1) ? !hlsByExt : hlsByExt;
            MediaSource src = useHls
                    ? new HlsMediaSource.Factory(http).createMediaSource(item)
                    : new ProgressiveMediaSource.Factory(http).createMediaSource(item);
            player.setMediaSource(src);
        }
        player.prepare();
        player.setPlayWhenReady(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            playerView.setPlayer(null);
            player.release();
            player = null;
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
}
