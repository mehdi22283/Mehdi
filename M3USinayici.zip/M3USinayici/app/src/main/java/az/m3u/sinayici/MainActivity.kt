package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var prevLogin = ""
    private val pool = Executors.newFixedThreadPool(24)
    private var fileCb: ValueCallback<Array<Uri>>? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("m3u", MODE_PRIVATE)
        prevLogin = sp.getString("lastLogin", "") ?: ""
        sp.edit().putString("lastLogin", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())).apply()
        web = WebView(this); setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = true
            allowFileAccessFromFileURLs = true; allowUniversalAccessFromFileURLs = true
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 2)
                return true
            }
            override fun onJsAlert(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r?.confirm() }
                    .setOnCancelListener { r?.cancel() }.show(); return true
            }
            override fun onJsConfirm(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r?.confirm() }
                    .setNegativeButton("Ləğv et") { _, _ -> r?.cancel() }.setOnCancelListener { r?.cancel() }.show(); return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq == 2) {
            val u = d?.data
            fileCb?.onReceiveValue(if (rs == RESULT_OK && u != null) arrayOf(u) else null); fileCb = null
        } else if (rq == 1 && rs == RESULT_OK) web.evaluateJavascript("ottImportFromNative()", null)
    }

    inner class Bridge {
        @JavascriptInterface fun openOtt() = runOnUiThread { startActivityForResult(Intent(this@MainActivity, BrowserActivity::class.java), 1) }
        @JavascriptInterface fun play(url: String, hdr: String) = runOnUiThread {
            startActivity(Intent(this@MainActivity, PlayerActivity::class.java).putExtra("url", url).putExtra("hdr", hdr))
        }
        @JavascriptInterface fun probe(url: String, hdr: String, id: Int) {
            pool.execute {
                val r = Net.probe(url, hdr)
                runOnUiThread { web.evaluateJavascript("__probeDone($id,'$r')", null) }
            }
        }
        @JavascriptInterface fun getSavedPlaylist(): String {
            val f = File(filesDir, "playlist1.m3u"); return if (f.exists()) f.readText() else ""
        }
        @JavascriptInterface fun getLastLogin(): String = prevLogin
    }
}
