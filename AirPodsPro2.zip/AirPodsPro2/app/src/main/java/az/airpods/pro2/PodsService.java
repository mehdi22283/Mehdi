package az.airpods.pro2;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Collections;
import java.util.List;

public class PodsService extends Service {
    static final String ACTION_STOP = "az.airpods.pro2.STOP";
    private static final String CH = "pods";
    private static final int NID = 11;
    private static final int RSSI_MIN = -78;
    private static final long STALE_MS = 9000;

    private final Handler h = new Handler(Looper.getMainLooper());
    private BluetoothLeScanner scanner;
    private boolean scanning = false;
    private long last = 0;
    private PodsState cur;
    private boolean active = false;

    private WindowManager wm;
    private View popup;
    private LinearLayout popupCard;
    private AirPodsView popupView;

    private final Runnable hideRun = new Runnable() { @Override public void run() { hidePopup(); } };
    private final Runnable retryRun = new Runnable() { @Override public void run() { startScan(); } };
    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            if (active && SystemClock.elapsedRealtime() - last > STALE_MS) {
                active = false;
                PodsStore.active = false;
                PodsStore.changed();
                notifyState(null);
            }
            h.postDelayed(this, 1500);
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        NotificationChannel ch = new NotificationChannel(CH, "AirPods batareyası", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        if (in != null && ACTION_STOP.equals(in.getAction())) {
            Prefs.set(this, "run", false);
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            Notification n = build("AirPods axtarılır…", "AirPods Pro 2");
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            } else {
                startForeground(NID, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        PodsStore.running = true;
        PodsStore.changed();
        h.removeCallbacks(watchdog);
        h.postDelayed(watchdog, 1500);
        startScan();
        return START_STICKY;
    }

    @SuppressLint("MissingPermission")
    private void startScan() {
        h.removeCallbacks(retryRun);
        if (scanning) return;
        try {
            BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter ad = bm == null ? null : bm.getAdapter();
            if (ad == null || !ad.isEnabled()) {
                PodsStore.btOff = true;
                PodsStore.changed();
                notifyText("Bluetooth söndürülüb");
                h.postDelayed(retryRun, 4000);
                return;
            }
            scanner = ad.getBluetoothLeScanner();
            if (scanner == null) { h.postDelayed(retryRun, 4000); return; }
            PodsStore.btOff = false;
            PodsStore.changed();

            ScanFilter f = new ScanFilter.Builder()
                    .setManufacturerData(PodsState.APPLE,
                            new byte[]{0x07, 0x19},
                            new byte[]{(byte) 0xFF, (byte) 0xFF})
                    .build();
            ScanSettings ss = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            scanner.startScan(Collections.singletonList(f), ss, cb);
            scanning = true;
            if (!active) notifyText("AirPods axtarılır…");
        } catch (Exception e) {
            h.postDelayed(retryRun, 5000);
        }
    }

    @SuppressLint("MissingPermission")
    private void stopScan() {
        h.removeCallbacks(retryRun);
        try { if (scanner != null && scanning) scanner.stopScan(cb); } catch (Exception ignored) { }
        scanning = false;
    }

    private final ScanCallback cb = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult r) { handle(r); }
        @Override public void onBatchScanResults(List<ScanResult> l) { for (ScanResult r : l) handle(r); }
        @Override public void onScanFailed(int code) {
            scanning = false;
            h.postDelayed(retryRun, 5000);
        }
    };

    @SuppressLint("MissingPermission")
    private void handle(final ScanResult r) {
        ScanRecord rec = r.getScanRecord();
        if (rec == null || r.getRssi() < RSSI_MIN) return;
        PodsState s = PodsState.parse(rec.getManufacturerSpecificData(PodsState.APPLE), r.getRssi(), r.getDevice().getAddress());
        if (s == null) return;

        long now = SystemClock.elapsedRealtime();
        if (cur != null && now - last < 3000 && !s.address.equals(cur.address) && s.rssi < cur.rssi) return;

        // qulaqlıq qabda olanda yayılmayan dəyər varsa son bilinəni saxla
        if (cur != null && now - last < 30000) {
            if (s.left < 0) s.left = cur.left;
            if (s.right < 0) s.right = cur.right;
            if (s.caseLevel < 0) s.caseLevel = cur.caseLevel;
        }

        boolean was = active;
        cur = s;
        last = now;
        active = true;
        PodsStore.state = s;
        PodsStore.active = true;
        PodsStore.changed();
        notifyState(s);

        if (!was) showPopup(s);
        else if (popupView != null) popupView.setData(s, true);
    }

    // ---------- bildiriş ----------
    private static String fmt(int v) { return v < 0 ? "—" : v + "%"; }

    private void notifyState(PodsState s) {
        if (s == null) {
            notifyText("Qab bağlıdır · son məlumat saxlanılıb");
            return;
        }
        notifyText("Sol " + fmt(s.left) + "   Sağ " + fmt(s.right) + "   Qab " + fmt(s.caseLevel));
    }

    private void notifyText(String text) {
        String title = cur != null ? cur.name : "AirPods Pro 2";
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NID, build(text, title));
    }

    private Notification build(String text, String title) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, PodsService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action act = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_stat_pods), "Dayandır", stop).build();
        return new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat_pods)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .addAction(act)
                .build();
    }

    // ---------- Apple tipli açılan kart ----------
    private void showPopup(PodsState s) {
        if (popup != null || !Prefs.popup(this) || !Settings.canDrawOverlays(this)) return;
        final float d = getResources().getDisplayMetrics().density;
        int sw = getResources().getDisplayMetrics().widthPixels;

        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding((int) (12 * d), 0, (int) (12 * d), (int) (20 * d));

        final LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF01C1C1E);
        bg.setCornerRadius(28 * d);
        card.setBackground(bg);
        card.setPadding((int) (16 * d), (int) (18 * d), (int) (16 * d), (int) (10 * d));

        TextView t = new TextView(this);
        t.setText(s.name);
        t.setTextColor(Color.WHITE);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        card.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final AirPodsView av = new AirPodsView(this);
        card.addView(av, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (270 * d)));
        wrap.addView(card, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        card.setOnTouchListener(new View.OnTouchListener() {
            float y0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        y0 = e.getRawY();
                        h.removeCallbacks(hideRun);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        v.setTranslationY(Math.max(0f, e.getRawY() - y0));
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        float ty = v.getTranslationY();
                        if (ty > 60 * d || (ty < 8 * d && e.getActionMasked() == MotionEvent.ACTION_UP)) {
                            hidePopup();
                        } else {
                            v.animate().translationY(0f).setDuration(200).start();
                            h.postDelayed(hideRun, 5000);
                        }
                        return true;
                }
                return false;
            }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                Math.min(sw, (int) (460 * d)),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;

        try {
            card.setTranslationY(500 * d);
            wm.addView(wrap, lp);
        } catch (Exception e) {
            return;
        }
        popup = wrap;
        popupCard = card;
        popupView = av;

        card.animate().translationY(0f).setDuration(520)
                .setInterpolator(new OvershootInterpolator(0.9f)).start();
        final PodsState sf = s;
        h.postDelayed(new Runnable() {
            @Override public void run() { if (popupView == av) av.setData(cur != null ? cur : sf, true); }
        }, 350);
        h.postDelayed(hideRun, 7000);
    }

    private void hidePopup() {
        h.removeCallbacks(hideRun);
        if (popup == null) return;
        final View v = popup;
        View card = popupCard;
        popup = null;
        popupCard = null;
        popupView = null;
        final float d = getResources().getDisplayMetrics().density;
        card.animate().translationY(420 * d).alpha(0f).setDuration(260)
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        try { wm.removeView(v); } catch (Exception ignored) { }
                    }
                }).start();
    }

    @Override public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        stopScan();
        if (popup != null) {
            try { wm.removeView(popup); } catch (Exception ignored) { }
            popup = null;
        }
        PodsStore.running = false;
        PodsStore.active = false;
        PodsStore.changed();
        super.onDestroy();
    }
}
