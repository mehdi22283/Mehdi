package az.m3u.sinayici

import org.json.JSONObject

/**
 * ottplayer.tv giriş səhifəsində email/şifrəni avtomatik doldurub OK (giriş) düyməsinə basır.
 * Təhlükəsizlik: hesab bloklanmasın deyə 10 dəqiqə ərzində ən çox 3 avtomatik göndərmə edilir
 * (səhv şifrə halında dövrə girmir). Artıq daxil olubsa (şifrə sahəsi yoxdursa) heç nə etmir.
 */
object OttLogin {
    private const val EMAIL = "mustafayev636@gmail.com"
    private const val PASS = "6700mehdi"

    fun host(h: String?) = h != null && (h == "ottplayer.tv" || h.endsWith(".ottplayer.tv"))

    fun js(): String = SCRIPT
        .replace("__EMAIL__", JSONObject.quote(EMAIL))
        .replace("__PASS__", JSONObject.quote(PASS))

    private val SCRIPT = """
(function(){
  if(window.__ottAutoRun) return; window.__ottAutoRun = true;
  var EMAIL = __EMAIL__, PASS = __PASS__;
  var LOGIN_RE = /^\s*(ok|ок|login|log in|sign in|submit|войти|вход|daxil ol|giriş|giris)\s*${'$'}/i;
  var OPEN_RE  = /^\s*(login|log in|sign in|войти|вход|daxil ol|giriş)\s*${'$'}/i;
  function vis(e){ var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function recent(){
    try { var a = JSON.parse(localStorage.getItem('__ottAuto') || '[]'), n = Date.now(); return a.filter(function(t){ return n - t < 600000; }); }
    catch(e){ return []; }
  }
  function mark(){ try { var a = recent(); a.push(Date.now()); localStorage.setItem('__ottAuto', JSON.stringify(a)); } catch(e){} }
  function setVal(el, v){
    el.focus();
    var d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if(d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input',  {bubbles:true}));
    el.dispatchEvent(new Event('change', {bubbles:true}));
    el.dispatchEvent(new Event('blur',   {bubbles:true}));
  }
  function findEmail(pw){
    var scope = pw.form || pw.parentElement;
    for(var i = 0; i < 6 && scope; i++){
      var c = [].slice.call(scope.querySelectorAll('input')).filter(function(x){
        var t = (x.type || 'text').toLowerCase();
        return x !== pw && vis(x) && (t === 'email' || t === 'text' || t === 'tel');
      });
      if(c.length) return {el: c[0], scope: scope};
      scope = scope.parentElement;
    }
    return null;
  }
  function findBtn(scope){
    var all = [].slice.call(scope.querySelectorAll('button, input[type=submit], input[type=button], a, [role=button]')).filter(vis);
    var sub = all.filter(function(b){ return (b.type || '').toLowerCase() === 'submit'; })[0];
    if(sub) return sub;
    var byText = all.filter(function(b){ return LOGIN_RE.test((b.innerText || b.value || '').trim()); })[0];
    return byText || null;
  }
  var tries = 0, opened = false, submitted = false;
  var timer = setInterval(function(){
    if(submitted || ++tries > 60){ clearInterval(timer); return; }
    var pw = [].slice.call(document.querySelectorAll('input[type=password]')).filter(vis)[0];
    if(!pw){
      // şifrə sahəsi yoxdur: ya artıq daxil olunub, ya da giriş forması açılmayıb → bir dəfə "Giriş" düyməsinə bas
      if(!opened && tries > 6){
        var o = [].slice.call(document.querySelectorAll('a, button, [role=button]')).filter(function(b){ return vis(b) && OPEN_RE.test((b.innerText || '').trim()); })[0];
        if(o){ opened = true; try { o.click(); } catch(e){} }
      }
      return;
    }
    var f = findEmail(pw);
    if(!f) return;
    if(recent().length >= 3){ clearInterval(timer); return; }   // dövrəyə girməsin / hesab bloklanmasın
    setVal(f.el, EMAIL);
    setVal(pw, PASS);
    submitted = true; clearInterval(timer);
    setTimeout(function(){
      mark();
      try { if(window.OttSyncBridge && OttSyncBridge.submitted) OttSyncBridge.submitted(); } catch(e){}
      var b = findBtn(pw.form || f.scope);
      if(b){ b.click(); }
      else if(pw.form){ try { pw.form.requestSubmit ? pw.form.requestSubmit() : pw.form.submit(); } catch(e){} }
      else { pw.dispatchEvent(new KeyboardEvent('keydown', {key:'Enter', keyCode:13, which:13, bubbles:true})); }
    }, 500);
  }, 500);
})();
"""
}
