package com.wifi.finder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private fun fmtD(d: Double) =
    (if (d < 10) String.format("%.1f", d) else String.format("%.0f", d)) + " m"

class OverlayView(ctx: Context) : View(ctx) {
    var heading = 0f
    var rel = Float.NaN
    var elev = 0f
    var ar = false
    var label = ""
    var ssid = ""
    /** Bütün görünən şəbəkələr (seçilmiş olan daxil). Seçilmiş birinci gəlir. */
    var items: List<OverlayItem> = emptyList()

    private val GOLD = Color.parseColor("#FFC107")
    private val CYAN = Color.parseColor("#4DD0E1")

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = CYAN
    }
    private val goldRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 7f; color = GOLD
    }
    private val arrow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#FF5252")
    }
    private val goldFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = GOLD
    }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.WHITE
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 44f
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }
    private val goldTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GOLD; textAlign = Paint.Align.CENTER; textSize = 48f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B0BEC5"); textAlign = Paint.Align.CENTER; textSize = 34f
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }
    private val mid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 32f
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }
    private val tiny = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B0BEC5"); textAlign = Paint.Align.CENTER; textSize = 26f
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }
    private val horizon = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.parseColor("#88FFFFFF")
        pathEffect = DashPathEffect(floatArrayOf(20f, 16f), 0f)
    }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#33FFC107")
    }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#99FFC107")
    }
    private val dotHalo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#334DD0E1")
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#CC4DD0E1")
    }
    private val legL = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.LEFT; textSize = 30f
    }
    private val legLGold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GOLD; textAlign = Paint.Align.LEFT; textSize = 32f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val legC = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CFD8DC"); textAlign = Paint.Align.CENTER; textSize = 30f
    }
    private val legCGold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GOLD; textAlign = Paint.Align.CENTER; textSize = 32f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val legBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#AA000000")
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (ar) drawAr(c, w, h) else drawCompass(c, w, h)
    }

    private fun legendText(it: OverlayItem): String =
        (if (it.selected) "\u2605 " else "\u2022 ") + it.name.take(22) + "  " +
            fmtD(it.dist) + (if (it.rtt) " RTT" else "")

    /** Bütün şəbəkələrin məsafə siyahısı. */
    private fun drawLegend(c: Canvas, x: Float, y0: Float, maxLines: Int, left: Boolean) {
        if (items.isEmpty() || maxLines <= 0) return
        val shown = if (items.size > maxLines) maxLines - 1 else items.size
        val lines = ArrayList<Pair<String, Boolean>>()
        for (i in 0 until shown) lines.add(legendText(items[i]) to items[i].selected)
        if (items.size > shown) lines.add("+${items.size - shown} digər" to false)
        val lh = 38f
        if (left) {
            var mw = 0f
            for (l in lines) mw = max(mw, legL.measureText(l.first))
            c.drawRoundRect(
                RectF(x - 10f, y0 - 32f, x + mw + 16f, y0 + lh * (lines.size - 1) + 14f),
                14f, 14f, legBg
            )
        }
        for ((i, l) in lines.withIndex()) {
            val p = if (left) (if (l.second) legLGold else legL) else (if (l.second) legCGold else legC)
            c.drawText(l.first, x, y0 + i * lh, p)
        }
    }

    private fun drawCompass(c: Canvas, w: Float, h: Float) {
        val r = min(w * 0.42f, h * 0.36f)
        val cx = w / 2
        val cy = r + 60f
        c.drawCircle(cx, cy, r, ring)
        c.save()
        c.rotate(-heading, cx, cy)
        for (k in 0 until 36) {
            val len = if (k % 9 == 0) 30f else if (k % 3 == 0) 18f else 10f
            c.drawLine(cx, cy - r, cx, cy - r + len, ring)
            c.rotate(10f, cx, cy)
        }
        c.restore()
        val names = arrayOf("N", "E", "S", "W")
        for (i in 0 until 4) {
            val th = Math.toRadians((-heading + i * 90f).toDouble())
            val x = cx + (r - 62f) * sin(th).toFloat()
            val y = cy - (r - 62f) * cos(th).toFloat() + 14f
            val p = if (i == 0) arrow else white
            c.drawText(names[i], x - 12f, y, Paint(p).apply { textSize = 40f })
        }
        // fixed "forward" marker
        val tri = Path().apply {
            moveTo(cx, cy - r - 4f); lineTo(cx - 16f, cy - r - 34f); lineTo(cx + 16f, cy - r - 34f); close()
        }
        c.drawPath(tri, white)

        // Seçilmiş şəbəkənin istiqamət oxu (qızılı)
        if (!rel.isNaN()) {
            c.save()
            c.rotate(rel, cx, cy)
            val a = Path().apply {
                moveTo(cx, cy - r * 0.8f)
                lineTo(cx - 48f, cy + r * 0.25f)
                lineTo(cx, cy + r * 0.1f)
                lineTo(cx + 48f, cy + r * 0.25f)
                close()
            }
            c.drawPath(a, goldFill)
            c.restore()
        } else {
            c.drawText("Telefonla yavaş 360° dönün", cx, cy, small)
        }

        // Radar: bütün şəbəkələr (yaxın = mərkəzə yaxın)
        for (pass in 0..1) {
            for (it in items) {
                if (it.rel.isNaN()) continue
                if ((pass == 1) != it.selected) continue
                val rr = r * (0.22f + 0.68f * sqrt(min(it.dist, 40.0) / 40.0).toFloat())
                val th = Math.toRadians(it.rel.toDouble())
                val x = cx + rr * sin(th).toFloat()
                val y = cy - rr * cos(th).toFloat()
                val d = fmtD(it.dist) + (if (it.rtt) " RTT" else "")
                if (it.selected) {
                    c.drawCircle(x, y, 38f, halo)
                    c.drawCircle(x, y, 22f, goldFill)
                    c.drawCircle(x, y, 22f, goldRing)
                    c.drawText("\u2605 $d", x, y - 52f, goldTxt)
                } else {
                    c.drawCircle(x, y, 20f, dotHalo)
                    c.drawCircle(x, y, 11f, dot)
                    c.drawText(d, x, y - 26f, mid)
                    c.drawText(it.name.take(14), x, y + 40f, tiny)
                }
            }
        }

        c.drawText(ssid, cx, cy + r + 60f, small)
        val top = cy + r + 108f
        val lines = ((h - top) / 38f).toInt().coerceIn(0, 7)
        drawLegend(c, cx, top, lines, false)
    }

    private fun drawAr(c: Canvas, w: Float, h: Float) {
        val cx = w / 2
        val cy = h / 2
        val hfov = 55f
        val vfov = 70f
        val yh = (cy + elev / vfov * h).coerceIn(0f, h)
        c.drawLine(0f, yh, w, yh, horizon)
        c.drawLine(cx - 30f, cy, cx + 30f, cy, ring)
        c.drawLine(cx, cy - 30f, cx, cy + 30f, ring)
        c.drawText("${heading.toInt()}°", cx, 70f, small)

        // Digər şəbəkələr (kiçik firuzəyi nöqtələr)
        var slot = 0
        for (it in items) {
            if (it.selected || it.rel.isNaN() || abs(it.rel) > hfov / 2) continue
            val x = cx + it.rel / hfov * w
            val y = (yh + ((slot % 3) - 1) * 150f).coerceIn(200f, h - 200f)
            slot++
            c.drawCircle(x, y, 26f, dotHalo)
            c.drawCircle(x, y, 14f, dot)
            c.drawCircle(x, y, 14f, ring)
            c.drawText(fmtD(it.dist) + (if (it.rtt) " RTT" else ""), x, y - 36f, mid)
            c.drawText(it.name.take(16), x, y + 56f, tiny)
        }

        // Hamısının məsafə siyahısı (sol üst)
        drawLegend(c, 24f, 130f, 7, true)

        if (rel.isNaN()) {
            c.drawText("Telefonu yavaş dönün...", cx, h * 0.2f + 300f, txt)
            return
        }
        if (abs(rel) <= hfov / 2) {
            val x = cx + rel / hfov * w
            val y = yh.coerceIn(140f, h - 140f)
            val pulse = sin(SystemClock.uptimeMillis() / 250.0).toFloat()
            val rad = 56f + 8f * pulse
            c.drawCircle(x, y, rad + 22f, halo)
            c.drawCircle(x, y, rad, mark)
            c.drawCircle(x, y, rad, goldRing)
            c.drawCircle(x, y, 8f, white)
            c.drawText("\u2605 $label", x, y - rad - 34f, goldTxt)
            c.drawText(ssid, x, y + rad + 54f, txt)
            if (yh < 140f) c.drawText("▲ yuxarı", cx, 130f, small)
            if (yh > h - 140f) c.drawText("▼ aşağı", cx, h - 120f, small)
            postInvalidateOnAnimation()
        } else {
            val left = rel < 0
            val x = if (left) 50f else w - 50f
            val dir = if (left) -1f else 1f
            val a = Path().apply {
                moveTo(x + dir * 30f, cy)
                lineTo(x - dir * 20f, cy - 45f)
                lineTo(x - dir * 20f, cy + 45f)
                close()
            }
            c.drawPath(a, goldFill)
            c.drawText("\u2605 $label", cx, cy - 120f, goldTxt)
            c.drawText(if (left) "◀ sola dönün" else "sağa dönün ▶", cx, cy - 70f, small)
        }
    }
}

class GraphView(ctx: Context) : View(ctx) {
    var data: List<Float> = emptyList()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.parseColor("#00E676")
    }
    private val grid = Paint().apply { color = Color.parseColor("#33FFFFFF"); strokeWidth = 1f }
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY; textSize = 24f }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(Color.parseColor("#101820"))
        for (v in intArrayOf(-40, -60, -80)) {
            val y = h - (v + 100f) / 70f * h
            c.drawLine(0f, y, w, y, grid)
            c.drawText("$v", 6f, y - 4f, t)
        }
        if (data.size < 2) return
        val p = Path()
        data.forEachIndexed { i, v ->
            val x = i.toFloat() / (data.size - 1) * w
            val y = (h - (v.coerceIn(-100f, -30f) + 100f) / 70f * h)
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        c.drawPath(p, line)
    }
}
