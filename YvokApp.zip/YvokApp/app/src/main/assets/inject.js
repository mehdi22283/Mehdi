(function () {
  var timer = null;

  window.__yvokRun = function (val) {
    if (timer) clearInterval(timer);
    var n = 0, filled = false;
    timer = setInterval(function () {
      n++;
      var ins = [].slice.call(document.querySelectorAll('input')).filter(function (i) {
        return ['hidden', 'checkbox', 'radio', 'button', 'submit'].indexOf(i.type) < 0 && i.offsetParent !== null;
      });
      var inp = ins.filter(function (i) {
        return /yv[öo]k|v[öo]en/i.test((i.placeholder || '') + (i.name || '') + (i.id || ''));
      })[0] || ins[0];
      var btn = [].slice.call(document.querySelectorAll('button,input[type=submit],a,div[role=button]'))
        .filter(function (x) { return /yoxla/i.test(x.innerText || x.value || ''); })[0];

      if (inp && inp.value !== val) {
        inp.focus();
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(inp, val);
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        inp.dispatchEvent(new Event('change', { bubbles: true }));
        filled = true;
      } else if (inp && inp.value === val) {
        filled = true;
      }
      if (filled && btn && !btn.disabled) {
        clearInterval(timer);
        setTimeout(function () { btn.click(); }, 400);
        return;
      }
      if (n > 60) clearInterval(timer);
    }, 500);
  };
})();
