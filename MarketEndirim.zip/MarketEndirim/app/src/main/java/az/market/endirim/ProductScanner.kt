package az.market.endirim

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

/**
 * Jurnalların bütün səhifələrini OCR ilə oxuyub məhsul adı + qiymət çıxarır.
 *  - PDF: hər səhifə render edilib oxunur;
 *  - şəkil albomu (Al Market): şəkillər endirilib oxunur;
 *  - veb-jurnal (Bravo flipbook): gizli WebView-da səhifələr ekran görüntüsü ilə oxunur (sınaqsız, ən zəif hissə).
 */
object ProductScanner {
    private const val PDF_W = 2000
    private const val MAX_H = 4200
    private const val MAX_IMG_W = 2400
    private const val MAX_WEB_PAGES = 60
    private val http = OkHttpClient()

    /** Jurnalın "barmaq izi": PDF üçün serverin ETag/Last-Modified/ölçüsü, digərləri üçün linklər. Dəyişəndə yenidən skan olunur. */
    fun sigFor(ctx: Context, c: Catalog): String? {
        val base = if (c.kind == Kind.PDF) Downloader.storedSig(ctx, c.urls[0]) else "u:" + c.urls.joinToString("|").hashCode()
        // onlayn OCR qoşulanda köhnə nəticələr bir dəfə yenidən oxunur
        var sig = base
        if (OcrSpace.enabled(ctx)) sig = (sig ?: "") + "|os"
        if (PaddleOcr.ready(ctx)) sig = (sig ?: "") + "|pd2"
        return sig
    }

    /** onPartial — hər səhifə oxunandan sonra bu jurnaldan indiyə qədər tapılan məhsullar (axtarışda dərhal görünsün deyə). */
    suspend fun scan(
        act: Activity, c: Catalog,
        onProgress: (page: Int, total: Int) -> Unit,
        onPartial: (List<Product>) -> Unit = {}
    ): List<Product> {
        appCtx = act.applicationContext
        val w = workers(appCtx)
        Ocr.tessMax = w                                   // Tesseract nüsxələri = paralel səhifə sayı
        PaddleOcr.threads = (4 / w).coerceAtLeast(1)      // səhifələr paralel olduğu üçün hər sessiyaya az axın
        return dedupe(
            when (c.kind) {
                Kind.PDF -> scanPdf(act.applicationContext, c, onProgress, onPartial)
                Kind.IMAGES -> scanImages(c, onProgress, onPartial)
                Kind.WEB -> scanWeb(act, c, onProgress, onPartial)
            }
        )
    }

    /** Ümumi skan faizi üçün jurnalın təxmini səhifə sayı (PDF — dəqiq, şəkil albomu — şəkil sayı, veb-jurnal — təxmini 20). */
    suspend fun estimatePages(ctx: Context, c: Catalog): Int = when (c.kind) {
        Kind.IMAGES -> c.urls.size.coerceAtLeast(1)
        Kind.WEB -> 20
        Kind.PDF -> try {
            withContext(Dispatchers.IO) {
                val f = Downloader.ensure(ctx, c.urls[0])
                val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                val r = PdfRenderer(pfd)
                try { r.pageCount.coerceAtLeast(1) } finally { r.close(); pfd.close() }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            10
        }
    }

    /** Eyni anda neçə səhifə oxunur: CPU nüvələrinə və yaddaşa görə (zəif telefonda 1, orta 2, güclü 3). */
    private fun workers(ctx: Context): Int {
        val cores = Runtime.getRuntime().availableProcessors()
        val mem = try {
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).largeMemoryClass
        } catch (e: Exception) {
            128
        }
        return when {
            cores >= 8 && mem >= 512 -> 3
            cores >= 4 && mem >= 256 -> 2
            else -> 1
        }
    }

    private fun dedupe(list: List<Product>): List<Product> {
        // eyni məhsul həm endirimli, həm endirimsiz tapılıbsa — endirimli qalır
        val promoKeys = list.filter { it.promo }.map { it.key }.toHashSet()
        val seen = HashSet<String>()
        return list.filter { (it.promo || it.key !in promoKeys) && seen.add(it.key + "|" + it.price) }
    }

    private lateinit var appCtx: Context

    /** ML Kit (latın/azərbaycan) sətirlərinə Tesseract-ın tapdığı rus sətirlərini əlavə edir; üst-üstə düşən ML Kit səpələnmələrini silir. */
    private fun mergeRu(mk: List<OLine>, ru: List<OLine>): List<OLine> {
        if (ru.isEmpty()) return mk
        fun overlap(a: OLine, b: OLine): Boolean {
            val ox = minOf(a.r, b.r) - maxOf(a.l, b.l)
            val oy = minOf(a.b, b.b) - maxOf(a.t, b.t)
            return ox > 0 && oy > 0 && oy >= 0.4f * minOf(a.h, b.h) && ox >= 0.3f * minOf(a.w, b.w)
        }
        return mk.filter { m -> ru.none { overlap(m, it) } } + ru
    }

    private fun lineScore(ls: List<OLine>): Int =
        ls.count { ProductParser.looksLikePrice(it.text) } * 3 + ls.count { l -> l.text.count { it.isLetter() } >= 3 }

    private class PageRaw(
        val mk: Result<List<OLine>>, val pad: List<OLine>?, val os: List<OLine>?,
        val cyr: List<OLine>, val az: List<OLine>
    )

    /** İstisnanı Result-a çevirir (qardaş korutinlər ləğv olunmasın; ləğv siqnalı isə yuxarı ötürülür). */
    private suspend inline fun <T> safe(block: () -> T): Result<T> = try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }

    private suspend fun mlKitLines(bmp: Bitmap): List<OLine> =
        Ocr.recognizeText(bmp).textBlocks.flatMap { it.lines }.mapNotNull { ln ->
            ln.boundingBox?.let { OLine(ln.text, it.left, it.top, it.right, it.bottom) }
        }

    private suspend fun pageProducts(bmp: Bitmap, c: Catalog, pageNo: Int): List<Product> {
        // Bütün mühərriklər eyni səhifəni EYNİ ANDA oxuyur (əvvəl ardıcıl idi): səhifə vaxtı = ən yavaş mühərrikin vaxtı.
        // Hər biri xətanı özündə saxlayır ki, digərləri yarıda kəsilməsin və bitmap oxunarkən recycle olunmasın.
        val raw = coroutineScope {
            val mkD = async { safe { mlKitLines(bmp) } }
            val padD: Deferred<Result<List<OLine>?>>? = if (PaddleOcr.enabled(appCtx)) async { safe { PaddleOcr.lines(appCtx, bmp) } } else null
            val osD: Deferred<Result<List<OLine>?>>? = if (OcrSpace.enabled(appCtx)) async { safe { OcrSpace.lines(appCtx, bmp) } } else null
            val tsD = async { safe { Ocr.cyrillicLines(appCtx, bmp) } }
            val ts = tsD.await().getOrNull()
            PageRaw(
                mkD.await(),
                padD?.await()?.getOrNull(),
                osD?.await()?.getOrNull(),
                ts?.first ?: emptyList(),
                ts?.second ?: emptyList()
            )
        }
        val mk = raw.mk.getOrThrow()
        // Bravo: qiymət yalnız rəngli nişanın içində (qırmızı fonda ağ / sarı fonda qırmızı); digər marketlər: yalnız ₼ işarəli qiymət
        val mode = if (c.market == BravoPdf.MARKET) ProductParser.Mode.BADGE else ProductParser.Mode.CURRENCY
        // Qiymətlər (₼ və rəqəmlər) ML Kit-dən götürülür — Paddle latın lüğətində ₼ yoxdur.
        // Məhsul ADLARI isə ən güclü mühərrikdən (oflayn PaddleOCR latın / onlayn OCR.space) götürülür və
        // ML Kit-in üst-üstə düşən ad sətirlərini əvəz edir.
        val cands = ArrayList<List<OLine>>()
        raw.pad?.let { cands.add(it) }
        raw.os?.let { cands.add(it) }
        fun nameLines(ls: List<OLine>) = ls.filter { l -> l.text.count { it.isLetter() } >= 3 && !l.text.contains('₼') }
        var names: List<OLine> = emptyList()
        for (cnd in cands) {
            val nl = nameLines(cnd)
            if (cnd.size >= 5 && nl.size > names.size) names = nl
        }
        var lines = if (names.isEmpty()) mk else mergeRu(mk, names)
        // Tesseract: kirill sətirlər həmişə; Azərbaycan hərfli sətirlər yalnız güclü mühərrik işləməyibsə
        lines = mergeRu(lines, if (names.isEmpty()) raw.cyr + raw.az else raw.cyr)
        val allowed = Frame.allowedFor(c.market)
        val badges = withContext(Dispatchers.Default) { Frame.badges(bmp, allowed) }
        if (badges.isNotEmpty()) lines = rescueBadges(bmp, lines, badges, mode)
        if (badges.isNotEmpty()) lines = verifyBadgePrices(bmp, lines, badges)
        // yalnız endirimli üslub (3.⁹⁹₼) qəbul olunur: əvvəlcə parçalar birləşir, sonra superscript quruluşu yoxlanır
        if (mode == ProductParser.Mode.CURRENCY) lines = confirmSuper(bmp, ProductParser.joinParts(lines))
        val raws = withContext(Dispatchers.Default) {
            ProductParser.parse(
                lines, bmp.width, bmp.height,
                framed = { ln -> Frame.inBadge(badges, ln) || Frame.isFramed(bmp, ln, allowed) },
                struck = { ln -> !Frame.inBadge(badges, ln) && Frame.isStruck(bmp, ln) },
                mode = mode,
                inBadge = { ln -> Frame.inBadge(badges, ln) }
            )
        }
        return raws.map {
            val nm = AzText.fix(it.name)          // ə/ı/ş/ç/ö/ü/ğ bərpası, kirill-latın qarışığı, böyük hərf
            Product(nm, it.price, it.old, c.market, c.urls[0], pageNo, Categorizer.classify(nm), it.promo)
        }
    }

    /** Bir nişanın rəqəmləri Tesseract ilə oxunur (kəsilmiş şəkil sonda həmişə recycle olunur). */
    private suspend fun readBadge(bmp: Bitmap, b: Frame.Badge): BadgeReader.Result? {
        val prep = try { Frame.prepare(bmp, b) } catch (e: Exception) { null } ?: return null
        return try {
            BadgeReader.parse(Ocr.digitSymbols(appCtx, prep.bmp))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        } finally {
            prep.bmp.recycle()
        }
    }

    private suspend fun readLine(bmp: Bitmap, ln: OLine): BadgeReader.Result? {
        val crop = try { Frame.cropLine(bmp, ln) } catch (e: Exception) { null } ?: return null
        return try {
            BadgeReader.parse(Ocr.digitSymbols(appCtx, crop))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        } finally {
            crop.recycle()
        }
    }

    /**
     * Hər qiymət nişanı ikinci mühərriklə (Tesseract, rəqəm-rəqəm koordinatla) yoxlanır: böyük tam hissə + kiçik yuxarı qəpik
     * ayrıca oxunur. ML Kit eyni qiyməti verirsə — toxunulmur; fərqlidirsə (və ya heç oxumayıbsa) — nişandakı qiymət sətri
     * "8.79₼" ilə əvəz olunur. Köhnə (üstündən xətt çəkilmiş) qiymət sətirlərinə toxunulmur.
     * Nişanların oxunması paralel gedir (Tesseract hovuzu ilə), nəticələr isə sonra ardıcıl tətbiq olunur.
     */
    private suspend fun verifyBadgePrices(bmp: Bitmap, lines: List<OLine>, badges: List<Frame.Badge>): List<OLine> {
        val limited = badges.take(40)
        val reads: List<BadgeReader.Result?> = coroutineScope {
            limited.map { b -> async(Dispatchers.Default) { readBadge(bmp, b) } }.awaitAll()
        }
        var out = lines
        for ((idx, b) in limited.withIndex()) {
            val res = reads[idx] ?: continue
            val inB = out.filter { Frame.inside(b, it) }
            val kit = inB.flatMap { ProductParser.findPrices(it.text) + ProductParser.findPricesStrict(it.text) }
            if (kit.any { Math.abs(it - res.price) < 0.005 }) continue            // iki mühərrik razıdır
            val need = if (kit.isEmpty()) 50f else 75f                              // ML Kit nəsə oxuyubsa — daha yüksək əminlik tələb olunur
            if (res.conf < need) continue
            val big = inB.filter { ln ->
                ln.text.any { it.isDigit() } && ln.h >= 0.45f * (b.b - b.t) && !Frame.isStruck(bmp, ln)
            }
            val l: Int; val t: Int; val r: Int; val bt: Int
            if (big.isNotEmpty()) {
                l = big.minOf { it.l }; t = big.minOf { it.t }; r = big.maxOf { it.r }; bt = big.maxOf { it.b }
            } else {
                val w = b.r - b.l; val h = b.b - b.t
                l = b.l + w / 6; t = b.t + h / 6; r = b.r - w / 6; bt = b.b - h / 6
            }
            val txt = String.format(java.util.Locale.US, "%.2f", res.price) + "₼"
            out = out.filter { it !in big } + OLine(txt, l, t, r, bt, true)   // BadgeReader: iri tam hissə + kiçik yuxarı qəpik = endirimli üslub
        }
        return out
    }


    /**
     * Endirimli qiymət üslubu: iri tam hissə + yuxarıda kiçik qəpik + ₼ (3.⁹⁹₼). ₼ olan, hələ "sup" sayılmayan hər sətir kəsilib
     * Tesseract ilə simvol-simvol oxunur; BadgeReader iri/kiçik quruluşu təsdiqləyirsə sətir "3.99₼" ilə əvəz olunub sup=true edilir,
     * təsdiqləmirsə (adi, eyni ölçülü rəqəmlər — endirimsiz qiymət) sup=false qalır və parser onu atır.
     * Tesseract modeli yoxdursa yoxlama mümkün deyil — qiymətlər olduğu kimi qəbul olunur ki, tətbiq boş qalmasın.
     * Sətirlər (ilk 80) paralel oxunur.
     */
    private suspend fun confirmSuper(bmp: Bitmap, lines: List<OLine>): List<OLine> {
        fun needs(ln: OLine) = !ln.sup && ln.text.contains('₼') && ln.text.any { it.isDigit() }
        if (lines.none { needs(it) }) return lines
        if (!Ocr.tessReady(appCtx)) return lines.map { if (!it.sup && it.text.contains('₼')) it.copy(sup = true) else it }
        val cand: List<Int> = lines.indices.filter { needs(lines[it]) }.take(80)
        val reads: List<BadgeReader.Result?> = coroutineScope {
            cand.map { idx -> async(Dispatchers.Default) { readLine(bmp, lines[idx]) } }.awaitAll()
        }
        val byIdx = HashMap<Int, BadgeReader.Result?>()
        for ((k, idx) in cand.withIndex()) byIdx[idx] = reads[k]
        return lines.mapIndexed { i, ln ->
            val res = byIdx[i]
            if (res == null) ln
            else OLine(String.format(java.util.Locale.US, "%.2f", res.price) + "₼", ln.l, ln.t, ln.r, ln.b, true)
        }
    }

    /** Nişanın içində qiymət oxunmayıbsa (məs. rəngli fonda ağ yazı) — nişan kəsilib qara-ağ çevrilir və yenidən oxunur. */
    private suspend fun rescueBadges(bmp: Bitmap, lines: List<OLine>, badges: List<Frame.Badge>, mode: ProductParser.Mode): List<OLine> {
        var out = lines
        var n = 0
        for (b in badges) {
            if (n >= 25) break
            val inBadge = out.filter { Frame.inside(b, it) }
            if (inBadge.any { ProductParser.looksLikePriceIn(it.text, mode) || (mode == ProductParser.Mode.BADGE && ProductParser.looksLikePrice(it.text)) }) continue
            val prep = Frame.prepare(bmp, b) ?: continue
            n++
            val extra: List<OLine> = try {
                Ocr.recognizeText(prep.bmp).textBlocks.flatMap { it.lines }.mapNotNull { ln ->
                    ln.boundingBox?.let { r -> OLine(ln.text, prep.mapX(r.left), prep.mapY(r.top), prep.mapX(r.right), prep.mapY(r.bottom)) }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            } finally {
                prep.bmp.recycle()
            }
            if (extra.any { ProductParser.looksLikePriceIn(it.text, mode) || (mode == ProductParser.Mode.BADGE && ProductParser.looksLikePrice(it.text)) }) {
                out = out.filter { !Frame.inside(b, it) } + extra
            }
        }
        return out
    }

    // ---------------- Səhifələrin paralel oxunması ----------------
    /**
     * Səhifələri paralel oxuyur: səhifənin hazırlanması (PDF render / şəkil endirmə) ardıcıl gedir — PdfRenderer eyni anda yalnız
     * bir səhifə açır — OCR isə eyni anda `workers` səhifədə işləyir. Hazır olan səhifənin məhsulları dərhal onPartial ilə verilir
     * (axtarışda skan davam etdikcə görünür). Bütün geri çağırışlar əsas axında (Main) çağrılır.
     * tolerant=false: bir səhifə oxunmasa jurnal "oxunmadı" sayılır (yarımçıq nəticə yadda qalmasın, növbəti dəfə yenidən cəhd olunsun).
     */
    private suspend fun scanPages(
        n: Int, c: Catalog, tolerant: Boolean,
        load: suspend (Int) -> Bitmap,
        onProgress: (Int, Int) -> Unit, onPartial: (List<Product>) -> Unit
    ): List<Product> {
        val gate = Semaphore(workers(appCtx))
        val pages = arrayOfNulls<List<Product>>(n)
        var done = 0
        var failed = 0
        onProgress(1, n)
        coroutineScope {
            for (i in 0 until n) {
                gate.acquire()
                val bmp: Bitmap? = try {
                    load(i)
                } catch (e: CancellationException) {
                    gate.release()
                    throw e
                } catch (e: Exception) {
                    gate.release()
                    null
                }
                if (bmp == null) {
                    failed++
                    done++
                    continue
                }
                launch(Dispatchers.Default) {
                    var list: List<Product>? = null
                    try {
                        list = pageProducts(bmp, c, i + 1)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                    } finally {
                        bmp.recycle()
                        gate.release()
                    }
                    val got = list
                    withContext(Dispatchers.Main) {
                        done++
                        if (got != null) pages[i] = got else failed++
                        onProgress(minOf(done + 1, n), n)
                        if (got != null) onPartial(dedupe(pages.filterNotNull().flatten()))
                    }
                }
            }
        }
        if (n > 0 && (failed == n || (failed > 0 && !tolerant))) throw IOException("Səhifələr oxunmadı")
        return pages.filterNotNull().flatten()
    }

    // ---------------- PDF ----------------
    private suspend fun scanPdf(ctx: Context, c: Catalog, onProgress: (Int, Int) -> Unit, onPartial: (List<Product>) -> Unit): List<Product> {
        val file = Downloader.ensure(ctx, c.urls[0])
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try {
            return scanPages(r.pageCount, c, false, { i -> withContext(Dispatchers.IO) { renderPage(r, i) } }, onProgress, onPartial)
        } finally {
            r.close()
            pfd.close()
        }
    }

    private fun renderPage(r: PdfRenderer, i: Int): Bitmap {
        val p = r.openPage(i)
        try {
            var w = PDF_W
            var h = (w.toFloat() * p.height / p.width).toInt()
            if (h > MAX_H) {
                w = (w.toFloat() * MAX_H / h).toInt()
                h = MAX_H
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            p.close()
        }
    }

    // ---------------- Şəkil albomu ----------------
    private suspend fun scanImages(c: Catalog, onProgress: (Int, Int) -> Unit, onPartial: (List<Product>) -> Unit): List<Product> =
        scanPages(c.urls.size, c, true, { i -> withContext(Dispatchers.IO) { download(c.urls[i]) } }, onProgress, onPartial)

    private fun download(url: String): Bitmap {
        val req = Request.Builder().url(url).header("User-Agent", Insta.UA).build()
        val bytes = http.newCall(req).execute().use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            it.body!!.bytes()
        }
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / sample > MAX_IMG_W) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2) ?: throw IOException("Şəkil açılmadı")
    }

    // ---------------- Veb-jurnal (Bravo flipbook) ----------------
    private suspend fun scanWeb(act: Activity, c: Catalog, onProgress: (Int, Int) -> Unit, onPartial: (List<Product>) -> Unit): List<Product> {
        val root = act.findViewById<ViewGroup>(android.R.id.content)
        val w = (act.resources.displayMetrics.widthPixels * 1.8f).toInt()    // böyük ölçü → kiçik yazılar da oxunur
        val h = (w * 1.45f).toInt()
        val web = WebView(act)
        val out = ArrayList<Product>()
        try {
            web.settings.javaScriptEnabled = true
            web.settings.domStorageEnabled = true
            web.translationX = -w.toFloat()          // ekranın kənarında, görünmür
            root.addView(web, FrameLayout.LayoutParams(w, h))
            web.loadUrl(c.urls[0])
            delay(8000)

            val seen = HashSet<String>()
            var method = 0
            var stale = 0
            var pages = 0
            for (n in 1..MAX_WEB_PAGES) {
                onProgress(n, 0)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                web.draw(Canvas(bmp))
                try {
                    val text = try { Ocr.recognizeText(bmp) } catch (e: Exception) { null }
                    val sig = Categorizer.norm(text?.text ?: "").filter { it.isLetterOrDigit() }.take(300)
                    if (text != null && sig.length >= 20 && seen.add(sig)) {
                        stale = 0
                        pages++
                        out.addAll(pageProducts(bmp, c, pages))
                        onPartial(dedupe(out))
                    } else {
                        stale++
                        if (stale >= 4) break
                        method = (method + 1) % 3     // səhifə dəyişmədi — başqa keçid üsulu sına
                    }
                } finally {
                    bmp.recycle()
                }
                advance(web, w, h, method)
                delay(2500)
            }
        } finally {
            root.removeView(web)
            web.destroy()
        }
        return out
    }

    /** Növbəti səhifəyə keç: 0 = klaviatura →, 1 = "next" düyməsinə klik, 2 = sola sürüşdürmə. */
    private fun advance(web: WebView, w: Int, h: Int, method: Int) {
        when (method) {
            0 -> {
                web.requestFocus()
                val t = SystemClock.uptimeMillis()
                web.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT, 0))
                web.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_RIGHT, 0))
            }
            1 -> web.evaluateJavascript(
                "(function(){var e=document.querySelector('[class*=\"next\" i],[class*=\"Next\"],[aria-label*=\"ext\" i],[title*=\"ext\" i]');if(e){e.click();}})()",
                null
            )
            else -> {
                val t0 = SystemClock.uptimeMillis()
                val y = h * 0.5f
                val x0 = w * 0.8f
                val x1 = w * 0.2f
                fun ev(action: Int, x: Float, dt: Long) =
                    MotionEvent.obtain(t0, t0 + dt, action, x, y, 0).also { web.dispatchTouchEvent(it); it.recycle() }
                ev(MotionEvent.ACTION_DOWN, x0, 0)
                for (i in 1..6) ev(MotionEvent.ACTION_MOVE, x0 + (x1 - x0) * i / 6f, i * 25L)
                ev(MotionEvent.ACTION_UP, x1, 175)
            }
        }
    }
}
