package az.m3u.sinayici

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.CookieManager
import android.widget.Toast

/** .zip endirmələri üçün sistemin endirmə yöneticisi: fonda davam edir, bildirişdə faiz, fayl telefonun Downloads qovluğuna yazılır. */
object ZipDl {
    private const val PREF = "zipdl"
    private const val KEY = "ids"

    /** true — endirmə yöneticisinə verildi; false — mümkün olmadı (çağıran daxili endirməyə keçir). */
    fun enqueue(ctx: Context, url: String, ua: String?, referer: String?, name: String): Boolean {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return false
        if (Build.VERSION.SDK_INT < 29 &&
            ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "yukleme_" + System.currentTimeMillis() + ".zip" }
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(safe)
                .setDescription("Zip endirilir")
                .setMimeType("application/zip")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safe)
            if (!ua.isNullOrBlank()) req.addRequestHeader("User-Agent", ua)
            if (!referer.isNullOrBlank()) req.addRequestHeader("Referer", referer)
            CookieManager.getInstance().getCookie(url)?.takeIf { it.isNotBlank() }?.let { req.addRequestHeader("Cookie", it) }
            val id = dm.enqueue(req)
            synchronized(this) {
                val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                val set = HashSet(sp.getStringSet(KEY, emptySet()) ?: emptySet())
                set.add(id.toString())
                sp.edit().putStringSet(KEY, set).apply()
            }
            true
        } catch (e: Exception) { false }
    }

    /** Bu id bizim endirməmizdir? Varsa siyahıdan çıxarır. */
    fun forget(ctx: Context, id: Long): Boolean = synchronized(this) {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val set = HashSet(sp.getStringSet(KEY, emptySet()) ?: emptySet())
        val had = set.remove(id.toString())
        if (had) sp.edit().putStringSet(KEY, set).apply()
        had
    }
}

/** Endirmə bitəndə (tətbiq fonda olsa belə) nəticəni bildirir. */
class DlDoneReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        if (id < 0 || !ZipDl.forget(c, id)) return
        val dm = c.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        try {
            dm.query(DownloadManager.Query().setFilterById(id))?.use { cur ->
                if (!cur.moveToFirst()) return
                val st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val title = cur.getString(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "zip"
                if (st == DownloadManager.STATUS_SUCCESSFUL) {
                    Toast.makeText(c, "Downloads-a yazıldı: $title", Toast.LENGTH_LONG).show()
                } else {
                    val r = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                    val why = when {
                        r in 400..599 -> "HTTP $r"
                        r == DownloadManager.ERROR_INSUFFICIENT_SPACE -> "yaddaş doludur"
                        r == DownloadManager.ERROR_DEVICE_NOT_FOUND -> "yaddaş tapılmadı"
                        r == DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "fayl artıq var"
                        r == DownloadManager.ERROR_HTTP_DATA_ERROR || r == DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "şəbəkə/server xətası"
                        r == DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "həddindən çox yönləndirmə"
                        else -> "kod $r"
                    }
                    Toast.makeText(c, "Endirmə xətası: $title ($why)", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) { }
    }
}
