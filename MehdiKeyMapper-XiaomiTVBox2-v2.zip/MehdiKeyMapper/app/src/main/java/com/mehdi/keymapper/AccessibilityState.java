package com.mehdi.keymapper;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.provider.Settings;
import android.text.TextUtils;

public final class AccessibilityState {
    private AccessibilityState() {}

    public static boolean isEnabled(Context context) {
        try {
            String enabled = Settings.Secure.getString(
                    context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (TextUtils.isEmpty(enabled)) return false;
            String wanted = ComponentName.unflattenFromString(Config.ACCESSIBILITY_COMPONENT).flattenToString();
            for (String value : enabled.split(":")) {
                if (wanted.equalsIgnoreCase(value)) return true;
            }
            return false;
        } catch (Throwable ignored) {
            return false;
        }
    }

    /**
     * Requires WRITE_SECURE_SETTINGS. That permission is intentionally not
     * grantable by a normal UI flow; the included ADB setup script grants it.
     */
    public static boolean ensureEnabled(Context context) {
        try {
            String old = Settings.Secure.getString(
                    context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            String wanted = Config.ACCESSIBILITY_COMPONENT;
            String merged = mergeColonList(old, wanted);
            Settings.Secure.putString(
                    context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
                    merged);
            Settings.Secure.putInt(
                    context.getContentResolver(),
                    Settings.Secure.ACCESSIBILITY_ENABLED,
                    1);
            return isEnabled(context);
        } catch (SecurityException ignored) {
            return false;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static String mergeColonList(String old, String wanted) {
        if (TextUtils.isEmpty(old)) return wanted;
        for (String item : old.split(":")) {
            if (wanted.equalsIgnoreCase(item)) return old;
        }
        return old + ":" + wanted;
    }
}
