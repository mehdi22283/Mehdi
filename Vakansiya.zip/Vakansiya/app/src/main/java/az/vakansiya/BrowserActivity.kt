package az.vakansiya

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class BrowserActivity : AppCompatActivity() {
    private lateinit var wv: WebView
    private lateinit var base: String

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    private fun btn(t: String, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setOnClickListener { click() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        base = intent.getStringExtra("base") ?: ""
        val start = intent.getStringExtra("start") ?: base
        val title = intent.getStringExtra("title") ?: ""

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#1F3A8A"))
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(btn("◀") { if (wv.canGoBack()) wv.goBack() })
        bar.addView(btn("🏠") { wv.loadUrl(base) })
        bar.addView(btn("⟳") { wv.reload() })
        bar.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 15f; maxLines = 1
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            gravity = Gravity.CENTER
        })
        bar.addView(btn("✕") { finish() })
        root.addView(bar)

        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3))
        }
        root.addView(pb)

        wv = WebView(this)
        root.addView(wv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: android.webkit.WebResourceRequest): Boolean {
                val u = r.url.toString()
                if (u.startsWith("http://") || u.startsWith("https://")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { }
                return true
            }
            override fun onPageStarted(v: WebView, u: String, f: android.graphics.Bitmap?) { pb.visibility = View.VISIBLE }
            override fun onPageFinished(v: WebView, u: String) {
                pb.visibility = View.GONE
                Store.setLast(this@BrowserActivity, base, u)
                CookieManager.getInstance().flush()
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { pb.progress = p }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (wv.canGoBack()) wv.goBack() else finish() }
        })
        wv.loadUrl(start)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        wv.destroy()
        super.onDestroy()
    }
}
