package com.mehdi.keymapper

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class MappingRepository(context: Context) {
    private val prefs = context.getSharedPreferences("key_mappings_pref", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getMappings(): MutableList<KeyMapping> {
        val json = prefs.getString("mappings", null) ?: return getDefaultMappings()
        val type = object : TypeToken<MutableList<KeyMapping>>() {}.type
        return try {
            gson.fromJson(json, type) ?: getDefaultMappings()
        } catch (e: Exception) {
            getDefaultMappings()
        }
    }

    fun saveMappings(list: List<KeyMapping>) {
        prefs.edit().putString("mappings", gson.toJson(list)).apply()
    }

    fun addMapping(mapping: KeyMapping) {
        val list = getMappings()
        list.add(mapping)
        saveMappings(list)
    }

    fun updateMapping(mapping: KeyMapping) {
        val list = getMappings()
        val index = list.indexOfFirst { it.id == mapping.id }
        if (index != -1) {
            list[index] = mapping
            saveMappings(list)
        }
    }

    fun deleteMapping(id: String) {
        val list = getMappings()
        list.removeAll { it.id == id }
        saveMappings(list)
    }

    private fun getDefaultMappings(): MutableList<KeyMapping> {
        val defaultList = mutableListOf(
            // BUTTON_6 (204) -> DPAD_LEFT (21)
            KeyMapping(
                triggerKeyCode = 204,
                isLongPress = false,
                targetKeyCode = 21,
                actionType = ActionType.KEY_REMAP,
                label = "BUTTON_6 -> DPAD_LEFT"
            ),
            // BUTTON_5 (203) -> DPAD_CENTER (23)
            KeyMapping(
                triggerKeyCode = 203,
                isLongPress = false,
                targetKeyCode = 23,
                actionType = ActionType.KEY_REMAP,
                label = "BUTTON_5 -> DPAD_CENTER"
            ),
            // BUTTON_7 (205) -> DPAD_RIGHT (22)
            KeyMapping(
                triggerKeyCode = 205,
                isLongPress = false,
                targetKeyCode = 22,
                actionType = ActionType.KEY_REMAP,
                label = "BUTTON_7 -> DPAD_RIGHT"
            ),
            // Long Press BUTTON_5 (203) -> Launch es.ottplayer.tv
            KeyMapping(
                triggerKeyCode = 203,
                isLongPress = true,
                targetPackage = "es.ottplayer.tv",
                actionType = ActionType.LAUNCH_APP,
                label = "Long Press BUTTON_5 -> OTT Player"
            ),
            // Long Press HOME (3) -> Force Stop Current App
            KeyMapping(
                triggerKeyCode = 3,
                isLongPress = true,
                actionType = ActionType.FORCE_STOP_CURRENT_APP,
                label = "Long Press HOME -> Force Stop App"
            )
        )
        saveMappings(defaultList)
        return defaultList
    }
}
