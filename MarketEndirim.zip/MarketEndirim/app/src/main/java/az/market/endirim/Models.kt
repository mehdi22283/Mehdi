package az.market.endirim

import java.io.Serializable

enum class Kind { PDF, IMAGES, WEB }

/** urls: PDF -> [pdf url], IMAGES -> şəkil linkləri, WEB -> [səhifə linki] */
data class Catalog(
    val market: String,
    val title: String,
    val date: String?,
    val kind: Kind,
    val urls: List<String>,
    val note: String? = null
) : Serializable

data class MarketResult(val market: String, val catalogs: List<Catalog>, val error: String?)

data class Row(val market: String, val date: String?, val sub: String?, val catalog: Catalog?)
