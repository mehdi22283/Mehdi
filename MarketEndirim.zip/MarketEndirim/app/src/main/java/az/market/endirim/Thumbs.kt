package az.market.endirim

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/** Jurnal miniatürləri (thumbnail): diskdə saxlanır, offline də görünür. */
object Thumbs {
    private const val W = 360

    private fun dir(ctx: Context) = File(ctx.filesDir, "thumbs").apply { mkdirs() }

    fun file(ctx: Context, url: String) = File(dir(ctx), url.hashCode().toUInt().toString(16) + ".jpg")

    fun exists(ctx: Context, url: String) = file(ctx, url).let { it.exists() && it.length() > 0 }

    /** Ekran görüntüsünü (məs. Bravo flipbook) miniatür kimi yazır. */
    fun save(ctx: Context, url: String, src: Bitmap) {
        try {
            val bmp = if (src.width > W) Bitmap.createScaledBitmap(src, W, (src.height * W.toFloat() / src.width).toInt(), true) else src
            val f = file(ctx, url)
            val tmp = File(f.path + ".part")
            FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            tmp.renameTo(f)
        } catch (e: Exception) {
        }
    }

    /** PDF üçün ilk səhifədən yaradır; digərləri üçün yalnız hazır fayl qaytarılır. */
    suspend fun get(ctx: Context, c: Catalog): File? = withContext(Dispatchers.IO) {
        val url = c.urls[0]
        val f = file(ctx, url)
        if (f.exists() && f.length() > 0) return@withContext f
        if (c.kind != Kind.PDF) return@withContext null
        try {
            val pdf = Downloader.ensure(ctx.applicationContext, url)
            ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                val r = PdfRenderer(pfd)
                try {
                    val p = r.openPage(0)
                    try {
                        val h = (W.toFloat() * p.height / p.width).toInt()
                        val bmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        save(ctx, url, bmp)
                    } finally {
                        p.close()
                    }
                } finally {
                    r.close()
                }
            }
            if (f.exists() && f.length() > 0) f else null
        } catch (e: Exception) {
            null
        }
    }

    /** Siyahıda olmayan köhnə miniatürləri silir. */
    fun cleanup(ctx: Context, keepUrls: Collection<String>) {
        val keep = keepUrls.map { file(ctx, it).name }.toSet()
        dir(ctx).listFiles()?.forEach { if (it.name !in keep) it.delete() }
    }
}
