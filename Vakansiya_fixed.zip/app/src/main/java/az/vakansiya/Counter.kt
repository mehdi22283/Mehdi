package az.vakansiya

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener
import java.util.Calendar

/** Saytları gizli brauzerlərdə eyni anda açıb bu gün / dünən yerləşdirilən elanları təxmini sayır. */
class Counter(
    private val ctx: Context,
    private val sites: List<Site>,
    private val onUpdate: (Int) -> Unit,
    private val onDone: () -> Unit,
    private val onPartial: ((Int) -> Unit)? = null
) {
    private val h = Handler(Looper.getMainLooper())
    /** İş siyahısı: hər sayt + (varsa) əlavə səhifələri (məs. Busy.az ?page=2). Əlavə səhifəli saytlarda nəticə birləşdirilir. */
    private val work = ArrayList<Site>()
    private val owner = ArrayList<Int>()
    private val wvs: Array<WebView?>
    private val finished: BooleanArray
    private val started: BooleanArray
    private val pageDone: LongArray
    private var left: Int
    var stopped = false

    init {
        sites.forEachIndexed { i, s ->
            val ex = Store.extraPages(s.url)
            if (ex.isEmpty()) { work.add(s); owner.add(i) }
            else {
                work.add(Site(s.name, s.url)); owner.add(i)
                ex.forEach { work.add(Site(s.name, it)); owner.add(i) }
            }
        }
        wvs = arrayOfNulls(work.size)
        finished = BooleanArray(work.size)
        started = BooleanArray(work.size)
        pageDone = LongArray(work.size)
        left = work.size
    }

    /** Əlavə səhifəli saytın hissə nəticələrini əsas sayta toplayır. */
    private fun merge(o: Int) {
        val real = sites[o]
        val parts = work.indices.filter { owner[it] == o && work[it] !== real }.map { work[it] }
        if (parts.isEmpty()) return
        val ok = parts.filter { it.today >= 0 }
        if (ok.isEmpty()) return
        real.today = ok.sumOf { it.today }
        real.yest = ok.sumOf { maxOf(it.yest, 0) }
        real.d2 = if (ok.any { it.d2 >= 0 }) ok.sumOf { maxOf(it.d2, 0) } else -1
        val seen = HashSet<String>()
        real.items = ok.flatMap { it.items }.filter { seen.add(it.key) }
            .sortedWith(compareBy({ it.day }, { if (it.kind == 0) 9 else it.kind }))
        val ls = LinkedHashSet<String>()
        ok.forEach { p -> p.links?.let { ls.addAll(it) } }
        real.links = ls.toList()
    }

    private fun partial(i: Int) {
        val o = owner[i]
        if (sites[o] !== work[i]) merge(o)
        onPartial?.invoke(o)
    }

    inner class Bridge(val i: Int) {
        @JavascriptInterface
        fun done(json: String) {
            h.post {
                if (!stopped && !finished[i]) {
                    try {
                        val o = JSONObject(json)
                        applyRes(work[i], o)
                    } catch (e: Exception) { }
                    finish(i)
                }
            }
        }
    }

    private fun applyRes(site: Site, o: JSONObject) {
        try {
            site.today = o.getInt("t")
            site.yest = o.getInt("y")
            site.items = Hit.parse(o.optJSONArray("s"))
            site.d2 = o.optInt("w", -1)
            val arr = o.getJSONArray("l")
            site.links = List(arr.length()) { arr.getString(it) }
        } catch (e: Exception) { }
    }

    /** Səhifə hazır olana qədər tez-tez yoxlayır (sabit gözləmə yoxdur): nəticə sabitləşən kimi qəbul edir. */
    private fun poll(v: WebView, i: Int, site: Site, detail: Boolean) {
        val careful = Store.careful(site.url)
        val script = if (detail) "" else Scan.js(ctx, careful)
        val glorri = site.url.contains("glorri.az")
        val jobing = site.url.contains("jobing.az")
        val slow = Store.scrolly(site.url)   // Glorri qaydası: gözlə, aşağı sürüşdür, "daha çox yüklə"
        val firstWait = Store.firstWait(site.url)
        val t0 = System.currentTimeMillis()
        val extra = (if (detail) 10000L else if (glorri) 45000L else if (Store.boss(site.url)) 60000L else if (slow) 32000L else if (jobing) 38000L else if (careful) 20000L else 10000L)
        // vaxt limiti səhifənin yüklənmə bitişindən (onPageFinished) hesablanır: erkən başlasaq da, yavaş render olunan saytlar tələsik bitirilməsin
        fun deadline() = maxOf(t0, pageDone[i]) + firstWait + extra
        var same = 0
        var last = ""
        var lastN = 0
        var stag = 0
        fun tick() {
            if (stopped || finished[i]) return
            val late = System.currentTimeMillis() >= deadline()
            if (detail) {
                v.evaluateJavascript(if (Store.telegram(site.url)) "document.querySelectorAll('.tgme_widget_message').length" else "document.querySelectorAll('a[href*=\"/vakansiya-is-elani/\"]').length") { r ->
                    if (stopped || finished[i]) return@evaluateJavascript
                    val n = r?.toIntOrNull() ?: 0
                    if (n > 0 || late) v.evaluateJavascript(Scan.detailScript(ctx, site.url), null)
                    else h.postDelayed({ tick() }, 300)
                }
            } else {
                v.evaluateJavascript(script) { r ->
                    if (stopped || finished[i]) return@evaluateJavascript
                    var o: JSONObject? = null
                    try { o = JSONObject(JSONTokener(r).nextValue() as String) } catch (e: Exception) { }
                    val size = o?.getJSONArray("l")?.length() ?: 0
                    if (slow) {
                        // Glorri: səhifə yavaş-yavaş aşağı sürüşdürülür, saylar canlı yenilənir
                        val g = o?.optInt("g", 0) ?: 0
                        if (o != null && g > 0) {
                            applyRes(site, o)
                            partial(i)
                            if (size > lastN) { lastN = size; stag = 0 } else stag++
                        } else if (System.currentTimeMillis() - t0 >= firstWait) stag++
                        if ((g == 2 && r == last) || stag >= (if (Store.boss(site.url)) 40 else 18) || late) {
                            if (o != null && site.today < 0) applyRes(site, o)
                            finish(i)
                        } else { last = r ?: ""; h.postDelayed({ tick() }, 250) }
                        return@evaluateJavascript
                    }
                    val hits = (o?.optInt("t", 0) ?: 0) + (o?.optInt("y", 0) ?: 0) + (o?.optInt("w", 0) ?: 0)
                    if (r == last) same++ else same = 0
                    // elan tapılmayıbsa (səhifə hələ boşdur) daha uzun sabitləşmə gözlənilir
                    val need = if (hits == 0) 8 else 4
                    if (o != null && ((size >= 3 && same >= need) || late)) {
                        applyRes(site, o)
                        finish(i)
                    } else if (late) finish(i)
                    else {
                        // canlı yenilənmə: yarımçıq nəticə də ekranda dərhal görünsün
                        if (o != null && size >= 1 && r != last) { applyRes(site, o); partial(i) }
                        last = r ?: ""; h.postDelayed({ tick() }, 150)
                    }
                }
            }
        }
        h.postDelayed({ tick() }, Store.startDelay(site.url))
    }

    /** Uzun çəkən (ağır) saytlar əvvəl başlayır: ümumi skan vaxtı qısalır. */
    private fun startWeight(u: String): Int = Store.weight(u)

    @android.annotation.SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    fun start() {
        if (work.isEmpty()) { onDone(); return }
        work.indices.sortedByDescending { startWeight(work[it].url) }.forEach { i ->
            val site = work[i]
            val detail = Store.detail(site.url)
            val careful = Store.careful(site.url)
            val glorri = site.url.contains("glorri.az")
            val slow = Store.scrolly(site.url)
            val jooble = site.url.contains("jooble")
            val jobing = site.url.contains("jobing.az")
            val w = WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.blockNetworkImage = true
                settings.loadsImagesAutomatically = false
                if (detail) addJavascriptInterface(Bridge(i), "Bridge")
                webChromeClient = object : android.webkit.WebChromeClient() {
                    override fun onProgressChanged(v: WebView, p: Int) {
                        if (p < 90 || stopped || finished[i] || started[i]) return
                        started[i] = true
                        poll(v, i, site, detail)
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(v: WebView, req: android.webkit.WebResourceRequest) = Block.intercept(req)
                    override fun onPageFinished(v: WebView, u: String) {
                        pageDone[i] = System.currentTimeMillis()
                        if (stopped || finished[i] || started[i]) return
                        started[i] = true
                        poll(v, i, site, detail)
                    }
                }
            }
            if (slow) {
                // ekrana bağlı olmayan WebView-a ölçü ver ki, sürüşdürmə/yükləmə işləsin
                w.measure(android.view.View.MeasureSpec.makeMeasureSpec(1080, android.view.View.MeasureSpec.EXACTLY),
                    android.view.View.MeasureSpec.makeMeasureSpec(1920, android.view.View.MeasureSpec.EXACTLY))
                w.layout(0, 0, 1080, 1920)
            }
            wvs[i] = w
            w.loadUrl(Store.scanUrl(site.url))
            // hər sayt üçün ayrıca vaxt limiti
            // nəticə gəlməyibsə bir dəfə yenidən yüklənir, sonra bitirilir
            h.postDelayed({
                if (stopped || finished[i]) return@postDelayed
                if (site.today < 0) {
                    started[i] = false
                    w.loadUrl(Store.scanUrl(site.url))
                    h.postDelayed({ if (!stopped && !finished[i]) finish(i) }, if (detail) 65000L else if (glorri) 48000L else if (Store.boss(site.url)) 35000L else if (slow) 40000L else if (jobing) 55000L else if (careful) 40000L else 28000L)
                } else finish(i)
            }, if (detail) 65000L else if (glorri) 58000L else if (Store.boss(site.url)) 75000L else if (slow) 50000L else if (jooble) 32000L else if (jobing) 50000L else if (careful) 32000L else 20000L)
        }
    }

    private fun finish(i: Int) {
        if (finished[i]) return
        finished[i] = true
        try { wvs[i]?.destroy() } catch (e: Exception) { }
        val o = owner[i]
        if (sites[o] !== work[i]) merge(o)
        if (work.indices.all { owner[it] != o || finished[it] }) onUpdate(o) else onPartial?.invoke(o)
        left--
        if (left == 0 && !stopped) onDone()
    }

    fun stop() {
        stopped = true
        h.removeCallbacksAndMessages(null)
        wvs.forEachIndexed { i, w ->
            if (w != null && !finished[i]) { finished[i] = true; try { w.destroy() } catch (e: Exception) { } }
        }
    }
}
