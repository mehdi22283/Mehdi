package com.mehdi.keymapper

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "Key Mapper TV"
            textSize = 26f
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            textSize = 18f
            setPadding(0, pad, 0, pad)
            gravity = Gravity.CENTER
        }
        root.addView(status)

        fun btn(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            isFocusable = true
            setOnClickListener { action() }
            root.addView(this)
        }

        val first = btn("Əlçatımlılıq ayarlarını aç") {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) {}
        }
        btn("Batareya ayarlarını aç") {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) {}
        }
        btn("Arxa plan servisini başlat") { startKeepAlive(); refresh() }

        setContentView(ScrollView(this).apply { addView(root) })
        first.requestFocus()

        if (Build.VERSION.SDK_INT >= 33) {
            try { requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1) } catch (_: Exception) {}
        }
        startKeepAlive()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun startKeepAlive() {
        try {
            val s = Intent(this, KeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s) else startService(s)
        } catch (_: Exception) {}
    }

    private fun refresh() {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        status.text = if (enabled) "Əlçatımlılıq servisi: AKTİV ✔"
        else "Əlçatımlılıq servisi: SÖNÜLÜ ✘\nAyarlar > Əlçatımlılıq > Endirilmiş tətbiqlər > Key Mapper TV"
    }
}
