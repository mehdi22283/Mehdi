package az.yvok.yoxla;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final String URL = "https://e-belediyye.gov.az/tax-debts";
    private static final int LEN = 12;

    private WebView webView;
    private EditText etCode;
    private boolean pageLoaded = false;
    private String pendingCode = null;
    private String lastSent = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etCode = findViewById(R.id.etCode);
        Button btnGo = findViewById(R.id.btnGo);
        webView = findViewById(R.id.webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                if (pendingCode != null) {
                    String c = pendingCode;
                    pendingCode = null;
                    inject(c);
                }
            }
        });
        webView.loadUrl(URL);

        // 12 simvol yazılan kimi avtomatik göndər
        etCode.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence a, int b, int c, int d) {}
            public void onTextChanged(CharSequence a, int b, int c, int d) {}
            public void afterTextChanged(Editable e) {
                String t = e.toString().trim();
                if (t.length() == LEN && !t.equals(lastSent)) {
                    submit(t);
                } else if (t.length() < LEN) {
                    lastSent = "";
                }
            }
        });

        btnGo.setOnClickListener(v -> {
            String t = etCode.getText().toString().trim();
            if (t.length() != LEN) {
                Toast.makeText(this, "Tam " + LEN + " simvol daxil edin", Toast.LENGTH_SHORT).show();
                return;
            }
            submit(t);
        });
    }

    private void submit(String code) {
        lastSent = code;
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(etCode.getWindowToken(), 0);
        if (pageLoaded) {
            inject(code);
        } else {
            pendingCode = code;
        }
    }

    /** Saytdakı YVÖK xanasını doldurur və "Yoxla" düyməsini basır. */
    private void inject(String code) {
        String js =
            "(function(){" +
            "var v=" + JSONObject.quote(code) + ";" +
            "var tries=0;" +
            "function findInput(){" +
            "  var list=document.querySelectorAll('input');" +
            "  for(var i=0;i<list.length;i++){var t=(list[i].type||'text').toLowerCase();" +
            "    if(['text','search','tel','number',''].indexOf(t)>=0 && !list[i].disabled && list[i].offsetParent!==null) return list[i];}" +
            "  return null;}" +
            "function findBtn(){" +
            "  var list=document.querySelectorAll('button,input[type=submit],input[type=button],a');" +
            "  for(var i=0;i<list.length;i++){var tx=(list[i].innerText||list[i].value||list[i].textContent||'').trim();" +
            "    if(/^yoxla$/i.test(tx) && list[i].offsetParent!==null) return list[i];}" +
            "  return null;}" +
            "function go(){" +
            "  tries++;" +
            "  var inp=findInput(), btn=findBtn();" +
            "  if(inp && btn){" +
            "    inp.focus();" +
            "    var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;" +
            "    setter.call(inp,v);" +
            "    inp.dispatchEvent(new Event('input',{bubbles:true}));" +
            "    inp.dispatchEvent(new Event('change',{bubbles:true}));" +
            "    setTimeout(function(){btn.click();},300);" +
            "  } else if(tries<40){ setTimeout(go,500); }" +
            "}" +
            "go();" +
            "})();";
        webView.evaluateJavascript(js, null);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
