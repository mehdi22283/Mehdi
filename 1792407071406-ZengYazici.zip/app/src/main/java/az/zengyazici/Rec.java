package az.zengyazici;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Build;
import java.io.File;

public class Rec {
    private static MediaRecorder mr;
    private static File file;
    public static String app = "";
    private static boolean spkChanged = false, volChanged = false, oldSpk = false;
    private static int oldVol = 0;

    public static synchronized boolean active() { return mr != null; }

    /** a = "tel" | "wa", dir = "in" | "out" */
    public static synchronized void start(Context c, String a, String dir, String number) {
        if (mr != null) return;
        Context ctx = c.getApplicationContext();
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        try {
            Intent si = new Intent(ctx, KeepAliveService.class);
            si.putExtra("label", ("wa".equals(a) ? "WhatsApp" : "Telefon") + " · " + ("in".equals(dir) ? "gələn zəng" : "gedən zəng"));
            ctx.startForegroundService(si);
        } catch (Exception e) { }
        File d = ctx.getExternalFilesDir("calls");
        if (d == null) return;
        d.mkdirs();
        long ts = System.currentTimeMillis();
        int pref = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("src", 0);
        int[] auto = Build.VERSION.SDK_INT < 29
                ? new int[]{MediaRecorder.AudioSource.VOICE_CALL, MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC}
                : new int[]{MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC};
        int[] src = auto;
        if (pref != 0) {
            src = new int[auto.length + 1];
            src[0] = pref;
            System.arraycopy(auto, 0, src, 1, auto.length);
        }
        for (int s : src) {
            MediaRecorder m = null;
            File f = new File(d, ts + "__" + a + "__" + dir + "__" + clean(number) + "__" + s + ".m4a");
            try {
                m = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(ctx) : new MediaRecorder();
                m.setAudioSource(s);
                m.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                m.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                m.setAudioEncodingBitRate(96000);
                m.setAudioSamplingRate(44100);
                m.setOutputFile(f.getAbsolutePath());
                m.prepare();
                m.start();
                mr = m; file = f; app = a;
                applyAudio(ctx);
                return;
            } catch (Exception e) {
                if (m != null) { try { m.release(); } catch (Exception x) { } }
                f.delete();
            }
        }
        try { ctx.stopService(new Intent(ctx, KeepAliveService.class)); } catch (Exception e) { }
    }

    /** Returns the recorded file (or null). */
    public static synchronized File stop(Context c) {
        if (mr == null) return null;
        try { mr.stop(); } catch (Exception e) { }
        try { mr.release(); } catch (Exception e) { }
        mr = null;
        File f = file;
        file = null; app = "";
        restoreAudio(c.getApplicationContext());
        try { c.getApplicationContext().stopService(new Intent(c, KeepAliveService.class)); } catch (Exception e) { }
        if (f != null && f.length() < 3000) { f.delete(); return null; }
        return f;
    }

    private static void applyAudio(Context ctx) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE);
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (sp.getBoolean("spk", false)) {
                oldSpk = am.isSpeakerphoneOn();
                am.setSpeakerphoneOn(true);
                spkChanged = true;
            }
            if (sp.getBoolean("vol", false)) {
                oldVol = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL);
                am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0);
                volChanged = true;
            }
        } catch (Exception e) { }
    }

    private static void restoreAudio(Context ctx) {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (spkChanged) am.setSpeakerphoneOn(oldSpk);
            if (volChanged) am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, oldVol, 0);
        } catch (Exception e) { }
        spkChanged = false; volChanged = false;
    }

    /** Faylın nömrə hissəsini dəyişir. */
    public static File rename(File f, String num) {
        String[] p = f.getName().replace(".m4a", "").split("__", -1);
        if (p.length < 4) return f;
        p[3] = clean(num);
        File nf = new File(f.getParentFile(), String.join("__", p) + ".m4a");
        return f.renameTo(nf) ? nf : f;
    }

    public static String clean(String n) {
        String s = n == null ? "" : n.replaceAll("[^\\p{L}\\p{N}+ .()-]", "").trim();
        return s.isEmpty() ? "-" : s;
    }
}
