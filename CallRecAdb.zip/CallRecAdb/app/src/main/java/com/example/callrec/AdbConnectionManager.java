package com.example.callrec;

import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import java.io.*;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import java.util.Random;
import sun.security.x509.*;

/** Açarlar fayla yazılır, beləcə cütləşdirmə bir dəfə kifayətdir. */
public class AdbConnectionManager extends AbsAdbConnectionManager {
    private static AdbConnectionManager INSTANCE;
    private PrivateKey mPrivateKey;
    private Certificate mCertificate;

    public static synchronized AdbConnectionManager getInstance(Context c) throws Exception {
        if (INSTANCE == null) INSTANCE = new AdbConnectionManager(c.getApplicationContext());
        return INSTANCE;
    }

    private AdbConnectionManager(Context c) throws Exception {
        setApi(Build.VERSION.SDK_INT);
        File kf = new File(c.getFilesDir(), "adb_key.pk8");
        File cf = new File(c.getFilesDir(), "adb_cert.der");
        if (kf.exists() && cf.exists()) {
            mPrivateKey = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(read(kf)));
            mCertificate = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(read(cf)));
            return;
        }
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048, SecureRandom.getInstance("SHA1PRNG"));
        KeyPair kp = g.generateKeyPair();
        PublicKey publicKey = kp.getPublic();
        mPrivateKey = kp.getPrivate();
        String algorithmName = "SHA512withRSA";
        Date notBefore = new Date();
        Date notAfter = new Date(System.currentTimeMillis() + 3650L * 86400000L);
        CertificateExtensions ext = new CertificateExtensions();
        ext.set("SubjectKeyIdentifier", new SubjectKeyIdentifierExtension(new KeyIdentifier(publicKey).getIdentifier()));
        X500Name name = new X500Name("CN=CallRec");
        ext.set("PrivateKeyUsage", new PrivateKeyUsageExtension(notBefore, notAfter));
        X509CertInfo info = new X509CertInfo();
        info.set("version", new CertificateVersion(2));
        info.set("serialNumber", new CertificateSerialNumber(new Random().nextInt() & Integer.MAX_VALUE));
        info.set("algorithmID", new CertificateAlgorithmId(AlgorithmId.get(algorithmName)));
        info.set("subject", new CertificateSubjectName(name));
        info.set("key", new CertificateX509Key(publicKey));
        info.set("validity", new CertificateValidity(notBefore, notAfter));
        info.set("issuer", new CertificateIssuerName(name));
        info.set("extensions", ext);
        X509CertImpl cert = new X509CertImpl(info);
        cert.sign(mPrivateKey, algorithmName);
        mCertificate = cert;
        write(kf, mPrivateKey.getEncoded());
        write(cf, cert.getEncoded());
    }

    private static byte[] read(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[4096]; int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return o.toByteArray();
        }
    }
    private static void write(File f, byte[] d) throws IOException {
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(d); }
    }

    @NonNull @Override protected PrivateKey getPrivateKey() { return mPrivateKey; }
    @NonNull @Override protected Certificate getCertificate() { return mCertificate; }
    @NonNull @Override protected String getDeviceName() { return "CallRec"; }
}
