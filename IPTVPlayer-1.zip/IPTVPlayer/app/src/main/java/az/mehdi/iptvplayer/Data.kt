package az.mehdi.iptvplayer

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Channel(val number: Int, val name: String, val url: String, val group: String, val logo: String?)

const val PLAYLIST_URL = "https://ottplayer.tv/playlist/download/215091118"
private const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) OTTPlayer/1.0"

fun fetchToFile(src: String, dest: File, timeout: Int = 15000) {
    val c = URL(src).openConnection() as HttpURLConnection
    c.connectTimeout = timeout
    c.readTimeout = timeout * 2
    c.instanceFollowRedirects = true
    c.setRequestProperty("User-Agent", UA)
    try {
        if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
        val tmp = File(dest.path + ".tmp")
        c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        if (dest.exists()) dest.delete()
        if (!tmp.renameTo(dest)) throw IOException("rename failed")
    } finally {
        c.disconnect()
    }
}

/** Hər açılışda çağırılır: playlisti yenidən endirir, uğurlu olarsa keşi yeniləyir. */
fun downloadPlaylist(cache: File): String {
    val fresh = File(cache.path + ".new")
    fetchToFile(PLAYLIST_URL, fresh, 20000)
    val text = fresh.readText()
    if (!text.contains("#EXTINF")) { fresh.delete(); throw IOException("Playlist boşdur") }
    if (cache.exists()) cache.delete()
    fresh.renameTo(cache)
    return text
}

fun parsePlaylist(text: String): List<Channel> {
    val res = ArrayList<Channel>()
    val attr = Regex("([\\w-]+)=\"([^\"]*)\"")
    var name: String? = null
    var group = "Digər"
    var logo: String? = null
    for (raw in text.lineSequence()) {
        val line = raw.trim()
        if (line.isEmpty()) continue
        if (line.startsWith("#EXTINF")) {
            val comma = line.lastIndexOf(',')
            name = if (comma >= 0) line.substring(comma + 1).trim() else ""
            val head = if (comma >= 0) line.substring(0, comma) else line
            val a = attr.findAll(head).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
            group = a["group-title"]?.takeIf { it.isNotBlank() } ?: "Digər"
            logo = a["tvg-logo"]?.takeIf { it.startsWith("http") }
        } else if (line.startsWith("#EXTGRP:")) {
            group = line.substringAfter(':').trim().ifEmpty { "Digər" }
        } else if (!line.startsWith("#")) {
            if (name != null) {
                res.add(Channel(res.size + 1, name.ifBlank { line }, line, group, logo))
            }
            name = null; group = "Digər"; logo = null
        }
    }
    return res
}

/** Gizli brauzerin (WebView) endirmə linkini onun cookie-ləri ilə endirir. */
fun downloadWithCookies(url: String, ua: String?, cookie: String?): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 20000
    c.readTimeout = 40000
    c.instanceFollowRedirects = true
    c.setRequestProperty("User-Agent", ua ?: UA)
    if (!cookie.isNullOrEmpty()) c.setRequestProperty("Cookie", cookie)
    try {
        if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
        val t = c.inputStream.bufferedReader().use { it.readText() }
        if (!t.contains("#EXTINF")) throw IOException("Playlist boşdur")
        return t
    } finally {
        c.disconnect()
    }
}
