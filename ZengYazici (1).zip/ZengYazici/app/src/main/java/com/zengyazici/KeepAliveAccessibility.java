package com.zengyazici;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

/**
 * Əlçatımlılıq xidməti: aktiv edildikdə sistem tətbiqi bağlamağa daha az meyl edir,
 * və xidmət dayanıbsa, onu yenidən işə salır. Ekran məzmunu oxunmur.
 */
public class KeepAliveAccessibility extends AccessibilityService {
    private long last;

    private void ensureRunning() { RecService.ensure(this); }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        RecService.log("Əlçatımlılıq xidməti aktivdir");
        getSharedPreferences("cfg", 0).edit().putBoolean("autostart", true).apply();
        ensureRunning();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        long now = System.currentTimeMillis();
        if (now - last < 5000) return;
        last = now;
        ensureRunning();
    }

    @Override public void onInterrupt() { }
}
