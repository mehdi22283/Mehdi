package az.zeng.yazici;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.util.Log;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Shell icazələri ilə ayrıca prosesdə (Daemon) işləyən yazıcı.
 * Wi-Fi getsə və ya tətbiq bağlansa da yazı davam edir.
 */
public class Recorder {
    private static final String TAG = "ZengRec";
    private static final int SRC_MIC = 1, SRC_VOICE_CALL = 4, SRC_REMOTE_SUBMIX = 8;
    private static final long MAX_MS = 3L * 3600 * 1000;

    private final StringBuilder logBuf = new StringBuilder();
    private Thread th;
    private volatile boolean run;
    private AudioRecord cA, cB;
    private long t0;

    public Recorder() {
        log("xidmət başladı (uid=" + android.os.Process.myUid() + ", sdk=" + android.os.Build.VERSION.SDK_INT + ")");
    }

    public synchronized boolean start(String path, int mode) {
        stopInternal();
        try {
            File f = new File(path);
            File par = f.getParentFile();
            if (par != null) par.mkdirs();

            int[] modes = mode == 0 ? new int[]{0, 1} : new int[]{1};
            int[] rates = {48000, 44100, 16000, 8000};
            AudioRecord a = null, b = null;
            int rate = 0;
            for (int m : modes) {
                for (int r : rates) {
                    a = make(m == 0 ? SRC_VOICE_CALL : SRC_MIC, r);
                    if (a == null) continue;
                    if (m == 1) {
                        b = make(SRC_REMOTE_SUBMIX, r);
                        if (b == null) {
                            a.release();
                            a = null;
                            continue;
                        }
                    }
                    rate = r;
                    log("rejim=" + (m == 0 ? "VOICE_CALL" : "MIC+SUBMIX") + " rate=" + r);
                    break;
                }
                if (a != null) break;
                log("rejim " + (m == 0 ? "VOICE_CALL" : "MIC+SUBMIX") + " alınmadı");
            }
            if (a == null) {
                log("AudioRecord yaradıla bilmədi. FakeContext: " + FakeContext.lastError);
                return false;
            }
            a.startRecording();
            if (b != null) b.startRecording();
            if (a.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                log("startRecording alınmadı");
                a.release();
                if (b != null) b.release();
                return false;
            }
            cA = a;
            cB = b;
            run = true;
            t0 = System.currentTimeMillis();
            final AudioRecord fa = a, fb = b;
            final int fr = rate;
            th = new Thread(() -> loop(fa, fb, fr, f), "zeng-rec");
            th.start();
            return true;
        } catch (Throwable t) {
            log("start xətası: " + t);
            return false;
        }
    }

    public synchronized long stop() {
        long ms = t0 == 0 ? 0 : System.currentTimeMillis() - t0;
        stopInternal();
        return ms;
    }

    public boolean isRecording() {
        return run;
    }

    public String getLog() {
        synchronized (logBuf) {
            return logBuf.toString();
        }
    }

    synchronized void stopInternal() {
        run = false;
        Thread t = th;
        if (t != null) {
            try {
                t.join(2000);
            } catch (InterruptedException ignored) {
            }
            if (t.isAlive()) {
                try {
                    if (cA != null) cA.stop();
                    if (cB != null) cB.stop();
                } catch (Throwable ignored) {
                }
                try {
                    t.join(2000);
                } catch (InterruptedException ignored) {
                }
            }
        }
        th = null;
        t0 = 0;
    }

    private AudioRecord make(int src, int rate) {
        try {
            int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) min = rate;
            int buf = Math.max(min * 2, rate / 5 * 2);
            AudioFormat fmt = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build();
            AudioRecord.Builder bd = new AudioRecord.Builder()
                    .setAudioSource(src)
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(buf);
            Context fc = FakeContext.get();
            if (fc != null) {
                try {
                    AudioRecord.Builder.class.getMethod("setContext", Context.class).invoke(bd, fc);
                } catch (Throwable t) {
                    log("setContext: " + t);
                }
            }
            AudioRecord ar = bd.build();
            if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
                ar.release();
                return null;
            }
            return ar;
        } catch (Throwable t) {
            log("make(src=" + src + ", rate=" + rate + "): " + t);
            return null;
        }
    }

    private void loop(AudioRecord a, AudioRecord b, int rate, File f) {
        RandomAccessFile raf = null;
        long data = 0;
        final int dec = rate == 48000 ? 3 : 1;
        final int outRate = rate / dec;
        try {
            short[] ba = new short[rate / 50];
            short[] bb = b != null ? new short[rate / 50] : null;
            ByteBuffer bytes = ByteBuffer.allocate((ba.length / dec + 1) * 2).order(ByteOrder.LITTLE_ENDIAN);
            raf = new RandomAccessFile(f, "rw");
            raf.setLength(0);
            raf.write(new byte[44]);
            long end = System.currentTimeMillis() + MAX_MS;
            while (run && System.currentTimeMillis() < end) {
                int n = a.read(ba, 0, ba.length);
                if (n < 0) {
                    log("read xətası: " + n);
                    break;
                }
                if (n == 0) continue;
                if (b != null) {
                    int m = b.read(bb, 0, n);
                    for (int i = 0; i < n; i++) {
                        int s = ba[i] + (i < m ? bb[i] : 0);
                        if (s > 32767) s = 32767;
                        if (s < -32768) s = -32768;
                        ba[i] = (short) s;
                    }
                }
                bytes.clear();
                for (int i = 0; i + dec <= n; i += dec) {
                    int s = 0;
                    for (int k = 0; k < dec; k++) s += ba[i + k];
                    bytes.putShort((short) (s / dec));
                }
                raf.write(bytes.array(), 0, bytes.position());
                data += bytes.position();
            }
        } catch (Throwable t) {
            log("loop xətası: " + t);
        } finally {
            try {
                if (raf != null) {
                    writeHeader(raf, data, outRate);
                    raf.close();
                }
            } catch (Throwable t) {
                log("header: " + t);
            }
            try {
                a.stop();
                a.release();
            } catch (Throwable ignored) {
            }
            try {
                if (b != null) {
                    b.stop();
                    b.release();
                }
            } catch (Throwable ignored) {
            }
            run = false;
            log("yazı bitdi, " + data + " bayt, " + outRate + " Hz");
        }
    }

    private static void writeHeader(RandomAccessFile r, long data, int rate) throws Exception {
        ByteBuffer h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        h.put("RIFF".getBytes());
        h.putInt((int) (36 + data));
        h.put("WAVE".getBytes());
        h.put("fmt ".getBytes());
        h.putInt(16);
        h.putShort((short) 1);
        h.putShort((short) 1);
        h.putInt(rate);
        h.putInt(rate * 2);
        h.putShort((short) 2);
        h.putShort((short) 16);
        h.put("data".getBytes());
        h.putInt((int) data);
        r.seek(0);
        r.write(h.array());
    }

    private void log(String s) {
        Log.i(TAG, s);
        synchronized (logBuf) {
            logBuf.append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date())).append(' ').append(s).append('\n');
            if (logBuf.length() > 6000) logBuf.delete(0, logBuf.length() - 6000);
        }
    }
}
