package az.zengyazici

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** WhatsApp zəng ekranının açıldığını bilmək üçün. Ekran məzmunu oxunmur. */
class WhatsAppWatcherService : AccessibilityService() {
    private var inVoip = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Sistem bu xidməti açılışda özü bağlayır → proses canlı qalır, xidməti avtomatik bərpa edirik.
        AdbAuto.bootstrap(applicationContext)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (!pkg.startsWith("com.whatsapp")) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            inVoip = e.className?.toString()?.contains("voip", ignoreCase = true) == true
        }
        if (inVoip) RecorderService.lastVoipSeen = System.currentTimeMillis()
    }

    override fun onInterrupt() {}
}
