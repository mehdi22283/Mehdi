package az.yvok.app;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/**
 * Google Cloud Vision (DOCUMENT_TEXT_DETECTION) ilə onlayn OCR (tətbiqdə yeganə OCR mühərriki).
 */
final class CloudVision {
    // Açar index.html-də "Toplu yoxlama" yanındakı xanadan daxil edilir, SharedPreferences-də saxlanır.
    static volatile String apiKey = "";

    // Google sorğu həddi ~10 MB JSON-dur; base64 4/3 dəfə böyütdüyü üçün bu rəqəm təhlükəsiz yuxarı sərhəddir
    private static final int MAX_B64 = 9_000_000;


    private CloudVision() { }

    static volatile String lastError = null;

    static final int FREE_LIMIT = 33;   // sayğacın aylıq limiti (istifadəçi tələbi ilə 33)

    // Google hesablaşma ayı Pacific vaxtı ilə sıfırlanır; sayğac telefonda saxlanılır (təxmini)
    private static String monthKey() {
        java.util.Calendar cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("America/Los_Angeles"));
        return cal.get(java.util.Calendar.YEAR) + "-" + (cal.get(java.util.Calendar.MONTH) + 1);
    }

    static synchronized int left(Context c) {
        android.content.SharedPreferences sp = c.getSharedPreferences("yvok", Context.MODE_PRIVATE);
        int used = monthKey().equals(sp.getString("vision_month", "")) ? sp.getInt("vision_used", 0) : 0;
        return Math.max(0, FREE_LIMIT - used);
    }

    private static synchronized void bump(Context c) {
        android.content.SharedPreferences sp = c.getSharedPreferences("yvok", Context.MODE_PRIVATE);
        String mk = monthKey();
        int used = mk.equals(sp.getString("vision_month", "")) ? sp.getInt("vision_used", 0) : 0;
        sp.edit().putString("vision_month", mk).putInt("vision_used", used + 1).apply();
    }

    static boolean enabled() { return !apiKey.isEmpty(); }

    /** Şəkildəki bütün mətni qaytarır; xəta və ya internet yoxdursa null. Yalnız arxa thread-də çağırılır. */
    static String detect(Context c, Uri uri) {
        lastError = null;
        if (!enabled()) { lastError = "Vision API açarı yoxdur"; return null; }
        try {
            String img64 = prepare(c, uri);

            JSONObject req = new JSONObject()
                    .put("image", new JSONObject().put("content", img64))
                    .put("features", new JSONArray().put(new JSONObject().put("type", "DOCUMENT_TEXT_DETECTION")))
                    .put("imageContext", new JSONObject().put("languageHints", new JSONArray().put("en").put("az")));
            byte[] body = new JSONObject().put("requests", new JSONArray().put(req)).toString().getBytes("UTF-8");

            HttpURLConnection h = (HttpURLConnection) new URL("https://vision.googleapis.com/v1/images:annotate?key=" + apiKey).openConnection();
            h.setRequestMethod("POST");
            h.setConnectTimeout(8000);
            h.setReadTimeout(45000);
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            h.setRequestProperty("X-Android-Package", c.getPackageName());
            String sha = certSha1(c);
            if (sha != null) h.setRequestProperty("X-Android-Cert", sha);
            try (OutputStream os = h.getOutputStream()) { os.write(body); }
            int code = h.getResponseCode();
            if (code != 200) {
                lastError = (code == 400 || code == 403) ? "Vision açarı qəbul olunmadı (" + code + "): açarı və API-nin aktiv olduğunu yoxlayın"
                        : "Vision xətası (" + code + ")";
                return null;
            }
            bump(c);   // uğurlu sorğu = 1 vahid
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = h.getInputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            JSONObject r = new JSONObject(out.toString("UTF-8")).getJSONArray("responses").getJSONObject(0);
            JSONObject full = r.optJSONObject("fullTextAnnotation");
            if (full == null) return null;
            String ordered = orderedText(full);          // sözlər şəkildəki mövqeyə görə yuxarıdan aşağı düzülür
            return ordered != null ? ordered : full.optString("text", null);
        } catch (java.io.IOException t) {
            lastError = "İnternet yoxdur və ya Google-a qoşulmaq olmadı";
            return null;
        } catch (Throwable t) {
            lastError = "Vision cavabı oxunmadı";
            return null;
        }
    }


    /**
     * Vision-un öz "text"i bloklara görə gəlir və şəkildəki sıra ilə üst-üstə düşməyə bilər.
     * Burada bütün sözlər mövqeyinə görə (əyilmiş şəkildə mətnin öz istiqamətinə görə) yuxarıdan aşağı,
     * eyni cərgədə soldan sağa düzülüb sətirlərə yığılır.
     */
    private static String orderedText(JSONObject full) {
        try {
            JSONArray pages = full.optJSONArray("pages");
            if (pages == null) return null;
            java.util.ArrayList<double[]> ws = new java.util.ArrayList<>();   // cx, cy, h, pageIdx
            java.util.ArrayList<String> txt = new java.util.ArrayList<>();
            java.util.ArrayList<Double> angs = new java.util.ArrayList<>();
            for (int pi = 0; pi < pages.length(); pi++) {
                JSONArray blocks = pages.getJSONObject(pi).optJSONArray("blocks");
                if (blocks == null) continue;
                for (int b = 0; b < blocks.length(); b++) {
                    JSONArray paras = blocks.getJSONObject(b).optJSONArray("paragraphs");
                    if (paras == null) continue;
                    for (int p = 0; p < paras.length(); p++) {
                        JSONArray words = paras.getJSONObject(p).optJSONArray("words");
                        if (words == null) continue;
                        for (int w = 0; w < words.length(); w++) {
                            JSONObject wo = words.getJSONObject(w);
                            JSONObject bb = wo.optJSONObject("boundingBox");
                            JSONArray v = bb == null ? null : bb.optJSONArray("vertices");
                            JSONArray sy = wo.optJSONArray("symbols");
                            if (v == null || v.length() < 4 || sy == null) continue;
                            StringBuilder sb = new StringBuilder();
                            for (int k = 0; k < sy.length(); k++) sb.append(sy.getJSONObject(k).optString("text", ""));
                            if (sb.length() == 0) continue;
                            double[] x = new double[4], y = new double[4];
                            for (int k = 0; k < 4; k++) {
                                x[k] = v.getJSONObject(k).optDouble("x", 0);
                                y[k] = v.getJSONObject(k).optDouble("y", 0);
                            }
                            double h = Math.max(1, Math.hypot(x[3] - x[0], y[3] - y[0]));
                            ws.add(new double[]{(x[0] + x[1] + x[2] + x[3]) / 4, (y[0] + y[1] + y[2] + y[3]) / 4, h, pi});
                            txt.add(sb.toString());
                            angs.add(Math.atan2(y[1] - y[0], x[1] - x[0]));
                        }
                    }
                }
            }
            int n = ws.size();
            if (n == 0) return null;
            java.util.Collections.sort(angs);
            double th = angs.get(n / 2);                  // median mətn bucağı
            final double cs = Math.cos(th), sn = Math.sin(th);
            final double[] ax = new double[n], ay = new double[n];
            Integer[] idx = new Integer[n];
            for (int i = 0; i < n; i++) {
                double cx = ws.get(i)[0], cy = ws.get(i)[1];
                ax[i] = cx * cs + cy * sn;               // mətn boyunca
                ay[i] = -cx * sn + cy * cs;              // mətnin "aşağı" istiqaməti
                idx[i] = i;
            }
            final java.util.ArrayList<double[]> wsf = ws;
            java.util.Arrays.sort(idx, (a, b) -> {
                int pa = (int) wsf.get(a)[3], pb = (int) wsf.get(b)[3];
                return pa != pb ? Integer.compare(pa, pb) : Double.compare(ay[a], ay[b]);
            });
            StringBuilder out = new StringBuilder();
            int i = 0;
            while (i < n) {
                java.util.ArrayList<Integer> row = new java.util.ArrayList<>();
                int first = idx[i];
                double rowY = ay[first], rowH = ws.get(first)[2];
                int page = (int) ws.get(first)[3];
                row.add(first);
                int j = i + 1;
                while (j < n) {
                    int c = idx[j];
                    if ((int) ws.get(c)[3] != page || Math.abs(ay[c] - rowY) >= 0.5 * Math.max(rowH, ws.get(c)[2])) break;
                    row.add(c);
                    rowY = (rowY * (row.size() - 1) + ay[c]) / row.size();
                    j++;
                }
                java.util.Collections.sort(row, (a, b) -> Double.compare(ax[a], ax[b]));
                for (int k = 0; k < row.size(); k++) {
                    if (k > 0) out.append(' ');
                    out.append(txt.get(row.get(k)));
                }
                out.append('\n');
                i = j;
            }
            return out.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * Şəkil ağ-qara filterdən keçirilir və tam ölçüdə JPEG 100 ilə göndərilir; yalnız limiti aşarsa
     * keyfiyyət/ölçü lazım qədər azaldılır.
     */
    private static String prepare(Context c, Uri uri) throws IOException {
        Bitmap bmp = OcrImage.loadEnhanced(c, uri);   // ağ-qara + Clarity/Contrast/Sharpness 100
        int q = 100;
        try {
            while (true) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, q, bos);
                if ((long) bos.size() * 4 / 3 + 1000 <= MAX_B64 || Math.max(bmp.getWidth(), bmp.getHeight()) < 800) {
                    return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
                }
                if (q > 85) {
                    q -= 5;
                } else {
                    Bitmap t = Bitmap.createScaledBitmap(bmp, Math.round(bmp.getWidth() * 0.85f), Math.round(bmp.getHeight() * 0.85f), true);
                    if (t != bmp) bmp.recycle();
                    bmp = t;
                    q = 95;
                }
            }
        } finally {
            bmp.recycle();
        }
    }

    @SuppressWarnings("deprecation")
    private static String certSha1(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNATURES);
            byte[] d = MessageDigest.getInstance("SHA-1").digest(pi.signatures[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02X", x));
            return sb.toString();
        } catch (Throwable t) {
            return null;
        }
    }
}
