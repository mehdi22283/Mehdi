package az.zengyazici

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** WhatsApp gələn zəng bildirişini (fullScreenIntent) görüb istiqaməti müəyyən edir. */
class WaListener : NotificationListenerService() {
    companion object { @Volatile var incomingAt = 0L }
    override fun onNotificationPosted(s: StatusBarNotification) {
        if (s.packageName.startsWith("com.whatsapp") &&
            s.notification.category == Notification.CATEGORY_CALL &&
            s.notification.fullScreenIntent != null) incomingAt = System.currentTimeMillis()
    }
}
