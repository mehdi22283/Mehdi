package com.example.m3utester

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.util.concurrent.TimeUnit

class BrowserActivity : AppCompatActivity() {
    private lateinit var wv: WebView

    inner class Bridge {
        @JavascriptInterface
        fun onText(t: String) { runOnUiThread { handle(t) } }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        wv = WebView(this)
        setContentView(wv)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url.toString()
                val path = u.substringBefore('?')
                if (path.endsWith(".m3u") || path.endsWith(".m3u8")) { download(u, v.settings.userAgentString); return true }
                return false
            }
        }
        wv.setDownloadListener { url, ua, _, _, _ ->
            if (url.startsWith("blob:"))
                wv.evaluateJavascript("fetch('$url').then(r=>r.text()).then(t=>Android.onText(t))", null)
            else download(url, ua)
        }
        wv.loadUrl("https://ottplayer.tv/playlist/original")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (wv.canGoBack()) wv.goBack() else finish() }
        })
    }

    private fun download(url: String, ua: String) = lifecycleScope.launch {
        val text = withContext(Dispatchers.IO) {
            try {
                val rb = Request.Builder().url(url).header("User-Agent", ua)
                CookieManager.getInstance().getCookie(url)?.let { rb.header("Cookie", it) }
                http.newBuilder().readTimeout(60, TimeUnit.SECONDS).build()
                    .newCall(rb.build()).execute().use { it.body?.string() }
            } catch (e: Exception) { null }
        }
        if (text == null) Toast.makeText(this@BrowserActivity, "Yükləmə alınmadı", Toast.LENGTH_SHORT).show()
        else handle(text)
    }

    private fun handle(text: String) {
        val prev = Store.load(this).associate { it.url to it.ok }
        val l = parseM3u(text).onEach { it.ok = prev[it.url] }
        if (l.isEmpty()) { Toast.makeText(this, "M3U tapılmadı", Toast.LENGTH_SHORT).show(); return }
        Store.save(this, l)
        Toast.makeText(this, "${l.size} kanal yükləndi, test başlayır", Toast.LENGTH_SHORT).show()
        setResult(RESULT_OK)
        finish()
    }

    override fun onDestroy() { wv.destroy(); super.onDestroy() }
}
