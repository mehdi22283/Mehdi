# IPTV Player – oynatma optimizasiyası

- VLC şəbəkə/live cache-i 2.2 saniyəyə təyin edildi: başlanğıc gecikməsi ilə qısa şəbəkə kəsilmələri arasında balans.
- ExoPlayer bufer hədləri yeniləndi: 5 saniyə minimum, 45 saniyə maksimum, ilk oynatma üçün 1 saniyə və yenidən oynatma üçün 2.5 saniyə; daha tez start üçün.
- Uzun müddət davam edən buffering zamanı 10 saniyədən sonra digər pleyerlə ehtiyat cəhd edilir.
- Həm ehtiyat pleyer də axını aça bilmirsə, sonsuz yüklənmə əvəzinə istifadəçiyə mesaj göstərilir.
- Kanal dəyişmə nəsli ilə (generation) köhnə player hadisələri filtrlənir; gecikmiş xətalar yeni kanalı dəyişmir.
- VLC media hazırlanarkən kanalın dəyişib-dəyişmədiyi yenidən yoxlanır; köhnəlmiş media açılmır.
- VLC-də kanal dəyişərkən ayrıca `stop()` çağırışı çıxarıldı; ilişmiş native `stop()` əmri digər kanal əmrlərini eyni növbədə bloklaya bilər.
- HTTP reconnect və gecikmiş kadrların atlanması aktivləşdirildi. ExoPlayer bağlantı vaxtı 5 saniyə, oxuma vaxtı 8 saniyə olaraq qısaldıldı.

Qeyd: Bu mühitdə Android SDK və Gradle quraşdırılmadığı üçün APK yığılması mümkün olmadı. Mənbə kodu statik yoxlanılıb; real cihazda canlı IPTV axınları ilə sınaq ayrıca aparılmalıdır.
