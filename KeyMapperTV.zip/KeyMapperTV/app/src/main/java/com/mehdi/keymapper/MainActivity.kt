package com.mehdi.keymapper

import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val ui = Handler(Looper.getMainLooper())

    private val poll = object : Runnable {
        override fun run() {
            Adb.ping()
            refresh()
            ui.postDelayed(this, 5000)
        }
    }
    private val adbListener: () -> Unit = { ui.post { refresh() } }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { f() }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        setPadding(0, dp(14), 0, dp(2))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        root.addView(TextView(this).apply { text = "Key Mapper TV"; textSize = 26f })

        status = TextView(this).apply { textSize = 16f; setPadding(0, dp(12), 0, dp(12)) }
        root.addView(status)

        root.addView(row(
            btn("ADB ilə qoşul") { Adb.connect(force = true) },
            btn("ADB ünvanı") { showHostDialog() }
        ))
        root.addView(row(
            btn("Servisi ADB ilə aktiv et") { Adb.enableAccessibilityAsync() },
            btn("Əlçatımlılıq ayarları") {
                try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) {}
            }
        ))

        root.addView(label("Düymə əvəzləmələri"))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(row(
            btn("+ Yeni düymə") { showEditor(null) },
            btn("Standarta qaytar") {
                AlertDialog.Builder(this)
                    .setMessage("Bütün düymə ayarları standart vəziyyətə qayıtsın?")
                    .setPositiveButton("Bəli", DialogInterface.OnClickListener { _, _ ->
                        Store.reset(); rebuildList()
                    })
                    .setNegativeButton("Xeyr", null).show()
            }
        ))

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33) {
            try { requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1) } catch (_: Exception) {}
        }
        try {
            val s = Intent(this, KeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s) else startService(s)
        } catch (_: Exception) {}
        Adb.connect()
        rebuildList()
    }

    override fun onStart() {
        super.onStart()
        Adb.listeners.add(adbListener)
        ui.post(poll)
    }

    override fun onStop() {
        Adb.listeners.remove(adbListener)
        ui.removeCallbacks(poll)
        super.onStop()
    }

    private fun refresh() {
        val adb = when (Adb.state) {
            Adb.State.CONNECTED -> "QOŞULUB ✔"
            Adb.State.CONNECTING -> "qoşulur..."
            Adb.State.ERROR -> "XƏTA ✘ ${Adb.error ?: ""}"
            else -> "QOŞULMAYIB ✘"
        }
        status.text = "Arxa plan servisi: " + (if (KeepAliveService.running) "İŞLƏYİR ✔" else "DAYANIB ✘") +
            "\nDüymə tutma servisi: " + (if (KeyMapperService.running) "AKTİV ✔" else "SÖNÜLÜ ✘") +
            "\nADB ${Store.host}:${Store.port}: $adb" +
            "\nSürətli düymə rejimi: " + (if (Adb.fastReady) "AKTİV ✔ (~0 ms)" else "hazır deyil (ehtiyat rejim)")
    }

    private fun rebuildList() {
        list.removeAllViews()
        Store.mappings.forEach { m ->
            list.addView(TextView(this).apply {
                text = Store.keyName(m.key).removePrefix("KEYCODE_") +
                    "\n  Qısa: ${m.short.describe()}\n  Uzun: ${m.long.describe()}"
                textSize = 16f
                setPadding(0, dp(12), 0, dp(4))
            })
            list.addView(row(
                btn("Redaktə") { showEditor(m) },
                btn("Sil") { Store.remove(m.key); rebuildList() }
            ))
        }
    }

    private fun showHostDialog() {
        val et = EditText(this).apply {
            setSingleLine()
            setText("${Store.host}:${Store.port}")
        }
        AlertDialog.Builder(this)
            .setTitle("ADB ünvanı (ip:port)")
            .setView(et)
            .setPositiveButton("Yadda saxla", DialogInterface.OnClickListener { _, _ ->
                val t = et.text.toString().trim()
                val h = t.substringBefore(":")
                val p = t.substringAfter(":", "5555").toIntOrNull()
                if (h.isNotEmpty() && p != null) {
                    Store.host = h
                    Store.port = p
                    Adb.connect(force = true)
                    refresh()
                } else toast("Yanlış format")
            })
            .setNegativeButton("Ləğv et", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun captureKey(onKey: (Int) -> Unit) {
        var dlg: AlertDialog? = null
        val timeout = Runnable { dlg?.dismiss() }
        dlg = AlertDialog.Builder(this)
            .setTitle("Düyməyə basın")
            .setMessage("8 saniyə ərzində pultda və ya klaviaturada düyməyə basın")
            .setOnKeyListener { _, code, ev ->
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    dlg?.dismiss()
                    onKey(code)
                }
                true
            }
            .setOnDismissListener {
                KeyMapperService.capture = null
                ui.removeCallbacks(timeout)
            }
            .create()
        KeyMapperService.capture = { code -> dlg?.dismiss(); onKey(code) }
        dlg.show()
        ui.postDelayed(timeout, 8000)
    }

    private fun actionEditor(parent: LinearLayout, title: String, a: Action): Pair<Spinner, EditText> {
        parent.addView(label(title))
        val et = EditText(this).apply { setSingleLine(); setText(a.param) }
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Actions.LABELS
            )
            setSelection(Actions.TYPES.indexOf(a.type).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    et.hint = Actions.HINTS[pos]
                    et.visibility =
                        if (Actions.TYPES[pos] in listOf("KEY", "APP", "SHELL")) View.VISIBLE else View.GONE
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        parent.addView(sp)
        parent.addView(et)
        return Pair(sp, et)
    }

    private fun showEditor(old: Mapping?) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        c.addView(label("Mənbə düymə"))
        val keyEt = EditText(this).apply {
            setSingleLine()
            hint = "KEYCODE_BUTTON_5"
            setText(old?.let { Store.keyName(it.key) } ?: "")
        }
        c.addView(keyEt)
        c.addView(btn("Düyməni tut") { captureKey { keyEt.setText(Store.keyName(it)) } })
        val (sSp, sEt) = actionEditor(c, "Qısa basma", old?.short ?: Action())
        val (lSp, lEt) = actionEditor(c, "Uzun basma", old?.long ?: Action())

        AlertDialog.Builder(this)
            .setTitle(if (old == null) "Yeni düymə" else "Düyməni redaktə et")
            .setView(ScrollView(this).apply { addView(c) })
            .setPositiveButton("Yadda saxla", DialogInterface.OnClickListener { _, _ ->
                val code = Store.parseKey(keyEt.text.toString())
                if (code == 0) {
                    toast("Düymə tanınmadı")
                } else {
                    Store.upsert(
                        old?.key,
                        Mapping(
                            code,
                            Action(Actions.TYPES[sSp.selectedItemPosition], sEt.text.toString().trim()),
                            Action(Actions.TYPES[lSp.selectedItemPosition], lEt.text.toString().trim())
                        )
                    )
                    rebuildList()
                }
            })
            .setNegativeButton("Ləğv et", null)
            .show()
    }
}
