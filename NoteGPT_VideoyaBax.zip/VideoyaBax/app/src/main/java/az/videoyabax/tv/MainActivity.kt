package az.videoyabax.tv

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

/**
 * "Videoya bax" — Android TV tətbiqi.
 *
 * TV daxilində HTTP server işlədir. Telefon brauzerdən bu serverə qoşulur,
 * videosunu seçir və göndərir. Video heç bir yerə yazılmadan, birbaşa
 * şəbəkədən RAM buferi vasitəsilə anlıq olaraq TV-də oynanılır.
 */
@UnstableApi
class MainActivity : Activity(), StreamServer.Listener {

    companion object {
        private const val TAG = "VideoyaBax"
        private const val STREAM_URI = "videoyabax://stream"
    }

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var panel: View
    private lateinit var qrImage: ImageView
    private lateinit var urlText: TextView
    private lateinit var statusText: TextView

    private lateinit var server: StreamServer
    private val ui = Handler(Looper.getMainLooper())
    private var tvUrl = ""
    private var playingSession: StreamBuffer? = null

    private val statusUpdater = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        playerView = findViewById(R.id.player_view)
        panel = findViewById(R.id.panel)
        qrImage = findViewById(R.id.qr_image)
        urlText = findViewById(R.id.url_text)
        statusText = findViewById(R.id.status_text)

        val ip = resolveLocalIp()
        tvUrl = "http://$ip:${BuildConfig.SERVER_PORT}"
        urlText.text = "$ip:${BuildConfig.SERVER_PORT}"
        qrImage.setImageBitmap(createQrBitmap(tvUrl, 640))

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(StreamDataSourceFactory()))
            .build()
        playerView.player = player
        player.addListener(playerListener)

        val html = try {
            assets.open("index.html").bufferedReader().use { it.readText() }
                .replace("__TV_URL__", tvUrl)
        } catch (e: Exception) {
            Log.e(TAG, "index.html oxunmadı", e)
            "<html><body style=\"background:#000;color:#fff;font-family:sans-serif;padding:40px\">" +
                "<h1>Videoya bax</h1><p>Səhifə yüklənə bilmədi.</p></body></html>"
        }

        server = StreamServer(BuildConfig.SERVER_PORT, html, this)
        server.start()

        ui.post(statusUpdater)
        showPanel()
        updateStatus()
    }

    // ------------------------------------------------------------------ UI

    private fun showPanel() {
        panel.visibility = View.VISIBLE
    }

    private fun hidePanel() {
        panel.visibility = View.GONE
        playerView.requestFocus()
    }

    private fun updateStatus() {
        val session = server.activeSession
        val builder = StringBuilder()

        if (server.lastError != null) {
            builder.append("Server xətası: ").append(server.lastError)
        } else {
            when {
                session == null -> builder.append(getString(R.string.status_waiting))
                session.isFailed() -> builder.append("Xəta: ").append(session.errorMessage())
                !session.isComplete() -> {
                    builder.append("Qəbul edilir: ").append(formatSize(session.available()))
                    if (session.totalBytes > 0) {
                        builder.append(" / ").append(formatSize(session.totalBytes))
                        val percent = (session.available() * 100 / session.totalBytes).coerceIn(0, 100)
                        builder.append("  (").append(percent).append("%)")
                    }
                }
                else -> builder.append("Tam qəbul edildi: ").append(formatSize(session.available()))
            }
        }

        playingSession?.let {
            builder.append("\nOynadıcı: ").append(playerStateText())
        }

        statusText.text = builder.toString()
    }

    private fun playerStateText(): String = when (player.playbackState) {
        Player.STATE_IDLE -> "hazır deyil"
        Player.STATE_BUFFERING -> "yüklənir..."
        Player.STATE_READY -> if (player.isPlaying) "oynanılır" else "dayandırılıb"
        Player.STATE_ENDED -> "bitdi"
        else -> "-"
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format("%.0f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format("%.1f MB", mb)
        return String.format("%.2f GB", mb / 1024.0)
    }

    // ------------------------------------------------------------- Pult (D-pad)

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_BACK -> {
                if (panel.visibility == View.VISIBLE) {
                    hidePanel()
                    return true
                }
            }

            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO -> {
                showPanel()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------- Server hadisələri

    override fun onSessionStarted(session: StreamBuffer) {
        runOnUiThread {
            playingSession = session
            StreamSessionHolder.current = session
            player.stop()
            player.clearMediaItems()
            player.setMediaItem(MediaItem.fromUri(STREAM_URI))
            player.prepare()
            player.play()
            statusText.text = "Video qəbul edilir..."
            updateStatus()
        }
    }

    override fun onSessionProgress(session: StreamBuffer) {
        runOnUiThread { updateStatus() }
    }

    override fun onSessionFinished(session: StreamBuffer) {
        runOnUiThread { updateStatus() }
    }

    override fun onSessionFailed(session: StreamBuffer, message: String) {
        runOnUiThread {
            showPanel()
            statusText.text = "Xəta: $message"
            updateStatus()
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_READY -> hidePanel()
                Player.STATE_ENDED -> {
                    showPanel()
                    statusText.text = getString(R.string.status_finished)
                }
            }
            updateStatus()
        }

        override fun onPlayerError(error: PlaybackException) {
            Log.e(TAG, "Oynadıcı xətası", error)
            showPanel()
            statusText.text = "Video açıla bilmədi: ${error.errorCodeName}"
            updateStatus()
        }
    }

    // ------------------------------------------------------------- Köməkçilər

    private fun resolveLocalIp(): String {
        try {
            val candidates = ArrayList<String>()
            for (networkInterface in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!networkInterface.isUp || networkInterface.isLoopback) continue
                for (address in Collections.list(networkInterface.inetAddresses)) {
                    if (address is Inet4Address && !address.isLoopbackAddress) {
                        address.hostAddress?.let { candidates.add(it) }
                    }
                }
            }
            candidates.firstOrNull { it.startsWith("192.168.") }?.let { return it }
            candidates.firstOrNull { it.startsWith("10.") }?.let { return it }
            candidates.firstOrNull { it.startsWith("172.") }?.let { return it }
            candidates.firstOrNull()?.let { return it }
        } catch (e: Exception) {
            Log.w(TAG, "IP ünvanı tapılmadı, standart ünvan istifadə olunur", e)
        }
        return BuildConfig.DEFAULT_TV_IP
    }

    private fun createQrBitmap(content: String, size: Int): Bitmap {
        return try {
            val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size)
            val width = matrix.width
            val height = matrix.height
            val pixels = IntArray(width * height)
            for (y in 0 until height) {
                val offset = y * width
                for (x in 0 until width) {
                    pixels[offset + x] = if (matrix.get(x, y)) Color.BLACK else Color.WHITE
                }
            }
            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
                setPixels(pixels, 0, width, 0, 0, width, height)
            }
        } catch (e: Exception) {
            Log.e(TAG, "QR kod yaradıla bilmədi", e)
            Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        }
    }

    override fun onDestroy() {
        ui.removeCallbacks(statusUpdater)
        server.stop()
        player.release()
        super.onDestroy()
    }
}
