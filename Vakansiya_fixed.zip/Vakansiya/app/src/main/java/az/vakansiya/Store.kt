package az.vakansiya

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Site(var name: String, var url: String, var last: String = "", var today: Int = -1, var yest: Int = -1, var skip: Boolean = false) {
    // yalnız iş zamanı (yadda saxlanmır)
    var links: List<String>? = null
    var fresh: Int = -1
    var checked: Boolean = false
    /** Son 2 gün ərzində tapılan elanlar (ad, link, gün). */
    var items: List<Hit> = emptyList()
    /** 2 gün əvvəl paylaşılan elanların sayı */
    var d2: Int = -1
    /** Çəkməcə açıqdırmı (yalnız iş zamanı). */
    var expanded: Boolean = false
    /** Bu gün yerləşdirilən və açar sözə uyğun gələn elanlar ("Xüsusi Vakansiya"). */
    val special: List<Hit> get() = items.filter { it.kind > 0 && it.day == 0 }.sortedBy { it.kind }
}

/** kind: 1 = İT, 2 = çağrı mərkəzi / qeydiyyat, 3 = mühafizə / təhlükəsizlik */
/** day: 0 = bu gün, 1 = dünən, 2 = 2 gün əvvəl */
data class Hit(val title: String, val url: String, val kind: Int, val day: Int = 0, val dup: Int = 0) {
    /** Elanın açarı: eyni ad və eyni linkli təkrar elanlar da ayrıca sayılır (dup = sıra nömrəsi). */
    val key: String get() = "$url|$title|$dup"
    companion object {
        fun parse(a: JSONArray?): List<Hit> {
            if (a == null) return emptyList()
            val l = ArrayList<Hit>()
            val cnt = HashMap<String, Int>()
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val u = o.optString("h")
                if (u.isEmpty()) continue
                val n = o.optString("n")
                // eyni ad + eyni link təkrar gəlirsə də atılmır: sıra nömrəsi ilə ayrıca elan olur
                val dup = if (o.has("p")) o.optInt("p") else (cnt[u + "|" + n] ?: 0)
                cnt[u + "|" + n] = (cnt[u + "|" + n] ?: 0) + 1
                l.add(Hit(n, u, o.optInt("k"), o.optInt("d", 0), dup))
            }
            return l.sortedWith(compareBy({ it.day }, { if (it.kind == 0) 9 else it.kind }))
        }
    }
}

object Store {
    private val DEFAULTS = listOf(
        "HelloJob" to "https://www.hellojob.az/vakansiyalar",
        "Work.az" to "https://www.work.az/vakansiyalar?orderBy=DATE&orderDirection=DESC",
        "Busy.az" to "https://busy.az/vacancies",
        "HRIN" to "https://t.me/s/HRIN_AZ",
        "Glorri Jobs" to "https://jobs.glorri.az/?cityId=62f1516b22d84be76acb9d2d",
        "JobSearch" to "https://jobsearch.az/vacancies",
        "JobSearch Staj" to "https://jobsearch.az/internship-program",
        "eJob" to "https://ejob.az/is-elanlari/",
        "AzVak" to "https://azvak.az/",
        "AzJob" to "https://azjob.az/",
        "İşəqəbul" to "https://iseqebul.az/vakansiyalar/",
        "Boss.az" to "https://boss.az/search/vacancies",
        "EasyJob" to "https://easyjob.az/?search=&company_id=&category_id=&date=three_days&salary=",
        "HumanPro" to "https://humanpro.az/az/vakansiyalar",
        "Jooble" to "https://jooble.az/",
        "JobSite (İT)" to "https://jobsite.az/vakansiya-is-elanlari/informasiya-texnologiyalari",
        "JobSite Staj" to "https://jobsite.az/vakansiya-is-elanlari#staj",
        "Jobing (Bakı)" to "https://jobing.az/baki",
        "Vəzifə" to "https://vezife.az/",
        "Jobu" to "https://jobu.az/vakansiyalar/?filter-orderby=newest"
    )

    /** Yoxlanılmayan saytlar (istifadəçi sonradan dəyişə bilər). */
    fun defaultSkip(url: String) = listOf("easyjob.az", "jobsite.az").any { url.contains(it) }

    /** "#staj" ilə bitən JobSite ünvanı: yalnız təcrübə/staj elanları sayılır. */
    fun stajFilter(url: String) = url.contains("jobsite.az") && url.endsWith("#staj")

    /** Elan tarixi yalnız elanın öz səhifəsində olan saytlar. */
    fun detail(url: String) = url.contains("jobsite.az") || telegram(url)

    /** Telegram kanalı: elanların paylaşım saatları kanaldan oxunur (t.me/s/KANAL önizləməsi). */
    fun telegram(url: String) = url.contains("t.me/")

    /** Yoxlama zamanı açılan ünvan: t.me/KANAL → t.me/s/KANAL (açıq önizləmə). */
    fun scanUrl(url: String): String =
        Regex("^https?://t\\.me/(?!s/)([A-Za-z0-9_]+)/?$").find(url)?.let { "https://t.me/s/" + it.groupValues[1] } ?: url

    /** Birinci səhifədən əlavə yoxlanılan səhifələr (məs. Busy.az-ın 2-ci səhifəsi). */
    fun extraPages(url: String): List<String> {
        if (!url.contains("busy.az/vacancies")) return emptyList()
        if (url.contains("page=1")) return listOf(url.replace("page=1", "page=2"))
        if (url.contains("page=")) return emptyList()
        return listOf(if (url.contains("?")) "$url&page=2" else url.trimEnd('/') + "?page=2")
    }

    /** Daha diqqətli (kart əsaslı) yoxlanılan saytlar. */
    fun careful(url: String) = listOf("jobsearch.az", "jobing.az", "jobu.az", "glorri.az").any { url.contains(it) }

    /** Glorri qaydası: səhifəni aşağı sürüşdürüb / "Daha çox yüklə" düyməsini basıb köhnə elanlara çatana qədər yükləyən saytlar. */
    fun scrolly(url: String) = listOf("glorri.az", "work.az", "jobsearch.az", "azvak.az", "boss.az", "jobu.az", "iseqebul.az", "jobing.az").any { url.contains(it) }

    /** İlk oxumanın başlama vaxtı: sürüşdürən saytlarda tez başlayır (hazırdırsa gözləmədən bitir), digərlərində firstWait qədər gözləyir. */
    fun startDelay(url: String): Long = if (scrolly(url)) minOf(firstWait(url), 1500L) else firstWait(url)

    /** Səhifə açıldıqdan sonra ilk oxumadan əvvəl gözləmə (ms). Sürüşdürən saytlarda: bu müddət keçməmiş "dayanma" sayılmır. */
    fun firstWait(url: String): Long = when {
        url.contains("glorri.az") -> 5000L
        url.contains("jobu.az") -> 5000L
        url.contains("jobing.az") -> 6000L
        url.contains("iseqebul.az") -> 3000L
        url.contains("jooble") -> 10000L
        scrolly(url) -> 1500L
        url.contains("busy.az") -> 3000L
        else -> 600L
    }

    private fun p(c: Context) = c.getSharedPreferences("vak", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Site> {
        val s = p(c).getString("sites", null)
        val l = mutableListOf<Site>()
        if (s == null) {
            DEFAULTS.forEach { l.add(Site(it.first, it.second, skip = defaultSkip(it.second))) }
            save(c, l)
            return l
        }
        val a = JSONArray(s)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            l.add(Site(o.getString("n"), o.getString("u"), o.optString("l", ""), o.optInt("t", -1), o.optInt("y", -1),
                if (o.has("k")) o.getBoolean("k") else defaultSkip(o.getString("u"))).also { st -> st.d2 = o.optInt("w", -1); st.items = Hit.parse(o.optJSONArray("i")) })
        }
        if (!p(c).getBoolean("mig_staj", false)) {
            if (l.none { it.url.endsWith("#staj") }) {
                val idx = l.indexOfFirst { it.url.contains("jobsite.az") }
                l.add(if (idx >= 0) idx + 1 else l.size, Site("JobSite Staj", "https://jobsite.az/vakansiya-is-elanlari#staj"))
            }
            p(c).edit().putBoolean("mig_staj", true).apply()
            save(c, l)
        }
        // Busy.az əvvəlki ünvanına qaytarılır (bir dəfəlik)
        if (!p(c).getBoolean("mig_busy_back", false)) {
            l.filter { it.url.contains("busy.az/vacancies") }.forEach { it.url = "https://busy.az/vacancies" }
            p(c).edit().putBoolean("mig_busy_back", true).apply()
            save(c, l)
        }
        // HRIN: Telegram kanalından (paylaşım saatlarına görə) yoxlanılır; yandırılır (bir dəfəlik)
        if (!p(c).getBoolean("mig_hrin_tg", false)) {
            l.filter { it.url.contains("hrin.az") }.forEach { it.url = "https://t.me/s/HRIN_AZ"; it.last = ""; it.skip = false }
            p(c).edit().putBoolean("mig_hrin_tg", true).apply()
            save(c, l)
        }
        // JobSite saytları (hər ikisi) yoxlanılmasın; sonradan menyudan yandırmaq olar
        if (!p(c).getBoolean("mig_jobsite_off", false)) {
            l.filter { it.url.contains("jobsite.az") }.forEach { it.skip = true }
            p(c).edit().putBoolean("mig_jobsite_off", true).apply()
            save(c, l)
        }
        // İşəqəbul yoxlanılmasın (bir dəfəlik); sonradan menyudan yandırmaq olar
        if (!p(c).getBoolean("mig_iseqebul_off", false)) {
            l.filter { it.url.contains("iseqebul.az") }.forEach { it.skip = true }
            p(c).edit().putBoolean("mig_iseqebul_off", true).apply()
            save(c, l)
        }
        // İşəqəbul: "N gün qalıb" məntiqi ilə yoxlanılır; ünvan /vakansiyalar/ olur və yandırılır (bir dəfəlik)
        if (!p(c).getBoolean("mig_iseqebul_on", false)) {
            l.filter { it.url.contains("iseqebul.az") }.forEach { it.url = "https://iseqebul.az/vakansiyalar/"; it.last = ""; it.skip = false }
            p(c).edit().putBoolean("mig_iseqebul_on", true).apply()
            save(c, l)
        }
        return l
    }

    private fun hitsJson(l: List<Hit>) = JSONArray().also { a ->
        l.forEach { a.put(JSONObject().put("n", it.title).put("h", it.url).put("k", it.kind).put("d", it.day).put("p", it.dup)) }
    }

    fun save(c: Context, l: List<Site>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("n", it.name).put("u", it.url).put("l", it.last).put("t", it.today).put("y", it.yest).put("w", it.d2).put("k", it.skip).put("i", hitsJson(it.items)))
        }
        p(c).edit().putString("sites", a.toString()).apply()
    }

    fun setLast(c: Context, base: String, last: String) {
        val l = load(c)
        l.firstOrNull { it.url == base }?.last = last
        save(c, l)
    }
}
