package az.yvok.app;

import android.Manifest;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;
import java.util.ArrayList;

// Tətbiqin öz kamerası: sənəd çəkilişi üçün (çərçivə bələdçisi, toxunub fokus, fənər, çoxlu şəkil, qalereya)
public class CameraActivity extends ComponentActivity {

    private static final int REQ_PERM = 11;
    private static final int REQ_GALLERY = 12;

    private PreviewView preview;
    private ImageCapture capture;
    private Camera camera;
    private boolean torch = false;
    private boolean busy = false;
    private final ArrayList<Uri> shots = new ArrayList<>();
    private TextView doneBtn;
    private TextView countTv;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_PERM);
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        preview = new PreviewView(this);
        preview.setScaleType(PreviewView.ScaleType.FIT_CENTER);
        root.addView(preview, new FrameLayout.LayoutParams(-1, -1));

        View guide = new View(this) {
            final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override
            protected void onDraw(Canvas c) {
                float m = dp(24);
                RectF r = new RectF(m, dp(80), getWidth() - m, getHeight() - dp(190));
                p.setStyle(Paint.Style.STROKE);
                p.setColor(Color.argb(200, 255, 255, 255));
                p.setStrokeWidth(dp(3));
                float L = dp(34);
                c.drawLine(r.left, r.top, r.left + L, r.top, p);
                c.drawLine(r.left, r.top, r.left, r.top + L, p);
                c.drawLine(r.right, r.top, r.right - L, r.top, p);
                c.drawLine(r.right, r.top, r.right, r.top + L, p);
                c.drawLine(r.left, r.bottom, r.left + L, r.bottom, p);
                c.drawLine(r.left, r.bottom, r.left, r.bottom - L, p);
                c.drawLine(r.right, r.bottom, r.right - L, r.bottom, p);
                c.drawLine(r.right, r.bottom, r.right, r.bottom - L, p);
            }
        };
        guide.setClickable(false);
        root.addView(guide, new FrameLayout.LayoutParams(-1, -1));

        preview.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_UP && camera != null) {
                MeteringPoint pt = preview.getMeteringPointFactory().createPoint(e.getX(), e.getY());
                camera.getCameraControl().startFocusAndMetering(new FocusMeteringAction.Builder(pt).build());
                v.performClick();
            }
            return true;
        });

        // Yuxarı sətir: bağla + fənər
        FrameLayout top = new FrameLayout(this);
        TextView close = label("✕", 22);
        close.setOnClickListener(v -> { setResult(RESULT_CANCELED); finish(); });
        top.addView(close, new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.START));
        TextView flash = label("🔦", 22);
        flash.setOnClickListener(v -> {
            torch = !torch;
            if (camera != null && camera.getCameraInfo().hasFlashUnit()) camera.getCameraControl().enableTorch(torch);
            flash.setAlpha(torch ? 1f : 0.5f);
        });
        flash.setAlpha(0.5f);
        top.addView(flash, new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.END));
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(-1, dp(56), Gravity.TOP);
        tlp.topMargin = dp(24);
        tlp.leftMargin = dp(12);
        tlp.rightMargin = dp(12);
        root.addView(top, tlp);

        TextView hint = label("Sənədi çərçivəyə yerləşdirin", 14);
        hint.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        hlp.topMargin = dp(88);
        root.addView(hint, hlp);

        // Aşağı sətir: qalereya | çək | hazır
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.argb(140, 0, 0, 0));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setGravity(Gravity.CENTER);
        TextView gal = label("🖼", 26);
        gal.setOnClickListener(v -> pickGallery());
        left.addView(gal, new LinearLayout.LayoutParams(dp(56), dp(56)));
        bar.addView(left, new LinearLayout.LayoutParams(0, -1, 1f));

        View shutter = new View(this);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(Color.WHITE);
        gd.setStroke(dp(5), Color.argb(160, 120, 120, 120));
        shutter.setBackground(gd);
        shutter.setOnClickListener(v -> takeShot());
        bar.addView(shutter, new LinearLayout.LayoutParams(dp(74), dp(74)));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER);
        countTv = label("", 13);
        doneBtn = label("Hazır ✓", 16);
        GradientDrawable dbg = new GradientDrawable();
        dbg.setCornerRadius(dp(22));
        dbg.setColor(Color.parseColor("#2E7D32"));
        doneBtn.setBackground(dbg);
        doneBtn.setPadding(dp(16), dp(10), dp(16), dp(10));
        doneBtn.setOnClickListener(v -> finishWithShots());
        doneBtn.setVisibility(View.INVISIBLE);
        right.addView(countTv);
        right.addView(doneBtn);
        bar.addView(right, new LinearLayout.LayoutParams(0, -1, 1f));

        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-1, dp(130), Gravity.BOTTOM);
        root.addView(bar, blp);

        setContentView(root);
    }

    private TextView label(String t, int sp) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(sp);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private void startCamera() {
        final ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(this);
        f.addListener(() -> {
            try {
                ProcessCameraProvider provider = f.get();
                Preview pv = new Preview.Builder().build();
                pv.setSurfaceProvider(preview.getSurfaceProvider());
                capture = new ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)   // sənəd üçün maksimum keyfiyyət
                        .build();
                provider.unbindAll();
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv, capture);
            } catch (Exception e) {
                Toast.makeText(this, "Kamera açılmadı", Toast.LENGTH_SHORT).show();
                setResult(RESULT_CANCELED);
                finish();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void takeShot() {
        if (capture == null || busy) return;
        busy = true;
        File dir = new File(getCacheDir(), "ocr");
        dir.mkdirs();
        final File out = new File(dir, "cam_" + System.currentTimeMillis() + ".jpg");
        capture.takePicture(new ImageCapture.OutputFileOptions.Builder(out).build(),
                ContextCompat.getMainExecutor(this),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(ImageCapture.OutputFileResults r) {
                        busy = false;
                        shots.add(Uri.fromFile(out));
                        updateBar();
                    }

                    @Override
                    public void onError(ImageCaptureException e) {
                        busy = false;
                        Toast.makeText(CameraActivity.this, "Şəkil çəkilmədi", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void updateBar() {
        countTv.setText(shots.size() + " şəkil");
        doneBtn.setVisibility(shots.isEmpty() ? View.INVISIBLE : View.VISIBLE);
    }

    private void pickGallery() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(Intent.createChooser(pick, "Şəkil seçin"), REQ_GALLERY);
        } catch (Exception e) {
            Toast.makeText(this, "Qalereya açılmadı", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_GALLERY || res != RESULT_OK || data == null) return;
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) shots.add(u);
            }
        } else if (data.getData() != null) {
            shots.add(data.getData());
        }
        finishWithShots();
    }

    private void finishWithShots() {
        if (shots.isEmpty()) return;
        Intent r = new Intent();
        ClipData clip = ClipData.newRawUri("", shots.get(0));
        for (int i = 1; i < shots.size(); i++) clip.addItem(new ClipData.Item(shots.get(i)));
        r.setClipData(clip);
        r.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        setResult(RESULT_OK, r);
        finish();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req != REQ_PERM) return;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            Toast.makeText(this, "Kamera icazəsi lazımdır", Toast.LENGTH_LONG).show();
            setResult(RESULT_CANCELED);
            finish();
        }
    }
}
