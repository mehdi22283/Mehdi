package az.wifiscan

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.os.*
import android.view.*
import android.widget.*
import org.json.JSONObject
import java.net.*
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val BG = 0xFF000000.toInt()
    private val CARD = 0xFF0C0C0C.toInt()
    private val TXT = 0xFFE6EDF3.toInt()
    private val SUB = 0xFF8FA3B5.toInt()
    private val ACC = 0xFF4FC3F7.toInt()
    private lateinit var pages: Array<View>
    private lateinit var tabBtns: Array<TextView>

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun tv(t: String = "", sz: Float = 14f, col: Int = TXT, bold: Boolean = false, mono: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = sz; setTextColor(col)
            typeface = if (mono) Typeface.MONOSPACE else if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.BLACK); setBackgroundColor(ACC); setOnClickListener { f() }
    }
    private fun edit(h: String, def: String) = EditText(this).apply {
        setText(def); setHint(h); setTextColor(TXT); setHintTextColor(SUB); setSingleLine()
    }
    private fun onUiSync(f: () -> Unit) {
        val l = CountDownLatch(1); ui.post { f(); l.countDown() }; l.await()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(0, dp(24), 0, 0) }
        val content = FrameLayout(this)
        pages = arrayOf(scanPage(), pingPage(), tracePage(), speedPage())
        pages.forEach { content.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(CARD) }
        val names = arrayOf("📡 Skan", "🏓 Ping", "🧭 Trace", "⚡ Sürət")
        tabBtns = Array(4) { i ->
            tv(names[i], 13f, SUB, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14)); setOnClickListener { select(i) } }
        }
        tabBtns.forEach { bar.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        setContentView(root); select(0)
    }

    private fun select(i: Int) {
        pages.forEachIndexed { j, v -> v.visibility = if (i == j) View.VISIBLE else View.GONE }
        tabBtns.forEachIndexed { j, t -> t.setTextColor(if (i == j) ACC else SUB) }
    }

    // ---------------- SKAN ----------------
    private lateinit var infoTv: TextView
    private lateinit var cntTv: TextView
    private lateinit var pb: ProgressBar
    private lateinit var scanBtn: Button
    private lateinit var devAdapter: DevAdapter
    private var scanner: Scanner? = null
    private val pend = AtomicBoolean(false)

    private fun scanPage(): View {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), 0) }
        p.addView(tv("Wi-Fi Skaner", 22f, ACC, true))
        infoTv = tv("", 12f, SUB); p.addView(infoTv)
        pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        p.addView(pb)
        cntTv = tv("Hazırdır", 13f); p.addView(cntTv)
        scanBtn = btn("▶ Skana başla") { toggleScan() }; p.addView(scanBtn)
        devAdapter = DevAdapter()
        val lv = ListView(this)
        lv.adapter = devAdapter
        lv.divider = ColorDrawable(BG); lv.dividerHeight = dp(6)
        lv.setOnItemClickListener { _, _, pos, _ -> showDevice(devAdapter.items[pos]) }
        p.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        return p
    }

    private fun netInfo(): Triple<String, Int, String>? {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return null
        val lp = cm.getLinkProperties(n) ?: return null
        val la = lp.linkAddresses.firstOrNull { it.address is Inet4Address && !it.address.isLoopbackAddress } ?: return null
        val gw = lp.routes.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress ?: ""
        return Triple(la.address.hostAddress ?: return null, la.prefixLength, gw)
    }

    private fun toggleScan() {
        if (scanner != null) { scanner?.cancel(); return }
        val ni = netInfo()
        if (ni == null) { Toast.makeText(this, "Wi-Fi şəbəkəsinə qoşulun", Toast.LENGTH_LONG).show(); return }
        val (ip, prefix, gw) = ni
        Store.devices.clear(); Store.upnp.clear(); Store.gateway = gw; Store.localIp = ip
        devAdapter.reload()
        infoTv.text = "IP: $ip/$prefix • Gateway: $gw"
        scanBtn.text = "⏹ Dayandır"
        val s = Scanner(applicationContext,
            { refresh() },
            { d, t -> ui.post { pb.progress = d * 100 / t; cntTv.text = "Yoxlanılır: $d/$t • Tapılan: ${Store.devices.size}" } },
            { ui.post { scanner = null; scanBtn.text = "▶ Yenidən skan"; pb.progress = 100; cntTv.text = "Bitdi • ${Store.devices.size} cihaz"; devAdapter.reload() } })
        scanner = s; s.start(ip, prefix, gw)
    }

    private fun refresh() {
        if (pend.compareAndSet(false, true)) ui.postDelayed({ pend.set(false); devAdapter.reload() }, 200)
    }

    inner class DevAdapter : BaseAdapter() {
        var items: List<Device> = emptyList()
        fun reload() {
            items = Store.devices.values.sortedBy { it.ip.split(".").fold(0L) { a, s -> a * 256 + (s.toLongOrNull() ?: 0) } }
            notifyDataSetChanged()
        }
        override fun getCount() = items.size
        override fun getItem(i: Int) = items[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, cv: View?, parent: ViewGroup): View {
            val d = items[i]
            val row = (cv as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(CARD)
                layoutParams = AbsListView.LayoutParams(-1, -2)
                addView(tv("", 15f, TXT, true)); addView(tv("", 13f, ACC))
                addView(tv("", 12f, SUB)); addView(tv("", 12f, 0xFF9CCC65.toInt()))
            }
            (row.getChildAt(0) as TextView).text = "${d.type}   ${d.ip}"
            val m = listOf(d.vendor, d.model).filter { it.isNotBlank() }.distinct().joinToString(" • ")
            (row.getChildAt(1) as TextView).text = if (m.isEmpty()) "Model: məlum deyil" else m
            (row.getChildAt(2) as TextView).text = "MAC: ${if (d.mac.isEmpty()) "—" else d.mac}   ${d.name}"
            (row.getChildAt(3) as TextView).text =
                if (d.ports.isEmpty()) "🔒 Açıq port yoxdur / yoxlanılır" else "🔓 " + d.ports.joinToString(", ") { "$it ${Net.PORTS[it] ?: ""}" }
            return row
        }
    }

    private fun showDevice(d: Device) {
        val s = StringBuilder()
        s.append("Tip: ${d.type}\nIP: ${d.ip}\nMAC: ${d.mac.ifEmpty { "—" }}\nİstehsalçı: ${d.vendor.ifEmpty { "—" }}\nModel: ${d.model.ifEmpty { "—" }}\nAd: ${d.name.ifEmpty { "—" }}\n")
        if (d.upnp.isNotEmpty()) s.append("UPnP: ${d.upnp}\n")
        if (d.http.isNotEmpty()) s.append("Web: ${d.http}\n")
        s.append("\nAçıq portlar:\n")
        if (d.ports.isEmpty()) s.append("—") else d.ports.forEach { s.append("  $it  ${Net.PORTS[it] ?: ""}\n") }
        AlertDialog.Builder(this).setTitle(d.ip).setMessage(s.toString())
            .setPositiveButton("Traceroute") { _, _ -> traceHost.setText(d.ip); select(2); startTrace() }
            .setNeutralButton("Ping") { _, _ -> pingHost.setText(d.ip); select(1); togglePing() }
            .setNegativeButton("Bağla", null).show()
    }

    // ---------------- PING ----------------
    private lateinit var pingHost: EditText
    private lateinit var pingOut: TextView
    private lateinit var pingSv: ScrollView
    private lateinit var pingBtn: Button
    @Volatile private var pingProc: Process? = null

    private fun pingPage(): View {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), 0) }
        p.addView(tv("Ping", 22f, ACC, true))
        pingHost = edit("Host / IP", "8.8.8.8"); p.addView(pingHost)
        pingBtn = btn("▶ Ping") { togglePing() }; p.addView(pingBtn)
        pingOut = tv("", 12f, TXT, false, true)
        pingSv = ScrollView(this).apply { addView(pingOut) }
        p.addView(pingSv, LinearLayout.LayoutParams(-1, 0, 1f))
        return p
    }

    private fun togglePing() {
        if (pingProc != null) { pingProc?.destroy(); return }
        val host = pingHost.text.toString().trim(); if (host.isEmpty()) return
        pingOut.text = ""; pingBtn.text = "⏹ Dayandır"
        Thread {
            try {
                val p = ProcessBuilder("/system/bin/ping", "-c", "20", host).redirectErrorStream(true).start()
                pingProc = p
                p.inputStream.bufferedReader().forEachLine { l ->
                    ui.post { pingOut.append(l + "\n"); pingSv.post { pingSv.fullScroll(View.FOCUS_DOWN) } }
                }
                p.waitFor()
            } catch (e: Exception) { ui.post { pingOut.append("Xəta: ${e.message}\n") } }
            pingProc = null; ui.post { pingBtn.text = "▶ Ping" }
        }.start()
    }

    // ---------------- TRACEROUTE ----------------
    private lateinit var traceHost: EditText
    private lateinit var traceBox: LinearLayout
    private lateinit var traceSv: ScrollView
    private lateinit var traceBtn: Button
    private lateinit var traceHead: TextView
    @Volatile private var tracing = false
    @Volatile private var traceStop = false
    @Volatile private var traceProc: Process? = null

    private fun tracePage(): View {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), 0) }
        p.addView(tv("Traceroute", 22f, ACC, true))
        traceHost = edit("Host / IP", "google.com"); p.addView(traceHost)
        traceBtn = btn("▶ Traceroute") { startTrace() }; p.addView(traceBtn)
        traceHead = tv("", 13f, SUB); p.addView(traceHead)
        traceBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        traceSv = ScrollView(this).apply { addView(traceBox) }
        p.addView(traceSv, LinearLayout.LayoutParams(-1, 0, 1f))
        return p
    }

    private fun endTrace() { tracing = false; traceBtn.text = "▶ Traceroute" }

    private fun startTrace() {
        if (tracing) { traceStop = true; traceProc?.destroy(); return }
        val host = traceHost.text.toString().trim(); if (host.isEmpty()) return
        tracing = true; traceStop = false; traceBox.removeAllViews()
        traceBtn.text = "⏹ Dayandır"; traceHead.text = "Həll edilir: $host …"
        Thread {
            val dest = try { InetAddress.getByName(host).hostAddress ?: host } catch (e: Exception) {
                ui.post { traceHead.text = "❌ Host tapılmadı: $host"; endTrace() }; return@Thread
            }
            ui.post { traceHead.text = "🎯 Hədəf: $host ($dest) • maks. 30 hop" }
            val geo = ConcurrentHashMap<Int, String>()
            val workers = ArrayList<Thread>()
            var miss = 0; var hops = 0
            for (ttl in 1..30) {
                if (traceStop) break
                var v: TextView? = null
                onUiSync {
                    v = tv("#$ttl  …", 13f, TXT, false, true).apply { setBackgroundColor(CARD); setPadding(dp(10), dp(8), dp(10), dp(8)) }
                    traceBox.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
                    traceSv.post { traceSv.fullScroll(View.FOCUS_DOWN) }
                }
                val view = v!!
                val t0 = System.nanoTime()
                val out = try {
                    val pr = ProcessBuilder("/system/bin/ping", "-c", "1", "-W", "2", "-t", "$ttl", dest).redirectErrorStream(true).start()
                    traceProc = pr
                    val s = pr.inputStream.bufferedReader().readText(); pr.waitFor(); s
                } catch (e: Exception) { "" }
                val wall = (System.nanoTime() - t0) / 1_000_000
                val ip = Regex("[Ff]rom\\s+(\\d+\\.\\d+\\.\\d+\\.\\d+)").find(out)?.groupValues?.get(1)
                if (ip == null) {
                    miss++
                    ui.post { view.text = "#$ttl  * * *   cavab yoxdur (ICMP bloklana bilər)" }
                    if (miss >= 6) break else continue
                }
                miss = 0; hops++
                val exact = Regex("time=([0-9.]+)").find(out)?.groupValues?.get(1)
                val rtt = if (exact != null) "$exact ms" else "~$wall ms"
                ui.post { view.text = "#$ttl  $ip   $rtt\n⏳ məlumat toplanır…" }
                val w = Thread { val info = hopInfo(ip, ttl, geo); ui.post { view.text = "#$ttl  $ip   $rtt\n$info" } }
                w.start(); workers.add(w)
                if (ip == dest) break
            }
            workers.forEach { it.join(6000) }
            val path = (1..30).mapNotNull { geo[it] }.fold(ArrayList<String>()) { a, c -> if (a.lastOrNull() != c) a.add(c); a }
            ui.post {
                traceHead.text = "✅ Bitdi: $hops hop cavab verdi" + (if (path.isNotEmpty()) "\n🌍 Marşrut: ${path.joinToString(" → ")}" else "")
                endTrace()
            }
        }.start()
    }

    private fun isPrivate(ip: String): Boolean {
        val p = ip.split("."); val a = p[0].toInt(); val b = p[1].toInt()
        return a == 10 || (a == 192 && b == 168) || (a == 172 && b in 16..31) || (a == 100 && b in 64..127) || (a == 169 && b == 254)
    }

    private fun role(h: String): String {
        val s = h.lowercase()
        return when {
            Regex("(^|[.-])(gw|gateway)\\d*").containsMatchIn(s) -> "Gateway"
            s.contains("core") || Regex("(^|[.-])cr\\d").containsMatchIn(s) -> "Core router (magistral)"
            s.contains("edge") || s.contains("border") || Regex("(^|[.-])(br|er)\\d").containsMatchIn(s) -> "Edge / Border router"
            Regex("(^|[.-])ix").containsMatchIn(s) || s.contains("peering") -> "IXP / peering nöqtəsi"
            s.contains("backbone") || Regex("(^|[.-])bb").containsMatchIn(s) -> "Backbone"
            s.contains("agg") || s.contains("dist") -> "Aqreqasiya / paylayıcı"
            s.contains("google") || s.contains("cloudflare") || s.contains("cdn") || s.contains("amazon") -> "Hədəf / CDN serveri"
            else -> "Router"
        }
    }

    private fun hopInfo(ip: String, ttl: Int, geo: MutableMap<Int, String>): String {
        val sb = StringBuilder()
        val rdns = try { val n = InetAddress.getByName(ip).canonicalHostName; if (n != ip) n else "" } catch (e: Exception) { "" }
        val dev = Store.devices[ip]
        if (isPrivate(ip)) {
            when {
                ip == Store.gateway || (ttl == 1 && dev == null) ->
                    sb.append("🌐 Router / Gateway (sizin şəbəkənin çıxışı)" + (dev?.let { "\n   ${it.vendor} ${it.model}".trimEnd() } ?: ""))
                dev != null -> sb.append("🏠 Lokal cihaz: ${dev.type}\n   ${dev.vendor} ${dev.model}".trimEnd())
                ip.startsWith("100.") -> sb.append("🏢 Provayder daxili (CGNAT) cihazı")
                else -> sb.append("🏢 Provayderin daxili şəbəkə cihazı (private IP)")
            }
        } else {
            try {
                val c = URL("http://ip-api.com/json/$ip?fields=status,country,countryCode,regionName,city,isp,org,as").openConnection() as HttpURLConnection
                c.connectTimeout = 3000; c.readTimeout = 3000
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                if (j.optString("status") == "success") {
                    geo[ttl] = j.optString("countryCode")
                    sb.append("📍 ${j.optString("city")}, ${j.optString("regionName")}, ${j.optString("country")}\n")
                    sb.append("🏢 ${j.optString("isp")} (${j.optString("org")})\n🔢 ${j.optString("as")}")
                } else sb.append("📍 Məlumat tapılmadı")
            } catch (e: Exception) { sb.append("📍 Geo məlumatı alınmadı") }
        }
        if (rdns.isNotEmpty()) sb.append("\n🔖 $rdns\n   → ${role(rdns)}")
        return sb.toString()
    }

    // ---------------- SPEED ----------------
    private lateinit var spTv: TextView
    private lateinit var spInfo: TextView
    private lateinit var spBtn: Button
    private lateinit var spPb: ProgressBar
    @Volatile private var spRun = false

    private fun speedPage(): View {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), 0) }
        p.addView(tv("Download sürəti", 22f, ACC, true))
        spTv = tv("0.0 Mbps", 40f, TXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(30), 0, dp(10)) }
        p.addView(spTv)
        spInfo = tv("", 13f, SUB).apply { gravity = Gravity.CENTER }; p.addView(spInfo)
        spPb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }; p.addView(spPb)
        spBtn = btn("▶ Testə başla") { toggleSpeed() }; p.addView(spBtn)
        return p
    }

    private fun toggleSpeed() {
        if (spRun) { spRun = false; return }
        spRun = true; spBtn.text = "⏹ Dayandır"; spPb.progress = 0
        Thread {
            val total = AtomicLong(0); val start = System.nanoTime(); val durMs = 10000L
            val ws = (1..4).map {
                Thread {
                    try {
                        val c = URL("https://speed.cloudflare.com/__down?bytes=50000000").openConnection() as HttpURLConnection
                        c.connectTimeout = 5000; c.readTimeout = 5000
                        val ins = c.inputStream; val buf = ByteArray(65536)
                        while (spRun && (System.nanoTime() - start) / 1_000_000 < durMs) {
                            val n = ins.read(buf); if (n < 0) break; total.addAndGet(n.toLong())
                        }
                        ins.close(); c.disconnect()
                    } catch (e: Exception) {}
                }.also { it.start() }
            }
            var peak = 0.0; var lastB = 0L; var lastT = start
            while (spRun && (System.nanoTime() - start) / 1_000_000 < durMs && ws.any { it.isAlive }) {
                Thread.sleep(250)
                val now = System.nanoTime(); val b = total.get()
                val inst = (b - lastB) * 8.0 / ((now - lastT) / 1e9) / 1e6
                lastB = b; lastT = now; peak = maxOf(peak, inst)
                val avg = b * 8.0 / ((now - start) / 1e9) / 1e6
                val pr = (((now - start) / 1e6) * 100 / durMs).toInt()
                val pk = peak
                ui.post {
                    spTv.text = String.format("%.1f Mbps", inst)
                    spInfo.text = String.format("Orta: %.1f • Maks: %.1f Mbps • %.1f MB", avg, pk, b / 1e6)
                    spPb.progress = pr
                }
            }
            spRun = false
            val el = maxOf((System.nanoTime() - start) / 1e9, 0.001)
            val avg = total.get() * 8.0 / el / 1e6
            val pk = peak; val mb = total.get() / 1e6
            ui.post {
                spTv.text = String.format("%.1f Mbps", avg)
                spInfo.text = String.format("Yekun orta: %.1f Mbps • Maks: %.1f • %.1f MB / %.1f san", avg, pk, mb, el)
                spBtn.text = "▶ Yenidən test"; spPb.progress = 100
            }
        }.start()
    }
}
