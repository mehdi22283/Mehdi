package com.example.callrec

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val info = TextView(this).apply {
            setPadding(40, 40, 40, 20)
            text = "Zəng Yazıcı (Shizuku)\n\n" +
                "1) Shizuku tətbiqini quraşdır\n" +
                "2) Developer options → Wireless debugging → aç\n" +
                "3) Shizuku → \"Pairing\" ilə kodla qoşul, sonra Start\n" +
                "4) Aşağıda \"İcazə ver\" və \"Başlat\""
        }
        status = TextView(this).apply { setPadding(40, 10, 40, 10) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        setContentView(ScrollView(this).apply { addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(info); addView(status)
            addView(btn("Shizuku-nu aç") {
                packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let(::startActivity)
                    ?: Toast.makeText(context, "Shizuku quraşdırılmayıb", Toast.LENGTH_LONG).show() })
            addView(btn("Developer options") { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) })
            addView(btn("Shizuku icazəsi ver") { askShizuku() })
            addView(btn("Başlat") { start() })
            addView(btn("Dayandır") { stopService(Intent(context, RecorderService::class.java)) })
        }) })
        requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        status.text = when {
            !Shizuku.pingBinder() -> "Shizuku: İŞLƏMİR"
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> "Shizuku: işləyir, icazə YOXDUR"
            else -> "Shizuku: hazırdır ✔"
        }
    }

    private fun askShizuku() {
        if (!Shizuku.pingBinder()) { refresh(); return }
        Shizuku.addRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }
        Shizuku.requestPermission(100)
    }

    private fun start() {
        refresh()
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED)
            startForegroundService(Intent(this, RecorderService::class.java))
        else Toast.makeText(this, "Əvvəl Shizuku-nu başladın və icazə verin", Toast.LENGTH_LONG).show()
    }
}
