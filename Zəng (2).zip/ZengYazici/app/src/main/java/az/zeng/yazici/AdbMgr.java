package az.zeng.yazici;

import android.content.Context;
import android.os.Build;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.conscrypt.Conscrypt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import java.util.Random;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;

/** libadb-android üçün açar/sertifikat saxlayıcısı. Açar tətbiqin daxili qovluğunda qalır. */
final class AdbMgr extends AbsAdbConnectionManager {
    private static AdbMgr inst;
    private final PrivateKey key;
    private final Certificate cert;

    static synchronized AdbMgr get(Context c) throws Exception {
        if (inst == null) inst = new AdbMgr(c.getApplicationContext());
        return inst;
    }

    static boolean paired(Context c) {
        return new File(c.getFilesDir(), "adb.key").exists() && new File(c.getFilesDir(), "adb.crt").exists()
                && c.getSharedPreferences("st", 0).getBoolean("paired", false);
    }

    private AdbMgr(Context c) throws Exception {
        Security.insertProviderAt(Conscrypt.newProvider(), 1);
        setApi(Build.VERSION.SDK_INT);
        File kf = new File(c.getFilesDir(), "adb.key");
        File cf = new File(c.getFilesDir(), "adb.crt");
        PrivateKey k = null;
        Certificate ce = null;
        if (kf.exists() && cf.exists()) {
            try (FileInputStream a = new FileInputStream(kf); FileInputStream b = new FileInputStream(cf)) {
                byte[] kb = new byte[(int) kf.length()];
                int off = 0;
                while (off < kb.length) {
                    int n = a.read(kb, off, kb.length - off);
                    if (n < 0) break;
                    off += n;
                }
                k = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(kb));
                ce = CertificateFactory.getInstance("X.509").generateCertificate(b);
            } catch (Exception e) {
                k = null;
                ce = null;
            }
        }
        if (k == null) {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            KeyPair kp = g.generateKeyPair();
            k = kp.getPrivate();
            X500Name name = new X500Name("CN=ZengYazici");
            Date from = new Date(System.currentTimeMillis() - 86400000L);
            Date to = new Date(System.currentTimeMillis() + 20L * 365 * 86400000L);
            JcaX509v3CertificateBuilder cb = new JcaX509v3CertificateBuilder(
                    name, BigInteger.valueOf(new Random().nextInt() & Integer.MAX_VALUE), from, to, name, kp.getPublic());
            ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").build(k);
            ce = new JcaX509CertificateConverter().getCertificate(cb.build(signer));
            try (FileOutputStream o = new FileOutputStream(kf); FileOutputStream o2 = new FileOutputStream(cf)) {
                o.write(k.getEncoded());
                o2.write(ce.getEncoded());
            }
        }
        key = k;
        cert = ce;
    }

    @Override
    public PrivateKey getPrivateKey() {
        return key;
    }

    @Override
    public Certificate getCertificate() {
        return cert;
    }

    @Override
    public String getDeviceName() {
        return "ZengYazici";
    }
}
