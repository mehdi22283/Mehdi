package az.wifiscan

import android.widget.*
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

fun pingPage(u: Ui): Page {
    val p = u.vbox()
    p.addView(u.tv("Ping", 22f, u.ACC, true))
    val host = u.edit("Host / IP", "8.8.8.8"); p.addView(host)
    val cur = u.tv("— ms", 34f, u.TXT, true).apply { gravity = android.view.Gravity.CENTER }
    val stats = u.tv("", 12f, u.SUB).apply { gravity = android.view.Gravity.CENTER }
    val chart = LineChartView(u.act, "ms", u.ACC)
    val log = u.tv("", 12f, u.TXT, false, true)
    val running = AtomicBoolean(false)
    val proc = AtomicReference<Process?>(null)
    lateinit var btn: Button

    fun start() {
        if (running.get()) { running.set(false); proc.get()?.destroy(); return }
        val h = host.text.toString().trim(); if (h.isEmpty()) return
        running.set(true); btn.text = "⏹ Dayandır"; log.text = ""; chart.clear(); cur.text = "…"
        Thread {
            val samples = ArrayList<Float>()
            var sent = 0; var lost = 0; var seq = 0
            val logLines = ArrayList<String>()
            while (running.get()) {
                val t0 = System.nanoTime()
                val out = try {
                    val pr = ProcessBuilder("/system/bin/ping", "-c", "1", "-W", "2", h).redirectErrorStream(true).start()
                    proc.set(pr)
                    val s = pr.inputStream.bufferedReader().readText(); pr.waitFor(); s
                } catch (e: Exception) { "" }
                if (!running.get()) break
                if (out.contains("unknown host", true) || out.contains("bad address", true)) {
                    u.post { cur.text = "❌"; stats.text = "Host tapılmadı: $h" }; break
                }
                val rtt = Regex("time[=<]([0-9.]+)").find(out)?.groupValues?.get(1)?.toFloatOrNull()
                sent++; seq++
                if (rtt == null) { lost++; samples.add(-1f); logLines.add("#$seq  ✖ cavab yoxdur") } else { samples.add(rtt); logLines.add("#$seq  %.1f ms".format(rtt)) }
                val ok = samples.filter { it >= 0 }
                val mn = ok.minOrNull(); val mx = ok.maxOrNull(); val avg = if (ok.isEmpty()) null else ok.average().toFloat()
                var jit = 0f
                if (ok.size > 1) { var s = 0f; for (i in 1 until ok.size) s += Math.abs(ok[i] - ok[i - 1]); jit = s / (ok.size - 1) }
                val shown = samples.takeLast(120)
                val txt = logLines.takeLast(8).joinToString("\n")
                u.post {
                    cur.text = if (rtt == null) "✖" else "%.1f ms".format(rtt)
                    stats.text = if (avg == null) "Göndərilən: $sent • İtki: 100%" else
                        "Göndərilən: $sent • İtki: ${lost * 100 / sent}%\nMin %.1f • Orta %.1f • Maks %.1f • Jitter %.1f ms".format(mn, avg, mx, jit)
                    chart.set(shown); log.text = txt
                }
                val el = (System.nanoTime() - t0) / 1_000_000
                if (el < 1000 && running.get()) try { Thread.sleep(1000 - el) } catch (e: InterruptedException) {}
            }
            running.set(false); proc.set(null)
            u.post { btn.text = "▶ Ping" }
        }.start()
    }

    btn = u.btn("▶ Ping") { start() }
    p.addView(btn); p.addView(cur); p.addView(stats)
    p.addView(chart, LinearLayout.LayoutParams(-1, u.dp(190)))
    p.addView(ScrollView(u.act).apply { addView(log) }, LinearLayout.LayoutParams(-1, 0, 1f))
    return Page(p, open = { h -> host.setText(h); if (!running.get()) start() })
}
