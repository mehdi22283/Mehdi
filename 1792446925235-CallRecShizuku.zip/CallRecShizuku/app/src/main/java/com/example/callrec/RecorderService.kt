package com.example.callrec

import android.app.*
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.*
import rikka.shizuku.Shizuku
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RecorderService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var am: AudioManager
    private lateinit var nm: NotificationManager
    private var recorder: IRecorder? = null
    private var recording = false
    private var binding = false
    private var fileName = ""

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, RecorderImpl::class.java.name))
            .daemon(false).processNameSuffix("rec").version(1)
    }
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            recorder = IRecorder.Stub.asInterface(b); binding = false
            idleNotif("Zəng yazıcı işləyir", "Shizuku bağlıdır • Telefon və WhatsApp izlənir")
        }
        override fun onServiceDisconnected(n: ComponentName?) {
            recorder = null; binding = false
            idleNotif("Zəng yazıcı işləyir", "Shizuku bağlantısı kəsildi, yenidən qoşulur…")
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            ensureBound()
            val mode = am.mode
            val active = mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION
            if (active && !recording) startRec(mode == AudioManager.MODE_IN_CALL)
            else if (!active && recording) stopRec()
            h.postDelayed(this, 700)
        }
    }

    private fun ensureBound() {
        if (recorder != null || binding) return
        if (!Shizuku.pingBinder() ||
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            idleNotif("Zəng yazıcı işləyir", "Shizuku işləmir və ya icazə yoxdur!"); return
        }
        binding = true
        try { Shizuku.bindUserService(args, conn) } catch (_: Throwable) { binding = false }
    }

    override fun onCreate() {
        super.onCreate()
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("idle", "Xidmət", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("rec", "Yazılma", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("done", "Yazıldı", NotificationManager.IMPORTANCE_HIGH))
        startForeground(1, buildIdle("Zəng yazıcı işləyir", "Başladılır…"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        h.post(poll)
    }

    private fun buildIdle(t: String, x: String) = Notification.Builder(this, "idle")
        .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle(t).setContentText(x)
        .setOngoing(true)
        .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE)).build()

    private fun idleNotif(t: String, x: String) = nm.notify(1, buildIdle(t, x))

    private fun startRec(phone: Boolean) {
        val src = if (phone) "Telefon" else "WhatsApp"
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        fileName = "${src}_$ts.m4a"
        val path = "/sdcard/Music/CallRec/$fileName"
        // telefon: VOICE_CALL(4) -> MIC(1) | VoIP: REMOTE_SUBMIX(8) -> VOICE_COMMUNICATION(7) -> MIC(1)
        val sources = if (phone) intArrayOf(4, 1) else intArrayOf(8, 7, 1)
        val ok = try { recorder?.start(path, sources) == true } catch (_: Throwable) { false }
        if (!ok) { idleNotif("Zəng yazıcı işləyir", "Yazı başlamadı (Shizuku/icazə yoxlayın)"); return }
        recording = true
        nm.notify(2, Notification.Builder(this, "rec")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("$src zəngi yazılır…").setContentText("Yazı davam edir")
            .setOngoing(true).setCategory(Notification.CATEGORY_CALL).build())
    }

    private fun stopRec() {
        try { recorder?.stop() } catch (_: Throwable) {}
        recording = false
        nm.cancel(2)
        nm.notify(System.currentTimeMillis().toInt(), Notification.Builder(this, "done")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Zəng yazıldı")
            .setContentText("Music/CallRec/$fileName").setAutoCancel(true).build())
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() {
        h.removeCallbacks(poll)
        if (recording) stopRec()
        try { Shizuku.unbindUserService(args, conn, true) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
