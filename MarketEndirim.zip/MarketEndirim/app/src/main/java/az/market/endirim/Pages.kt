package az.market.endirim

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.github.chrisbanes.photoview.PhotoView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class PageVH(val img: PhotoView, root: View = img) : RecyclerView.ViewHolder(root) {
    var job: Job? = null
    var tileJob: Job? = null
    var overlay: ImageView? = null
    var page = -1
}

private fun newPhotoView(parent: ViewGroup) = PhotoView(parent.context).apply {
    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    scaleType = ImageView.ScaleType.FIT_CENTER
    mediumScale = 3f
    maximumScale = 8f        // yaxınlaşdırma: PDF yüksək ölçüdə render olunur, ona görə böyüdəndə də aydın qalır
}

class ImageAdapter(private val urls: List<String>) : RecyclerView.Adapter<PageVH>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PageVH(newPhotoView(parent))
    override fun getItemCount() = urls.size
    override fun onBindViewHolder(holder: PageVH, position: Int) {
        holder.img.load(urls[position]) { crossfade(true) }
    }
}

/** PDF səhifələrini slayd kimi göstərir (PdfRenderer, səhifə-səhifə). */
class PdfAdapter(
    file: File, widthPx: Int, private val scope: CoroutineScope,
    cacheBytes: Int = (Runtime.getRuntime().maxMemory() / 6).toInt()
) : RecyclerView.Adapter<PageVH>() {

    companion object {
        private const val MAX_SIDE = 4096          // GPU tekstur limiti — bundan böyük bitmap çəkilməz
        private const val MAX_PIXELS = 16_000_000  // ≈ 64 MB / səhifə

        /** Tam ekran oxuyucu üçün maksimum keyfiyyət: ekran enindən 3 dəfə (1800–3200 px). */
        fun maxWidth(screenPx: Int): Int = (screenPx * 4f).toInt().coerceIn(2400, 4096)

        /** Siyahı daxilindəki kiçik oxuyucu üçün: ekran enindən 2 dəfə (yaddaş qənaəti). */
        fun inlineWidth(screenPx: Int): Int = (screenPx * 2.5f).toInt().coerceIn(1800, 2800)
    }

    private val widthPx = widthPx

    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    // keş bayt ilə ölçülür (böyük səhifələr üçün): ən azı 2 səhifə
    private val cache = object : LruCache<Int, Bitmap>(cacheBytes.coerceAtLeast(2 * 48 * 1024 * 1024).coerceAtMost((Runtime.getRuntime().maxMemory() / 2).toInt())) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.allocationByteCount
    }
    private var closed = false

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        val photo = newPhotoView(parent)
        val box = FrameLayout(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        box.addView(photo)
        val ov = ImageView(parent.context).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            visibility = View.GONE
            isClickable = false
        }
        box.addView(ov, FrameLayout.LayoutParams(1, 1))
        val vh = PageVH(photo, box)
        vh.overlay = ov
        // yaxınlaşdırma/sürüşdürmə bitəndə görünən hissə tam keyfiyyətdə yenidən render olunur
        photo.setOnMatrixChangeListener {
            ov.visibility = View.GONE
            vh.tileJob?.cancel()
            if (vh.page >= 0 && photo.scale > 1.15f) {
                vh.tileJob = scope.launch {
                    kotlinx.coroutines.delay(220)
                    renderTile(vh)
                }
            }
        }
        return vh
    }
    override fun getItemCount() = renderer.pageCount

    /** Görünən sahəni ekranın real piksel sıxlığında (bitmap-i böyütmədən) PDF-dən birbaşa render edir. */
    private suspend fun renderTile(vh: PageVH) {
        val photo = vh.img
        val ov = vh.overlay ?: return
        val pos = vh.page
        val disp: RectF = photo.displayRect ?: return
        val vw = photo.width.toFloat(); val vh2 = photo.height.toFloat()
        if (vw <= 0f || vh2 <= 0f || disp.width() <= 0f) return
        val vis = RectF(maxOf(0f, disp.left), maxOf(0f, disp.top), minOf(vw, disp.right), minOf(vh2, disp.bottom))
        if (vis.width() < 8f || vis.height() < 8f) return
        // görünən sahənin səhifədəki payı (0..1)
        val fl = (vis.left - disp.left) / disp.width();  val fr = (vis.right - disp.left) / disp.width()
        val ft = (vis.top - disp.top) / disp.height();   val fb = (vis.bottom - disp.top) / disp.height()
        var tw = vis.width().toInt(); var th = vis.height().toInt()
        val k = minOf(1f, MAX_SIDE.toFloat() / maxOf(tw, th), Math.sqrt(MAX_PIXELS.toDouble() / (tw.toDouble() * th)).toFloat())
        if (k < 1f) { tw = (tw * k).toInt(); th = (th * k).toInt() }
        val bmp = withContext(Dispatchers.IO) {
            synchronized(renderer) {
                if (closed) return@withContext null
                val page = renderer.openPage(pos)
                try {
                    val pw = page.width.toFloat(); val ph = page.height.toFloat()
                    val l = fl * pw; val t = ft * ph
                    val sx = tw / ((fr - fl) * pw); val sy = th / ((fb - ft) * ph)
                    val m = Matrix().apply { setScale(sx, sy); postTranslate(-l * sx, -t * sy) }
                    val b = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
                    b.eraseColor(Color.WHITE)
                    page.render(b, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    b
                } finally {
                    page.close()
                }
            }
        } ?: return
        // render zamanı səhifə dəyişibsə və ya yenidən yaxınlaşdırılıbsa nəticəni atırıq
        val now: RectF = photo.displayRect ?: return
        if (vh.page != pos || Math.abs(now.left - disp.left) > 1f || Math.abs(now.top - disp.top) > 1f || Math.abs(now.width() - disp.width()) > 1f) return
        ov.layoutParams = FrameLayout.LayoutParams(vis.width().toInt(), vis.height().toInt())
        ov.translationX = vis.left
        ov.translationY = vis.top
        ov.setImageBitmap(bmp)
        ov.visibility = View.VISIBLE
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        holder.job?.cancel()
        holder.tileJob?.cancel()
        holder.overlay?.visibility = View.GONE
        holder.page = position
        val cached = cache.get(position)
        if (cached != null) {
            holder.img.setImageBitmap(cached)
            return
        }
        holder.img.setImageDrawable(null)
        holder.job = scope.launch {
            val bmp = withContext(Dispatchers.IO) { render(position) } ?: return@launch
            cache.put(position, bmp)
            if (holder.bindingAdapterPosition == position) holder.img.setImageBitmap(bmp)
        }
    }

    override fun onViewRecycled(holder: PageVH) {
        holder.job?.cancel()
        holder.tileJob?.cancel()
        holder.overlay?.visibility = View.GONE
        holder.page = -1
    }

    private fun render(i: Int): Bitmap? = synchronized(renderer) {
        if (closed) return null
        val page = renderer.openPage(i)
        try {
            var w = widthPx
            var h = (w.toFloat() * page.height / page.width).toInt()
            // GPU limiti və yaddaş həddi: nisbət saxlanılaraq kiçildilir
            val k = minOf(1f, MAX_SIDE.toFloat() / maxOf(w, h), Math.sqrt(MAX_PIXELS.toDouble() / (w.toDouble() * h)).toFloat())
            if (k < 1f) { w = (w * k).toInt(); h = (h * k).toInt() }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp.setHasMipMap(true)   // kiçildərkən (tam görünüş) yazılar tutqun/dişli olmasın
            bmp
        } finally {
            page.close()
        }
    }

    fun close() {
        synchronized(renderer) {
            if (closed) return
            closed = true
            renderer.close()
            pfd.close()
        }
    }
}
