package az.mehdi.iptvplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * Loqo axtarışı:
 *  0) Offline keş: əvvəl endirilmiş loqo kanal adı ilə filesDir/logo_cache-də saxlanılır,
 *     növbəti açılışlarda internet olmadan birbaşa oradan göstərilir.
 *  1) Dropbox-dakı Logo.txt siyahısı (kanal adı -> loqo linki).
 *  2) Tapılmasa (və ya link işləməsə): https://iptv-org.github.io bazası.
 * Hər loqonun endirildiyi link də yadda saxlanılır (<ad>.url); link dəyişərsə açılışda yeni loqo
 * endirilib köhnənin yerinə yazılır.
 */
const val LOGO_LIST_URL = "https://dl.dropboxusercontent.com/scl/fi/um0ttg46rhklgmjeq5wia/Logo.txt?rlkey=he9qojtmtruggsuenwr72l12a"
private const val IPTV_ORG_CHANNELS = "https://iptv-org.github.io/api/channels.json"
private const val IPTV_ORG_LOGOS = "https://iptv-org.github.io/api/logos.json"

class LogoStore(private val ctx: Context, private val scope: CoroutineScope) {
    private val dir = File(ctx.filesDir, "logo_cache").apply { mkdirs() }
    private val failed = Collections.synchronizedSet(HashSet<String>())
    private val sem = Semaphore(4)
    private val locks = ConcurrentHashMap<String, Mutex>()
    // Loqo sayına görə deyil, bitmap yaddaş istifadəsinə görə keş limitlənir (təxminən 8 MiB).
    private val mem = object : LruCache<String, Bitmap>(8 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }
    private val listIndex = HashMap<String, String>()
    private val orgIndex = HashMap<String, String>()
    private val listJob: Job = scope.launch(Dispatchers.IO) { runCatching { buildList() } }
    // iptv-org bazası yalnız lazım olanda (Dropbox-da tapılmayanda) yüklənir
    private val orgJob: Job by lazy { scope.launch(Dispatchers.IO) { runCatching { buildOrgIndex() } } }

    init {
        // Əvvəlki versiyalardan qalan köhnə keşi təmizlə
        runCatching { File(ctx.filesDir, "logos").deleteRecursively() }
    }

    private fun norm(s: String): String {
        var t = s.lowercase().replace('ə', 'e').replace('ı', 'i')
        t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        t = t.replace(Regex("[\\[(].*?[\\])]"), " ")
        t = t.replace(Regex("\\b(hd|fhd|uhd|sd|4k|8k|hevc|h265|backup)\\b"), " ")
        return t.replace(Regex("[^a-z0-9]"), "")
    }

    private fun md5(s: String) = MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    /** Hər açılışda Dropbox-dakı Logo.txt yenilənir (alınmasa köhnə nüsxə qalır). */
    private fun buildList() {
        val f = File(ctx.filesDir, "logo_list.txt")
        val fresh = File(ctx.filesDir, "logo_list.new")
        runCatching {
            fetchToFile(LOGO_LIST_URL, fresh, 20000)
            if (fresh.readText().contains("#EXTINF")) { if (f.exists()) f.delete(); fresh.renameTo(f) } else fresh.delete()
        }
        if (!f.exists()) return
        val items = parsePlaylist(f.readText())
        synchronized(listIndex) {
            for (c in items) {
                val u = c.logo ?: c.url
                val k = norm(c.name)
                if (k.isNotEmpty() && u.startsWith("http")) listIndex.putIfAbsent(k, u)
            }
        }
    }

    /** iptv-org: ad -> loqo cədvəli diskdə (logo_index.tsv) saxlanılır, 1 gündən köhnədirsə açılışda yenilənir. */
    private fun buildOrgIndex() {
        val tsv = File(ctx.filesDir, "logo_index.tsv")
        val fresh = tsv.exists() && System.currentTimeMillis() - tsv.lastModified() < 24L * 3600 * 1000
        if (!fresh) runCatching {
            val ch = File(ctx.filesDir, "channels.json")
            val lg = File(ctx.filesDir, "logos.json")
            fetchToFile(IPTV_ORG_CHANNELS, ch, 30000)
            fetchToFile(IPTV_ORG_LOGOS, lg, 30000)
            val urls = HashMap<String, String>()
            val la = JSONArray(lg.readText())
            for (i in 0 until la.length()) {
                val o = la.getJSONObject(i)
                val id = o.optString("channel")
                val u = o.optString("url")
                if (id.isNotEmpty() && u.startsWith("http") && !urls.containsKey(id)) urls[id] = u
            }
            val sb = StringBuilder()
            val ca = JSONArray(ch.readText())
            for (i in 0 until ca.length()) {
                val o = ca.getJSONObject(i)
                val u = urls[o.optString("id")] ?: continue
                sb.append(norm(o.optString("name"))).append('\t').append(u).append('\n')
                val alt = o.optJSONArray("alt_names")
                if (alt != null) for (j in 0 until alt.length()) sb.append(norm(alt.getString(j))).append('\t').append(u).append('\n')
            }
            tsv.writeText(sb.toString())
            ch.delete(); lg.delete()
        }
        if (tsv.exists()) synchronized(orgIndex) {
            tsv.forEachLine { l ->
                val p = l.split('\t')
                if (p.size == 2 && p[0].isNotEmpty()) orgIndex.putIfAbsent(p[0], p[1])
            }
        }
    }

    private fun lookupIn(map: HashMap<String, String>, name: String): String? {
        val n = norm(name)
        if (n.isEmpty()) return null
        return synchronized(map) { map[n] ?: map[n.removeSuffix("tv")] ?: map[n + "tv"] }
    }

    private fun decode(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0) return null
        var s = 1
        val maxDimension = maxOf(o.outWidth, o.outHeight)
        while (maxDimension / s > 256) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    /** Loqonu endirib kanal adı ilə offline keşə yazır. Uğurlu olarsa bitmap qaytarır. */
    private suspend fun downloadTo(u: String, f: File): Bitmap? {
        val tmp = File(dir, f.name + ".dl")
        try {
            sem.withPermit { withContext(Dispatchers.IO) { fetchToFile(u, tmp, 10000) } }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            tmp.delete()
            return null
        }
        return withContext(Dispatchers.IO) {
            val bmp = decode(tmp)
            if (bmp != null) { if (f.exists()) f.delete(); tmp.renameTo(f) } else tmp.delete()
            bmp
        }
    }

    private fun fileFor(key: String) = File(dir, md5(key) + ".img")
    private fun urlFileFor(key: String) = File(dir, md5(key) + ".url")

    /**
     * Kanalın cari loqo linkini tapır (Dropbox -> iptv-org) və endirilmiş linklə müqayisə edir.
     * Loqo yoxdursa və ya link dəyişibsə yenisini endirib əvəz edir. Yeni endirmə olubsa true qaytarır.
     * Endirmə alınmasa köhnə loqo toxunulmaz qalır.
     */
    private suspend fun refreshOne(key: String, name: String): Boolean {
        val file = fileFor(key)
        val urlFile = urlFileFor(key)
        val have = file.exists() && file.length() > 0L
        val stored = runCatching { urlFile.readText().trim() }.getOrNull()

        suspend fun download(u: String): Boolean {
            val bmp = downloadTo(u, file) ?: return false
            runCatching { urlFile.writeText(u) }
            mem.put(key, bmp)
            return true
        }

        listJob.join()
        val d = lookupIn(listIndex, name)
        if (d != null) {
            if (have && stored == d) return false // link dəyişməyib
            if (download(d)) return true
        }
        orgJob.join()
        val o = lookupIn(orgIndex, name)
        if (o != null) {
            if (have && stored == o) return false
            if (download(o)) return true
        }
        return false
    }

    suspend fun bitmapFor(ch: Channel): Bitmap? {
        val key = norm(ch.name)
        if (key.isEmpty()) return null
        mem.get(key)?.let { return it }

        // 0) Offline keş (internet və siyahı lazım deyil)
        val file = fileFor(key)
        if (file.exists() && file.length() > 0L) {
            val b = withContext(Dispatchers.IO) { decode(file) }
            if (b != null) { mem.put(key, b); return b }
            file.delete() // zədəli fayl
        }
        if (failed.contains(key)) return null

        // 1) Dropbox Logo.txt, 2) ehtiyat: iptv-org.github.io
        locks.computeIfAbsent(key) { Mutex() }.withLock {
            mem.get(key)?.let { return it }
            if (refreshOne(key, ch.name)) mem.get(key)?.let { return it }
        }
        failed.add(key) // yalnız bu sessiya üçün; növbəti açılışda yenidən cəhd olunur
        return null
    }

    /**
     * Açılışda çağırılır, hər kanal üçün:
     *  - loqosu offline yaddaşda yoxdursa, yenidən axtarıb endirir;
     *  - loqo linki dəyişibsə (Logo.txt-də və ya iptv-org-da), yeni loqonu endirib köhnənin yerinə yazır.
     * Əvvəlki "tapılmadı" nəticələri sıfırlanır. Yenilənən/yeni tapılan loqoların sayını qaytarır.
     */
    suspend fun refreshAll(channels: List<Channel>): Int {
        failed.clear()
        val seen = HashSet<String>()
        val todo = channels.mapNotNull { ch -> norm(ch.name).takeIf { it.isNotEmpty() && seen.add(it) }?.let { it to ch.name } }
        if (todo.isEmpty()) return 0
        return coroutineScope {
            // Yüzlərlə/minlərlə async iş açmaq əvəzinə ən çox 4 worker istifadə et.
            val workerCount = minOf(4, todo.size)
            val chunkSize = (todo.size + workerCount - 1) / workerCount
            todo.chunked(chunkSize).map { batch ->
                async {
                    var updated = 0
                    for ((key, name) in batch) {
                        updated += if (locks.computeIfAbsent(key) { Mutex() }.withLock { refreshOne(key, name) }) 1 else 0
                    }
                    updated
                }
            }.awaitAll().sum()
        }
    }
}
