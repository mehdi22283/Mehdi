package com.mehdi.keymapper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val s = Intent(context, KeepAliveService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(s) else context.startService(s)
        } catch (e: Exception) {
        }
    }
}
