package az.market.endirim

import android.content.Context
import android.content.SharedPreferences
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Market logoları və başlıq rəngləri OFFLINE işləyir:
 *  1) res/drawable-nodpi/logo_<market>.png varsa — tətbiqin içindən (məs. Rahat) göstərilir;
 *  2) yoxsa bir dəfə yüklənib filesDir/logos-a yazılır və sonra həmişə oradan oxunur;
 *  3) başlıq rəngi sabit (Rahat) və ya logodan oxunub SharedPreferences-də saxlanır.
 */
object Brand {
    /** Logo rəngi hələ oxunmayıbsa göstərilən neytral rəng. */
    val FALLBACK: Int = 0xFF455A64.toInt()

    val logos = mapOf(
        "Bravo Market" to "https://bravosupermarket.az/site/templates/img/newLogo.png",
        "Araz Market" to "https://www.arazmarket.az/_next/static/media/logo.42b6a354.svg",
        "Al Market" to "https://almarket.az/assets/img/icons/logo.svg",
        "Rahat Market" to "https://rahatmarket.az/images/s_logo.svg",
        "Tamstore" to "https://www.tamstore.az/uploads/1703078675-6582eb13d78b9.png"
    )

    /** Sosial şəbəkə hesabları: Instagram istifadəçi adı və WhatsApp kanal linki. */
    class Social(val instagram: String?, val whatsapp: String?)

    val socials = mapOf(
        "Bravo Market" to Social("bravosupermarketaz", "https://whatsapp.com/channel/0029VaCi0unC6ZvgBI6aST3a"),
        "Araz Market" to Social("arazsupermarket", "https://whatsapp.com/channel/0029Vb4aNvQCXC3SGV4P852T"),
        "Al Market" to Social("almarketler", "https://whatsapp.com/channel/0029VahpDbL6mYPIRTMZ8q1i"),
        "Rahat Market" to Social("rahatmarket.az", "https://whatsapp.com/channel/0029Vb88gId1iUxa3Y8u9M3i"),
        "Bolmart" to Social("bolmart.supermarket", "https://whatsapp.com/channel/0029VaCaaDHA2pLJ38bAo80n")
    )

    /** Rəngi əvvəlcədən məlum olan marketlər (logodan götürülüb). */
    private val fixedColors = mapOf(
        "Rahat Market" to 0xFFED1B24.toInt()
    )

    /** Logodan oxunmuş rənglər (yaddaşda da saxlanır) */
    val colors = HashMap<String, Int>()

    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        if (::prefs.isInitialized) return
        prefs = ctx.applicationContext.getSharedPreferences("brand", Context.MODE_PRIVATE)
        for (m in logos.keys) if (prefs.contains(m)) colors[m] = prefs.getInt(m, FALLBACK)
    }

    fun colorOf(market: String): Int = fixedColors[market] ?: colors[market] ?: FALLBACK
    fun hasColor(market: String): Boolean = fixedColors.containsKey(market) || colors.containsKey(market)

    fun saveColor(market: String, color: Int) {
        colors[market] = color
        if (::prefs.isInitialized) prefs.edit().putInt(market, color).apply()
    }

    private fun slug(market: String) = market.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')

    /** Tətbiqə daxil edilmiş logo (drawable) — yoxdursa 0. */
    fun bundledRes(ctx: Context, market: String): Int =
        ctx.resources.getIdentifier("logo_" + slug(market), "drawable", ctx.packageName)

    private fun logoFile(ctx: Context, market: String) =
        File(File(ctx.filesDir, "logos").apply { mkdirs() }, slug(market) + ".img")

    /** Yaddaşa yazılmış logo (varsa). */
    fun cachedFile(ctx: Context, market: String): File? =
        logoFile(ctx, market).takeIf { it.exists() && it.length() > 0 }

    /** Logonu bir dəfə endirib yaddaşa yazır; artıq varsa və ya tətbiqin içindədirsə heç nə etmir. */
    suspend fun ensureLogo(ctx: Context, market: String) = withContext(Dispatchers.IO) {
        if (bundledRes(ctx, market) != 0) return@withContext
        if (cachedFile(ctx, market) != null) return@withContext
        val url = logos[market] ?: return@withContext
        val f = logoFile(ctx, market)
        val tmp = File(f.path + ".part")
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13)")
            try {
                if (c.responseCode !in 200..299) return@withContext
                c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            } finally {
                c.disconnect()
            }
            if (tmp.length() > 0) tmp.renameTo(f) else tmp.delete()
        } catch (e: Exception) {
            tmp.delete()
        }
    }

    fun pick(p: Palette?): Int? {
        val c = p?.vibrantSwatch?.rgb ?: p?.dominantSwatch?.rgb ?: return null
        return if (ColorUtils.calculateLuminance(c) > 0.9) null else c
    }
}
