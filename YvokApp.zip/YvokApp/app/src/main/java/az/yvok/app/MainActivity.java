package az.yvok.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.Iterator;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String EBEL_URL = "https://e-belediyye.gov.az/tax-debts";
    private static final Pattern CODE = Pattern.compile("^10011[A-Z0-9]{7}$");
    private static final Pattern NAME_OK = Pattern.compile("^[\\p{L}\\s.'\\-]{3,100}$");
    private static final Pattern DEBT_OK = Pattern.compile("^(\\d{1,9}(\\.\\d{1,2})?)?$");
    private static final int REQ_OCR = 7001;
    // OCR səhvlərinə tolerant: 1/I/L/| və 0/O/Q/D qarışıqlığı yalnız "10011" prefiksində düzəldilir
    private static final Pattern OCR_CODE = Pattern.compile("[1IL|][0OQD][0OQD][1IL|][1IL|]([A-Z0-9]{7})");
    private static final int MIN_WORKERS = 4;
    private static final int TOP_WORKERS = 50;  // əvvəlcədən qızdırılan hazır gizli səhifələrin yuxarı həddi
    private int maxWorkers = MIN_WORKERS;      // cihazın yaddaşına görə onCreate-də hesablanır
    private boolean warming = false;

    private static class Job {
        final String code;
        final boolean batch;
        int attempts = 0;
        Job(String code, boolean batch) { this.code = code; this.batch = batch; }
    }

    // Hər Worker = e-belediyye.gov.az açıq olan bir gizli WebView (ui-nin ARXASINDA işləyir)
    private class Worker {
        final WebView wv;
        final boolean batch;
        boolean loaded = false;
        String pending = null;
        Job current = null;
        final Runnable watchdog = () -> onWatchdog(this);
        Worker(WebView wv, boolean batch) { this.wv = wv; this.batch = batch; }
    }

    private FrameLayout root;
    private WebView ui;
    private String injectJs;
    private Worker single;                                   // yalnız YVÖK xanası (mesaj göndərmə) üçün
    private final ArrayList<Worker> pool = new ArrayList<>(); // yalnız toplu yoxlama üçün
    private final ArrayDeque<Job> batchJobs = new ArrayDeque<>();
    private Uri cameraUri = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        injectJs = readAsset("inject.js");
        clearOcrCache();                      // əvvəlki sessiyadan qalan kamera şəkilləri
        maxWorkers = computeMaxWorkers();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ui = new WebView(this);
        ui.setBackgroundColor(Color.BLACK);
        ui.setFocusable(true);
        ui.setFocusableInTouchMode(true);
        root.addView(ui, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        setupCommon(ui);

        // ---- Yuxarı: öz səhifəmiz (assets/index.html) ----
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        ui.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                ui.requestFocus();
                ui.evaluateJavascript("document.getElementById('phone-input').focus();", null);
                ui.postDelayed(() -> {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(ui, InputMethodManager.SHOW_IMPLICIT);
                }, 350);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {                                   // whatsapp:// və xarici linklər
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Tətbiq tapılmadı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        ui.addJavascriptInterface(new Object() {
            // YVÖK xanası (mesaj göndərmə): yalnız öz gizli səhifəsini sıfırlayır
            @JavascriptInterface
            public void reset() {
                runOnUiThread(() -> freshSingle(true));
            }

            @JavascriptInterface
            public void fill(String code) {
                final String v = "10011" + (code == null ? "" : code.toUpperCase());
                if (!CODE.matcher(v).matches()) return;
                runOnUiThread(() -> {
                    // Səhifə əvvəlki istifadədən sonra ARXA FONDA artıq təzələnib və hazırdır:
                    // birbaşa istifadə olunur (gözləmə yoxdur). Yalnız yarımçıq sorğu varsa yenidən yüklənir.
                    if (single.current != null) recycle(single);
                    status("loading");
                    start(single, new Job(v, false));
                });
            }

            // Toplu yoxlama səhifələrini əvvəlcədən hazırla (mətn qutusuna toxunanda)
            @JavascriptInterface
            public void warm() {
                runOnUiThread(() -> warmUp());
            }

            // Toplu yoxlama: vergüllə ayrılmış tam kodlar (10011XXXXXXX)
            @JavascriptInterface
            public void batch(String csv) {
                if (csv == null) return;
                final String[] parts = csv.split(",");
                runOnUiThread(() -> {
                    for (String c : parts) {
                        c = c.trim().toUpperCase();
                        if (!CODE.matcher(c).matches()) continue;
                        boolean dup = false;
                        for (Worker w : pool) {
                            if (w.current != null && w.current.code.equals(c)) { dup = true; break; }
                        }
                        if (!dup) for (Job j : batchJobs) if (j.code.equals(c)) { dup = true; break; }
                        if (!dup) batchJobs.addLast(new Job(c, true));
                    }
                    pumpBatch();
                });
            }

            // Şəkildən kod oxu: kamera və ya qalereya
            @JavascriptInterface
            public void ocr() {
                runOnUiThread(() -> openOcrChooser());
            }

            @JavascriptInterface
            public void batchStop() {
                runOnUiThread(() -> {
                    batchJobs.clear();
                    for (Worker w : pool) if (w.current != null) recycle(w);
                });
            }
        }, "Android");
        ui.loadUrl("https://" + HOST + "/assets/index.html");

        // ---- Aşağı: e-belediyye.gov.az (gizli WebView-lar) ----
        single = createWorker(false);
        root.postDelayed(this::warmUp, 1500);   // toplu yoxlama üçün hazır səhifələri əvvəlcədən qızdır
    }

    // ---------------- OCR ----------------
    private void openOcrChooser() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        Intent chooser = Intent.createChooser(pick, "Şəkil seçin");
        cameraUri = null;
        try {
            File dir = new File(getCacheDir(), "ocr");
            dir.mkdirs();
            File f = new File(dir, "cam_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("", cameraUri));
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        } catch (Exception e) {
            cameraUri = null;   // kamera olmasa yalnız qalereya
        }
        try {
            startActivityForResult(chooser, REQ_OCR);
        } catch (Exception e) {
            toast("Şəkil seçmək mümkün olmadı");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_OCR) return;
        if (res != RESULT_OK) { clearOcrCache(); return; }
        ArrayList<Uri> uris = new ArrayList<>();
        if (data != null && data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) uris.add(u);
            }
        } else if (data != null && data.getData() != null) {
            uris.add(data.getData());
        } else if (cameraUri != null) {
            uris.add(cameraUri);      // kamera çəkilişi
        }
        if (uris.isEmpty()) return;
        runOcr(uris);
    }

    // Şəkillər PARALEL oxunur (sürət üçün), amma nəticələr seçilmə sırasına görə birləşdirilir
    private void runOcr(ArrayList<Uri> uris) {
        toast("Şəkil oxunur…");
        final TextRecognizer rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        final int n = uris.size();
        final Text[] results = new Text[n];
        final int[] left = {n};
        for (int i = 0; i < n; i++) {
            final int idx = i;
            try {
                InputImage img = InputImage.fromFilePath(this, uris.get(i));
                rec.process(img)
                        .addOnSuccessListener(t -> { results[idx] = t; ocrOneDone(rec, results, left); })
                        .addOnFailureListener(e -> ocrOneDone(rec, results, left));
            } catch (Exception e) {
                ocrOneDone(rec, results, left);
            }
        }
    }

    private void ocrOneDone(TextRecognizer rec, Text[] results, int[] left) {
        if (--left[0] > 0) return;
        LinkedHashSet<String> found = new LinkedHashSet<>();
        for (Text t : results) collectCodes(t, found);   // indeks sırası = seçilmə sırası
        ocrFinish(rec, found);
    }

    // Kameradan çəkilən müvəqqəti şəkillər (cache/ocr) oxunandan sonra silinir.
    // Qalereyadan seçilən şəkillərə toxunulmur.
    private void clearOcrCache() {
        try {
            File[] fs = new File(getCacheDir(), "ocr").listFiles();
            if (fs != null) for (File f : fs) f.delete();
        } catch (Exception ignored) { }
        cameraUri = null;
    }

    // İş bitəndən sonra səhifəni arxa fonda hazırla: YVÖK xanası üçün tam təzə səhifə (köhnə yaddaş silinir),
    // toplu yoxlama üçün təzədən yükləmə
    private void renew(Worker w) {
        if (w == single) freshSingle(false); else recycle(w);
    }

    // YVÖK xanası üçün gizli səhifəni tam sıfırla: köhnə səhifə məhv edilir (keş, tarixçə, formlar,
    // gözləyən sorğu, gec gələn nəticə), yerinə təzə səhifə açılır.
    private void freshSingle(boolean wipeStorage) {
        if (single != null) {
            single.current = null;            // köhnə nəticə gec gəlsə nəzərə alınmasın
            single.pending = null;
            single.wv.removeCallbacks(single.watchdog);
            try {
                single.wv.stopLoading();
                single.wv.loadUrl("about:blank");
                single.wv.clearHistory();
                if (wipeStorage) single.wv.clearCache(true);
                single.wv.clearFormData();
                single.wv.removeJavascriptInterface("AndroidEbel");
                root.removeView(single.wv);
                single.wv.destroy();
            } catch (Exception ignored) { }
        }
        if (wipeStorage) {
            try { WebStorage.getInstance().deleteAllData(); } catch (Exception ignored) { }
        }
        single = createWorker(false);
    }

    // Cihazın yaddaşına görə neçə səhifəni əvvəlcədən qızdırmaq olar (ən çox 50)
    private int computeMaxWorkers() {
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null || am.isLowRamDevice()) return MIN_WORKERS;
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long totalMb = mi.totalMem / (1024 * 1024);
            int n = (int) (totalMb * 0.35 / 80);   // RAM-ın ~35%-i, hər səhifə ~80 MB
            return Math.max(MIN_WORKERS, Math.min(TOP_WORKERS, n));
        } catch (Exception e) {
            return MIN_WORKERS;
        }
    }

    // Hazır səhifələri bir-bir (aralıqla) yarat ki, telefon donmasın və sayt eyni anda boğulmasın
    private void warmUp() {
        if (warming) return;
        warming = true;
        warmStep();
    }

    private void warmStep() {
        if (isFinishing() || pool.size() >= maxWorkers) { warming = false; return; }
        createWorker(true);
        root.postDelayed(this::warmStep, 120);
    }

    // Yaddaş azalanda artıq səhifələri azalt ki, tətbiq çökməsin
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level < TRIM_MEMORY_RUNNING_LOW) return;
        maxWorkers = Math.max(MIN_WORKERS, pool.size() / 2);
        for (int i = pool.size() - 1; i >= 0 && pool.size() > maxWorkers; i--) {
            Worker w = pool.get(i);
            if (w.current != null) continue;
            destroyWorker(w);
            pool.remove(i);
        }
    }

    private void destroyWorker(Worker w) {
        w.current = null;                 // gec gələn köhnə nəticələr nəzərə alınmasın
        w.pending = null;
        w.wv.removeCallbacks(w.watchdog);
        try {
            w.wv.stopLoading();
            w.wv.loadUrl("about:blank");
            w.wv.clearHistory();
            w.wv.clearFormData();
            w.wv.removeJavascriptInterface("AndroidEbel");
            root.removeView(w.wv);
            w.wv.destroy();
        } catch (Exception ignored) { }
    }

    // Yeni şəkildən sonra: gözləyən işlər ləğv olunur, istifadə olunmuş (işləyən) səhifələr məhv edilir.
    // İstifadə olunmamış hazır səhifələr SAXLANILIR (artıq yüklənib və təmizdir), çatışmayanlar arxa fonda əlavə olunur.
    private void resetBatchEngine() {
        batchJobs.clear();
        for (int i = pool.size() - 1; i >= 0; i--) {
            Worker w = pool.get(i);
            if (w.current != null) {
                destroyWorker(w);
                pool.remove(i);
            }
        }
        warmUp();
    }

    private void ocrFinish(TextRecognizer rec, LinkedHashSet<String> found) {
        rec.close();
        clearOcrCache();
        if (found.isEmpty()) {
            toast("Şəkildə kod tapılmadı");
            return;
        }
        resetBatchEngine();   // köhnədən qalan hər şeyi sil, təmiz başla
        ui.evaluateJavascript("window.addOcrCodes(" + JSONObject.quote(String.join("\n", found)) + ");", null);
    }

    // ML Kit blokları öz "ağlına" görə düzür (sütun-sütun, qarışıq). Ona görə bütün sətirləri
    // götürüb şəkildəki mövqeyinə görə düzürük: yuxarıdan aşağı, eyni cərgədə soldan sağa.
    private void collectCodes(Text t, LinkedHashSet<String> out) {
        if (t == null) return;
        ArrayList<Text.Line> lines = new ArrayList<>();
        for (Text.TextBlock b : t.getTextBlocks()) lines.addAll(b.getLines());

        final Comparator<Text.Line> byY = (x, y) -> Float.compare(centerY(x), centerY(y));
        Collections.sort(lines, byY);

        ArrayList<ArrayList<Text.Line>> rows = new ArrayList<>();
        float rowY = 0, rowH = 0;
        for (Text.Line ln : lines) {
            Rect r = ln.getBoundingBox();
            float h = r == null ? 1 : Math.max(1, r.height());
            float cy = centerY(ln);
            if (!rows.isEmpty() && Math.abs(cy - rowY) < 0.5f * Math.max(rowH, h)) {
                ArrayList<Text.Line> row = rows.get(rows.size() - 1);
                row.add(ln);
                rowY = (rowY * (row.size() - 1) + cy) / row.size();   // cərgənin orta mövqeyi
            } else {
                ArrayList<Text.Line> row = new ArrayList<>();
                row.add(ln);
                rows.add(row);
                rowY = cy;
                rowH = h;
            }
        }
        for (ArrayList<Text.Line> row : rows) {
            Collections.sort(row, (x, y) -> Integer.compare(left(x), left(y)));
            for (Text.Line ln : row) {
                String line = ln.getText().toUpperCase();
                int before = out.size();
                addMatches(line, out);
                if (out.size() == before) addMatches(line.replaceAll("\\s+", ""), out);
            }
        }
    }

    private static float centerY(Text.Line l) {
        Rect r = l.getBoundingBox();
        return r == null ? 0 : r.centerY();
    }

    private static int left(Text.Line l) {
        Rect r = l.getBoundingBox();
        return r == null ? 0 : r.left;
    }

    private void addMatches(String s, LinkedHashSet<String> out) {
        java.util.regex.Matcher m = OCR_CODE.matcher(s);
        while (m.find()) out.add("10011" + m.group(1));
    }

    private Worker createWorker(boolean batch) {
        final WebView wv = new WebView(this);
        wv.setBackgroundColor(Color.WHITE);
        wv.setFocusable(false);                       // klaviaturanı/fokusu oğurlamasın
        wv.setFocusableInTouchMode(false);
        // ui-nin ARXASINA (index 0) əlavə olunur: tam ölçüdə layout alır, amma görünmür
        root.addView(wv, 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setupCommon(wv);
        final Worker w = new Worker(wv, batch);
        if (batch) pool.add(w);
        wv.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void result(final String code, final String name, final String debt) {
                runOnUiThread(() -> onEbelResult(w, code, name, debt));
            }

            @JavascriptInterface
            public void fail(final String code, final String reason) {
                runOnUiThread(() -> onEbelFail(w, code, reason));
            }
        }, "AndroidEbel");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                w.loaded = true;
                if (w.pending != null) {
                    String p = w.pending;
                    w.pending = null;
                    runFill(w, p);
                }
            }
        });
        wv.loadUrl(EBEL_URL);
        return w;
    }

    // Səhifəni təzədən yüklə: hər kod TƏMİZ səhifədə yoxlanılır, əvvəlki sorğunun vəziyyəti qalmır
    private void recycle(Worker w) {
        w.wv.removeCallbacks(w.watchdog);
        w.current = null;
        w.pending = null;
        w.loaded = false;
        w.wv.stopLoading();
        w.wv.loadUrl(EBEL_URL);
    }

    private void start(Worker w, Job j) {
        w.current = j;
        w.wv.removeCallbacks(w.watchdog);
        w.wv.postDelayed(w.watchdog, 45000);
        if (w.loaded) runFill(w, j.code); else w.pending = j.code;
    }

    private Worker pickBatchWorker() {
        for (Worker w : pool) if (w.current == null && w.loaded) return w;
        for (Worker w : pool) if (w.current == null) return w;
        if (pool.size() < maxWorkers) return createWorker(true);
        return null;
    }

    private void pumpBatch() {
        while (!batchJobs.isEmpty()) {
            Worker w = pickBatchWorker();
            if (w == null) return;
            start(w, batchJobs.pollFirst());
        }
    }

    private void runFill(Worker w, String value) {
        w.wv.evaluateJavascript(injectJs + ";window.__yvokRun('" + value + "');", null);
    }

    private void onEbelResult(Worker w, String code, String name, String debt) {
        Job j = w.current;
        if (j == null || code == null || !j.code.equals(code)) return;   // köhnə/yad nəticə
        final String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        final String d = debt == null ? "" : debt.trim();
        if (j.batch) renew(w);   // YVÖK xanasında əvvəl nəticə yazılır, səhifə yenilənməsi sonra
        if (!NAME_OK.matcher(n).matches() || !DEBT_OK.matcher(d).matches()) {
            failJob(j, "Məlumat formatı tanınmadı");
        } else if (j.batch) {
            ui.evaluateJavascript("window.setBatchResult(" + JSONObject.quote(j.code) + ","
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
        } else {
            ui.evaluateJavascript("window.setEbelStatus('ok');window.setEbelResult("
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
            if (d.isEmpty()) toast("Borc məbləği tapılmadı");
        }
        if (j.batch) pumpBatch(); else renewLater(w, j);
    }

    private void onEbelFail(Worker w, String code, String reason) {
        Job j = w.current;
        if (j == null || (code != null && !j.code.equals(code))) return;
        handleFail(w, j, reason == null || reason.length() > 80 ? "Məlumat tapılmadı" : reason);
    }

    private void onWatchdog(Worker w) {
        Job j = w.current;
        if (j == null) return;
        handleFail(w, j, "Sayt cavab vermədi");
    }

    private void handleFail(Worker w, Job j, String msg) {
        if (j.batch) renew(w);
        if (j.batch && j.attempts < 1) {      // toplu sorğuya bir dəfə təkrar şans ver
            j.attempts++;
            batchJobs.addLast(j);
        } else {
            failJob(j, msg);
        }
        if (j.batch) pumpBatch(); else renewLater(w, j);
    }

    // Nəticə ekrana göndərildikdən SONRA (ağır WebView yaratma/silmə nəticəni gecikdirməsin deyə)
    private void renewLater(final Worker w, final Job j) {
        w.wv.removeCallbacks(w.watchdog);
        ui.post(() -> { if (w == single && w.current == j) renew(w); });
    }

    private void failJob(Job j, String msg) {
        if (j.batch) {
            ui.evaluateJavascript("window.setBatchFail(" + JSONObject.quote(j.code) + ","
                    + JSONObject.quote(msg) + ");", null);
        } else {
            status("fail");
            toast(msg);
        }
    }

    private void setupCommon(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("OK", (d, x) -> res.confirm())
                        .setOnCancelListener(d -> res.confirm()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("Bəli", (d, x) -> res.confirm())
                        .setNegativeButton("Xeyr", (d, x) -> res.cancel())
                        .setOnCancelListener(d -> res.cancel()).show();
                return true;
            }
        });
    }

    private void status(final String st) {
        runOnUiThread(() -> ui.evaluateJavascript("window.setEbelStatus('" + st + "');", null));
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
