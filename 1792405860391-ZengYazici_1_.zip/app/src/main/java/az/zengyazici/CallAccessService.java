package az.zengyazici;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/** Boş əlçatanlıq xidməti: Android 10+ cihazlarda mikrofonun fonda yazıya icazə verməsi üçün. */
public class CallAccessService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }
}
