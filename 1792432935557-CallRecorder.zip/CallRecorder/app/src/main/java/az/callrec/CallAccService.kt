package az.callrec

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class CallAccService : AccessibilityService() {
    private var incomingHint = false
    private var started = false

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.packageName?.toString() != "com.whatsapp") return
        if (e.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val t = e.text.joinToString(" ").lowercase()
            if (t.contains("incoming") || t.contains("gələn") || t.contains("gelen") || t.contains("входящ")) incomingHint = true
        } else if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val cls = e.className?.toString() ?: ""
            if (cls.contains("Voip", true) && !started) {
                started = true
                RecorderService.inst?.startRec("WhatsApp", if (incomingHint) "in" else "out", readName())
                incomingHint = false
            } else if (!cls.contains("Voip", true) && cls.isNotEmpty()) {
                started = false
            }
        }
    }

    private fun readName(): String {
        val root = rootInActiveWindow ?: return "WhatsApp"
        val texts = ArrayList<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            n.text?.toString()?.trim()?.let { if (it.length > 1) texts.add(it) }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return texts.firstOrNull { !it.matches(Regex("[0-9:]+")) && !it.contains("WhatsApp", true) && !it.contains("zəng", true) && !it.contains("call", true) } ?: "WhatsApp"
    }

    override fun onInterrupt() {}
}
