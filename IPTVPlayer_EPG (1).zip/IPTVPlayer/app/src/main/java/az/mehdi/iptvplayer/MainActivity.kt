package az.mehdi.iptvplayer

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.SurfaceView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File

class ChannelAdapter(
    private val logos: LogoStore,
    private val epg: EpgStore,
    private val scope: CoroutineScope,
    private val layoutRes: Int = R.layout.item_channel,
    private val resLabel: () -> String? = { null },
    private val onFocusCh: ((Channel) -> Unit)? = null,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    var items: List<Channel> = emptyList()
    var playingUrl: String? = null

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val logo: ImageView = v.findViewById(R.id.logo)
        val name: TextView = v.findViewById(R.id.name)
        val epgTv: TextView = v.findViewById(R.id.epg)
        val bar: ProgressBar? = v.findViewById(R.id.epgBar)
        var job: Job? = null
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(layoutRes, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val ch = items[pos]
        h.job?.cancel()
        h.name.text = "${ch.number}. ${ch.name}"
        h.logo.setImageDrawable(null)
        val playing = ch.url == playingUrl
        h.itemView.isActivated = playing
        h.itemView.setOnClickListener { onClick(ch) }
        h.itemView.setOnFocusChangeListener { _, has -> if (has) onFocusCh?.invoke(ch) }

        // Kanal adının altında EPG: indi gedən proqram + resolution (yalnız oynayan kanal üçün məlum)
        val now = epg.nowNext(ch).first
        val sb = StringBuilder()
        if (playing) resLabel()?.let { sb.append("[").append(it).append("]  ") }
        if (now != null) sb.append(hm(now.start)).append("  ").append(now.title)
        h.epgTv.text = sb
        val invisible = if (layoutRes == R.layout.item_channel) View.INVISIBLE else View.GONE
        h.epgTv.visibility = if (sb.isEmpty()) invisible else View.VISIBLE
        h.bar?.let { b ->
            if (now != null && now.stop > now.start) {
                val t = System.currentTimeMillis() / 1000
                b.progress = (((t - now.start) * 100) / (now.stop - now.start)).toInt().coerceIn(0, 100)
                b.visibility = View.VISIBLE
            } else b.visibility = View.INVISIBLE
        }

        h.job = scope.launch {
            val bmp = logos.bitmapFor(ch)
            if (bmp != null) h.logo.setImageBitmap(bmp)
        }
    }

    override fun onViewRecycled(h: VH) {
        h.job?.cancel()
    }
}

/** Tam ekran bölmədə sol tərəfdəki qruplar siyahısı. Fokus qrupa keçəndə sağda həmin qrupun kanalları göstərilir. */
class GroupAdapter(
    private val count: (String?) -> Int,
    private val onFocus: (String?) -> Unit,
    private val onPick: (String?) -> Unit
) : RecyclerView.Adapter<GroupAdapter.VH>() {
    var items: List<String?> = emptyList()
    var selected: String? = null

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_group, p, false) as TextView)

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val g = items[pos]
        h.tv.text = "${g ?: "Hamısı"}  (${count(g)})"
        h.tv.isActivated = g == selected
        h.tv.setOnClickListener { onPick(g) }
        h.tv.setOnFocusChangeListener { _, has ->
            if (has) {
                val old = items.indexOf(selected)
                selected = g
                // RecyclerView layout zamanı notify çağırmamaq üçün post ilə
                h.tv.post {
                    if (old >= 0) notifyItemChanged(old)
                    val ni = items.indexOf(g)
                    if (ni >= 0) notifyItemChanged(ni)
                }
                onFocus(g)
            }
        }
    }
}

/** Kanalın tam proqram cədvəli (OK-a iki dəfə basanda). */
class ProgAdapter : RecyclerView.Adapter<ProgAdapter.VH>() {
    var items: List<Prog> = emptyList()
    var nowStart: Long = -1L

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val time: TextView = v.findViewById(R.id.progTime)
        val title: TextView = v.findViewById(R.id.progTitle)
        val desc: TextView = v.findViewById(R.id.progDesc)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_prog, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val p = items[pos]
        val now = p.start == nowStart
        val day = dayLabel(p.start)
        h.time.text = hm(p.start) + "–" + hm(p.stop) + (if (day.isEmpty()) "" else "\n$day")
        h.title.text = (if (now) "▶ " else "") + p.title
        h.desc.text = p.desc
        h.desc.visibility = if (p.desc.isBlank()) View.GONE else View.VISIBLE
        h.itemView.isActivated = now
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var libVLC: LibVLC
    private lateinit var player: MediaPlayer
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var exoSurface: SurfaceView
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var infoBar: LinearLayout
    private lateinit var infoLogo: ImageView
    private lateinit var infoName: TextView
    private lateinit var infoEpg: TextView
    private lateinit var infoRes: TextView
    private lateinit var detNow: TextView
    private lateinit var detNext: TextView
    private lateinit var detDesc: TextView
    private lateinit var panel: View
    private lateinit var panelBody: View
    private lateinit var groupTitle: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ChannelAdapter
    private lateinit var logos: LogoStore
    private lateinit var epgFull: View
    private lateinit var epgFullList: RecyclerView
    private lateinit var epgFullTitle: TextView
    private lateinit var epgFullRes: TextView
    private lateinit var epgFullLogo: ImageView
    private lateinit var epgFullEmpty: TextView
    private lateinit var progAdapter: ProgAdapter
    private var epgFullCh: Channel? = null
    private lateinit var epg: EpgStore
    private lateinit var browser: View
    private lateinit var groupsList: RecyclerView
    private lateinit var channelsList: RecyclerView
    private lateinit var browserTitle: TextView
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var rowAdapter: ChannelAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val hidePanelRun = Runnable { setPanel(false) }
    private val hideInfoRun = Runnable { infoBar.visibility = View.GONE }

    private var all: List<Channel> = emptyList()
    private var byGroup: Map<String, List<Channel>> = emptyMap()
    private var groupList: List<String?> = listOf(null) // null = "Hamısı"
    private var playGroup: String? = null
    private var browseGroup: String? = null
    private var browserGroup: String? = null
    private var current: Channel? = null
    private var switching = false
    private var exo: ExoPlayer? = null
    private var usingExo = false
    private var stoppedForLifecycle = false
    private var fallbackTried = false
    private var previewCh: Channel? = null
    private var infoShown: Channel? = null
    private var curMedia: Media? = null // VLC trek məlumatı (resolution) üçün saxlanılır
    private var focusedCh: Channel? = null
    private var curRes: String? = null       // məs. 1920×1080  (1080p)
    private var curResShort: String? = null  // məs. 1080p
    private val resRun = Runnable { updateResolution() }
    private var lastFastStep = 0L
    private val commitRun = Runnable { previewCh?.let { play(it, playGroup) }; previewCh = null }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun listFor(g: String?): List<Channel> = if (g == null) all else byGroup[g].orEmpty()
    private fun panelShown() = panel.visibility == View.VISIBLE
    private fun browserShown() = browser.visibility == View.VISIBLE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        videoLayout = findViewById(R.id.videoLayout)
        exoSurface = findViewById(R.id.exoSurface)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        infoBar = findViewById(R.id.infoBar)
        infoLogo = findViewById(R.id.infoLogo)
        infoName = findViewById(R.id.infoName)
        infoEpg = findViewById(R.id.infoEpg)
        infoRes = findViewById(R.id.infoRes)
        panel = findViewById(R.id.panel)
        panelBody = findViewById(R.id.panelBody)
        groupTitle = findViewById(R.id.groupTitle)
        list = findViewById(R.id.list)
        detNow = findViewById(R.id.detNow)
        epgFull = findViewById(R.id.epgFull)
        epgFullList = findViewById(R.id.epgFullList)
        epgFullTitle = findViewById(R.id.epgFullTitle)
        epgFullRes = findViewById(R.id.epgFullRes)
        epgFullLogo = findViewById(R.id.epgFullLogo)
        epgFullEmpty = findViewById(R.id.epgFullEmpty)
        progAdapter = ProgAdapter()
        epgFullList.layoutManager = LinearLayoutManager(this)
        epgFullList.adapter = progAdapter
        epgFullList.itemAnimator = null
        detNext = findViewById(R.id.detNext)
        detDesc = findViewById(R.id.detDesc)

        epg = EpgStore(applicationContext)
        logos = LogoStore(applicationContext, lifecycleScope, epg)
        adapter = ChannelAdapter(
            logos, epg, lifecycleScope, R.layout.item_channel,
            resLabel = { curResShort },
            onFocusCh = { ch -> focusedCh = ch; renderDetail() }
        ) { ch ->
            // Oynayan kanalda ikinci OK: tam proqram cədvəli
            if (ch.url == current?.url) setEpgFull(true, ch)
            else { play(ch, browseGroup); setPanel(false) }
        }
        list.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        list.adapter = adapter
        list.itemAnimator = null
        list.setHasFixedSize(true)

        browser = findViewById(R.id.browser)
        groupsList = findViewById(R.id.groupsList)
        channelsList = findViewById(R.id.channelsList)
        browserTitle = findViewById(R.id.browserTitle)
        groupAdapter = GroupAdapter(
            count = { g -> listFor(g).size },
            onFocus = { g ->
                if (g != browserGroup) {
                    browserGroup = g
                    showBrowserChannels()
                    channelsList.scrollToPosition(0)
                }
            },
            onPick = { g ->
                browserGroup = g
                showBrowserChannels()
                focusPos(channelsList, rowAdapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0))
            }
        )
        groupsList.layoutManager = LinearLayoutManager(this)
        groupsList.adapter = groupAdapter
        groupsList.itemAnimator = null
        groupsList.setHasFixedSize(true)
        rowAdapter = ChannelAdapter(logos, epg, lifecycleScope, R.layout.item_channel_row, resLabel = { curResShort }) { ch ->
            if (ch.url == current?.url) { setBrowser(false); setEpgFull(true, ch) }
            else { play(ch, browserGroup); setBrowser(false) }
        }
        channelsList.layoutManager = GridLayoutManager(this, 2, RecyclerView.VERTICAL, false)
        channelsList.adapter = rowAdapter
        channelsList.itemAnimator = null
        channelsList.setHasFixedSize(true)
        channelsList.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> adjustChannelColumns() }
        channelsList.post { adjustChannelColumns() }

        libVLC = LibVLC(this, arrayListOf("--network-caching=1200", "--live-caching=1200", "--clock-jitter=0", "--clock-synchro=0"))
        player = MediaPlayer(libVLC)
        player.setEventListener { ev ->
            runOnUiThread {
                when (ev.type) {
                    MediaPlayer.Event.Buffering ->
                        progress.visibility = if (ev.buffering < 100f) View.VISIBLE else View.GONE
                    MediaPlayer.Event.Playing -> {
                        progress.visibility = View.GONE; status.visibility = View.GONE; applyStretch(); updateResolution()
                    }
                    MediaPlayer.Event.Vout -> { applyStretch(); updateResolution() }
                    MediaPlayer.Event.EncounteredError -> {
                        val c = current
                        if (!usingExo && !fallbackTried && c != null) {
                            fallbackTried = true
                            playExo(c) // VLC aça bilmədisə Media3 ilə cəhd
                        } else if (!usingExo) {
                            progress.visibility = View.GONE
                            status.text = "Kanal açılmadı"
                            status.visibility = View.VISIBLE
                        }
                    }
                }
            }
        }
        videoLayout.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyStretch() }

        val root = findViewById<View>(R.id.root)
        root.setOnClickListener { setPanel(!panelShown()) }
        root.isFocusable = false

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Geri: tam ekran bölmə (solda qruplar, sağda kanallar). Açıqdırsa bağlanır.
                when {
                    epgFullShown() -> setEpgFull(false)
                    browserShown() -> setBrowser(false)
                    panelShown() -> setPanel(false)
                    else -> setBrowser(true)
                }
            }
        })

        hideBars()
        showCached()   // əvvəlki playlist dərhal açılır
        loadPlaylist() // hər açılışda yenisi endirilir
    }

    // ---------- playlist ----------
    private fun showCached() {
        val cache = File(filesDir, "playlist.m3u")
        if (!cache.exists()) return
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { runCatching { cache.readText() }.getOrNull() } ?: return@launch
            applyPlaylist(text)
        }
    }

    private fun loadPlaylist() {
        if (all.isEmpty()) {
            status.text = "Playlist yüklənir…"
            status.visibility = View.VISIBLE
        }
        lifecycleScope.launch {
            val cache = File(filesDir, "playlist.m3u")
            // Keşin əvvəlki mətnini endirmədən öncə saxla: eyni linklərdə UI-ni yenidən qurmağa ehtiyac yoxdur.
            val result = withContext(Dispatchers.IO) {
                val cachedText = runCatching { if (cache.exists()) cache.readText() else null }.getOrNull()
                val downloaded = runCatching { downloadPlaylist(cache) }.getOrNull()
                cachedText to downloaded
            }
            val oldText = result.first
            val text = result.second
            if (text != null) {
                val oldLinks = oldText?.let { withContext(Dispatchers.Default) { parsePlaylist(it).map(Channel::url) } }
                val newLinks = withContext(Dispatchers.Default) { parsePlaylist(text).map(Channel::url) }
                if (oldLinks == null || oldLinks != newLinks) {
                    applyPlaylist(text) // EPG və loqolar applyPlaylist daxilində yenilənir
                } else {
                    // Linklər eynidir: mövcud kanalların vəziyyətini və seçimini olduğu kimi saxla.
                    status.visibility = View.GONE
                }
            } else if (all.isEmpty()) {
                status.text = "Playlist yüklənmədi"
                status.visibility = View.VISIBLE
            } else {
                Toast.makeText(this@MainActivity, "Yenilənmədi, köhnə playlist açıqdır", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun applyPlaylist(text: String) {
        val parsed = withContext(Dispatchers.Default) { parsePlaylist(text) }
        if (parsed.isEmpty()) return
        // Playlistin qruplaşdırılması da arxa planda aparılır: böyük siyahı UI-ni dondurmasın.
        val prepared = withContext(Dispatchers.Default) {
            val groupedByName = parsed.groupBy { it.group }
            val order = parsed.map { it.group }.distinct()
            val grouped = order.asSequence()
                .flatMap { groupedByName[it].orEmpty().asSequence() }
                .mapIndexed { i, c -> c.copy(number = i + 1) }
                .toList()
            Triple(order, grouped, grouped.groupBy { it.group })
        }
        val order = prepared.first
        val grouped = prepared.second
        all = grouped
        byGroup = prepared.third
        groupList = listOf<String?>(null) + order
        if (playGroup != null && playGroup !in order) playGroup = null
        if (browseGroup != null && browseGroup !in order) browseGroup = null
        status.visibility = View.GONE

        if (current == null) {
            val prefs = getSharedPreferences("p", MODE_PRIVATE)
            val lastUrl = prefs.getString("last", null)
            val lastGroup = prefs.getString("group", "")?.takeIf { it.isNotEmpty() && it in order }
            val ch = all.firstOrNull { it.url == lastUrl && (lastGroup == null || it.group == lastGroup) }
                ?: all.firstOrNull { it.url == lastUrl }
                ?: byGroup[lastGroup]?.firstOrNull()
                ?: all.first()
            play(ch, if (lastGroup == null || ch.group == lastGroup) lastGroup else null)
        } else if (panelShown()) {
            loadBrowse()
        }
        if (browserShown()) {
            if (browserGroup != null && browserGroup !in order) browserGroup = null
            groupAdapter.items = groupList
            groupAdapter.selected = browserGroup
            groupAdapter.notifyDataSetChanged()
            showBrowserChannels()
        }
        reloadEpg()
    }

    // ---------- playback ----------
    /** DASH / Smooth Streaming VLC-nin aça bilmədiyi formatlardır: Media3 ilə açılır. Qalan hər şey VLC ilə (VLC açmasa Media3 ehtiyatı). */
    private fun isExoUrl(u: String): Boolean {
        val l = u.lowercase()
        return l.contains(".mpd") || l.contains(".ism/") || l.endsWith(".ism") || l.contains("/manifest")
    }

    private fun play(ch: Channel, group: String?, dir: Int = 0) {
        current = ch
        playGroup = group
        curRes = null; curResShort = null
        scheduleRes()
        getSharedPreferences("p", MODE_PRIVATE).edit()
            .putString("last", ch.url).putString("group", group ?: "").apply()
        adapter.playingUrl = ch.url
        if (panelShown()) adapter.notifyDataSetChanged()
        showInfo(ch, dir)
        status.visibility = View.GONE
        progress.visibility = View.VISIBLE
        fallbackTried = false
        // VLC əsasdır; açıla bilməyən kanalları Media3 (ExoPlayer) açır
        if (isExoUrl(ch.url)) playExo(ch) else playVlc(ch)
        onChannelSwitched(ch)
    }

    private fun playVlc(ch: Channel) {
        usingExo = false
        exo?.let { it.stop(); it.clearMediaItems() }
        exoSurface.visibility = View.GONE
        videoLayout.visibility = View.VISIBLE
        try {
            val media = Media(libVLC, Uri.parse(ch.url))
            media.setHWDecoderEnabled(true, false)
            media.addOption(":network-caching=1200")
            media.addOption(":live-caching=1200")
            media.addOption(":clock-jitter=0")
            media.addOption(":clock-synchro=0")
            val old = curMedia
            player.media = media
            curMedia = media
            runCatching { old?.release() }
            applyStretch()
            player.play()
        } catch (t: Throwable) {
            if (!fallbackTried) { fallbackTried = true; playExo(ch) }
        }
    }

    private fun playExo(ch: Channel) {
        usingExo = true
        runCatching { player.stop() }
        runCatching { curMedia?.release() }; curMedia = null
        videoLayout.visibility = View.INVISIBLE
        exoSurface.visibility = View.VISIBLE
        try {
            val p = exo ?: createExo().also { exo = it }
            val b = MediaItem.Builder().setUri(ch.url)
            if (ch.url.lowercase().contains(".mpd")) b.setMimeType(MimeTypes.APPLICATION_MPD)
            p.setMediaItem(b.build())
            p.prepare()
            p.playWhenReady = true
        } catch (t: Throwable) {
            if (!fallbackTried) { fallbackTried = true; playVlc(ch); return }
            progress.visibility = View.GONE
            status.text = "Kanal açılmadı"
            status.visibility = View.VISIBLE
        }
    }

    private fun createExo(): ExoPlayer {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(12000)
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) MehdiPlayer")
        // Daha geniş bufer: qısa şəbəkə dalğalanmalarında canlı yayımın dayanmasını azaldır.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(5000, 30000, 1000, 2000)
            .build()
        val p = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .build()
        p.setVideoSurfaceView(exoSurface) // surface tam ölçüdə olduğu üçün video ekrana uzanır
        p.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) { updateResolution() }
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> progress.visibility = View.VISIBLE
                    Player.STATE_READY -> { progress.visibility = View.GONE; status.visibility = View.GONE }
                }
            }
            override fun onPlayerError(error: PlaybackException) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    p.seekToDefaultPosition(); p.prepare(); return
                }
                val c = current
                if (usingExo && !fallbackTried && c != null) {
                    fallbackTried = true
                    playVlc(c) // ExoPlayer aça bilmədi -> VLC
                    return
                }
                progress.visibility = View.GONE
                status.text = "Kanal açılmadı"
                status.visibility = View.VISIBLE
            }
        })
        return p
    }

    private fun neighbor(base: Channel?, d: Int): Channel? {
        val l = listFor(playGroup).ifEmpty { all }
        if (l.isEmpty()) return null
        val i = l.indexOfFirst { it.url == base?.url }
        return l[((if (i < 0) 0 else i + d) + l.size) % l.size]
    }

    private fun step(d: Int) {
        previewCh = null
        handler.removeCallbacks(commitRun)
        neighbor(current, d)?.let { play(it, playGroup, d) }
    }

    /** Sol/sağ düyməni basıb saxlayanda kanallar sürətlə dəyişir; kanal düymə buraxılanda açılır. */
    private fun fastStep(d: Int) {
        val now = SystemClock.uptimeMillis()
        if (now - lastFastStep < 110) return
        lastFastStep = now
        val ch = neighbor(previewCh ?: current, d) ?: return
        previewCh = ch
        showInfo(ch, d)
        handler.removeCallbacks(commitRun)
        handler.postDelayed(commitRun, 450)
    }

    /** Yalnız ekran nisbətinə uyğun gəlməyən (tam ekranı doldurmayan) videoları uzat. */
    private fun applyStretch() {
        val dm = resources.displayMetrics
        val screenW = if (videoLayout.width > 0) videoLayout.width else dm.widthPixels
        val screenH = if (videoLayout.height > 0) videoLayout.height else dm.heightPixels
        // LibVLC's MediaPlayer does not expose videoWidth/videoHeight as Kotlin properties.
        // Read dimensions from its video-track API reflectively to stay compatible with
        // the LibVLC versions used by this project.
        val videoTrack = runCatching {
            player.javaClass.methods.firstOrNull { it.name == "getVideoTracks" && it.parameterCount == 0 }
                ?.invoke(player)?.let { tracks ->
                    when (tracks) {
                        is Array<*> -> tracks.firstOrNull()
                        is Iterable<*> -> tracks.firstOrNull()
                        else -> null
                    }
                }
        }.getOrNull()
        fun trackDimension(vararg names: String): Int = runCatching {
            val getter = videoTrack?.javaClass?.methods?.firstOrNull {
                it.parameterCount == 0 && it.name in names
            }
            (getter?.invoke(videoTrack) as? Number)?.toInt() ?: 0
        }.getOrDefault(0)
        val videoW = trackDimension("getWidth", "getVideoWidth", "width")
        val videoH = trackDimension("getHeight", "getVideoHeight", "height")

        if (screenW <= 0 || screenH <= 0 || videoW <= 0 || videoH <= 0) return

        val screenRatio = screenW.toFloat() / screenH.toFloat()
        val videoRatio = videoW.toFloat() / videoH.toFloat()
        // Ekranı onsuz da dolduran videonun nisbətini dəyişmə; yalnız fərqli nisbətli videoları uzat.
        if (kotlin.math.abs(videoRatio - screenRatio) / screenRatio <= 0.03f) {
            player.setAspectRatio(null)
        } else {
            player.setAspectRatio("$screenW:$screenH")
        }
        player.setScale(0f)
    }

    /** Kanal dəyişəndə/seçiləndə aşağıda məlumat yüngül animasiya ilə göstərilir, sonra silinir. */
    private fun showInfo(ch: Channel, dir: Int = 0) {
        infoShown = ch
        val l = listFor(playGroup).ifEmpty { all }
        val idx = (l.indexOfFirst { it.url == ch.url } + 1).coerceAtLeast(1)
        infoName.text = "${ch.name}  •  $idx/${l.size}  •  ${playGroup ?: "Hamısı"}"
        updateInfoExtras(ch)
        infoLogo.setImageDrawable(null)
        infoBar.animate().cancel()
        if (dir != 0) {
            infoBar.translationX = dp(48).toFloat() * dir
            infoBar.alpha = 0.3f
            infoBar.visibility = View.VISIBLE
            infoBar.animate().translationX(0f).alpha(1f).setDuration(120).start()
        } else {
            infoBar.translationX = 0f
            infoBar.alpha = 1f
            infoBar.visibility = View.VISIBLE
        }
        lifecycleScope.launch {
            val bmp = logos.bitmapFor(ch)
            if (bmp != null && infoShown == ch) infoLogo.setImageBitmap(bmp)
        }
        handler.removeCallbacks(hideInfoRun)
        handler.postDelayed(hideInfoRun, 4000)
    }

    // ---------- channel panel ----------
    // ---------- tam ekran: qruplar (sol) + kanallar (sağ) ----------
    private fun showBrowserChannels() {
        val l = listFor(browserGroup)
        rowAdapter.items = l
        rowAdapter.playingUrl = current?.url
        rowAdapter.notifyDataSetChanged()
        browserTitle.text = "${browserGroup ?: "Hamısı"}  (${l.size})"
    }

    private fun adjustChannelColumns() {
        val layout = channelsList.layoutManager as? GridLayoutManager ?: return
        val available = channelsList.width
        if (available <= 0) return
        // Geniş ekranda daha çox kanal eyni anda görünür; kiçik ekranda sütun sayı azalır.
        val desired = (available.toFloat() / dp(270).coerceAtLeast(1)).roundToInt().coerceIn(2, 5)
        if (layout.spanCount != desired) layout.spanCount = desired
    }

    private fun focusPos(rv: RecyclerView, idx: Int) {
        val layout = rv.layoutManager as? LinearLayoutManager ?: return
        layout.scrollToPositionWithOffset(idx, if (rv == channelsList) dp(24) else dp(120))
        rv.postDelayed({ rv.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }, 90)
    }

    private fun setBrowser(show: Boolean) {
        if (!show) { browser.visibility = View.GONE; return }
        handler.removeCallbacks(hidePanelRun)
        handler.removeCallbacks(hideInfoRun)
        setPanel(false)
        infoBar.visibility = View.GONE
        browserGroup = playGroup
        groupAdapter.items = groupList
        groupAdapter.selected = browserGroup
        groupAdapter.notifyDataSetChanged()
        showBrowserChannels()
        browser.visibility = View.VISIBLE
        groupsList.scrollToPosition(groupList.indexOf(browserGroup).coerceAtLeast(0))
        focusPos(channelsList, rowAdapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0))
    }

    private fun handleBrowserKey(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val f = currentFocus
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> if (f != null) {
                    val channelItem = channelsList.findContainingItemView(f)
                    if (channelItem != null) {
                        val pos = channelsList.getChildAdapterPosition(channelItem)
                        val grid = channelsList.layoutManager as? GridLayoutManager
                        // Sol kənardakı sütundan qruplara keç; daxili sütunlarda adi sol hərəkət qalsın.
                        if (pos != RecyclerView.NO_POSITION && grid != null && pos % grid.spanCount == 0) {
                            focusPos(groupsList, groupList.indexOf(browserGroup).coerceAtLeast(0))
                            return true
                        }
                    }
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (f != null && groupsList.findContainingItemView(f) != null) {
                    focusPos(channelsList, if (browserGroup == playGroup)
                        rowAdapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0) else 0)
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun setPanel(show: Boolean) {
        handler.removeCallbacks(hidePanelRun)
        panel.animate().cancel()
        panelBody.animate().cancel()
        switching = false
        if (show) {
            handler.removeCallbacks(hideInfoRun)
            infoBar.visibility = View.GONE
            browseGroup = playGroup
            panelBody.translationY = 0f
            panelBody.alpha = 1f
            loadBrowse()
            panel.alpha = 0f
            panel.visibility = View.VISIBLE
            panel.animate().alpha(1f).setDuration(150).start()
            focusedCh = current
            renderDetail()
            focusCurrent()
            handler.postDelayed(hidePanelRun, 10000)
        } else {
            panel.visibility = View.GONE
        }
    }

    private fun loadBrowse() {
        val l = listFor(browseGroup)
        adapter.items = l
        adapter.playingUrl = current?.url
        adapter.notifyDataSetChanged()
        val gi = groupList.indexOf(browseGroup).coerceAtLeast(0)
        groupTitle.text = "${browseGroup ?: "Hamısı"}  (${l.size})      ${gi + 1}/${groupList.size}"
    }

    private fun focusCurrent() {
        val idx = adapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0)
        (list.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(400))
        list.postDelayed({ list.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }, 70)
    }

    /** Yuxarı/aşağı: qonşu qrupa yüngül sürüşmə animasiyası ilə keçid. */
    private fun switchGroup(d: Int) {
        if (switching || groupList.size < 2) return
        switching = true
        val gi = groupList.indexOf(browseGroup).coerceAtLeast(0)
        val next = groupList[(gi + d + groupList.size) % groupList.size]
        val dist = dp(56).toFloat() * d
        panelBody.animate().translationY(-dist).alpha(0f).setDuration(110).withEndAction {
            browseGroup = next
            loadBrowse()
            panelBody.translationY = dist
            panelBody.animate().translationY(0f).alpha(1f).setDuration(160)
                .withEndAction { switching = false }.start()
            focusCurrent()
        }.start()
    }

    // ---------- remote control ----------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (epgFullShown()) return super.dispatchKeyEvent(e)
        if (browserShown()) return handleBrowserKey(e)
        if (e.action == KeyEvent.ACTION_UP && previewCh != null) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_CHANNEL_UP,
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    handler.removeCallbacks(commitRun); commitRun.run(); return true
                }
            }
        }
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (panelShown()) {
                handler.removeCallbacks(hidePanelRun)
                handler.postDelayed(hidePanelRun, 10000)
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { if (e.repeatCount == 0) switchGroup(-1); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { if (e.repeatCount == 0) switchGroup(1); return true }
                }
                return super.dispatchKeyEvent(e) // sol/sağ/OK: kanal seçimi
            }
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_MENU -> {
                    if (e.repeatCount == 0) setPanel(true); return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> return true
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    if (e.repeatCount == 0) step(-1) else fastStep(-1); return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    if (e.repeatCount == 0) step(1) else fastStep(1); return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (usingExo) exo?.let { it.playWhenReady = !it.playWhenReady }
                    else if (player.isPlaying) player.pause() else player.play()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // ---------- EPG + resolution ----------
    private fun reloadEpg() {
        val chs = all
        if (chs.isEmpty()) return
        lifecycleScope.launch {
            logos.beginBatch() // loqolar tam yenilənənə qədər kartlar tək-tək endirməsin
            try {
                // 1) telefondakı EPG dərhal; 2) mənbədə yenilik varsa tam endirilib bir anda əvəz olunur
                if (epg.loadCached(chs)) refreshEpgUi()
                if (epg.update(chs, true)) refreshEpgUi() // açılışda mənbədə yenilik məcburi yoxlanılır
                // 3) loqolar: hamısı paralel endirilir, tam bitəndən sonra birdən dəyişir
                val n = logos.refreshAll(all, epg.consumeSourceUpdated())
                if (n > 0) refreshEpgUi()
            } finally {
                logos.endBatch()
            }
            refreshEpgUi() // gözləyən kartlar yeni loqonu göstərsin
        }
    }

    /**
     * Kanal dəyişəndə şəbəkədən EPG yoxlanılmır (EPG mənbəyi əsasən açılışda yoxlanılır). Yalnız bu kanalın proqramı
     * köhnəlibsə telefondakı EPG faylından yenilənir; kanalın loqosu mənbədə dəyişibsə yalnız o halda əvəz olunur.
     */
    private fun onChannelSwitched(ch: Channel) {
        lifecycleScope.launch {
            if (epg.refreshChannel(ch, all)) refreshEpgUi()
        }
        lifecycleScope.launch {
            if (logos.refreshChannel(ch)) {
                if (infoShown == ch) logos.bitmapFor(ch)?.let { infoLogo.setImageBitmap(it) }
                adapter.notifyDataSetChanged(); rowAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun epgFullShown() = epgFull.visibility == View.VISIBLE

    private fun setEpgFull(show: Boolean, ch: Channel? = null) {
        if (!show) { epgFull.visibility = View.GONE; epgFullCh = null; return }
        if (ch == null) return
        handler.removeCallbacks(hidePanelRun); handler.removeCallbacks(hideInfoRun)
        setPanel(false)
        infoBar.visibility = View.GONE
        epgFullCh = ch
        epgFullTitle.text = "${ch.number}. ${ch.name}"
        epgFullRes.text = if (ch.url == current?.url) curRes.orEmpty() else ""
        epgFullLogo.setImageDrawable(null)
        lifecycleScope.launch {
            val b = logos.bitmapFor(ch)
            if (b != null && epgFullCh == ch) epgFullLogo.setImageBitmap(b)
        }
        val list = epg.programs(ch)
        val nowStart = epg.nowNext(ch).first?.start ?: -1L
        progAdapter.items = list
        progAdapter.nowStart = nowStart
        progAdapter.notifyDataSetChanged()
        epgFullEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        epgFull.visibility = View.VISIBLE
        val idx = list.indexOfFirst { it.start == nowStart }.coerceAtLeast(0)
        (epgFullList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(40))
        epgFullList.postDelayed({ epgFullList.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }, 90)
    }

    private fun refreshEpgUi() {
        adapter.notifyDataSetChanged(); rowAdapter.notifyDataSetChanged()
        renderDetail()
        current?.let { updateInfoExtras(it) }
    }

    private fun scheduleRes() {
        handler.removeCallbacks(resRun)
        for (d in longArrayOf(400, 900, 1500, 2500, 4000, 7000)) handler.postDelayed(resRun, d)
    }

    /** Oynayan kanalın real video ölçüsü: Media3-də videoSize, VLC-də cari video trekin en/hündürlüyü. */
    private fun readVideoSize(): Pair<Int, Int>? {
        if (usingExo) {
            val s = exo?.videoSize ?: return null
            return if (s.width > 0 && s.height > 0) s.width to s.height else null
        }
        fun dim(o: Any?, n: String): Int {
            if (o == null) return 0
            val f = runCatching { (o.javaClass.getField(n).get(o) as? Number)?.toInt() }.getOrNull()
            if (f != null && f > 0) return f
            val g = "get" + n.replaceFirstChar { it.uppercase() }
            return runCatching { (o.javaClass.getMethod(g).invoke(o) as? Number)?.toInt() }.getOrNull() ?: 0
        }
        val tr = runCatching { player.javaClass.getMethod("getCurrentVideoTrack").invoke(player) }.getOrNull()
        var w = dim(tr, "width")
        var h = dim(tr, "height")
        val m = curMedia
        if ((w <= 0 || h <= 0) && m != null) {
            // VLC Media-nın trek siyahısından video trekin ölçüsü
            runCatching {
                val cnt = (m.javaClass.getMethod("getTrackCount").invoke(m) as Number).toInt()
                val gt = m.javaClass.getMethod("getTrack", Integer.TYPE)
                for (i in 0 until cnt) {
                    val t = gt.invoke(m, i) ?: continue
                    if (t.javaClass.simpleName == "VideoTrack") {
                        w = dim(t, "width"); h = dim(t, "height")
                        if (w > 0 && h > 0) break
                    }
                }
            }
        }
        return if (w > 0 && h > 0) w to h else null
    }

    private fun updateResolution() {
        val (w, h) = readVideoSize() ?: return
        val label = when {
            h >= 2160 -> "4K"
            h >= 1440 -> "1440p"
            h >= 1080 -> "1080p"
            h >= 720 -> "720p"
            h >= 576 -> "576p"
            h >= 480 -> "480p"
            else -> "${h}p"
        }
        val full = "$w×$h  ($label)"
        if (full == curRes) return
        curRes = full; curResShort = label
        if (epgFullShown() && epgFullCh?.url == current?.url) epgFullRes.text = full
        current?.let { updateInfoExtras(it) }
        renderDetail()
        if (panelShown()) {
            val i = adapter.items.indexOfFirst { it.url == current?.url }
            if (i >= 0) adapter.notifyItemChanged(i)
        }
    }

    /** Kanal dəyişəndə çıxan alt zolaqda: indi/sonra proqram + resolution. */
    private fun updateInfoExtras(ch: Channel) {
        if (infoShown != ch) return
        val (n, x) = epg.nowNext(ch)
        val sb = StringBuilder()
        if (n != null) sb.append(hm(n.start)).append("–").append(hm(n.stop)).append("  ").append(n.title)
        if (x != null) {
            if (sb.isNotEmpty()) sb.append("   ▸   ")
            sb.append(hm(x.start)).append("  ").append(x.title)
        }
        infoEpg.text = sb
        infoEpg.visibility = if (sb.isEmpty()) View.GONE else View.VISIBLE
        val r = if (ch.url == current?.url) curRes else null
        infoRes.text = r.orEmpty()
        infoRes.visibility = if (r == null) View.GONE else View.VISIBLE
    }

    /** OK ilə açılan bölmədə fokuslanan kanalın ətraflı məlumatı. */
    private fun renderDetail() {
        if (!panelShown()) return
        val ch = focusedCh ?: current ?: return
        val (n, x) = epg.nowNext(ch)
        detNow.text = if (n != null) "Hazırda:  ${hm(n.start)}–${hm(n.stop)}  ${n.title}" else "Proqram məlumatı yoxdur"
        val sb = StringBuilder()
        if (x != null) sb.append("Sonra:  ${hm(x.start)}  ${x.title}")
        val r = if (ch.url == current?.url) curRes else null
        if (r != null) {
            if (sb.isNotEmpty()) sb.append("        ")
            sb.append("Keyfiyyət:  ").append(r)
        }
        detNext.text = sb
        detDesc.text = n?.desc.orEmpty()
    }

    // ---------- lifecycle ----------
    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onStart() {
        super.onStart()
        player.attachViews(videoLayout, null, false, false)
        // İlk açılışda və ya arxa plandan qayıdanda yalnız lazım olduqda axını başladırıq.
        // Lazımsız təkrar prepare/play canlı yayımı yenidən buferləməyə məcbur edə bilər.
        if (stoppedForLifecycle) {
            stoppedForLifecycle = false
            current?.let { play(it, playGroup) }
        }
    }

    override fun onStop() {
        super.onStop()
        stoppedForLifecycle = true
        // Şəbəkə/video axını dayanarkən native pleyer xətası tətbiqin çökməsinə səbəb olmasın.
        runCatching { exo?.stop() }
        runCatching { player.stop() }
        runCatching { player.detachViews() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { exo?.release() }
        exo = null
        runCatching { player.setEventListener(null) }
        runCatching { player.release() }
        runCatching { curMedia?.release() }; curMedia = null
        runCatching { libVLC.release() }
        super.onDestroy()
    }
}
