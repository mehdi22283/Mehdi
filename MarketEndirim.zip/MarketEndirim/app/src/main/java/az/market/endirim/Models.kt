package az.market.endirim

import java.io.Serializable

enum class Kind { PDF, IMAGES, WEB }

/** urls: PDF -> [pdf url], IMAGES -> şəkil linkləri, WEB -> [səhifə linki] */
data class Catalog(
    val market: String,
    val title: String,
    val date: String?,
    val kind: Kind,
    val urls: List<String>,
    val note: String? = null
) : Serializable

data class MarketResult(val market: String, val catalogs: List<Catalog>, val error: String?)

/** OCR ilə tapılmış məhsul: ad + qiymət (oldPrice — köhnə/üstündən xətt çəkilmiş qiymət). */
data class Product(
    val name: String,
    val price: Double,
    val oldPrice: Double?,
    val market: String,
    val catalogUrl: String,
    val page: Int,
    val cat: String
) {
    val key: String = Categorizer.norm(name)
    val catKey: String = Categorizer.norm(cat)
}

/** Siyahıda göstərilən bir kateqoriya: items — göstərilənlər, total — kateqoriyadakı bütün məhsullar. */
data class ProductCat(
    val name: String,
    val items: List<Product>,
    val total: Int,
    val expanded: Boolean,
    val canToggle: Boolean
)

data class Row(
    val type: Int,
    val market: String,
    val title: String,
    val date: String?,
    val sub: String?,
    val catalog: Catalog?,
    val catalogs: List<Catalog> = emptyList(),
    val selected: Set<String> = emptySet(),
    val tick: Int = 0,
    val cat: ProductCat? = null
) {
    companion object {
        const val HEADER = 0
        const val ITEM = 1
        const val VIEWER = 2
        const val STRIP = 3
        const val PCAT = 4
        const val HINT = 5
        const val TITLE = 6
    }
}
