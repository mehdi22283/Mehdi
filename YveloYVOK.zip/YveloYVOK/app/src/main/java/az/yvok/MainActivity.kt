package az.yvok

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {

    private val URL = "https://gpp.yelo.az/search-to-pay/db6ed060-63f2-4085-88eb-c2f8fdb05b40"
    private val PREFIX = "10011"

    private lateinit var input: EditText
    private lateinit var tvPayer: TextView
    private lateinit var tvYvok: TextView
    private lateinit var tvAmount: TextView
    private lateinit var tvStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var web: WebView
    private var currentCode = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(28), dp(12), dp(8))
        }

        input = EditText(this).apply {
            hint = "7 simvol yazın"
            textSize = 20f
            filters = arrayOf(InputFilter.LengthFilter(7))
            setSingleLine()
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2))

        progress = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(dp(36), dp(36)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12)
        })

        tvStatus = TextView(this).apply { textSize = 14f; setTextColor(0xFF888888.toInt()) }
        root.addView(tvStatus, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        tvPayer = resultView(root, "Ödəyən")
        tvYvok = resultView(root, "YVÖK")
        tvAmount = resultView(root, "Məbləğ (AZN)")
        tvAmount.textSize = 24f
        tvAmount.setTypeface(null, Typeface.BOLD)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                if (currentCode.isNotEmpty()) {
                    view.evaluateJavascript(JS.replace("__CODE__", currentCode), null)
                }
            }
        }
        // Sayt canlı görünür: qalan bütün ekranı tutur
        web.webChromeClient = android.webkit.WebChromeClient()
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.setSupportZoom(true)
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(12) })
        setContentView(root)

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val t = s?.toString().orEmpty()
                if (t.length == 7) {
                    search(PREFIX + t)
                } else {
                    currentCode = ""
                    clearResults()
                }
            }
        })
    }

    private fun resultView(root: LinearLayout, label: String): TextView {
        val l = TextView(this).apply { text = label; textSize = 12f; setTextColor(0xFF888888.toInt()) }
        root.addView(l, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        val v = TextView(this).apply { textSize = 17f; text = "—"; setTextColor(0xFF111111.toInt()) }
        root.addView(v, LinearLayout.LayoutParams(-1, -2))
        return v
    }

    private fun clearResults() {
        tvPayer.text = "—"; tvYvok.text = "—"; tvAmount.text = "—"
        tvStatus.text = ""; progress.visibility = View.GONE
    }

    private fun search(code: String) {
        currentCode = code
        clearResults()
        tvYvok.text = code
        tvStatus.text = "Axtarılır..."
        progress.visibility = View.VISIBLE
        web.loadUrl(URL)
    }

    inner class Bridge {
        @JavascriptInterface
        fun status(msg: String) { runOnUiThread { if (currentCode.isNotEmpty() && progress.visibility == View.VISIBLE) tvStatus.text = msg } }

        @JavascriptInterface
        fun tap(x: Double, y: Double) {
            runOnUiThread {
                val sc = web.scale
                val px = (x * sc).toFloat(); val py = (y * sc).toFloat()
                val t = android.os.SystemClock.uptimeMillis()
                val d = android.view.MotionEvent.obtain(t, t, android.view.MotionEvent.ACTION_DOWN, px, py, 0)
                val u = android.view.MotionEvent.obtain(t, t + 60, android.view.MotionEvent.ACTION_UP, px, py, 0)
                web.dispatchTouchEvent(d)
                web.postDelayed({ web.dispatchTouchEvent(u); u.recycle(); d.recycle() }, 60)
            }
        }

        @JavascriptInterface
        fun onResult(code: String, payer: String, yvok: String, amount: String, err: String) {
            runOnUiThread {
                if (code != currentCode) return@runOnUiThread
                progress.visibility = View.GONE
                if (err.isNotEmpty()) {
                    tvStatus.text = err
                    return@runOnUiThread
                }
                tvStatus.text = ""
                tvPayer.text = payer.ifEmpty { "—" }
                tvYvok.text = yvok.ifEmpty { code }
                var v = amount.replace(",", ".").trim().toDoubleOrNull() ?: 0.0
                if (v < 0) v = 0.0 // mənfi dəyər 0 kimi qəbul olunur
                tvAmount.text = String.format(Locale.US, "%.2f", v)
            }
        }
    }

    private val JS = """
(function(code){
  if (window.__running) return;
  window.__running = true;
  var tries = 0, field = null, filledAt = 0, clicks = 0, lastClick = 0;
  function st(m){ try { Android.status(m); } catch(e){} }
  function vis(el){ var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function fire(el){
    var r = el.getBoundingClientRect();
    var o = {bubbles:true, cancelable:true, view:window, clientX:r.left+r.width/2, clientY:r.top+r.height/2};
    ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(n){
      try { var E = (n.indexOf('pointer')===0 && window.PointerEvent) ? PointerEvent : MouseEvent; el.dispatchEvent(new E(n, o)); } catch(e){}
    });
    try { el.click(); } catch(e){}
  }
  function enter(el){
    ['keydown','keypress','keyup'].forEach(function(n){
      try { el.dispatchEvent(new KeyboardEvent(n,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true})); } catch(e){}
    });
    try { if (el.form) { if (el.form.requestSubmit) el.form.requestSubmit(); else el.form.submit(); } } catch(e){}
  }
  function findBtn(){
    var ft = field ? field.getBoundingClientRect().top : 0;
    var els = [].slice.call(document.querySelectorAll('button,a,span,div,p,label,input[type=submit],input[type=button]')).filter(function(e){
      if (!vis(e)) return false;
      var t = ((e.innerText||e.value||'')+'').trim().toLowerCase();
      return t === 'axtar' && e.getBoundingClientRect().top >= ft - 5;
    });
    if (els.length) {
      var e0 = els[els.length-1];
      for (var q=0; q<els.length; q++){ if (els[q].tagName==='BUTTON' || els[q].tagName==='INPUT'){ e0 = els[q]; break; } }
      var c = e0.closest ? e0.closest('button,a,[role=button],[onclick]') : null;
      return c || e0;
    }
    var btns = [].slice.call(document.querySelectorAll('button,input[type=submit],input[type=button],[role=button],a.btn,a[class*=btn],div[class*=btn]')).filter(vis);
    var words = ['axtar','search','yoxla','tap','göstər','sorğu'];
    for (var w=0; w<words.length; w++) for (var j=0; j<btns.length; j++){
      var t = ((btns[j].innerText||btns[j].value||btns[j].getAttribute('aria-label')||'')+'').toLowerCase();
      if (t.indexOf(words[w]) >= 0) return btns[j];
    }
    for (var j2=0; j2<btns.length; j2++) if ((btns[j2].type||'') === 'submit') return btns[j2];
    var p = field;
    for (var d=0; d<5 && p; d++){
      p = p.parentElement; if (!p) break;
      var bs = [].slice.call(p.querySelectorAll('button,input[type=submit]')).filter(vis);
      if (bs.length) return bs[bs.length-1];
    }
    return btns.length ? btns[btns.length-1] : null;
  }
  function done(){ clearInterval(iv); window.__running = false; }
  var iv = setInterval(function(){
    tries++;
    if (tries > 160) { done(); Android.onResult(code,'','','','Cavab alınmadı (vaxt bitdi)'); return; }
    if (!filledAt) {
      var inputs = [].slice.call(document.querySelectorAll('input')).filter(function(i){
        var t = (i.type||'text').toLowerCase();
        if (i.readOnly || i.disabled || !vis(i)) return false;
        if (!(t==='text'||t==='search'||t==='tel'||t==='number')) return false;
        if ((i.placeholder||'').toLowerCase().indexOf('axtar') >= 0) return false;
        if (i.closest && i.closest('[class*=searchContainer]')) return false;
        if ((i.value||'').trim().toLowerCase() === 'yvök') return false;
        return true;
      });
      if (!inputs.length) return;
      var f = inputs[inputs.length-1];
      field = f;
      var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
      f.focus(); setter.call(f, code);
      ['keydown','input','keyup','change'].forEach(function(n){
        try { f.dispatchEvent(n.indexOf('key')===0 ? new KeyboardEvent(n,{key:'0',bubbles:true}) : new Event(n,{bubbles:true})); } catch(e){}
      });
      filledAt = tries;
      st('Kod yazıldı: ' + code);
      return;
    }
    var txt = document.body.innerText || '';
    var pm = txt.match(/Ödəyən\s*:?\s*([^\n]+)/i);
    if (pm && txt.indexOf(code) >= 0) {
      var amount = null, all = document.querySelectorAll('input');
      for (var a=0; a<all.length; a++){
        var el = all[a];
        if (el === field) continue;
        var val = (el.value||'').trim();
        if (!/^-?\d+([.,]\d+)?$/.test(val) || val === code) continue;
        var p = el, hit = false;
        for (var d=0; d<4 && p; d++){ p = p.parentElement; if (p && (p.innerText||'').toLowerCase().indexOf('məbləğ')>=0){ hit = true; break; } }
        if (hit) { amount = val; break; }
        if (amount === null) amount = val;
      }
      if (amount !== null) { done(); Android.onResult(code, pm[1].trim(), code, amount, ''); return; }
    }
    var wait = (clicks === 0) ? 1 : 12;
    if (clicks < 4 && tries - lastClick >= wait) {
      var b = findBtn();
      if (!b) { if (clicks === 0) { st('Düymə tapılmadı, Enter göndərilir'); enter(field); lastClick = tries; clicks++; } return; }
      if (b.disabled) { st('Düymə deaktivdir...'); field.dispatchEvent(new Event('input',{bubbles:true})); return; }
      try { b.scrollIntoView({block:'center'}); } catch(e){}
      lastClick = tries; clicks++;
      st('Axtar düyməsi basılır (' + clicks + '): ' + ((b.innerText||b.value||'')+'').trim());
      if (clicks === 1) { fire(b); }
      else if (clicks === 3) { enter(field); fire(b); }
      else { var r = b.getBoundingClientRect(); Android.tap(r.left + r.width/2, r.top + r.height/2); }
    }
  }, 250);
})('__CODE__');
"""
}
