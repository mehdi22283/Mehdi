package az.zengyazici

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Wireless debugging-i yandırıb özünə qoşulur və tətbiqi ön planda açaraq xidməti başladır.
        AdbAuto.bootstrap(context.applicationContext)
    }
}
