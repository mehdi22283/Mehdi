package az.m3u.sinayici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipInputStream

/** GitHub Actions: son run-u tapır, hazır artifact-i (app-debug-apk) endirib zip-in içini Downloads-a yazır. */
object ApkTool {
    fun clean(t: String) = t.replace(Regex("(?i)^\\s*(bearer|token)\\s+"), "").replace(Regex("[\\s\"']+"), "")

    fun epoch(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(s)?.time ?: 0L
    } catch (e: Exception) { 0L }

    private fun open(url: String, token: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 60000; c.instanceFollowRedirects = false
        c.setRequestProperty("Authorization", "Bearer " + clean(token))
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "M3USinayici")
        return c
    }

    private fun fail(code: Int, body: String): IOException {
        val msg = try { JSONObject(body).optString("message", "") } catch (e: Exception) { "" }
        return when (code) {
            401 -> IOException("Token yanlışdır və ya vaxtı bitib (401)")
            403, 404 -> IOException(msg.ifEmpty { "HTTP $code" } + " — token bu repoda Actions oxuma icazəsinə (Actions: Read) malik olmaya bilər")
            else -> IOException(msg.ifEmpty { "GitHub xətası (HTTP $code)" })
        }
    }

    private fun getJson(url: String, token: String): JSONObject {
        val c = open(url, token)
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        c.disconnect()
        if (code !in 200..299) throw fail(code, txt)
        return JSONObject(txt)
    }

    /** since>0: bu vaxtdan sonra yaranan ən yeni run; since<=0: ən son run. */
    fun latestRun(repo: String, token: String, since: Long): JSONObject? {
        val arr = getJson("https://api.github.com/repos/$repo/actions/runs?per_page=10", token).getJSONArray("workflow_runs")
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            if (since <= 0 || epoch(r.optString("created_at")) >= since) return r
        }
        return null
    }

    fun artifact(repo: String, token: String, runId: Long): JSONObject? {
        val arr = getJson("https://api.github.com/repos/$repo/actions/runs/$runId/artifacts", token).getJSONArray("artifacts")
        val list = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { !it.optBoolean("expired", false) }
        return list.firstOrNull { it.optString("name").contains("app-debug-apk", true) }
            ?: list.firstOrNull { it.optString("name").contains("apk", true) }
            ?: list.firstOrNull { it.optString("name").contains("debug", true) }
            ?: list.firstOrNull()
    }

    /** Artifact zip-ini endirir, içindəki faylları (APK) açılmış şəkildə Downloads-a yazır. */
    fun downloadExtract(ctx: Context, repo: String, token: String, artifactId: Long): List<String> {
        val c = open("https://api.github.com/repos/$repo/actions/artifacts/$artifactId/zip", token)
        val code = c.responseCode
        val stream: InputStream
        var c2: HttpURLConnection? = null
        if (code in 300..399) {
            val loc = c.getHeaderField("Location") ?: throw IOException("Endirmə linki alınmadı")
            c.disconnect()
            c2 = URL(loc).openConnection() as HttpURLConnection   // imzalı link: token göndərilmir
            c2.connectTimeout = 20000; c2.readTimeout = 60000
            if (c2.responseCode !in 200..299) throw IOException("Endirmə xətası (HTTP ${c2.responseCode})")
            stream = c2.inputStream
        } else if (code in 200..299) stream = c.inputStream
        else throw fail(code, c.errorStream?.bufferedReader()?.readText() ?: "")
        val names = ArrayList<String>()
        ZipInputStream(stream.buffered()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory) {
                    val nm = File(e.name).name
                    if (nm.isNotEmpty()) { writeDownload(ctx, nm) { out -> z.copyTo(out) }; names.add(nm) }
                }
                z.closeEntry(); e = z.nextEntry
            }
        }
        c2?.disconnect(); c.disconnect()
        return names
    }

    fun writeDownload(ctx: Context, name: String, w: (java.io.OutputStream) -> Unit) {
        if (Build.VERSION.SDK_INT >= 29) {
            val ext = name.substringAfterLast('.', "").lowercase()
            val mt = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: if (ext == "apk") "application/vnd.android.package-archive" else "application/octet-stream"
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mt)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            ctx.contentResolver.openOutputStream(u)!!.use(w)
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            File(dir, name).outputStream().use(w)
        }
    }
}

/** Fon xidməti: Actions-ı izləyir (build bitənə qədər), hazır olanda bildiriş göndərir; bildirişdən endirmək olur. */
class ApkWatchService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val repo = i?.getStringExtra("repo") ?: ""
        val token = i?.getStringExtra("token") ?: ""
        if (repo.isEmpty() || token.isEmpty()) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH_WORK, "APK izləmə", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_DONE, "APK hazırdır", NotificationManager.IMPORTANCE_HIGH))
        }
        when (i?.action) {
            ACTION_DL -> {
                startFg(nm, "APK yüklənir...")
                val art = i?.getLongExtra("artifact", 0L) ?: 0L
                Thread {
                    try {
                        val names = ApkTool.downloadExtract(this, repo, token, art)
                        done(nm, "✅ Downloads-a yazıldı", if (names.isEmpty()) "Zip boş idi" else names.joinToString(", "), null)
                    } catch (e: Exception) { done(nm, "❌ Endirmə xətası", e.message ?: e.toString(), null) }
                }.start()
            }
            else -> {
                startFg(nm, "Actions izlənir: build gedir...")
                val since = i?.getLongExtra("since", 0L) ?: 0L
                Thread { watch(nm, repo, token, since) }.start()
            }
        }
        return START_NOT_STICKY
    }

    private fun watch(nm: NotificationManager, repo: String, token: String, since: Long) {
        val t0 = System.currentTimeMillis()
        var errors = 0
        while (System.currentTimeMillis() - t0 < 40 * 60_000L) {
            try {
                val run = ApkTool.latestRun(repo, token, since)
                errors = 0
                if (run == null) {
                    if (System.currentTimeMillis() - t0 > 3 * 60_000L) {
                        done(nm, "⚠️ Yeni action tapılmadı", "3 dəqiqə ərzində Actions-da yeni build başlamadı.", null); return
                    }
                } else if (run.optString("status") == "completed") {
                    val concl = run.optString("conclusion")
                    if (concl != "success") { done(nm, "❌ Build uğursuz oldu", "Nəticə: $concl", null); return }
                    val art = ApkTool.artifact(repo, token, run.getLong("id"))
                    if (art == null) { done(nm, "⚠️ Build bitdi, amma APK artifact tapılmadı", "", null); return }
                    done(nm, "✅ APK hazırdır", art.optString("name") + ".zip — yükləmək üçün toxunun", art.getLong("id"), repo, token); return
                } else {
                    nm.notify(ID_WORK, workNotif("Actions izlənir: ${run.optString("status")}..."))
                }
            } catch (e: Exception) {
                if (++errors >= 8) { done(nm, "❌ Actions yoxlanmadı", e.message ?: e.toString(), null); return }
            }
            try { Thread.sleep(15_000) } catch (e: InterruptedException) { }
        }
        done(nm, "⚠️ Gözləmə vaxtı bitdi", "40 dəqiqə ərzində build bitmədi.", null)
    }

    private fun builder(ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else @Suppress("DEPRECATION") Notification.Builder(this)

    private fun openPi(): PendingIntent? = packageManager.getLaunchIntentForPackage(packageName)?.let {
        PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun workNotif(text: String): Notification =
        builder(CH_WORK).setSmallIcon(R.drawable.ic_notif).setContentTitle("APK").setContentText(text)
            .setOngoing(true).setContentIntent(openPi()).build()

    private fun startFg(nm: NotificationManager, text: String) {
        val n = workNotif(text)
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID_WORK, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(ID_WORK, n)
        } catch (e: Exception) { }
    }

    private fun done(nm: NotificationManager, title: String, text: String, @Suppress("UNUSED_PARAMETER") x: Long?, repo: String = "", token: String = "") {
        val b = builder(CH_DONE).setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(openPi())
        if (x != null && repo.isNotEmpty()) {
            val dl = Intent(this, ApkWatchService::class.java).setAction(ACTION_DL)
                .putExtra("repo", repo).putExtra("token", token).putExtra("artifact", x)
            val pi = if (Build.VERSION.SDK_INT >= 26)
                PendingIntent.getForegroundService(this, 7, dl, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            else PendingIntent.getService(this, 7, dl, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.setContentIntent(pi)
            b.addAction(Notification.Action.Builder(null, "⬇️ Yüklə", pi).build())
        }
        nm.notify(ID_DONE, b.build())
        stopForeground(true)
        stopSelf()
    }

    companion object {
        const val ACTION_DL = "az.m3u.sinayici.APK_DL"
        private const val CH_WORK = "apk_work"
        private const val CH_DONE = "apk_done"
        private const val ID_WORK = 4301
        private const val ID_DONE = 4302

        private fun go(c: Context, i: Intent) {
            try { if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i) } catch (e: Exception) { }
        }
        fun watch(c: Context, repo: String, token: String, since: Long) =
            go(c, Intent(c, ApkWatchService::class.java).putExtra("repo", repo).putExtra("token", token).putExtra("since", since))
        fun download(c: Context, repo: String, token: String, artifactId: Long) =
            go(c, Intent(c, ApkWatchService::class.java).setAction(ACTION_DL).putExtra("repo", repo).putExtra("token", token).putExtra("artifact", artifactId))
    }
}
