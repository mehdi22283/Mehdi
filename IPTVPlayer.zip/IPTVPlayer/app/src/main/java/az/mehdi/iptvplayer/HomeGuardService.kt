package az.mehdi.iptvplayer

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/** Tətbiq ↔ HomeGuardService arasında ortaq vəziyyət. */
object HomeGuard {
    /** true olanda Android-in öz launcher-ində qalmağa icazə var (Geri düyməsi ilə açılıb). */
    @Volatile var allowRealLauncher = false
}

/**
 * Əlçatımlılıq xidməti: Android launcher ekrana gələndə (TV açılışı, Home düyməsi, gözləmə rejimindən oyanma)
 * Mehdi Player-i onun yerinə öndə açır. Geri düyməsi ilə launcher-ə keçiddə müdaxilə etmir.
 */
class HomeGuardService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var homePkgs: Set<String> = emptySet()
    private var ignorePkgs: Set<String> = setOf("android", "com.android.systemui")
    private var lastStart = 0L

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> HomeGuard.allowRealLauncher = false
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    HomeGuard.allowRealLauncher = false
                    refreshPkgs()
                    handler.postDelayed({ openUs() }, 1500)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        refreshPkgs()
        runCatching {
            registerReceiver(screenRx, IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
            })
        }
    }

    private fun refreshPkgs() {
        runCatching {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            homePkgs = packageManager.queryIntentActivities(home, 0)
                .map { it.activityInfo.packageName }.filter { it != packageName }.toSet()
        }
        runCatching {
            val imm = getSystemService(InputMethodManager::class.java)
            val ime = imm.enabledInputMethodList.map { it.packageName }
            ignorePkgs = setOf("android", "com.android.systemui") + ime
        }
    }

    private fun openUs() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastStart < 1500) return
        lastStart = now
        runCatching {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) { HomeGuard.allowRealLauncher = false; return }
        if (pkg in homePkgs) {
            if (!HomeGuard.allowRealLauncher) openUs()
            return
        }
        // İstifadəçi launcher-dən başqa tətbiq açdı: sonrakı Home düyməsi yenə Mehdi Player-ə qayıtsın
        if (pkg !in ignorePkgs) HomeGuard.allowRealLauncher = false
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        runCatching { unregisterReceiver(screenRx) }
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
