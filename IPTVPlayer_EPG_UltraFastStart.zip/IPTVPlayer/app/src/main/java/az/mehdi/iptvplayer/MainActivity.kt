package az.mehdi.iptvplayer

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.SurfaceView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Arxa plan işlərində tutulmayan xəta tətbiqi çökdürməsin. */
val safeHandler = CoroutineExceptionHandler { _, _ -> }

class ChannelAdapter(
    private val logos: LogoStore,
    private val epg: EpgStore,
    private val scope: CoroutineScope,
    private val layoutRes: Int = R.layout.item_channel,
    private val onFocusCh: ((Channel) -> Unit)? = null,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    var items: List<Channel> = emptyList()
    var playingUrl: String? = null

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val logo: ImageView = v.findViewById(R.id.logo)
        val name: TextView = v.findViewById(R.id.name)
        val epgTv: TextView = v.findViewById(R.id.epg)
        val bar: ProgressBar? = v.findViewById(R.id.epgBar)
        var job: Job? = null
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(layoutRes, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val ch = items[pos]
        h.job?.cancel()
        h.name.text = "${ch.number}. ${ch.name}"
        h.logo.setImageDrawable(null)
        val playing = ch.url == playingUrl
        h.itemView.isActivated = playing
        h.itemView.setOnClickListener { onClick(ch) }
        h.itemView.setOnFocusChangeListener { _, has -> if (has) onFocusCh?.invoke(ch) }

        // Kanal adının altında EPG: indi gedən proqram + resolution (yalnız oynayan kanal üçün məlum)
        val now = epg.nowNext(ch).first
        val sb = StringBuilder()
        if (now != null) sb.append(hm(now.start)).append("  ").append(now.title)
        h.epgTv.text = sb
        val invisible = if (layoutRes == R.layout.item_channel) View.INVISIBLE else View.GONE
        h.epgTv.visibility = if (sb.isEmpty()) invisible else View.VISIBLE
        h.bar?.let { b ->
            if (now != null && now.stop > now.start) {
                val t = System.currentTimeMillis() / 1000
                b.progress = (((t - now.start) * 100) / (now.stop - now.start)).toInt().coerceIn(0, 100)
                b.visibility = View.VISIBLE
            } else b.visibility = View.INVISIBLE
        }

        h.job = scope.launch(safeHandler) {
            val bmp = runCatching { logos.bitmapFor(ch) }.getOrNull()
            if (bmp != null && !bmp.isRecycled && items.getOrNull(h.bindingAdapterPosition)?.url == ch.url) h.logo.setImageBitmap(bmp)
        }
    }

    override fun onViewRecycled(h: VH) {
        h.job?.cancel()
    }
}

/** Tam ekran bölmədə sol tərəfdəki qruplar siyahısı. Fokus qrupa keçəndə sağda həmin qrupun kanalları göstərilir. */
class GroupAdapter(
    private val count: (String?) -> Int,
    private val onFocus: (String?) -> Unit,
    private val onPick: (String?) -> Unit
) : RecyclerView.Adapter<GroupAdapter.VH>() {
    var items: List<String?> = emptyList()
    var selected: String? = null

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_group, p, false) as TextView)

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val g = items[pos]
        h.tv.text = "${g ?: "Hamısı"}  (${count(g)})"
        h.tv.isActivated = g == selected
        h.tv.setOnClickListener { onPick(g) }
        h.tv.setOnFocusChangeListener { _, has ->
            if (has) {
                val old = items.indexOf(selected)
                selected = g
                // RecyclerView layout zamanı notify çağırmamaq üçün post ilə
                h.tv.post {
                    if (old >= 0) notifyItemChanged(old)
                    val ni = items.indexOf(g)
                    if (ni >= 0) notifyItemChanged(ni)
                }
                onFocus(g)
            }
        }
    }
}

/** Kanalın tam proqram cədvəli (OK-a iki dəfə basanda). */
class ProgAdapter : RecyclerView.Adapter<ProgAdapter.VH>() {
    var items: List<Prog> = emptyList()
    var nowStart: Long = -1L

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val time: TextView = v.findViewById(R.id.progTime)
        val title: TextView = v.findViewById(R.id.progTitle)
        val desc: TextView = v.findViewById(R.id.progDesc)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_prog, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val p = items[pos]
        val now = p.start == nowStart
        val day = dayLabel(p.start)
        h.time.text = hm(p.start) + "–" + hm(p.stop) + (if (day.isEmpty()) "" else "\n$day")
        h.title.text = (if (now) "▶ " else "") + p.title
        h.desc.text = p.desc
        h.desc.visibility = if (p.desc.isBlank()) View.GONE else View.VISIBLE
        h.itemView.isActivated = now
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var libVLC: LibVLC
    private lateinit var player: MediaPlayer
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var exoSurface: SurfaceView
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var infoBar: LinearLayout
    private lateinit var infoLogo: ImageView
    private lateinit var infoName: TextView
    private lateinit var infoEpg: TextView
    private lateinit var infoNext: TextView
    private lateinit var detNow: TextView
    private lateinit var detNext: TextView
    private lateinit var detDesc: TextView
    private lateinit var panel: View
    private lateinit var panelBody: View
    private lateinit var groupTitle: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ChannelAdapter
    private lateinit var logos: LogoStore
    private lateinit var epgFull: View
    private lateinit var epgFullList: RecyclerView
    private lateinit var epgFullTitle: TextView
    private lateinit var epgFullLogo: ImageView
    private lateinit var epgFullEmpty: TextView
    private lateinit var progAdapter: ProgAdapter
    private var epgFullCh: Channel? = null
    private lateinit var epg: EpgStore
    private lateinit var browser: View
    private lateinit var groupsList: RecyclerView
    private lateinit var channelsList: RecyclerView
    private lateinit var browserTitle: TextView
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var rowAdapter: ChannelAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val hidePanelRun = Runnable { setPanel(false) }
    private val hideInfoRun = Runnable { infoBar.visibility = View.GONE }

    private var all: List<Channel> = emptyList()
    private var byGroup: Map<String, List<Channel>> = emptyMap()
    private var groupList: List<String?> = listOf(null) // null = "Hamısı"
    private var playGroup: String? = null
    private var browseGroup: String? = null
    private var browserGroup: String? = null
    private var current: Channel? = null
    private var switching = false
    private var exo: ExoPlayer? = null
    private var usingExo = false
    private var stoppedForLifecycle = false
    private var fallbackTried = false
    // Gecikmiş player hadisələrinin yeni seçilmiş kanala təsir etməsinin qarşısını alır.
    @Volatile private var vlcPlayGen = -1
    @Volatile private var exoItemGen = -1
    @Volatile private var exoItemUrl: String? = null
    private var playbackReady = false
    private var bufferingWatchdog: Runnable? = null
    private var bufferingWatchdogGen = -1
    private val bufferingTimeoutMs = 10_000L
    private var previewCh: Channel? = null
    private var infoShown: Channel? = null
    private var curMedia: Media? = null // yalnız vlcExec thread-ində istifadə olunur
    // Bütün VLC əmrləri (stop/media/play/release) tək arxa plan thread-ində, ardıcıl icra olunur: UI donmur, native race olmur.
    private val vlcExec: ExecutorService = Executors.newSingleThreadExecutor { r -> Thread(r, "vlc-cmd").apply { isDaemon = true } }
    private val playGen = AtomicInteger(0)
    private var lastPlayAt = 0L
    private var pendingPlay: Runnable? = null
    private var focusedCh: Channel? = null
    private var lastFastStep = 0L
    private val commitRun = Runnable { previewCh?.let { play(it, playGroup) }; previewCh = null }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun listFor(g: String?): List<Channel> = if (g == null) all else byGroup[g].orEmpty()
    private fun panelShown() = panel.visibility == View.VISIBLE
    private fun browserShown() = browser.visibility == View.VISIBLE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        videoLayout = findViewById(R.id.videoLayout)
        exoSurface = findViewById(R.id.exoSurface)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        infoBar = findViewById(R.id.infoBar)
        infoLogo = findViewById(R.id.infoLogo)
        infoName = findViewById(R.id.infoName)
        infoEpg = findViewById(R.id.infoEpg)
        infoNext = findViewById(R.id.infoNext)
        panel = findViewById(R.id.panel)
        panelBody = findViewById(R.id.panelBody)
        groupTitle = findViewById(R.id.groupTitle)
        list = findViewById(R.id.list)
        detNow = findViewById(R.id.detNow)
        epgFull = findViewById(R.id.epgFull)
        epgFullList = findViewById(R.id.epgFullList)
        epgFullTitle = findViewById(R.id.epgFullTitle)
        epgFullLogo = findViewById(R.id.epgFullLogo)
        epgFullEmpty = findViewById(R.id.epgFullEmpty)
        progAdapter = ProgAdapter()
        epgFullList.layoutManager = LinearLayoutManager(this)
        epgFullList.adapter = progAdapter
        epgFullList.itemAnimator = null
        detNext = findViewById(R.id.detNext)
        detDesc = findViewById(R.id.detDesc)

        epg = EpgStore(applicationContext)
        logos = LogoStore(applicationContext, lifecycleScope, epg)
        adapter = ChannelAdapter(
            logos, epg, lifecycleScope, R.layout.item_channel,
            onFocusCh = { ch -> focusedCh = ch; renderDetail() }
        ) { ch ->
            // Oynayan kanalda ikinci OK: tam proqram cədvəli
            if (ch.url == current?.url) setEpgFull(true, ch)
            else { play(ch, browseGroup); setPanel(false) }
        }
        list.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        list.adapter = adapter
        list.itemAnimator = null
        list.setHasFixedSize(true)

        browser = findViewById(R.id.browser)
        groupsList = findViewById(R.id.groupsList)
        channelsList = findViewById(R.id.channelsList)
        browserTitle = findViewById(R.id.browserTitle)
        groupAdapter = GroupAdapter(
            count = { g -> listFor(g).size },
            onFocus = { g ->
                if (g != browserGroup) {
                    browserGroup = g
                    showBrowserChannels()
                    channelsList.scrollToPosition(0)
                }
            },
            onPick = { g ->
                browserGroup = g
                showBrowserChannels()
                focusPos(channelsList, rowAdapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0))
            }
        )
        groupsList.layoutManager = LinearLayoutManager(this)
        groupsList.adapter = groupAdapter
        groupsList.itemAnimator = null
        groupsList.setHasFixedSize(true)
        rowAdapter = ChannelAdapter(logos, epg, lifecycleScope, R.layout.item_channel_row) { ch ->
            if (ch.url == current?.url) { setBrowser(false); setEpgFull(true, ch) }
            else { play(ch, browserGroup); setBrowser(false) }
        }
        channelsList.layoutManager = GridLayoutManager(this, 2, RecyclerView.VERTICAL, false)
        channelsList.adapter = rowAdapter
        channelsList.itemAnimator = null
        channelsList.setHasFixedSize(true)
        channelsList.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> adjustChannelColumns() }
        channelsList.post { adjustChannelColumns() }

        // Daha böyük şəbəkə keşindən istifadə et; clock sync-i söndürmək bəzi axınlarda
        // səs/video sinxronluğu və kəkələmə yarada bildiyindən standart davranışı saxla.
        libVLC = LibVLC(this, arrayListOf("--network-caching=2000", "--live-caching=2000", "--http-reconnect"))
        player = MediaPlayer(libVLC)
        player.setEventListener { ev ->
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                // Əvvəlki kanalın gecikmiş hadisələri yeni kanala tətbiq olunmasın.
                if (usingExo || vlcPlayGen != playGen.get()) return@runOnUiThread
                when (ev.type) {
                    MediaPlayer.Event.Buffering -> {
                        if (ev.buffering < 100f) {
                            progress.visibility = View.VISIBLE
                            playbackReady = false
                            scheduleBufferingWatchdog(vlcPlayGen)
                        } else {
                            progress.visibility = View.GONE
                        }
                    }
                    MediaPlayer.Event.Playing -> {
                        playbackReady = true
                        cancelBufferingWatchdog()
                        progress.visibility = View.GONE
                        status.visibility = View.GONE
                        applyStretch()
                    }
                    MediaPlayer.Event.Vout -> applyStretch()
                    MediaPlayer.Event.EncounteredError -> {
                        val c = current ?: return@runOnUiThread
                        val gen = playGen.get()
                        if (!fallbackTried) {
                            fallbackTried = true
                            playExo(c, gen) // VLC axını aça bilmirsə Media3 ilə ehtiyat cəhd
                        } else {
                            cancelBufferingWatchdog()
                            progress.visibility = View.GONE
                            status.text = "Kanal açılmadı"
                            status.visibility = View.VISIBLE
                        }
                    }
                }
            }
        }
        videoLayout.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyStretch() }

        val root = findViewById<View>(R.id.root)
        root.setOnClickListener { setPanel(!panelShown()) }
        root.isFocusable = false

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Geri: tam ekran bölmə (solda qruplar, sağda kanallar). Açıqdırsa bağlanır.
                when {
                    epgFullShown() -> setEpgFull(false)
                    browserShown() -> setBrowser(false)
                    panelShown() -> setPanel(false)
                    else -> setBrowser(true)
                }
            }
        })

        hideBars()
        showCached()   // əvvəlki playlist dərhal açılır
        loadPlaylist() // hər açılışda yenisi endirilir
    }

    // ---------- playlist ----------
    private fun showCached() {
        val cache = File(filesDir, "playlist.m3u")
        if (!cache.exists()) return
        lifecycleScope.launch(safeHandler) {
            val text = withContext(Dispatchers.IO) { runCatching { cache.readText() }.getOrNull() } ?: return@launch
            applyPlaylist(text)
        }
    }

    private fun loadPlaylist() {
        if (all.isEmpty()) {
            status.text = "Playlist yüklənir…"
            status.visibility = View.VISIBLE
        }
        lifecycleScope.launch(safeHandler) {
            val cache = File(filesDir, "playlist.m3u")
            // Keşin əvvəlki mətnini endirmədən öncə saxla: eyni linklərdə UI-ni yenidən qurmağa ehtiyac yoxdur.
            val result = withContext(Dispatchers.IO) {
                val cachedText = runCatching { if (cache.exists()) cache.readText() else null }.getOrNull()
                val downloaded = runCatching { downloadPlaylist(cache) }.getOrNull()
                cachedText to downloaded
            }
            val oldText = result.first
            val text = result.second
            if (text != null) {
                val oldLinks = oldText?.let { withContext(Dispatchers.Default) { parsePlaylist(it).map(Channel::url) } }
                val newLinks = withContext(Dispatchers.Default) { parsePlaylist(text).map(Channel::url) }
                if (oldLinks == null || oldLinks != newLinks) {
                    applyPlaylist(text) // EPG və loqolar applyPlaylist daxilində yenilənir
                } else {
                    // Linklər eynidir: mövcud kanalların vəziyyətini və seçimini olduğu kimi saxla.
                    status.visibility = View.GONE
                }
            } else if (all.isEmpty()) {
                status.text = "Playlist yüklənmədi"
                status.visibility = View.VISIBLE
            } else {
                Toast.makeText(this@MainActivity, "Yenilənmədi, köhnə playlist açıqdır", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun applyPlaylist(text: String) {
        val parsed = withContext(Dispatchers.Default) { parsePlaylist(text) }
        if (parsed.isEmpty()) return
        // Playlistin qruplaşdırılması da arxa planda aparılır: böyük siyahı UI-ni dondurmasın.
        val prepared = withContext(Dispatchers.Default) {
            val groupedByName = parsed.groupBy { it.group }
            val order = parsed.map { it.group }.distinct()
            val grouped = order.asSequence()
                .flatMap { groupedByName[it].orEmpty().asSequence() }
                .mapIndexed { i, c -> c.copy(number = i + 1) }
                .toList()
            Triple(order, grouped, grouped.groupBy { it.group })
        }
        val order = prepared.first
        val grouped = prepared.second
        all = grouped
        byGroup = prepared.third
        groupList = listOf<String?>(null) + order
        if (playGroup != null && playGroup !in order) playGroup = null
        if (browseGroup != null && browseGroup !in order) browseGroup = null
        status.visibility = View.GONE

        if (current == null) {
            val prefs = getSharedPreferences("p", MODE_PRIVATE)
            val lastUrl = prefs.getString("last", null)
            val lastGroup = prefs.getString("group", "")?.takeIf { it.isNotEmpty() && it in order }
            val ch = all.firstOrNull { it.url == lastUrl && (lastGroup == null || it.group == lastGroup) }
                ?: all.firstOrNull { it.url == lastUrl }
                ?: byGroup[lastGroup]?.firstOrNull()
                ?: all.first()
            play(ch, if (lastGroup == null || ch.group == lastGroup) lastGroup else null)
        } else if (panelShown()) {
            loadBrowse()
        }
        if (browserShown()) {
            if (browserGroup != null && browserGroup !in order) browserGroup = null
            groupAdapter.items = groupList
            groupAdapter.selected = browserGroup
            groupAdapter.notifyDataSetChanged()
            showBrowserChannels()
        }
        reloadEpg()
    }

    // ---------- playback ----------
    /** DASH / Smooth Streaming VLC-nin aça bilmədiyi formatlardır: Media3 ilə açılır. Qalan hər şey VLC ilə (VLC açmasa Media3 ehtiyatı). */
    private fun isExoUrl(u: String): Boolean {
        val l = u.lowercase()
        return l.contains(".mpd") || l.contains(".ism/") || l.endsWith(".ism") || l.contains("/manifest")
    }

    private fun play(ch: Channel, group: String?, dir: Int = 0) {
        current = ch
        playGroup = group
        getSharedPreferences("p", MODE_PRIVATE).edit()
            .putString("last", ch.url).putString("group", group ?: "").apply()
        adapter.playingUrl = ch.url
        if (panelShown()) adapter.notifyDataSetChanged()
        showInfo(ch, dir)
        status.visibility = View.GONE
        progress.visibility = View.VISIBLE
        playbackReady = false
        cancelBufferingWatchdog()
        fallbackTried = false

        // Tez-tez kanal dəyişəndə yalnız SON kanal açılsın; köhnə başladılma sorğusu ləğv edilir.
        val gen = playGen.incrementAndGet()
        pendingPlay?.let { handler.removeCallbacks(it) }
        val nowT = SystemClock.uptimeMillis()
        val delay = if (nowT - lastPlayAt < 900) 100L else 0L
        lastPlayAt = nowT
        val r = Runnable {
            pendingPlay = null
            if (gen != playGen.get() || isDestroyed || isFinishing) return@Runnable
            if (isExoUrl(ch.url)) playExo(ch, gen) else playVlc(ch, gen)
            onChannelSwitched(ch)
        }
        pendingPlay = r
        if (delay == 0L) r.run() else handler.postDelayed(r, delay)
    }

    private fun playVlc(ch: Channel, gen: Int = playGen.get()) {
        if (gen != playGen.get() || isDestroyed || isFinishing) return
        usingExo = false
        playbackReady = false
        cancelBufferingWatchdog()
        runCatching { exo?.let { it.stop(); it.clearMediaItems() } }
        exoItemGen = -1
        exoItemUrl = null
        exoSurface.visibility = View.GONE
        videoLayout.visibility = View.VISIBLE
        scheduleBufferingWatchdog(gen)
        val url = ch.url
        vlcExec.execute {
            if (gen != playGen.get()) return@execute
            var candidate: Media? = null
            try {
                candidate = Media(libVLC, Uri.parse(url))
                candidate.setHWDecoderEnabled(true, false)
                candidate.addOption(":network-caching=2000")
                candidate.addOption(":live-caching=2000")

                // Media hazırlanarkən istifadəçi başqa kanala keçmiş ola bilər.
                if (gen != playGen.get()) {
                    candidate.release()
                    candidate = null
                    return@execute
                }
                // MediaPlayer.media-nin dəyişdirilməsi mövcud VLC axınını əvəz edir.
                // Burada ayrıca stop() çağırmırıq: ilişmiş axında native stop gecikə və
                // növbəti kanal əmrlərini eyni worker növbəsində saxlaya bilər.
                if (gen != playGen.get()) {
                    candidate.release()
                    candidate = null
                    return@execute
                }

                val old = curMedia
                vlcPlayGen = gen
                player.media = candidate
                curMedia = candidate
                candidate = null // media artıq MediaPlayer-ə məxsusdur
                runCatching { old?.release() }
                if (gen != playGen.get()) return@execute
                player.play()
                runOnUiThread {
                    if (gen == playGen.get() && vlcPlayGen == gen && !usingExo) applyStretch()
                }
            } catch (t: Throwable) {
                candidate?.let { runCatching { it.release() } }
                runOnUiThread {
                    if (gen == playGen.get() && !isDestroyed && !isFinishing) {
                        if (!fallbackTried) {
                            fallbackTried = true
                            playExo(ch, gen)
                        } else {
                            cancelBufferingWatchdog()
                            progress.visibility = View.GONE
                            status.text = "Kanal açılmadı"
                            status.visibility = View.VISIBLE
                        }
                    }
                }
            }
        }
    }

    private fun playExo(ch: Channel, gen: Int = playGen.get()) {
        if (gen != playGen.get() || isDestroyed || isFinishing) return
        usingExo = true
        playbackReady = false
        cancelBufferingWatchdog()
        exoItemGen = gen
        exoItemUrl = ch.url
        // Stop yalnız bu kanal seçimi hələ aktualdırsa icra edilir; köhnə stop yeni VLC-ni kəsməsin.
        vlcExec.execute { if (gen == playGen.get()) runCatching { player.stop() } }
        videoLayout.visibility = View.INVISIBLE
        exoSurface.visibility = View.VISIBLE
        scheduleBufferingWatchdog(gen)
        try {
            val p = exo ?: createExo().also { exo = it }
            val b = MediaItem.Builder().setUri(ch.url)
            if (ch.url.lowercase().contains(".mpd")) b.setMimeType(MimeTypes.APPLICATION_MPD)
            if (gen != playGen.get()) return
            p.setMediaItem(b.build())
            p.prepare()
            p.playWhenReady = true
        } catch (t: Throwable) {
            if (gen != playGen.get()) return
            if (!fallbackTried) {
                fallbackTried = true
                playVlc(ch, gen)
            } else {
                cancelBufferingWatchdog()
                progress.visibility = View.GONE
                status.text = "Kanal açılmadı"
                status.visibility = View.VISIBLE
            }
        }
    }

    private fun createExo(): ExoPlayer {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(2500)
            .setReadTimeoutMs(4500)
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) MehdiPlayer")
        // Canlı yayım üçün ehtiyat buferi artırılır; rebuffer olduqda yenidən oynamağa
        // başlamazdan əvvəl bir qədər artıq məlumat toplamaq xırda şəbəkə kəsilmələrini azaldır.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(8000, 45000, 800, 1800)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        val p = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .build()
        p.setVideoSurfaceView(exoSurface)
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (!isCurrentExoPlayback(p)) return
                when (state) {
                    Player.STATE_BUFFERING -> {
                        progress.visibility = View.VISIBLE
                        playbackReady = false
                        scheduleBufferingWatchdog(exoItemGen)
                    }
                    Player.STATE_READY -> {
                        playbackReady = true
                        cancelBufferingWatchdog()
                        progress.visibility = View.GONE
                        status.visibility = View.GONE
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (!isCurrentExoPlayback(p)) return
                val gen = exoItemGen
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    runCatching { p.seekToDefaultPosition(); p.prepare() }
                    return
                }
                val c = current ?: return
                if (!fallbackTried) {
                    fallbackTried = true
                    playVlc(c, gen) // Media3 axını aça bilmirsə VLC ilə ehtiyat cəhd
                    return
                }
                cancelBufferingWatchdog()
                progress.visibility = View.GONE
                status.text = "Kanal açılmadı"
                status.visibility = View.VISIBLE
            }
        })
        return p
    }

    private fun isCurrentExoPlayback(p: ExoPlayer): Boolean =
        !isDestroyed && !isFinishing && usingExo && exo === p &&
            exoItemGen == playGen.get() && exoItemUrl == current?.url

    private fun cancelBufferingWatchdog() {
        bufferingWatchdog?.let { handler.removeCallbacks(it) }
        bufferingWatchdog = null
        bufferingWatchdogGen = -1
    }

    /** Sonsuz buffering baş verərsə alternativ pleyerə keçir; ikinci pleyer də ilişərsə xəbər verir. */
    private fun scheduleBufferingWatchdog(gen: Int) {
        // VLC buffering faizi çoxsaylı hadisələr göndərə bilər. Eyni kanal üçün vaxtı
        // hər faiz yenilənməsində sıfırlamırıq ki, ilişmiş axın heç vaxt timeout-dan qaçmasın.
        if (bufferingWatchdog != null && bufferingWatchdogGen == gen) return
        cancelBufferingWatchdog()
        val task = Runnable {
            bufferingWatchdog = null
            bufferingWatchdogGen = -1
            if (gen != playGen.get() || isDestroyed || isFinishing || playbackReady) return@Runnable
            val ch = current ?: return@Runnable
            if (usingExo && (exoItemGen != gen || exoItemUrl != ch.url)) return@Runnable
            if (!fallbackTried) {
                fallbackTried = true
                if (usingExo) playVlc(ch, gen) else playExo(ch, gen)
            } else {
                progress.visibility = View.GONE
                status.text = "Yayım donur. Başqa kanal seçin."
                status.visibility = View.VISIBLE
                if (usingExo) runCatching { exo?.pause() }
                else vlcExec.execute { if (gen == playGen.get()) runCatching { player.pause() } }
            }
        }
        bufferingWatchdog = task
        bufferingWatchdogGen = gen
        handler.postDelayed(task, bufferingTimeoutMs)
    }

    private fun neighbor(base: Channel?, d: Int): Channel? {
        val l = listFor(playGroup).ifEmpty { all }
        if (l.isEmpty()) return null
        val i = l.indexOfFirst { it.url == base?.url }
        return l[((if (i < 0) 0 else i + d) + l.size) % l.size]
    }

    private fun step(d: Int) {
        previewCh = null
        handler.removeCallbacks(commitRun)
        neighbor(current, d)?.let { play(it, playGroup, d) }
    }

    /** Sol/sağ düyməni basıb saxlayanda kanallar sürətlə dəyişir; kanal düymə buraxılanda açılır. */
    private fun fastStep(d: Int) {
        val now = SystemClock.uptimeMillis()
        if (now - lastFastStep < 110) return
        lastFastStep = now
        val ch = neighbor(previewCh ?: current, d) ?: return
        previewCh = ch
        showInfo(ch, d)
        handler.removeCallbacks(commitRun)
        handler.postDelayed(commitRun, 450)
    }

    /** Yalnız ekran nisbətinə uyğun gəlməyən (tam ekranı doldurmayan) videoları uzat. */
    private fun applyStretch() {
        val dm = resources.displayMetrics
        val screenW = if (videoLayout.width > 0) videoLayout.width else dm.widthPixels
        val screenH = if (videoLayout.height > 0) videoLayout.height else dm.heightPixels
        // LibVLC's MediaPlayer does not expose videoWidth/videoHeight as Kotlin properties.
        // Read dimensions from its video-track API reflectively to stay compatible with
        // the LibVLC versions used by this project.
        val videoTrack = runCatching {
            player.javaClass.methods.firstOrNull { it.name == "getVideoTracks" && it.parameterCount == 0 }
                ?.invoke(player)?.let { tracks ->
                    when (tracks) {
                        is Array<*> -> tracks.firstOrNull()
                        is Iterable<*> -> tracks.firstOrNull()
                        else -> null
                    }
                }
        }.getOrNull()
        fun trackDimension(vararg names: String): Int = runCatching {
            val getter = videoTrack?.javaClass?.methods?.firstOrNull {
                it.parameterCount == 0 && it.name in names
            }
            (getter?.invoke(videoTrack) as? Number)?.toInt() ?: 0
        }.getOrDefault(0)
        val videoW = trackDimension("getWidth", "getVideoWidth", "width")
        val videoH = trackDimension("getHeight", "getVideoHeight", "height")

        if (screenW <= 0 || screenH <= 0 || videoW <= 0 || videoH <= 0) return

        val screenRatio = screenW.toFloat() / screenH.toFloat()
        val videoRatio = videoW.toFloat() / videoH.toFloat()
        // Ekranı onsuz da dolduran videonun nisbətini dəyişmə; yalnız fərqli nisbətli videoları uzat.
        runCatching {
            if (kotlin.math.abs(videoRatio - screenRatio) / screenRatio <= 0.03f) {
                player.setAspectRatio(null)
            } else {
                player.setAspectRatio("$screenW:$screenH")
            }
            player.setScale(0f)
        }
    }

    /** Kanal dəyişəndə/seçiləndə aşağıda məlumat yüngül animasiya ilə göstərilir, sonra silinir. */
    private fun showInfo(ch: Channel, dir: Int = 0) {
        infoShown = ch
        val l = listFor(playGroup).ifEmpty { all }
        val idx = (l.indexOfFirst { it.url == ch.url } + 1).coerceAtLeast(1)
        infoName.text = "${ch.name}  •  $idx/${l.size}  •  ${playGroup ?: "Hamısı"}"
        updateInfoExtras(ch)
        infoLogo.setImageDrawable(null)
        infoBar.animate().cancel()
        if (dir != 0) {
            infoBar.translationX = dp(48).toFloat() * dir
            infoBar.alpha = 0.3f
            infoBar.visibility = View.VISIBLE
            infoBar.animate().translationX(0f).alpha(1f).setDuration(120).start()
        } else {
            infoBar.translationX = 0f
            infoBar.alpha = 1f
            infoBar.visibility = View.VISIBLE
        }
        lifecycleScope.launch(safeHandler) {
            val bmp = logos.bitmapFor(ch)
            if (bmp != null && infoShown == ch) infoLogo.setImageBitmap(bmp)
        }
        handler.removeCallbacks(hideInfoRun)
        handler.postDelayed(hideInfoRun, 4000)
    }

    // ---------- channel panel ----------
    // ---------- tam ekran: qruplar (sol) + kanallar (sağ) ----------
    private fun showBrowserChannels() {
        val l = listFor(browserGroup)
        rowAdapter.items = l
        rowAdapter.playingUrl = current?.url
        rowAdapter.notifyDataSetChanged()
        browserTitle.text = "${browserGroup ?: "Hamısı"}  (${l.size})"
    }

    private fun adjustChannelColumns() {
        val layout = channelsList.layoutManager as? GridLayoutManager ?: return
        val available = channelsList.width
        if (available <= 0) return
        // Geniş ekranda daha çox kanal eyni anda görünür; kiçik ekranda sütun sayı azalır.
        val desired = (available.toFloat() / dp(270).coerceAtLeast(1)).roundToInt().coerceIn(2, 5)
        if (layout.spanCount != desired) layout.spanCount = desired
    }

    private fun focusPos(rv: RecyclerView, idx: Int) {
        val layout = rv.layoutManager as? LinearLayoutManager ?: return
        layout.scrollToPositionWithOffset(idx, if (rv == channelsList) dp(24) else dp(120))
        rv.postDelayed({ rv.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }, 90)
    }

    private fun setBrowser(show: Boolean) {
        if (!show) { browser.visibility = View.GONE; return }
        handler.removeCallbacks(hidePanelRun)
        handler.removeCallbacks(hideInfoRun)
        setPanel(false)
        infoBar.visibility = View.GONE
        browserGroup = playGroup
        groupAdapter.items = groupList
        groupAdapter.selected = browserGroup
        groupAdapter.notifyDataSetChanged()
        showBrowserChannels()
        browser.visibility = View.VISIBLE
        groupsList.scrollToPosition(groupList.indexOf(browserGroup).coerceAtLeast(0))
        focusPos(channelsList, rowAdapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0))
    }

    private fun handleBrowserKey(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val f = currentFocus
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> if (f != null) {
                    val channelItem = channelsList.findContainingItemView(f)
                    if (channelItem != null) {
                        val pos = channelsList.getChildAdapterPosition(channelItem)
                        val grid = channelsList.layoutManager as? GridLayoutManager
                        // Sol kənardakı sütundan qruplara keç; daxili sütunlarda adi sol hərəkət qalsın.
                        if (pos != RecyclerView.NO_POSITION && grid != null && pos % grid.spanCount == 0) {
                            focusPos(groupsList, groupList.indexOf(browserGroup).coerceAtLeast(0))
                            return true
                        }
                    }
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (f != null && groupsList.findContainingItemView(f) != null) {
                    focusPos(channelsList, if (browserGroup == playGroup)
                        rowAdapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0) else 0)
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun setPanel(show: Boolean) {
        handler.removeCallbacks(hidePanelRun)
        panel.animate().cancel()
        panelBody.animate().cancel()
        switching = false
        if (show) {
            handler.removeCallbacks(hideInfoRun)
            infoBar.visibility = View.GONE
            browseGroup = playGroup
            panelBody.translationY = 0f
            panelBody.alpha = 1f
            loadBrowse()
            panel.alpha = 0f
            panel.visibility = View.VISIBLE
            panel.animate().alpha(1f).setDuration(150).start()
            focusedCh = current
            renderDetail()
            focusCurrent()
            handler.postDelayed(hidePanelRun, 10000)
        } else {
            panel.visibility = View.GONE
        }
    }

    private fun loadBrowse() {
        val l = listFor(browseGroup)
        adapter.items = l
        adapter.playingUrl = current?.url
        adapter.notifyDataSetChanged()
        val gi = groupList.indexOf(browseGroup).coerceAtLeast(0)
        groupTitle.text = "${browseGroup ?: "Hamısı"}  (${l.size})      ${gi + 1}/${groupList.size}"
    }

    private fun focusCurrent() {
        val idx = adapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0)
        (list.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(400))
        list.postDelayed({ list.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }, 70)
    }

    /** Yuxarı/aşağı: qonşu qrupa yüngül sürüşmə animasiyası ilə keçid. */
    private fun switchGroup(d: Int) {
        if (switching || groupList.size < 2) return
        switching = true
        val gi = groupList.indexOf(browseGroup).coerceAtLeast(0)
        val next = groupList[(gi + d + groupList.size) % groupList.size]
        val dist = dp(56).toFloat() * d
        panelBody.animate().translationY(-dist).alpha(0f).setDuration(110).withEndAction {
            browseGroup = next
            loadBrowse()
            panelBody.translationY = dist
            panelBody.animate().translationY(0f).alpha(1f).setDuration(160)
                .withEndAction { switching = false }.start()
            focusCurrent()
        }.start()
    }

    // ---------- remote control ----------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (epgFullShown()) return super.dispatchKeyEvent(e)
        if (browserShown()) return handleBrowserKey(e)
        if (e.action == KeyEvent.ACTION_UP && previewCh != null) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_CHANNEL_UP,
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    handler.removeCallbacks(commitRun); commitRun.run(); return true
                }
            }
        }
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (panelShown()) {
                handler.removeCallbacks(hidePanelRun)
                handler.postDelayed(hidePanelRun, 10000)
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { if (e.repeatCount == 0) switchGroup(-1); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { if (e.repeatCount == 0) switchGroup(1); return true }
                }
                return super.dispatchKeyEvent(e) // sol/sağ/OK: kanal seçimi
            }
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_MENU -> {
                    if (e.repeatCount == 0) setPanel(true); return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    // OK: yalnız indi baxılan kanalın alt zolağı (kanal dəyişəndə çıxan kimi).
                    // Zolaq açıq olarkən ikinci OK: tam proqram cədvəli.
                    if (e.repeatCount == 0) {
                        val c = current
                        if (c != null) {
                            if (infoBar.visibility == View.VISIBLE && infoShown?.url == c.url) setEpgFull(true, c)
                            else showInfo(c)
                        }
                    }
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> return true
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    if (e.repeatCount == 0) step(-1) else fastStep(-1); return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    if (e.repeatCount == 0) step(1) else fastStep(1); return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (usingExo) exo?.let { it.playWhenReady = !it.playWhenReady }
                    else if (player.isPlaying) player.pause() else player.play()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // ---------- EPG + resolution ----------
    private fun reloadEpg() {
        val chs = all
        if (chs.isEmpty()) return
        lifecycleScope.launch(safeHandler) {
            logos.beginBatch() // loqolar tam yenilənənə qədər kartlar tək-tək endirməsin
            try {
                // 0) ikinci loqo mənbəyinin telefondakı nüsxəsi dərhal oxunur (kanal adı ilə oxşar ad axtarışı üçün)
                logos.loadExtra(false)
                // 1) telefondakı EPG dərhal; 2) mənbədə yenilik varsa tam endirilib bir anda əvəz olunur
                if (epg.loadCached(chs)) refreshEpgUi()
                if (epg.update(chs, true)) refreshEpgUi() // açılışda mənbədə yenilik məcburi yoxlanılır
                // 2b) ikinci loqo mənbəyi yenilənir (dəyişibsə kartlar yenilənir)
                if (logos.loadExtra(true)) refreshEpgUi()
                // 3) loqolar: hamısı paralel endirilir, tam bitəndən sonra birdən dəyişir
                val n = logos.refreshAll(all, epg.consumeSourceUpdated())
                if (n > 0) refreshEpgUi()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (t: Throwable) {
                // şəbəkə/yaddaş xətası tətbiqi çökdürməsin: köhnə EPG/loqolar qalır
            } finally {
                logos.endBatch()
            }
            refreshEpgUi() // gözləyən kartlar yeni loqonu göstərsin
        }
    }

    /**
     * Kanal dəyişəndə şəbəkədən EPG yoxlanılmır (EPG mənbəyi əsasən açılışda yoxlanılır). Yalnız bu kanalın proqramı
     * köhnəlibsə telefondakı EPG faylından yenilənir; kanalın loqosu mənbədə dəyişibsə yalnız o halda əvəz olunur.
     */
    private var switchedJob: Job? = null
    private fun onChannelSwitched(ch: Channel) {
        // Sürətli dəyişmədə köhnə yoxlamalar ləğv olunur, yalnız son kanal üçün icra edilir.
        switchedJob?.cancel()
        switchedJob = lifecycleScope.launch(safeHandler) {
            kotlinx.coroutines.delay(700)
            if (epg.refreshChannel(ch, all)) refreshEpgUi()
            if (logos.refreshChannel(ch)) {
                if (infoShown == ch) logos.bitmapFor(ch)?.let { infoLogo.setImageBitmap(it) }
                adapter.notifyDataSetChanged(); rowAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun epgFullShown() = epgFull.visibility == View.VISIBLE

    private fun setEpgFull(show: Boolean, ch: Channel? = null) {
        if (!show) { epgFull.visibility = View.GONE; epgFullCh = null; return }
        if (ch == null) return
        handler.removeCallbacks(hidePanelRun); handler.removeCallbacks(hideInfoRun)
        setPanel(false)
        infoBar.visibility = View.GONE
        epgFullCh = ch
        epgFullTitle.text = "${ch.number}. ${ch.name}"
        epgFullLogo.setImageDrawable(null)
        lifecycleScope.launch(safeHandler) {
            val b = logos.bitmapFor(ch)
            if (b != null && epgFullCh == ch) epgFullLogo.setImageBitmap(b)
        }
        val list = epg.programs(ch)
        val nowStart = epg.nowNext(ch).first?.start ?: -1L
        progAdapter.items = list
        progAdapter.nowStart = nowStart
        progAdapter.notifyDataSetChanged()
        epgFullEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        epgFull.visibility = View.VISIBLE
        val idx = list.indexOfFirst { it.start == nowStart }.coerceAtLeast(0)
        (epgFullList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(40))
        epgFullList.postDelayed({ epgFullList.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }, 90)
    }

    private fun refreshEpgUi() {
        adapter.notifyDataSetChanged(); rowAdapter.notifyDataSetChanged()
        renderDetail()
        current?.let { updateInfoExtras(it) }
    }

    /** Alt zolaqda kanal adının altında: indi gedən proqram, onun altında növbəti proqram. */
    private fun updateInfoExtras(ch: Channel) {
        if (infoShown != ch) return
        val (n, x) = epg.nowNext(ch)
        if (n != null) {
            infoEpg.text = hm(n.start) + "–" + hm(n.stop) + "  " + n.title
            infoEpg.visibility = View.VISIBLE
        } else {
            infoEpg.text = ""
            infoEpg.visibility = View.GONE
        }
        if (x != null) {
            infoNext.text = "Sonra:  " + hm(x.start) + "  " + x.title
            infoNext.visibility = View.VISIBLE
        } else {
            infoNext.text = ""
            infoNext.visibility = View.GONE
        }
    }

    /** OK ilə açılan bölmədə fokuslanan kanalın ətraflı məlumatı. */
    private fun renderDetail() {
        if (!panelShown()) return
        val ch = focusedCh ?: current ?: return
        val (n, x) = epg.nowNext(ch)
        detNow.text = if (n != null) "Hazırda:  ${hm(n.start)}–${hm(n.stop)}  ${n.title}" else "Proqram məlumatı yoxdur"
        detNext.text = if (x != null) "Sonra:  ${hm(x.start)}  ${x.title}" else ""

        detDesc.text = n?.desc.orEmpty()
    }

    // ---------- lifecycle ----------
    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onStart() {
        super.onStart()
        runCatching { player.attachViews(videoLayout, null, false, false) }
        // İlk açılışda və ya arxa plandan qayıdanda yalnız lazım olduqda axını başladırıq.
        if (stoppedForLifecycle) {
            stoppedForLifecycle = false
            current?.let { play(it, playGroup) }
        }
    }

    override fun onStop() {
        super.onStop()
        stoppedForLifecycle = true
        pendingPlay?.let { handler.removeCallbacks(it) }; pendingPlay = null
        cancelBufferingWatchdog()
        playbackReady = false
        playGen.incrementAndGet() // gözləyən başlatmalar ləğv olunur
        // stop() şəbəkədə bloklana bilər: UI thread-də yox, VLC thread-ində icra olunur.
        runCatching { exo?.stop() }
        vlcExec.execute { runCatching { player.stop() } }
        runCatching { player.detachViews() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        bufferingWatchdog = null
        bufferingWatchdogGen = -1
        pendingPlay = null
        playGen.incrementAndGet()
        runCatching { exo?.release() }
        exo = null
        runCatching { player.setEventListener(null) }
        // Native release-lər sıralanmış şəkildə VLC thread-ində; sonra thread dayandırılır.
        vlcExec.execute {
            runCatching { player.stop() }
            runCatching { player.release() }
            runCatching { curMedia?.release() }; curMedia = null
            runCatching { libVLC.release() }
        }
        vlcExec.shutdown()
        super.onDestroy()
    }
}
