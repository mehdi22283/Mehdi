package az.telefonum.burdayam

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class ListenService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    companion object {
        const val CH = "listen"
        const val ACTION_STOP = "az.telefonum.burdayam.STOP"
        const val ACTION_TEST = "az.telefonum.burdayam.TEST"
        @Volatile var running = false

        private val BASE_TRIGGERS = listOf(
            "telefonum han", "telefon han", "telefonum harda", "telefonum nerde",
            "telefonum neredesin", "where is my phone", "where's my phone"
        )

        fun norm(s: String): String = s.lowercase(Locale.ROOT)
            .replace("\u0307", "")
            .replace('ı', 'i').replace('ə', 'e').replace('ö', 'o')
            .replace('ü', 'u').replace('ş', 's').replace('ç', 'c').replace('ğ', 'g')
            .replace(Regex("[^a-z0-9' ]"), " ")
            .replace(Regex("\\s+"), " ").trim()
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var responding = false
    private var oldAlarmVol = -1
    private var lang = "az-AZ"
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        val options = listOf(Locale("az", "AZ"), Locale("tr", "TR"), Locale.getDefault())
        for (l in options) {
            val r = t.isLanguageAvailable(l)
            if (r >= TextToSpeech.LANG_AVAILABLE) {
                t.language = l
                break
            }
        }
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setSpeechRate(0.8f)
        t.setPitch(1.1f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == "last") handler.post { finishRespond() }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == "last") handler.post { finishRespond() }
            }
        })
        ttsReady = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        when (intent?.action) {
            ACTION_STOP -> {
                running = false
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TEST -> {
                running = true
                respond()
            }
            else -> {
                running = true
                startListening()
            }
        }
        return START_STICKY
    }

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH, "Dinləmə", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setContentTitle("Telefonum hanı?")
            .setContentText("Dinləyirəm... \"Telefonum hanı?\" deyin")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    // ---------- Listening ----------

    private fun startListening() {
        if (!running || responding) return
        handler.post {
            try {
                recognizer?.destroy()
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                    it.setRecognitionListener(this)
                }
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
                recognizer?.startListening(i)
            } catch (e: Exception) {
                restartLater(1500)
            }
        }
    }

    private fun restartLater(ms: Long) {
        handler.postDelayed({ startListening() }, ms)
    }

    private fun checkMatch(list: List<String>?): Boolean {
        if (list == null) return false
        val custom = norm(getSharedPreferences("p", MODE_PRIVATE).getString("phrase", "") ?: "")
        for (raw in list) {
            val t = norm(raw)
            if (BASE_TRIGGERS.any { t.contains(it) }) return true
            if (custom.length >= 3 && t.contains(custom)) return true
        }
        return false
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val l = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!responding && checkMatch(l)) respond()
    }

    override fun onResults(results: Bundle?) {
        val l = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!responding && checkMatch(l)) respond() else restartLater(150)
    }

    override fun onError(error: Int) {
        if (responding) return
        when (error) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                running = false
                stopSelf()
            }
            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, 13 -> {
                lang = "tr-TR"
                restartLater(500)
            }
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restartLater(150)
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restartLater(1200)
            else -> restartLater(1500)
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    // ---------- Responding ----------

    private fun respond() {
        if (responding) return
        responding = true
        handler.post { try { recognizer?.cancel() } catch (_: Exception) {} }

        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "burdayam:wake")
            wake?.acquire(30_000)
        } catch (_: Exception) {}

        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        try {
            oldAlarmVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        } catch (_: Exception) {}

        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500, 200, 500), -1))
        } catch (_: Exception) {}

        try {
            ToneGenerator(AudioManager.STREAM_ALARM, 100)
                .startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500)
        } catch (_: Exception) {}

        handler.postDelayed({ speak() }, 600)
    }

    private fun speak() {
        val t = tts
        if (t == null || !ttsReady) {
            // TTS yoxdursa, sadəcə siqnal səsi
            try {
                ToneGenerator(AudioManager.STREAM_ALARM, 100)
                    .startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1500)
            } catch (_: Exception) {}
            handler.postDelayed({ finishRespond() }, 2000)
            return
        }
        val p = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_ALARM.toString())
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }
        t.speak("Burdayaaaam!", TextToSpeech.QUEUE_FLUSH, p, "r1")
        t.speak("Burdayaaaam!", TextToSpeech.QUEUE_ADD, p, "r2")
        t.speak("Mən buradayam!", TextToSpeech.QUEUE_ADD, p, "last")
        // təhlükəsizlik: 15 saniyədən sonra mütləq bitir
        handler.postDelayed({ if (responding) finishRespond() }, 15_000)
    }

    private fun finishRespond() {
        if (!responding) return
        responding = false
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            if (oldAlarmVol >= 0) am.setStreamVolume(AudioManager.STREAM_ALARM, oldAlarmVol, 0)
        } catch (_: Exception) {}
        try { wake?.release() } catch (_: Exception) {}
        if (running) restartLater(800)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (_: Exception) {}
        try { tts?.shutdown() } catch (_: Exception) {}
        try { wake?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
