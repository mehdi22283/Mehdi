package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.*
import androidx.media3.common.*
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.LoadEventInfo
import androidx.media3.exoplayer.source.MediaLoadData
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

class QItem(val name: String, val url: String, val hdr: String)
object PlayQueue { var items: List<QItem> = emptyList(); var index = 0 }

/** Portret oynadıcı. Mühərrik seçimi: Media3/ExoPlayer və ya LibVLC. Əvvəlki/sonrakı kanal. */
class PlayerActivity : Activity() {
    private var exo: ExoPlayer? = null
    private var vlcLib: LibVLC? = null
    private var vlc: MediaPlayer? = null
    private lateinit var pv: PlayerView
    private lateinit var vl: VLCVideoLayout
    private lateinit var statsTv: TextView
    private lateinit var nameTv: TextView
    private lateinit var engBtn: Button
    private val h = Handler(Looper.getMainLooper())
    private var engine = "exo"
    private var url = ""
    @Volatile private var target = Net.Target("", emptyMap(), "")
    private var profiles: List<Net.Target> = emptyList()
    private var pIdx = 0
    private var msg = ""
    private var gen = 0
    private var latency = -1L
    private var speedBps = -1L
    private var prevAhead = -1L
    private var vlcBuf = 100f
    private var vlcPlaying = false
    private var speed = 1f
    private var resizeIdx = 0
    private var alive = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        engine = getSharedPreferences("m3u", MODE_PRIVATE).getString("engine", "exo") ?: "exo"
        pv = PlayerView(this)
        pv.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        vl = VLCVideoLayout(this)
        statsTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; setPadding(14, 6, 14, 6) }
        nameTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER; maxLines = 2 }
        engBtn = btn("") { switchEngine() }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(btn("⏮") { step(-1) })
            addView(nameTv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(btn("⏭") { step(1) })
        }
        val tools = HorizontalScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(engBtn)
                addView(btn("⏯") { togglePlay() })
                addView(btn("🔲 Keyfiyyət") { pick(0) })
                addView(btn("⏩ Sürət") { pickSpeed() })
                addView(btn("🔊 Səs") { pick(1) })
                addView(btn("💬 Altyazı") { pick(2) })
                addView(btn("🖼 Görünüş") { cycleResize() })
                addView(btn("🔄 Yenilə") { loadCurrent() })
            })
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x66000000.toInt())
            addView(statsTv); addView(nav); addView(tools)
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(pv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(vl, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(top, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.TOP))
        })
        applyEngineViews()
        loadCurrent(); tick(); probeLoop()
    }

    private fun btn(t: String, f: () -> Unit): Button =
        Button(this).apply { text = t; textSize = 11f; isAllCaps = false; setOnClickListener { f() } }

    private fun applyEngineViews() {
        pv.visibility = if (engine == "exo") View.VISIBLE else View.GONE
        vl.visibility = if (engine == "vlc") View.VISIBLE else View.GONE
        engBtn.text = if (engine == "vlc") "⚙ VLC ⇄" else "⚙ ExoPlayer ⇄"
    }

    private fun switchEngine() {
        engine = if (engine == "exo") "vlc" else "exo"
        getSharedPreferences("m3u", MODE_PRIVATE).edit().putString("engine", engine).apply()
        gen++
        releaseExo(); releaseVlc()
        applyEngineViews()
        loadCurrent()
    }

    // ---------- kanal naviqasiyası ----------
    private fun loadCurrent() {
        val cur = PlayQueue.items.getOrNull(PlayQueue.index) ?: return
        nameTv.text = "${PlayQueue.index + 1}/${PlayQueue.items.size}  ${cur.name}"
        url = cur.url
        profiles = Net.profiles(cur.url, cur.hdr); pIdx = 0
        msg = ""; prevAhead = -1; latency = -1; speedBps = -1; vlcBuf = 100f; vlcPlaying = false
        begin()
    }

    private fun step(d: Int) {
        val n = PlayQueue.items.size
        if (n == 0) return
        PlayQueue.index = (PlayQueue.index + d + n) % n
        loadCurrent()
    }

    // ---------- ortaq başlatma / xəta ----------
    private fun begin() {
        val t = profiles[pIdx]; target = t
        gen++
        val my = gen
        prevAhead = -1
        if (engine == "vlc") startVlc(t)
        else Thread {
            val hls = try { Net.isHls(t) } catch (e: Exception) { false }
            runOnUiThread { if (alive && my == gen && engine == "exo") startExo(t, hls) }
        }.start()
    }

    private fun onEngineError(d: String) {
        if (pIdx < profiles.size - 1) {
            pIdx++; msg = "🔁 Profil: ${profiles[pIdx].name} ($d)"; begin()
        } else {
            msg = "❌ $d"; pIdx = 0
            val g = gen
            h.postDelayed({ if (alive && g == gen) begin() }, 5000)
        }
    }

    // ---------- ExoPlayer (Media3) ----------
    private fun ensureExo(): ExoPlayer {
        exo?.let { return it }
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000).setReadTimeoutMs(10000)
        val ds = ResolvingDataSource.Factory(http, ResolvingDataSource.Resolver { spec -> spec.withAdditionalHeaders(target.headers) })
        val p = ExoPlayer.Builder(this).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { msg = ""; Net.markGood(target.url, target.name) }
            }
            override fun onPlayerError(e: PlaybackException) { onEngineError(errText(e)) }
        })
        p.addAnalyticsListener(object : AnalyticsListener {
            override fun onLoadCompleted(t: AnalyticsListener.EventTime, i: LoadEventInfo, d: MediaLoadData) {
                if (i.loadDurationMs > 0) speedBps = i.bytesLoaded * 8000 / i.loadDurationMs
            }
        })
        p.setPlaybackSpeed(speed)
        pv.player = p
        pv.resizeMode = intArrayOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM)[resizeIdx]
        exo = p
        return p
    }

    private fun startExo(t: Net.Target, hls: Boolean) {
        val p = ensureExo()
        val mi = MediaItem.Builder().setUri(t.url)
        if (hls) mi.setMimeType(MimeTypes.APPLICATION_M3U8)
        p.setMediaItem(mi.build()); p.prepare(); p.playWhenReady = true
    }

    private fun errText(e: PlaybackException): String {
        var c: Throwable? = e.cause
        var code = ""
        while (c != null) {
            if (c is HttpDataSource.InvalidResponseCodeException) { code = " HTTP " + c.responseCode; break }
            c = c.cause
        }
        return e.errorCodeName + code + (e.cause?.message?.let { " – $it" } ?: "")
    }

    private fun releaseExo() { pv.player = null; exo?.release(); exo = null }

    // ---------- LibVLC ----------
    private fun startVlc(t: Net.Target) {
        val lib = vlcLib ?: LibVLC(this, arrayListOf("--http-reconnect", "--network-caching=2000")).also { vlcLib = it }
        val p = vlc ?: MediaPlayer(lib).also { vp ->
            vp.attachViews(vl, null, false, false)
            vp.setEventListener(object : MediaPlayer.EventListener {
                override fun onEvent(event: MediaPlayer.Event) { onVlcEvent(event) }
            })
            vlc = vp
        }
        val m = Media(lib, Uri.parse(t.url))
        t.headers["User-Agent"]?.let { m.addOption(":http-user-agent=$it") }
        t.headers["Referer"]?.let { m.addOption(":http-referrer=$it") }
        m.addOption(":network-caching=2000")
        p.setMedia(m)
        m.release()
        p.play()
        p.setRate(speed)
        applyResize()
    }

    private fun onVlcEvent(e: MediaPlayer.Event) {
        when (e.type) {
            MediaPlayer.Event.Playing -> { vlcPlaying = true; msg = ""; Net.markGood(target.url, target.name) }
            MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> vlcPlaying = false
            MediaPlayer.Event.Buffering -> vlcBuf = e.buffering
            MediaPlayer.Event.EncounteredError -> { vlcPlaying = false; onEngineError("VLC xətası") }
            else -> {}
        }
    }

    private fun releaseVlc() {
        vlc?.let { it.setEventListener(null); it.stop(); it.detachViews(); it.release() }
        vlcLib?.release()
        vlc = null; vlcLib = null
    }

    // ---------- idarəetmə ----------
    private fun togglePlay() {
        if (engine == "vlc") { val p = vlc; if (p != null) { if (p.isPlaying) p.pause() else p.play() } }
        else { val p = exo; if (p != null) p.playWhenReady = !p.playWhenReady }
    }

    private fun pick(kind: Int) {
        val titles = arrayOf("Keyfiyyət (resolution)", "Səs yolu", "Altyazı")
        if (engine == "vlc") pickVlc(kind, titles[kind])
        else pickExo(intArrayOf(C.TRACK_TYPE_VIDEO, C.TRACK_TYPE_AUDIO, C.TRACK_TYPE_TEXT)[kind], titles[kind])
    }

    private fun pickExo(type: Int, title: String) {
        val p = exo ?: return
        val names = mutableListOf(if (type == C.TRACK_TYPE_TEXT) "Söndür" else "Avto")
        val refs = mutableListOf<Pair<TrackGroup, Int>>()
        for (g in p.currentTracks.groups) if (g.type == type) for (i in 0 until g.length) {
            if (!g.isTrackSupported(i)) continue
            val f = g.getTrackFormat(i)
            names.add(when (type) {
                C.TRACK_TYPE_VIDEO -> "${f.height}p" + if (f.bitrate > 0) "  ${f.bitrate / 1000} kbps" else ""
                else -> (f.label ?: f.language ?: "Yol ${refs.size + 1}") + if (f.channelCount > 0) "  ${f.channelCount}ch" else ""
            })
            refs.add(g.mediaTrackGroup to i)
        }
        AlertDialog.Builder(this).setTitle(title).setItems(names.toTypedArray()) { _, w ->
            val b = p.trackSelectionParameters.buildUpon().clearOverridesOfType(type)
            if (w == 0) b.setTrackTypeDisabled(type, type == C.TRACK_TYPE_TEXT)
            else { b.setTrackTypeDisabled(type, false); b.setOverrideForType(TrackSelectionOverride(refs[w - 1].first, refs[w - 1].second)) }
            p.trackSelectionParameters = b.build()
        }.show()
    }

    private fun pickVlc(kind: Int, title: String) {
        val p = vlc ?: return
        val tracks = when (kind) { 0 -> p.getVideoTracks(); 1 -> p.getAudioTracks(); else -> p.getSpuTracks() }
        if (tracks == null || tracks.isEmpty()) { Toast.makeText(this, "Yol tapılmadı", Toast.LENGTH_SHORT).show(); return }
        val names = tracks.map { it.name ?: ("Yol " + it.id) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(title).setItems(names) { _, w ->
            val id = tracks[w].id
            when (kind) { 0 -> p.setVideoTrack(id); 1 -> p.setAudioTrack(id); else -> p.setSpuTrack(id) }
        }.show()
    }

    private fun pickSpeed() {
        val v = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        AlertDialog.Builder(this).setTitle("Sürət").setItems(v.map { "${it}x" }.toTypedArray()) { _, w ->
            speed = v[w]
            exo?.setPlaybackSpeed(speed)
            vlc?.setRate(speed)
        }.show()
    }

    private fun cycleResize() {
        resizeIdx = (resizeIdx + 1) % 3
        pv.resizeMode = intArrayOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM)[resizeIdx]
        applyResize()
        Toast.makeText(this, listOf("Sığdır", "Uzat", "Yaxınlaşdır")[resizeIdx], Toast.LENGTH_SHORT).show()
    }

    private fun applyResize() {
        val st = arrayOf(MediaPlayer.ScaleType.SURFACE_BEST_FIT, MediaPlayer.ScaleType.SURFACE_FILL, MediaPlayer.ScaleType.SURFACE_FIT_SCREEN)
        vlc?.setVideoScale(st[resizeIdx])
    }

    // ---------- statistika ----------
    private fun fmt(bps: Long) = when {
        bps <= 0 -> "naməlum"; bps >= 1_000_000 -> "%.2f Mbps".format(bps / 1e6); else -> "${bps / 1000} kbps"
    }

    private fun tick() {
        if (!alive) return
        var res = "naməlum"
        var br = -1L
        val lab: String
        if (engine == "vlc") {
            val vt = vlc?.getCurrentVideoTrack()
            if (vt != null && vt.width > 0) res = "${vt.width}×${vt.height}"
            if (vt != null && vt.bitrate > 0) br = vt.bitrate.toLong()
            lab = if (!vlcPlaying) "🔴" else if (vlcBuf < 100f) "🟠" else "🟢"
        } else {
            val p = exo
            val f = p?.videoFormat
            if (f != null && f.width > 0) res = "${f.width}×${f.height}"
            if (f != null) br = (if (f.bitrate > 0) f.bitrate else f.averageBitrate).toLong()
            val ahead = p?.totalBufferedDuration ?: 0L
            lab = when {
                p == null || p.playbackState != Player.STATE_READY || ahead <= 100 -> "🔴"
                ahead < 2000 -> "🟠"
                prevAhead >= 0 && ahead - prevAhead < -200 -> "🟡"
                else -> "🟢"
            }
            prevAhead = ahead
        }
        val ready = if (engine == "vlc") vlcPlaying else (exo?.playbackState == Player.STATE_READY)
        val head = if (msg.isNotEmpty() && !ready) msg + "\n" else ""
        statsTv.text = head + "🔲 $res  ⚡ ${fmt(br)}  🛰 ${if (latency >= 0) "$latency ms" else "naməlum"}  ⬇ ${fmt(speedBps)}  🪣 $lab  ⏩ ${speed}x"
        h.postDelayed({ tick() }, 1000)
    }

    /** Gecikmə (ilk bayta qədər) və VLC üçün təxmini endirmə sürəti; hər 6 saniyədə bir. */
    private fun probeLoop() {
        if (!alive) return
        val t = target
        Thread {
            try {
                val t0 = System.nanoTime()
                val c = Net.connect(t, "bytes=0-262143", 8000)
                val s = c.inputStream
                if (s.read() >= 0) {
                    latency = (System.nanoTime() - t0) / 1_000_000
                    var total = 1L
                    val buf = ByteArray(16384)
                    while (total < 262144) { val n = s.read(buf); if (n < 0) break; total += n }
                    val ms = (System.nanoTime() - t0) / 1_000_000
                    if (engine == "vlc" && ms > 0 && total >= 65536) speedBps = total * 8000 / ms
                }
                c.disconnect()
            } catch (e: Exception) { }
        }.start()
        h.postDelayed({ probeLoop() }, 6000)
    }

    override fun onDestroy() {
        alive = false; h.removeCallbacksAndMessages(null)
        releaseExo(); releaseVlc()
        super.onDestroy()
    }
}
