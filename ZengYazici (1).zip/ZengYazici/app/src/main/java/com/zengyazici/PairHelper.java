package com.zengyazici;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;

/** Cütləşmə kodunu bildirişdən yazmaq üçün: Ayarlar pəncərəsindən çıxmadan kod daxil edilir. */
public class PairHelper {
    static final int NID = 20;
    static final String CH = "pair";
    static Nsd.Handle handle;

    public static void start(Context c) {
        final Context app = c.getApplicationContext();
        NotificationManager nm = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH, "Cütləşmə", NotificationManager.IMPORTANCE_HIGH));

        RemoteInput ri = new RemoteInput.Builder("code").setLabel("Cütləşmə kodu (6 rəqəm)").build();
        Intent in = new Intent(app, PairReceiver.class).setAction("com.zengyazici.PAIR");
        PendingIntent pi = PendingIntent.getBroadcast(app, 0, in, PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action act = new Notification.Action.Builder(android.R.drawable.ic_menu_edit, "Kodu yaz", pi)
                .addRemoteInput(ri).build();
        nm.notify(NID, new Notification.Builder(app, CH)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Cütləşmə kodunu yazın")
                .setContentText("Ayarlar → Wireless debugging → «Pair device with pairing code» açın, kodu buraya yazın")
                .addAction(act)
                .setOngoing(false)
                .build());

        app.getSharedPreferences("cfg", 0).edit().remove("pair_port").apply();
        if (handle != null) handle.stop();
        handle = Nsd.watch(app, "_adb-tls-pairing._tcp", false, (host, port) ->
                app.getSharedPreferences("cfg", 0).edit().putString("pair_host", host).putInt("pair_port", port).apply());
    }

    public static void result(Context c, String msg) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NID, new Notification.Builder(c, CH)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Zəng Yazıcı")
                .setContentText(msg)
                .setAutoCancel(true)
                .build());
    }

    public static void stop() {
        if (handle != null) { handle.stop(); handle = null; }
    }
}
