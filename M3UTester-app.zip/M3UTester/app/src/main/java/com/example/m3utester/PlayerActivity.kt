package com.example.m3utester

import android.graphics.Color
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {
    private lateinit var pl: ExoPlayer

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val name = intent.getStringExtra("n") ?: ""
        val url = intent.getStringExtra("u") ?: ""
        val pv = PlayerView(this)
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); setBackgroundColor(0x99000000.toInt()); setPadding(24, 12, 24, 12); text = name
        }
        setContentView(FrameLayout(this).apply {
            addView(pv); addView(tv, FrameLayout.LayoutParams(-2, -2))
        })
        pl = ExoPlayer.Builder(this).build()
        pv.player = pl
        pl.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(v: VideoSize) {
                if (v.width > 0) tv.text = "$name  •  ${v.width}x${v.height}"
            }
            override fun onPlayerError(e: PlaybackException) { tv.text = "🔴 $name" }
        })
        pl.setMediaItem(MediaItem.fromUri(url))
        pl.prepare(); pl.play()
    }

    override fun onDestroy() { pl.release(); super.onDestroy() }
}
