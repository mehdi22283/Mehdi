package az.market.endirim

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.view.View
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette
import coil.Coil
import coil.ImageLoader
import coil.decode.SvgDecoder
import coil.load
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

class MainActivity : AppCompatActivity() {

    private class Src(val name: String, val fn: suspend () -> List<Catalog>)

    private val order = listOf("Bravo Market", "Araz Market", "Al Market", "Rahat Market", "Tamstore")
    private val results = HashMap<String, MarketResult>()
    private lateinit var adapter: CatalogAdapter
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var status: TextView
    private var loadJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Coil.setImageLoader(ImageLoader.Builder(this).components { add(SvgDecoder.Factory()) }.build())
        setContentView(R.layout.activity_main)
        swipe = findViewById(R.id.swipe)
        status = findViewById(R.id.status)
        adapter = CatalogAdapter { c ->
            startActivity(Intent(this, ViewerActivity::class.java).putExtra("catalog", c))
        }
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        swipe.setOnRefreshListener { load() }
        load()
    }

    private fun load() {
        loadJob?.cancel()
        results.clear()
        render()
        swipe.isRefreshing = true
        status.text = "Jurnallar axtarılır…"
        loadJob = lifecycleScope.launch {
            val sources = listOf(
                Src("Bravo Market") { Sources.bravo() },
                Src("Araz Market") { Sources.araz() },
                Src("Al Market") { Sources.al() },
                Src("Rahat Market") { Sources.rahat() },
                Src("Tamstore") { Sources.tamstore() }
            )
            sources.map { s ->
                async {
                    val r = try {
                        MarketResult(s.name, s.fn(), null)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        MarketResult(s.name, emptyList(), e.message ?: e.javaClass.simpleName)
                    }
                    results[s.name] = r
                    render()
                }
            }.awaitAll()
            swipe.isRefreshing = false
            launch { fillBravoDate() }
            downloadPdfs()
        }
    }

    /** Tətbiqə girəndə bütün PDF-ləri endirir; tarixi olmayanlar üçün OCR edir. */
    private suspend fun downloadPdfs() {
        val pdfs = results.values.flatMap { it.catalogs }.filter { it.kind == Kind.PDF }.map { it.urls[0] }.distinct()
        if (pdfs.isEmpty()) {
            status.text = ""
            return
        }
        var done = 0
        var failed = 0
        status.text = "PDF-lər yüklənir (0/${pdfs.size})"
        val sem = Semaphore(3)
        coroutineScope {
            pdfs.map { url ->
                async {
                    sem.withPermit {
                        try {
                            val f = Downloader.ensure(applicationContext, url)
                            fillDateByOcr(url, f)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            failed++
                        }
                    }
                    done++
                    status.text = "PDF-lər yüklənir ($done/${pdfs.size})"
                }
            }.awaitAll()
        }
        Downloader.cleanup(applicationContext, pdfs)
        status.text = "PDF-lər yükləndi" + if (failed > 0) " ($failed uğursuz)" else ""
    }

    private suspend fun fillDateByOcr(url: String, f: java.io.File) {
        val entry = results.entries.firstOrNull { e -> e.value.catalogs.any { it.urls[0] == url && it.date == null } } ?: return
        val market = entry.key
        val d = Ocr.pdfDate(applicationContext, f)
        val isTam = market == "Tamstore"
        if (d == null && !isTam) return
        val cur = results[market] ?: return
        results[market] = cur.copy(
            catalogs = if (d == null) cur.catalogs.filter { it.urls[0] != url }   // Tamstore: tarixi tapılmayanlar silinir
            else cur.catalogs.map { if (it.urls[0] == url) it.copy(date = d) else it }
        )
        render()
    }

    /** Bravo: tarix slaydın içindədir; səhifəni gizli WebView-da açıb ekran görüntüsündən OCR ilə oxuyur. */
    private suspend fun fillBravoDate() {
        val r = results["Bravo Market"] ?: return
        val c = r.catalogs.firstOrNull { it.kind == Kind.WEB && it.date == null } ?: return
        val d = try {
            BravoDate.read(this, c.urls[0])
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        } ?: return
        val cur = results["Bravo Market"] ?: return
        results["Bravo Market"] = cur.copy(catalogs = cur.catalogs.map { if (it.urls[0] == c.urls[0]) it.copy(date = d) else it })
        render()
    }

    private fun render() {
        val rows = ArrayList<Row>()
        for (name in order) {
            val r = results[name]
            val cats = r?.catalogs ?: emptyList()
            val single = r != null && r.error == null && cats.size == 1
            // market başlığı (logo + ad); tək jurnal varsa tarix adın yanında
            rows.add(Row(Row.HEADER, name, name, if (single) cats[0].date else null, null, null))
            when {
                r == null -> rows.add(Row(Row.ITEM, name, "Yüklənir…", null, null, null))
                r.error != null -> rows.add(Row(Row.ITEM, name, "Yüklənmədi", null, r.error, null))
                cats.isEmpty() -> rows.add(Row(Row.ITEM, name, "Jurnal tapılmadı", null, null, null))
                else -> cats.forEach { c ->
                    val pending = if (c.date == null) {
                        if (name == "Tamstore" || c.kind == Kind.WEB) "tarix oxunur…" else "tarix tapılmadı"
                    } else null
                    val sub = listOfNotNull(c.note, pending).joinToString(" • ")
                    rows.add(Row(Row.ITEM, name, c.title, if (single) null else c.date, sub.ifEmpty { null }, c))
                }
            }
        }
        adapter.submit(rows)
    }
}

class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
    val card: com.google.android.material.card.MaterialCardView = v.findViewById(R.id.headerCard)
    val logo: android.widget.ImageView = v.findViewById(R.id.logo)
    val letter: TextView = v.findViewById(R.id.logoLetter)
    val name: TextView = v.findViewById(R.id.hName)
    val date: TextView = v.findViewById(R.id.hDate)
    var boundMarket: String = ""
}

class ItemVH(v: View) : RecyclerView.ViewHolder(v) {
    val title: TextView = v.findViewById(R.id.tvTitle)
    val sub: TextView = v.findViewById(R.id.tvSub)
}

class CatalogAdapter(private val onClick: (Catalog) -> Unit) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var rows: List<Row> = emptyList()

    fun submit(r: List<Row>) {
        rows = r
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int) = rows[position].type
    override fun getItemCount() = rows.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return if (viewType == Row.HEADER) HeaderVH(inf.inflate(R.layout.item_header, parent, false))
        else ItemVH(inf.inflate(R.layout.item_catalog, parent, false))
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
        val row = rows[position]
        if (h is HeaderVH) bindHeader(h, row) else if (h is ItemVH) bindItem(h, row)
    }

    private fun bindItem(h: ItemVH, row: Row) {
        val sb = SpannableStringBuilder(row.title)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, 0)
        val d = row.date
        if (d != null) {
            val start = sb.length
            sb.append("  •  ").append(d)
            sb.setSpan(ForegroundColorSpan(h.itemView.context.getColor(R.color.accent)), start, sb.length, 0)
        }
        h.title.text = sb
        h.sub.text = row.sub ?: ""
        h.sub.visibility = if (row.sub == null) View.GONE else View.VISIBLE
        val c = row.catalog
        h.itemView.setOnClickListener { if (c != null) onClick(c) }
        h.itemView.isClickable = c != null
    }

    private fun bindHeader(h: HeaderVH, row: Row) {
        h.boundMarket = row.market
        h.letter.text = row.market.take(1)
        h.letter.visibility = View.VISIBLE
        h.name.text = row.market
        h.date.text = row.date ?: ""
        h.date.visibility = if (row.date == null) View.GONE else View.VISIBLE
        applyColor(h, Brand.colors[row.market] ?: Brand.FALLBACK)

        val url = Brand.logos[row.market] ?: return
        h.logo.load(url) {
            allowHardware(false)
            listener(onSuccess = { _, result ->
                h.letter.visibility = View.GONE
                if (!Brand.colors.containsKey(row.market)) {
                    val bmp = (result.drawable as? BitmapDrawable)?.bitmap
                    if (bmp != null) {
                        Palette.from(bmp).generate { p ->
                            val c = Brand.pick(p)
                            if (c != null) {
                                Brand.colors[row.market] = c
                                if (h.boundMarket == row.market) applyColor(h, c)
                            }
                        }
                    }
                }
            })
        }
    }

    private fun applyColor(h: HeaderVH, color: Int) {
        h.card.setCardBackgroundColor(color)
        val fg = if (ColorUtils.calculateLuminance(color) > 0.5) Color.BLACK else Color.WHITE
        h.name.setTextColor(fg)
        h.date.setTextColor(fg)
    }
}
