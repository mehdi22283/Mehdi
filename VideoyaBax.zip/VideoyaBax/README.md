# Videoya bax (Android TV)

TV-yə quraşdırılır. Telefon brauzerində `TV_IP:3169` açılır, video seçilir, TV-də oynayır.

Video TV-nin yaddaşına yazılmır: telefon faylı özündə saxlayır və TV oxuduqca şəbəkə üzərindən göndərir
(TV-də yalnız ~8 MB RAM buferi işlənir). Səhifə videonun sonuna qədər telefonda açıq qalmalıdır.
İrəli/geri atlama dəstəklənir. VOB, MPG, MPEG, MKV, AVI, MP4 və s. VLC ilə oynayır.

APK yığmaq: Android Studio ilə açın → Build > Build APK(s), və ya GitHub-a yükləyin (Actions avtomatik yığır).
Nəticə: app/build/outputs/apk/debug/Videoya-bax.apk
