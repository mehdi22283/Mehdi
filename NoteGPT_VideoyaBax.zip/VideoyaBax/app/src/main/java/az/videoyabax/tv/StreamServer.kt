package az.videoyabax.tv

import android.util.Log
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.nio.charset.StandardCharsets

/**
 * TV-nin daxilində işləyən yüngül HTTP serveri.
 *
 *  GET  /         -> telefondakı brauzerə yükləmə səhifəsini verir
 *  POST /stream   -> telefonun göndərdiyi video axınını qəbul edir (diskə yazmır)
 *  GET  /status   -> sessiyanın vəziyyəti (JSON)
 *
 * Heç bir fayl yaddaşa yazılmır: gələn baytlar birbaşa [StreamBuffer]-ə (RAM)
 * ötürülür və oynadıcı həmin buferdən oxuyur.
 */
class StreamServer(
    private val port: Int,
    private val htmlPage: String,
    private val listener: Listener
) {

    interface Listener {
        /** Telefon yükləməyə başladı — oynadıcını hazırlamaq lazımdır. */
        fun onSessionStarted(session: StreamBuffer)

        /** Yükləmə davam edir. */
        fun onSessionProgress(session: StreamBuffer)

        /** Yükləmə uğurla tamamlandı. */
        fun onSessionFinished(session: StreamBuffer)

        /** Xəta baş verdi. */
        fun onSessionFailed(session: StreamBuffer, message: String)
    }

    companion object {
        private const val TAG = "VideoyaBax/Server"
        private const val HEADER_READ_TIMEOUT_MS = 30_000
        private const val BODY_READ_TIMEOUT_MS = 120_000
        private const val NOTIFY_EVERY_BYTES = 4L * 1024 * 1024
    }

    @Volatile
    private var serverSocket: ServerSocket? = null

    @Volatile
    private var running = false

    @Volatile
    var activeSession: StreamBuffer? = null
        private set

    @Volatile
    var lastError: String? = null
        private set

    fun start() {
        if (running) return
        running = true
        val thread = Thread({ acceptLoop() }, "videoyabax-server")
        thread.isDaemon = true
        thread.start()
    }

    fun stop() {
        running = false
        try {
            serverSocket?.close()
        } catch (ignored: IOException) {
        }
        serverSocket = null
        activeSession?.abandon()
    }

    private fun acceptLoop() {
        try {
            val socket = ServerSocket()
            socket.reuseAddress = true
            socket.bind(InetSocketAddress(port))
            serverSocket = socket
            lastError = null
            Log.i(TAG, "Server $port portunda başladı")
            while (running) {
                val client = try {
                    socket.accept()
                } catch (e: IOException) {
                    if (running) {
                        Log.w(TAG, "accept xətası: ${e.message}")
                        continue
                    } else {
                        break
                    }
                }
                val worker = Thread({ handleClient(client) }, "videoyabax-client")
                worker.isDaemon = true
                worker.start()
            }
        } catch (e: Exception) {
            if (running) {
                lastError = e.message ?: e.toString()
                Log.e(TAG, "Server işə düşmədi (port $port)", e)
            }
        }
    }

    private fun handleClient(socket: Socket) {
        try {
            socket.tcpNoDelay = true
            socket.soTimeout = HEADER_READ_TIMEOUT_MS
            val input = BufferedInputStream(socket.getInputStream(), 128 * 1024)
            val output = BufferedOutputStream(socket.getOutputStream(), 32 * 1024)

            val requestLine = readLine(input, 8 * 1024) ?: return
            val parts = requestLine.trim().split(" ")
            if (parts.size < 2) {
                sendResponse(output, 400, "Bad Request", "text/plain; charset=utf-8", "400".toByteArray())
                return
            }
            val method = parts[0].uppercase()
            val path = parts[1].substringBefore('?')

            val headers = HashMap<String, String>()
            while (true) {
                val line = readLine(input, 8 * 1024) ?: break
                if (line.isEmpty()) break
                val index = line.indexOf(':')
                if (index > 0) {
                    headers[line.substring(0, index).trim().lowercase()] = line.substring(index + 1).trim()
                }
            }

            when {
                method == "GET" && (path == "/" || path == "/index.html" || path == "/index.htm") -> {
                    sendResponse(
                        output, 200, "OK", "text/html; charset=utf-8",
                        htmlPage.toByteArray(StandardCharsets.UTF_8)
                    )
                }

                method == "GET" && path == "/status" -> {
                    sendResponse(
                        output, 200, "OK", "application/json; charset=utf-8",
                        statusJson(activeSession).toByteArray(StandardCharsets.UTF_8)
                    )
                }

                method == "GET" && path == "/favicon.ico" -> {
                    sendResponse(output, 204, "No Content", "image/x-icon", ByteArray(0))
                }

                method == "POST" && path.startsWith("/stream") -> {
                    receiveUpload(input, output, headers, socket)
                }

                method == "OPTIONS" -> {
                    sendResponse(output, 204, "No Content", "text/plain; charset=utf-8", ByteArray(0))
                }

                else -> {
                    sendResponse(
                        output, 404, "Not Found", "text/plain; charset=utf-8",
                        "404".toByteArray(StandardCharsets.US_ASCII)
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Sorğu emal edilə bilmədi: ${e.message}")
        } finally {
            try {
                socket.close()
            } catch (ignored: IOException) {
            }
        }
    }

    /**
     * Telefondan gələn video axınını qəbul edir və RAM buferinə yazır.
     * Cavab yalnız yükləmə bitdikdən sonra göndərilir.
     */
    private fun receiveUpload(
        input: InputStream,
        output: OutputStream,
        headers: Map<String, String>,
        socket: Socket
    ) {
        val total = headers["content-length"]?.toLongOrNull() ?: -1L
        val isChunked = headers["transfer-encoding"]?.contains("chunked", ignoreCase = true) == true
        val expectContinue = headers["expect"]?.contains("100-continue", ignoreCase = true) == true

        if (expectContinue) {
            output.write("HTTP/1.1 100 Continue\r\n\r\n".toByteArray(StandardCharsets.US_ASCII))
            output.flush()
        }

        // Köhnə sessiyanı bağla, yenisini yarat
        activeSession?.abandon()
        val session = StreamBuffer(total)
        activeSession = session
        socket.soTimeout = BODY_READ_TIMEOUT_MS

        // Oynadıcı dərhal hazırlanır — video gözləmədən başlayır
        try {
            listener.onSessionStarted(session)
        } catch (e: Exception) {
            Log.w(TAG, "onSessionStarted xətası", e)
        }

        var received = 0L
        var lastNotify = 0L
        val buffer = ByteArray(256 * 1024)
        var error: String? = null

        try {
            if (isChunked) {
                while (true) {
                    val sizeLine = readLine(input, 64) ?: break
                    if (sizeLine.isEmpty()) continue
                    val size = sizeLine.trim().split(";")[0].toLongOrNull(16) ?: break
                    if (size == 0L) {
                        readLine(input, 64)
                        break
                    }
                    var remaining = size
                    while (remaining > 0) {
                        val n = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                        if (n < 0) break
                        session.append(buffer, 0, n)
                        remaining -= n
                        received += n
                        if (received - lastNotify >= NOTIFY_EVERY_BYTES) {
                            lastNotify = received
                            listener.onSessionProgress(session)
                        }
                        if (session.isFailed()) break
                    }
                    readLine(input, 64)
                    if (session.isFailed()) break
                }
            } else if (total >= 0) {
                var remaining = total
                while (remaining > 0) {
                    val n = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                    if (n < 0) break
                    session.append(buffer, 0, n)
                    remaining -= n
                    received += n
                    if (received - lastNotify >= NOTIFY_EVERY_BYTES) {
                        lastNotify = received
                        listener.onSessionProgress(session)
                    }
                    if (session.isFailed()) break
                }
            } else {
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    session.append(buffer, 0, n)
                    received += n
                    if (received - lastNotify >= NOTIFY_EVERY_BYTES) {
                        lastNotify = received
                        listener.onSessionProgress(session)
                    }
                    if (session.isFailed()) break
                }
            }
        } catch (e: SocketTimeoutException) {
            error = "Telefondan məlumat gəlmir (bağlantı vaxtı bitdi)"
        } catch (e: Exception) {
            error = e.message ?: "Bağlantı kəsildi"
        }

        if (session.isFailed()) {
            val message = session.errorMessage() ?: "Xəta"
            listener.onSessionFailed(session, message)
        } else if (error != null) {
            session.fail(error)
            listener.onSessionFailed(session, error)
        } else if (total >= 0 && received < total) {
            val message = "Yükləmə tamamlanmadı ($received / $total bayt)"
            session.fail(message)
            listener.onSessionFailed(session, message)
        } else {
            session.finish()
            listener.onSessionFinished(session)
        }

        Log.i(TAG, "Yükləmə bitdi: $received bayt (gözlənilən: $total)")

        try {
            sendResponse(
                output, 200, "OK", "application/json; charset=utf-8",
                statusJson(session).toByteArray(StandardCharsets.UTF_8)
            )
        } catch (e: IOException) {
            Log.w(TAG, "Cavab göndərilə bilmədi: ${e.message}")
        }
    }

    private fun statusJson(session: StreamBuffer?): String {
        if (session == null) {
            return "{\"state\":\"idle\",\"received\":0,\"total\":0}"
        }
        val state = when {
            session.isFailed() -> "error"
            session.isComplete() -> "complete"
            else -> "receiving"
        }
        val error = session.errorMessage()?.replace("\"", "'") ?: ""
        return "{\"state\":\"$state\",\"received\":${session.available()}," +
            "\"total\":${session.totalBytes},\"error\":\"$error\"}"
    }

    private fun sendResponse(
        output: OutputStream,
        code: Int,
        message: String,
        contentType: String,
        body: ByteArray
    ) {
        val header = buildString {
            append("HTTP/1.1 $code $message\r\n")
            append("Content-Type: ").append(contentType).append("\r\n")
            append("Content-Length: ").append(body.size).append("\r\n")
            append("Access-Control-Allow-Origin: *\r\n")
            append("Access-Control-Allow-Headers: Content-Type\r\n")
            append("Cache-Control: no-store, no-cache, must-revalidate\r\n")
            append("Pragma: no-cache\r\n")
            append("Connection: close\r\n")
            append("\r\n")
        }
        output.write(header.toByteArray(StandardCharsets.US_ASCII))
        if (body.isNotEmpty()) output.write(body)
        output.flush()
    }

    /** '\n' və ya '\r\n' ilə bitən sətri oxuyur. */
    @Throws(IOException::class)
    private fun readLine(input: InputStream, maxLength: Int): String? {
        val sb = StringBuilder(64)
        var sawAny = false
        while (true) {
            val c = input.read()
            if (c == -1) return if (sawAny && sb.isNotEmpty()) sb.toString() else null
            sawAny = true
            if (c == '\n'.code) return sb.toString()
            if (c != '\r'.code) sb.append(c.toChar())
            if (sb.length > maxLength) throw IOException("Sorğu sətri çox uzundur")
        }
    }
}
