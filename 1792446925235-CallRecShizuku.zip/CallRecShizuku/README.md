# Zəng Yazıcı (Shizuku, kompüter yoxdur)
1. Play Store/GitHub-dan Shizuku quraşdır. APK-nı quraşdır (Android Studio -> Run).
2. Telefon: Settings -> Developer options -> Wireless debugging (Wi-Fi-a qoşulu olmalıdır).
3. Shizuku -> "Start via Wireless debugging" -> Pairing (kod bildirişə yazılır) -> Start.
4. Zəng Yazıcı -> "Shizuku icazəsi ver" -> "Başlat".
Yazılar: /sdcard/Music/CallRec/
Qeyd: telefon yenidən başlayanda Shizuku-nu yenidən başlatmaq lazımdır.
