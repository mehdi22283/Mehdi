package az.airpods.pro2;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.CopyOnWriteArrayList;

public final class PodsStore {
    public interface Listener { void onChange(); }

    public static volatile PodsState state;
    public static volatile boolean running, active, btOff;

    private static final CopyOnWriteArrayList<Listener> L = new CopyOnWriteArrayList<>();
    private static final Handler H = new Handler(Looper.getMainLooper());

    public static void add(Listener l) { L.addIfAbsent(l); }
    public static void remove(Listener l) { L.remove(l); }

    public static void changed() {
        H.post(new Runnable() {
            @Override public void run() {
                for (Listener l : L) l.onChange();
            }
        });
    }

    private PodsStore() {}
}
