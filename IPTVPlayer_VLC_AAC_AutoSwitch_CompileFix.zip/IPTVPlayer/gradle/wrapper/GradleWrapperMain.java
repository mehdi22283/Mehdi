package org.gradle.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Small self-contained Gradle distribution bootstrapper for this source archive. */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path projectDir = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
        Path propertiesFile = projectDir.resolve("gradle/wrapper/gradle-wrapper.properties");
        if (!Files.isRegularFile(propertiesFile)) {
            throw new IllegalStateException("Missing " + propertiesFile);
        }
        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(propertiesFile)) {
            properties.load(in);
        }
        String distributionUrl = properties.getProperty("distributionUrl");
        if (distributionUrl == null || !distributionUrl.startsWith("https://")) {
            throw new IllegalStateException("A valid HTTPS distributionUrl is required");
        }

        String zipName = Paths.get(URI.create(distributionUrl).getPath()).getFileName().toString();
        String distributionId = zipName.endsWith(".zip") ? zipName.substring(0, zipName.length() - 4) : zipName;
        String rootName = distributionId.replaceFirst("-(bin|all)$", "");
        String homeValue = System.getenv("GRADLE_USER_HOME");
        Path gradleHome = (homeValue == null || homeValue.isBlank())
                ? Paths.get(System.getProperty("user.home"), ".gradle") : Paths.get(homeValue);
        Path cacheDir = gradleHome.resolve("wrapper/dists").resolve(distributionId).resolve("iptv-bootstrap");
        Path gradleRoot = cacheDir.resolve(rootName);
        Path gradleExecutable = gradleRoot.resolve(isWindows() ? "bin/gradle.bat" : "bin/gradle");

        if (!Files.isRegularFile(gradleExecutable)) {
            Files.createDirectories(cacheDir);
            Path archive = cacheDir.resolve(zipName + ".download");
            Path extraction = cacheDir.resolve("extract-tmp");
            System.out.println("Downloading Gradle distribution: " + zipName);
            download(distributionUrl, archive);
            String expectedSha256 = properties.getProperty("distributionSha256Sum", "").trim();
            if (!expectedSha256.isEmpty()) {
                String actualSha256 = sha256(archive);
                if (!actualSha256.equalsIgnoreCase(expectedSha256)) {
                    Files.deleteIfExists(archive);
                    throw new IOException("Gradle distribution SHA-256 mismatch; refusing to extract it");
                }
            }
            deleteTree(extraction);
            Files.createDirectories(extraction);
            unzip(archive, extraction);
            Path extractedRoot = extraction.resolve(rootName);
            if (!Files.isRegularFile(extractedRoot.resolve(isWindows() ? "bin/gradle.bat" : "bin/gradle"))) {
                throw new IOException("Gradle distribution has an unexpected layout: " + zipName);
            }
            deleteTree(gradleRoot);
            Files.move(extractedRoot, gradleRoot, StandardCopyOption.REPLACE_EXISTING);
            deleteTree(extraction);
            Files.deleteIfExists(archive);
            if (!isWindows()) gradleExecutable.toFile().setExecutable(true, false);
        }

        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        if (isWindows()) {
            command.add("cmd.exe"); command.add("/d"); command.add("/s"); command.add("/c");
            StringBuilder commandLine = new StringBuilder("\"").append(gradleExecutable).append("\"");
            for (String arg : args) {
                commandLine.append(" \"").append(arg.replace("\"", "\\\"")).append("\"");
            }
            command.add(commandLine.append("\"").toString());
        } else {
            command.add(gradleExecutable.toString());
            java.util.Collections.addAll(command, args);
        }
        Process process = new ProcessBuilder(command).directory(projectDir.toFile()).inheritIO().start();
        System.exit(process.waitFor());
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    private static void download(String address, Path destination) throws IOException {
        URL url = URI.create(address).toURL();
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(30_000);
        connection.setReadTimeout(60_000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "IPTVPlayer-GradleBootstrap/1.0");
        int response = connection.getResponseCode();
        if (response < 200 || response >= 300) {
            connection.disconnect();
            throw new IOException("Gradle download failed with HTTP " + response + ": " + address);
        }
        try (InputStream in = connection.getInputStream()) {
            Files.copy(in, destination, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            connection.disconnect();
        }
    }

    private static String sha256(Path file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = Files.newInputStream(file)) {
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = input.read(buffer)) >= 0) {
                if (count > 0) digest.update(buffer, 0, count);
            }
        }
        return HexFormat.of().formatHex(digest.digest());
    }

    private static void unzip(Path archive, Path destination) throws IOException {
        Path safeRoot = destination.toAbsolutePath().normalize();
        try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(archive))) {
            ZipEntry entry;
            byte[] buffer = new byte[32 * 1024];
            while ((entry = zip.getNextEntry()) != null) {
                Path target = safeRoot.resolve(entry.getName()).normalize();
                if (!target.startsWith(safeRoot)) throw new IOException("Unsafe path in Gradle archive");
                if (entry.isDirectory()) {
                    Files.createDirectories(target);
                } else {
                    Files.createDirectories(target.getParent());
                    try (var out = Files.newOutputStream(target)) {
                        int count;
                        while ((count = zip.read(buffer)) >= 0) {
                            if (count > 0) out.write(buffer, 0, count);
                        }
                    }
                }
                zip.closeEntry();
            }
        }
    }

    private static void deleteTree(Path root) throws IOException {
        if (!Files.exists(root)) return;
        Files.walkFileTree(root, new SimpleFileVisitor<>() {
            @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.deleteIfExists(file); return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult postVisitDirectory(Path dir, IOException error) throws IOException {
                if (error != null) throw error;
                Files.deleteIfExists(dir); return FileVisitResult.CONTINUE;
            }
        });
    }
}
