package az.mehdi.callrec

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.ByteArrayInputStream
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

class AdbMgr private constructor(ctx: Context) : AbsAdbConnectionManager() {
    private val priv: PrivateKey
    private val cert: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val kf = File(ctx.filesDir, "adb_key.der")
        val cf = File(ctx.filesDir, "adb_cert.der")
        var p: PrivateKey? = null
        var c: Certificate? = null
        try {
            if (kf.exists() && cf.exists()) {
                p = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
                c = CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(cf.readBytes()))
            }
        } catch (e: Exception) { p = null; c = null }
        if (p == null || c == null) {
            val g = KeyPairGenerator.getInstance("RSA")
            g.initialize(2048, SecureRandom())
            val kp = g.generateKeyPair()
            p = kp.private
            val name = X500Name("CN=ZengYazici")
            val notBefore = Date()
            val notAfter = Date(System.currentTimeMillis() + 3650L * 86400000L)
            val serial = BigInteger(64, SecureRandom()).abs()
            val builder = JcaX509v3CertificateBuilder(name, serial, notBefore, notAfter, name, kp.public)
            val signer = JcaContentSignerBuilder("SHA512withRSA").build(p)
            val holder = builder.build(signer)
            c = JcaX509CertificateConverter().getCertificate(holder)
            kf.writeBytes(p.encoded)
            cf.writeBytes(c.encoded)
        }
        priv = p!!
        cert = c!!
    }

    override fun getPrivateKey(): PrivateKey = priv
    override fun getCertificate(): Certificate = cert
    override fun getDeviceName(): String = "ZengYazici"

    companion object {
        @Volatile private var inst: AdbMgr? = null
        fun get(ctx: Context): AdbMgr = inst ?: synchronized(this) {
            inst ?: AdbMgr(ctx.applicationContext).also { inst = it }
        }
    }
}
