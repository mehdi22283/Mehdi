package az.market.endirim

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

object Downloader {
    private val locks = ConcurrentHashMap<String, Any>()

    private fun dir(ctx: Context) = File(ctx.filesDir, "pdfs").apply { mkdirs() }

    fun fileFor(ctx: Context, url: String): File {
        val name = url.substringAfterLast('/').substringBefore('?').takeLast(60)
        return File(dir(ctx), url.hashCode().toUInt().toString(16) + "_" + name)
    }

    /** PDF artıq yüklənibsə təkrar yükləmir. */
    suspend fun ensure(ctx: Context, url: String): File = withContext(Dispatchers.IO) {
        val f = fileFor(ctx, url)
        synchronized(locks.getOrPut(url) { Any() }) {
            if (!(f.exists() && f.length() > 0)) {
                val tmp = File(f.path + ".part")
                val c = URL(url).openConnection() as HttpURLConnection
                try {
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) Chrome/124.0 Mobile Safari/537.36")
                    c.connectTimeout = 20_000
                    c.readTimeout = 60_000
                    if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
                    c.inputStream.use { input -> FileOutputStream(tmp).use { out -> input.copyTo(out) } }
                    if (!tmp.renameTo(f)) throw IOException("Fayl yazıla bilmədi")
                } finally {
                    c.disconnect()
                    if (tmp.exists()) tmp.delete()
                }
            }
        }
        f
    }

    /** Siyahıda olmayan köhnə PDF-ləri silir. */
    fun cleanup(ctx: Context, keepUrls: List<String>) {
        val keep = keepUrls.map { fileFor(ctx, it).name }.toSet()
        dir(ctx).listFiles()?.forEach { if (it.name !in keep) it.delete() }
    }
}
