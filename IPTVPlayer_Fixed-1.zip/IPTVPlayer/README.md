# IPTVPlayer — build

This project uses VLC / AndroidX VLC as its sole playback engine.

## Toolchain

- JDK: 17
- Gradle: 8.7
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- Android compile SDK: 35 (targetSdk 35), build-tools 35.0.0
- libVLC: 3.6.0
- AndroidX: core-ktx 1.13.1, appcompat 1.7.0, recyclerview 1.3.2, lifecycle 2.8.4
- kotlinx-coroutines: 1.8.1

## Build a debug APK

From this project folder run:

```bash
./gradlew assembleDebug
```

On Windows:

```bat
gradlew.bat assembleDebug
```

The first Gradle start and dependency resolution require an internet connection. The Gradle distribution is SHA-256 checked before extraction. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.
