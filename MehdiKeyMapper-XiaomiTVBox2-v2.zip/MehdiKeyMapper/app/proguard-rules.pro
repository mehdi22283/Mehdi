# Intentionally empty: the app is small and ships without minification by default.
