package com.mehdi.keymapper;

import android.os.IBinder;
import android.os.SystemClock;
import android.view.InputEvent;
import android.view.KeyEvent;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

/** app_process ilə shell istifadəçisi kimi işləyir; stdin-dən əmr oxuyub düyməni dərhal inject edir.
 *  Əmrlər: "D kod təkrar" | "U kod" | "T kod" */
public class Injector {
    private static Object im;
    private static Method inject;
    private static long downTime = 0;

    public static void main(String[] args) {
        try {
            Class<?> sm = Class.forName("android.os.ServiceManager");
            IBinder b = (IBinder) sm.getMethod("getService", String.class).invoke(null, "input");
            Class<?> stub = Class.forName("android.hardware.input.IInputManager$Stub");
            im = stub.getMethod("asInterface", IBinder.class).invoke(null, b);
            Class<?> iface = Class.forName("android.hardware.input.IInputManager");
            inject = iface.getMethod("injectInputEvent", InputEvent.class, int.class);
            System.out.println("READY");
            System.out.flush();
        } catch (Throwable t) {
            System.out.println("FAIL " + t);
            System.out.flush();
            return;
        }
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
            String line;
            while ((line = r.readLine()) != null) {
                try { handle(line.trim()); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    private static void handle(String l) throws Exception {
        if (l.isEmpty()) return;
        String[] p = l.split(" ");
        char c = p[0].charAt(0);
        int code = Integer.parseInt(p[1]);
        if (c == 'D') {
            int rep = p.length > 2 ? Integer.parseInt(p[2]) : 0;
            send(KeyEvent.ACTION_DOWN, code, rep);
        } else if (c == 'U') {
            send(KeyEvent.ACTION_UP, code, 0);
        } else if (c == 'T') {
            send(KeyEvent.ACTION_DOWN, code, 0);
            send(KeyEvent.ACTION_UP, code, 0);
        }
    }

    private static void send(int action, int code, int repeat) throws Exception {
        long now = SystemClock.uptimeMillis();
        if (action == KeyEvent.ACTION_DOWN && repeat == 0) downTime = now;
        if (downTime == 0) downTime = now;
        KeyEvent ev = new KeyEvent(downTime, now, action, code, repeat, 0, -1, 0, 0, 0x301);
        inject.invoke(im, ev, 0); // 0 = ASYNC
    }
}
