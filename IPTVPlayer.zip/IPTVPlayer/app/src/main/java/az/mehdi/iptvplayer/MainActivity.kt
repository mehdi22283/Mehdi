package az.mehdi.iptvplayer

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File

class ChannelAdapter(
    private val logos: LogoStore,
    private val scope: CoroutineScope,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    var items: List<Channel> = emptyList()
    var playingUrl: String? = null

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val logo: ImageView = v.findViewById(R.id.logo)
        val name: TextView = v.findViewById(R.id.name)
        var job: Job? = null
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_channel, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val ch = items[pos]
        h.job?.cancel()
        h.name.text = "${ch.number}. ${ch.name}"
        h.logo.setImageDrawable(null)
        h.itemView.isActivated = ch.url == playingUrl
        h.itemView.setOnClickListener { onClick(ch) }
        h.job = scope.launch {
            val bmp = logos.bitmapFor(ch)
            if (bmp != null) h.logo.setImageBitmap(bmp)
        }
    }

    override fun onViewRecycled(h: VH) {
        h.job?.cancel()
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var libVLC: LibVLC
    private lateinit var player: MediaPlayer
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var infoBar: LinearLayout
    private lateinit var infoLogo: ImageView
    private lateinit var infoName: TextView
    private lateinit var panel: View
    private lateinit var panelBody: View
    private lateinit var groupTitle: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ChannelAdapter
    private lateinit var logos: LogoStore

    private val handler = Handler(Looper.getMainLooper())
    private val hidePanelRun = Runnable { setPanel(false) }
    private val hideInfoRun = Runnable { infoBar.visibility = View.GONE }

    private var all: List<Channel> = emptyList()
    private var byGroup: Map<String, List<Channel>> = emptyMap()
    private var groupList: List<String?> = listOf(null) // null = "Hamısı"
    private var playGroup: String? = null
    private var browseGroup: String? = null
    private var current: Channel? = null
    private var switching = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun listFor(g: String?): List<Channel> = if (g == null) all else byGroup[g].orEmpty()
    private fun panelShown() = panel.visibility == View.VISIBLE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        videoLayout = findViewById(R.id.videoLayout)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        infoBar = findViewById(R.id.infoBar)
        infoLogo = findViewById(R.id.infoLogo)
        infoName = findViewById(R.id.infoName)
        panel = findViewById(R.id.panel)
        panelBody = findViewById(R.id.panelBody)
        groupTitle = findViewById(R.id.groupTitle)
        list = findViewById(R.id.list)

        logos = LogoStore(applicationContext, lifecycleScope)
        adapter = ChannelAdapter(logos, lifecycleScope) { ch ->
            play(ch, browseGroup)
            setPanel(false)
        }
        list.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        list.adapter = adapter
        list.itemAnimator = null

        libVLC = LibVLC(this, arrayListOf("--network-caching=2000"))
        player = MediaPlayer(libVLC)
        player.setEventListener { ev ->
            runOnUiThread {
                when (ev.type) {
                    MediaPlayer.Event.Buffering ->
                        progress.visibility = if (ev.buffering < 100f) View.VISIBLE else View.GONE
                    MediaPlayer.Event.Playing -> {
                        progress.visibility = View.GONE; status.visibility = View.GONE; applyStretch()
                    }
                    MediaPlayer.Event.Vout -> applyStretch()
                    MediaPlayer.Event.EncounteredError -> {
                        progress.visibility = View.GONE
                        status.text = "Kanal açılmadı"
                        status.visibility = View.VISIBLE
                    }
                }
            }
        }
        videoLayout.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyStretch() }

        val root = findViewById<View>(R.id.root)
        root.setOnClickListener { setPanel(!panelShown()) }
        root.isFocusable = false

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (panelShown()) setPanel(false) else finish() }
        })

        hideBars()
        showCached()   // əvvəlki playlist dərhal açılır
        loadPlaylist() // hər açılışda yenisi endirilir
    }

    // ---------- playlist ----------
    private fun showCached() {
        val cache = File(filesDir, "playlist.m3u")
        if (!cache.exists()) return
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { runCatching { cache.readText() }.getOrNull() } ?: return@launch
            applyPlaylist(text)
        }
    }

    private fun loadPlaylist() {
        if (all.isEmpty()) {
            status.text = "Playlist yüklənir…"
            status.visibility = View.VISIBLE
        }
        lifecycleScope.launch {
            val cache = File(filesDir, "playlist.m3u")
            val text = withContext(Dispatchers.IO) { runCatching { downloadPlaylist(cache) }.getOrNull() }
            if (text != null) {
                applyPlaylist(text)
            } else if (all.isEmpty()) {
                status.text = "Playlist yüklənmədi"
                status.visibility = View.VISIBLE
            } else {
                Toast.makeText(this@MainActivity, "Yenilənmədi, köhnə playlist açıqdır", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun applyPlaylist(text: String) {
        val parsed = withContext(Dispatchers.Default) { parsePlaylist(text) }
        if (parsed.isEmpty()) return
        // "Hamısı": bütün kanallar qrup ardıcıllığı ilə
        val order = parsed.map { it.group }.distinct()
        val grouped = withContext(Dispatchers.Default) {
            order.flatMap { g -> parsed.filter { it.group == g } }.mapIndexed { i, c -> c.copy(number = i + 1) }
        }
        all = grouped
        byGroup = grouped.groupBy { it.group }
        groupList = listOf<String?>(null) + order
        if (playGroup != null && playGroup !in order) playGroup = null
        if (browseGroup != null && browseGroup !in order) browseGroup = null
        status.visibility = View.GONE

        if (current == null) {
            val prefs = getSharedPreferences("p", MODE_PRIVATE)
            val lastUrl = prefs.getString("last", null)
            val lastGroup = prefs.getString("group", "")?.takeIf { it.isNotEmpty() && it in order }
            val ch = all.firstOrNull { it.url == lastUrl && (lastGroup == null || it.group == lastGroup) }
                ?: all.firstOrNull { it.url == lastUrl }
                ?: byGroup[lastGroup]?.firstOrNull()
                ?: all.first()
            play(ch, if (lastGroup == null || ch.group == lastGroup) lastGroup else null)
        } else if (panelShown()) {
            loadBrowse()
        }
    }

    // ---------- playback ----------
    private fun play(ch: Channel, group: String?) {
        current = ch
        playGroup = group
        getSharedPreferences("p", MODE_PRIVATE).edit()
            .putString("last", ch.url).putString("group", group ?: "").apply()
        adapter.playingUrl = ch.url
        if (panelShown()) adapter.notifyDataSetChanged()
        showInfo(ch)
        status.visibility = View.GONE
        progress.visibility = View.VISIBLE
        val media = Media(libVLC, Uri.parse(ch.url))
        media.setHWDecoderEnabled(true, false)
        media.addOption(":network-caching=2000")
        player.media = media
        media.release()
        applyStretch()
        player.play()
    }

    private fun step(d: Int) {
        val l = listFor(playGroup).ifEmpty { all }
        if (l.isEmpty()) return
        val i = l.indexOfFirst { it.url == current?.url }
        play(l[((if (i < 0) 0 else i + d) + l.size) % l.size], playGroup)
    }

    /** Video ekrana balacadırsa ekranın tam ölçüsünə uzadılır (stretch). */
    private fun applyStretch() {
        val dm = resources.displayMetrics
        val w = if (videoLayout.width > 0) videoLayout.width else dm.widthPixels
        val h = if (videoLayout.height > 0) videoLayout.height else dm.heightPixels
        player.setAspectRatio("$w:$h")
        player.setScale(0f)
    }

    /** Kanal dəyişəndə/seçiləndə aşağıda məlumat göstərilir, bir neçə saniyə sonra silinir. */
    private fun showInfo(ch: Channel) {
        val l = listFor(playGroup).ifEmpty { all }
        val idx = (l.indexOfFirst { it.url == ch.url } + 1).coerceAtLeast(1)
        infoName.text = "${ch.name}  •  $idx/${l.size}  •  ${playGroup ?: "Hamısı"}"
        infoLogo.setImageDrawable(null)
        infoBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val bmp = logos.bitmapFor(ch)
            if (bmp != null && current == ch) infoLogo.setImageBitmap(bmp)
        }
        handler.removeCallbacks(hideInfoRun)
        handler.postDelayed(hideInfoRun, 4000)
    }

    // ---------- channel panel ----------
    private fun setPanel(show: Boolean) {
        handler.removeCallbacks(hidePanelRun)
        panel.animate().cancel()
        panelBody.animate().cancel()
        switching = false
        if (show) {
            handler.removeCallbacks(hideInfoRun)
            infoBar.visibility = View.GONE
            browseGroup = playGroup
            panelBody.translationY = 0f
            panelBody.alpha = 1f
            loadBrowse()
            panel.alpha = 0f
            panel.visibility = View.VISIBLE
            panel.animate().alpha(1f).setDuration(150).start()
            focusCurrent()
            handler.postDelayed(hidePanelRun, 10000)
        } else {
            panel.visibility = View.GONE
        }
    }

    private fun loadBrowse() {
        val l = listFor(browseGroup)
        adapter.items = l
        adapter.playingUrl = current?.url
        adapter.notifyDataSetChanged()
        val gi = groupList.indexOf(browseGroup).coerceAtLeast(0)
        groupTitle.text = "${browseGroup ?: "Hamısı"}  (${l.size})      ${gi + 1}/${groupList.size}"
    }

    private fun focusCurrent() {
        val idx = adapter.items.indexOfFirst { it.url == current?.url }.coerceAtLeast(0)
        (list.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(300))
        list.postDelayed({ list.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }, 70)
    }

    /** Yuxarı/aşağı: qonşu qrupa yüngül sürüşmə animasiyası ilə keçid. */
    private fun switchGroup(d: Int) {
        if (switching || groupList.size < 2) return
        switching = true
        val gi = groupList.indexOf(browseGroup).coerceAtLeast(0)
        val next = groupList[(gi + d + groupList.size) % groupList.size]
        val dist = dp(56).toFloat() * d
        panelBody.animate().translationY(-dist).alpha(0f).setDuration(110).withEndAction {
            browseGroup = next
            loadBrowse()
            panelBody.translationY = dist
            panelBody.animate().translationY(0f).alpha(1f).setDuration(160)
                .withEndAction { switching = false }.start()
            focusCurrent()
        }.start()
    }

    // ---------- remote control ----------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (panelShown()) {
                handler.removeCallbacks(hidePanelRun)
                handler.postDelayed(hidePanelRun, 10000)
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { if (e.repeatCount == 0) switchGroup(-1); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { if (e.repeatCount == 0) switchGroup(1); return true }
                }
                return super.dispatchKeyEvent(e) // sol/sağ/OK: kanal seçimi
            }
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_MENU -> {
                    if (e.repeatCount == 0) setPanel(true); return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> return true
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    if (e.repeatCount == 0) step(-1); return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    if (e.repeatCount == 0) step(1); return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (player.isPlaying) player.pause() else player.play(); return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // ---------- lifecycle ----------
    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onStart() {
        super.onStart()
        player.attachViews(videoLayout, null, false, false)
        current?.let { play(it, playGroup) }
    }

    override fun onStop() {
        super.onStop()
        player.stop()
        player.detachViews()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        player.release()
        libVLC.release()
    }
}
