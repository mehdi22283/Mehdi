package az.zengyazi

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.net.Uri
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF22A559)   // gələn
private val Blue = Color(0xFF2F7CF6)    // gedən
private val WaGreen = Color(0xFF25D366)
private val Red = Color(0xFFD32F2F)

class MainActivity : ComponentActivity() {
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        permLauncher.launch(perms.toTypedArray())
        setContent {
            MaterialTheme(colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App(onExit = { finish() })
                }
            }
        }
    }
}

class Player(private val ctx: Context) {
    var path by mutableStateOf<String?>(null)
    var playing by mutableStateOf(false)
    var pos by mutableIntStateOf(0)
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            mp?.let { pos = it.currentPosition }
            if (playing) h.postDelayed(this, 250)
        }
    }

    private fun load(r: Rec) {
        release()
        mp = MediaPlayer().apply {
            setDataSource(r.file.path); prepare()
            setOnCompletionListener { this@Player.playing = false; this@Player.pos = 0 }
        }
        path = r.file.path; pos = 0
    }

    fun toggle(r: Rec) {
        if (path != r.file.path) load(r)
        val m = mp ?: return
        if (playing) { m.pause(); playing = false }
        else { m.start(); playing = true; h.post(tick) }
    }

    fun seek(r: Rec, frac: Float) {
        if (path != r.file.path) load(r)
        val t = (frac * r.durMs).toInt()
        mp?.seekTo(t); pos = t
    }

    fun release() { mp?.release(); mp = null; playing = false; h.removeCallbacks(tick) }
}

private fun fmt(ms: Int): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun App(onExit: () -> Unit) {
    val ctx = LocalContext.current
    var consent by remember { mutableStateOf(Repo.hasConsent(ctx)) }
    val active by RecState.active.collectAsState()
    var list by remember { mutableStateOf(emptyList<Rec>()) }
    var filter by remember { mutableStateOf("Hamısı") }
    val player = remember { Player(ctx) }
    var listenerOn by remember { mutableStateOf(false) }

    LaunchedEffect(active) {
        list = Repo.load(ctx)
        listenerOn = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    if (!consent) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Vacib xəbərdarlıq") },
            text = {
                Text("Zəngin yazılması üçün qarşı tərəfin xəbəri və razılığı lazımdır. " +
                    "Gizli yazı bir çox ölkədə qanunsuzdur. Bu tətbiqdən yalnız qanuni məqsədlə " +
                    "və qarşı tərəfi xəbərdar edərək istifadə edəcəyinizi təsdiq edirsiniz.")
            },
            confirmButton = { TextButton(onClick = { Repo.setConsent(ctx); consent = true }) { Text("Razıyam") } },
            dismissButton = { TextButton(onClick = onExit) { Text("Çıx") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        // YUXARIDA "Zəng yazılır" göstəricisi
        AnimatedVisibility(visible = active != null) {
            active?.let { Banner(it) }
        }
        Column(Modifier.padding(16.dp)) {
            Text("Zəng Yazıları", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Hamısı", "Telefon", "WhatsApp").forEach {
                    FilterChip(selected = filter == it, onClick = { filter = it }, label = { Text(it) })
                }
            }
            if (!listenerOn) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }) { Text("WhatsApp zənglərini aktiv et") }
            }
            SetupCard()
            Spacer(Modifier.height(10.dp))
            val shown = list.filter { filter == "Hamısı" || it.app == filter }
            if (shown.isEmpty()) Text("Hələ yazı yoxdur.", color = Color.Gray)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(shown, key = { it.file.path }) { RecItem(it, player) }
            }
        }
    }
}

@Composable
fun Banner(info: Info) {
    val elapsed by produceState(0L, info) {
        while (true) { value = (System.currentTimeMillis() - info.startMs) / 1000; delay(1000) }
    }
    val a by rememberInfiniteTransition(label = "pulse").animateFloat(
        1f, 0.2f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a"
    )
    Row(
        Modifier.fillMaxWidth().background(Red).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).alpha(a).background(Color.White, CircleShape))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Zəng yazılır", color = Color.White, fontWeight = FontWeight.Bold)
            val src by RecState.source.collectAsState()
            Text("${info.number} · ${info.app}", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            if (src.isNotEmpty()) Text("Mənbə: $src", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
        }
        Text("%d:%02d".format(elapsed / 60, elapsed % 60), color = Color.White, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun RecItem(r: Rec, p: Player) {
    val color = if (r.incoming) Green else Blue
    val mine = p.path == r.file.path
    val pos = if (mine) p.pos else 0
    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
                Icon(
                    if (r.incoming) Icons.Filled.CallReceived else Icons.Filled.CallMade,
                    contentDescription = if (r.incoming) "Gələn" else "Gedən", tint = Color.White
                )
            }
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(r.number, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f, fill = false))
                    Text(
                        r.app, color = Color.White, fontSize = 11.sp,
                        modifier = Modifier.clip(RoundedCornerShape(10.dp))
                            .background(if (r.app == "WhatsApp") WaGreen else Color.Gray)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
                Text(
                    (if (r.incoming) "Gələn" else "Gedən") + " · " +
                        SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(r.ts)),
                    fontSize = 12.sp, color = Color.Gray
                )
                // Nömrənin altında musiqi pleyeri çubuğu
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { p.toggle(r) }) {
                        Icon(if (mine && p.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Oynat")
                    }
                    Slider(
                        value = if (r.durMs > 0) pos.toFloat() / r.durMs else 0f,
                        onValueChange = { p.seek(r, it) },
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color)
                    )
                    Text("${fmt(pos)}/${fmt(r.durMs)}", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }
    }
}

private fun tryOpen(ctx: Context, vararg intents: Intent) {
    for (i in intents) {
        try { ctx.startActivity(i); return } catch (_: Exception) {}
    }
}

@Composable
fun SetupCard() {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var speaker by remember { mutableStateOf(Repo.speaker(ctx)) }
    val appDetails = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
    Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Xiaomi quraşdırması", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { open = !open }) { Text(if (open) "Gizlət" else "Aç") }
            }
            if (open) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Zəngdə avtomatik dinamik rejimi", modifier = Modifier.weight(1f), fontSize = 14.sp)
                    Switch(checked = speaker, onCheckedChange = { speaker = it; Repo.setSpeaker(ctx, it) })
                }
                SourcePicker()
                OutlinedButton(onClick = {
                    tryOpen(ctx,
                        Intent().setComponent(ComponentName("com.miui.securitycenter",
                            "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                        appDetails)
                }) { Text("1. Avtostartı aç") }
                OutlinedButton(onClick = {
                    tryOpen(ctx,
                        Intent().setComponent(ComponentName("com.miui.powerkeeper",
                            "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"))
                            .putExtra("package_name", ctx.packageName)
                            .putExtra("package_label", "Zəng Yazıları"),
                        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }) { Text("2. Batareya: Məhdudiyyət yoxdur") }
                OutlinedButton(onClick = {
                    tryOpen(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }) { Text("3. Köməkçi xidməti aç") }
                OutlinedButton(onClick = { tryOpen(ctx, appDetails) }) { Text("4. İcazələr (hamısına icazə ver)") }
                Text("Sonra son tətbiqlər ekranında bu tətbiqi aşağı çəkib kilidləyin.",
                    fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun SourcePicker() {
    val ctx = LocalContext.current
    var sel by remember { mutableStateOf(Repo.source(ctx)) }
    var exp by remember { mutableStateOf(false) }
    val label = if (sel in Sources.all.indices) Sources.all[sel].first else "Avtomatik (hamısını sına)"
    Column {
        Text("Səs mənbəyi", fontSize = 12.sp, color = Color.Gray)
        OutlinedButton(onClick = { exp = true }, modifier = Modifier.fillMaxWidth()) { Text(label, fontSize = 13.sp) }
        DropdownMenu(expanded = exp, onDismissRequest = { exp = false }) {
            DropdownMenuItem(text = { Text("Avtomatik (hamısını sına)") },
                onClick = { sel = -1; Repo.setSource(ctx, -1); exp = false })
            Sources.all.forEachIndexed { i, (name, _) ->
                DropdownMenuItem(text = { Text(name) },
                    onClick = { sel = i; Repo.setSource(ctx, i); exp = false })
            }
        }
    }
}
