package com.mehdi.keymapper;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.List;
import java.util.Locale;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private TextView status, adbStatus;
    private LinearLayout mappingsBox;
    private MappingStore store;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new MappingStore(this);
        KeyInjectorClient.init(this);
        buildUi();
        maybeRequestNotificationPermission();
        startKeepAlive();
        try { Shizuku.addRequestPermissionResultListener((requestCode, grantResult) -> refreshStatus()); } catch(Throwable ignored){}
    }

    @Override protected void onResume() { super.onResume(); startKeepAlive(); refreshStatus(); renderMappings(); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,24,32,32);
        scroll.addView(root);

        TextView title = new TextView(this); title.setText("Mehdi Key Mapper"); title.setTextSize(27); title.setGravity(Gravity.CENTER); root.addView(title, lp());
        TextView sub = new TextView(this); sub.setText("Xiaomi TV Box 2 / Android • sürətli lokal key mapper"); sub.setTextSize(15); sub.setGravity(Gravity.CENTER); root.addView(sub, lp());

        status = new TextView(this); status.setTextSize(16); status.setPadding(0,18,0,8); root.addView(status, lp());
        adbStatus = new TextView(this); adbStatus.setTextSize(15); root.addView(adbStatus, lp());

        Button adb = button("ADB ilə qoşul / yoxla", v -> connectAdb()); root.addView(adb, lp());
        Button enable = button("Accessibility-i avtomatik aktiv et", v -> {
            boolean ok = AccessibilityState.ensureEnabled(this);
            Toast.makeText(this, ok ? "Accessibility aktivdir" : "WRITE_SECURE_SETTINGS tələb olunur", Toast.LENGTH_SHORT).show();
            refreshStatus();
        }); root.addView(enable, lp());

        Button shizuku = button("Shizuku / Injector statusu", v -> {
            try { if (Shizuku.pingBinder() && !KeyInjectorClient.hasShizukuPermission()) KeyInjectorClient.requestPermission(); else KeyInjectorClient.onShizukuBinderReady(); } catch(Throwable ignored){}
            refreshStatus();
        }); root.addView(shizuku, lp());

        Button battery = button("Batareya məhdudiyyətini aç", v -> {
            try { startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:"+getPackageName()))); } catch(Throwable e) { try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch(Throwable ignored){} }
        }); root.addView(battery, lp());

        TextView h = new TextView(this); h.setText("Düymə xəritələri"); h.setTextSize(22); h.setPadding(0,22,0,8); root.addView(h,lp());
        TextView hint = new TextView(this); hint.setText("Qısa basma və DOWN/UP/repeat hadisələri saxlanılır. Dəyişikliklər dərhal servisdə istifadə olunur."); root.addView(hint,lp());
        mappingsBox = new LinearLayout(this); mappingsBox.setOrientation(LinearLayout.VERTICAL); root.addView(mappingsBox,lp());
        Button add = button("＋ Yeni düymə əlavə et", v -> editMapping(-1)); root.addView(add,lp());

        TextView special = new TextView(this); special.setText("\nXüsusi funksiyalar\nLong BUTTON_5 → es.ottplayer.tv\nLong HOME → cari tətbiqi Force Stop\n\nServis boot zamanı avtomatik başlayır və foreground notification saxlayır."); special.setTextSize(16); root.addView(special,lp());
        Button start = button("Arxa plan servisinin indi başlat", v -> { startKeepAlive(); refreshStatus(); }); root.addView(start,lp());
        setContentView(scroll);
        renderMappings(); refreshStatus();
    }

    private void renderMappings() {
        if (mappingsBox == null) return; mappingsBox.removeAllViews(); List<MappingStore.Mapping> list=store.get();
        for(int i=0;i<list.size();i++) {
            final int index=i; MappingStore.Mapping m=list.get(i);
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,8,0,8);
            TextView t=new TextView(this); t.setText(m.sourceName()+"  →  "+m.targetName()); t.setTextSize(17); row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            Button edit=button("Redaktə",v->editMapping(index)); row.addView(edit,new LinearLayout.LayoutParams(-2,-2));
            Button del=button("Sil",v->{store.delete(index);renderMappings();}); row.addView(del,new LinearLayout.LayoutParams(-2,-2));
            mappingsBox.addView(row);
        }
    }

    private void editMapping(int index) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(16,8,16,0);
        EditText src=new EditText(this); src.setHint("Mənbə: KEYCODE_BUTTON_6 və ya 6"); box.addView(src);
        EditText dst=new EditText(this); dst.setHint("Hədəf: KEYCODE_DPAD_LEFT və ya 21"); box.addView(dst);
        CheckBox enabled=new CheckBox(this); enabled.setText("Aktiv"); enabled.setChecked(true); box.addView(enabled);
        if(index>=0){ MappingStore.Mapping m=store.get().get(index); src.setText(m.sourceName()); dst.setText(m.targetName()); enabled.setChecked(m.enabled); }
        AlertDialog d=new AlertDialog.Builder(this).setTitle(index<0?"Düymə əlavə et":"Düyməni redaktə et").setView(box).setNegativeButton("Ləğv",null).setPositiveButton("Yadda saxla",null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{ int s=MappingStore.parseKey(src.getText().toString()), t=MappingStore.parseKey(dst.getText().toString()); if(s<0||t<0){Toast.makeText(this,"KEYCODE düzgün deyil",Toast.LENGTH_SHORT).show();return;} MappingStore.Mapping m=new MappingStore.Mapping(s,t,enabled.isChecked()); if(index<0)store.add(m);else store.update(index,m); d.dismiss();renderMappings(); }); d.show();
    }

    private void connectAdb(){
        adbStatus.setText("ADB yoxlanılır: "+Config.ADB_HOST+":"+Config.ADB_PORT+" …");
        new Thread(()->{
            boolean ok=false; String msg;
            try(Socket s=new Socket()){ s.connect(new InetSocketAddress(Config.ADB_HOST,Config.ADB_PORT),1200); ok=true; msg="ADB server portu əlçatandır"; }
            catch(Exception e){msg="ADB qoşulmadı: "+e.getClass().getSimpleName();}
            boolean access=AccessibilityState.ensureEnabled(this);
            runOnUiThread(()->{adbStatus.setText("ADB: "+(ok?"CONNECTED":"OFF")+" • "+msg+"\nAccessibility: "+(access?"ON":"OFF"));refreshStatus();});
        }).start();
    }

    private Button button(String text, View.OnClickListener l){Button b=new Button(this);b.setText(text);b.setOnClickListener(l);return b;}
    private LinearLayout.LayoutParams lp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=8;return p;}
    private void startKeepAlive(){try{Intent i=new Intent(this,KeepAliveService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}catch(Throwable ignored){}}
    private void refreshStatus(){if(status==null)return;boolean a=AccessibilityState.isEnabled(this),s=false;try{s=Shizuku.pingBinder();}catch(Throwable ignored){}boolean inj=KeyInjectorClient.isAvailable();status.setText(String.format(Locale.US,"Program: RUNNING\nForeground service: ON\nAccessibility: %s\nShizuku: %s\nInput injector: %s\nADB target: %s:%d",a?"ON":"OFF",s?"ON":"OFF",inj?"READY":"OFF",Config.ADB_HOST,Config.ADB_PORT));}
    private void maybeRequestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=getPackageManager().PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},8801);}
}
