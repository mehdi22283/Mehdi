package az.axtaris.baza

import android.app.Activity
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import java.io.File
import java.util.Locale

data class Card(val path: String, val title: String, val headers: List<String>, val cells: List<String>)

class MainActivity : Activity() {

    private lateinit var db: SQLiteDatabase
    private val ui = Handler(Looper.getMainLooper())
    private var searchGen = 0
    private var sugGen = 0
    private var suppress = false

    // search panel
    private lateinit var etStreet: EditText
    private lateinit var etMenzil: EditText
    private lateinit var etSoyad: EditText
    private lateinit var etAd: EditText
    private lateinit var etAta: EditText
    private lateinit var etNomre: EditText
    private lateinit var form: LinearLayout
    private lateinit var row2: LinearLayout
    private lateinit var row3: LinearLayout
    private lateinit var sugBox: LinearLayout
    private lateinit var tvCount: TextView
    private lateinit var searchList: ListView
    private val searchAdapter by lazy { CardAdapter() }

    // catalog panel
    private lateinit var catPanel: LinearLayout
    private lateinit var tvPath: TextView
    private lateinit var catList: ListView
    private lateinit var searchPanel: LinearLayout
    private val cardAdapterCat by lazy { CardAdapter() }
    private var level = 0
    private var fileId = 0L
    private var streetId = 0L
    private var buildingId = 0L
    private var fileName = ""
    private var streetName = ""
    private var catIds = ArrayList<Long>()

    private lateinit var btnSearch: Button
    private lateinit var btnCat: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = openDb()
        buildUi()
        showTab(true)
    }

    // ---------- database ----------
    private fun openDb(): SQLiteDatabase {
        val f = File(filesDir, "data.db")
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val ver = 2
        if (!f.exists() || prefs.getInt("dbver", 0) != ver) {
            assets.open("data.db").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            prefs.edit().putInt("dbver", ver).apply()
        }
        return SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY)
    }

    private fun fold(s: String): String {
        var t = s.replace('İ', 'i').replace('I', 'ı').lowercase(Locale.ROOT)
        t = t.replace('ə', 'e').replace('ı', 'i').replace('ö', 'o').replace('ü', 'u')
            .replace('ş', 's').replace('ç', 'c').replace('ğ', 'g')
        return t.trim().replace(Regex("\\s+"), " ")
    }

    // ---------- UI ----------
    private fun edit(hint: String, key: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText =
        EditText(this).apply {
            this.hint = hint
            textSize = 14f
            isSingleLine = true
            inputType = type or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.WHITE); setStroke(dp(1), Color.parseColor("#B0BEC5")); cornerRadius = dp(8).toFloat()
            }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (suppress) return
                    scheduleSearch(); scheduleSuggest(key)
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            setOnFocusChangeListener { _, has -> if (has) scheduleSuggest(key) }
            setOnEditorActionListener { v, _, _ ->
                hideSug()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
                true
            }
        }

    private fun rowOf(vararg items: Pair<View, Float>): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            items.forEachIndexed { i, (v, w) ->
                addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w).apply {
                    if (i > 0) leftMargin = dp(6)
                })
            }
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#ECEFF1"))
        }

        btnSearch = Button(this).apply { text = "Axtarış"; setOnClickListener { showTab(true) } }
        btnCat = Button(this).apply { text = "Kataloq"; setOnClickListener { showTab(false) } }
        root.addView(rowOf(btnSearch to 1f, btnCat to 1f), LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(24); leftMargin = dp(8); rightMargin = dp(8)
        })

        // ----- search panel -----
        searchPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        etStreet = edit("Küçə adı", "street")
        etMenzil = edit("Mənzil", "menzil")
        etSoyad = edit("Soyad", "soyad")
        etAd = edit("Ad", "ad")
        etAta = edit("Atasının adı", "ata")
        etNomre = edit("Nömrə", "nomre", InputType.TYPE_CLASS_PHONE)

        form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        // 1) Küçə adı — ən yuxarıda
        form.addView(etStreet, LinearLayout.LayoutParams(-1, -2))
        // 2) qalan xanalar onun altında
        row2 = rowOf(etMenzil to 0.8f, etSoyad to 1.1f, etAd to 1f)
        row3 = rowOf(etAta to 1f, etNomre to 1f)
        form.addView(row2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        form.addView(row3, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        sugBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            elevation = dp(6).toFloat()
            background = GradientDrawable().apply {
                setColor(Color.WHITE); setStroke(dp(1), Color.parseColor("#B0BEC5")); cornerRadius = dp(8).toFloat()
            }
        }
        form.addView(sugBox, 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })

        val btnClear = Button(this).apply {
            text = "Təmizlə"
            setOnClickListener {
                suppress = true
                listOf(etStreet, etMenzil, etSoyad, etAd, etAta, etNomre).forEach { it.setText("") }
                suppress = false
                hideSug(); scheduleSearch()
            }
        }
        form.addView(btnClear, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        searchPanel.addView(form)

        tvCount = TextView(this).apply { textSize = 13f; setPadding(dp(12), dp(2), dp(12), dp(4)); setTextColor(Color.DKGRAY) }
        searchPanel.addView(tvCount)
        searchList = ListView(this).apply {
            divider = null; adapter = searchAdapter
            clipToPadding = false; setPadding(dp(8), 0, dp(8), dp(8))
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) hideSug(); false }
        }
        searchPanel.addView(searchList, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(searchPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        // ----- catalog panel -----
        catPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvPath = TextView(this).apply {
            textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(8), dp(12), dp(8)); setTextColor(Color.parseColor("#263238"))
        }
        catPanel.addView(tvPath)
        catList = ListView(this).apply { divider = null }
        catList.setOnItemClickListener { _, _, pos, _ ->
            if (level < 3) openChild(catIds[pos], (catList.adapter.getItem(pos) as String))
        }
        catPanel.addView(catList, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(catPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        loadLevel()
    }

    private fun showTab(search: Boolean) {
        searchPanel.visibility = if (search) View.VISIBLE else View.GONE
        catPanel.visibility = if (search) View.GONE else View.VISIBLE
        btnSearch.alpha = if (search) 1f else 0.55f
        btnCat.alpha = if (search) 0.55f else 1f
        if (search) scheduleSearch() else hideSug()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (catPanel.visibility == View.VISIBLE && level > 0) {
            level--; loadLevel()
        } else if (catPanel.visibility == View.VISIBLE) {
            showTab(true)
        } else if (sugBox.visibility == View.VISIBLE) {
            hideSug()
        } else super.onBackPressed()
    }

    // ---------- filters ----------
    private fun fieldOf(key: String): EditText = when (key) {
        "street" -> etStreet; "menzil" -> etMenzil; "soyad" -> etSoyad
        "ad" -> etAd; "ata" -> etAta; else -> etNomre
    }

    /** Bütün xanalara görə şərtlər; exclude — öz xanası (təklif üçün) */
    private fun buildWhere(exclude: String?, where: ArrayList<String>, args: ArrayList<String>) {
        if (exclude != "street") fold(etStreet.text.toString()).split(' ').filter { it.isNotEmpty() }
            .forEach { where.add("b.name_n LIKE ?"); args.add("%$it%") }
        val mz = fold(etMenzil.text.toString())
        if (exclude != "menzil" && mz.isNotEmpty()) { where.add("r.menzil_n = ?"); args.add(mz) }
        val so = fold(etSoyad.text.toString())
        if (exclude != "soyad" && so.isNotEmpty()) { where.add("r.soyad_n LIKE ?"); args.add("%$so%") }
        val ad = fold(etAd.text.toString())
        if (exclude != "ad" && ad.isNotEmpty()) { where.add("r.ad_n LIKE ?"); args.add("%$ad%") }
        val at = fold(etAta.text.toString())
        if (exclude != "ata" && at.isNotEmpty()) { where.add("r.ata_n LIKE ?"); args.add("%$at%") }
        val nr = etNomre.text.toString().filter { it.isDigit() }
        if (exclude != "nomre" && nr.isNotEmpty()) { where.add("r.nomre_d LIKE ?"); args.add("%$nr%") }
    }

    // ---------- suggestions (Google kimi) ----------
    private fun scheduleSuggest(key: String) {
        ui.removeCallbacksAndMessages("g")
        ui.postAtTime({ doSuggest(key) }, "g", SystemClock.uptimeMillis() + 120)
    }

    private fun hideSug() {
        sugGen++
        sugBox.visibility = View.GONE
    }

    private fun doSuggest(key: String) {
        val et = fieldOf(key)
        val q = fold(et.text.toString())
        if (key == "nomre" || q.isEmpty() || !et.hasFocus()) { hideSug(); return }
        val gen = ++sugGen
        Thread {
            val items = ArrayList<String>()
            try {
                if (key == "street") {
                    val toks = q.split(' ').filter { it.isNotEmpty() }
                    val w1 = toks.joinToString(" AND ") { "name_n LIKE ?" }
                    val a1 = toks.map { "%$it%" }.toTypedArray()
                    db.rawQuery("SELECT DISTINCT name FROM streets WHERE $w1 ORDER BY name LIMIT 4", a1).use { c ->
                        while (c.moveToNext()) items.add(c.getString(0))
                    }
                    val w2 = toks.joinToString(" AND ") { "name_n LIKE ?" }
                    db.rawQuery("SELECT DISTINCT name FROM buildings WHERE $w2 ORDER BY file_id, ord LIMIT 10", a1).use { c ->
                        while (c.moveToNext()) { val n = c.getString(0); if (n !in items) items.add(n) }
                    }
                } else {
                    val col = when (key) { "menzil" -> "r.menzil"; "soyad" -> "r.soyad"; "ad" -> "r.ad"; else -> "r.ata" }
                    val where = ArrayList<String>(); val args = ArrayList<String>()
                    buildWhere(key, where, args)
                    where.add("${col}_n LIKE ?"); args.add("$q%")
                    where.add("$col <> ''")
                    db.rawQuery(
                        "SELECT DISTINCT $col FROM rows r JOIN buildings b ON b.id = r.building_id WHERE " +
                            where.joinToString(" AND ") + " ORDER BY ${col}_n LIMIT 8", args.toTypedArray()
                    ).use { c -> while (c.moveToNext()) items.add(c.getString(0)) }
                }
            } catch (e: Exception) { /* ignore */ }
            runOnUiThread { if (gen == sugGen) showSug(key, items) }
        }.start()
    }

    private fun showSug(key: String, items: List<String>) {
        if (items.isEmpty()) { sugBox.visibility = View.GONE; return }
        val anchor: View = when (key) { "street" -> etStreet; "menzil", "soyad", "ad" -> row2; else -> row3 }
        form.removeView(sugBox)
        form.addView(sugBox, form.indexOfChild(anchor) + 1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        sugBox.removeAllViews()
        for (it in items) {
            sugBox.addView(TextView(this).apply {
                text = "🔍  $it"; textSize = 15f; setTextColor(Color.parseColor("#263238"))
                setPadding(dp(12), dp(11), dp(12), dp(11))
                setOnClickListener {
                    val et = fieldOf(key)
                    suppress = true
                    et.setText(items[sugBox.indexOfChild(this)])
                    et.setSelection(et.text.length)
                    suppress = false
                    hideSug(); scheduleSearch()
                }
            })
        }
        sugBox.visibility = View.VISIBLE
    }

    // ---------- search ----------
    private fun scheduleSearch() {
        ui.removeCallbacksAndMessages("s")
        ui.postAtTime({ doSearch() }, "s", SystemClock.uptimeMillis() + 250)
    }

    private fun doSearch() {
        val empty = listOf(etStreet, etMenzil, etSoyad, etAd, etAta).all { fold(it.text.toString()).isEmpty() } &&
            etNomre.text.toString().none { it.isDigit() }
        if (empty) {
            searchAdapter.set(emptyList()); tvCount.text = "Axtarmaq üçün yuxarıdakı xanalara yazın"; return
        }
        val gen = ++searchGen
        Thread {
            val where = ArrayList<String>(); val args = ArrayList<String>()
            buildWhere(null, where, args)
            val sql = "SELECT r.cells, b.headers, b.name, b.title, f.name FROM rows r " +
                "JOIN buildings b ON b.id = r.building_id JOIN files f ON f.id = b.file_id " +
                "WHERE " + where.joinToString(" AND ") + " ORDER BY f.ord, b.ord, r.ord LIMIT 201"
            val list = ArrayList<Card>()
            try {
                db.rawQuery(sql, args.toTypedArray()).use { c ->
                    while (c.moveToNext()) {
                        list.add(Card(
                            path = c.getString(4) + "  ›  " + c.getString(2),
                            title = c.getString(3),
                            headers = jsonList(c.getString(1)),
                            cells = jsonList(c.getString(0))
                        ))
                    }
                }
            } catch (e: Exception) { /* ignore */ }
            runOnUiThread {
                if (gen == searchGen) {
                    val more = list.size > 200
                    val shown = if (more) list.subList(0, 200) else list
                    searchAdapter.set(shown)
                    tvCount.text = if (shown.isEmpty()) "Nəticə tapılmadı"
                    else if (more) "İlk 200 nəticə göstərilir — axtarışı dəqiqləşdirin" else "${shown.size} nəticə"
                    searchList.setSelection(0)
                }
            }
        }.start()
    }

    private fun jsonList(s: String): List<String> {
        val a = JSONArray(s); return List(a.length()) { a.getString(it) }
    }

    // ---------- catalog ----------
    private fun openChild(id: Long, label: String) {
        when (level) {
            0 -> { fileId = id; fileName = label.substringBefore("  (") }
            1 -> { streetId = id; streetName = label.substringBefore("  (") }
            2 -> { buildingId = id }
        }
        level++; loadLevel()
    }

    private fun loadLevel() {
        val labels = ArrayList<String>(); catIds = ArrayList()
        when (level) {
            0 -> {
                tvPath.text = "Əsas kateqoriya (fayl)"
                db.rawQuery("SELECT f.id, f.name, (SELECT count(*) FROM streets WHERE file_id=f.id) FROM files f ORDER BY f.ord", null).use { c ->
                    while (c.moveToNext()) { catIds.add(c.getLong(0)); labels.add("${c.getString(1)}  (${c.getInt(2)} küçə)") }
                }
            }
            1 -> {
                tvPath.text = fileName
                db.rawQuery("SELECT s.id, s.name, (SELECT count(*) FROM buildings WHERE street_id=s.id) FROM streets s WHERE s.file_id=? ORDER BY s.ord", arrayOf(fileId.toString())).use { c ->
                    while (c.moveToNext()) { catIds.add(c.getLong(0)); labels.add("${c.getString(1)}  (${c.getInt(2)} ünvan)") }
                }
            }
            2 -> {
                tvPath.text = "$fileName  ›  $streetName"
                db.rawQuery("SELECT b.id, b.name, (SELECT count(*) FROM rows WHERE building_id=b.id) FROM buildings b WHERE b.street_id=? ORDER BY b.ord", arrayOf(streetId.toString())).use { c ->
                    while (c.moveToNext()) { catIds.add(c.getLong(0)); labels.add("${c.getString(1)}  (${c.getInt(2)} mənzil)") }
                }
            }
            3 -> {
                val cards = ArrayList<Card>()
                db.rawQuery("SELECT headers, name, title FROM buildings WHERE id=?", arrayOf(buildingId.toString())).use { b ->
                    if (b.moveToFirst()) {
                        val hdr = jsonList(b.getString(0)); val nm = b.getString(1); val title = b.getString(2)
                        tvPath.text = "$fileName  ›  $nm"
                        db.rawQuery("SELECT cells FROM rows WHERE building_id=? ORDER BY ord", arrayOf(buildingId.toString())).use { c ->
                            while (c.moveToNext()) cards.add(Card("", title, hdr, jsonList(c.getString(0))))
                        }
                    }
                }
                cardAdapterCat.set(cards)
                catList.adapter = cardAdapterCat
                catList.setPadding(dp(8), 0, dp(8), dp(8)); catList.clipToPadding = false
                return
            }
        }
        catList.setPadding(0, 0, 0, 0)
        catList.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.textSize = 15f; v.setTextColor(Color.parseColor("#263238"))
                return v
            }
        }
    }

    // ---------- card adapter ----------
    inner class CardAdapter : BaseAdapter() {
        private var items: List<Card> = emptyList()
        fun set(l: List<Card>) { items = l; notifyDataSetChanged() }
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val c = items[position]
            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = dp(10).toFloat(); setStroke(dp(1), Color.parseColor("#CFD8DC"))
                }
            }
            if (c.path.isNotEmpty()) box.addView(TextView(this@MainActivity).apply {
                text = c.path; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#1565C0"))
            })
            if (c.title.isNotEmpty()) box.addView(TextView(this@MainActivity).apply {
                text = c.title; textSize = 11f; setTextColor(Color.GRAY); setPadding(0, 0, 0, dp(4))
            })
            for (i in c.headers.indices) {
                val v = c.cells.getOrNull(i).orEmpty().ifEmpty { "—" }
                box.addView(TextView(this@MainActivity).apply {
                    text = "${c.headers[i]}: $v"; textSize = 14f; setTextColor(Color.parseColor("#263238"))
                    setTextIsSelectable(true)
                })
            }
            val wrap = FrameLayout(this@MainActivity).apply {
                setPadding(0, dp(3), 0, dp(3)); layoutParams = AbsListView.LayoutParams(-1, -2)
            }
            wrap.addView(box, FrameLayout.LayoutParams(-1, -2))
            return wrap
        }
    }
}
