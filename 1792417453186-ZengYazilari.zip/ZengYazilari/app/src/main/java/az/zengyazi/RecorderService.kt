package az.zengyazi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.File

class RecorderService : Service() {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            START -> start(
                intent.getStringExtra("number") ?: "Naməlum",
                intent.getStringExtra("app") ?: "Telefon",
                intent.getBooleanExtra("incoming", true)
            )
            else -> { stopRec(); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun start(number: String, app: String, incoming: Boolean) {
        if (!Repo.hasConsent(this) || rec != null) { stopSelf(); return }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Zəng yazısı", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = NotificationCompat.Builder(this, "rec")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Zəng yazılır")
            .setContentText("$number · $app")
            .setOngoing(true).build()
        try {
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) { stopSelf(); return }

        val info = Info(number, app, incoming, System.currentTimeMillis())
        val f = Repo.newFile(this, info)
        // Əvvəl zəng səsini (VOICE_CALL) yoxlayır, alınmasa mikrofona (dinamik rejimi) keçir.
        val r = tryRecorder(MediaRecorder.AudioSource.VOICE_CALL, f)
            ?: tryRecorder(MediaRecorder.AudioSource.MIC, f)
        if (r == null) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return }
        rec = r; file = f
        RecState.active.value = info
    }

    private fun tryRecorder(src: Int, f: File): MediaRecorder? = try {
        (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()).apply {
            setAudioSource(src)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(96000)
            setAudioSamplingRate(44100)
            setOutputFile(f.path)
            prepare(); start()
        }
    } catch (e: Exception) { f.delete(); null }

    private fun stopRec() {
        rec?.let {
            try { it.stop() } catch (e: RuntimeException) { file?.delete() }
            it.release()
        }
        rec = null; file = null
        RecState.active.value = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() { stopRec(); super.onDestroy() }

    companion object {
        const val START = "az.zengyazi.START"
        const val STOP = "az.zengyazi.STOP"

        fun start(c: Context, number: String, app: String, incoming: Boolean) {
            val i = Intent(c, RecorderService::class.java).setAction(START)
                .putExtra("number", number).putExtra("app", app).putExtra("incoming", incoming)
            ContextCompat.startForegroundService(c, i)
        }

        fun stop(c: Context) {
            c.startService(Intent(c, RecorderService::class.java).setAction(STOP))
        }
    }
}
