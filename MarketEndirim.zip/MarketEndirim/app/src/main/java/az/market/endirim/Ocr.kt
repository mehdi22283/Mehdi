package az.market.endirim

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import com.googlecode.tesseract.android.TessBaseAPI
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** PDF-in ilk 2 səhifəsindən OCR ilə tarix oxuyur (nəticə yadda saxlanır). */
object Ocr {
    suspend fun pdfDate(ctx: Context, file: File): String? {
        val prefs = ctx.getSharedPreferences("ocr", Context.MODE_PRIVATE)
        if (prefs.contains(file.name)) return prefs.getString(file.name, "")?.ifEmpty { null }
        return try {
            val sb = StringBuilder()
            for (i in 0..1) {
                val bmp = withContext(Dispatchers.IO) { renderPage(file, i) } ?: break
                sb.append(recognize(bmp)).append('\n')
            }
            val d = DateUtil.find(sb.toString())
            prefs.edit().putString(file.name, d ?: "").apply()
            d
        } catch (e: Exception) {
            null
        }
    }

    private fun renderPage(file: File, index: Int): Bitmap? = try {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            val r = PdfRenderer(pfd)
            try {
                if (index >= r.pageCount) null else {
                    val p = r.openPage(index)
                    try {
                        val w = 1600
                        val h = (w.toFloat() * p.height / p.width).toInt()
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bmp
                    } finally {
                        p.close()
                    }
                }
            } finally {
                r.close()
            }
        }
    } catch (e: Exception) {
        null
    }

    suspend fun recognize(bmp: Bitmap): String = suspendCancellableCoroutine { c ->
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { c.resume(it.text) }
            .addOnFailureListener { c.resumeWithException(it) }
    }

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /** Mətn + sətirlərin koordinatları (məhsul skanı üçün). */
    suspend fun recognizeText(bmp: Bitmap): Text = suspendCancellableCoroutine { c ->
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { c.resume(it) }
            .addOnFailureListener { c.resumeWithException(it) }
    }

    // ---------------- Tesseract (rus + aze) ----------------
    // Paralel skan üçün bir neçə Tesseract nüsxəsi (hovuz) işləyir; hər nüsxə eyni anda yalnız bir işə baxır.
    private val tessHttp = OkHttpClient()
    private val tessLock = Any()
    private val tessQueue = java.util.concurrent.ConcurrentLinkedQueue<TessBaseAPI>()
    @Volatile private var tessFailed = false
    @Volatile private var tessLangs: String? = null

    /** Eyni anda neçə Tesseract nüsxəsi işləyə bilər (ProductScanner skandan əvvəl təyin edir). */
    @Volatile var tessMax = 2
    private val tessGate by lazy { Semaphore(tessMax.coerceAtLeast(1)) }

    private fun tessRoot(ctx: Context) = File(ctx.filesDir, "tess")

    /** rus + aze (Azərbaycan latın: ə ı ş ç ö ü ğ ₼) modelləri bir dəfə endirilir. Biri alınmasa digəri ilə işləyir; heç biri alınmasa Tesseract söndürülür, qalan hər şey işləyir. */
    private fun tessModels(ctx: Context): String? {
        tessLangs?.let { return it }
        synchronized(tessLock) {
            tessLangs?.let { return it }
            if (tessFailed) return null
            val dir = File(tessRoot(ctx), "tessdata").apply { mkdirs() }
            val ok = ArrayList<String>()
            for (lang in listOf("aze", "rus")) {
                val f = File(dir, "$lang.traineddata")
                if (f.exists() && f.length() > 100_000) { ok.add(lang); continue }
                try {
                    val req = Request.Builder().url("https://github.com/tesseract-ocr/tessdata_fast/raw/main/$lang.traineddata").build()
                    tessHttp.newCall(req).execute().use { r ->
                        if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}")
                        val tmp = File(dir, "$lang.tmp")
                        r.body!!.byteStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                        tmp.renameTo(f)
                    }
                    if (f.exists() && f.length() > 100_000) ok.add(lang)
                } catch (e: Exception) {
                }
            }
            if (ok.isEmpty()) {
                tessFailed = true
                return null
            }
            val langs = ok.joinToString("+")
            tessLangs = langs
            return langs
        }
    }

    private fun createTess(ctx: Context): TessBaseAPI? {
        val langs = tessModels(ctx) ?: return null
        return try {
            val api = TessBaseAPI()
            if (!api.init(tessRoot(ctx).absolutePath, langs)) {
                api.recycle()
                throw IllegalStateException("tess init")
            }
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT)
            api
        } catch (e: Exception) {
            tessFailed = true
            null
        }
    }

    /** Hovuzdan boş Tesseract nüsxəsi götürür (yoxdursa yaradır; hamısı məşğulsa gözləyir), block-u işlədir, geri qaytarır. */
    private suspend fun <T> withTess(ctx: Context, block: (TessBaseAPI) -> T): T? {
        if (tessFailed) return null
        return tessGate.withPermit {
            withContext(Dispatchers.Default) {
                val api = tessQueue.poll() ?: createTess(ctx)
                if (api == null) null else try {
                    block(api)
                } finally {
                    tessQueue.offer(api)
                }
            }
        }
    }

    private const val AZ_LETTERS = "əƏıİşŞğĞöÖüÜçÇ"

    /**
     * Tesseract ilə oxunan "ML Kit-in pis oxuduğu" sətirlər. İki siyahı qaytarır:
     *  first  — kirill (rus) sətirlər (həmişə lazımdır);
     *  second — Azərbaycan xüsusi hərfi (ə ı ş ç ö ü ğ) olan, rəqəmi az sətirlər (məhsul adı) — yalnız güclü mühərrik adları
     *           oxuya bilməyibsə istifadə olunur. Çox rəqəmli sətirlərə toxunulmur.
     * Model yoxdursa iki boş siyahı.
     */
    suspend fun cyrillicLines(ctx: Context, bmp: Bitmap): Pair<List<OLine>, List<OLine>> = withTess(ctx) { api ->
        val cyrOut = ArrayList<OLine>()
        val azOut = ArrayList<OLine>()
        try {
            api.setImage(bmp)
            api.getUTF8Text()                       // tanıma işə düşür
            val it = api.resultIterator ?: return@withTess Pair<List<OLine>, List<OLine>>(cyrOut, azOut)
            val lvl = TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE
            it.begin()
            do {
                val t = it.getUTF8Text(lvl)?.trim() ?: continue
                val conf = it.confidence(lvl)
                val r = it.getBoundingRect(lvl)
                val cyr = t.count { ch -> ch in '\u0400'..'\u04FF' }
                val az = t.count { ch -> ch in AZ_LETTERS }
                val letters = t.count { ch -> ch.isLetter() }
                val digits = t.count { ch -> ch.isDigit() }
                val cyrOk = cyr >= 3 && conf >= 45f
                val azOk = cyr == 0 && az >= 1 && letters >= 4 && digits <= 2 && conf >= 60f
                if (cyrOk) cyrOut.add(OLine(t, r.left, r.top, r.right, r.bottom))
                else if (azOk) azOut.add(OLine(t, r.left, r.top, r.right, r.bottom))
            } while (it.next(lvl))
            it.delete()
        } catch (e: Exception) {
        }
        Pair<List<OLine>, List<OLine>>(cyrOut, azOut)
    } ?: Pair<List<OLine>, List<OLine>>(emptyList(), emptyList())
}
