package az.market.endirim

/**
 * Qiymət nişanındakı "böyük tam hissə + kiçik yuxarı qəpik" (8⁷⁹, 4⁹⁹) yazılışını simvolların hündürlüyünə görə oxuyur.
 *  - tam hissə: ən hündür rəqəmlər (maks. hündürlüyün ≥72%-i);
 *  - qəpik: kiçik 2 rəqəm — tam hissənin sağında və onun yuxarı yarısı hizasında;
 *  - tam hissənin ÜSTÜNDƏ qalan kiçik rəqəmlər köhnə (üstündən xətt çəkilmiş) qiymətdir, qəpik sayılmır.
 * Yalnız bu üslub tanınır; səpələnmiş və ya birmənalı olmayan nəticədə null qaytarır (ML Kit nəticəsi qalır).
 */
object BadgeReader {
    class Result(val price: Double, val conf: Float)

    fun parse(syms: List<Ocr.Sym>): Result? {
        val d = syms.sortedBy { it.l }
        if (d.size < 3) return null
        val maxH = d.maxOf { it.h }
        if (maxH < 14) return null
        val big = d.filter { it.h >= 0.72f * maxH }
        if (big.isEmpty() || big.size > 3) return null
        val bigTop = big.minOf { it.t }
        val bigBottom = big.maxOf { it.b }
        val bigRight = big.maxOf { it.r }
        // tam hissənin rəqəmləri yan-yana (eyni xətt üzərində) olmalıdır
        if (big.any { it.t > bigTop + 0.35f * maxH }) return null
        val bigH = (bigBottom - bigTop).toFloat()
        val cents = d.filter { s ->
            val cy = (s.t + s.b) / 2f
            s.h < 0.72f * maxH && s.h >= 0.25f * maxH &&
                s.l >= bigRight - 0.35f * maxH &&
                cy >= bigTop - 0.05f * bigH && cy <= bigTop + 0.6f * bigH
        }.sortedBy { it.l }
        if (cents.size < 2) return null
        val two = cents.take(2)
        // iki qəpik rəqəmi bitişik olmalıdır
        if (two[1].l - two[0].r > 0.8f * two[0].h) return null
        val ints = big.sortedBy { it.l }.joinToString("") { it.ch.toString() }
        val v = "$ints.${two[0].ch}${two[1].ch}".toDoubleOrNull() ?: return null
        if (v < 0.05 || v > 999.0) return null
        val conf = (big + two).map { it.conf }.average().toFloat()
        return Result(v, conf)
    }
}
