package com.zengyazici;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.inputmethod.InputMethodManager;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Qeydlər: nömrə/kontakt siyahısı; hər birində xatırlatmalar və sərbəst mətn qeydləri. */
public class NotesActivity extends Activity {
    LinearLayout head, content;
    String cur;          // null = siyahı, əks halda açıq nömrə/kontakt
    boolean direct;      // birbaşa nömrə ilə açılıb: geri düyməsi çıxır
    String q = "";       // axtarış sorğusu
    EditText sb;
    final SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US);

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    void paint(View v, int c1, int c2, int r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        g.setCornerRadius(dp(r));
        v.setBackground(g);
    }

    Button btn(String t, int c1, int c2, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextSize(14); b.setTextColor(Color.WHITE);
        paint(b, c1, c2, 14);
        b.setOnClickListener(l);
        return b;
    }

    Button small(String t, View.OnClickListener l) {
        Button b = btn(t, MainActivity.PURPLE, 0xFF5E35B1, l);
        b.setTextSize(13); b.setMinHeight(0); b.setMinimumHeight(0); b.setMinWidth(0); b.setMinimumWidth(0);
        b.setPadding(dp(12), dp(6), dp(12), dp(6));
        return b;
    }

    TextView tv(String t, int size, int color, boolean bold) {
        TextView x = new TextView(this);
        x.setText(t); x.setTextSize(size); x.setTextColor(color);
        if (bold) x.setTypeface(null, Typeface.BOLD);
        return x;
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF17171C); g.setCornerRadius(dp(18));
        l.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(5); lp.bottomMargin = dp(5);
        l.setLayoutParams(lp);
        return l;
    }

    LinearLayout.LayoutParams top(int dpv) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(dpv);
        return lp;
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(MainActivity.BG);
        root.setPadding(dp(14), dp(32), dp(14), dp(8));

        head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));

        sb = new EditText(this);
        sb.setHint("Nömrə və ya ad ilə axtar…"); sb.setHintTextColor(MainActivity.GRAY); sb.setTextColor(Color.WHITE);
        sb.setSingleLine(true); sb.setTextSize(14); sb.setInputType(InputType.TYPE_CLASS_TEXT);
        sb.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable sg = new GradientDrawable();
        sg.setColor(0x33FFFFFF); sg.setCornerRadius(dp(14));
        sb.setBackground(sg);
        sb.setVisibility(View.GONE);
        sb.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable e) { q = e.toString(); if (cur == null) { content.removeAllViews(); fillList(); } }
        });
        root.addView(sb, top(8));

        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(8), 0, dp(24));
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        handle(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handle(i);
    }

    void handle(Intent i) {
        String k = i == null ? null : i.getStringExtra("key");
        cur = k == null || k.isEmpty() ? null : Notes.norm(k);
        direct = cur != null;
        render();
    }

    @Override
    public void onBackPressed() {
        if (cur != null && !direct) { cur = null; render(); }
        else super.onBackPressed();
    }

    void render() {
        head.removeAllViews();
        content.removeAllViews();
        if (cur != null) {
            sb.setVisibility(View.GONE);
            renderDetail();
        } else {
            renderList();
        }
    }

    void toggleSearch() {
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (sb.getVisibility() == View.VISIBLE) {
            sb.setText("");
            sb.setVisibility(View.GONE);
            im.hideSoftInputFromWindow(sb.getWindowToken(), 0);
        } else {
            sb.setVisibility(View.VISIBLE);
            sb.requestFocus();
            im.showSoftInput(sb, 0);
        }
    }

    /** Neçənci gün qalıb (təqvim günü ilə): 0 = bu gün. */
    static long daysLeft(long due) {
        java.util.Calendar a = java.util.Calendar.getInstance(), b = java.util.Calendar.getInstance();
        b.setTimeInMillis(due);
        for (java.util.Calendar c : new java.util.Calendar[]{a, b}) {
            c.set(java.util.Calendar.HOUR_OF_DAY, 12); c.set(java.util.Calendar.MINUTE, 0);
            c.set(java.util.Calendar.SECOND, 0); c.set(java.util.Calendar.MILLISECOND, 0);
        }
        return Math.round((b.getTimeInMillis() - a.getTimeInMillis()) / 86400000.0);
    }

    static String leftText(long due) {
        long d = daysLeft(due);
        return d <= 0 ? "bu gün" : d + " gün qalıb";
    }

    // ---------- nömrə/kontakt siyahısı ----------
    void renderList() {
        TextView t = tv("📝  Qeydlər", 22, Color.WHITE, true);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        Button sbtn = small("🔍", v -> toggleSearch());
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.rightMargin = dp(8);
        head.addView(sbtn, slp);
        head.addView(small("+ Nömrə", v -> askKey()));
        fillList();
    }

    /** Ən az günü qalan nömrə yuxarıda; xatırlatması olmayanlar sonda (ən son dəyişən birinci). */
    void fillList() {
        List<Notes.Entry> all = Notes.all(this);
        List<String> keys = new ArrayList<>(Notes.keys(this));
        final java.util.Map<String, Long> nextMap = new java.util.HashMap<>();
        for (Notes.Entry e : all) {
            if (!Notes.T_REM.equals(e.type) || e.done) continue;
            Long cu = nextMap.get(e.key);
            if (cu == null || e.due < cu) nextMap.put(e.key, e.due);
        }
        Collections.sort(keys, (a, b) -> {
            Long x = nextMap.get(a), y = nextMap.get(b);
            if (x != null && y != null) return Long.compare(x, y);
            if (x != null) return -1;
            if (y != null) return 1;
            return 0; // sabit sıralama: əvvəlki (ən son dəyişən) qalır
        });
        List<String> shown = new ArrayList<>();
        for (String k : keys) if (Search.match(k, q)) shown.add(k);

        if (keys.isEmpty()) {
            TextView h = tv("Hələ qeyd və ya xatırlatma yoxdur.\n«+ Nömrə» ilə əlavə edin və ya yazılar siyahısında nömrənin yanındakı 📝 işarəsinə basın.", 14, MainActivity.GRAY, false);
            h.setPadding(0, dp(16), 0, 0);
            content.addView(h);
            return;
        }
        if (shown.isEmpty()) {
            TextView h = tv("Heç nə tapılmadı.", 14, MainActivity.GRAY, false);
            h.setPadding(0, dp(16), 0, 0);
            content.addView(h);
            return;
        }
        for (final String k : shown) {
            int notes = 0, rems = 0;
            for (Notes.Entry e : all) {
                if (!e.key.equals(k)) continue;
                if (Notes.T_NOTE.equals(e.type)) notes++; else rems++;
            }
            Long next = nextMap.get(k);
            LinearLayout c = card();
            c.addView(tv(k, 17, Color.WHITE, true));
            String sub = "📝 " + notes + " qeyd  ·  ⏰ " + rems + " xatırlatma";
            c.addView(tv(sub, 12, MainActivity.GRAY, false));
            if (next != null) {
                c.addView(tv("⏳ " + leftText(next) + "  ·  " + df.format(new Date(next)), 12, 0xFFFFB74D, false));
            }
            c.setOnClickListener(v -> { cur = k; direct = false; render(); });
            c.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setMessage("«" + k + "» üzrə bütün qeyd və xatırlatmalar silinsin?")
                        .setPositiveButton("Sil", (d, w) -> { Notes.removeKey(this, k); render(); })
                        .setNegativeButton("Ləğv et", null).show();
                return true;
            });
            content.addView(c);
        }
    }

    void askKey() {
        final EditText e = new EditText(this);
        e.setHint("Nömrə və ya ad"); e.setHintTextColor(MainActivity.GRAY); e.setTextColor(Color.WHITE);
        e.setSingleLine(true); e.setInputType(InputType.TYPE_CLASS_TEXT);
        LinearLayout l = new LinearLayout(this);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        l.addView(e, new LinearLayout.LayoutParams(-1, -2));
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Nömrə / kontakt").setView(l)
                .setPositiveButton("Davam", (dd, w) -> {
                    String k = Notes.norm(e.getText().toString());
                    if (k.isEmpty()) return;
                    cur = k; direct = false; render();
                }).setNegativeButton("Ləğv et", null).create();
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
    }

    // ---------- bir nömrənin səhifəsi ----------
    void renderDetail() {
        if (!direct) {
            head.addView(small("←", v -> { cur = null; render(); }));
        }
        TextView t = tv(cur, 20, Color.WHITE, true);
        t.setPadding(dp(direct ? 0 : 10), 0, dp(8), 0);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (Notes.isNumber(cur)) {
            head.addView(btn("📞", MainActivity.GREEN, 0xFF009624, v -> {
                try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + cur))); } catch (Throwable x) { }
            }));
        }

        List<Notes.Entry> rems = new ArrayList<>(), notes = new ArrayList<>();
        for (Notes.Entry e : Notes.all(this)) {
            if (!e.key.equals(cur)) continue;
            if (Notes.T_REM.equals(e.type)) rems.add(e); else notes.add(e);
        }
        Collections.sort(rems, (a, b) -> Long.compare(a.due, b.due));
        Collections.sort(notes, (a, b) -> Long.compare(b.ts, a.ts));

        // --- xatırlatmalar ---
        TextView h1 = tv("⏰  Xatırlatmalar", 16, 0xFFFFB74D, true);
        h1.setPadding(0, dp(14), 0, dp(4));
        content.addView(h1);
        if (rems.isEmpty()) content.addView(tv("Xatırlatma yoxdur.", 13, MainActivity.GRAY, false));
        for (final Notes.Entry e : rems) {
            LinearLayout c = card();
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(tv(df.format(new Date(e.due)), 16, Color.WHITE, true));
            col.addView(tv(e.days + " gün sonra zəng  ·  " + (e.done ? "✔ bildiriş göndərildi" : "⏳ " + leftText(e.due)),
                    12, e.done ? MainActivity.GREEN : MainActivity.GRAY, false));
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView x = tv("✕", 20, MainActivity.GRAY, false);
            x.setPadding(dp(14), dp(6), dp(6), dp(6));
            x.setOnClickListener(v -> { Notes.remove(this, e.id); render(); });
            r.addView(x);
            c.addView(r);
            content.addView(c);
        }
        content.addView(btn("+ Xatırlatma əlavə et", MainActivity.PURPLE, 0xFF5E35B1, v -> askReminder()), top(8));

        // --- qeydlər ---
        TextView h2 = tv("📝  Qeydlər", 16, 0xFFFFB74D, true);
        h2.setPadding(0, dp(22), 0, dp(4));
        content.addView(h2);
        if (notes.isEmpty()) content.addView(tv("Qeyd yoxdur.", 13, MainActivity.GRAY, false));
        for (final Notes.Entry e : notes) {
            LinearLayout c = card();
            c.addView(tv(e.text, 15, Color.WHITE, false));
            TextView d = tv(df.format(new Date(e.ts)), 11, MainActivity.GRAY, false);
            d.setPadding(0, dp(4), 0, 0);
            c.addView(d);
            c.setOnClickListener(v -> editNote(e));
            content.addView(c);
        }
        content.addView(btn("+ Qeyd əlavə et", MainActivity.BLUE, 0xFF1565C0, v -> editNote(null)), top(8));
    }

    /** Neçə gün sonra zəng edim — yalnız rəqəm klaviaturası. */
    void askReminder() {
        final EditText e = new EditText(this);
        e.setHint("Neçə gün sonra?"); e.setHintTextColor(MainActivity.GRAY); e.setTextColor(Color.WHITE);
        e.setSingleLine(true); e.setTextSize(18);
        e.setKeyListener(DigitsKeyListener.getInstance("0123456789"));
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
        TextView info = tv("Həmin gün saat " + String.format(Locale.US, "%02d:00", Notes.REMIND_HOUR) + "-da bildiriş gələcək.", 12, MainActivity.GRAY, false);
        info.setPadding(0, dp(8), 0, 0);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        l.addView(e, new LinearLayout.LayoutParams(-1, -2));
        l.addView(info);
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Yenidən zəng et").setView(l)
                .setPositiveButton("Əlavə et", (dd, w) -> {
                    String s = e.getText().toString().trim();
                    if (s.isEmpty()) { Toast.makeText(this, "Gün sayını yazın", Toast.LENGTH_SHORT).show(); return; }
                    Notes.Entry n = Notes.add(this, cur, Notes.T_REM, "", Integer.parseInt(s));
                    Toast.makeText(this, "Xatırlatma: " + df.format(new Date(n.due)), Toast.LENGTH_LONG).show();
                    render();
                }).setNegativeButton("Ləğv et", null).create();
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
    }

    /** Adi çoxsətirli mətn qutusu (yeni qeyd və ya redaktə). */
    void editNote(final Notes.Entry old) {
        final EditText e = new EditText(this);
        e.setHint("Qeyd yazın…"); e.setHintTextColor(MainActivity.GRAY); e.setTextColor(Color.WHITE);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setMinLines(5); e.setGravity(Gravity.TOP | Gravity.START); e.setTextSize(15);
        if (old != null) { e.setText(old.text); e.setSelection(old.text.length()); }
        LinearLayout l = new LinearLayout(this);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        l.addView(e, new LinearLayout.LayoutParams(-1, -2));
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(old == null ? "Yeni qeyd" : "Qeyd").setView(l)
                .setPositiveButton("Yadda saxla", (dd, w) -> {
                    String s = e.getText().toString().trim();
                    if (s.isEmpty()) return;
                    if (old == null) Notes.add(this, cur, Notes.T_NOTE, s, 0); else Notes.setText(this, old.id, s);
                    render();
                }).setNegativeButton("Ləğv et", null);
        if (old != null) b.setNeutralButton("Sil", (dd, w) -> { Notes.remove(this, old.id); render(); });
        AlertDialog d = b.create();
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
    }
}
