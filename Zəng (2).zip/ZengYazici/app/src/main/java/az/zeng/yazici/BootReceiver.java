package az.zeng.yazici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Telefon açılanda yazıcı prosesi (mümkündürsə) hazırlayır. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) return;
        final PendingResult pr = goAsync();
        RecorderClient.warmUp(c, pr::finish);
    }
}
