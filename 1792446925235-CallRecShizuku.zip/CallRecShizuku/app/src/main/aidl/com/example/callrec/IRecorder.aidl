package com.example.callrec;
interface IRecorder {
    void destroy() = 16777114;
    boolean start(String path, in int[] sources) = 1;
    void stop() = 2;
}
