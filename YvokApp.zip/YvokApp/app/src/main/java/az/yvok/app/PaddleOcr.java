package az.yvok.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.FloatBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

import ai.onnxruntime.NodeInfo;
import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;

/**
 * Lokal (oflayn) PaddleOCR: PP-OCR aşkarlama (DB) + tanıma (CTC), ONNX Runtime ilə.
 * Modellər ilk istifadədə internetdən endirilir və tətbiqin öz qovluğunda saxlanır (files/paddleocr/).
 * İstəsəniz eyni adlı faylları assets/paddleocr/ içinə də qoya bilərsiniz (bax: README.txt), onda endirmə tələb olunmur.
 */
final class PaddleOcr {
    static volatile String lastError = null;

    private static OrtEnvironment env;
    private static OrtSession det, rec;
    private static String detIn, recIn;
    private static String[] chars;
    private static int recH = 48;      // tanıma modelinin giriş hündürlüyü
    private static int recFixedW = -1; // model sabit enlidirsə, o enlik

    private PaddleOcr() { }

    // Modellərin endirmə ünvanları (Hugging Face). Ölçü yoxlaması: yarımçıq/boş fayl qəbul olunmasın.
    // det: RapidOCR (PP-OCRv4 mobil aşkarlama, ~4.7 MB); rec + lüğət: PP-OCR ingilis/latın tanıma (~7.8 MB) və ona aid dict.txt
    private static final String[][] FILES = {
            {"det.onnx", "https://huggingface.co/SWHL/RapidOCR/resolve/main/PP-OCRv4/ch_PP-OCRv4_det_infer.onnx", "1000000"},
            {"rec.onnx", "https://huggingface.co/xberg-io/paddleocr-onnx-models/resolve/main/rec/english/model.onnx", "1000000"},
            {"keys.txt", "https://huggingface.co/xberg-io/paddleocr-onnx-models/resolve/main/rec/english/dict.txt", "200"},
    };
    private static final long MAX_DOWNLOAD = 60_000_000L;

    private static File dir(Context c) { return new File(c.getFilesDir(), "paddleocr"); }

    private static boolean hasModel(Context c, String name, long min) {
        File f = new File(dir(c), name);
        if (f.isFile() && f.length() >= min) return true;
        try (InputStream in = c.getAssets().open("paddleocr/" + name)) {
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Üç fayl da (endirilmiş və ya assets-də) hazırdırmı. */
    static boolean modelsReady(Context c) {
        for (String[] f : FILES) if (!hasModel(c, f[0], Long.parseLong(f[2]))) return false;
        return true;
    }

    /** Çatışmayan faylları endirir (~13 MB). Yalnız arxa thread-də çağırılır. Uğurludursa true. */
    static synchronized boolean download(Context c) {
        lastError = null;
        File d = dir(c);
        if (!d.isDirectory() && !d.mkdirs()) {
            lastError = "PaddleOCR qovluğu yaradılmadı";
            return false;
        }
        for (String[] f : FILES) {
            long min = Long.parseLong(f[2]);
            if (hasModel(c, f[0], min)) continue;
            File tmp = new File(d, f[0] + ".part");
            try {
                HttpURLConnection h = (HttpURLConnection) new URL(f[1]).openConnection();
                h.setInstanceFollowRedirects(true);
                h.setConnectTimeout(15000);
                h.setReadTimeout(60000);
                h.setRequestProperty("User-Agent", "YvokApp");
                if (h.getResponseCode() != 200) {
                    lastError = "PaddleOCR modeli endirilmədi (" + h.getResponseCode() + ")";
                    return false;
                }
                long total = 0;
                try (InputStream in = h.getInputStream(); FileOutputStream out = new FileOutputStream(tmp)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        total += n;
                        if (total > MAX_DOWNLOAD) throw new java.io.IOException("too big");
                        out.write(buf, 0, n);
                    }
                }
                if (total < min) {
                    tmp.delete();
                    lastError = "PaddleOCR modeli natamam endirildi, yenidən cəhd edin";
                    return false;
                }
                File dst = new File(d, f[0]);
                dst.delete();
                if (!tmp.renameTo(dst)) {
                    lastError = "PaddleOCR modeli yazılmadı";
                    return false;
                }
            } catch (java.io.IOException e) {
                tmp.delete();
                lastError = "PaddleOCR modelini endirmək üçün internet lazımdır";
                return false;
            } catch (Throwable e) {
                tmp.delete();
                lastError = "PaddleOCR modeli endirilmədi";
                return false;
            }
        }
        return true;
    }

    // Endirilmiş fayllar zədəli çıxsa silinir ki, növbəti dəfə təzədən endirilsin
    private static void deleteDownloaded(Context c) {
        for (String[] f : FILES) new File(dir(c), f[0]).delete();
    }

    // ---------- yükləmə ----------
    private static synchronized boolean init(Context c) {
        if (det != null && rec != null) return true;
        try {
            env = OrtEnvironment.getEnvironment();
            OrtSession.SessionOptions o1 = new OrtSession.SessionOptions();
            o1.setIntraOpNumThreads(4);
            det = env.createSession(readModel(c, "det.onnx"), o1);
            OrtSession.SessionOptions o2 = new OrtSession.SessionOptions();
            o2.setIntraOpNumThreads(4);
            rec = env.createSession(readModel(c, "rec.onnx"), o2);
            detIn = det.getInputNames().iterator().next();
            recIn = rec.getInputNames().iterator().next();

            Map<String, NodeInfo> ri = rec.getInputInfo();
            long[] sh = ((TensorInfo) ri.get(recIn).getInfo()).getShape();
            if (sh.length == 4) {
                if (sh[2] > 0) recH = (int) sh[2];
                if (sh[3] > 0) recFixedW = (int) sh[3];
            }

            String keys = new String(readModel(c, "keys.txt"), StandardCharsets.UTF_8);
            ArrayList<String> list = new ArrayList<>();
            list.add("");                                   // 0 = CTC boş işarə
            for (String ln : keys.split("\n", -1)) {
                if (ln.endsWith("\r")) ln = ln.substring(0, ln.length() - 1);
                list.add(ln);
            }
            if (list.get(list.size() - 1).isEmpty()) list.remove(list.size() - 1);   // faylın sonundakı boş sətir
            list.add(" ");                                  // use_space_char
            chars = list.toArray(new String[0]);
            return true;
        } catch (java.io.FileNotFoundException e) {
            lastError = "PaddleOCR modelləri yoxdur, internetdən yüklənməlidir";
        } catch (Throwable e) {
            deleteDownloaded(c);
            lastError = "PaddleOCR modeli zədəli idi və silindi, yenidən yüklənəcək (" + e.getClass().getSimpleName() + ")";
        }
        det = null;
        rec = null;
        return false;
    }

    // Əvvəlcə endirilmiş fayl, yoxdursa assets/paddleocr/ içindəki fayl
    private static byte[] readModel(Context c, String name) throws java.io.IOException {
        File f = new File(dir(c), name);
        try (InputStream in = f.isFile() ? new FileInputStream(f) : c.getAssets().open("paddleocr/" + name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] b = new byte[65536];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            return out.toByteArray();
        }
    }

    // ---------- ictimai API ----------
    /** Şəkildəki mətni sətir-sətir qaytarır; modellər yoxdursa null (səbəb lastError-da). Arxa thread-də çağırılır. */
    static String recognize(Context c, Bitmap src) {
        lastError = null;
        if (!init(c)) return null;
        try {
            ArrayList<int[]> boxes = detect(src);
            // yuxarıdan aşağı, eyni cərgədə soldan sağa
            Collections.sort(boxes, (a, b) -> Integer.compare((a[1] + a[3]) / 2, (b[1] + b[3]) / 2));
            ArrayList<ArrayList<int[]>> rows = new ArrayList<>();
            float rowY = 0, rowH = 0;
            for (int[] b : boxes) {
                float cy = (b[1] + b[3]) / 2f, h = Math.max(1, b[3] - b[1]);
                if (!rows.isEmpty() && Math.abs(cy - rowY) < 0.5f * Math.max(rowH, h)) {
                    ArrayList<int[]> row = rows.get(rows.size() - 1);
                    row.add(b);
                    rowY = (rowY * (row.size() - 1) + cy) / row.size();
                } else {
                    ArrayList<int[]> row = new ArrayList<>();
                    row.add(b);
                    rows.add(row);
                    rowY = cy;
                    rowH = h;
                }
            }
            StringBuilder sb = new StringBuilder();
            for (ArrayList<int[]> row : rows) {
                Collections.sort(row, (a, b) -> Integer.compare(a[0], b[0]));
                for (int[] b : row) {
                    int cw = b[2] - b[0], ch = b[3] - b[1];
                    if (cw < 2 || ch < 2) continue;
                    Bitmap crop = Bitmap.createBitmap(src, b[0], b[1], cw, ch);
                    if (ch >= cw * 1.5f) {            // şaquli yazı: 90° çevir
                        Matrix m = new Matrix();
                        m.postRotate(-90);
                        Bitmap r = Bitmap.createBitmap(crop, 0, 0, cw, ch, m, true);
                        if (r != crop) crop.recycle();
                        crop = r;
                    }
                    String t = recognizeCrop(crop);
                    crop.recycle();
                    if (t != null && !t.isEmpty()) sb.append(t).append(' ');
                }
                sb.append('\n');
            }
            return sb.toString();
        } catch (Throwable e) {
            lastError = "PaddleOCR xətası: " + e.getClass().getSimpleName();
            return null;
        }
    }

    // ---------- aşkarlama (DB) ----------
    private static ArrayList<int[]> detect(Bitmap src) throws Exception {
        int w = src.getWidth(), h = src.getHeight();
        int mx = Math.max(w, h), mn = Math.min(w, h);
        float ratio = 1f;
        if (mx > 1280) ratio = 1280f / mx;
        else if (mn < 640) ratio = Math.min(640f / mn, 1280f / mx);
        int rw = Math.max(32, Math.round(w * ratio / 32f) * 32);
        int rh = Math.max(32, Math.round(h * ratio / 32f) * 32);
        Bitmap sc = Bitmap.createScaledBitmap(src, rw, rh, true);

        int plane = rw * rh;
        float[] data = new float[3 * plane];
        int[] px = new int[plane];
        sc.getPixels(px, 0, rw, 0, 0, rw, rh);
        if (sc != src) sc.recycle();
        for (int i = 0; i < plane; i++) {           // BGR sırası, ImageNet normallaşdırması
            int p = px[i];
            data[i] = (((p & 0xFF) / 255f) - 0.485f) / 0.229f;
            data[plane + i] = ((((p >> 8) & 0xFF) / 255f) - 0.456f) / 0.224f;
            data[2 * plane + i] = ((((p >> 16) & 0xFF) / 255f) - 0.406f) / 0.225f;
        }

        float[] prob;
        int ow, oh;
        try (OnnxTensor in = OnnxTensor.createTensor(env, FloatBuffer.wrap(data), new long[]{1, 3, rh, rw});
             OrtSession.Result res = det.run(Collections.singletonMap(detIn, in))) {
            OnnxTensor out = (OnnxTensor) res.get(0);
            long[] os = out.getInfo().getShape();
            oh = (int) os[os.length - 2];
            ow = (int) os[os.length - 1];
            FloatBuffer fb = out.getFloatBuffer();
            prob = new float[fb.remaining()];
            fb.duplicate().get(prob);
        }

        // bağlı komponentlər (8 qonşu), eşik 0.3
        boolean[] seen = new boolean[ow * oh];
        int[] queue = new int[ow * oh];
        ArrayList<int[]> boxes = new ArrayList<>();
        float sx = (float) w / ow, sy = (float) h / oh;
        for (int s = 0; s < ow * oh; s++) {
            if (seen[s] || prob[s] <= 0.3f) continue;
            int qh = 0, qt = 0;
            queue[qt++] = s;
            seen[s] = true;
            int minX = ow, minY = oh, maxX = 0, maxY = 0, cnt = 0;
            double sum = 0;
            while (qh < qt) {
                int cur = queue[qh++];
                int cx = cur % ow, cy = cur / ow;
                cnt++;
                sum += prob[cur];
                if (cx < minX) minX = cx;
                if (cx > maxX) maxX = cx;
                if (cy < minY) minY = cy;
                if (cy > maxY) maxY = cy;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = cx + dx, ny = cy + dy;
                        if (nx < 0 || ny < 0 || nx >= ow || ny >= oh) continue;
                        int ni = ny * ow + nx;
                        if (seen[ni] || prob[ni] <= 0.3f) continue;
                        seen[ni] = true;
                        queue[qt++] = ni;
                    }
                }
            }
            int bw = maxX - minX + 1, bh = maxY - minY + 1;
            if (Math.min(bw, bh) < 3 || cnt < 12 || sum / cnt < 0.5) continue;
            // unclip: DB sahəni kiçik çıxarır, bunu geri açırıq (nisbət 1.6)
            float d = bw * bh * 1.6f / (2f * (bw + bh));
            int x0 = Math.max(0, Math.round((minX - d) * sx));
            int y0 = Math.max(0, Math.round((minY - d) * sy));
            int x1 = Math.min(w, Math.round((maxX + 1 + d) * sx));
            int y1 = Math.min(h, Math.round((maxY + 1 + d) * sy));
            if (x1 - x0 >= 4 && y1 - y0 >= 4) boxes.add(new int[]{x0, y0, x1, y1});
        }
        return boxes;
    }

    // ---------- tanıma (CTC) ----------
    private static String recognizeCrop(Bitmap crop) throws Exception {
        int ch = crop.getHeight(), cw = crop.getWidth();
        int rw = (int) Math.ceil(recH * (cw / (float) ch));
        rw = Math.max(8, Math.min(rw, 2048));
        int tw = rw;
        if (recFixedW > 0) {
            rw = Math.min(rw, recFixedW);
            tw = recFixedW;
        }
        Bitmap sc = Bitmap.createScaledBitmap(crop, rw, recH, true);
        int[] px = new int[rw * recH];
        sc.getPixels(px, 0, rw, 0, 0, rw, recH);
        if (sc != crop) sc.recycle();

        int plane = recH * tw;
        float[] data = new float[3 * plane];   // sağdakı boşluq 0 ilə doldurulur
        for (int y = 0; y < recH; y++) {
            for (int x = 0; x < rw; x++) {
                int p = px[y * rw + x];
                int i = y * tw + x;
                data[i] = (((p & 0xFF) / 255f) - 0.5f) / 0.5f;                 // B
                data[plane + i] = ((((p >> 8) & 0xFF) / 255f) - 0.5f) / 0.5f;   // G
                data[2 * plane + i] = ((((p >> 16) & 0xFF) / 255f) - 0.5f) / 0.5f; // R
            }
        }

        try (OnnxTensor in = OnnxTensor.createTensor(env, FloatBuffer.wrap(data), new long[]{1, 3, recH, tw});
             OrtSession.Result res = rec.run(Collections.singletonMap(recIn, in))) {
            OnnxTensor out = (OnnxTensor) res.get(0);
            long[] os = out.getInfo().getShape();
            int classes = (int) os[os.length - 1];
            int steps = (int) os[os.length - 2];
            FloatBuffer fb = out.getFloatBuffer();
            float[] arr = new float[fb.remaining()];
            fb.duplicate().get(arr);

            StringBuilder sb = new StringBuilder();
            int last = 0;
            for (int t = 0; t < steps; t++) {
                int best = 0;
                float bv = -1e30f;
                int off = t * classes;
                for (int k = 0; k < classes; k++) {
                    if (arr[off + k] > bv) { bv = arr[off + k]; best = k; }
                }
                if (best != 0 && best != last && best < chars.length) sb.append(chars[best]);
                last = best;
            }
            return sb.toString();
        }
    }
}
