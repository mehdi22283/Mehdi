package az.mehdi.iptvplayer

import android.content.Context
import android.util.Xml
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.GZIPInputStream

const val EPG_URL = "https://iptvx.one/EPG_NOARCH"

data class EpgProgramme(val title: String, val start: Long, val stop: Long)
data class EpgInfo(val now: EpgProgramme?, val next: EpgProgramme?)

/** XMLTV EPG-ni .gz axınından oxuyur; kanal loqoları da yalnız bu mənbənin <icon src> dəyərindən götürülür. */
class EpgStore(private val context: Context, private val scope: CoroutineScope) {
    private val dataFile = File(context.filesDir, "epg_index.json")
    private val gzipFile = File(context.filesDir, "epg_source.gz")
    private val names = HashMap<String, String>() // normalized display-name -> XMLTV channel id
    private val icons = HashMap<String, String>() // XMLTV channel id -> icon URL
    private val programmes = HashMap<String, MutableList<EpgProgramme>>()
    @Volatile private var loaded = false
    private var job: Job? = null

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch(Dispatchers.IO) {
            runCatching {
                if (dataFile.exists() && System.currentTimeMillis() - dataFile.lastModified() < 6 * 60 * 60 * 1000L) {
                    readIndex()
                } else {
                    downloadSource()
                    parseSource()
                    writeIndex()
                }
            }.onFailure {
                // Şəbəkə alınmasa əvvəlki indeks mövcuddursa istifadə et.
                runCatching { if (dataFile.exists()) readIndex() }
            }
            loaded = true
        }
    }

    suspend fun awaitReady() { start(); job?.join() }

    fun logoFor(channelName: String): String? {
        val id = names[norm(channelName)] ?: return null
        return icons[id]
    }

    fun infoFor(channelName: String): EpgInfo {
        val id = names[norm(channelName)] ?: return EpgInfo(null, null)
        val now = System.currentTimeMillis()
        val list = programmes[id].orEmpty().sortedBy { it.start }
        val current = list.firstOrNull { it.start <= now && it.stop > now }
        val next = list.firstOrNull { it.start > now }
        return EpgInfo(current, next)
    }

    private fun norm(s: String): String {
        var t = s.lowercase(Locale.ROOT).replace('ə', 'e').replace('ı', 'i')
        t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        t = t.replace(Regex("\\b(hd|fhd|uhd|sd|4k|8k|hevc|h265|backup)\\b"), " ")
        return t.replace(Regex("[^a-z0-9]"), "")
    }

    private fun downloadSource() {
        val c = (URL(EPG_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000; readTimeout = 60000; instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) MehdiPlayer")
            setRequestProperty("Accept-Encoding", "identity")
        }
        try {
            if (c.responseCode !in 200..299) error("EPG HTTP ${c.responseCode}")
            val tmp = File(gzipFile.path + ".tmp")
            c.inputStream.use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
            if (tmp.length() < 10) { tmp.delete(); error("EPG faylı boşdur") }
            if (gzipFile.exists()) gzipFile.delete()
            if (!tmp.renameTo(gzipFile)) error("EPG cache yazılmadı")
        } finally { c.disconnect() }
    }

    private fun openXmlInput(): InputStream {
        val raw = BufferedInputStream(gzipFile.inputStream())
        raw.mark(2); val a = raw.read(); val b = raw.read(); raw.reset()
        return if (a == 0x1f && b == 0x8b) GZIPInputStream(raw) else raw
    }

    private fun parseTime(value: String?): Long {
        if (value.isNullOrBlank()) return 0L
        val patterns = listOf("yyyyMMddHHmmss Z", "yyyyMMddHHmmss", "yyyyMMddHHmm")
        for (pattern in patterns) try {
            val f = SimpleDateFormat(pattern, Locale.US).apply { isLenient = true; timeZone = TimeZone.getDefault() }
            return f.parse(value.trim())?.time ?: 0L
        } catch (_: Exception) { }
        return 0L
    }

    private fun parseSource() {
        names.clear(); icons.clear(); programmes.clear()
        val parser = Xml.newPullParser()
        openXmlInput().use { input ->
            parser.setInput(input, null)
            var event = parser.eventType
            var channelId: String? = null
            var channelNames = ArrayList<String>()
            var channelIcon: String? = null
            var pId: String? = null; var pStart = 0L; var pStop = 0L; var pTitle: String? = null
            val now = System.currentTimeMillis()
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "channel" -> { channelId = parser.getAttributeValue(null, "id"); channelNames = ArrayList(); channelIcon = null }
                        "display-name" -> if (channelId != null) {
                            val s = parser.nextText().trim(); if (s.isNotEmpty()) channelNames.add(s)
                        }
                        "icon" -> if (channelId != null && channelIcon == null) channelIcon = parser.getAttributeValue(null, "src")
                        "programme" -> {
                            pId = parser.getAttributeValue(null, "channel")
                            pStart = parseTime(parser.getAttributeValue(null, "start"))
                            pStop = parseTime(parser.getAttributeValue(null, "stop")); pTitle = null
                        }
                        "title" -> if (pId != null) pTitle = parser.nextText().trim()
                    }
                    XmlPullParser.END_TAG -> when (parser.name) {
                        "channel" -> {
                            val id = channelId
                            if (!id.isNullOrBlank()) {
                                if (!channelIcon.isNullOrBlank() && channelIcon!!.startsWith("http")) icons[id] = channelIcon!!
                                channelNames.forEach { display -> val key = norm(display); if (key.isNotEmpty()) names.putIfAbsent(key, id) }
                            }
                            channelId = null
                        }
                        "programme" -> {
                            val id = pId; val title = pTitle
                            if (!id.isNullOrBlank() && !title.isNullOrBlank() && pStop > now) {
                                val l = programmes.getOrPut(id) { ArrayList() }
                                l.add(EpgProgramme(title, pStart, pStop))
                                l.sortBy { it.start }
                                while (l.size > 3) l.removeAt(l.lastIndex)
                            }
                            pId = null
                        }
                    }
                }
                event = parser.next()
            }
        }
    }

    private fun writeIndex() {
        val root = JSONObject(); val ca = JSONArray(); val pa = JSONArray()
        icons.forEach { (id, icon) -> ca.put(JSONObject().put("id", id).put("icon", icon)) }
        names.forEach { (name, id) -> ca.put(JSONObject().put("name", name).put("id", id)) }
        programmes.forEach { (id, list) -> list.forEach { p -> pa.put(JSONObject().put("id", id).put("title", p.title).put("start", p.start).put("stop", p.stop)) } }
        root.put("channels", ca).put("programmes", pa)
        val tmp = File(dataFile.path + ".tmp"); tmp.writeText(root.toString())
        if (dataFile.exists()) dataFile.delete(); tmp.renameTo(dataFile)
    }

    private fun readIndex() {
        names.clear(); icons.clear(); programmes.clear()
        val root = JSONObject(dataFile.readText())
        val ca = root.optJSONArray("channels") ?: JSONArray()
        for (i in 0 until ca.length()) {
            val o = ca.getJSONObject(i)
            if (o.has("name")) names[o.getString("name")] = o.getString("id")
            if (o.has("icon")) icons[o.getString("id")] = o.getString("icon")
        }
        val pa = root.optJSONArray("programmes") ?: JSONArray()
        val now = System.currentTimeMillis()
        for (i in 0 until pa.length()) {
            val o = pa.getJSONObject(i); val start = o.optLong("start"); val stop = o.optLong("stop")
            if (stop > now) programmes.getOrPut(o.getString("id")) { ArrayList() }.add(EpgProgramme(o.optString("title"), start, stop))
        }
    }
}
