package az.zengyazici;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/** Zəng yazılarkən: bildiriş (taymerlə) + başqa tətbiqlərin üstündə "Səs yazılır" popupu. */
public class KeepAliveService extends Service {
    WindowManager wm;
    LinearLayout overlay;
    TextView timer;
    long t0;
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable tick = new Runnable() {
        @Override public void run() {
            if (timer == null) return;
            long s = (SystemClock.elapsedRealtime() - t0) / 1000;
            timer.setText(String.format(Locale.US, "%d:%02d", s / 60, s % 60));
            h.postDelayed(this, 1000);
        }
    };

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        String label = i == null ? null : i.getStringExtra("label");
        if (label == null) label = "";
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel("rec2", "Zəng yazılır", NotificationManager.IMPORTANCE_DEFAULT);
        ch.setSound(null, null);
        ch.enableVibration(false);
        nm.createNotificationChannel(ch);
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "rec2")
                .setContentTitle("● Səs yazılır")
                .setContentText(label)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .setUsesChronometer(true)
                .setWhen(System.currentTimeMillis())
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(pi)
                .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        else startForeground(1, n);
        showOverlay(label);
        return START_NOT_STICKY;
    }

    void showOverlay(String label) {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        try {
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            LinearLayout ll = new LinearLayout(this);
            ll.setGravity(Gravity.CENTER_VERTICAL);
            ll.setPadding(dp(16), dp(8), dp(16), dp(8));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xE6B71C1C);
            bg.setCornerRadius(dp(24));
            ll.setBackground(bg);

            TextView txt = new TextView(this);
            txt.setText("● Səs yazılır" + (label.isEmpty() ? "" : "  ·  " + label) + "  ·  ");
            txt.setTextColor(Color.WHITE);
            txt.setTextSize(13);
            ll.addView(txt);
            timer = new TextView(this);
            timer.setText("0:00");
            timer.setTextColor(Color.WHITE);
            timer.setTextSize(13);
            ll.addView(timer);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = dp(48);
            wm.addView(ll, lp);
            overlay = ll;
            t0 = SystemClock.elapsedRealtime();
            h.post(tick);
        } catch (Exception e) { overlay = null; timer = null; }
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(tick);
        if (overlay != null && wm != null) { try { wm.removeView(overlay); } catch (Exception e) { } }
        overlay = null; timer = null;
        super.onDestroy();
    }
}
