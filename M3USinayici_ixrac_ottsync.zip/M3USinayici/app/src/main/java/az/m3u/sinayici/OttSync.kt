package az.m3u.sinayici

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout

/**
 * İxracdan sonra arxa planda (ekranda görünməyən WebView) https://ottplayer.tv/playlist/original səhifəsinə girir,
 * "Mehdi" yazılan sətrin sağındakı dairəvi ox (yenilə / update) düyməsinə basır və nəticəni bildirir.
 * Giriş lazım olsa OttLogin skripti ilə avtomatik daxil olur (BrowserActivity-dəki cookie-lər paylaşılır).
 *
 * Nəticə: cb(ok, info). ok=true yalnız yeniləmə düyməsinə BASILIBSA (fayl yalnız onda silinir).
 */
object OttSync {
    private const val HOME = "https://ottplayer.tv/playlist/original"
    private const val TIMEOUT_MS = 90_000L
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    @SuppressLint("SetJavaScriptEnabled")
    fun run(act: Activity, name: String = "Mehdi", cb: (Boolean, String) -> Unit) {
        if (running) { cb(false, "Ottplayer yeniləməsi artıq gedir"); return }
        running = true
        val host = act.window.decorView as ViewGroup
        val web = WebView(act)
        var finished = false

        fun finish(ok: Boolean, info: String) {
            if (finished) return
            finished = true
            main.removeCallbacksAndMessages(null)
            try { host.removeView(web) } catch (e: Exception) { }
            try { web.stopLoading(); web.removeJavascriptInterface("OttSyncBridge"); web.destroy() } catch (e: Exception) { }
            running = false
            cb(ok, info)
        }

        // Ekrandan kənarda (toxunuşlara mane olmasın), amma tam ölçülü ki, səhifə düzgün qurulsun
        val dm = act.resources.displayMetrics
        val lp = FrameLayout.LayoutParams(dm.widthPixels, dm.heightPixels).apply { leftMargin = -(dm.widthPixels + 200) }
        web.setBackgroundColor(Color.BLACK)
        host.addView(web, lp)

        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = true
        }
        CookieManager.getInstance().setAcceptCookie(true)
        web.webChromeClient = object : WebChromeClient() {
            // Sayt "əminsiniz?" soruşsa avtomatik təsdiq
            override fun onJsConfirm(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean { r?.confirm(); return true }
            override fun onJsAlert(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean { r?.confirm(); return true }
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun result(status: String, info: String) {
                main.post {
                    when (status) {
                        "ok" -> finish(true, info)
                        else -> finish(false, info)
                    }
                }
            }
        }, "OttSyncBridge")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) {
                super.onPageFinished(v, url)
                val h = try { android.net.Uri.parse(url ?: "").host } catch (e: Exception) { null }
                if (!OttLogin.host(h)) return
                v.evaluateJavascript(OttLogin.js(), null)
                v.evaluateJavascript(script(name), null)
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = !OttLogin.host(r.url.host)
        }
        main.postDelayed({ finish(false, "Ottplayer-də 90 saniyə ərzində yeniləmə düyməsi tapılıb basılmadı") }, TIMEOUT_MS)
        web.loadUrl(HOME)
    }

    /** Səhifədə "Mehdi" sətrini tapıb sağındakı yeniləmə (dairəvi ox) ikonuna basır. */
    private fun script(name: String): String = """
(function(){
  if(window.__ottSyncRun) return; window.__ottSyncRun = true;
  var NAME = ${org.json.JSONObject.quote(name)}.toLowerCase();
  var POS = /refresh|update|sync|reload|renew|rotate|cycle|clockwise|redo|yenil|обнов/i;
  var NEG = /delete|trash|remove|bin\b|edit|pencil|copy|share|link|setting|menu|more|close|download|qr|add|plus|play|info|sil\b|удал|измен/i;
  var pending = 0, afterClick = false, doneReq = 0;
  // Klikdən sonra gedən şəbəkə sorğularını izləyirik (yeniləmənin bitdiyini bilmək üçün)
  try {
    var xs = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function(){
      if(afterClick){ pending++; var x = this; x.addEventListener('loadend', function(){ pending--; doneReq++; }); }
      return xs.apply(this, arguments);
    };
    var of = window.fetch;
    if(of) window.fetch = function(){
      if(!afterClick) return of.apply(this, arguments);
      pending++;
      return of.apply(this, arguments).then(function(r){ pending--; doneReq++; return r; }, function(e){ pending--; doneReq++; throw e; });
    };
  } catch(e){}
  function vis(e){ var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }
  function sig(e){
    var s = (e.className && e.className.baseVal !== undefined ? e.className.baseVal : e.className) + ' ' + (e.id||'') + ' ' + (e.title||'') + ' ' +
      (e.getAttribute('aria-label')||'') + ' ' + (e.getAttribute('data-icon')||'') + ' ' + (e.getAttribute('name')||'') + ' ' +
      (e.getAttribute('href')||'') + ' ' + (e.getAttribute('data-original-title')||'') + ' ' + (e.getAttribute('ng-click')||'') + ' ' +
      (e.getAttribute('onclick')||'') + ' ' + (e.getAttribute('@click')||'') + ' ' + (e.getAttribute('v-on:click')||'');
    if(e.children.length < 3) s += ' ' + (e.innerText||'').slice(0,30);   // material-icons: mətn "refresh"
    var u = e.querySelector && e.querySelector('use'); if(u) s += ' ' + (u.getAttribute('href')||u.getAttribute('xlink:href')||'');
    var ch = e.querySelector && e.querySelector('i, svg, span[class*=icon], mat-icon'); if(ch && ch !== e) s += ' ' + (ch.className && ch.className.baseVal !== undefined ? ch.className.baseVal : ch.className) + ' ' + (ch.innerText||'').slice(0,20);
    return s;
  }
  function nameEl(){
    var all = [].slice.call(document.querySelectorAll('body *')).filter(function(e){
      if(!vis(e) || e.children.length > 2) return false;
      var t = (e.innerText || e.textContent || '').trim().toLowerCase();
      return t === NAME;
    });
    return all[0] || null;
  }
  function fire(el){
    var t = el.closest('button, a, [role=button], [onclick]') || el;
    [t, el].forEach(function(x, i){
      if(i === 1 && x === t) return;
      ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(n){
        try { x.dispatchEvent(new MouseEvent(n, {bubbles:true, cancelable:true, view:window})); } catch(e){}
      });
    });
    try { t.click(); } catch(e){}
  }
  var tries = 0, clicked = false;
  var timer = setInterval(function(){
    if(clicked || ++tries > 110){ if(!clicked){ clearInterval(timer); try{ OttSyncBridge.result('fail', 'Səhifədə \"' + NAME + '\" sətri tapılmadı (giriş olmaya bilər)'); }catch(e){} } return; }
    var ne = nameEl(); if(!ne) return;
    var nr = ne.getBoundingClientRect(), row = ne, cands = [];
    for(var up = 0; up < 7 && row.parentElement; up++){
      row = row.parentElement;
      cands = [].slice.call(row.querySelectorAll('button, a, [role=button], i, svg, mat-icon, span[class*=icon], span[class*=btn], div[class*=btn], div[class*=icon], [onclick], [ng-click]'))
        .filter(function(e){
          if(!vis(e) || e.contains(ne) || ne.contains(e)) return false;
          var r = e.getBoundingClientRect();
          return r.left >= nr.right - 4 && Math.abs((r.top + r.height/2) - (nr.top + nr.height/2)) < Math.max(40, nr.height * 1.5);
        });
      if(cands.length) break;
    }
    if(!cands.length) return;
    var best = null, bs = 0;
    cands.forEach(function(e){
      var s = sig(e), sc = 0;
      if(POS.test(s)) sc += 10;
      if(NEG.test(s)) sc -= 10;
      if(sc > bs){ bs = sc; best = e; }
    });
    if(!best){
      var ok = cands.filter(function(e){ return !NEG.test(sig(e)); });
      // eyni düymənin içindəki svg + button təkrarlarını say: ən kənar düymələrə endir
      var tops = ok.filter(function(e){ return !ok.some(function(o){ return o !== e && o.contains(e); }); });
      if(tops.length === 1) best = tops[0];
    }
    if(!best){
      clearInterval(timer); clicked = true;
      var d = cands.slice(0, 8).map(function(e){ return e.tagName + '.' + String(e.className && e.className.baseVal !== undefined ? e.className.baseVal : e.className).slice(0,40); }).join(' | ');
      try { OttSyncBridge.result('fail', 'Yeniləmə (dairəvi ox) düyməsi dəqiq tapılmadı. Sətirdəki elementlər: ' + d); } catch(e){}
      return;
    }
    clicked = true; clearInterval(timer);
    setTimeout(function(){
      afterClick = true; pending = 0; doneReq = 0;
      fire(best);
      // yeniləmənin bitməsini gözlə: klikdən sonra başlayan sorğular bitib və 4 san sakitlik olub; ən çoxu 25 san
      var t0 = Date.now(), quietSince = 0;
      var w = setInterval(function(){
        var el = Date.now() - t0;
        if(pending === 0 && doneReq > 0){ if(!quietSince) quietSince = Date.now(); }
        else quietSince = 0;
        if((quietSince && Date.now() - quietSince > 4000) || el > 25000){
          clearInterval(w);
          try { OttSyncBridge.result('ok', doneReq > 0 ? 'yeniləndi' : 'düyməyə basıldı'); } catch(e){}
        }
      }, 500);
    }, 800);
  }, 500);
})();
"""
}
