# Zəng Yazıcı — Shizuku-suz, özü ADB qoşulan
Quraşdırma: APK -> "Başlat" -> bildirişdən pairing "PORT KOD" daxil et (bir dəfə, Wi-Fi ilə).
Sonra tətbiq `tcpip:5555` açır və 127.0.0.1-dən qoşulur => Wi-Fi olmadan davam edir.
Yenidən başlatmadan sonra: Wi-Fi olanda avtomatik bərpa (WRITE_SECURE_SETTINGS özünə verilib).
Yazılar: /sdcard/Music/CallRec/
