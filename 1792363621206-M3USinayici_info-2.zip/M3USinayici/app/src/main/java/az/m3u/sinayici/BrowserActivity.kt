package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.*
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.File
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Daxili qaranlıq brauzer (Ottplayer və GitHub axtarışı üçün).
 * - Endirilən M3U fayl filesDir/playlist<N>.m3u kimi saxlanılır (Ottplayer: 1, GitHub: 2).
 * - Media linkinə (m3u8, ts, mp4 …) toxunduqda və ya linkə uzun basdıqda link tətbiqin playerində açılır.
 */
class BrowserActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private lateinit var swipe: SwipeRefreshLayout
    @Volatile private var pageAtTop = true
    private val OTT_HOME = "https://ottplayer.tv/playlist/original"
    private val MINI_HOME = "https://github.com/mehdi22283/Mehdi"
    private var copyBar: LinearLayout? = null
    private val hideCopyBar = Runnable { copyBar?.let { root.removeView(it) }; copyBar = null }
    private var listNo = 1
    private var ghToken = ""
    private val pool = Executors.newFixedThreadPool(12)
    /** Yoxlama növbəsi səhifə sırasına görə: 1-ci səhifənin linkləri, sonra 2-ci, 3-cü ... (eyni səhifədə gəliş sırası). */
    private val probeSeq = java.util.concurrent.atomic.AtomicLong()
    private class PTask(val rank: Int, val seq: Long, val r: Runnable) : Runnable, Comparable<PTask> {
        override fun run() { r.run() }
        override fun compareTo(other: PTask): Int = if (rank != other.rank) rank.compareTo(other.rank) else seq.compareTo(other.seq)
    }
    private val probePrio = java.util.concurrent.ThreadPoolExecutor(12, 12, 0L, java.util.concurrent.TimeUnit.MILLISECONDS,
        java.util.concurrent.PriorityBlockingQueue<Runnable>())
    private var bgRank = 2
    private var touchX = 0f
    private var touchY = 0f
    /** "Yeni səhifədə aç" ilə açılmış fayl səhifəsi: linkə toxun → player, basıb saxla → kopyala. */
    private var fileMode = false
    /** Mini brauzer: yuxarıda ünvan qutusu olan sərbəst brauzer; açıqkən tətbiqdən çıxılsa fon xidməti işləyir. */
    private var mini = false
    private var apk = false
    /** Başqa tətbiqdən (Telegram, mesencer…) link açılıb: brauzer kimi işləyir, bağlananda geri qayıdılır. */
    private var external = false
    private var sniffToasted = false
    private var fileCb: android.webkit.ValueCallback<Array<Uri>>? = null
    private var customView: android.view.View? = null
    private var customCb: android.webkit.WebChromeClient.CustomViewCallback? = null
    private var urlBox: android.widget.EditText? = null

    // ---------- m3u8 sniffer (yalnız mini brauzer) ----------
    private class Sniffed(val url: String, val referer: String, val ua: String, val cookie: String)
    private val sniffed = java.util.Collections.synchronizedList(ArrayList<Sniffed>())
    private var sniffBtn: TextView? = null

    private fun looksLikeM3u8(u: String): Boolean {
        val l = u.lowercase()
        if (!(l.startsWith("http://") || l.startsWith("https://"))) return false
        val path = l.substringBefore('?').substringBefore('#')
        return path.endsWith(".m3u8") || path.endsWith(".m3u") || l.contains(".m3u8?") || l.contains("/m3u8") || l.contains("format=m3u8") || l.contains("type=m3u8")
    }

    private fun onSniff(r: WebResourceRequest) {
        val url = r.url.toString()
        if (!looksLikeM3u8(url)) return
        synchronized(sniffed) {
            if (sniffed.any { it.url == url }) return
            val h = r.requestHeaders ?: emptyMap()
            sniffed.add(Sniffed(url, h["Referer"] ?: h["referer"] ?: (pageUrl ?: ""),
                h["User-Agent"] ?: h["user-agent"] ?: web.settings.userAgentString ?: "",
                CookieManager.getInstance().getCookie(url) ?: ""))
        }
        runOnUiThread { updateSniffBadge() }
    }

    private fun updateSniffBadge() {
        val n = sniffed.size
        sniffBtn?.text = if (n == 0) "📡" else "📡 $n"
        if (n == 0) sniffToasted = false
        else if (!sniffToasted) { sniffToasted = true; Toast.makeText(this, "📡 m3u8 tapıldı — playerdə açmaq üçün 📡 düyməsinə basın", Toast.LENGTH_LONG).show() }
    }

    /** Xarici tətbiqdən gələn yeni link açıq brauzerdə yüklənir. */
    fun openUrl(u: String) { urlBox?.setText(u); web.loadUrl(u) }

    private fun hdrJson(x: Sniffed): String {
        val o = JSONObject()
        if (x.referer.isNotEmpty()) o.put("Referer", x.referer)
        if (x.ua.isNotEmpty()) o.put("User-Agent", x.ua)
        if (x.cookie.isNotEmpty()) o.put("Cookie", x.cookie)
        return o.toString()
    }

    private fun showSniffer() {
        val list = synchronized(sniffed) { ArrayList(sniffed) }
        if (list.isEmpty()) {
            AlertDialog.Builder(this).setTitle("📡 m3u8 sniffer")
                .setMessage("Hələ m3u8 tapılmadı. Videonu olan səhifəni açıb oynadın, tapılan linklər burada görünəcək.")
                .setNegativeButton("Bağla", null).show()
            return
        }
        val items = list.map { it.url.let { u -> if (u.length > 90) u.take(60) + "…" + u.takeLast(28) else u } }.toTypedArray()
        AlertDialog.Builder(this).setTitle("📡 m3u8 sniffer (${list.size})")
            .setItems(items) { _, i -> sniffItemMenu(list[i]) }
            .setNeutralButton("📋 Hamısını kopyala") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("m3u8", list.joinToString("\n") { it.url }))
                Toast.makeText(this, "${list.size} link kopyalandı", Toast.LENGTH_SHORT).show()
            }
            .setPositiveButton("🗑 Təmizlə") { _, _ -> sniffed.clear(); updateSniffBadge() }
            .setNegativeButton("Bağla", null).show()
    }

    private fun sniffItemMenu(x: Sniffed) {
        val d = AlertDialog.Builder(this).setTitle("m3u8 link").setMessage(x.url)
            .setPositiveButton("▶ Playerdə aç") { _, _ ->
                val name = Uri.decode(Uri.parse(x.url).lastPathSegment ?: x.url)
                PlayQueue.items = listOf(QItem(name, x.url, hdrJson(x))); PlayQueue.index = 0
                PlayerPanel.open(this)
            }
            .setNeutralButton("📋 Kopyala") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", x.url))
                Toast.makeText(this, "Link kopyalandı", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Bağla", null).show()
        d.findViewById<TextView>(android.R.id.message)?.setTextIsSelectable(true)
    }
    private fun inFilePage() = fileMode && (web.url ?: "").contains("/blob/")

    private val mediaExt = setOf("m3u8", "m3u", "ts", "mp4", "mkv", "mpd", "flv", "avi", "mov", "webm",
        "mp3", "aac", "m4a", "m4v", "3gp", "mpg", "mpeg")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        listNo = intent.getIntExtra("list", 1)
        ghToken = intent.getStringExtra("token") ?: ""
        fileMode = intent.getBooleanExtra("file", false)
        mini = intent.getBooleanExtra("mini", false)
        if (mini) listNo = 2   // mini brauzerdə GitHub-dan baxılan/endirilən .m3u hər zaman 2-ci playlistə (testerə) düşür
        apk = intent.getBooleanExtra("apk", false)
        external = intent.getBooleanExtra("external", false)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        tabs.add(Tab(web))
        root = FrameLayout(this)
        swipe = SwipeRefreshLayout(this)
        swipe.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        swipe.setProgressBackgroundColorSchemeColor(Color.parseColor("#161B22"))
        swipe.setColorSchemeColors(Color.parseColor("#2EA043"))
        swipe.isEnabled = !mini && intent.getStringExtra("url") == null   // yalnız Ottplayer ekranında
        // Yuxarıdan aşağı çəkib yeniləmək üçün lazım olan məsafə qısaldıldı (standart 64dp → 28dp)
        swipe.setDistanceToTriggerSync((28 * resources.displayMetrics.density).toInt())
        // Yuxarıdan çəkib yeniləmə yalnız səhifənin ən üst zolağından (≈110dp) başlayan toxunuşda işləyir:
        // kanaldan/siyahıdan tutub sürüşdürəndə yeniləmə jesti səhifənin sürüşməsini və kanal sürüklənməsini kəsmir
        swipe.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 || !pageAtTop || touchY > 110f * resources.displayMetrics.density }
        swipe.setOnRefreshListener {
            web.loadUrl(OTT_HOME)
            swipe.postDelayed({ swipe.isRefreshing = false }, 6000)
        }
        root.addView(swipe, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        // Ünvan sətri + ⬇ Endirilənlər düyməsi bütün brauzer rejimlərində
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        col.addView(buildUrlBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(buildTabBar(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(root, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(col)
        if (mini) {
            MiniBrowser.register(this)
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 5)
        configure(web)
        tabs[0].desktop = prefDesktop(); applyDesktop(web, tabs[0].desktop)
        if (mini) {
            val start = intent.getStringExtra("start") ?: MINI_HOME
            homeUrl = start
            urlBox?.setText(start)
            addSearchFab()
            web.loadUrl(start)
            refreshTabs()
        } else {
            addSearchFab()   // 🔍 axtarış düyməsi bütün brauzer rejimlərində (Ottplayer, GitHub, Mini, fayl səhifəsi)
            val first = intent.getStringExtra("url") ?: "https://ottplayer.tv/playlist/original"
            homeUrl = first
            web.loadUrl(first)
            refreshTabs()
        }
    }

    /** Hər tab (WebView) üçün eyni quraşdırma: parametr adı `web` sinif sahəsini kölgələyir, ona görə bütün callback-lər məhz bu tabın WebView-na işləyir. */
    private fun configure(web: WebView) {
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; javaScriptCanOpenWindowsAutomatically = true }
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.setSupportMultipleWindows(true)
        if (mini && Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)   // fonda da səhifə işləməyə davam etsin
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        web.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onReceivedTitle(v: WebView?, t: String?) {
                tabs.firstOrNull { it.wv === v }?.let { tb -> val nt = (t ?: "").trim(); if (nt.isNotEmpty() && nt != tb.title) { tb.title = nt; refreshTabs() } }
            }
            /** target=_blank və window.open: mini brauzerdə yeni tabda açılır. */
            override fun onCreateWindow(v: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                if (resultMsg == null) return false
                val tr = resultMsg.obj as? WebView.WebViewTransport ?: return false
                val tb = newTab(null)
                tr.webView = tb.wv; resultMsg.sendToTarget()
                return true
            }
            override fun onCloseWindow(v: WebView?) {
                tabs.indexOfFirst { it.wv === v }.takeIf { it >= 0 }?.let { closeTab(it) }
            }
            override fun onShowFileChooser(w: WebView?, cb: android.webkit.ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try {
                    val i = Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                    startActivityForResult(Intent.createChooser(i, "Fayl seç"), 9); true
                } catch (e: Exception) { fileCb = null; false }
            }
            override fun onShowCustomView(v: android.view.View?, cb: CustomViewCallback?) {
                if (customView != null) { cb?.onCustomViewHidden(); return }
                customView = v; customCb = cb
                (window.decorView as FrameLayout).addView(v, FrameLayout.LayoutParams(-1, -1))
            }
            override fun onHideCustomView() {
                customView?.let { (window.decorView as FrameLayout).removeView(it) }
                customView = null; customCb?.onCustomViewHidden(); customCb = null
            }
        }
        enableDark(web)
        CookieManager.getInstance().setAcceptCookie(true)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try { WebViewCompat.addDocumentStartJavaScript(web, NO_PTR_JS, setOf("*")) } catch (e: Exception) { }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (mini) try { onSniff(r) } catch (e: Exception) { }
                return super.shouldInterceptRequest(v, r)
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.host == "github.com" && v.url?.contains("github.com/search") == true &&
                    u.path?.contains("/blob/") == true && u.fragment?.matches(Regex("L\\d+.*")) == true) return true
                return handleLink(u.toString())
            }
            override fun onPageStarted(v: WebView, url: String?, f: android.graphics.Bitmap?) {
                super.onPageStarted(v, url, f)
                apiSearchFor(url)
                if (v === this@BrowserActivity.web) showUrl(url)
                v.evaluateJavascript(NO_PTR_JS, null)
            }
            override fun onPageFinished(v: WebView, url: String?) {
                super.onPageFinished(v, url)
                if (v === this@BrowserActivity.web) showUrl(url)
                swipe.isRefreshing = false
                v.evaluateJavascript(NO_PTR_JS, null)
                // Ottplayer giriş: email/şifrə avtomatik doldurulur və OK düyməsinə basılır
                if (!mini && !fileMode && url != null && OttLogin.host(Uri.parse(url).host)) {
                    v.evaluateJavascript(OttLogin.js(), null)
                }
                if (url != null && Uri.parse(url).host?.endsWith("github.com") == true) {
                    v.evaluateJavascript("window.__m3uFile=" + (if (inFilePage()) "true" else "false"), null)
                    v.evaluateJavascript(MARK_JS, null)
                    if (apiAll.isNotEmpty()) v.evaluateJavascript("window.__m3uBulk&&__m3uBulk(" + JSONArray(apiAll.toList()) + ")", null)
                }
            }
        }
        web.addJavascriptInterface(object {
            /** GitHub (Turbo) səhifələrində klikləri tutmaq üçün: true qaytarsa link brauzerdə açılmır, native işlənir. */
            @JavascriptInterface fun link(url: String, text: String): Boolean {
                val u = Uri.parse(url)
                if (isRepoLink(u)) {
                    // repo yalnız adına (owner/repo və ya repo) toxunduqda yoxlanılır
                    if (!isRepoName(u, text)) return false
                    runOnUiThread { testRepo(u.pathSegments[0], u.pathSegments[1]) }
                    return true
                }
                if (!intercepts(url)) return false
                runOnUiThread { handleLink(url) }
                return true
            }
            /** Axtarış nəticəsində toxunulan .m3u8 linki birbaşa playerdə açılır. */
            @JavascriptInterface fun play(raw: String) { runOnUiThread { playStream(raw) } }
            /** Fayl səhifəsində: faylın xam mətnindəki bütün .m3u8 linkləri tapılır (ekranda görünməyənlər də). */
            @JavascriptInterface fun rawScan(rawUrl: String) {
                if (Uri.parse(rawUrl).host != "raw.githubusercontent.com") return
                pool.execute {
                    try {
                        val c = URL(rawUrl).openConnection() as HttpURLConnection
                        c.connectTimeout = 15000; c.readTimeout = 30000
                        c.setRequestProperty("User-Agent", "M3USinayici")
                        val txt = c.inputStream.use { it.readBytes() }.let { String(it, Charsets.UTF_8) }
                        c.disconnect()
                        val hls = Regex("\\.m3u8(\\?|#|\\||\$)", RegexOption.IGNORE_CASE)
                        val set = LinkedHashSet<String>()
                        Regex("https?://[^\\s\"'<>`\\\\]+").findAll(txt).forEach { m ->
                            val u = m.value.trimEnd(')', ',', '.', ';', ']', '}')
                            if (set.size < 5000) set.add(u)
                        }
                        val arr = JSONArray(set.toList())
                        runOnUiThread { web.evaluateJavascript("window.__m3uBulk&&__m3uBulk($arr)", null) }
                    } catch (e: Exception) { }
                }
            }
            /** Alt panelin hündürlüyü (CSS px): 🔍 düyməsi həmişə panelin üstündə qalır, düymələri örtmür. */
            @JavascriptInterface fun barH(h: Int) {
                runOnUiThread {
                    val fab = findFab ?: return@runOnUiThread
                    val lp = fab.layoutParams as? FrameLayout.LayoutParams ?: return@runOnUiThread
                    val dn = resources.displayMetrics.density
                    lp.bottomMargin = if (h <= 0) (24 * dn).toInt() else ((h + 14) * dn).toInt()
                    fab.layoutParams = lp
                }
            }
            @JavascriptInterface fun bgStart(href: String) { runOnUiThread { this@BrowserActivity.bgStart(href) } }
            @JavascriptInterface fun check(id: Int, url: String) { checkRank(id, url, 0) }
            /** rank = axtarış nəticəsinin səhifə nömrəsi: aşağı rank əvvəl yoxlanır. */
            @JavascriptInterface fun checkR(id: Int, url: String, rank: Int) { checkRank(id, url, rank) }
            private fun checkRank(id: Int, url: String, rank: Int) {
                if (isImageUrl(url)) return   // .png/.jpg və s. şəkil linkləri heç vaxt test olunmur
                try {
                    probePrio.execute(PTask(rank, probeSeq.incrementAndGet(), Runnable {
                        Net.deviceOnline = Net.online(this@BrowserActivity)
                        val r = try { Net.probe(url, "{}", true) } catch (e: Exception) { "unknown" }
                        runOnUiThread { web.evaluateJavascript("window.__m3uStat&&__m3uStat($id,'$r')", null) }
                    }))
                } catch (e: Exception) { }
            }
        }, "M3UProbe")
        web.addJavascriptInterface(object {
            @JavascriptInterface fun top(b: Boolean) { pageAtTop = b }
        }, "PtrBridge")
        web.setOnTouchListener { _, e ->
            if (e.action == android.view.MotionEvent.ACTION_DOWN) { touchX = e.x; touchY = e.y }
            false
        }
        web.setOnLongClickListener {
            val hit = web.hitTestResult
            val link = hit.extra
            if (inFilePage()) {
                // fayl səhifəsi: linkə basıb saxla → linki kopyala
                if ((hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                    && link != null && link.startsWith("http") && !link.contains("github.com")) { copyLink(link); return@setOnLongClickListener true }
                findUrlAtTouch { copyLink(it) }
                return@setOnLongClickListener false
            }
            if ((hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                && link != null && link.startsWith("http")) {
                val lu = Uri.parse(link)
                when {
                    isRepoLink(lu) -> showFullLink(link)
                    lu.host == "github.com" && lu.pathSegments.size >= 5 && lu.pathSegments[2] == "blob" -> showFileMenu(link)
                    else -> askPlay(link)
                }
                true
            } else {
                // GitHub axtarış nəticələrində linklər sadə mətndir: toxunulan yerdəki linki tapır
                findUrlAtTouch { askPlay(it) }
                false
            }
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun saveNamed(name: String, s: String) = save(Base64.decode(s, Base64.DEFAULT), null, name)
            @JavascriptInterface fun saveZip(name: String, unzip: Boolean, s: String) { zipBytes(name, Base64.decode(s, Base64.DEFAULT), unzip) }
        }, "NativeSave")
        web.setDownloadListener { url, ua, cd, mime, _ ->
            val fname = android.webkit.URLUtil.guessFileName(url, cd, mime)
            // Ottplayer saytından endirilən fayl (adı/mime-ı nə olursa olsun) playlist kimi qəbul edilir; M3U deyilsə save() onu Downloads-a yazır
            val onOtt = !mini && !fileMode && OttLogin.host(try { Uri.parse(web.url ?: "").host } catch (e: Exception) { null })
            val m3uLike = Regex("\\.(m3u8?|txt)$", RegexOption.IGNORE_CASE).containsMatchIn(fname) || (mime ?: "").contains("mpegurl", true) ||
                (onOtt && !fname.endsWith(".apk", true))
            val zipMimes = setOf("application/zip", "application/x-zip", "application/x-zip-compressed", "multipart/x-zip")
            val isZip = fname.endsWith(".zip", true) || ((mime ?: "").substringBefore(';').trim().lowercase() in zipMimes && !fname.endsWith(".apk", true))
            // .zip faylı HEÇ VAXT m3u/m3u8 kanal testinə düşmür: həmişə telefonun Downloads qovluğuna gedir
            if (isZip) { onZipDownload(url, ua, fname, mime); return@setDownloadListener }
            if (apk && url.startsWith("http")) { dl(url, ua, fname, mime); return@setDownloadListener }
            // M3U olmayan hər fayl bütün brauzerlərdə birbaşa Downloads-a endirilir
            if (url.startsWith("http") && !m3uLike) { dl(url, ua, fname, mime); return@setDownloadListener }
            // Mini brauzerdə də M3U endirilməsi Downloads-a yox, 2-ci playlistə (testerə) düşür; M3U olmayan fayllar yuxarıda Downloads-a gedir
            Toast.makeText(this, "Yüklənir...", Toast.LENGTH_SHORT).show()
            when {
                url.startsWith("blob:") -> web.evaluateJavascript(
                    "fetch('$url').then(r=>r.blob()).then(b=>{var f=new FileReader();f.onload=function(){NativeSave.saveNamed(" + JSONObject.quote(fname) + ",f.result.split(',')[1]);};f.readAsDataURL(b);});", null)
                url.startsWith("data:") -> save(Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT), null, fname)
                else -> Thread {
                    try {
                        val c = URL(url).openConnection() as HttpURLConnection
                        c.setRequestProperty("User-Agent", ua)
                        CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                        save(c.inputStream.readBytes(), url, fname)
                    } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() } }
                }.start()
            }
        }
    }

    // ---------- Kompüter (stolüstü sayt) rejimi ----------
    private var deskBtn: TextView? = null
    private val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private fun prefDesktop() = getSharedPreferences("browser", MODE_PRIVATE).getBoolean("desktop", false)

    private fun applyDesktop(w: WebView, on: Boolean) {
        val st = w.settings
        if (on) {
            st.userAgentString = DESKTOP_UA
            st.useWideViewPort = true; st.loadWithOverviewMode = true
            st.setSupportZoom(true); st.builtInZoomControls = true; st.displayZoomControls = false
        } else {
            st.userAgentString = null     // WebView-un standart (mobil) User-Agent-i
            st.useWideViewPort = false; st.loadWithOverviewMode = false
        }
    }

    private fun updateDeskBtn() {
        val b = deskBtn ?: return
        val on = curTabObj()?.desktop == true
        (b.background as? GradientDrawable)?.setColor(Color.parseColor(if (on) "#1F6FEB" else "#30363D"))
        b.invalidate()
    }

    private fun toggleDesktop(tb: Tab) {
        tb.desktop = !tb.desktop
        applyDesktop(tb.wv, tb.desktop)
        getSharedPreferences("browser", MODE_PRIVATE).edit().putBoolean("desktop", tb.desktop).apply()
        updateDeskBtn()
        Toast.makeText(this, if (tb.desktop) "🖥 Kompüter rejimi açıldı" else "📱 Mobil rejim", Toast.LENGTH_SHORT).show()
        tb.wv.reload()
    }

    // ---------- Mini brauzer: tablar ----------
    private class Tab(val wv: WebView, var title: String = "Yeni tab", var desktop: Boolean = false)
    private val tabs = ArrayList<Tab>()
    private var curTab = 0
    private var homeUrl = "https://github.com/mehdi22283/Mehdi"
    private var tabBar: LinearLayout? = null

    private fun curTabObj(): Tab? = tabs.getOrNull(curTab)

    private fun refreshTabs() {
        updateDeskBtn()
        val bar = tabBar ?: return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        bar.removeAllViews()
        // 🗂 siyahı + tab sayı
        bar.addView(TextView(this).apply {
            text = "🗂 ${tabs.size}"; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(5), dp(10), dp(5))
            background = GradientDrawable().apply { setColor(Color.parseColor("#30363D")); cornerRadius = dp(8).toFloat() }
            setOnClickListener { showTabList() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) })
        tabs.forEachIndexed { i, tb ->
            val active = i == curTab
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    setColor(Color.parseColor(if (active) "#1F6FEB" else "#21262D")); cornerRadius = dp(8).toFloat()
                    setStroke(dp(1), Color.parseColor(if (active) "#58A6FF" else "#30363D"))
                }
                setPadding(dp(10), dp(5), dp(4), dp(5))
                setOnClickListener { switchTab(i) }
                setOnLongClickListener { showTabMenu(i); true }
            }
            chip.addView(TextView(this).apply {
                text = tb.title.ifBlank { "Yeni tab" }; setTextColor(Color.WHITE); textSize = 13f
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; maxWidth = dp(120)
            })
            chip.addView(TextView(this).apply {
                text = "✕"; setTextColor(Color.parseColor("#C9D1D9")); textSize = 13f; gravity = Gravity.CENTER
                setPadding(dp(8), dp(2), dp(8), dp(2))
                setOnClickListener { closeTab(i) }
            })
            bar.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) })
        }
        bar.addView(TextView(this).apply {
            text = "＋"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(dp(14), dp(3), dp(14), dp(3))
            background = GradientDrawable().apply { setColor(Color.parseColor("#238636")); cornerRadius = dp(8).toFloat() }
            setOnClickListener { newTab(homeUrl); urlBox?.requestFocus() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun buildTabBar(): View {
        val d = resources.displayMetrics.density
        val inner = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tabBar = inner
        return android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.parseColor("#0D1117"))
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            addView(inner, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    /** Yeni tab: öz WebView-u var (digər tablar fonda işləməyə davam edir). url=null → səhifəni WebView özü (window.open) yükləyir. */
    private fun newTab(url: String?): Tab {
        val w = WebView(this)
        w.setBackgroundColor(Color.BLACK)
        configure(w)
        val tb = Tab(w)
        tb.desktop = prefDesktop(); applyDesktop(w, tb.desktop)
        tabs.add(tb)
        switchTab(tabs.size - 1)
        if (url != null) w.loadUrl(url)
        return tb
    }

    private fun switchTab(i: Int) {
        val tb = tabs.getOrNull(i) ?: return
        curTab = i
        if (web !== tb.wv) {
            (web.parent as? ViewGroup)?.removeView(web)
            web = tb.wv
            (web.parent as? ViewGroup)?.removeView(web)
            swipe.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val u = web.url
        pageUrl = u
        urlBox?.let { if (!it.hasFocus()) it.setText(if (u == null || u == "about:blank") "" else u) }
        refreshTabs(); updateDeskBtn()
    }

    private fun closeTab(i: Int) {
        val tb = tabs.getOrNull(i) ?: return
        if (tabs.size == 1) {   // son tab bağlanmır: ana səhifəyə qayıdır
            tb.title = "Yeni tab"; web.loadUrl(homeUrl); refreshTabs(); return
        }
        val wasCur = i == curTab
        tabs.removeAt(i)
        try { tb.wv.stopLoading(); tb.wv.loadUrl("about:blank"); (tb.wv.parent as? ViewGroup)?.removeView(tb.wv); tb.wv.destroy() } catch (e: Exception) { }
        if (wasCur) { curTab = minOf(i, tabs.size - 1); switchTab(curTab) }
        else { if (i < curTab) curTab--; refreshTabs() }
    }

    private fun closeOtherTabs(keep: Int) {
        val k = tabs.getOrNull(keep) ?: return
        val rm = tabs.filter { it !== k }
        for (t in rm) { try { t.wv.stopLoading(); t.wv.loadUrl("about:blank"); (t.wv.parent as? ViewGroup)?.removeView(t.wv); t.wv.destroy() } catch (e: Exception) { } }
        tabs.clear(); tabs.add(k); switchTab(0)
    }

    private fun showTabMenu(i: Int) {
        val tb = tabs.getOrNull(i) ?: return
        vMenu(tb.title.ifBlank { "Tab" }, tb.wv.url, listOf(
            "🔄 Yenilə" to { tb.wv.reload() },
            (if (tb.desktop) "📱 Mobil rejimə keç" else "🖥 Kompüter rejimi") to { toggleDesktop(tb) },
            "📑 Dublikat et" to { newTab(tb.wv.url ?: homeUrl); Unit },
            "📋 Linki kopyala" to { val u = tb.wv.url ?: ""; if (u.isNotEmpty()) copyLink(u) },
            "🧹 Digər tabları bağla" to { closeOtherTabs(i) },
            "✖ Bu tabı bağla" to { closeTab(i) }
        ))
    }

    private fun showTabList() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        tabs.forEachIndexed { i, t ->
            items.add(((if (i == curTab) "▶ " else "") + t.title.ifBlank { "Yeni tab" }) to { switchTab(i) })
        }
        items.add("＋ Yeni tab" to { newTab(homeUrl); urlBox?.requestFocus(); Unit })
        items.add("🗑 Hamısını bağla" to { closeOtherTabs(curTab); closeTab(0) })
        vMenu("Tablar (${tabs.size})", null, items)
    }

    // ---------- Mini brauzer: ünvan qutusu ----------
    private fun buildUrlBar(): LinearLayout {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val input = android.widget.EditText(this).apply {
            hint = "Sayt ünvanı və ya axtarış"; setHintTextColor(Color.parseColor("#8B949E")); setTextColor(Color.WHITE)
            textSize = 16f; isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0D1117")); cornerRadius = dp(8).toFloat(); setStroke(dp(1), Color.parseColor("#30363D"))
            }
            setOnEditorActionListener { _, id, ev ->
                if (id == android.view.inputmethod.EditorInfo.IME_ACTION_GO ||
                    (ev != null && ev.keyCode == android.view.KeyEvent.KEYCODE_ENTER && ev.action == android.view.KeyEvent.ACTION_DOWN)) { goUrl(); true } else false
            }
        }
        urlBox = input
        val go = TextView(this).apply {
            text = "→"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            setPadding(dp(16), dp(6), dp(16), dp(6))
            background = GradientDrawable().apply { setColor(Color.parseColor("#238636")); cornerRadius = dp(8).toFloat() }
            setOnClickListener { goUrl() }
        }
        val sn = TextView(this).apply {
            text = "📡"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply { setColor(Color.parseColor("#1F6FEB")); cornerRadius = dp(8).toFloat() }
            setOnClickListener { showSniffer() }
        }
        sniffBtn = sn
        val dsk = TextView(this).apply {
            text = "🖥"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply { setColor(Color.parseColor("#30363D")); cornerRadius = dp(8).toFloat() }
            setOnClickListener { curTabObj()?.let { toggleDesktop(it) } }
        }
        deskBtn = dsk
        val dlBtn = TextView(this).apply {
            text = "⬇"; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply { setColor(Color.parseColor("#30363D")); cornerRadius = dp(8).toFloat() }
            setOnClickListener { showDownloads() }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#161B22")); setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (mini) addView(sn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
            addView(dsk, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
            addView(dlBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
            addView(go, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        }
    }

    private fun fmtSize(b: Long) = if (b <= 0) "" else if (b >= 1048576) String.format(java.util.Locale.US, " — %.1f MB", b / 1048576.0) else String.format(java.util.Locale.US, " — %d KB", b / 1024)

    /** ⬇ Endirilənlər: gedən endirmələr + tamamlanmış fayllar; toxun → aç, basıb saxla → siyahıdan sil. */
    private fun showDownloads() {
        val items = DlLog.list(this)
        val act = DlLog.active.values.toList()
        val labels = ArrayList<String>()
        act.forEach { labels.add("⏳ $it") }
        items.forEach { labels.add("📄 " + it.name + fmtSize(it.size)) }
        if (labels.isEmpty()) { Toast.makeText(this, "Endirilən fayl yoxdur", Toast.LENGTH_SHORT).show(); return }
        val dlg = AlertDialog.Builder(this).setTitle("Endirilənlər")
            .setItems(labels.toTypedArray()) { _, i ->
                val it = items.getOrNull(i - act.size) ?: return@setItems
                openDownloaded(it)
            }
            .setNeutralButton("📂 Downloads") { _, _ ->
                try { startActivity(Intent("android.intent.action.VIEW_DOWNLOADS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
            }
            .setNegativeButton("Bağla", null)
            .setPositiveButton("🗑 Təmizlə") { _, _ -> DlLog.clear(this) }
            .create()
        dlg.listView.setOnItemLongClickListener { _, _, pos, _ ->
            items.getOrNull(pos - act.size)?.let { DlLog.remove(this, it.time); Toast.makeText(this, "Siyahıdan silindi", Toast.LENGTH_SHORT).show(); dlg.dismiss() }
            true
        }
        dlg.show()
    }

    private fun openDownloaded(it: DlLog.Item) {
        val uri = Uri.parse(it.uri)
        val ext = it.name.substringAfterLast('.', "").lowercase()
        val mt = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: if (ext == "apk") "application/vnd.android.package-archive" else "*/*"
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mt)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK), it.name))
        } catch (e: Exception) { Toast.makeText(this, "Faylı açan tətbiq tapılmadı", Toast.LENGTH_LONG).show() }
    }

    private fun goUrl() {
        val box = urlBox ?: return
        val t = box.text.toString().trim()
        if (t.isEmpty()) return
        val u = when {
            Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*").matches(t) -> t
            !t.contains(' ') && Regex("^(localhost|\\d{1,3}(\\.\\d{1,3}){3}|[\\w-]+\\.(local|lan|home)|[\\w.-]+:\\d{1,5})(:\\d{1,5})?([/?#].*)?$", RegexOption.IGNORE_CASE).matches(t) -> "http://$t"
            !t.contains(' ') && t.contains('.') -> "https://$t"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(t, "UTF-8")
        }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
            .hideSoftInputFromWindow(box.windowToken, 0)
        box.clearFocus()
        web.requestFocus()
        web.loadUrl(u)
    }

    /** Səhifə ünvanı UI axınında yadda saxlanır: arxa plan axınlarından web.url çağırmaq WebView xətası verir. */
    @Volatile private var pageUrl: String? = null

    private fun showUrl(url: String?) {
        if (url != null) pageUrl = url
        val box = urlBox ?: return
        if (url == null || url == "about:blank" || box.hasFocus()) return
        box.setText(url)
    }

    private var findBar: LinearLayout? = null
    private var findFab: TextView? = null

    /** Bütün brauzer rejimlərində sağ aşağıda 🔍 düyməsi: basanda ən aşağıda axtarış paneli açılır (mətn qutusu + ▲ ▼ oxlar). */
    private fun addSearchFab() {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val fab = TextView(this).apply {
            text = "🔍"; textSize = 24f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#238636")) }
            elevation = dp(8).toFloat()
            setOnClickListener { showFindBar() }
        }
        val lp = FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END)
        lp.setMargins(0, 0, dp(16), dp(24))
        root.addView(fab, lp)
        findFab = fab
    }

    private fun showFindBar() {
        if (findBar != null) return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        val count = TextView(this).apply { setTextColor(Color.parseColor("#8B949E")); textSize = 13f; setPadding(dp(6), 0, dp(6), 0) }
        val input = android.widget.EditText(this).apply {
            hint = "Səhifədə axtar"; setHintTextColor(Color.parseColor("#8B949E")); setTextColor(Color.WHITE)
            textSize = 16f; isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0D1117")); cornerRadius = dp(8).toFloat(); setStroke(dp(1), Color.parseColor("#30363D"))
            }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val q = s?.toString() ?: ""
                    if (q.isEmpty()) { web.clearMatches(); count.text = "" } else web.findAllAsync(q)
                }
            })
            setOnEditorActionListener { _, id, _ ->
                if (id == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) { web.findNext(true); true } else false
            }
        }
        web.setFindListener { active, total, done ->
            if (done) count.text = if (input.text.isEmpty()) "" else if (total == 0) "0" else "${active + 1}/$total"
        }
        fun arrow(t: String, fwd: Boolean) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { web.findNext(fwd) }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#161B22")); setPadding(dp(8), dp(8), dp(8), dp(8)); elevation = dp(12).toFloat()
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(count)
            addView(arrow("▲", false)); addView(arrow("▼", true))
            addView(TextView(this@BrowserActivity).apply {
                text = "✕"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
                setPadding(dp(14), dp(6), dp(14), dp(6)); setOnClickListener { hideFindBar() }
            })
        }
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        findBar = bar
        findFab?.visibility = android.view.View.GONE
        input.requestFocus()
        imm.showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideFindBar() {
        val b = findBar ?: return
        web.clearMatches(); web.setFindListener(null)
        (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
            .hideSoftInputFromWindow(b.windowToken, 0)
        root.removeView(b); findBar = null
        findFab?.visibility = android.view.View.VISIBLE
    }


    /** Fayl linkinə basıb saxlayanda: yeni səhifədə aç (orada .m3u8 linkləri də yoxlanılır). */
    /** Bütün brauzer pəncərələrində düymələr şaquli (alt-alta, tam enli) düzülür. */
    private fun vMenu(title: String, message: String?, items: List<Pair<String, () -> Any?>>) {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        var dlg: AlertDialog? = null
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(12)) }
        col.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 17f; typeface = android.graphics.Typeface.DEFAULT_BOLD; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        if (!message.isNullOrEmpty()) col.addView(TextView(this).apply {
            text = message; setTextColor(Color.parseColor("#C9D1D9")); textSize = 13f; setTextIsSelectable(true)
            setPadding(0, dp(8), 0, dp(4))
        })
        fun btn(label: String, bg: String, act: () -> Any?) = col.addView(TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(dp(12), dp(13), dp(12), dp(13))
            background = GradientDrawable().apply { setColor(Color.parseColor(bg)); cornerRadius = dp(10).toFloat() }
            setOnClickListener { dlg?.dismiss(); act() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        items.forEach { (l, a) -> btn(l, "#21262D", a) }
        btn("Bağla", "#30363D") { }
        val sv = android.widget.ScrollView(this).apply { addView(col) }
        dlg = AlertDialog.Builder(this).setView(sv).create()
        dlg.window?.setBackgroundDrawable(GradientDrawable().apply { setColor(Color.parseColor("#161B22")); cornerRadius = dp(14).toFloat() })
        dlg.show()
    }

    private fun showFileMenu(link: String) {
        val clean = link.substringBefore('#')
        val ext = (Uri.parse(clean).lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        val isM3u = ext == "m3u" || ext == "m3u8"
        val items = ArrayList<Pair<String, () -> Unit>>()
        if (isM3u) items.add("📥 2-ci playlistə yüklə" to { listNo = 2; handleLink(clean); Unit })
        items.add("🗂 Yeni tabda aç" to { newTab(clean); Unit })
        items.add("🌐 Yeni səhifədə aç" to { openNewPage(clean) })
        items.add("📋 Kopyala" to {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", link))
            Toast.makeText(this, "Link kopyalandı", Toast.LENGTH_SHORT).show()
        })
        vMenu(Uri.decode(Uri.parse(clean).lastPathSegment ?: "Fayl"), null, items)
    }

    private fun openNewPage(url: String) {
        startActivityForResult(Intent(this, BrowserActivity::class.java)
            .putExtra("url", url).putExtra("list", listNo).putExtra("token", ghToken).putExtra("file", true), 7)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rc: Int, data: Intent?) {
        super.onActivityResult(rq, rc, data)
        // yeni səhifədə playlist yadda saxlanıbsa, nəticə əsas ekrana ötürülür
        if (rq == 7 && rc == RESULT_OK) { setResult(RESULT_OK, data); finish() }
        if (rq == 9) { fileCb?.onReceiveValue(android.webkit.WebChromeClient.FileChooserParams.parseResult(rc, data)); fileCb = null }
    }

    private fun askPlay(link: String) {
        vMenu("Link", link, listOf(
            "▶ Playerdə aç" to { playStream(link) },
            "🗂 Yeni tabda aç" to { newTab(link.split("|", limit = 2)[0].trim()); Unit },
            "⬇ Endir" to {
                val real = link.split("|", limit = 2)[0].trim()
                fileToDownloads(real, null, android.webkit.URLUtil.guessFileName(real, null, null))
            },
            "📋 Kopyala" to { copyLink(link) }
        ))
    }

    /** Repo adına basıb saxlayanda linkin tam görünməsi (kəsilmədən) + kopyalama. */
    private fun showFullLink(link: String) {
        vMenu("Repo linki", link, listOf(
            "🗂 Yeni tabda aç" to { newTab(link); Unit },
            "🌐 Bu tabda aç" to { web.loadUrl(link) },
            "📋 Kopyala" to {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", link))
                Toast.makeText(this, "Link kopyalandı", Toast.LENGTH_SHORT).show()
            }
        ))
    }

    /** Uzun basılan yerdəki mətndən http(s) linkini çıxarır (GitHub kod axtarışı nəticələri link deyil, mətndir). */
    private fun copyLink(link: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", link))
        showCopiedPopup(link)
    }

    /** "Link kopyalandı" popupı: kopyalanan linki göstərir; düyməyə basanda yalnız bu link playerdə açılır. */
    private fun showCopiedPopup(link: String) {
        copyBar?.let { root.removeView(it) }
        root.removeCallbacks(hideCopyBar)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2161B22")); cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.parseColor("#30363D"))
            }
            elevation = dp(8).toFloat()
        }
        bar.addView(TextView(this).apply {
            text = "📋 Link kopyalandı"; setTextColor(Color.WHITE); textSize = 14f
        })
        bar.addView(TextView(this).apply {
            text = link; setTextColor(Color.parseColor("#8B949E")); textSize = 12f
            maxLines = 4; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            setTextIsSelectable(true)
            setPadding(0, dp(6), 0, dp(8))
        })
        bar.addView(TextView(this).apply {
            text = "▶ Playerdə aç"; setTextColor(Color.WHITE); textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply { setColor(Color.parseColor("#238636")); cornerRadius = dp(8).toFloat() }
            setOnClickListener { root.removeCallbacks(hideCopyBar); hideCopyBar.run(); playStream(link) }
        })
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        lp.setMargins(dp(12), 0, dp(12), dp(64))
        root.addView(bar, lp)
        copyBar = bar
        root.postDelayed(hideCopyBar, 8000)
    }

    private fun findUrlAtTouch(onUrl: (String) -> Unit) {
        @Suppress("DEPRECATION")
        var sc = web.scale
        if (sc <= 0f) sc = resources.displayMetrics.density
        val x = touchX / sc; val y = touchY / sc
        val js = """
(function(x,y){
  try{
    if(window.__m3uUrlAt){ var q0=window.__m3uUrlAt(x,y); if(q0) return q0; }
    var r=document.caretRangeFromPoint?document.caretRangeFromPoint(x,y):null; if(!r) return '';
    var n=r.startContainer, o=r.startOffset;
    var el=n.nodeType===3?n.parentElement:n, root=el;
    for(var i=0;i<8&&el;i++){ if((el.textContent||'').indexOf('http')>=0){ root=el; break; } el=el.parentElement; }
    if(!root) return '';
    var tw=document.createTreeWalker(root,NodeFilter.SHOW_TEXT), pos=0, caret=-1, t;
    while((t=tw.nextNode())){ if(t===n){ caret=pos+o; } pos+=t.nodeValue.length; }
    var text=root.textContent||'';
    var re=/https?:\/\/[^\s"'<>`\\]+/g, m, best='', bd=1e9;
    while((m=re.exec(text))){
      var u=m[0].replace(/[),.;\]}]+$/,''), s=m.index, e=s+u.length;
      var d=(caret>=s&&caret<=e)?0:Math.min(Math.abs(caret-s),Math.abs(caret-e));
      if(d<bd){ bd=d; best=u; }
    }
    return bd<=200?best:'';
  }catch(e){ return ''; }
})($x,$y)
"""
        web.evaluateJavascript(js) { v ->
            val u = try { org.json.JSONTokener(v ?: "").nextValue() as? String } catch (e: Exception) { null }
            if (!u.isNullOrEmpty() && u.startsWith("http")) onUrl(u)
        }
    }

    private fun enableDark(w: WebView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, true)
        } else if (Build.VERSION.SDK_INT >= 29) {
            @Suppress("DEPRECATION")
            w.settings.forceDark = WebSettings.FORCE_DARK_ON
        }
    }

    /** Sonu şəkil formatı (.png, .jpg, ...) olan linklər test edilmir. */
    private fun isImageUrl(u: String): Boolean = try {
        Regex("\\.(png|jpe?g|gif|webp|bmp|svg|ico|avif|heic|tiff?)\$", RegexOption.IGNORE_CASE)
            .containsMatchIn(Uri.parse(u.substringBefore('|').trim()).path ?: "")
    } catch (e: Exception) { false }

    /** Bu link native işlənməlidirmi (repo / media / GitHub-dakı M3U faylı)? */
    private fun intercepts(raw: String): Boolean {
        val u = Uri.parse(raw)
        if (u.scheme != "http" && u.scheme != "https") return false
        if (isRepoLink(u)) return false
        val ext = (u.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        if (ext !in mediaExt) return false
        if (u.host == "github.com") {
            val seg = u.pathSegments
            return (ext == "m3u" || ext == "m3u8") && seg.size >= 5 && seg[2] == "blob"
        }
        return true
    }

    /** true qaytarsa naviqasiya brauzerdə baş vermir (link ya playerdə açılır, ya da playlist kimi yadda saxlanılır). */
    private fun handleLink(raw: String): Boolean {
        val u = Uri.parse(raw)
        if (u.scheme != "http" && u.scheme != "https") return false
        if (isRepoLink(u)) return false
        val ext = (u.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        if (ext !in mediaExt) return false
        var url = raw
        if (u.host == "github.com") {
            val seg = u.pathSegments
            if (ext != "m3u" && ext != "m3u8") return false
            if (seg.size >= 5 && seg[2] == "blob") url = "https://raw.githubusercontent.com/${seg[0]}/${seg[1]}/${seg.drop(3).joinToString("/")}"
            else return false
        }
        if (ext == "m3u" || ext == "m3u8") {
            // kanal siyahısıdır, yoxsa canlı yayım (HLS)?
            Toast.makeText(this, "Yoxlanılır...", Toast.LENGTH_SHORT).show()
            val target = url
            Thread {
                var bytes: ByteArray? = null
                try {
                    val t = Net.Target(target, mapOf("User-Agent" to "VLC/3.0.20 LibVLC/3.0.20"), "brauzer")
                    val c = Net.connect(t, null, 10000)
                    bytes = c.inputStream.use { it.readBytes() }
                    c.disconnect()
                } catch (e: Exception) { }
                val text = bytes?.let { String(it, Charsets.UTF_8) } ?: ""
                // HLS manifesti (TARGETDURATION / STREAM-INF / MEDIA-SEQUENCE) playlist deyil; qalan #EXTINF-li fayl kanal siyahısıdır
                val hlsManifest = text.contains("#EXT-X-TARGETDURATION") || text.contains("#EXT-X-STREAM-INF") || text.contains("#EXT-X-MEDIA-SEQUENCE")
                val isList = bytes != null && text.contains("#EXTINF") && !hlsManifest
                val fromGh = try { (Uri.parse(target).host ?: "").endsWith("githubusercontent.com") } catch (e: Exception) { false }
                runOnUiThread {
                    when {
                        isList -> save(bytes!!, target)
                        fromGh && bytes == null -> Toast.makeText(this, "GitHub faylı yüklənmədi", Toast.LENGTH_LONG).show()   // GitHub faylı yüklənməsə player açılmır
                        else -> playStream(target)
                    }
                }
            }.start()
        } else if (mini && ext !in setOf("ts", "mpd")) askMediaAction(url)
        else playStream(url)
        return true
    }

    private fun playStream(url: String) {
        val base = url.split("|", limit = 2)[0].trim()
        val name = Uri.decode(Uri.parse(base).lastPathSegment ?: base)
        PlayQueue.items = listOf(QItem(name, url, "{}")); PlayQueue.index = 0
        PlayerPanel.open(this)
    }

    /** Fayl (zip, apk və s.) açılmadan, olduğu kimi Downloads-a endirilir; bildirişdə faiz görünür. */
    /** Zip: tətbiqin öz endirmə meneceri (FastDl) — fayl hissələrə bölünüb paralel endirilir (maksimum sürət),
     *  bildirişdə faiz görünür, tətbiqdən çıxılsa da davam edir, bitəndə Downloads-a yazılır. */
    private fun zipToDownloads(url: String, ua: String?, name: String) = fastDownload(url, ua, name)

    /** Brauzer kimi: server adı ilə, olduğu kimi Downloads-a; paralel bağlantılarla. */
    private fun fastDownload(url: String, ua: String?, name: String) {
        Toast.makeText(this, "Downloads-a endirilir: $name", Toast.LENGTH_SHORT).show()
        FastDl.start(this, url, ua, web.url, name, { n, w -> writeDownload(n, w) }) { ok, msg, _ ->
            runOnUiThread {
                Toast.makeText(this, if (ok) "Downloads-a yazıldı: $msg" else "Xəta: $msg", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun fileToDownloads(url: String, ua: String?, name: String) {
        if (url.startsWith("http")) { fastDownload(url, ua, name); return }
        val ref = web.url
        Toast.makeText(this, "Downloads-a endirilir: $name", Toast.LENGTH_SHORT).show()
        val dn = DlNotif(this, name, -1)
        Thread {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 20000; c.readTimeout = 60000
                c.setRequestProperty("Accept-Encoding", "identity")
                ua?.let { c.setRequestProperty("User-Agent", it) }
                ref?.let { c.setRequestProperty("Referer", it) }
                CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
                dn.setTotal(c.contentLengthLong)
                val saved = writeDownload(name) { out ->
                    c.inputStream.use { ins ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            val n = ins.read(buf); if (n < 0) break
                            out.write(buf, 0, n); dn.add(n.toLong())
                        }
                    }
                }
                c.disconnect()
                DlLog.add(this, name, saved.toString(), maxOf(c.contentLengthLong, 0L))
                dn.finish(name, if (name.endsWith(".apk", true)) saved else null)
                runOnUiThread { Toast.makeText(this, "Downloads-a yazıldı: $name", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                dn.fail(e.message ?: e.toString())
                runOnUiThread { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    /** Bütün http endirmələr: Downloads-a yazılır, bildirişdə faiz görünür. */
    private fun dl(url: String, ua: String?, name: String, mime: String?) = fileToDownloads(url, ua, name)

    /** Bütün brauzer rejimlərində zip yalnız endirilir: açılmır, test olunmur, olduğu kimi Downloads-a yazılır. */
    private fun onZipDownload(url: String, ua: String?, fname: String, mime: String?) {
        val zipName = if (fname.endsWith(".zip", true)) fname else "$fname.zip"
        zipAction(url, ua, zipName, false)
    }

    private fun zipAction(url: String, ua: String?, zipName: String, unzip: Boolean) {
        when {
            url.startsWith("http") -> if (unzip) unzipToDownloads(url, ua, zipName) else zipToDownloads(url, ua, zipName)
            url.startsWith("blob:") -> web.evaluateJavascript(
                "fetch('$url').then(r=>r.blob()).then(b=>{var f=new FileReader();f.onload=function(){NativeSave.saveZip(" + JSONObject.quote(zipName) + "," + unzip + ",f.result.split(',')[1]);};f.readAsDataURL(b);});", null)
            url.startsWith("data:") -> Thread { zipBytes(zipName, Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT), unzip) }.start()
            else -> Toast.makeText(this, "Bu link növü dəstəklənmir", Toast.LENGTH_LONG).show()
        }
    }

    /** Yaddaşdakı zip baytlarını (blob/data) ya açıb, ya da olduğu kimi Downloads-a yazır. */
    private fun zipBytes(name: String, bytes: ByteArray, unzip: Boolean) {
        try {
            if (unzip) {
                val names = unzipStream(java.io.ByteArrayInputStream(bytes))
                runOnUiThread { Toast.makeText(this, if (names.isEmpty()) "Zip boş idi" else "Downloads-a yazıldı: " + names.joinToString(", "), Toast.LENGTH_LONG).show() }
            } else {
                writeBytesNotif(name, bytes)
                runOnUiThread { Toast.makeText(this, "Downloads-a yazıldı: $name", Toast.LENGTH_LONG).show() }
            }
        } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() } }
    }

    /** Zip axınını açıb hər faylı (qovluqsuz) Downloads-a yazır; yazılan adların siyahısını qaytarır. */
    @Volatile private var lastApkUri: Uri? = null

    private fun unzipStream(ins: java.io.InputStream): List<String> {
        lastApkUri = null
        val names = ArrayList<String>()
        java.util.zip.ZipInputStream(ins.buffered()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory) {
                    val nm = File(e.name).name
                    if (nm.isNotEmpty() && !e.name.startsWith("__MACOSX")) { val su = writeDownload(nm) { out -> z.copyTo(out) }; names.add(nm); if (nm.endsWith(".apk", true)) lastApkUri = su }
                }
                z.closeEntry(); e = z.nextEntry
            }
        }
        return names
    }

    /** Zip faylını endirir və içindəkiləri (məs. APK) açılmış şəkildə Downloads qovluğuna yazır. */
    private fun unzipToDownloads(url: String, ua: String?, fname: String) {
        Toast.makeText(this, "Yüklənir və açılır: $fname", Toast.LENGTH_LONG).show()
        val ref = web.url
        val dn = DlNotif(this, fname, -1)
        Thread {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 20000; c.readTimeout = 60000
                c.setRequestProperty("Accept-Encoding", "identity")
                ua?.let { c.setRequestProperty("User-Agent", it) }
                ref?.let { c.setRequestProperty("Referer", it) }
                CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
                dn.setTotal(c.contentLengthLong)
                val counted = object : java.io.FilterInputStream(c.inputStream) {
                    override fun read(): Int { val r = super.read(); if (r >= 0) dn.add(1); return r }
                    override fun read(b: ByteArray, off: Int, len: Int): Int { val r = super.read(b, off, len); if (r > 0) dn.add(r.toLong()); return r }
                }
                val names = unzipStream(counted)
                c.disconnect()
                dn.finish(if (names.isEmpty()) "Zip boş idi" else names.joinToString(", "), lastApkUri)
                runOnUiThread {
                    Toast.makeText(this, if (names.isEmpty()) "Zip boş idi" else "Downloads-a yazıldı: " + names.joinToString(", "), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) { dn.fail(e.message ?: e.toString()); runOnUiThread { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() } }
        }.start()
    }

    private fun writeDownload(name: String, w: (java.io.OutputStream) -> Unit): Uri {
        if (Build.VERSION.SDK_INT >= 29) {
            val ext = name.substringAfterLast('.', "").lowercase()
            val mt = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: if (ext == "apk") "application/vnd.android.package-archive" else "application/octet-stream"
            val v = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name)
                put(android.provider.MediaStore.Downloads.MIME_TYPE, mt)
                put(android.provider.MediaStore.Downloads.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
            }
            val u = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(u)!!.use(w)
            return u
        } else {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                runOnUiThread { requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 7) }
                throw java.io.IOException("Yaddaş icazəsi lazımdır — icazə verib yenidən endirin")
            }
            val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val f = File(dir, name)
            f.outputStream().use(w)
            return androidx.core.content.FileProvider.getUriForFile(this, packageName + ".fileprovider", f)
        }
    }

    private fun saveToDownloads(bytes: ByteArray, name: String) {
        try {
            writeBytesNotif(name, bytes)
            runOnUiThread { Toast.makeText(this, "Downloads-a yazıldı: $name", Toast.LENGTH_LONG).show() }
        } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show() } }
    }

    /** Yaddaşdakı baytları hissə-hissə Downloads-a yazır; bildirişdə faiz göstərir. */
    private fun writeBytesNotif(name: String, bytes: ByteArray) {
        val dn = DlNotif(this, name, bytes.size.toLong())
        try {
            val saved = writeDownload(name) { out ->
                var off = 0
                while (off < bytes.size) {
                    val n = minOf(256 * 1024, bytes.size - off)
                    out.write(bytes, off, n); off += n; dn.add(n.toLong())
                }
            }
            DlLog.add(this, name, saved.toString(), bytes.size.toLong())
            dn.finish(name, if (name.endsWith(".apk", true)) saved else null)
        } catch (e: Exception) { dn.fail(e.message ?: e.toString()); throw e }
    }

    /** Zip imzası (PK 03 04): məzmun zip-dirsə, adı/mime-ı nə olursa olsun. */
    private fun isZipBytes(b: ByteArray) = b.size > 4 && b[0] == 0x50.toByte() && b[1] == 0x4B.toByte() && b[2] == 0x03.toByte() && b[3] == 0x04.toByte()

    /** Mini brauzerdə video/audio fayl linki: playerdə aç və ya Downloads-a endir. */
    private fun askMediaAction(url: String) {
        val name = android.webkit.URLUtil.guessFileName(url, null, null)
        vMenu(name, url, listOf(
            "▶ Playerdə aç" to { playStream(url) },
            "⬇ Endir" to { fileToDownloads(url, null, name) },
            "📋 Kopyala" to { copyLink(url) }
        ))
    }

    private fun save(bytes: ByteArray, src: String? = null, name: String? = null) {
        // Zip heç vaxt kanal testi kimi qəbul edilmir — Downloads-a yazılır
        if (isZipBytes(bytes)) {
            val n = (name ?: "yukleme_" + System.currentTimeMillis()).let { if (it.endsWith(".zip", true)) it else "$it.zip" }
            saveToDownloads(bytes, n); return
        }
        val t = if (bytes.size > 5_000_000) "" else String(bytes, Charsets.UTF_8)
        // M3U olmayan fayl heç bir brauzerdə itmir: Downloads-a yazılır
        if (!t.contains("#EXTINF") && !t.contains("#EXTM3U")) { saveToDownloads(bytes, name ?: ("yukleme_" + System.currentTimeMillis())); return }
        // GitHub-dan (fayl linki, raw, GitHub səhifəsi) gələn playlist HƏR ZAMAN 2-ci playlistə yüklənir
        fun gh(u: String?) = try { (Uri.parse(u ?: "").host ?: "").let { it == "github.com" || it.endsWith(".githubusercontent.com") || it.endsWith(".github.com") } } catch (e: Exception) { false }
        val onOtt = !mini && !fileMode && OttLogin.host(try { Uri.parse(pageUrl ?: "").host } catch (e: Exception) { null })
        // Ottplayer-dən endirilən playlist HƏR ZAMAN 1-ci playlistə yüklənir (GitHub: 2)
        val ln = if (gh(src) || gh(pageUrl)) 2 else if (onOtt) 1 else listNo
        runOnUiThread {
            File(filesDir, "playlist$ln.m3u").writeText(t)
            File(filesDir, "playlist$ln.url").writeText(src ?: "")
            if (external) {
                startActivity(Intent(this, MainActivity::class.java).putExtra("importList", ln).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } else setResult(RESULT_OK, Intent().putExtra("list", ln))
            finish()
        }
    }

    // ---------- GitHub repo: M3U fayllarını tap, 2-ci playlistdə yoxla ----------
    private val reserved = setOf("search", "settings", "orgs", "topics", "marketplace", "features", "login", "signup",
        "explore", "notifications", "sponsors", "collections", "trending", "pricing", "about", "contact", "issues", "pulls",
        "codespaces", "new", "join", "site", "enterprise", "readme", "security", "apps", "users", "organizations")

    private fun isRepoLink(u: Uri): Boolean {
        if (u.host != "github.com") return false
        val seg = u.pathSegments
        return seg.size == 2 && seg[0].lowercase() !in reserved
    }

    private fun isRepoName(u: Uri, text: String): Boolean {
        val t = text.replace(Regex("\\s+"), "").lowercase()
        val owner = u.pathSegments[0].lowercase(); val repo = u.pathSegments[1].lowercase()
        return t == "$owner/$repo" || t == repo
    }

    private fun gh(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "M3USinayici")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        if (ghToken.isNotEmpty()) c.setRequestProperty("Authorization", "token $ghToken")
        return c
    }

    private fun encSeg(p: String) = p.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    private fun testRepo(owner: String, repo: String) {
        Toast.makeText(this, "$owner/$repo yoxlanılır...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val c = gh("https://api.github.com/repos/$owner/$repo/git/trees/HEAD?recursive=1")
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                c.disconnect()
                val j = JSONObject(txt)
                if (code !in 200..299) throw java.io.IOException(j.optString("message", "GitHub xətası (HTTP $code)"))
                val tree = j.getJSONArray("tree")
                val files = ArrayList<String>()
                for (i in 0 until tree.length()) {
                    val o = tree.getJSONObject(i)
                    val path = o.getString("path")
                    val low = path.lowercase()
                    if (o.getString("type") == "blob" && (low.endsWith(".m3u") || low.endsWith(".m3u8")) && o.optLong("size", 0) < 30L * 1024 * 1024) files.add(path)
                }
                files.sort()
                runOnUiThread {
                    when {
                        files.isEmpty() -> Toast.makeText(this, "Bu repoda M3U fayl tapılmadı", Toast.LENGTH_LONG).show()
                        files.size == 1 -> loadRepoFile(owner, repo, files[0])
                        else -> AlertDialog.Builder(this).setTitle("$owner/$repo — fayl seçin")
                            .setItems(files.take(60).toTypedArray()) { _, w -> loadRepoFile(owner, repo, files[w]) }.show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Repo xətası: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun loadRepoFile(owner: String, repo: String, path: String) {
        Toast.makeText(this, "Yüklənir: $path", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val c = URL("https://raw.githubusercontent.com/$owner/$repo/HEAD/${encSeg(path)}").openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 60000
                c.setRequestProperty("User-Agent", "M3USinayici")
                val bytes = c.inputStream.use { it.readBytes() }
                c.disconnect()
                val t = String(bytes, Charsets.UTF_8)
                if (!t.contains("#EXTINF")) runOnUiThread { Toast.makeText(this, "Bu fayl kanal siyahısı deyil", Toast.LENGTH_LONG).show() }
                else save(bytes, "https://raw.githubusercontent.com/$owner/$repo/HEAD/${encSeg(path)}")
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Yükləmə xətası: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        ApkTool.cleanInstalled(this)   // quraşdırılmış APK faylları silinir
    }

    // ---------- Gizli arxa plan: GitHub axtarışının növbəti səhifələri ekranda göstərilmədən oxunur ----------
    private var bg: WebView? = null
    private var bgGen = 0
    private val bgSeen = HashSet<String>()

    private fun bgStart(href: String) {
        if (ghToken.isNotEmpty()) { apiSearchFor(href); return }   // token varsa: gizli səhifə əvəzinə GitHub API (limitsiz-sürətli)
        val u = Uri.parse(href)
        if (u.host != "github.com" || u.path?.startsWith("/search") != true) return
        bgGen++; bgSeen.clear(); bgSeen.add(href); bgRank = 2
        bgLoad(href)
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun bgLoad(href: String) {
        val v = bg ?: WebView(this).also { w ->
            w.settings.javaScriptEnabled = true
            w.settings.domStorageEnabled = true
            w.settings.userAgentString = web.settings.userAgentString
            w.alpha = 0.01f
            w.isClickable = false; w.isFocusable = false
            w.addJavascriptInterface(object {
                @JavascriptInterface fun page(json: String, next: String) { runOnUiThread { bgPage(json, next) } }
            }, "BgProbe")
            w.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String?) {
                    super.onPageFinished(view, url)
                    view.evaluateJavascript(BG_JS, null)
                }
            }
            val d = resources.displayMetrics.density
            root.addView(w, 0, FrameLayout.LayoutParams((360 * d).toInt(), (640 * d).toInt()))
            bg = w
        }
        v.loadUrl(href)
    }

    private fun bgPage(json: String, next: String) {
        val g = bgGen
        val arr = try { JSONArray(json) } catch (e: Exception) { JSONArray() }
        val list = JSONArray()
        for (i in 0 until arr.length()) { val u = arr.optString(i); if (u.isNotEmpty() && !isImageUrl(u)) list.put(u) }
        if (list.length() > 0) web.evaluateJavascript("window.__m3uBulk&&__m3uBulk($list, $bgRank)", null)
        bgRank++
        if (next.isEmpty() || !bgSeen.add(next) || bgSeen.size > 100) return
        // GitHub sorğu limitinə düşməmək üçün növbəti səhifə gecikmə ilə açılır
        val delay = 3000L + minOf(list.length(), 100) * 100L
        root.postDelayed({ if (g == bgGen) bgLoad(next) }, delay)
    }

    // ---------- GitHub API axtarışı (token ilə): web səhifənin limitinə düşmür, bütün səhifələr tez oxunur ----------
    @Volatile private var dead = false
    @Volatile private var apiGen = 0
    private var apiKey = ""
    private val apiAll = LinkedHashSet<String>()      // yalnız UI thread-də dəyişir

    private fun apiInfo(t: String) {
        runOnUiThread { web.evaluateJavascript("window.__m3uInfo&&__m3uInfo(" + JSONObject.quote(t) + ")", null) }
    }

    private fun apiPush(list: Collection<String>, rank: Int = 1) {
        runOnUiThread {
            val fresh = ArrayList<String>()
            for (u in list) { if (apiAll.size < 5000 && apiAll.add(u)) fresh.add(u) }
            if (fresh.isNotEmpty()) web.evaluateJavascript("window.__m3uBulk&&__m3uBulk(" + JSONArray(fresh) + ", $rank)", null)
        }
    }

    private fun apiSearchFor(pageUrl: String?) {
        if (ghToken.isEmpty() || pageUrl == null) return
        val u = try { Uri.parse(pageUrl) } catch (e: Exception) { return }
        if (u.host != "github.com" || u.path?.startsWith("/search") != true) return
        val type = u.getQueryParameter("type")
        if (type != null && type != "code") return
        val q = u.getQueryParameter("q")?.trim() ?: return
        if (q.isEmpty() || q == apiKey) return
        apiKey = q; apiGen++; apiAll.clear()
        val g = apiGen
        Thread { try { apiRun(q, g) } catch (e: Exception) { if (g == apiGen) apiInfo("❌ API: " + (e.message ?: e.toString())) } }
            .apply { isDaemon = true }.start()
    }

    private val urlRx = Regex("https?://[^\\s\"'<>`\\\\]+")
    private fun urlsIn(t: String): List<String> =
        urlRx.findAll(t).map { it.value.trimEnd(')', ',', '.', ';', ']', '}') }.filter { !isImageUrl(it) }.toList()

    private fun apiRun(q: String, g: Int) {
        val clause = Regex("\\(?\\s*path:\\.m3u\\s+OR\\s+path:\\.m3u8\\s*\\)?", RegexOption.IGNORE_CASE)
        val base = q.replace(clause, " ").replace(Regex("\\s+"), " ").trim()
        val queries = if (clause.containsMatchIn(q)) listOf("$base extension:m3u", "$base extension:m3u8") else listOf(q)
        // xam fayldan axtarılan söz (qualifier-siz)
        val phrase = base.replace("\"", "").split(' ').filter { it.isNotEmpty() && !it.contains(':') }.joinToString(" ").lowercase()
        val tk = ApkTool.clean(ghToken)
        var found = 0
        apiInfo("🔎 API axtarışı başladı")
        for (qq in queries) {
            var page = 1; var tries = 0
            while (page <= 10 && g == apiGen && !dead) {
                val c = URL("https://api.github.com/search/code?q=" + java.net.URLEncoder.encode(qq, "UTF-8") + "&per_page=100&page=$page")
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 20000; c.readTimeout = 30000
                c.setRequestProperty("Authorization", "Bearer $tk")
                c.setRequestProperty("Accept", "application/vnd.github.text-match+json")
                c.setRequestProperty("User-Agent", "M3USinayici")
                val code = c.responseCode
                val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                val retry = c.getHeaderField("Retry-After")?.toLongOrNull()
                val reset = c.getHeaderField("x-ratelimit-reset")?.toLongOrNull()
                c.disconnect()
                if (code == 401) { apiInfo("❌ Token yanlışdır (401)"); return }
                if (code == 403 || code == 429) {
                    if (++tries > 6) { apiInfo("⚠️ GitHub limiti: axtarış dayandırıldı (" + found + " link)"); return }
                    val w = (retry ?: reset?.let { it - System.currentTimeMillis() / 1000 + 1 } ?: 30L).coerceIn(5L, 90L)
                    apiInfo("⏳ GitHub limiti: $w san gözlənilir")
                    Thread.sleep(w * 1000); continue
                }
                if (code !in 200..299) { break }
                val items = JSONObject(body).optJSONArray("items") ?: break
                val got = LinkedHashSet<String>()
                val needRaw = ArrayList<String>()
                val sync = java.util.Collections.synchronizedSet(got)
                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val tm = item.optJSONArray("text_matches")
                    var any = false
                    if (tm != null) for (k in 0 until tm.length()) {
                        val us = urlsIn(tm.getJSONObject(k).optString("fragment", ""))
                        if (us.isNotEmpty()) { any = true; got.addAll(us) }
                    }
                    if (!any) needRaw.add(item.optString("html_url", ""))
                }
                // fraqmentdə link olmayan fayllar: xam mətndən axtarılan sözün sətri və növbəti 2 sətir
                if (needRaw.isNotEmpty() && phrase.isNotEmpty()) {
                    val latch = java.util.concurrent.CountDownLatch(needRaw.size)
                    for (h in needRaw) {
                        try {
                            pool.execute {
                                try {
                                    val raw = h.replace("https://github.com/", "https://raw.githubusercontent.com/").replaceFirst("/blob/", "/")
                                    val rc = URL(raw).openConnection() as HttpURLConnection
                                    rc.connectTimeout = 15000; rc.readTimeout = 20000
                                    rc.setRequestProperty("User-Agent", "M3USinayici")
                                    if (rc.responseCode in 200..299) {
                                        val txt = rc.inputStream.use { ins ->
                                            val bo = java.io.ByteArrayOutputStream(); val buf = ByteArray(16384)
                                            while (bo.size() < 3_000_000) { val r = ins.read(buf); if (r < 0) break; bo.write(buf, 0, r) }
                                            String(bo.toByteArray(), Charsets.UTF_8)
                                        }
                                        val lines = txt.lines(); var n = 0
                                        for (i in lines.indices) {
                                            if (n >= 20) break
                                            if (lines[i].lowercase().contains(phrase)) {
                                                for (j in i..minOf(i + 2, lines.size - 1)) { val us = urlsIn(lines[j]); sync.addAll(us); n += us.size }
                                            }
                                        }
                                    }
                                    rc.disconnect()
                                } catch (e: Exception) { } finally { latch.countDown() }
                            }
                        } catch (e: Exception) { latch.countDown() }
                    }
                    latch.await(45, java.util.concurrent.TimeUnit.SECONDS)
                }
                val snap = synchronized(sync) { ArrayList(got) }
                found += snap.size
                apiPush(snap, page)
                apiInfo("🔎 API: $found link (səhifə $page)")
                tries = 0
                if (items.length() < 100) break
                page++
                Thread.sleep(6500)    // kod axtarışı API limiti ~10 sorğu/dəq
            }
        }
        if (g == apiGen) apiInfo("✅ API: $found link tapıldı")
    }

    override fun onDestroy() {
        dead = true
        try { bg?.let { it.stopLoading(); (it.parent as? ViewGroup)?.removeView(it); it.destroy() }; bg = null } catch (e: Exception) { }
        pool.shutdownNow(); probePrio.shutdownNow()
        if (mini) {
            MiniBrowser.unregister(this)
            BrowserService.stop(this)
        }
        for (t in tabs) { try { t.wv.stopLoading(); t.wv.loadUrl("about:blank"); (t.wv.parent as? ViewGroup)?.removeView(t.wv); t.wv.destroy() } catch (e: Exception) { } }
        super.onDestroy()
    }

    companion object {
        /** Gizli səhifədə: nəticələr yüklənənə qədər gözləyir, mətndəki linkləri və "növbəti" linkini native tərəfə verir. */
        val BG_JS = """(function(){
if(window.__bgRun) return; window.__bgRun=true;
var t0=Date.now(), last=-1, stable=0;
var skipHost=/(^|\.)(github\.com|githubusercontent\.com|githubassets\.com|githubapp\.com)#SP#/i;
var media=/\.(m3u8?|ts|mp4|mkv|mpd|flv|avi|mov|webm|mp3|aac|m4a|m4v|3gp|mpg|mpeg)#SP#/i;
var imgExt=/\.(png|jpe?g|gif|webp|bmp|svg|ico|avif|heic|tiff?)#SP#/i;
var nonStream=/\.(css|js|mjs|html?|woff2?|ttf|otf|map|pdf|zip|apk|md|txt)#SP#/i;
function cleanEnd(u){ return u.replace(/[),.;\]}]+#SP#/,''); }
function good(u){ try{ var x=new URL(u.split('|')[0]); if(skipHost.test(x.hostname)) return false;
  if(imgExt.test(x.pathname)) return false;
  var p=x.pathname; if(nonStream.test(p)) return false;
  return !!x.port || media.test(p) || p.length>1; }catch(e){ return false; } }
function nextHref(){
  var a=document.querySelector('a[rel="next"]'); if(a) return a.href;
  var all=document.querySelectorAll('a[href*="p="]');
  for(var i=0;i<all.length;i++){
    var l=((all[i].getAttribute('aria-label')||'')+' '+(all[i].textContent||'')).toLowerCase();
    if(/next/.test(l) && all[i].getAttribute('aria-disabled')!=='true') return all[i].href;
  }
  return '';
}
var iv=setInterval(function(){
  var txt=document.body?document.body.innerText:'';
  if(txt.length===last) stable++; else { stable=0; last=txt.length; }
  var ready = stable>=3 && txt.length>300 && (document.querySelector('a[href*="/blob/"]') || nextHref());
  if(ready || Date.now()-t0>20000){
    clearInterval(iv);
    var seen={}, out=[], m, rx=/https?:\/\/[^\s"'<>`\\]+/g;
    while((m=rx.exec(txt))){ var u=cleanEnd(m[0]); if(!seen[u] && good(u)){ seen[u]=1; out.push(u); } }
    try{ BgProbe.page(JSON.stringify(out), nextHref()); }catch(e){}
  }
},700);
})();""".replace("#SP#", "$")

        /** Səhifənin ən yuxarıda olub-olmadığını native tərəfə bildirir (yuxarıdan sürüşdürüb yeniləmə üçün); GitHub səhifələrinə toxunmur. */
        val NO_PTR_JS = """(function(){
try{ if(String(location.hostname).slice(-10)==='github.com') return; }catch(e){ return; }
if(window.__noPtr) return; window.__noPtr=true;
try{
  var st=document.createElement('style');
  st.textContent='html,body{overscroll-behavior-y:none!important;}';
  (document.head||document.documentElement).appendChild(st);
}catch(e){}
function canScrollUp(el){
  while(el && el.nodeType===1){
    try{
      var cs=getComputedStyle(el);
      if(/(auto|scroll)/.test(cs.overflowY) && el.scrollHeight>el.clientHeight && el.scrollTop>0) return true;
    }catch(e){}
    el=el.parentElement;
  }
  return false;
}
window.addEventListener('touchstart',function(e){
  var top=window.pageYOffset||(document.scrollingElement&&document.scrollingElement.scrollTop)||0;
  try{ PtrBridge.top(top<=0 && !canScrollUp(e.target)); }catch(x){}
},{capture:true,passive:true});
})();"""

        /** GitHub səhifəsində mətn şəklindəki linklərin yanına 🟢/🔴 qoyur (yoxlama native aparılır). */
        val MARK_JS = """(function(){
if(window.__m3uInit){ if(window.__m3uScan) window.__m3uScan(); return; }
window.__m3uInit=true;
var state={}, cur={}, curPath='', rawDone='', ids={}, nid=0, total=0, MAX=2000, auto=false, lastNew=Date.now(), lastNext='', lastClick=0, saveT=null;
try{ state=JSON.parse(sessionStorage.getItem('m3uAll')||'{}')||{}; auto=false; }catch(e){ state={}; }
var skipHost=/(^|\.)(github\.com|githubusercontent\.com|githubassets\.com|githubapp\.com)#SP#/i;
var media=/\.(m3u8?|ts|mp4|mkv|mpd|flv|avi|mov|webm|mp3|aac|m4a|m4v|3gp|mpg|mpeg)#SP#/i;
var nonStream=/\.(css|js|mjs|html?|woff2?|ttf|otf|map|pdf|zip|apk|md|txt)#SP#/i;
var imgExt=/\.(png|jpe?g|gif|webp|bmp|svg|ico|avif|heic|tiff?)#SP#/i;
var re=/https?:\/\/[^\s"'<>`\\]+/g;
var INLINE={SPAN:1,MARK:1,EM:1,B:1,STRONG:1,I:1,A:1,CODE:1,U:1,S:1,SMALL:1};
function cleanEnd(u){ return u.replace(/[),.;\]}]+#SP#/,''); }
function good(u){ try{ var x=new URL(u.split('|')[0]); if(skipHost.test(x.hostname)) return false;
  if(imgExt.test(x.pathname)) return false;
  var p=x.pathname; if(nonStream.test(p)) return false;
  return !!x.port || media.test(p) || p.length>1; }catch(e){ return false; } }
for(var k0 in state){ if(!good(k0)) delete state[k0]; }
function paint(sp,st){ sp.textContent = st==='ok' ? ' \uD83D\uDFE2' : st==='dead' ? ' \uD83D\uDD34' : ' \u23F3'; }
function persist(){ clearTimeout(saveT); saveT=setTimeout(function(){ try{
  var o={}; for(var k in state){ if(state[k]==='ok'||state[k]==='dead') o[k]=state[k]; }
  sessionStorage.setItem('m3uAll',JSON.stringify(o)); }catch(e){} },800); }
window.__m3uStat=function(id,st){
  var u=ids[id]; if(!u) return; state[u]=st;
  var all=document.querySelectorAll('span.m3u-st');
  for(var i=0;i<all.length;i++){ if(all[i].getAttribute('data-url')===u) paint(all[i],st); }
  persist(); bar();
};
function mark(u){
  var sp=document.createElement('span'); sp.className='m3u-st'; sp.setAttribute('data-url',u);
  sp.style.cssText='user-select:none;-webkit-user-select:none';
  cur[u]=1;
  if(state[u]===undefined){ state[u]='pending'; lastNew=Date.now(); var id=++nid; ids[id]=u; try{ M3UProbe.check(id,u); }catch(e){} }
  paint(sp, state[u]==='pending' ? '' : state[u]);
  return sp;
}
/* Eyni sətirdəki mətn qovşaqlarını birləşdirir: axtarış sözü <mark> ilə seçildikdə link bir neçə qovşağa bölünür */
function processGroup(nodes){
  var text='', starts=[], i;
  for(i=0;i<nodes.length;i++){ starts.push(text.length); text+=nodes[i].nodeValue; }
  if(text.indexOf('http')<0) return;
  var m, found=[]; re.lastIndex=0;
  while((m=re.exec(text))){ var u=cleanEnd(m[0]); if(good(u)) found.push({u:u,end:m.index+u.length}); }
  for(var k=found.length-1;k>=0;k--){
    if(total>=MAX) return;
    var f=found[k], idx=nodes.length-1;
    while(idx>0 && starts[idx]>=f.end) idx--;
    var node=nodes[idx], par=node.parentNode; if(!par) continue;
    var off=f.end-starts[idx];
    if(off>=node.nodeValue.length){
      var nx=node.nextSibling; if(nx && nx.nodeType===1 && nx.className==='m3u-st') continue;
      par.insertBefore(mark(f.u), node.nextSibling);
    } else {
      var rest=node.splitText(off); par.insertBefore(mark(f.u), rest);
    }
    total++;
  }
}
window.__m3uBulk=function(list,rank){
  for(var i=0;i<list.length;i++){ var u=list[i]; if(!good(u)) continue; cur[u]=1;
    if(state[u]===undefined){ state[u]='pending'; lastNew=Date.now(); var id=++nid; ids[id]=u; try{ if(rank){ M3UProbe.checkR(id,u,rank); } else { M3UProbe.check(id,u); } }catch(e){} } }
  bar();
};
function fileStyle(){
  if(window.__m3uFile && document.head && !document.getElementById('m3u-nosel')){
    var st=document.createElement('style'); st.id='m3u-nosel';
    st.textContent='*{-webkit-user-select:none!important;user-select:none!important;-webkit-touch-callout:none!important}';
    document.head.appendChild(st);
  }
}
function scan(){
  if(!document.body) return;
  fileStyle();
  if(curPath!==location.pathname){ curPath=location.pathname; cur={}; rawDone=''; }
  if(rawDone!==location.pathname){
    var mm=location.pathname.match(/^\/([^\/]+)\/([^\/]+)\/blob\/(.+)#SP#/);
    if(mm){ rawDone=location.pathname; try{ M3UProbe.rawScan('https://raw.githubusercontent.com/'+mm[1]+'/'+mm[2]+'/'+mm[3]); }catch(e){} }
  }
  var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode:function(n){
    var p=n.parentNode; if(!p) return 2; var t=p.nodeName;
    if(t==='SCRIPT'||t==='STYLE'||t==='TEXTAREA'||t==='NOSCRIPT') return 2;
    if(p.className==='m3u-st') return 2;
    if(p.closest && p.closest('#m3u-bar')) return 2;
    return 1; }});
  var groups=[], cur=null, curRoot=null, n;
  while((n=w.nextNode())){
    var r=n.parentNode; while(r && INLINE[r.nodeName]) r=r.parentNode;
    if(r!==curRoot){ curRoot=r; cur=[]; groups.push(cur); }
    cur.push(n);
  }
  groups.forEach(processGroup);
  bar();
}
window.__m3uScan=scan;
/* ---- alt panel: say + növbəti səhifə + avtomatik rejim ---- */
function nextLink(){
  var a=document.querySelector('a[rel="next"]'); if(a) return a;
  var all=document.querySelectorAll('a[href*="p="]');
  for(var i=0;i<all.length;i++){
    var l=((all[i].getAttribute('aria-label')||'')+' '+(all[i].textContent||'')).toLowerCase();
    if(/next/.test(l) && all[i].getAttribute('aria-disabled')!=='true') return all[i];
  }
  return null;
}
function scopeKeys(){
  var out=[], k, i;
  if(/^\/search/.test(location.pathname)){ for(k in state) out.push(k); }
  else if(/\/blob\//.test(location.pathname)){ for(k in cur) out.push(k); }
  else {
    var seen={}, sp=document.querySelectorAll('span.m3u-st');
    for(i=0;i<sp.length;i++){ k=sp[i].getAttribute('data-url'); if(seen[k]) continue; seen[k]=1; out.push(k); }
  }
  return out;
}
function counts(){
  var ok=0, dead=0, pend=0, ks=scopeKeys(), s;
  for(var i=0;i<ks.length;i++){ s=state[ks[i]]; if(s==='ok') ok++; else if(s==='dead') dead++; else pend++; }
  return {ok:ok,dead:dead,pend:pend};
}
function setTxt(el,t){ if(el && el.textContent!==t) el.textContent=t; }
/* Alt panel: 🟢/🔴 düyməsinə basanda həmin statusdakı linklərin siyahısı açılır; linkə basanda playerdə açılır */
var listTab='', listSig='', info='';
window.__m3uInfo=function(t){ info=t; try{ bar(); }catch(e){} };
function renderList(){
  var box=document.getElementById('m3u-list'); if(!box) return;
  if(!listTab){ if(box.style.display!=='none') box.style.display='none'; listSig=''; return; }
  var ks=scopeKeys(), arr=[], i;
  for(i=0;i<ks.length;i++){ if(state[ks[i]]===listTab) arr.push(ks[i]); }
  var sig=listTab+'|'+arr.length+'|'+(arr[arr.length-1]||'');
  if(box.style.display==='none') box.style.display='block';
  if(sig===listSig) return;
  listSig=sig;
  while(box.firstChild) box.removeChild(box.firstChild);
  var head=document.createElement('div');
  head.style.cssText='position:sticky;top:0;background:#0d1117;padding:5px 4px;font-weight:bold;border-bottom:1px solid #30363d';
  head.textContent=(listTab==='ok'?'\uD83D\uDFE2 \u0130\u015Fl\u0259k linkl\u0259r: ':'\uD83D\uDD34 \u0130\u015Fl\u0259m\u0259y\u0259n linkl\u0259r: ')+arr.length+'  (basanda playerd\u0259 a\u00E7\u0131l\u0131r)';
  box.appendChild(head);
  if(!arr.length){ var em=document.createElement('div'); em.style.cssText='padding:8px 4px;color:#8b949e'; em.textContent='H\u0259l\u0259 yoxdur'; box.appendChild(em); return; }
  var frag=document.createDocumentFragment(), lim=Math.min(arr.length,1000);
  for(i=0;i<lim;i++){
    (function(u,n){
      var it=document.createElement('div');
      it.style.cssText='padding:9px 4px;border-bottom:1px solid #21262d;font-size:12px;word-break:break-all;color:#e6edf3';
      it.textContent='\u25B6 '+n+'. '+u.split('|')[0];
      it.onclick=function(ev){ ev.preventDefault(); ev.stopPropagation(); try{ M3UProbe.play(u); }catch(x){} };
      frag.appendChild(it);
    })(arr[i],i+1);
  }
  box.appendChild(frag);
}
function bar(){
  var b=document.getElementById('m3u-bar');
  var isS=/^\/search/.test(location.pathname);
  var isB=/\/blob\//.test(location.pathname);
  if(!isS && !(isB && Object.keys(cur).length) && !document.querySelector('span.m3u-st')){ if(b) b.style.display='none'; return; }
  if(!b){
    b=document.createElement('div'); b.id='m3u-bar';
    b.style.cssText='position:fixed;left:0;right:0;bottom:0;z-index:2147483647;background:#161b22;color:#e6edf3;border-top:1px solid #30363d;padding:6px 8px;font:13px sans-serif;display:flex;align-items:center;gap:6px;flex-wrap:wrap';
    var lb=document.createElement('div'); lb.id='m3u-list';
    lb.style.cssText='display:none;flex:0 0 100%;max-height:40vh;overflow-y:auto;-webkit-overflow-scrolling:touch;background:#0d1117;border-radius:6px;margin-bottom:4px';
    b.appendChild(lb);
    var c=document.createElement('span'); c.id='m3u-cnt'; c.style.cssText='flex:1;min-width:60px'; b.appendChild(c);
    function btn(id,t,fn){ var x=document.createElement('button'); x.id=id; x.textContent=t;
      x.style.cssText='background:#238636;color:#fff;border:0;border-radius:6px;padding:6px 10px;font-size:13px'; x.onclick=fn; b.appendChild(x); return x; }
    function tabBtn(id,st,bg){ var x=btn(id,'',function(){ listTab = (listTab===st ? '' : st); listSig=''; bar(); }); x.style.background=bg; }
    tabBtn('m3u-tok','ok','#238636'); tabBtn('m3u-tdead','dead','#b62324');
    btn('m3u-auto','',function(){ auto=!auto; try{ sessionStorage.setItem('m3uAuto',auto?'1':'0'); }catch(e){} lastNew=Date.now(); lastNext=''; bar(); });
    var nb=btn('m3u-next','\u25B6 N\u00F6vb\u0259ti',function(){ var n=nextLink(); if(n) n.click(); }); nb.style.padding='8px 16px'; nb.style.fontWeight='bold';
    document.body.appendChild(b);
  }
  b.style.display='flex';
  document.getElementById('m3u-auto').style.display = 'none';
  document.getElementById('m3u-next').style.display = isS ? '' : 'none';
  var q=counts(), done=!!(isS && auto && !nextLink() && q.pend===0);
  setTxt(document.getElementById('m3u-cnt'),'\u23F3 '+q.pend+(info?'  '+info:'')+(done?'  \u2705 Bitdi':''));
  setTxt(document.getElementById('m3u-tok'),'\uD83D\uDFE2 '+q.ok+(listTab==='ok'?' \u25B2':' \u25BC'));
  setTxt(document.getElementById('m3u-tdead'),'\uD83D\uDD34 '+q.dead+(listTab==='dead'?' \u25B2':' \u25BC'));
  setTxt(document.getElementById('m3u-auto'), auto ? '\u23F9 Dayan' : '\u25B6\u25B6 Avto: b\u00FCt\u00FCn s\u0259hif\u0259l\u0259r');
  renderList();
  try{ var bh=(b.style.display==='none')?0:b.offsetHeight; if(bh!==window.__m3uBH){ window.__m3uBH=bh; M3UProbe.barH(bh); } }catch(e){}
}
/* Növbəti səhifələr gizli arxa plan brauzerində açılır (ekran dəyişmir); tapılan linklər burada yoxlanılır */
var bgKey='';
setInterval(function(){
  if(!/^\/search/.test(location.pathname)) return;
  var key=location.search.replace(/[?&]p=\d+/,'');
  if(key===bgKey) return;
  var n=nextLink(); if(!n) return;
  bgKey=key; try{ M3UProbe.bgStart(n.href); }catch(e){}
},1500);
function blockRootOf(n){ var r=n.parentNode; while(r && INLINE[r.nodeName]) r=r.parentNode; return r; }
/* Toxunulan nöqtədəki http(s) linkini mətndən tapır (yalnız hərfin üstünə toxunulubsa) */
/* Fayl səhifəsində kodun üstündə şəffaf textarea/örtük olur: onu müvəqqəti keçib altındakı mətni tapır */
function caretAt(x,y){
  var saved=[], rg=null;
  try{
    for(var i=0;i<6;i++){
      var el=document.elementFromPoint(x,y); if(!el) break;
      var overlay = el.nodeName==='TEXTAREA' || (!el.firstElementChild && !/\S/.test(el.textContent||''));
      if(!overlay) break;
      saved.push([el,el.style.pointerEvents]); el.style.pointerEvents='none';
    }
    rg=document.caretRangeFromPoint?document.caretRangeFromPoint(x,y):null;
  }catch(e){}
  for(var j=saved.length-1;j>=0;j--) saved[j][0].style.pointerEvents=saved[j][1];
  return rg;
}
function urlAt(x,y){
  try{
    var rg=caretAt(x,y); if(!rg) return '';
    var n=rg.startContainer, o=rg.startOffset; if(n.nodeType!==3) return '';
    if(n.parentNode && n.parentNode.className==='m3u-st') return '';
    var hit=false, L=n.nodeValue.length, pairs=[[o-1,o],[o,o+1]];
    for(var k=0;k<2&&!hit;k++){
      var p=pairs[k]; if(p[0]<0||p[1]>L) continue;
      var r2=document.createRange(); r2.setStart(n,p[0]); r2.setEnd(n,p[1]);
      var rs=r2.getClientRects();
      for(var i=0;i<rs.length;i++){ var q=rs[i]; if(x>=q.left-4&&x<=q.right+4&&y>=q.top-4&&y<=q.bottom+4) hit=true; }
    }
    if(!hit) return '';
    var root=blockRootOf(n), w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT), t, text='', pos=0, caret=-1;
    while((t=w.nextNode())){
      var pp=t.parentNode; if(pp && pp.className==='m3u-st') continue;
      if(blockRootOf(t)!==root) continue;
      if(t===n) caret=pos+o;
      text+=t.nodeValue; pos+=t.nodeValue.length;
    }
    if(caret<0) return '';
    var m, rr=/https?:\/\/[^\s"'<>`\\]+/g;
    while((m=rr.exec(text))){ var u=cleanEnd(m[0]); if(caret>=m.index && caret<=m.index+u.length) return u; }
  }catch(e){}
  return '';
}
window.__m3uUrlAt=urlAt;
function inPreview(el){
  try{ return !!(el && el.closest && el.closest('table,pre,code,[class*="snippet" i],[class*="blob-code"],[class*="code-list"],[data-testid*="snippet" i]')); }catch(e){ return false; }
}
function isBlobPage(){ return /\/blob\//.test(location.pathname); }
function block(e){ e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); }
document.addEventListener('click',function(e){
  var tg=e.target; if(tg && tg.closest && tg.closest('#m3u-bar')) return;
  var onSearch=/^\/search/.test(location.pathname);
  var u=urlAt(e.clientX,e.clientY);
  if(u && (/\.m3u8(\?|#|\||#SP#)/i.test(u) || (window.__m3uFile && isBlobPage() && good(u)))){ block(e); try{ M3UProbe.play(u); }catch(x){} return; }
  var a=tg&&tg.closest?tg.closest('a[href]'):null;
  if(a && a.href){
    try{ if(M3UProbe.link(a.href,(a.textContent||'').trim())){ block(e); return; } }catch(x){}
    if(onSearch && (inPreview(a) || /\/blob\/[^#]*#L\d+/.test(a.href))) block(e);
    return;
  }
  if(onSearch && inPreview(tg)) block(e);
},true);
var timer=null;
new MutationObserver(function(){ clearTimeout(timer); timer=setTimeout(scan,700); }).observe(document.body,{childList:true,subtree:true});
scan();
})();""".replace("#SP#", "$")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (PlayerPanel.handleBack()) return; if (customView != null) { web.webChromeClient?.onHideCustomView(); return }; if (findBar != null) { hideFindBar(); return }; 
        if (web.canGoBack()) web.goBack() else if (tabs.size > 1) closeTab(curTab) else super.onBackPressed() }
}
