package az.mehdi.iptvplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.SystemClock
import android.util.LruCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.Collections
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

/**
 * Loqo YALNIZ EPG mənbəsindən (https://iptvx.one/EPG_NOARCH, XML-dəki <icon src="...">) götürülür.
 *  - Offline keş: filesDir/logo_cache2 (fayl adı EPG kanal id-sinin hash-i).
 *  - Toplu yeniləmə (refreshAll): çatışan / linki dəyişən / (ETag, Last-Modified-ə görə) məzmunu dəyişən bütün loqolar
 *    16 paralel axınla müvəqqəti qovluğa (logo_new) endirilir, hamısı tam bitəndən sonra bir anda əvəz olunur.
 */
private const val WORKERS = 16
private const val CHANNEL_CHECK_MS = 5L * 60 * 1000

class LogoStore(private val ctx: Context, private val scope: CoroutineScope, private val epg: EpgStore) {
    private val dir = File(ctx.filesDir, "logo_cache2").apply { mkdirs() }
    private val stage = File(ctx.filesDir, "logo_new")
    private val failed = Collections.synchronizedSet(HashSet<String>())
    private val locks = java.util.concurrent.ConcurrentHashMap<String, Mutex>()
    private val refreshMutex = Mutex()
    private val lastCheck = java.util.concurrent.ConcurrentHashMap<String, Long>()
    // Bitmap yaddaş istifadəsinə görə keş limitlənir (təxminən 8 MiB).
    private val mem = object : LruCache<String, Bitmap>(8 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }

    // Toplu yeniləmə gedərkən kartlar tək-tək endirməsin: yeniləmənin bitməsini gözləyir.
    private val batchLock = Any()
    private var batchUsers = 0
    private var batch: CompletableDeferred<Unit>? = null
    fun beginBatch() = synchronized(batchLock) { if (batchUsers++ == 0) batch = CompletableDeferred() }
    fun endBatch() = synchronized(batchLock) {
        if (batchUsers > 0 && --batchUsers == 0) { batch?.complete(Unit); batch = null }
    }

    init {
        runCatching {
            File(ctx.filesDir, "logo_cache").deleteRecursively()
            File(ctx.filesDir, "logos").deleteRecursively()
            File(ctx.filesDir, "logo_list.txt").delete()
            File(ctx.filesDir, "logo_list.new").delete()
            File(ctx.filesDir, "logo_index.tsv").delete()
            stage.deleteRecursively()
        }
    }

    private fun md5(s: String) = MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun fileFor(key: String) = File(dir, md5(key) + ".img")
    private fun metaFor(key: String) = File(dir, md5(key) + ".meta")

    private class Meta(val url: String, val etag: String?, val lm: String?)
    private fun readMeta(key: String): Meta? = runCatching {
        val l = metaFor(key).readLines()
        Meta(l[0], l.getOrNull(1)?.takeIf { it.isNotEmpty() }, l.getOrNull(2)?.takeIf { it.isNotEmpty() })
    }.getOrNull()
    private fun writeMeta(key: String, url: String, etag: String?, lm: String?) {
        runCatching { metaFor(key).writeText(url + "\n" + (etag ?: "") + "\n" + (lm ?: "")) }
    }

    private fun isImage(f: File): Boolean {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        return o.outWidth > 0
    }

    private fun decode(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0) return null
        var s = 1
        val maxDimension = maxOf(o.outWidth, o.outHeight)
        while (maxDimension / s > 256) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private suspend fun fromDisk(key: String): Bitmap? {
        val file = fileFor(key)
        if (!(file.exists() && file.length() > 0L)) return null
        val b = withContext(Dispatchers.IO) { decode(file) }
        if (b != null) { mem.put(key, b); return b }
        file.delete() // zədəli fayl
        return null
    }

    suspend fun bitmapFor(ch: Channel): Bitmap? {
        epg.ready.await() // kanal -> EPG id uyğunluğu hazır olsun
        val key = epg.idFor(ch) ?: return null
        mem.get(key)?.let { return it }
        fromDisk(key)?.let { return it }

        // Toplu yeniləmə gedirsə onun bitməsini gözlə (hamısı birdən gəlsin)
        synchronized(batchLock) { batch }?.await()
        fromDisk(key)?.let { return it }
        if (failed.contains(key)) return null

        // Ehtiyat: toplu yeniləmə bu loqonu gətirməyibsə, tək endirmə cəhdi
        val u = epg.iconUrl(key) ?: run { failed.add(key); return null }
        locks.computeIfAbsent(key) { Mutex() }.withLock {
            mem.get(key)?.let { return it }
            val tmp = File(dir, md5(key) + ".dl")
            val ok = withContext(Dispatchers.IO) {
                try {
                    val r = fetchConditional(u, tmp, null, null, 10000)
                    if (!r.notModified && isImage(tmp)) {
                        val f = fileFor(key); if (f.exists()) f.delete(); tmp.renameTo(f)
                        writeMeta(key, u, r.etag, r.lastMod); true
                    } else { tmp.delete(); false }
                } catch (e: CancellationException) { throw e } catch (e: Exception) { tmp.delete(); false }
            }
            if (ok) fromDisk(key)?.let { return it }
        }
        failed.add(key) // yalnız bu sessiya üçün
        return null
    }

    /**
     * Kanal dəyişəndə çağırılır: həmin kanalın loqosu mənbədə dəyişibsə (link, ETag/Last-Modified və ya məzmun)
     * dərhal yenisini endirib əvəz edir. Eyni kanal üçün 5 dəqiqədən tez təkrar yoxlanmır. Yenilənibsə true.
     */
    suspend fun refreshChannel(ch: Channel): Boolean {
        epg.ready.await()
        val key = epg.idFor(ch) ?: return false
        val u = epg.iconUrl(key) ?: return false
        synchronized(batchLock) { batch }?.await() // toplu endirmə gedirsə onu gözlə
        val now = SystemClock.elapsedRealtime()
        val prev = lastCheck[key]
        if (prev != null && now - prev < CHANNEL_CHECK_MS) return false
        lastCheck[key] = now
        return locks.computeIfAbsent(key) { Mutex() }.withLock {
            val live = fileFor(key)
            val have = live.exists() && live.length() > 0L
            val meta = readMeta(key)
            val same = have && meta?.url == u
            val tmp = File(dir, md5(key) + ".chk")
            val updated = withContext(Dispatchers.IO) {
                try {
                    val r = fetchConditional(u, tmp, if (same) meta?.etag else null, if (same) meta?.lm else null, 8000)
                    if (r.notModified) { tmp.delete(); false }
                    else if (!isImage(tmp)) { tmp.delete(); false }
                    else if (have && tmp.length() == live.length() && tmp.readBytes().contentEquals(live.readBytes())) {
                        writeMeta(key, u, r.etag, r.lastMod); tmp.delete(); false // məzmun eynidir
                    } else {
                        if (live.exists()) live.delete()
                        val ok = tmp.renameTo(live) || runCatching { tmp.copyTo(live, true); tmp.delete(); true }.getOrDefault(false)
                        if (ok) writeMeta(key, u, r.etag, r.lastMod)
                        ok
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    tmp.delete(); false
                }
            }
            if (updated) { mem.remove(key); fromDisk(key) }
            updated
        }
    }

    private class Item(val key: String, val url: String, val etag: String?, val lm: String?)
    private class Staged(val key: String, val url: String, val etag: String?, val lm: String?, val file: File)

    /**
     * Çatışan, linki dəyişən (və ya `force` / 6 saatdan bir ETag-Last-Modified yoxlamasına görə məzmunu dəyişən) bütün
     * loqoları 16 paralel axınla müvəqqəti qovluğa endirir; HAMISI tam bitəndən sonra birdən əvəz edir.
     * Əvəz olunan loqoların sayını qaytarır.
     */
    suspend fun refreshAll(channels: List<Channel>, force: Boolean): Int = refreshMutex.withLock {
        failed.clear()
        val keys = channels.mapNotNull { epg.idFor(it) }.distinct()
        if (keys.isEmpty()) return@withLock 0
        val revalidate = force

        val todo = ArrayList<Item>()
        for (key in keys) {
            val u = epg.iconUrl(key) ?: continue
            val have = fileFor(key).let { it.exists() && it.length() > 0L }
            val meta = readMeta(key)
            if (!have || meta == null || meta.url != u) todo.add(Item(key, u, null, null))
            else if (revalidate && (force || meta.etag != null || meta.lm != null)) todo.add(Item(key, u, meta.etag, meta.lm))
        }
        if (todo.isEmpty()) return@withLock 0

        stage.deleteRecursively(); stage.mkdirs()
        val done = ConcurrentLinkedQueue<Staged>()
        val next = AtomicInteger(0)
        coroutineScope {
            repeat(minOf(WORKERS, todo.size)) {
                launch(Dispatchers.IO) {
                    while (true) {
                        val i = next.getAndIncrement()
                        if (i >= todo.size) break
                        val it = todo[i]
                        val tmp = File(stage, md5(it.key) + ".img")
                        var attempt = 0
                        while (attempt < 2) {
                            attempt++
                            try {
                                val r = fetchConditional(it.url, tmp, it.etag, it.lm, 10000)
                                if (!r.notModified && isImage(tmp)) done.add(Staged(it.key, it.url, r.etag, r.lastMod, tmp))
                                else tmp.delete()
                                break
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                tmp.delete()
                            }
                        }
                    }
                }
            }
        }

        // Hamısı endirildi -> bir anda əvəz et
        var replaced = 0
        withContext(Dispatchers.IO) {
            for (s in done) {
                val live = fileFor(s.key)
                if (live.exists()) live.delete()
                val ok = s.file.renameTo(live) || runCatching { s.file.copyTo(live, true); true }.getOrDefault(false)
                if (ok) { writeMeta(s.key, s.url, s.etag, s.lm); replaced++ }
            }
            stage.deleteRecursively()
        }
        if (replaced > 0) mem.evictAll()
        replaced
    }
}
