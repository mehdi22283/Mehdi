package com.mehdi.keymapper

import android.content.Context
import android.content.SharedPreferences
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

data class Action(val type: String = "NONE", val param: String = "") {
    fun describe(): String {
        val i = Actions.TYPES.indexOf(type)
        val name = if (i >= 0) Actions.LABELS[i] else type
        return if (param.isBlank() || type == "NONE") name else "$name: $param"
    }
}

data class Mapping(val key: Int, val short: Action, val long: Action)

object Actions {
    val TYPES = listOf("NONE", "KEY", "APP", "FORCE_STOP", "HOME", "BACK", "SHELL")
    val LABELS = listOf("Heç nə", "Düymə göndər", "Tətbiq aç", "Cari tətbiqi dayandır", "Home", "Geri", "ADB əmri")
    val HINTS = listOf("", "KEYCODE_DPAD_LEFT", "es.ottplayer.tv", "", "", "", "input keyevent 4")
}

object Store {
    private lateinit var sp: SharedPreferences
    @Volatile var mappings: List<Mapping> = emptyList()
        private set
    @Volatile private var map: Map<Int, Mapping> = emptyMap()

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.applicationContext.getSharedPreferences("km", Context.MODE_PRIVATE)
        val s = sp.getString("mappings", null)
        mappings = if (s == null) defaults() else try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Mapping(
                    o.getInt("k"),
                    Action(o.getString("st"), o.getString("sp")),
                    Action(o.getString("lt"), o.getString("lp"))
                )
            }
        } catch (e: Exception) { defaults() }
        map = mappings.associateBy { it.key }
    }

    var host: String
        get() = sp.getString("host", "192.168.31.220") ?: "192.168.31.220"
        set(v) { sp.edit().putString("host", v).apply() }

    var port: Int
        get() = sp.getInt("port", 5555)
        set(v) { sp.edit().putInt("port", v).apply() }

    var repeatDelay: Long
        get() = sp.getLong("rd", 250L)
        set(v) { sp.edit().putLong("rd", v).apply() }

    var repeatInterval: Long
        get() = sp.getLong("ri", 40L)
        set(v) { sp.edit().putLong("ri", v).apply() }

    fun find(code: Int): Mapping? = map[code]

    private fun defaults() = listOf(
        Mapping(KeyEvent.KEYCODE_BUTTON_6, Action("KEY", "KEYCODE_DPAD_LEFT"), Action()),
        Mapping(KeyEvent.KEYCODE_BUTTON_7, Action("KEY", "KEYCODE_DPAD_RIGHT"), Action()),
        Mapping(KeyEvent.KEYCODE_BUTTON_5, Action("KEY", "KEYCODE_DPAD_CENTER"), Action("APP", "es.ottplayer.tv")),
        Mapping(KeyEvent.KEYCODE_HOME, Action("HOME"), Action("FORCE_STOP"))
    )

    private fun save(l: List<Mapping>) {
        mappings = l
        map = l.associateBy { it.key }
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("k", it.key)
                    .put("st", it.short.type).put("sp", it.short.param)
                    .put("lt", it.long.type).put("lp", it.long.param)
            )
        }
        sp.edit().putString("mappings", a.toString()).apply()
    }

    fun upsert(oldKey: Int?, m: Mapping) = save(mappings.filter { it.key != m.key && it.key != oldKey } + m)
    fun remove(key: Int) = save(mappings.filter { it.key != key })
    fun reset() = save(defaults())

    fun keyName(code: Int): String = KeyEvent.keyCodeToString(code)

    fun parseKey(s: String): Int {
        val t = s.trim().uppercase()
        t.toIntOrNull()?.let { return it }
        var c = KeyEvent.keyCodeFromString(t)
        if (c == KeyEvent.KEYCODE_UNKNOWN) c = KeyEvent.keyCodeFromString("KEYCODE_$t")
        return c
    }
}
