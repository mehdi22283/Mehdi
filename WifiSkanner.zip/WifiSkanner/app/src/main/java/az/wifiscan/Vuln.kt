package az.wifiscan

import java.net.InetSocketAddress
import java.net.Socket

/** level: 3 = yüksək, 2 = orta, 1 = aşağı */
class Vuln(val level: Int, val title: String, val detail: String) {
    val icon: String get() = when (level) { 3 -> "🔴"; 2 -> "🟠"; else -> "🟡" }
    val label: String get() = when (level) { 3 -> "Yüksək"; 2 -> "Orta"; else -> "Aşağı" }
}

/**
 * Passiv qaydalar (açıq portlar, bannerlər) + yalnız öz şəbəkədə yüngül yoxlamalar
 * (parolsuz RTSP, anonim FTP). Parol sınağı / istismar YOXDUR.
 */
object VulnCheck {
    private val oldSoft = listOf(
        Regex("(?i)\\bboa\\b") to "Boa web server (dəstəyi dayandırılıb, bir çox kamera/router açığı var)",
        Regex("(?i)goahead") to "GoAhead web server (köhnə versiyalarda ciddi açıqlar var)",
        Regex("(?i)mini_httpd") to "mini_httpd (köhnə IoT firmware əlaməti)",
        Regex("(?i)apache/2\\.[02]\\.") to "Apache 2.0/2.2 (köhnəlmiş)",
        Regex("(?i)lighttpd/1\\.4\\.[0-3]\\d?\\b") to "Köhnə lighttpd",
        Regex("(?i)openssh[_-][1-6]\\.") to "Köhnə OpenSSH versiyası",
        Regex("(?i)dropbear.*20(0\\d|1[0-5])") to "Köhnə Dropbear SSH",
        Regex("(?i)miniupnpd/1\\.[0-5]") to "Köhnə miniupnpd (UPnP)"
    )

    /** Şəbəkə sorğuları ilə tam yoxlama (arxa thread-də çağırın). */
    fun run(d: Device) {
        val extra = ArrayList<Vuln>()
        if (554 in d.ports) {
            val pr = Rtsp.describe(d.ip, 554, "/")
            val pr2 = if (pr.code == 404 || pr.code == -1) Rtsp.describe(d.ip, 554, "/Streaming/Channels/101") else pr
            val ok = listOf(pr, pr2).any { it.code == 200 }
            if (ok) extra.add(Vuln(3, "Kamera parolsuz yayım verir", "RTSP (554) autentifikasiya tələb etmir: şəbəkədəki hər kəs canlı videoya baxa bilər. Kamera parolunu təyin edin."))
        }
        if (21 in d.ports && anonFtp(d.ip)) {
            extra.add(Vuln(3, "Anonim FTP girişi açıqdır", "FTP serverinə istifadəçi adı/parolsuz (anonymous) daxil olmaq mümkündür."))
        }
        d.vulns = (analyze(d) + extra).sortedByDescending { it.level }
    }

    /** Yalnız portlara/bannerlərə əsaslanan passiv təhlil (şəbəkə sorğusu yoxdur). */
    fun analyze(d: Device): List<Vuln> {
        val p = d.ports
        val r = ArrayList<Vuln>()
        if (23 in p) r.add(Vuln(3, "Telnet açıqdır (23)", "Şifrələnməmiş idarəetmə. Parollar şəbəkədə açıq mətnlə gedir; IoT botnetlərinin əsas hədəfidir. Söndürün, yerinə SSH istifadə edin."))
        if (5555 in p) r.add(Vuln(3, "Android ADB açıqdır (5555)", "Autentifikasiyasız uzaqdan komanda icrasına yol aça bilər. TV/box-da ADB debugging-i söndürün."))
        if (5900 in p) r.add(Vuln(3, "VNC açıqdır (5900)", "Uzaq ekran idarəsi. Güclü parol olmasa və ya şifrəsizdirsə təhlükəlidir."))
        if (3389 in p) r.add(Vuln(2, "RDP açıqdır (3389)", "Brute-force və BlueKeep tipli hücumların hədəfi. Windows yeniləmələri və NLA aktiv olmalıdır."))
        if (21 in p) r.add(Vuln(2, "FTP açıqdır (21)", "Parollar şifrələnmədən ötürülür. Mümkünsə SFTP istifadə edin."))
        if (445 in p && !d.isSelf) r.add(Vuln(2, "SMB açıqdır (445)", "Fayl paylaşımı. SMBv1 söndürülməli, paylaşımlar parolla qorunmalıdır (EternalBlue tipli açıqlar)."))
        if (139 in p && 445 !in p) r.add(Vuln(1, "NetBIOS açıqdır (139)", "Cihaz adı və paylaşım məlumatı sızdıra bilər."))
        if (7547 in p) r.add(Vuln(2, "TR-069 açıqdır (7547)", "Router uzaqdan idarə portu; keçmişdə kütləvi hücumlarda (Mirai variantları) istifadə olunub."))
        if (8291 in p || 8728 in p) r.add(Vuln(2, "MikroTik idarə portu açıqdır", "Winbox/API portu (8291/8728). RouterOS yenilənməlidir (köhnə versiyalarda CVE-2018-14847), yalnız etibarlı IP-lərə icazə verin."))
        if (34567 in p || 37777 in p) r.add(Vuln(2, "DVR/NVR idarə portu açıqdır", "XMeye (34567) / Dahua (37777) portları. Bu ailələrin köhnə firmware-lərində məlum açıqlar var, firmware-i yeniləyin."))
        if (554 in p && r.none { it.title.startsWith("Kamera parolsuz") }) r.add(Vuln(1, "RTSP açıqdır (554)", "Kamera video axını şəbəkədə əlçatandır. Güclü parol təyin olunduğuna əmin olun."))
        if (1883 in p) r.add(Vuln(2, "MQTT şifrəsiz açıqdır (1883)", "Broker anonim qoşulmaya icazə verirsə, IoT cihazları kənardan idarə oluna bilər."))
        if (9100 in p) r.add(Vuln(1, "Printer RAW portu açıqdır (9100)", "Şəbəkədəki hər kəs çapa göndərə bilər."))
        if ((80 in p || 8080 in p || 8000 in p) && 443 !in p && 8443 !in p && !d.isSelf && (d.isGateway || d.type.contains("Kamera") || d.type.contains("Router")))
            r.add(Vuln(1, "Admin panel yalnız HTTP-dir", "Giriş parolu şifrələnməmiş ötürülür. Mümkünsə HTTPS aktiv edin."))
        if (53 in p && !d.isGateway && !d.isSelf) r.add(Vuln(1, "DNS servisi açıqdır (53)", "Gözlənilməz DNS server: DNS yönləndirmə (hijack) riskini yoxlayın."))
        if ((49152 in p || 1900 in p) && d.isGateway) r.add(Vuln(1, "UPnP aktivdir", "Cihazlar router-də avtomatik port açdıra bilər. Lazım deyilsə söndürün."))
        if (p.size >= 8 && !d.isSelf) r.add(Vuln(1, "Çox sayda açıq port (${p.size})", "Hücum səthi genişdir; istifadə olunmayan servisləri söndürün."))
        val texts = ArrayList<String>()
        texts.add(d.http); texts.add(d.upnp); texts.addAll(d.banners.values)
        val all = texts.joinToString(" | ")
        for ((rx, msg) in oldSoft) if (rx.containsMatchIn(all)) r.add(Vuln(2, "Köhnə proqram aşkarlandı", msg))
        return r.sortedByDescending { it.level }
    }

    private fun anonFtp(ip: String): Boolean = try {
        Socket().use { s ->
            s.connect(InetSocketAddress(ip, 21), 1000); s.soTimeout = 1500
            val ins = s.getInputStream(); val out = s.getOutputStream()
            fun read(): String { val b = ByteArray(512); val n = ins.read(b); return if (n > 0) String(b, 0, n) else "" }
            read()
            out.write("USER anonymous\r\n".toByteArray()); var a = read()
            if (a.startsWith("230")) true
            else if (a.startsWith("331")) { out.write("PASS wifiskan@local\r\n".toByteArray()); a = read(); a.startsWith("230") }
            else false
        }
    } catch (e: Exception) { false }
}
