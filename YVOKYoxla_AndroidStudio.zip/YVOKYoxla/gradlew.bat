@echo off
setlocal
set VERSION=8.9
set GH=%GRADLE_USER_HOME%
if "%GH%"=="" set GH=%USERPROFILE%\.gradle
set BASE=%GH%\wrapper\dists\gradle-%VERSION%-bin\yvok
set GRADLE=%BASE%\gradle-%VERSION%\bin\gradle.bat
if exist "%GRADLE%" goto run
if not exist "%BASE%" mkdir "%BASE%"
set ZIP=%BASE%\gradle-%VERSION%-bin.zip
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ZIP%'; Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%BASE%' -Force"
if errorlevel 1 exit /b %errorlevel%
:run
call "%GRADLE%" %*
exit /b %errorlevel%
