#!/system/bin/sh
# Run these commands from a host PC with adb installed.
# The TV Box itself uses the same address requested for the local ADB endpoint.

set -e
PKG='com.mehdi.keymapper'
COMP="$PKG/com.mehdi.keymapper.KeyMapperAccessibilityService"
TV='192.168.31.220:5555'

adb connect "$TV"
adb install -r app-debug.apk

# Allow the app to keep its Accessibility service enabled programmatically.
adb shell pm grant "$PKG" android.permission.WRITE_SECURE_SETTINGS || true

# Remove the app from the common background execution restrictions.
adb shell settings put global app_standby_enabled 0 || true
adb shell cmd appops set "$PKG" RUN_IN_BACKGROUND allow || true
adb shell cmd appops set "$PKG" RUN_ANY_IN_BACKGROUND allow || true

# Stronger device-idle protection.
adb shell dumpsys deviceidle whitelist +"$PKG" || true

# Auto-enable this Accessibility service.
adb shell settings put secure enabled_accessibility_services "$COMP"
adb shell settings put secure accessibility_enabled 1

# Start the app and its foreground service.
adb shell am start -n "$PKG/.MainActivity"

echo
echo 'Done. Now open the app once, verify Accessibility=ON and enable Shizuku/Injector.'
