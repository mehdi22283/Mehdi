package az.market.endirim

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.Base64
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume

/**
 * Bravo: Publuu səhifəsində sağ yuxarıdakı paylaş düyməsi (üç birləşmiş dairə) → açılan pəncərədə
 * aşağıdakı qırmızı PDF düyməsi. Gizli WebView bu addımları özü edir, PDF-i endirir, PDF kimi
 * yoxlayır (başlıq %PDF + PdfRenderer) və tətbiqdə PDF slayd kimi göstərilir.
 */
object BravoPdf {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private const val EVENTS = "['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(n){" +
        "t.dispatchEvent(new MouseEvent(n,{bubbles:true,cancelable:true,view:window}));});"

    private const val SHARE_JS = """(function(){
 function vis(e){var r=e.getBoundingClientRect();return r.width>4&&r.height>4&&r.bottom>0&&r.right>0;}
 function cls(e){var c=e.className;return (typeof c==='string'?c:(c&&c.baseVal)||'');}
 var c=[];
 [].slice.call(document.querySelectorAll('button,a,[role=button],div,span,li,svg')).forEach(function(e){
  if(!vis(e))return;
  var r=e.getBoundingClientRect();
  if(r.width>120||r.height>120)return;
  var s=((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||'')+' '+cls(e)+' '+(e.id||'')).toLowerCase();
  var sc=0;
  if(/share|payla/.test(s))sc+=3;
  if(e.querySelectorAll('circle').length===3)sc+=2;
  if(sc>0&&r.top<200)sc+=1;
  if(sc>=3)c.push({e:e,s:sc,l:r.left});
 });
 if(!c.length)return 'none';
 c.sort(function(a,b){return b.s-a.s||b.l-a.l;});
 var t=c[0].e;
 $EVENTS
 return 'ok';
})()"""

    private const val PDF_JS = """(function(){
 function vis(e){var r=e.getBoundingClientRect();return r.width>4&&r.height>4;}
 var c=[];
 [].slice.call(document.querySelectorAll('a,button,[role=button],div,span,li')).forEach(function(e){
  if(!vis(e))return;
  var r=e.getBoundingClientRect();
  if(r.width>400||r.height>200)return;
  var t=((e.innerText||'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||'')+' '+(e.getAttribute('href')||'')).toLowerCase();
  if(t.indexOf('pdf')<0)return;
  var m=(getComputedStyle(e).backgroundColor.match(/\d+/g))||[];
  var red=(m.length>=3&&+m[0]>150&&+m[1]<110&&+m[2]<110)?1:0;
  var tag=e.tagName;
  c.push({e:e,s:red*2+((tag==='A'||tag==='BUTTON')?1:0)-e.querySelectorAll('*').length*0.01,b:r.bottom});
 });
 if(!c.length)return 'none';
 c.sort(function(a,b){return b.s-a.s||b.b-a.b;});
 var t=c[0].e;
 var a=(t.tagName==='A')?t:(t.closest?t.closest('a'):null);
 var h=a?(a.href||''):'';
 $EVENTS
 return /^https?:/.test(h)?h:'clicked';
})()"""

    /** Yoxlanmış PDF-in "açar linkini" qaytarır (Downloader.fileFor ilə fayla çevrilir); alınmasa null. */
    suspend fun resolve(activity: Activity, flipUrl: String): String? {
        val ctx = activity.applicationContext
        val prefs = ctx.getSharedPreferences("bravopdf", Context.MODE_PRIVATE)
        prefs.getString(flipUrl, null)?.let { key ->
            if (valid(Downloader.fileFor(ctx, key))) return key
        }
        val key = grab(activity, flipUrl) ?: return null
        prefs.edit().putString(flipUrl, key).apply()
        return key
    }

    /** PDF yoxlaması: %PDF başlığı + PdfRenderer səhifələri aça bilir. */
    fun valid(f: File): Boolean {
        if (!f.exists() || f.length() < 1024) return false
        return try {
            val head = ByteArray(4)
            f.inputStream().use { it.read(head) }
            if (String(head, Charsets.ISO_8859_1) != "%PDF") return false
            ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                val r = PdfRenderer(pfd)
                try { r.pageCount > 0 } finally { r.close() }
            }
        } catch (e: Exception) {
            false
        }
    }

    private suspend fun js(web: WebView, code: String): String = suspendCancellableCoroutine { c ->
        web.evaluateJavascript(code) { v ->
            c.resume((v ?: "").trim('"').replace("\\/", "/").replace("\\u0026", "&"))
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private suspend fun grab(activity: Activity, flipUrl: String): String? {
        val ctx = activity.applicationContext
        val root = activity.findViewById<ViewGroup>(android.R.id.content)
        val w = activity.resources.displayMetrics.widthPixels
        val h = (w * 1.6f).toInt()
        val result = CompletableDeferred<String>()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val web = WebView(activity)

        // link endirilir → fayla yazılır → PDF kimi yoxlanır
        fun saveFrom(url: String, ua: String?) {
            scope.launch {
                try {
                    val f = Downloader.fileFor(ctx, url)
                    val tmp = File(f.path + ".part")
                    val c = URL(url).openConnection() as HttpURLConnection
                    try {
                        c.setRequestProperty("User-Agent", ua ?: UA)
                        c.setRequestProperty("Referer", flipUrl)
                        CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
                        c.connectTimeout = 20_000
                        c.readTimeout = 60_000
                        if (c.responseCode != 200) return@launch
                        c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    } finally {
                        c.disconnect()
                    }
                    if (valid(tmp) && tmp.renameTo(f)) result.complete(url) else tmp.delete()
                } catch (e: Exception) {
                }
            }
        }

        val bridge = object {
            @JavascriptInterface
            fun blob(b64: String) {
                scope.launch {
                    try {
                        val key = "$flipUrl#bravo.pdf"
                        val f = Downloader.fileFor(ctx, key)
                        val tmp = File(f.path + ".part")
                        tmp.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                        if (valid(tmp) && tmp.renameTo(f)) result.complete(key) else tmp.delete()
                    } catch (e: Exception) {
                    }
                }
            }
        }

        try {
            web.settings.javaScriptEnabled = true
            web.settings.domStorageEnabled = true
            web.settings.userAgentString = UA
            web.webViewClient = WebViewClient()
            web.addJavascriptInterface(bridge, "BravoBridge")
            web.setDownloadListener { url, ua, _, _, _ ->
                if (url.startsWith("blob:")) {
                    web.evaluateJavascript(
                        "fetch('$url').then(function(r){return r.blob();}).then(function(b){var f=new FileReader();" +
                            "f.onload=function(){BravoBridge.blob(String(f.result).split(',')[1]);};f.readAsDataURL(b);});",
                        null
                    )
                } else saveFrom(url, ua)
            }
            web.translationX = -w.toFloat()   // ekranın kənarında, görünmür
            root.addView(web, FrameLayout.LayoutParams(w, h))
            web.loadUrl(flipUrl)

            withTimeoutOrNull(60_000) {
                delay(4000)
                var shared = false
                var misses = 0
                while (!result.isCompleted) {
                    if (!shared) {
                        if (js(web, SHARE_JS) == "ok") { shared = true; misses = 0 }
                        delay(2000)
                    } else {
                        val r = js(web, PDF_JS)
                        when {
                            r.startsWith("http") -> { saveFrom(r, null); delay(6000) }
                            r == "clicked" -> delay(6000)
                            else -> { if (++misses > 4) shared = false; delay(1500) }
                        }
                    }
                }
            }
            return if (result.isCompleted) result.await() else null
        } finally {
            scope.cancel()
            root.removeView(web)
            web.destroy()
        }
    }
}
