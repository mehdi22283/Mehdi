# M3U Sınayıcı (Android APK)

## APK-nı yığmaq

**Variant 1 – GitHub (kompüter lazım deyil):**
1. Bu qovluğun məzmununu yeni GitHub repoya yükləyin (`main` branch).
2. Repo → **Actions** → "APK yığ" işi bitəndə **Artifacts → M3USinayici-apk** yükləyin (içində `app-debug.apk`).
3. APK-nı telefona köçürüb quraşdırın ("naməlum mənbələrdən quraşdırma"ya icazə verin).

**Variant 2 – Android Studio:** qovluğu açın → Build → Build APK(s).
Fayl: `app/build/outputs/apk/debug/app-debug.apk`

APK sabit açarla (`app/debug.keystore`) imzalanır, buna görə yeni versiya köhnənin üstünə
məlumat silinmədən qurulur.

## Nə edir
- Səhifə tətbiqin daxili brauzerində (WebView) açılır; xarici linklər də tətbiqin daxili brauzerində açılır.
- Hansı "Fayl yüklə" düyməsindən seçilsə də, fayl avtomatik **1-ci playlistə** düşür və tətbiq bağlananda belə orada qalır.
- 1-ci playlistin altında: son giriş tarixi, indiyə qədər xarab olan kanalların sayı və siyahısı.
  Kanal ardıcıl 3 yoxlamada 🔴 çıxsa "xarab oldu" sayılır (`bridge` kodunda `DEAD_CONFIRM`).
- Kanala toxunanda oynadıcı əvvəlki kimi siyahının içində açılır, amma ExoPlayer (Media3) ilə. Oynadıcının
  üzərindəki tam ekran düyməsi onu tam ekranda açır. Eyni anda ən çox 4 oynadıcı işləyir; ekrandan çıxan oynadıcı dayanır.
- Kanal yoxlaması native HTTP ilə edilir (brauzerdəki CORS məhdudiyyəti olmadan).
