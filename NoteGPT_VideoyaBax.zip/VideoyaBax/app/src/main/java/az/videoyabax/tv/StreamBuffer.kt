package az.videoyabax.tv

import java.io.IOException

/**
 * Şəbəkədən (telefondan) gələn video məlumatını YALNIZ RAM-da saxlayan bufer.
 *
 * Diskə / TV-nin daxili yaddaşına heç bir şey yazılmır.
 * Oxuyan tərəf (ExoPlayer) hələ gəlməmiş baytları istəyərsə, yeni məlumat gələnə
 * qədər gözləyir — yəni video anlıq olaraq axın (stream) şəklində oynanılır.
 */
class StreamBuffer(val totalBytes: Long) {

    companion object {
        /** Bir yaddaş bloku (128 KB) */
        private const val CHUNK_SIZE = 128 * 1024

        /** Məlumat gəlməzsə nə qədər gözlənilsin (ms) */
        private const val WAIT_TIMEOUT_MS = 60_000L

        /**
         * Maksimum RAM buferi (bayt). 0 = limitsiz.
         * Android TV qurğularında adətən 1.5–2 GB RAM olur; təhlükəsiz hədd.
         */
        @Volatile
        var maxBytes: Long = 1200L * 1024 * 1024
    }

    private val lock = Object()
    private val chunks = ArrayList<ByteArray>()

    @Volatile
    private var length = 0L

    @Volatile
    private var finished = false

    @Volatile
    private var failure: String? = null

    @Volatile
    private var abandoned = false

    private var lastDataAt = System.currentTimeMillis()

    /** Şəbəkədən gələn baytları bufera əlavə edir. */
    fun append(data: ByteArray, offset: Int, count: Int) {
        if (count <= 0) return
        synchronized(lock) {
            if (abandoned) return
            if (maxBytes > 0 && length + count > maxBytes) {
                if (failure == null) {
                    failure = "RAM buferi doldu (${maxBytes / 1024 / 1024} MB). Daha böyük video üçün RAM kifayət etmir."
                }
                lock.notifyAll()
                return
            }
            var sourceOffset = offset
            var remaining = count
            while (remaining > 0) {
                val index = (length / CHUNK_SIZE).toInt()
                val inChunk = (length % CHUNK_SIZE).toInt()
                if (index == chunks.size) chunks.add(ByteArray(CHUNK_SIZE))
                val chunk = chunks[index]
                val n = minOf(remaining, CHUNK_SIZE - inChunk)
                System.arraycopy(data, sourceOffset, chunk, inChunk, n)
                length += n
                sourceOffset += n
                remaining -= n
            }
            lastDataAt = System.currentTimeMillis()
            lock.notifyAll()
        }
    }

    /** Yükləmə uğurla tamamlandı. */
    fun finish() {
        synchronized(lock) {
            finished = true
            lock.notifyAll()
        }
    }

    /** Xəta baş verdi (oxuyan tərəfə ötürülür). */
    fun fail(message: String) {
        synchronized(lock) {
            if (failure == null) failure = message
            lock.notifyAll()
        }
    }

    /** Köhnə sessiyanı bağlayır (yeni video gələndə). */
    fun abandon() {
        synchronized(lock) {
            abandoned = true
            lock.notifyAll()
        }
    }

    /** Buferdə olan bayt sayı. */
    fun available(): Long = length

    fun isComplete(): Boolean = finished

    fun isFailed(): Boolean = failure != null

    fun errorMessage(): String? = failure

    /**
     * Gözlənilən baytları verir; məlumat hələ gəlməyibsə gözləyir.
     *
     * @return oxunan bayt sayı, ya da axın bitibsə -1.
     */
    @Throws(IOException::class)
    fun read(position: Long, target: ByteArray, offset: Int, size: Int): Int {
        synchronized(lock) {
            while (length <= position) {
                failure?.let { throw IOException(it) }
                if (abandoned) throw IOException("Sessiya dayandırıldı")
                if (finished) return -1
                if (System.currentTimeMillis() - lastDataAt > WAIT_TIMEOUT_MS) {
                    throw IOException("Telefondan məlumat gəlmir (gözləmə vaxtı bitdi)")
                }
                try {
                    lock.wait(250)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw IOException("Oxuma ləğv edildi")
                }
            }

            val available = minOf(size.toLong(), length - position).toInt()
            var pos = position
            var out = offset
            var remaining = available
            while (remaining > 0) {
                val index = (pos / CHUNK_SIZE).toInt()
                val inChunk = (pos % CHUNK_SIZE).toInt()
                val chunk = chunks[index]
                val n = minOf(remaining, CHUNK_SIZE - inChunk)
                System.arraycopy(chunk, inChunk, target, out, n)
                pos += n
                out += n
                remaining -= n
            }
            return available
        }
    }
}
