package az.mirror.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Outline
import android.os.Bundle
import android.os.SystemClock
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var holder: FrameLayout
    private lateinit var preview: PreviewView
    private lateinit var focusRing: View
    private lateinit var expoBox: LinearLayout
    private lateinit var expoSeek: SeekBar
    private lateinit var expoLabel: TextView

    private var camera: Camera? = null
    private var expoMin = 0
    private var reversed = false
    private var lightOn = false
    private var ringPx = 0f

    // Sifət avto fokusu
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val detector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setMinFaceSize(0.15f)
                .build()
        )
    }
    private var manualLock = false
    private var faceFocused = false
    private var lastFocusMs = 0L
    private var lastNx = 0f
    private var lastNy = 0f
    private var lastNw = 0f

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera()
            else Toast.makeText(this, "Kamera icazəsi lazımdır", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContentView(R.layout.activity_main)
        ringPx = 72 * resources.displayMetrics.density

        root = findViewById(R.id.root)
        holder = findViewById(R.id.holder)
        preview = findViewById(R.id.preview)
        focusRing = findViewById(R.id.focusRing)
        expoBox = findViewById(R.id.expoBox)
        expoSeek = findViewById(R.id.expoSeek)
        expoLabel = findViewById(R.id.expoLabel)

        preview.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        preview.scaleType = PreviewView.ScaleType.FILL_CENTER

        holder.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val r = if (lightOn) 28 * resources.displayMetrics.density else 0f
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        holder.clipToOutline = true

        expoBox.visibility = View.GONE
        expoSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val idx = p + expoMin
                camera?.cameraControl?.setExposureCompensationIndex(idx)
                expoLabel.text = "☀️ " + (if (idx > 0) "+$idx" else "$idx")
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        setupGestures()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else permLauncher.launch(Manifest.permission.CAMERA)

        Toast.makeText(
            this,
            "Fokus sifətə avtomatik • Basıb saxla: əllə fokus • Toxun: avto fokus • Sürüşdür: tərs/düz • 2 dəfə toxun: işıq",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        analysisExecutor.shutdown()
        detector.close()
    }

    private fun setupGestures() {
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                autoFocus()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                manualFocus(e)
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                toggleLight()
                return true
            }

            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float
            ): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dx) > 120 && abs(dx) > abs(dy) * 1.5f && abs(vx) > 600) {
                    toggleReverse()
                    return true
                }
                return false
            }
        })
        preview.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            true
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val prev = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build().also { it.setAnalyzer(analysisExecutor) { p -> analyze(p) } }
            provider.unbindAll()
            try {
                val cam = provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_FRONT_CAMERA, prev, analysis
                )
                camera = cam
                setupExposure(cam)
            } catch (e: Exception) {
                Toast.makeText(this, "Ön kamera açılmadı", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setupExposure(cam: Camera) {
        val st = cam.cameraInfo.exposureState
        if (!st.isExposureCompensationSupported) {
            expoBox.visibility = View.GONE
            return
        }
        val range = st.exposureCompensationRange
        expoMin = range.lower
        expoSeek.max = range.upper - range.lower
        expoSeek.progress = -range.lower
        expoBox.visibility = View.VISIBLE
    }

    // ---------- Sifət aşkarlama + avto fokus ----------

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null || manualLock) {
            proxy.close()
            return
        }
        val rot = proxy.imageInfo.rotationDegrees
        val upW = if (rot == 90 || rot == 270) proxy.height else proxy.width
        val upH = if (rot == 90 || rot == 270) proxy.width else proxy.height
        val input = InputImage.fromMediaImage(media, rot)
        detector.process(input)
            .addOnSuccessListener { faces -> onFaces(faces, upW, upH) }
            .addOnCompleteListener { proxy.close() }
    }

    private fun onFaces(faces: List<Face>, upW: Int, upH: Int) {
        if (manualLock) return
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
        if (face == null) {
            if (faceFocused) {
                faceFocused = false
                camera?.cameraControl?.cancelFocusAndMetering()
                focusRing.animate().cancel()
                focusRing.visibility = View.GONE
            }
            return
        }
        val vw = preview.width.toFloat()
        val vh = preview.height.toFloat()
        if (vw == 0f || vh == 0f) return

        val b = face.boundingBox
        // Ön kamera önizləməsi güzgülüdür, ona görə x tərsinə çevrilir
        val nx = 1f - b.exactCenterX() / upW
        val ny = b.exactCenterY() / upH
        val nw = b.width().toFloat() / upW

        // FILL_CENTER: kadr ekrana sığışdırılıb kəsilir
        val scale = max(vw / upW, vh / upH)
        val vx = (nx * upW * scale + (vw - upW * scale) / 2f).coerceIn(0f, vw)
        val vy = (ny * upH * scale + (vh - upH * scale) / 2f).coerceIn(0f, vh)

        val now = SystemClock.elapsedRealtime()
        val moved = hypot(nx - lastNx, ny - lastNy)
        val sizeChange = abs(nw - lastNw) / max(lastNw, 0.01f)
        val needFocus = !faceFocused ||
            (now - lastFocusMs > 700 && (moved > 0.05f || sizeChange > 0.2f)) ||
            now - lastFocusMs > 3000
        if (needFocus) {
            val pt = preview.meteringPointFactory.createPoint(vx, vy)
            val action = FocusMeteringAction.Builder(
                pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
            ).disableAutoCancel().build()
            camera?.cameraControl?.startFocusAndMetering(action)
            faceFocused = true
            lastFocusMs = now
            lastNx = nx
            lastNy = ny
            lastNw = nw
        }
    }

    // ---------- Əllə fokus ----------

    private fun manualFocus(e: MotionEvent) {
        val cam = camera ?: return
        manualLock = true
        faceFocused = false
        val point = preview.meteringPointFactory.createPoint(e.x, e.y)
        val action = FocusMeteringAction.Builder(
            point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        ).disableAutoCancel().build()
        cam.cameraControl.startFocusAndMetering(action)
        showRing(e.rawX, e.rawY)
    }

    // Toxunma: əllə fokusu ləğv edir, yenidən sifətə avto fokus
    private fun autoFocus() {
        val wasManual = manualLock
        manualLock = false
        faceFocused = false
        camera?.cameraControl?.cancelFocusAndMetering()
        focusRing.animate().cancel()
        focusRing.visibility = View.GONE
        if (wasManual) Toast.makeText(this, "Avto fokus (sifət)", Toast.LENGTH_SHORT).show()
    }

    private fun showRing(rawX: Float, rawY: Float) {
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        focusRing.animate().cancel()
        focusRing.x = rawX - loc[0] - ringPx / 2f
        focusRing.y = rawY - loc[1] - ringPx / 2f
        focusRing.alpha = 1f
        focusRing.scaleX = 1.5f
        focusRing.scaleY = 1.5f
        focusRing.visibility = View.VISIBLE
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            focusRing.animate().alpha(0.5f).setStartDelay(1000).setDuration(400).start()
        }.start()
    }

    // ---------- Güzgü və işıq ----------

    private fun toggleReverse() {
        reversed = !reversed
        preview.scaleX = if (reversed) -1f else 1f
    }

    private fun toggleLight() {
        lightOn = !lightOn
        val d = resources.displayMetrics.density
        val m = ((if (lightOn) 64 else 0) * d).toInt()
        val bottom = m + if (lightOn) (40 * d).toInt() else 0
        val lp = holder.layoutParams as FrameLayout.LayoutParams
        lp.setMargins(m, m, m, bottom)
        holder.layoutParams = lp
        holder.invalidateOutline()
        root.setBackgroundColor(if (lightOn) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())

        val attrs = window.attributes
        attrs.screenBrightness =
            if (lightOn) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = attrs
    }
}
