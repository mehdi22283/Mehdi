package com.zengyazici;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Handler;
import android.os.Looper;
import java.net.InetAddress;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Wireless debugging xidmətlərini (mDNS) tapır: _adb-tls-connect._tcp və _adb-tls-pairing._tcp */
public class Nsd {
    public interface CB { void found(String host, int port); }

    public static class Handle {
        NsdManager m;
        NsdManager.DiscoveryListener l;
        volatile boolean stopped;
        public synchronized void stop() {
            if (stopped) return;
            stopped = true;
            try { m.stopServiceDiscovery(l); } catch (Throwable e) { }
        }
    }

    private static final Handler H = new Handler(Looper.getMainLooper());

    public static Handle watch(Context c, String type, boolean once, CB cb) {
        final NsdManager m = (NsdManager) c.getSystemService(Context.NSD_SERVICE);
        final Handle h = new Handle();
        h.m = m;
        h.l = new NsdManager.DiscoveryListener() {
            @Override public void onStartDiscoveryFailed(String t, int e) { RecService.log("mDNS start xətası " + e); }
            @Override public void onStopDiscoveryFailed(String t, int e) { }
            @Override public void onDiscoveryStarted(String t) { }
            @Override public void onDiscoveryStopped(String t) { }
            @Override public void onServiceFound(NsdServiceInfo si) { resolve(m, si, cb, h, once, 0); }
            @Override public void onServiceLost(NsdServiceInfo si) { }
        };
        try {
            m.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, h.l);
        } catch (Throwable e) {
            RecService.log("mDNS: " + e);
        }
        return h;
    }

    private static void resolve(final NsdManager m, final NsdServiceInfo si, final CB cb, final Handle h,
                                final boolean once, final int tries) {
        if (h.stopped) return;
        try {
            m.resolveService(si, new NsdManager.ResolveListener() {
                @Override public void onResolveFailed(NsdServiceInfo i, int e) {
                    if (tries < 6 && !h.stopped) {
                        H.postDelayed(() -> resolve(m, si, cb, h, once, tries + 1), 400);
                    }
                }
                @Override public void onServiceResolved(NsdServiceInfo i) {
                    InetAddress a = i.getHost();
                    cb.found(a == null ? "127.0.0.1" : a.getHostAddress(), i.getPort());
                    if (once) h.stop();
                }
            });
        } catch (Throwable e) {
            RecService.log("mDNS resolve: " + e);
        }
    }

    /** Bloklayan variant: [host, port] və ya null qaytarır. */
    public static String[] findOnce(Context c, String type, long ms) {
        final CountDownLatch lt = new CountDownLatch(1);
        final String[] r = new String[2];
        Handle h = watch(c, type, true, (host, port) -> {
            if (r[0] == null) { r[0] = host; r[1] = String.valueOf(port); }
            lt.countDown();
        });
        try { lt.await(ms, TimeUnit.MILLISECONDS); } catch (Exception e) { }
        h.stop();
        return r[0] == null ? null : r;
    }
}
