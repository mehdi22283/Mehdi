package az.mehdi.callrec

import android.accessibilityservice.AccessibilityService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class WaService : AccessibilityService() {
    private var active = false
    private var low = 0
    private val h = Handler(Looper.getMainLooper())

    private val poller = object : Runnable {
        override fun run() {
            if (!active) return
            val am = getSystemService(AudioManager::class.java)
            if (am.mode == AudioManager.MODE_IN_COMMUNICATION) low = 0 else low++
            if (low >= 3) {
                active = false; low = 0
                RecService.inst?.waStop()
            } else h.postDelayed(this, 1500)
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val cls = e.className?.toString() ?: return
        if (!cls.contains("voip", true) || active) return
        val texts = ArrayList<String>()
        rootInActiveWindow?.let { collect(it, texts, 0) }
        val inc = texts.any { Regex("(?i)answer|decline|cavab|rədd|ответ|отклон").containsMatchIn(it) }
        val name = texts.firstOrNull {
            it.length in 2..40 &&
            !Regex("[0-9]{1,2}:[0-9]{2}").containsMatchIn(it) &&
            !Regex("(?i)whatsapp|calling|ringing|end|mute|speaker|video|call|zəng|звон").containsMatchIn(it)
        } ?: ""
        active = true; low = 0
        RecService.inst?.waStart(name, inc)
        h.postDelayed(poller, 3000)
    }

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<String>, d: Int) {
        if (d > 8) return
        n.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until n.childCount) n.getChild(i)?.let { collect(it, out, d + 1) }
    }

    override fun onInterrupt() {}
}
