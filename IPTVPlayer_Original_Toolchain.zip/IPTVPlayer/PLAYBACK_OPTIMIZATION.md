# IPTV Player – sürətli açılış və şəbəkə sabitliyi

- VLC şəbəkə və canlı yayım keşləri 2 saniyədir: ilkin açılışı sürətləndirmək və qısa şəbəkə dalğalanmalarına bir qədər ehtiyat saxlamaq üçün balans.
- VLC-də gecikmiş kadrları zorla saxlama seçimi çıxarıldı; gecikmə yarananda pleyer kadrları ata bilər və canlı yayım daha axıcı qala bilər.
- Bufer dəyərləri MainActivity.kt-nin başında sabitlərdədir (EXO_*, VLC_*): Exo min 10 san, max 20 san, ilkin 2 san, rebufer 4 san; VLC network 1 san, live 0.5 san. Köhnə bufer kanal dəyişəndə dərhal atılır.
- HTTP bağlantı timeout-u 2.5 saniyə, oxuma timeout-u 4.5 saniyədir; cavab verməyən mənbədən daha tez alternativ pleyerə keçməyə kömək edir.
- Axın başlamasa və ya buffering uzun çəksə, 10 saniyədən sonra alternativ pleyerə keçid edilir.
- Sürətli kanal dəyişmələrində son seçim üstün tutulur; əvvəlki 350 ms gözləmə 100 ms edilib.
- Kanal dəyişmə nəsli ilə köhnə player hadisələri filtrlənir; HTTP reconnect aktivdir.

Qeyd: Daha qısa bufer ilk görüntünü tezləşdirə bilər, lakin zəif internetdə donma ehtimalını artıra bilər. Real nəticə IPTV mənbəyindən, kodekdən və bağlantıdan asılıdır. Android SDK/Gradle və canlı IPTV axınları ilə cihaz testi bu mühitdə aparılmayıb.

- Əsas pleyer ExoPlayer-dir (Media3 1.4.1). Kanal 7 saniyə içində açılmasa və ya xəta versə, avtomatik VLC (libVLC 3.6.0) ehtiyatına keçilir.
- Kanalın səsi ExoPlayer-də oxunmursa (dəstəklənməyən audio kodek), avtomatik VLC-yə keçilir.
- Kanalın səsi AAC-dirsə ExoPlayer ilə davam edir; AAC deyilsə və ya oxunmursa avtomatik VLC-yə keçilir.
