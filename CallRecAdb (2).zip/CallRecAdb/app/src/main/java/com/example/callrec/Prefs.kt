package com.example.callrec

import android.content.Context
import java.util.UUID

object Prefs {
    const val PORT = 28765
    private fun p(c: Context) = c.getSharedPreferences("callrec", Context.MODE_PRIVATE)
    fun token(c: Context): String = p(c).getString("t", null)
        ?: UUID.randomUUID().toString().also { p(c).edit().putString("t", it).apply() }
    fun paired(c: Context) = p(c).getBoolean("paired", false)
    fun setPaired(c: Context) = p(c).edit().putBoolean("paired", true).apply()
}
