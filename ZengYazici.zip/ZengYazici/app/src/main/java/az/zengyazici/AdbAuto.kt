package az.zengyazici

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput

/** Shizuku olmadan: tətbiq özü Wireless ADB-yə qoşulur və bütün quraşdırmanı edir. */
object AdbAuto {
    @Volatile var logger: ((String) -> Unit)? = null
    @Volatile var pairPort = -1
    @Volatile private var starting = false
    private var nsd: NsdManager? = null
    private var discovery: NsdManager.DiscoveryListener? = null

    const val CH_PAIR = "pair"
    const val ID_PAIR = 10
    const val ID_RESULT = 11
    const val KEY_CODE = "code"

    fun log(m: String) { logger?.invoke(m) }

    /** WRITE_SECURE_SETTINGS verilibsə, Wireless debugging-i özü yandırır. */
    fun enableWirelessDebugging(ctx: Context): Boolean = try {
        Settings.Global.putInt(ctx.contentResolver, "adb_wifi_enabled", 1); true
    } catch (e: Exception) { false }

    fun connect(ctx: Context, tries: Int = 1): Boolean {
        for (i in 0 until tries) {
            try {
                val m = AdbManager.get(ctx)
                if (m.isConnected || m.autoConnect(ctx, 5000L)) return true
            } catch (e: Throwable) { log("Qoşulma: ${e.message}") }
            if (i < tries - 1) Thread.sleep(3000)
        }
        return false
    }

    fun sh(ctx: Context, cmd: String): String = AdbManager.get(ctx).run(cmd)

    /** İcazələr + arxa fon + əlçatanlıq + tətbiqi avtomatik başlat. */
    fun finishSetup(ctx: Context) {
        val p = ctx.packageName
        val cmds = listOf(
            "pm grant $p android.permission.RECORD_AUDIO",
            "pm grant $p android.permission.READ_PHONE_STATE",
            "pm grant $p android.permission.POST_NOTIFICATIONS",
            "pm grant $p android.permission.WRITE_SECURE_SETTINGS",
            "dumpsys deviceidle whitelist +$p",
            "appops set $p RUN_ANY_IN_BACKGROUND allow",
            "appops set $p RUN_IN_BACKGROUND allow"
        )
        for (c in cmds) {
            val out = try { sh(ctx, c).trim() } catch (e: Throwable) { "xəta: ${e.message}" }
            log("$c → ${if (out.isEmpty()) "OK" else out.take(80)}")
        }
        try {
            val comp = "$p/$p.WhatsAppWatcherService"
            val cur = sh(ctx, "settings get secure enabled_accessibility_services").trim()
            if (!cur.contains(comp)) {
                val nv = if (cur.isEmpty() || cur == "null") comp else "$cur:$comp"
                sh(ctx, "settings put secure enabled_accessibility_services $nv")
            }
            sh(ctx, "settings put secure accessibility_enabled 1")
            log("Əlçatanlıq xidməti aktiv edildi")
        } catch (e: Throwable) { log("Əlçatanlıq: ${e.message}") }
        try {
            sh(ctx, "am start -n $p/.MainActivity --ez autostart true")
            log("Xidmət başladılır…")
        } catch (e: Throwable) { log("Başlatma: ${e.message}") }
        notifyResult(ctx, "Quraşdırma tamamlandı. Zəng Yazıcı işə düşür.")
    }

    // ---------- Cihaz yenidən başlayanda / xidmət bağlananda avtomatik bərpa ----------
    fun bootstrap(ctx: Context) {
        if (RecorderService.running || starting) return
        if (ctx.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) != PackageManager.PERMISSION_GRANTED) return
        starting = true
        Thread {
            try {
                enableWirelessDebugging(ctx)
                if (connect(ctx, 12)) {
                    sh(ctx, "am start -n ${ctx.packageName}/.MainActivity --ez autostart true")
                    try { AdbManager.get(ctx).disconnect() } catch (e: Throwable) { }
                }
            } catch (e: Throwable) { } finally { starting = false }
        }.start()
    }

    // ---------- İlk dəfə cütləşmə ----------
    fun startPairing(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_PAIR, "ADB cütləşmə", NotificationManager.IMPORTANCE_HIGH))
        postPairNotification(ctx, "Pairing xidməti axtarılır… “Pair device with pairing code” pəncərəsini açın")
        stopDiscovery()
        val mgr = ctx.getSystemService(NsdManager::class.java)
        nsd = mgr
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) { log("NSD xətası $e") }
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onServiceLost(s: NsdServiceInfo) { pairPort = -1 }
            override fun onServiceFound(s: NsdServiceInfo) {
                mgr.resolveService(s, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(si: NsdServiceInfo, e: Int) {}
                    override fun onServiceResolved(si: NsdServiceInfo) {
                        pairPort = si.port
                        log("Pairing portu tapıldı: ${si.port}")
                        postPairNotification(ctx, "Pairing pəncərəsindəki 6 rəqəmli kodu aşağıya yazın")
                    }
                })
            }
        }
        discovery = l
        mgr.discoverServices("_adb-tls-pairing._tcp", NsdManager.PROTOCOL_DNS_SD, l)
    }

    private fun stopDiscovery() {
        try { discovery?.let { nsd?.stopServiceDiscovery(it) } } catch (e: Exception) { }
        discovery = null
    }

    private fun postPairNotification(ctx: Context, text: String) {
        val ri = RemoteInput.Builder(KEY_CODE).setLabel("6 rəqəmli kod").build()
        val pi = PendingIntent.getBroadcast(
            ctx, 0, Intent(ctx, PairReceiver::class.java).setPackage(ctx.packageName),
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val action = NotificationCompat.Action.Builder(android.R.drawable.ic_menu_edit, "Kodu yaz", pi)
            .addRemoteInput(ri).build()
        val n = NotificationCompat.Builder(ctx, CH_PAIR)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ADB cütləşməsi")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .addAction(action)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_PAIR, n)
    }

    fun notifyResult(ctx: Context, text: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.cancel(ID_PAIR)
        nm.notify(ID_RESULT, NotificationCompat.Builder(ctx, CH_PAIR)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ADB").setContentText(text).setAutoCancel(true).build())
    }

    fun pairAndFinish(ctx: Context, code: String) {
        if (pairPort < 0) { notifyResult(ctx, "Pairing portu tapılmadı. Pairing pəncərəsi açıq olmalıdır."); postPairNotification(ctx, "Yenidən cəhd edin"); return }
        try {
            val ok = AdbManager.get(ctx).pair("127.0.0.1", pairPort, code.trim())
            log(if (ok) "Cütləşdi" else "Cütləşmə alınmadı")
            if (!ok) { postPairNotification(ctx, "Kod səhvdir, yenidən yazın"); return }
        } catch (e: Throwable) {
            log("Cütləşmə xətası: ${e.message}")
            postPairNotification(ctx, "Xəta: ${e.message}. Yenidən cəhd edin"); return
        }
        stopDiscovery()
        if (connect(ctx, 6)) finishSetup(ctx)
        else notifyResult(ctx, "Cütləşdi, amma qoşulmaq alınmadı. Wireless debugging açıq və Wi-Fi qoşulu olmalıdır.")
    }
}
