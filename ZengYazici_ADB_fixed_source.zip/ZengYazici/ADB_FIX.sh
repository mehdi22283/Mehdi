#!/usr/bin/env sh
set -eu
adb get-state >/dev/null
echo 'Zəng Yazıcı icazələri verilir...'
adb shell pm grant com.zengyazici android.permission.RECORD_AUDIO
adb shell pm grant com.zengyazici android.permission.READ_PHONE_STATE
adb shell pm grant com.zengyazici android.permission.READ_CALL_LOG
adb shell pm grant com.zengyazici android.permission.POST_NOTIFICATIONS || true
adb shell appops set com.zengyazici RECORD_AUDIO allow
adb shell appops set com.zengyazici SYSTEM_ALERT_WINDOW allow
adb shell appops set com.zengyazici RUN_IN_BACKGROUND allow
adb shell appops set com.zengyazici RUN_ANY_IN_BACKGROUND allow
adb shell dumpsys deviceidle whitelist +com.zengyazici
adb shell cmd notification allow_listener com.zengyazici/com.zengyazici.WaListener || true
adb shell am force-stop com.zengyazici
adb shell monkey -p com.zengyazici 1
echo 'Bitdi. WhatsApp-da sınaq zəngi edin, sonra tətbiqdə Menyu > Log bölməsinə baxın.'
