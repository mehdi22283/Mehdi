package az.m3u.sinayici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import org.json.JSONArray
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Arxa fonda kanalları dövri yoxlayır. Əvvəl işləyən kanal işləməyi dayandırarsa bildiriş göndərir.
 * Kanal siyahısı tətbiqdən filesDir/monitored.json faylına yazılır.
 */
class MonitorService : Service() {
    companion object {
        const val CH_ALERT = "alerts"
        const val CH_STATE = "monitor"

        fun start(c: Context) {
            val i = Intent(c, MonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }

        fun stop(c: Context) { c.stopService(Intent(c, MonitorService::class.java)) }
    }

    private val lock = Object()
    @Volatile private var alive = false
    private var worker: Thread? = null
    private val state = HashMap<String, Boolean>()   // url -> işləyir?
    private var nid = 100

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Kanal xəbərdarlıqları", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel(CH_STATE, "Kanal monitorinqi", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun builder(ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun stateNotif(text: String): Notification =
        builder(CH_STATE).setSmallIcon(R.drawable.ic_notif).setContentTitle("M3U Sınayıcı")
            .setContentText(text).setOngoing(true).setContentIntent(openAppIntent()).build()

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val n = stateNotif("Kanallar izlənir")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(1, n)
        if (!alive) {
            alive = true
            worker = Thread { loop() }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        synchronized(lock) { lock.notifyAll() }
        super.onDestroy()
    }

    private fun items(): List<QItem> {
        val f = File(filesDir, "monitored.json")
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            val seen = HashSet<String>()
            val out = ArrayList<QItem>()
            for (k in 0 until arr.length()) {
                val a = arr.getJSONArray(k)
                val url = a.getString(1)
                if (url.isNotBlank() && seen.add(url)) out.add(QItem(a.getString(0), url, a.optJSONObject(2)?.toString() ?: "{}"))
            }
            out
        } catch (e: Exception) { emptyList() }
    }

    private fun sleep(ms: Long) {
        synchronized(lock) { if (alive) try { lock.wait(ms) } catch (e: InterruptedException) { } }
    }

    private fun loop() {
        val pool = Executors.newFixedThreadPool(12)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        try {
            while (alive) {
                val list = items()
                if (list.isEmpty()) { sleep(15_000); continue }
                val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "m3u:monitor")
                wl.acquire(20 * 60 * 1000L)
                try { cycle(pool, list) } catch (e: Exception) { } finally { if (wl.isHeld) wl.release() }
                val min = getSharedPreferences("m3u", MODE_PRIVATE).getInt("monitorMin", 5).coerceAtLeast(1)
                sleep(min * 60_000L)
            }
        } finally { pool.shutdownNow() }
    }

    private fun cycle(pool: ExecutorService, list: List<QItem>) {
        val res = ConcurrentHashMap<String, Boolean>()
        list.map { q -> pool.submit(Runnable { res[q.url] = Net.probe(q.url, q.hdr) == "ok" }) }
            .forEach { try { it.get() } catch (e: Exception) { } }
        if (!alive) return

        // ok -> dead: yanlış həyəcanın qarşısını almaq üçün bir də yoxlayırıq
        val suspects = list.filter { state[it.url] == true && res[it.url] == false }
        if (suspects.isNotEmpty()) {
            sleep(15_000)
            suspects.map { q -> pool.submit(Runnable { if (Net.probe(q.url, q.hdr) == "ok") res[q.url] = true }) }
                .forEach { try { it.get() } catch (e: Exception) { } }
        }
        val died = suspects.filter { res[it.url] == false }

        for (q in list) res[q.url]?.let { state[q.url] = it }
        state.keys.retainAll(list.map { it.url }.toSet())

        if (died.isNotEmpty()) alert(died)
        val ok = state.values.count { it }
        getSystemService(NotificationManager::class.java)
            .notify(1, stateNotif("Kanallar izlənir: $ok/${list.size} işləyir"))
    }

    private fun alert(dead: List<QItem>) {
        val nm = getSystemService(NotificationManager::class.java)
        val pi = openAppIntent()
        fun post(title: String, text: String, big: String? = null) {
            val b = builder(CH_ALERT).setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(text)
                .setContentIntent(pi).setAutoCancel(true)
            if (big != null) b.setStyle(Notification.BigTextStyle().bigText(big))
            if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
            if (nid > 5000) nid = 100
            nm.notify(nid++, b.build())
        }
        if (dead.size <= 3) dead.forEach { post("❌ Kanal işləmir", "${it.name} işləməyi dayandırdı") }
        else post("❌ ${dead.size} kanal işləməyi dayandırdı",
            dead.take(5).joinToString(", ") { it.name } + if (dead.size > 5) "…" else "",
            dead.take(30).joinToString("\n") { "• " + it.name } + if (dead.size > 30) "\n…" else "")
    }
}
