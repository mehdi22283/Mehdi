package az.yvok.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;

import java.io.IOException;
import java.io.InputStream;

/**
 * OCR üçün şəkli yükləyir (EXIF-ə görə düzgün çevirir) və ağ-qara "sənəd" filteri tətbiq edir:
 * Clarity 100, Contrast 100, Sharpness 100 (bax: enhance).
 */
final class OcrImage {
    private static final int MAX_SIDE = 6000;          // uzun tərəf bundan böyük olmasın
    private static final long MAX_PIXELS = 16_000_000L; // yaddaş qoruyucusu

    private OcrImage() { }

    /** Şəkli yükləyir, EXIF-ə görə düzgün çevirir və lazım olsa kiçildir. */
    static Bitmap load(Context c, Uri uri) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, o);
        }
        int w0 = o.outWidth, h0 = o.outHeight;
        if (w0 <= 0 || h0 <= 0) throw new IOException("şəkil oxunmadı");

        int sample = 1;
        while (Math.max(w0, h0) / (sample * 2) >= MAX_SIDE) sample *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = sample;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        o.inMutable = true;
        Bitmap bmp;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            bmp = BitmapFactory.decodeStream(in, null, o);
        }
        if (bmp == null) throw new IOException("şəkil açılmadı");

        // EXIF çevrilməsi
        int orient = ExifInterface.ORIENTATION_NORMAL;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in != null) orient = new ExifInterface(in).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
        } catch (Exception ignored) { }
        Matrix m = new Matrix();
        switch (orient) {
            case ExifInterface.ORIENTATION_ROTATE_90: m.postRotate(90); break;
            case ExifInterface.ORIENTATION_ROTATE_180: m.postRotate(180); break;
            case ExifInterface.ORIENTATION_ROTATE_270: m.postRotate(270); break;
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_FLIP_VERTICAL: m.postScale(1, -1); break;
            case ExifInterface.ORIENTATION_TRANSPOSE: m.postRotate(90); m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_TRANSVERSE: m.postRotate(270); m.postScale(-1, 1); break;
            default: break;
        }
        // Kiçiltmə (ölçü həddi)
        float scale = 1f;
        int w = bmp.getWidth(), h = bmp.getHeight();
        int maxSide = Math.max(w, h);
        if (maxSide > MAX_SIDE) scale = Math.min(scale, (float) MAX_SIDE / maxSide);
        if ((long) w * h > MAX_PIXELS) scale = Math.min(scale, (float) Math.sqrt((double) MAX_PIXELS / ((double) w * h)));
        if (scale < 1f) m.postScale(scale, scale);

        if (!m.isIdentity()) {
            Bitmap t = Bitmap.createBitmap(bmp, 0, 0, w, h, m, true);
            if (t != bmp) bmp.recycle();
            bmp = t;
        }
        return bmp;
    }


    /** Şəkli yükləyir və ağ-qara + Clarity/Contrast/Sharpness 100 filterini tətbiq edir. */
    static Bitmap loadEnhanced(Context c, Uri uri) throws IOException {
        return enhance(load(c, uri));
    }

    /**
     * Ağ-qara filter (Xiaomi "sənəd" filtrinin nümunə nəticəsinə görə kalibrlənib: fon ağ, mətn qara, boz zolaqlar oxunaqlı qalır).
     * 1) boz tona çevirmə; 2) Clarity: böyük radiuslu yerli kontrast (0.6); 3) Contrast: orta tondan 1.5 dəfə uzaqlaşdırma;
     * 4) Sharpness: kiçik radiuslu yüngül kəskinləşdirmə (0.3). Şəkil yerindəcə dəyişir (yaddaş qənaəti); mutable deyilsə kopyalanır.
     */
    static Bitmap enhance(Bitmap src) {
        Bitmap b = src;
        if (!b.isMutable() || b.getConfig() != Bitmap.Config.ARGB_8888) {
            b = src.copy(Bitmap.Config.ARGB_8888, true);
            if (b == null) return src;
            src.recycle();
        }
        final int w = b.getWidth(), h = b.getHeight();
        byte[] lum = new byte[w * h];
        final int chunk = 128;
        int[] buf = new int[w * chunk];
        for (int y = 0; y < h; y += chunk) {
            int rows = Math.min(chunk, h - y);
            b.getPixels(buf, 0, w, 0, y, w, rows);
            for (int i = 0, n = w * rows; i < n; i++) {
                int p = buf[i];
                int g = (((p >> 16) & 255) * 299 + ((p >> 8) & 255) * 587 + (p & 255) * 114) / 1000;
                lum[y * w + i] = (byte) g;
            }
        }

        // Clarity: böyük radiuslu yerli kontrast
        int rc = Math.max(10, Math.min(60, Math.max(w, h) / 80));
        byte[] blur = boxBlur(lum, w, h, rc);
        for (int i = 0; i < lum.length; i++) {
            int v = lum[i] & 255, bl = blur[i] & 255;
            lum[i] = clamp(v + (int) (0.6f * (v - bl)));
        }
        blur = null;

        // Contrast: orta tondan 1.5 dəfə uzaqlaşdırma (fon ağarır, mətn qaralır)
        for (int i = 0; i < lum.length; i++) {
            int v = lum[i] & 255;
            lum[i] = clamp((v - 128) * 3 / 2 + 128);
        }

        // Sharpness: kiçik radiuslu unsharp mask
        blur = boxBlur(lum, w, h, 2);
        for (int i = 0; i < lum.length; i++) {
            int v = lum[i] & 255, bl = blur[i] & 255;
            lum[i] = clamp(v + (int) (0.3f * (v - bl)));
        }
        blur = null;

        for (int y = 0; y < h; y += chunk) {
            int rows = Math.min(chunk, h - y);
            for (int i = 0, n = w * rows; i < n; i++) {
                int v = lum[y * w + i] & 255;
                buf[i] = 0xFF000000 | (v << 16) | (v << 8) | v;
            }
            b.setPixels(buf, 0, w, 0, y, w, rows);
        }
        return b;
    }

    private static byte clamp(int v) {
        return (byte) (v < 0 ? 0 : v > 255 ? 255 : v);
    }

    /** Ayrılan (separable) box blur, kənarlar təkrarlanır. */
    private static byte[] boxBlur(byte[] src, int w, int h, int r) {
        final int win = 2 * r + 1;
        byte[] tmp = new byte[src.length];
        for (int y = 0; y < h; y++) {
            int base = y * w;
            int sum = 0;
            for (int k = -r; k <= r; k++) sum += src[base + Math.min(w - 1, Math.max(0, k))] & 255;
            for (int x = 0; x < w; x++) {
                tmp[base + x] = (byte) (sum / win);
                sum += (src[base + Math.min(w - 1, x + r + 1)] & 255) - (src[base + Math.max(0, x - r)] & 255);
            }
        }
        byte[] out = new byte[src.length];
        int[] sums = new int[w];
        for (int k = -r; k <= r; k++) {
            int base = Math.min(h - 1, Math.max(0, k)) * w;
            for (int x = 0; x < w; x++) sums[x] += tmp[base + x] & 255;
        }
        for (int y = 0; y < h; y++) {
            int base = y * w;
            for (int x = 0; x < w; x++) out[base + x] = (byte) (sums[x] / win);
            int add = Math.min(h - 1, y + r + 1) * w, rem = Math.max(0, y - r) * w;
            for (int x = 0; x < w; x++) sums[x] += (tmp[add + x] & 255) - (tmp[rem + x] & 255);
        }
        return out;
    }


    /** Şəkli saat əqrəbi istiqamətində verilən bucaq qədər çevirir (90/180/270). */
    static Bitmap rotate(Bitmap src, int deg) {
        if (deg % 360 == 0) return src;
        Matrix m = new Matrix();
        m.postRotate(deg);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
    }
}
