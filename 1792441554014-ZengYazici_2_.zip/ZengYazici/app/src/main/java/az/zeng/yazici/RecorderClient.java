package az.zeng.yazici;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import rikka.shizuku.Shizuku;

/** Tətbiq tərəfi: Shizuku vasitəsilə shell prosesinə qoşulur və yazını başladıb/bitirir. */
public final class RecorderClient {
    public interface Action {
        void run(IRecorder r) throws Exception;
    }

    public interface Done {
        void done(Throwable err);
    }

    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static final List<Runnable> waiters = new ArrayList<>();
    private static IRecorder svc;
    private static boolean binding, listenerAdded;

    private static final Shizuku.UserServiceArgs ARGS = new Shizuku.UserServiceArgs(
            new ComponentName("az.zeng.yazici", RecorderService.class.getName()))
            .daemon(true)
            .processNameSuffix("rec")
            .version(1);

    private static final ServiceConnection CONN = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName n, IBinder b) {
            List<Runnable> w;
            synchronized (RecorderClient.class) {
                svc = IRecorder.Stub.asInterface(b);
                binding = false;
                w = new ArrayList<>(waiters);
                waiters.clear();
            }
            for (Runnable r : w) EX.execute(r);
        }

        @Override
        public void onServiceDisconnected(ComponentName n) {
            synchronized (RecorderClient.class) {
                svc = null;
                binding = false;
            }
        }
    };

    private RecorderClient() {
    }

    /** Əməliyyatı shell xidməti üzərində icra edir; done həmişə əsas threaddə çağırılır. */
    public static void run(final Action a, final Done d) {
        final AtomicBoolean fin = new AtomicBoolean();
        final Runnable job = () -> {
            if (!fin.compareAndSet(false, true)) return;
            Throwable err = null;
            try {
                a.run(svc);
            } catch (Throwable t) {
                err = t;
            }
            final Throwable e = err;
            UI.post(() -> {
                if (d != null) d.done(e);
            });
        };
        UI.postDelayed(() -> {
            if (fin.compareAndSet(false, true)) {
                synchronized (RecorderClient.class) {
                    waiters.remove(job);
                }
                if (d != null)
                    d.done(new IllegalStateException("Shizuku xidməti qoşulmadı (Shizuku işləyir və icazə verilib?)"));
            }
        }, 9000);
        UI.post(() -> ensureBound(job));
    }

    private static void ensureBound(Runnable job) {
        synchronized (RecorderClient.class) {
            if (svc != null && svc.asBinder().pingBinder()) {
                EX.execute(job);
                return;
            }
            svc = null;
            waiters.add(job);
            if (binding) return;
        }
        if (!listenerAdded) {
            listenerAdded = true;
            Shizuku.addBinderReceivedListenerSticky(RecorderClient::bindNow);
        } else if (Shizuku.pingBinder()) {
            bindNow();
        }
    }

    private static void bindNow() {
        synchronized (RecorderClient.class) {
            if (binding || svc != null) return;
            binding = true;
        }
        try {
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                synchronized (RecorderClient.class) {
                    binding = false;
                }
                return;
            }
            Shizuku.bindUserService(ARGS, CONN);
        } catch (Throwable t) {
            synchronized (RecorderClient.class) {
                binding = false;
            }
        }
    }

    /** Yazını başladır (artıq aktivdirsə heç nə etmir). */
    public static void begin(Context c, String src, String dir, String label, Runnable after) {
        final Context a = c.getApplicationContext();
        final SharedPreferences p = a.getSharedPreferences("st", 0);
        final String path;
        synchronized (RecorderClient.class) {
            if (p.getBoolean("active", false) && System.currentTimeMillis() - p.getLong("t", 0) < 4 * 3600_000L) {
                if (after != null) after.run();
                return;
            }
            File[] dirs = a.getExternalMediaDirs();
            File d = (dirs != null && dirs.length > 0 && dirs[0] != null) ? dirs[0] : a.getExternalFilesDir(null);
            d.mkdirs();
            String name = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date())
                    + "__" + src + "__" + dir + "__" + safe(label) + ".wav";
            path = new File(d, name).getAbsolutePath();
            p.edit().putBoolean("active", true).putLong("t", System.currentTimeMillis())
                    .putString("src", src).putString("dir", dir).putString("label", label)
                    .putString("path", path).commit();
        }
        final int mode = src.equals("ph") ? p.getInt("ph_mode", 0) : 1;
        Notif.recording(a, src, dir, label);
        run(r -> {
            if (!r.start(path, mode)) throw new Exception(lastLine(r.getLog()));
        }, err -> {
            if (err != null) {
                p.edit().putBoolean("active", false).apply();
                Notif.cancelRec(a);
                Notif.error(a, String.valueOf(err.getMessage()));
            }
            if (after != null) after.run();
        });
    }

    /** Yazını bitirir. src==null olarsa istənilən aktiv yazı dayandırılır. */
    public static void end(Context c, String src, Runnable after) {
        final Context a = c.getApplicationContext();
        final SharedPreferences p = a.getSharedPreferences("st", 0);
        final String asrc, dir, label;
        synchronized (RecorderClient.class) {
            if (!p.getBoolean("active", false) || (src != null && !src.equals(p.getString("src", "")))) {
                if (after != null) after.run();
                return;
            }
            asrc = p.getString("src", "ph");
            dir = p.getString("dir", "in");
            label = p.getString("label", "");
            p.edit().putBoolean("active", false).commit();
        }
        final long[] ms = new long[1];
        run(r -> ms[0] = r.stop(), err -> {
            Notif.cancelRec(a);
            Notif.saved(a, asrc, dir, label, ms[0], err);
            if (after != null) after.run();
        });
    }

    static String safe(String s) {
        if (s == null || s.trim().isEmpty()) return "Namelum";
        String r = s.trim().replaceAll("[^\\p{L}\\p{N}+\\-]", "_").replaceAll("_+", "_");
        return r.length() > 40 ? r.substring(0, 40) : r;
    }

    private static String lastLine(String log) {
        if (log == null) return "naməlum xəta";
        String[] ls = log.trim().split("\n");
        return ls.length == 0 ? "naməlum xəta" : ls[ls.length - 1];
    }
}
