package az.zeng.yazici;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;

final class Notif {
    static final String CH_REC = "rec2", CH_SAVED = "saved";
    static final int ID_REC = 1001, ID_SAVED = 1002;

    private Notif() {
    }

    static void init(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel a = new NotificationChannel(CH_REC, "Zəng yazılır", NotificationManager.IMPORTANCE_HIGH);
        a.setSound(null, null);
        a.enableVibration(false);
        NotificationChannel b = new NotificationChannel(CH_SAVED, "Yazının nəticəsi", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(a);
        nm.createNotificationChannel(b);
    }

    static String srcName(String src) {
        return "wa".equals(src) ? "WhatsApp" : "Telefon";
    }

    static String dirName(String dir) {
        return "in".equals(dir) ? "Gələn" : "Gedən";
    }

    private static PendingIntent open(Context c) {
        return PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Yazı gedərkən heads-up bildiriş (sayğaclı, "Dayandır" düyməsi ilə). */
    static void recording(Context c, String src, String dir, String label) {
        init(c);
        PendingIntent stop = PendingIntent.getBroadcast(c, 1, new Intent(c, StopReceiver.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(c, CH_REC)
                .setSmallIcon(R.drawable.ic_rec)
                .setContentTitle("● Zəng yazılır")
                .setContentText(srcName(src) + " · " + dirName(dir) + " · " + label)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_STATUS)
                .setColor(0xFFE53935)
                .setContentIntent(open(c))
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .setUsesChronometer(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(c, R.drawable.ic_rec), "Dayandır", stop).build());
        c.getSystemService(NotificationManager.class).notify(ID_REC, b.build());
    }

    static void cancelRec(Context c) {
        c.getSystemService(NotificationManager.class).cancel(ID_REC);
    }

    static void saved(Context c, String src, String dir, String label, long ms, Throwable err) {
        init(c);
        long s = ms / 1000;
        String text = err == null
                ? srcName(src) + " · " + dirName(dir) + " · " + label + " · " + s / 60 + ":" + String.format("%02d", s % 60)
                : "Yazı düzgün bağlanmadı: " + err.getMessage();
        Notification.Builder b = new Notification.Builder(c, CH_SAVED)
                .setSmallIcon(R.drawable.ic_rec)
                .setContentTitle(err == null ? "Yazı saxlanıldı" : "Yazı xətası")
                .setContentText(text)
                .setContentIntent(open(c))
                .setAutoCancel(true)
                .setTimeoutAfter(10000);
        c.getSystemService(NotificationManager.class).notify(ID_SAVED, b.build());
    }

    static void error(Context c, String msg) {
        init(c);
        Notification.Builder b = new Notification.Builder(c, CH_SAVED)
                .setSmallIcon(R.drawable.ic_rec)
                .setContentTitle("Yazı başlamadı")
                .setContentText(msg)
                .setStyle(new Notification.BigTextStyle().bigText(msg))
                .setContentIntent(open(c))
                .setAutoCancel(true);
        c.getSystemService(NotificationManager.class).notify(ID_SAVED, b.build());
    }
}
