package az.wifiscan

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import java.net.*
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicInteger

class Scanner(
    private val ctx: Context,
    private val onUpdate: () -> Unit,
    private val onProgress: (Int, Int, Int) -> Unit,
    private val onDone: () -> Unit
) {
    @Volatile private var cancelled = false
    @Volatile private var pool: ExecutorService? = null
    private var base = 0
    private var mask = 0
    private var selfIp = ""
    private val extra = ConcurrentLinkedQueue<Thread>()

    fun cancel() { cancelled = true; pool?.shutdownNow() }

    fun start(ip: String, prefix: Int, gw: String) { Thread { run(ip, prefix, gw) }.start() }

    private fun inRange(ip: String) = try { (Net.toInt(ip) and mask) == base } catch (e: Exception) { false }

    private fun run(ip: String, prefix: Int, gw: String) {
        Oui.load(ctx)
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wm.createMulticastLock("wifiskan").apply { setReferenceCounted(false); acquire() }
        try {
            val p = prefix.coerceIn(22, 30)
            mask = -1 shl (32 - p); base = Net.toInt(ip) and mask; selfIp = ip
            val n = (1 shl (32 - p)) - 2
            val self = Device(ip).apply {
                isSelf = true; name = Build.MODEL; vendor = Build.MANUFACTURER
                model = "${Build.MANUFACTURER} ${Build.MODEL}"; isGateway = (ip == gw)
            }
            Net.classify(self); Store.devices[ip] = self; onUpdate()

            // Kəşf mənbələri: SSDP + mDNS (2.4G/5G fərqi yoxdur, hamısı eyni LAN-dadır)
            val helpers = listOf(Thread { ssdp(gw) }, Thread { mdns(gw) })
            helpers.forEach { it.start() }
            if (gw.isNotEmpty()) discovered(gw, gw)

            val hosts = (1..n).map { Net.fromInt(base + it) }.filter { it != ip }
            val missed = ConcurrentLinkedQueue<String>()
            pass(1, hosts, false, gw, missed)
            if (!cancelled) pass(2, missed.toList(), true, gw, null)

            helpers.forEach { it.join(12000) }
            while (true) { val t = extra.poll() ?: break; t.join(60000) }
        } catch (e: Throwable) {
        } finally { lock.release(); pool = null; onDone() }
    }

    private fun pass(no: Int, hosts: List<String>, deep: Boolean, gw: String, missed: ConcurrentLinkedQueue<String>?) {
        val ex = Executors.newFixedThreadPool(96); pool = ex
        val done = AtomicInteger(0); val total = hosts.size
        for (h in hosts) ex.execute {
            try {
                if (!cancelled && !Store.devices.containsKey(h)) {
                    if (!probe(h, gw, deep, false)) missed?.add(h)
                }
            } catch (e: Throwable) {}
            onProgress(no, done.incrementAndGet(), total)
        }
        ex.shutdown(); ex.awaitTermination(10, TimeUnit.MINUTES)
    }

    private fun discovered(ip: String, gw: String) {
        if (cancelled || ip == selfIp || !inRange(ip) || Store.devices.containsKey(ip)) return
        val t = Thread { try { probe(ip, gw, false, true) } catch (e: Throwable) {} }
        extra.add(t); t.start()
    }

    private fun probe(h: String, gw: String, deep: Boolean, force: Boolean): Boolean {
        if (Store.devices.containsKey(h)) return true
        var mac = Net.arp(h)
        if (!force) {
            val up = if (deep) Net.aliveDeep(h) else Net.alive(h)
            if (!up && mac.isEmpty()) return false
        }
        val d = Device(h)
        d.isGateway = h == gw
        d.mac = mac; d.vendor = Oui.vendor(mac); d.randomMac = Oui.isRandom(mac)
        if (Store.devices.putIfAbsent(h, d) != null) return true
        Net.classify(d); onUpdate()

        val ex = Executors.newFixedThreadPool(24)
        for (port in Net.PORTS.keys) ex.execute { if (!cancelled && Net.open(h, port)) { d.ports.add(port); Net.classify(d); onUpdate() } }
        ex.shutdown(); ex.awaitTermination(40, TimeUnit.SECONDS)

        if (mac.isEmpty()) {
            mac = Net.arp(h)
            if (mac.isNotEmpty()) { d.mac = mac; d.vendor = Oui.vendor(mac); d.randomMac = Oui.isRandom(mac) }
        }
        Net.classify(d); onUpdate()

        val nm = Net.netbios(h).ifEmpty { Store.mdns[h] ?: "" }.ifEmpty { Net.dns(h) }
        if (nm.isNotEmpty()) d.name = nm
        Net.classify(d); onUpdate()

        val hp = listOf(80, 8080, 8000, 81, 8081, 8090, 5000).firstOrNull { it in d.ports }
        if (hp != null) d.http = Net.http(h, hp)
        for (bp in intArrayOf(21, 22, 23)) if (bp in d.ports) { val b = Net.banner(h, bp); if (b.isNotEmpty()) d.banners[bp] = b }
        Net.classify(d); onUpdate()

        if (!cancelled) { try { VulnCheck.run(d) } catch (e: Throwable) {}; onUpdate() }
        return true
    }

    private fun ssdp(gw: String) {
        try {
            val s = DatagramSocket(); s.soTimeout = 700
            val msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n".toByteArray()
            val grp = InetAddress.getByName("239.255.255.250")
            val end = System.currentTimeMillis() + 9000
            val seen = HashSet<String>()
            var last = 0L
            val buf = ByteArray(4096)
            while (System.currentTimeMillis() < end && !cancelled) {
                if (System.currentTimeMillis() - last > 2500) {
                    s.send(DatagramPacket(msg, msg.size, grp, 1900)); last = System.currentTimeMillis()
                }
                try {
                    val pk = DatagramPacket(buf, buf.size); s.receive(pk)
                    val txt = String(pk.data, 0, pk.length)
                    val ip = pk.address.hostAddress ?: continue
                    discovered(ip, gw)
                    val loc = Regex("(?i)location:\\s*(\\S+)").find(txt)?.groupValues?.get(1) ?: continue
                    val srv = Regex("(?i)server:\\s*(.+)").find(txt)?.groupValues?.get(1)?.trim() ?: ""
                    if (!seen.add(loc)) continue
                    Thread { fetchDesc(ip, loc, srv) }.start()
                } catch (e: SocketTimeoutException) {}
            }
            s.close()
        } catch (e: Throwable) {}
    }

    private fun mdns(gw: String) {
        try {
            val s = DatagramSocket(); s.soTimeout = 700
            val names = listOf("_services._dns-sd._udp", "_googlecast._tcp", "_airplay._tcp", "_http._tcp", "_workstation._tcp",
                "_ipp._tcp", "_companion-link._tcp", "_hap._tcp", "_spotify-connect._tcp", "_smb._tcp", "_device-info._tcp", "_apple-mobdev2._tcp")
            val bo = java.io.ByteArrayOutputStream()
            bo.write(byteArrayOf(0, 0, 0, 0, 0, names.size.toByte(), 0, 0, 0, 0, 0, 0))
            for (nm in names) {
                for (lab in (nm + ".local").split(".")) { bo.write(lab.length); bo.write(lab.toByteArray()) }
                bo.write(0); bo.write(byteArrayOf(0, 12, 0x80.toByte(), 1))
            }
            val q = bo.toByteArray(); val grp = InetAddress.getByName("224.0.0.251")
            val end = System.currentTimeMillis() + 9000
            var last = 0L
            val buf = ByteArray(8192)
            while (System.currentTimeMillis() < end && !cancelled) {
                if (System.currentTimeMillis() - last > 2500) {
                    s.send(DatagramPacket(q, q.size, grp, 5353)); last = System.currentTimeMillis()
                }
                try {
                    val pk = DatagramPacket(buf, buf.size); s.receive(pk)
                    val ip = pk.address.hostAddress ?: continue
                    discovered(ip, gw)
                    val str = String(pk.data, 0, pk.length, Charsets.ISO_8859_1)
                    val nm = Regex("([A-Za-z0-9][A-Za-z0-9_\\-]{1,40})\u0005local").findAll(str)
                        .map { it.groupValues[1] }.firstOrNull { !it.startsWith("_") }
                    if (nm != null) {
                        Store.mdns[ip] = nm
                        Store.devices[ip]?.let { if (it.name.isBlank()) { it.name = nm; Net.classify(it); onUpdate() } }
                    }
                } catch (e: SocketTimeoutException) {}
            }
            s.close()
        } catch (e: Throwable) {}
    }

    private fun fetchDesc(ip: String, loc: String, srv: String) {
        try {
            val c = URL(loc).openConnection() as HttpURLConnection
            c.connectTimeout = 1500; c.readTimeout = 1500
            val x = c.inputStream.bufferedReader().readText()
            fun t(tag: String) = Regex("<$tag>(.*?)</$tag>", RegexOption.DOT_MATCHES_ALL).find(x)?.groupValues?.get(1)?.trim() ?: ""
            val old = Store.upnp[ip]
            if (old == null || old.model.isBlank()) Store.upnp[ip] = Upnp(t("friendlyName"), t("manufacturer"), t("modelName"), srv)
            Store.devices[ip]?.let { Net.classify(it) }
            onUpdate()
        } catch (e: Throwable) {}
    }
}
