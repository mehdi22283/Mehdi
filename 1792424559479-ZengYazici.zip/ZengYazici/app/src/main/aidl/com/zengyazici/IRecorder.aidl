package com.zengyazici;

interface IRecorder {
    void destroy() = 16777114;
    String start(in ParcelFileDescriptor out) = 1;
    void stop() = 2;
}
