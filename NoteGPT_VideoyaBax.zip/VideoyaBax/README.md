# Videoya bax — Android TV üçün

Telefondakı videonu **tətbiq yükləmədən** TV-də açmağa imkan verən Android TV tətbiqi.

Telefonun brauzerində TV-nin ünvanını (`http://192.168.31.220:3169`) açırsınız, fayl seçicidən
videonu seçirsiniz və video **anlıq olaraq şəbəkə üzərindən** TV-də oynanılır.
Video TV-nin yaddaşına (diskinə) **yazılmır** — yalnız RAM-da müvəqqəti buferlə saxlanılır.
Telefonda heç bir tətbiq, qoşulma və ya hususi proqram lazım deyil: sadəcə brauzer.

---

## 1. Necə işləyir (arxitektura)

```
┌──────────────────┐                      ┌────────────────────────────┐
│  TELEFON         │   Wi-Fi / LAN        │  TV ("Videoya bax" APK)    │
│  (brauzer)       │                      │                            │
│                  │  GET  /            → │  Daxili HTTP server        │
│  fayl seçici  ←──┼──────────────────────┤  (port 3169)               │
│                  │  POST /stream      → │  gələn baytlar → RAM bufer │
│  video faylı ────┼─── (axın) ──────────→ │            ↓               │
│                  │  GET  /status      ← │  ExoPlayer (RAM-dan oxuyur)│
└──────────────────┘                      └────────────────────────────┘
```

* TV tətbiqi daxilində yüngül HTTP server işlədir (heç bir xarici kitabxana yoxdur — saf `ServerSocket`).
* HTML səhifəsi TV-nin özündən verilir, ona görə telefonda yalnız brauzer kifayətdir.
* Telefon `POST /stream` ilə videonu göndərir; TV bu baytları **birbaşa** RAM buferinə yazır.
* ExoPlayer üçün xüsusi `DataSource` yazılıb: o, diskdən/şəbəkədən deyil, həmin RAM buferindən oxuyur.
  Məlumat hələ gəlməyibsə oxuma gözləyir — yəni video **stream** kimi oynanılır, kopyalanmır.

---

## 2. Layihə strukturu

```
VideoyaBax/
├── .github/workflows/build-apk.yml   # APK-ı yığıb GitHub Release-ə əlavə edir
├── app/
│   ├── build.gradle.kts              # APK adı: "Videoya bax.apk"
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/index.html         # telefon üçün yükləmə səhifəsi
│       ├── java/az/videoyabax/tv/
│       │   ├── MainActivity.kt       # UI, QR kod, oynadıcı
│       │   ├── StreamServer.kt       # HTTP server (port 3169)
│       │   ├── StreamBuffer.kt       # RAM buferi (diske yazmır)
│       │   └── StreamDataSource.kt   # ExoPlayer üçün xüsusi mənbə
│       └── res/                      # ikonlar, TV banner, mətnlər
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── README.md
```

---

## 3. APK-ı GitHub Actions ilə yükləmək (zip yoxdur)

### 3.1. Layihəni GitHub-a yükləyin

**Ən asan yol (kompüterdən, git lazım deyil):**

1. GitHub-da **New repository** → ad verin (məsələn `videoya-bax`) → **Create repository**.
2. Açılan səhifədə **"uploading an existing file"** linkinə keçin.
3. `VideoyaBax` qovluğunun **içindəki bütün fayl və qovluqları** (`.github` qovluğu daxil olmaqla)
   brauzer pəncərəsinə sürüşdürüb buraxın → **Commit changes**.

**Git ilə:**

1. GitHub-da yeni **boş** repository yaradın (məsələn `videoya-bax`), `Add README` seçməyin.
2. Bu qovluğun içindəki bütün faylları ora yükləyin:

```bash
cd VideoyaBax
git init
git add .
git commit -m "Videoya bax — ilk versiya"
git branch -M main
git remote add origin https://github.com/<İSTİFADƏÇİ_ADI>/videoya-bax.git
git push -u origin main
```

> `.github/workflows/build-apk.yml` faylının da yükləndiyinə əmin olun (gizli qovluqdur).

### 3.2. APK avtomatik yığılır

* `main` branch-ə push edən kimi **Actions** işə düşür.
* Əl ilə başlatmaq üçün: **Actions → "APK yığ (Videoya bax)" → Run workflow**.
* Build bitəndə workflow avtomatik olaraq **Release** yaradır və APK-ı oraya əlavə edir.

### 3.3. APK-ı endirmək

1. Repository səhifəsində sağ tərəfdə **Releases** bölməsinə keçin (`…/releases`).
2. Ən son buraxılışda **Assets** altında `Videoya bax.apk` faylını birbaşa endirin.
   **Bu fayl artıq APK-dır — zip açmaq lazım deyil.**
3. (Ehtiyat variant) **Actions → build → Artifacts → Videoya-bax-apk** — bu isə zip şəklindədir.

---

## 4. TV-yə quraşdırma

1. Endirdiyiniz `Videoya bax.apk` faylını USB flash sürücüyə atın və ya telefona köçürün.
2. Variant A — **USB ilə**: flash sürücünü TV-yə taxın, fayl meneceri ilə APK-ı açıb quraşdırın.
3. Variant B — **Telefonla**: TV-də "Send files to TV" / "TV File Transfer" kimi proqramla APK-ı TV-yə göndərib quraşdırın.
4. Variant C — **ADB ilə** (kompüterdən):
   ```bash
   adb connect 192.168.31.220:5555
   adb install "Videoya bax.apk"
   ```
5. Naməlum mənbələrdən quraşdırmaya icazə verməlisiniz: **Settings → Security → Unknown sources**.

> Qeyd: APK GitHub Actions-da avtomatik yaradılan debug açarı ilə imzalanır.
> Yeni versiyanı quraşdırarkən "App not installed" xətası çıxsa, köhnə versiyanı silib yenidən quraşdırın.

## 5. İstifadə

1. TV-də **Videoya bax** tətbiqini açın. Ekranda böyük ünvan və QR kod görünəcək:
   `192.168.31.220:3169`
2. Telefonu **TV ilə eyni Wi-Fi şəbəkəsinə** qoşun (mobil internet yox, eyni router).
3. Telefonun brauzerində (Chrome/Safari) ünvanı yazın: **`http://192.168.31.220:3169`**
   (və ya TV ekranındakı QR kodu skan edin).
4. Səhifədə **"Video seç"** düyməsi ilə videonu seçin, sonra **"TV-də aç"** düyməsinə basın.
5. Video dərhal TV-də oynamağa başlayır. Telefon sərbəst qalır — amma **brauzer səhifəsini bağlamayın**,
   köçürmə səhifə açıq olduqca davam edir.
6. TV pultu ilə idarə edin: **OK/Seç** → oynat/dayandır və ekran kontrolleri, **Geri** → məlumat panelini bağla,
   **Menu** → paneli yenidən aç.

## 6. Məhdudiyyətlər (vacib)

* **RAM yaddaşı:** video TV-nin diskində saxlanmır, ancaq oynama zamanı RAM-da saxlanılır.
  Bu səbəbdən **çox böyük fayllar (təxminən 1.2 GB-dan yuxarı)** yaddaş çatışmazlığı verə bilər.
  Limit `StreamBuffer.kt` faylındakı `maxBytes` dəyəri ilə dəyişdirilir.
* **Fayl strukturu:** bəzi MP4 fayllarında (moov atomu faylın sonunda olanlar) oynatma
  yükləmə tam bitdikdən sonra başlayır. Tez-start (faststart) fayllarda isə video dərhal başlayır.
  Yavaş görünürsə, videosu faststart formatına çevirmək kömək edər.
* **Eyni şəbəkə:** telefon və TV eyni Wi-Fi/LAN-da olmalıdır. Router "AP isolation" / "Client isolation"
  funksiyası açıqsa qoşulma alınmaz — söndürün.
* **Brauzer açıq qalmalıdır:** səhifə bağlanarsa köçürmə dayanır. Ekran sönməsinə mane olmaq üçün
  səhifə `wakeLock` istifadə edir.
* Eyni anda yalnız bir telefon/video göndərilə bilər (yeni video gələndə köhnəsi əvəz olunur).

## 7. Fərdiləşdirmə

| Nə | Harada |
|---|---|
| Port (3169) | `app/build.gradle.kts` → `SERVER_PORT` |
| Ehtiyat IP (192.168.31.220) | `app/build.gradle.kts` → `DEFAULT_TV_IP` (adətən avtomatik tapılır) |
| RAM limiti | `StreamBuffer.kt` → `maxBytes` |
| Tətbiq adı | `app/src/main/res/values/strings.xml` → `app_name` |
| İkon / banner | `app/src/main/res/mipmap-*/ic_launcher.png`, `drawable-xhdpi/tv_banner.png` |
| Telefon səhifəsinin görünüşü | `app/src/main/assets/index.html` |

Qeyd: port və ya IP dəyişsəniz, telefonun brauzerində yeni ünvanı yazmalısınız (TV ekranında avtomatik göstərilir).

## 8. Texniki tələblər

* Android TV / Android Box: **Android 5.0 (API 21) və yuxarı**
* Build: JDK 17, Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24
* Kitabxanalar: `androidx.media3:media3-exoplayer`, `androidx.media3:media3-ui`, `com.google.zxing:core`

## 9. Problemlərin həlli

| Problem | Səbəb / Həll |
|---|---|
| Səhifə açılmır | Telefon və TV eyni Wi-Fi-dadır? TV-də tətbiq açıqdır? Router-də "AP/client isolation" söndürülüb? |
| "TV-yə qoşulmaq mümkün deyil" | TV-nin IP-si dəyişib. TV ekranındakı ünvanı yoxlayın. |
| Video açılmır | Fayl kodeki TV tərəfindən dəstəklənmir (məsələn HEVC 10-bit) və ya fayl çox böyükdür. |
| Yükləmə yarıda kəsilir | Telefon ekranı sönüb / brauzer fon rejiminə düşüb. Səhifəni açıq saxlayın. |
| Video TV-də ləng başlayır | Fayl "moov-at-end" strukturundadır — tam yüklənməsini gözləyir (bölmə 6). |
| Port işğal olunub | 3169 portunu başqa proqram tutub; `SERVER_PORT` dəyərini dəyişin. |

---

## Lisenziya

Şəxsi istifadə üçün sərbəst istifadə edilə bilər (MIT tipli, zəmanətsiz).
