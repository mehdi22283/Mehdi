package az.market.endirim

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Bir marketin Instagram səhifəsindən son 15 postun YALNIZ ŞƏKİLLƏRİNİ endirir (video/reels yoxdur):
 *   filesDir/insta/<istifadəçi>/<sıra>_<postKodu>_<n>.jpg
 * Səhifələr yalnız şəkil linklərini tapmaq üçün gizli WebView-da açılır, heç bir səhifə arxivlənmir.
 */
class InstaSaver(private val ctx: Context, private val web: WebView) {

    enum class Res { OK, FAILED, LOGIN }

    var pageDone: CompletableDeferred<Unit>? = null

    companion object {
        const val TARGET = 15
        private const val MAX_PER_POST = 10
        const val UA =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
        val lock = Mutex()

        private val MARKETS = listOf("Bravo Market", "Araz Market", "Al Market", "Rahat Market", "Tamstore", "Bolmart")
        private val IMG_EXT = setOf("jpg", "jpeg", "png", "webp")

        fun users(): List<Pair<String, String>> =
            MARKETS.mapNotNull { m -> Brand.socials[m]?.instagram?.let { m to it } }

        private fun root(ctx: Context) = File(ctx.filesDir, "insta").apply { mkdirs() }
        private fun userDir(ctx: Context, user: String) = File(root(ctx), user).apply { mkdirs() }

        /** Saxlanmış şəkillər (post sırası ilə). */
        fun images(ctx: Context, user: String): List<File> =
            userDir(ctx, user).listFiles()?.filter { it.extension.lowercase() in IMG_EXT }?.sortedBy { it.name } ?: emptyList()

        /** Əvvəlki versiyalardan qalan səhifə arxivləri (.mht) silinir — yalnız şəkillər qalır. */
        fun cleanupLegacy(ctx: Context) {
            root(ctx).listFiles()?.forEach { f ->
                if (f.isFile) f.delete()
                else f.listFiles()?.filter { it.extension.lowercase() !in IMG_EXT }?.forEach { it.delete() }
            }
        }

        fun prefs(ctx: Context) = ctx.getSharedPreferences("insta", Context.MODE_PRIVATE)
        fun lastOk(ctx: Context, user: String) = prefs(ctx).getLong("ok_$user", 0L)
        fun needLogin(ctx: Context) = prefs(ctx).getBoolean("need_login", false)

        /** Bu gün (təqvim günü) artıq yenilənibsə true. */
        fun doneToday(ctx: Context, user: String): Boolean {
            val t = lastOk(ctx, user)
            if (t == 0L) return false
            val f = SimpleDateFormat("yyyyMMdd", Locale.US)
            return f.format(Date(t)) == f.format(Date())
        }

        fun loggedIn(): Boolean =
            CookieManager.getInstance().getCookie("https://www.instagram.com")?.contains("sessionid=") == true

        /** Video sorğularını boş cavabla kəsir. */
        fun blockVideo(req: WebResourceRequest): WebResourceResponse? {
            val u = req.url.toString().lowercase()
            val video = u.contains(".mp4") || u.contains(".webm") || u.contains(".m3u8") || u.contains(".mpd") ||
                u.contains("/o1/v/") || u.contains("/v/t16/")
            return if (video) WebResourceResponse("text/plain", "utf-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0))) else null
        }
    }

    private suspend fun load(url: String): Boolean {
        val done = CompletableDeferred<Unit>()
        pageDone = done
        web.loadUrl(url)
        return withTimeoutOrNull(30_000) { done.await(); true } ?: false
    }

    private suspend fun evalString(js: String): String = suspendCoroutine { c ->
        web.evaluateJavascript(js) { raw ->
            val v = try { (JSONTokener(raw ?: "null").nextValue() as? String) ?: "" } catch (e: Exception) { "" }
            c.resume(v)
        }
    }

    private val collectJs = """(function(){window.scrollTo(0,document.body.scrollHeight);var s=[],m={};
document.querySelectorAll('a[href*="/p/"]').forEach(function(a){var h=a.getAttribute('href');if(!m[h]){m[h]=1;s.push(h);}});
return s.join('|');})()"""

    /** Postun şəkilləri: əvvəl og:image, sonra article içindəki böyük şəkillər. */
    private val imgJs = """(function(){var r=[],m={};function add(u){if(u&&/^https?:/.test(u)&&!m[u]){m[u]=1;r.push(u);}}
var o=document.querySelector('meta[property="og:image"]');if(o)add(o.content);
var root=document.querySelector('article')||document;
root.querySelectorAll('img').forEach(function(i){if(/profile picture/i.test(i.alt||''))return;
var u=i.currentSrc||i.src;if(i.naturalWidth>=400&&/scontent|fbcdn|cdninstagram/.test(u))add(u);});
return r.join('|');})()"""

    private suspend fun collectPosts(): List<String> {
        var best = emptyList<String>()
        var stale = 0
        for (step in 0 until 30) {
            val list = evalString(collectJs).split('|').filter { it.isNotBlank() }
            if (list.size > best.size) { best = list; stale = 0 } else stale++
            if (best.size >= TARGET || stale >= 4) break
            delay(1200)
        }
        return best
    }

    private suspend fun download(url: String, f: File): Boolean = withContext(Dispatchers.IO) {
        if (f.exists() && f.length() > 0) return@withContext true
        val tmp = File(f.path + ".part")
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.setRequestProperty("User-Agent", UA)
                c.setRequestProperty("Referer", "https://www.instagram.com/")
                c.connectTimeout = 15_000
                c.readTimeout = 30_000
                if (c.responseCode != 200) return@withContext false
                if (c.contentType?.startsWith("image") != true) return@withContext false
                c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            } finally {
                c.disconnect()
            }
            tmp.length() > 0 && tmp.renameTo(f)
        } catch (e: Exception) {
            false
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    private fun loginPage() = web.url?.contains("accounts/login") == true

    suspend fun saveUser(user: String, status: (String) -> Unit): Res {
        web.settings.javaScriptEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        status("profil yüklənir…")
        if (!load("https://www.instagram.com/$user/")) return Res.FAILED
        delay(2500)
        if (loginPage()) {
            prefs(ctx).edit().putBoolean("need_login", true).apply()
            return Res.LOGIN
        }
        val codes = LinkedHashSet<String>()
        val re = Regex("/p/([^/?#]+)")
        collectPosts().forEach { h -> re.find(h)?.let { codes.add(it.groupValues[1]) } }
        if (codes.isEmpty()) return Res.FAILED

        val dir = userDir(ctx, user)
        val keep = HashSet<String>()
        var rank = 0
        for ((n, code) in codes.take(TARGET).withIndex()) {
            status("post ${n + 1}/${minOf(codes.size, TARGET)}…")
            if (!load("https://www.instagram.com/p/$code/")) continue
            delay(1500)
            if (loginPage()) {
                prefs(ctx).edit().putBoolean("need_login", true).apply()
                return Res.LOGIN
            }
            if (evalString("document.querySelector('video')?'1':'0'") == "1") continue   // video post — yüklənmir
            val urls = evalString(imgJs).split('|').filter { it.isNotBlank() }
                .distinctBy { it.substringBefore('?').substringAfterLast('/') }
                .take(MAX_PER_POST)
            if (urls.isEmpty()) continue
            rank++
            urls.forEachIndexed { k, u ->
                var ext = u.substringBefore('?').substringAfterLast('.', "jpg").lowercase()
                if (ext !in IMG_EXT) ext = "jpg"
                val name = "%02d_%s_%d.%s".format(rank, code, k, ext)
                if (download(u, File(dir, name))) keep.add(name)
            }
        }
        if (keep.isEmpty()) return Res.FAILED
        dir.listFiles()?.forEach { if (it.name !in keep) it.delete() }   // köhnə postların şəkilləri silinir
        prefs(ctx).edit().putLong("ok_$user", System.currentTimeMillis()).putBoolean("need_login", false).apply()
        return Res.OK
    }
}
