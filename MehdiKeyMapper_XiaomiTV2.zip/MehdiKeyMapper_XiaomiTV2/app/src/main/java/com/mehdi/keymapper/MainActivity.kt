package com.mehdi.keymapper

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var tvServiceStatus: TextView
    private lateinit var tvAdbStatus: TextView
    private lateinit var btnConnectAdb: Button
    private lateinit var btnEnableAccessibility: Button
    private lateinit var btnAddMapping: Button
    private lateinit var rvMappings: RecyclerView

    private lateinit var repository: MappingRepository
    private lateinit var adapter: MappingsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repository = MappingRepository(this)

        tvServiceStatus = findViewById(R.id.tvServiceStatus)
        tvAdbStatus = findViewById(R.id.tvAdbStatus)
        btnConnectAdb = findViewById(R.id.btnConnectAdb)
        btnEnableAccessibility = findViewById(R.id.btnEnableAccessibility)
        btnAddMapping = findViewById(R.id.btnAddMapping)
        rvMappings = findViewById(R.id.rvMappings)

        // Arxa plan servisini başladaq
        val serviceIntent = Intent(this, KeyMapperService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        setupRecyclerView()

        btnConnectAdb.setOnClickListener {
            tvAdbStatus.text = "ADB Status: Qoşulur (${AdbManager.TARGET_IP}:${AdbManager.TARGET_PORT})..."
            AdbManager.connectAndSetup { success, msg ->
                tvAdbStatus.text = "ADB Status: $msg"
            }
        }

        btnEnableAccessibility.setOnClickListener {
            // Əvvəlcə ADB vasitəsilə aktivləşdirməyə çalışırıq
            AdbManager.connectAndSetup { success, _ ->
                if (success) {
                    Toast.makeText(this, "Əlçatımlılıq ADB ilə aktiv edildi!", Toast.LENGTH_SHORT).show()
                } else {
                    // ADB alınmazsa, menyuya yönəldirik
                    try {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(this, "Ayarlar açıla bilmədi", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        btnAddMapping.setOnClickListener {
            showAddEditDialog(null)
        }

        // İlkin ADB bağlantısı cəhdi
        AdbManager.connectAndSetup { success, msg ->
            tvAdbStatus.text = "ADB Status: $msg"
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        refreshList()
    }

    private fun updateStatus() {
        if (KeyMapperAccessibilityService.isServiceRunning) {
            tvServiceStatus.text = "Servis Status: Əlçatımlılıq Xidməti İşləyir (Aktiv)"
            tvServiceStatus.setTextColor(0xFF4CAF50.toInt())
        } else {
            tvServiceStatus.text = "Servis Status: Deaktivdir (Aktivləşdirmək lazımdır)"
            tvServiceStatus.setTextColor(0xFFFF5252.toInt())
        }
    }

    private fun setupRecyclerView() {
        adapter = MappingsAdapter(
            repository.getMappings(),
            onEditClick = { mapping -> showAddEditDialog(mapping) },
            onDeleteClick = { mapping ->
                repository.deleteMapping(mapping.id)
                refreshList()
                Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
            }
        )
        rvMappings.layoutManager = LinearLayoutManager(this)
        rvMappings.adapter = adapter
    }

    private fun refreshList() {
        adapter.updateData(repository.getMappings())
    }

    private fun showAddEditDialog(existingMapping: KeyMapping?) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(if (existingMapping == null) "Yeni Düymə Əlavə Et" else "Düyməni Redaktə Et")

        val dialogView = layoutInflater.inflate(R.layout.dialog_add_mapping, null)
        val etLabel = dialogView.findViewById<EditText>(R.id.etLabel)
        val etTriggerCode = dialogView.findViewById<EditText>(R.id.etTriggerCode)
        val etTargetCode = dialogView.findViewById<EditText>(R.id.etTargetCode)
        val etTargetPackage = dialogView.findViewById<EditText>(R.id.etTargetPackage)

        if (existingMapping != null) {
            etLabel.setText(existingMapping.label)
            etTriggerCode.setText(existingMapping.triggerKeyCode.toString())
            etTargetCode.setText(existingMapping.targetKeyCode.toString())
            etTargetPackage.setText(existingMapping.targetPackage ?: "")
        }

        builder.setView(dialogView)
        builder.setPositiveButton("Yadda Saxla") { dialog, _ ->
            val label = etLabel.text.toString().trim()
            val trigger = etTriggerCode.text.toString().toIntOrNull() ?: 0
            val targetKey = etTargetCode.text.toString().toIntOrNull() ?: 0
            val targetPkg = etTargetPackage.text.toString().trim()

            val actionType = if (targetPkg.isNotEmpty()) {
                ActionType.LAUNCH_APP
            } else {
                ActionType.KEY_REMAP
            }

            if (existingMapping == null) {
                val newMapping = KeyMapping(
                    triggerKeyCode = trigger,
                    isLongPress = false,
                    targetKeyCode = targetKey,
                    targetPackage = if (targetPkg.isEmpty()) null else targetPkg,
                    actionType = actionType,
                    label = label
                )
                repository.addMapping(newMapping)
            } else {
                existingMapping.label = label
                existingMapping.triggerKeyCode = trigger
                existingMapping.targetKeyCode = targetKey
                existingMapping.targetPackage = if (targetPkg.isEmpty()) null else targetPkg
                existingMapping.actionType = actionType
                repository.updateMapping(existingMapping)
            }

            refreshList()
            dialog.dismiss()
        }
        builder.setNegativeButton("Ləğv Et") { dialog, _ -> dialog.cancel() }
        builder.show()
    }
}
