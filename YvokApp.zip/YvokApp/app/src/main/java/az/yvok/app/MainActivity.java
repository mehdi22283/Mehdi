package az.yvok.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;


import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String EBEL_URL = "https://e-belediyye.gov.az/tax-debts";
    private static final Pattern CODE = Pattern.compile("^10011[A-Z0-9]{7}$");
    private static final Pattern NAME_OK = Pattern.compile("^[\\p{L}\\s.'\\-]{3,100}$");
    private static final Pattern DEBT_OK = Pattern.compile("^(\\d{1,9}(\\.\\d{1,2})?)?$");
    private static final int REQ_OCR = 7001;
    // OCR səhvlərinə tolerant: 1/I/L/| və 0/O/Q/D qarışıqlığı "10011" prefiksində düzəldilir,
    // sonrakı 7 simvol isə mövqeyə görə normallaşdırılır (bax: fixOcrTail)
    private static final Pattern OCR_CODE = Pattern.compile("[1IL|!][0OQD][0OQD][1IL|!][1IL|!]([A-Z0-9|!]{7})");
    private static final int MAX_JOBS_PER_VIEW = 10;   // bu qədər sorğudan sonra gizli WebView təzələnir (yavaşlama yığılmasın)
    private static final int LOAD_LIMIT_MS = 2000;     // sorğu göndəriləndən sonra maksimum gözləmə: nəticə gəlməsə "Məlumat tapılmadı"
    private static final int PAGE_GUARD_MS = 20000;    // səhifənin özü açılmasa ümumi qoruyucu
    private static final int MAX_WORKERS = 6;   // toplu yoxlama üçün paralel gizli səhifə sayı

    private static class Job {
        final String code;          // hazırda yoxlanılan kod (O/Q variantı ola bilər)
        final String orig;          // istifadəçinin siyahısındakı ilkin kod
        final boolean batch;
        ArrayDeque<String> variants = null;   // yoxlanılmamış O/Q/I variantları (ilk "tapılmadı"dan sonra qurulur)
        Job(String code, boolean batch) { this.code = code; this.orig = code; this.batch = batch; }
        Job(String code, Job from) { this.code = code; this.orig = from.orig; this.batch = from.batch; this.variants = from.variants; }
    }

    // Hər Worker = e-belediyye.gov.az açıq olan bir gizli WebView (ui-nin ARXASINDA işləyir)
    private class Worker {
        WebView wv;                       // köhnələndə yenisi ilə əvəz olunur
        int jobs = 0;                     // bu WebView neçə sorğu emal edib
        boolean loaded = false;
        String pending = null;
        Job current = null;
        final Runnable watchdog = () -> onWatchdog(this);
    }

    private FrameLayout root;
    private WebView ui;
    private String injectJs;
    private Worker single;                                   // yalnız YVÖK xanası (mesaj göndərmə) üçün
    private final ArrayList<Worker> pool = new ArrayList<>(); // yalnız toplu yoxlama üçün
    private final ArrayDeque<Job> batchJobs = new ArrayDeque<>();
    private Uri cameraUri = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        injectJs = readAsset("inject.js");
        clearOcrCache();                      // əvvəlki sessiyadan qalan kamera şəkilləri

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ui = new WebView(this);
        ui.setBackgroundColor(Color.BLACK);
        ui.setFocusable(true);
        ui.setFocusableInTouchMode(true);
        root.addView(ui, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        setupCommon(ui);

        // ---- Yuxarı: öz səhifəmiz (assets/index.html) ----
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        ui.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                ui.requestFocus();
                ui.evaluateJavascript("document.getElementById('phone-input').focus();", null);
                ui.postDelayed(() -> {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(ui, InputMethodManager.SHOW_IMPLICIT);
                }, 350);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {                                   // whatsapp:// və xarici linklər
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Tətbiq tapılmadı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        ui.addJavascriptInterface(new Object() {
            // YVÖK xanası (mesaj göndərmə): yalnız öz gizli səhifəsini sıfırlayır
            @JavascriptInterface
            public void reset() {
                runOnUiThread(() -> recycle(single));
            }

            @JavascriptInterface
            public void fill(String code) {
                final String v = "10011" + (code == null ? "" : code.toUpperCase());
                if (!CODE.matcher(v).matches()) return;
                runOnUiThread(() -> {
                    if (single.current != null) recycle(single);   // əvvəlki sorğunu ləğv et
                    status("loading");
                    start(single, new Job(v, false));
                });
            }

            // Toplu yoxlama səhifələrini əvvəlcədən hazırla ("Şəkildən oxu" basılanda)
            @JavascriptInterface
            public void warm() {
                runOnUiThread(() -> { while (pool.size() < MAX_WORKERS) createWorker(true); });
            }

            // Toplu yoxlama: vergüllə ayrılmış tam kodlar (10011XXXXXXX)
            @JavascriptInterface
            public void batch(String csv) {
                if (csv == null) return;
                final String[] parts = csv.split(",");
                runOnUiThread(() -> {
                    for (String c : parts) {
                        c = c.trim().toUpperCase();
                        if (!CODE.matcher(c).matches()) continue;
                        boolean dup = false;
                        for (Worker w : pool) {
                            if (w.current != null && (w.current.code.equals(c) || w.current.orig.equals(c))) { dup = true; break; }
                        }
                        if (!dup) for (Job j : batchJobs) if (j.code.equals(c)) { dup = true; break; }
                        if (!dup) batchJobs.addLast(new Job(c, true));
                    }
                    pumpBatch();
                });
            }

            // Google Cloud Vision API açarı (Toplu yoxlama yanındakı xana)
            @JavascriptInterface
            public String getVisionKey() {
                return CloudVision.apiKey;
            }

            // OCR mühərriki seçimi: "cloud" (Google Cloud Vision) və ya "mlkit" (oflayn ML Kit)
            @JavascriptInterface
            public String getOcrMode() {
                return ocrMode();
            }

            @JavascriptInterface
            public void setOcrMode(String mode) {
                getSharedPreferences("yvok", MODE_PRIVATE).edit()
                        .putString("ocr_mode", "mlkit".equals(mode) ? "mlkit" : "cloud").apply();
            }

            // Cloud Vision kvota səhifəsi xarici brauzerdə açılır (tətbiqin öz səhifəsini əvəz etməsin)
            @JavascriptInterface
            public void openQuota() {
                runOnUiThread(() -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://console.cloud.google.com/iam-admin/quotas")));
                    } catch (Exception e) {
                        toast("Brauzer açılmadı");
                    }
                });
            }

            @JavascriptInterface
            public int getVisionLimit() {
                return CloudVision.FREE_LIMIT;
            }

            @JavascriptInterface
            public int getVisionLeft() {
                return CloudVision.left(MainActivity.this);
            }

            @JavascriptInterface
            public void setVisionKey(String k) {
                final String v = k == null ? "" : k.trim();
                CloudVision.apiKey = v;
                getSharedPreferences("yvok", MODE_PRIVATE).edit().putString("vision_key", v).apply();
            }

            // Şəkildən kod oxu: kamera və ya qalereya
            @JavascriptInterface
            public void ocr() {
                runOnUiThread(() -> openOcrChooser());
            }

            @JavascriptInterface
            public void batchStop() {
                runOnUiThread(() -> {
                    batchJobs.clear();
                    for (Worker w : pool) if (w.current != null) recycle(w);
                });
            }
        }, "Android");
        CloudVision.apiKey = getSharedPreferences("yvok", MODE_PRIVATE).getString("vision_key", "");
        ui.loadUrl("https://" + HOST + "/assets/index.html");

        // ---- Aşağı: e-belediyye.gov.az (gizli WebView-lar) ----
        single = createWorker(false);
    }

    // ---------------- OCR ----------------
    private void openOcrChooser() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        Intent chooser = Intent.createChooser(pick, "Şəkil seçin");
        cameraUri = null;
        try {
            File dir = new File(getCacheDir(), "ocr");
            dir.mkdirs();
            File f = new File(dir, "cam_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.setClipData(ClipData.newRawUri("", cameraUri));
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        } catch (Exception e) {
            cameraUri = null;   // kamera olmasa yalnız qalereya
        }
        try {
            startActivityForResult(chooser, REQ_OCR);
        } catch (Exception e) {
            toast("Şəkil seçmək mümkün olmadı");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_OCR) return;
        if (res != RESULT_OK) { clearOcrCache(); return; }
        ArrayList<Uri> uris = new ArrayList<>();
        if (data != null && data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) uris.add(u);
            }
        } else if (data != null && data.getData() != null) {
            uris.add(data.getData());
        } else if (cameraUri != null) {
            uris.add(cameraUri);      // kamera çəkilişi
        }
        if (uris.isEmpty()) return;
        runOcr(uris);
    }

    private String ocrMode() {
        String v = getSharedPreferences("yvok", MODE_PRIVATE).getString("ocr_mode", "cloud");
        return "mlkit".equals(v) ? "mlkit" : "cloud";
    }

    private TextRecognizer activeRec = null;   // yalnız ML Kit rejimində

    // İki rejim (Toplu yoxlama yanındakı düymə): Cloud Vision, ML Kit.
    // Cloud Vision: şəkil maksimum keyfiyyətdə (mümkünsə orijinal fayl olduğu kimi) Google-a göndərilir.
    // ML Kit: oflayn; bütün şəkil, hündür şəkillər zolaqlara bölünüb, tapılmasa 90/270/180 dərəcə çevrilib oxunur.
    // Şəkillər PARALEL oxunur, nəticələr seçilmə sırasına görə birləşdirilir.
    private void runOcr(ArrayList<Uri> uris) {
        final String mode = ocrMode();
        final boolean cloudMode = "cloud".equals(mode);
        if (cloudMode && !CloudVision.enabled()) {
            clearOcrCache();
            toast("Cloud Vision açarını \"Şəkildən oxu\" altındakı xanaya yazın və ya ML Kit seçin");
            return;
        }
        toast("Şəkil oxunur…");
        final TextRecognizer rec = cloudMode ? null : TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        activeRec = rec;
        final int n = uris.size();
        final ArrayList<LinkedHashSet<String>> res = new ArrayList<>();
        for (int i = 0; i < n; i++) res.add(null);
        final int[] left = {n};
        final String[] err = {null};
        for (int i = 0; i < n; i++) {
            final int idx = i;
            final Uri uri = uris.get(i);
            new Thread(() -> {
                LinkedHashSet<String> s = new LinkedHashSet<>();
                try {
                    if (cloudMode) {
                        String text = CloudVision.detect(MainActivity.this, uri);
                        if (text != null) collectFromString(text, s);
                        else if (CloudVision.lastError != null) err[0] = CloudVision.lastError;
                    } else {
                        Bitmap bmp = OcrImage.load(MainActivity.this, uri);
                        s = scanBitmap(rec, bmp);
                        if (s.isEmpty()) {
                            int[] degs = {90, 270, 180};
                            for (int d : degs) {
                                Bitmap r = OcrImage.rotate(bmp, d);
                                s = scanBitmap(rec, r);
                                if (r != bmp) r.recycle();
                                if (!s.isEmpty()) break;
                            }
                        }
                        bmp.recycle();
                    }
                } catch (Throwable t) {
                    err[0] = "Şəkil oxunmadı";
                }
                final LinkedHashSet<String> fs = s;
                runOnUiThread(() -> ocrImgDone(fs, idx, res, left, err));
            }).start();
        }
    }

    // ---- ML Kit (oflayn) ----
    // Hər tapılan kod şəkildəki mövqeyi ilə yadda saxlanır, sonda yuxarıdan aşağı (eyni cərgədə soldan sağa) düzülür.
    private static final class Pos {
        final String code; final float cy, h, x;
        Pos(String code, float cy, float h, float x) { this.code = code; this.cy = cy; this.h = h; this.x = x; }
    }

    // Bir şəkli (lazım olsa zolaqlara bölüb) oxuyur. Yalnız arxa thread-də çağırılır.
    private LinkedHashSet<String> scanBitmap(TextRecognizer rec, Bitmap bmp) {
        ArrayList<Pos> found = new ArrayList<>();
        runPass(rec, bmp, 0, found);
        int w = bmp.getWidth(), h = bmp.getHeight();
        if (h > w * 1.6f) {
            int tileH = (int) (w * 1.3f);
            int step = (int) (tileH * 0.8f);      // 20% üst-üstə düşmə: sətir kəsilsə də digər zolaqda tam olsun
            for (int y = 0; y < h; y += step) {
                int th = Math.min(tileH, h - y);
                if (th < w * 0.3f && y > 0) break;
                try {
                    Bitmap tile = Bitmap.createBitmap(bmp, 0, y, w, th);
                    runPass(rec, tile, y, found);
                    if (tile != bmp) tile.recycle();
                } catch (Throwable ignored) { }
                if (y + th >= h) break;
            }
        }
        return sortByPosition(found);
    }

    private void runPass(TextRecognizer rec, Bitmap b, int yOff, ArrayList<Pos> out) {
        try {
            Text t = com.google.android.gms.tasks.Tasks.await(rec.process(InputImage.fromBitmap(b, 0)));
            collectCodes(t, yOff, out);
        } catch (Throwable ignored) { }
    }

    // Eyni kod və ya eyni yerdəki kod (başqa zolaqda bir qədər fərqli oxunsa da) ikinci dəfə əlavə olunmur.
    private static void addPos(ArrayList<Pos> out, String code, float cy, float h, float x) {
        for (Pos p : out) {
            if (p.code.equals(code)) return;
            if (Math.abs(p.cy - cy) < 0.4f * Math.max(p.h, h) && Math.abs(p.x - x) < 0.5f * Math.max(1f, Math.max(p.h, h)) * 8f) return;
        }
        out.add(new Pos(code, cy, h, x));
    }

    private static LinkedHashSet<String> sortByPosition(ArrayList<Pos> found) {
        Collections.sort(found, (a, b) -> Float.compare(a.cy, b.cy));
        ArrayList<ArrayList<Pos>> rows = new ArrayList<>();
        float rowY = 0, rowH = 0;
        for (Pos p : found) {
            if (!rows.isEmpty() && Math.abs(p.cy - rowY) < 0.5f * Math.max(rowH, p.h)) {
                ArrayList<Pos> row = rows.get(rows.size() - 1);
                row.add(p);
                rowY = (rowY * (row.size() - 1) + p.cy) / row.size();
            } else {
                ArrayList<Pos> row = new ArrayList<>();
                row.add(p);
                rows.add(row);
                rowY = p.cy;
                rowH = p.h;
            }
        }
        LinkedHashSet<String> out = new LinkedHashSet<>();
        for (ArrayList<Pos> row : rows) {
            Collections.sort(row, (a, b) -> Float.compare(a.x, b.x));
            for (Pos p : row) out.add(p.code);
        }
        return out;
    }

    // Əvvəl bütün sətirlər öz mövqeyi ilə oxunur; sonra sətirlərə bölünmüş (iki sətrə düşən) kodlar blok daxilində
    // axtarılır və mövqeyi kodun başladığı sətirdən götürülür.
    private void collectCodes(Text t, int yOff, ArrayList<Pos> out) {
        if (t == null) return;
        for (Text.TextBlock b : t.getTextBlocks()) {
            for (Text.Line ln : b.getLines()) {
                String line = ln.getText().toUpperCase();
                ArrayList<String> codes = matchList(line);
                if (codes.isEmpty()) codes = matchList(line.replaceAll("\\s+", ""));
                float cy = centerY(ln) + yOff;
                Rect r = ln.getBoundingBox();
                float h = r == null ? 1 : Math.max(1, r.height());
                int k = 0;
                for (String c : codes) addPos(out, c, cy, h, left(ln) + (k++) * 0.001f);
            }
        }
        for (Text.TextBlock b : t.getTextBlocks()) {
            java.util.List<Text.Line> lines = b.getLines();
            if (lines.size() < 2) continue;
            StringBuilder joined = new StringBuilder();
            ArrayList<Integer> starts = new ArrayList<>();
            for (Text.Line ln : lines) {
                starts.add(joined.length());
                joined.append(ln.getText().toUpperCase().replaceAll("\\s+", ""));
            }
            if (joined.length() < 12) continue;
            java.util.regex.Matcher m = OCR_CODE.matcher(joined);
            while (m.find()) {
                String c = "10011" + fixOcrTail(m.group(1));
                if (!CODE.matcher(c).matches()) continue;
                int li = 0;
                for (int i = 0; i < starts.size(); i++) if (starts.get(i) <= m.start()) li = i;
                Text.Line ln = lines.get(li);
                Rect r = ln.getBoundingBox();
                addPos(out, c, centerY(ln) + yOff, r == null ? 1 : Math.max(1, r.height()), left(ln));
            }
        }
    }

    private static float centerY(Text.Line l) {
        Rect r = l.getBoundingBox();
        return r == null ? 0 : r.centerY();
    }

    private static int left(Text.Line l) {
        Rect r = l.getBoundingBox();
        return r == null ? 0 : r.left;
    }

    private ArrayList<String> matchList(String s) {
        ArrayList<String> res = new ArrayList<>();
        java.util.regex.Matcher m = OCR_CODE.matcher(s);
        while (m.find()) {
            String c = "10011" + fixOcrTail(m.group(1));
            if (CODE.matcher(c).matches()) res.add(c);
        }
        return res;
    }

    // ---- Cloud Vision ----
    // Mətn artıq CloudVision.orderedText ilə şəkildəki sıraya düzülüb: sətir-sətir oxunur, sıra pozulmur.
    private void collectFromString(String text, LinkedHashSet<String> out) {
        String up = text.toUpperCase();
        for (String line : up.split("\\r?\\n")) {
            int before = out.size();
            addMatches(line, out);
            if (out.size() == before) addMatches(line.replaceAll("\\s+", ""), out);
        }
    }

    private void ocrImgDone(LinkedHashSet<String> s, int idx, ArrayList<LinkedHashSet<String>> res,
                            int[] left, String[] err) {
        res.set(idx, s);
        if (--left[0] > 0) return;
        LinkedHashSet<String> found = new LinkedHashSet<>();
        for (LinkedHashSet<String> x : res) if (x != null) found.addAll(x);   // indeks sırası = seçilmə sırası
        ocrFinish(found, err[0]);
    }

    // Kameradan çəkilən müvəqqəti şəkillər (cache/ocr) oxunandan sonra silinir.
    // Qalereyadan seçilən şəkillərə toxunulmur.
    private void clearOcrCache() {
        try {
            File[] fs = new File(getCacheDir(), "ocr").listFiles();
            if (fs != null) for (File f : fs) f.delete();
        } catch (Exception ignored) { }
        cameraUri = null;
    }

    private void ocrFinish(LinkedHashSet<String> found, String err) {
        if (activeRec != null) { activeRec.close(); activeRec = null; }
        clearOcrCache();
        ui.evaluateJavascript("window.updateVisionLeft && updateVisionLeft();", null);
        if (found.isEmpty()) {
            toast(err != null ? err : "Şəkildə kod tapılmadı");
            return;
        }
        ui.evaluateJavascript("window.addOcrCodes(" + JSONObject.quote(String.join("\n", found)) + ");", null);
    }

    private void addMatches(String s, LinkedHashSet<String> out) {
        java.util.regex.Matcher m = OCR_CODE.matcher(s);
        while (m.find()) {
            String c = "10011" + fixOcrTail(m.group(1));
            if (CODE.matcher(c).matches()) out.add(c);
        }
    }

    // Koddakı 7 simvolun qaydası: 6-8-ci simvollar (tail[0..2]) hərf, 9-12-ci simvollar (tail[3..6]) rəqəmdir.
    // Hərf yerində: 0 -> O, 1/|/! -> I   (O, Q və digər hərflər olduğu kimi qalır)
    // Rəqəm yerində: O/Q/D -> 0, I/L/|/! -> 1, S -> 5
    private static String fixOcrTail(String t) {
        StringBuilder sb = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (i < 3) {
                if (c == '0') c = 'O';
                else if (c == '1' || c == '|' || c == '!') c = 'I';
            } else {
                if (c == 'O' || c == 'Q' || c == 'D') c = '0';
                else if (c == 'I' || c == 'L' || c == '|' || c == '!') c = '1';
                else if (c == 'S') c = '5';
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private Worker createWorker(boolean batch) {
        final Worker w = new Worker();
        if (batch) pool.add(w);
        attachWebView(w);
        return w;
    }

    private void attachWebView(final Worker w) {
        final WebView wv = new WebView(this);
        wv.setBackgroundColor(Color.WHITE);
        wv.setFocusable(false);                       // klaviaturanı/fokusu oğurlamasın
        wv.setFocusableInTouchMode(false);
        // ui-nin ARXASINA (index 0) əlavə olunur: tam ölçüdə layout alır, amma görünmür
        root.addView(wv, 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setupCommon(wv);
        wv.getSettings().setLoadsImagesAutomatically(false);   // gizli səhifədə şəkil lazım deyil: daha tez açılır
        wv.getSettings().setBlockNetworkImage(true);
        w.wv = wv;
        w.loaded = false;
        wv.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void result(final String code, final String name, final String debt) {
                runOnUiThread(() -> { if (w.wv == wv) onEbelResult(w, code, name, debt); });
            }

            @JavascriptInterface
            public void fail(final String code, final String reason) {
                runOnUiThread(() -> { if (w.wv == wv) onEbelFail(w, code, reason); });
            }
        }, "AndroidEbel");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                if (w.wv == wv) w.loaded = false;     // yeni yükləmə başlayıb: köhnə "hazırdır" siqnalı keçərsiz
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (w.wv != wv) return;
                v.clearHistory();                      // hər təzələmə tarixçəni şişirtməsin
                w.loaded = true;
                if (w.pending != null) {
                    String p = w.pending;
                    w.pending = null;
                    runFill(w, p);
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                // Əsas səhifə yüklənmədisə 45 san gözləmədən tez təkrar yüklə
                if (w.wv != wv || r == null || !r.isForMainFrame()) return;
                v.postDelayed(() -> { if (w.wv == wv && !w.loaded) wv.loadUrl(EBEL_URL); }, 1500);
            }
        });
        wv.loadUrl(EBEL_URL);
    }

    // Köhnə WebView tam məhv edilir, yenisi açılır (uzun işləyəndə yaddaş və yavaşlıq yığılmasın)
    private void rebuild(Worker w) {
        WebView old = w.wv;
        old.removeCallbacks(w.watchdog);
        w.wv = null;
        old.stopLoading();
        old.setWebViewClient(new WebViewClient());
        root.removeView(old);
        old.destroy();
        w.jobs = 0;
        w.current = null;
        w.pending = null;
        attachWebView(w);
    }

    // Səhifəni təzədən yüklə: hər kod TƏMİZ səhifədə yoxlanılır, əvvəlki sorğunun vəziyyəti qalmır
    private void recycle(Worker w) {
        if (w.current != null && ++w.jobs >= MAX_JOBS_PER_VIEW) { rebuild(w); return; }
        w.wv.removeCallbacks(w.watchdog);
        w.current = null;
        w.pending = null;
        w.loaded = false;
        w.wv.stopLoading();
        w.wv.loadUrl(EBEL_URL);
    }

    private void start(Worker w, Job j) {
        w.current = j;
        w.wv.removeCallbacks(w.watchdog);
        if (w.loaded) {
            runFill(w, j.code);                          // 5 san sayğacı runFill-də başlayır
        } else {
            w.pending = j.code;                          // səhifə hələ açılır: sayğac açılandan sonra başlayacaq
            w.wv.postDelayed(w.watchdog, PAGE_GUARD_MS);
        }
    }

    private Worker pickBatchWorker() {
        for (Worker w : pool) if (w.current == null && w.loaded) return w;
        for (Worker w : pool) if (w.current == null) return w;
        if (pool.size() < MAX_WORKERS) return createWorker(true);
        return null;
    }

    private void pumpBatch() {
        while (!batchJobs.isEmpty()) {
            Worker w = pickBatchWorker();
            if (w == null) return;
            start(w, batchJobs.pollFirst());
        }
    }

    private void runFill(Worker w, String value) {
        w.wv.removeCallbacks(w.watchdog);
        w.wv.postDelayed(w.watchdog, LOAD_LIMIT_MS);     // sorğu göndərildi: 2 saniyədə nəticə gəlməsə "Məlumat tapılmadı"
        w.wv.evaluateJavascript(injectJs + ";window.__yvokRun('" + value + "');", null);
    }

    private void onEbelResult(Worker w, String code, String name, String debt) {
        Job j = w.current;
        if (j == null || code == null || !j.code.equals(code)) return;   // köhnə/yad nəticə
        final String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        final String d = debt == null ? "" : debt.trim();
        recycle(w);
        if (!NAME_OK.matcher(n).matches() || !DEBT_OK.matcher(d).matches()) {
            failJob(j, "Məlumat formatı tanınmadı");
        } else if (j.batch) {
            ui.evaluateJavascript("window.setBatchResult(" + JSONObject.quote(j.orig) + ","
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + "," + JSONObject.quote(j.code) + ");", null);
        } else {
            ui.evaluateJavascript("window.setEbelStatus('ok');window.setEbelResult("
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
            if (d.isEmpty()) toast("Borc məbləği tapılmadı");
        }
        if (j.batch) pumpBatch();
    }

    private void onEbelFail(Worker w, String code, String reason) {
        Job j = w.current;
        if (j == null || (code != null && !j.code.equals(code))) return;
        handleFail(w, j, "Məlumat tapılmadı");
    }

    private void onWatchdog(Worker w) {
        Job j = w.current;
        if (j == null) return;
        handleFail(w, j, "Məlumat tapılmadı");
    }

    private void handleFail(Worker w, Job j, String msg) {
        // Nəticə gəlməyibsə (kod yanlışdır) qarışan simvol variantları yoxlanılır (0/O/Q, 1/I, 9-12-ci simvollarda 5/S).
        // Nəticə gəlibsə koda toxunulmur. "Sayt cavab vermədi" mesajı yoxdur: bütün uğursuzluqlar "Məlumat tapılmadı"dır.
        if (j.batch) {
            if (j.variants == null) j.variants = buildVariants(j.orig);
            String next = j.variants.pollFirst();
            if (next != null) {
                recycle(w);
                start(w, new Job(next, j));
                return;
            }
        }
        recycle(w);
        failJob(j, msg);                      // təkrar yoxlama yoxdur: 5 saniyədən çox gözlətmə
        if (j.batch) pumpBatch();
    }

    // Qarışan simvol qrupları: {0,O,Q,D} və {1,I,L} (6-12-ci simvollar), {5,S} (yalnız 8-12-ci simvollar). Koddakı 6-12-ci simvolların (indeks 5..11) hər biri
    // öz qrupunun istənilən üzvü ilə əvəz oluna bilər (hər iki istiqamətdə: O->0, 0->O, 0<->D, I->1, 1->I, 1<->L, O<->Q ...).
    // Variantlar az dəyişiklikdən çoxuna doğru sıralanır və MAX_VARIANTS ilə məhdudlaşdırılır.
    private static final int MAX_VARIANTS = 40;

    private static String confusableGroup(char c, int i) {
        if (c == '0' || c == 'O' || c == 'Q' || c == 'D') return "0OQD";
        if (c == '1' || c == 'I' || c == 'L') return "1IL";
        if (i >= 7 && (c == '5' || c == 'S')) return "5S";   // 8-12-ci simvollarda 5<->S qarışır
        return null;
    }

    private static ArrayDeque<String> buildVariants(String code) {
        ArrayList<Integer> pos = new ArrayList<>();
        for (int i = 5; i < code.length(); i++) if (confusableGroup(code.charAt(i), i) != null) pos.add(i);
        int n = pos.size();
        ArrayList<String> list = new ArrayList<>();
        ArrayList<int[]> meta = new ArrayList<>();
        int[] idx = new int[n];                       // hər mövqedə qrupdan seçilən üzvün nömrəsi
        while (true) {
            char[] cs = code.toCharArray();
            int d = 0;
            for (int b = 0; b < n; b++) {
                int i = pos.get(b);
                char nc = confusableGroup(code.charAt(i), i).charAt(idx[b]);
                if (cs[i] != nc) { cs[i] = nc; d++; }
            }
            if (d > 0) {
                list.add(new String(cs));
                meta.add(new int[]{d, list.size() - 1});
            }
            int b = 0;                                // sayğacı bir artır (qarışıq say sistemi)
            while (b < n) {
                if (++idx[b] < confusableGroup(code.charAt(pos.get(b)), pos.get(b)).length()) break;
                idx[b++] = 0;
            }
            if (b == n) break;
        }
        Collections.sort(meta, (p, q) -> p[0] != q[0] ? Integer.compare(p[0], q[0]) : Integer.compare(p[1], q[1]));
        ArrayDeque<String> out = new ArrayDeque<>();
        for (int[] m : meta) { if (out.size() >= MAX_VARIANTS) break; out.add(list.get(m[1])); }
        return out;
    }

    private void failJob(Job j, String msg) {
        if (j.batch) {
            ui.evaluateJavascript("window.setBatchFail(" + JSONObject.quote(j.orig) + ","
                    + JSONObject.quote(msg) + ");", null);
        } else {
            status("fail");
            toast(msg);
        }
    }

    private void setupCommon(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("OK", (d, x) -> res.confirm())
                        .setOnCancelListener(d -> res.confirm()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("Bəli", (d, x) -> res.confirm())
                        .setNegativeButton("Xeyr", (d, x) -> res.cancel())
                        .setOnCancelListener(d -> res.cancel()).show();
                return true;
            }
        });
    }

    private void status(final String st) {
        runOnUiThread(() -> ui.evaluateJavascript("window.setEbelStatus('" + st + "');", null));
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
