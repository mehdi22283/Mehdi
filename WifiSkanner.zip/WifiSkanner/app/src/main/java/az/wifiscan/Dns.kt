package az.wifiscan

import android.content.Context
import android.net.ConnectivityManager
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.net.*

/** Xam DNS müştərisi (A, AAAA, MX, NS, TXT, CNAME, SOA, PTR) + WHOIS. */
object Dns {
    val TYPES = linkedMapOf("A" to 1, "AAAA" to 28, "MX" to 15, "NS" to 2, "TXT" to 16, "CNAME" to 5, "SOA" to 6, "PTR" to 12)

    class Result(val lines: List<String>, val ms: Long, val rcode: Int, val error: String = "")

    fun systemServers(ctx: Context): List<String> {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return emptyList()
            cm.getLinkProperties(n)?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    private fun build(name: String, type: Int): ByteArray {
        val bo = ByteArrayOutputStream()
        val id = (System.nanoTime() and 0xFFFF).toInt()
        bo.write(id shr 8); bo.write(id and 255)
        bo.write(0x01); bo.write(0x00)           // RD
        bo.write(0); bo.write(1)                  // QDCOUNT
        bo.write(0); bo.write(0); bo.write(0); bo.write(0); bo.write(0); bo.write(0)
        for (lab in name.trim('.').split(".")) {
            val b = lab.toByteArray(); bo.write(b.size); bo.write(b)
        }
        bo.write(0)
        bo.write(0); bo.write(type); bo.write(0); bo.write(1)
        return bo.toByteArray()
    }

    private fun u16(b: ByteArray, p: Int) = ((b[p].toInt() and 255) shl 8) or (b[p + 1].toInt() and 255)
    private fun u32(b: ByteArray, p: Int) = (u16(b, p).toLong() shl 16) or u16(b, p + 2).toLong()

    /** Ad + növbəti mövqe */
    private fun name(b: ByteArray, start: Int): Pair<String, Int> {
        val sb = StringBuilder(); var p = start; var next = -1; var guard = 0
        while (guard++ < 64) {
            val len = b[p].toInt() and 255
            if (len == 0) { p++; break }
            if ((len and 0xC0) == 0xC0) {
                if (next < 0) next = p + 2
                p = ((len and 0x3F) shl 8) or (b[p + 1].toInt() and 255)
                continue
            }
            sb.append(String(b, p + 1, len)).append('.'); p += 1 + len
        }
        if (next < 0) next = p
        return Pair(if (sb.isEmpty()) "." else sb.toString(), next)
    }

    private fun udp(q: ByteArray, server: String, timeout: Int): ByteArray {
        return DatagramSocket().use { s ->
            s.soTimeout = timeout
            s.send(DatagramPacket(q, q.size, InetAddress.getByName(server), 53))
            val buf = ByteArray(4096); val pk = DatagramPacket(buf, buf.size)
            s.receive(pk)
            buf.copyOf(pk.length)
        }
    }

    private fun tcp(q: ByteArray, server: String, timeout: Int): ByteArray {
        return Socket().use { s ->
            s.connect(InetSocketAddress(server, 53), timeout); s.soTimeout = timeout
            val o = s.getOutputStream()
            o.write(q.size shr 8); o.write(q.size and 255); o.write(q); o.flush()
            val di = DataInputStream(s.getInputStream())
            val len = di.readUnsignedShort(); val r = ByteArray(len); di.readFully(r)
            r
        }
    }

    fun query(domain: String, type: Int, server: String, timeout: Int = 3000): Result {
        val t0 = System.nanoTime()
        return try {
            val q = build(domain, type)
            var r = udp(q, server, timeout)
            if (r.size >= 12 && (r[2].toInt() and 0x02) != 0) r = try { tcp(q, server, timeout) } catch (e: Exception) { r }
            val ms = (System.nanoTime() - t0) / 1_000_000
            if (r.size < 12) return Result(emptyList(), ms, -1, "Cavab natamamdır")
            val rcode = r[3].toInt() and 15
            val qd = u16(r, 4); val an = u16(r, 6)
            var p = 12
            repeat(qd) { p = name(r, p).second + 4 }
            val out = ArrayList<String>()
            repeat(an) {
                val (nm, np) = name(r, p); p = np
                val t = u16(r, p); val ttl = u32(r, p + 4); val rl = u16(r, p + 8); p += 10
                val tn = TYPES.entries.firstOrNull { it.value == t }?.key ?: "TYPE$t"
                val data = try { rdata(r, p, rl, t) } catch (e: Exception) { "?" }
                out.add("${nm.trimEnd('.')}  $ttl  $tn  $data")
                p += rl
            }
            Result(out, ms, rcode)
        } catch (e: SocketTimeoutException) {
            Result(emptyList(), (System.nanoTime() - t0) / 1_000_000, -1, "Vaxt bitdi (server cavab vermədi)")
        } catch (e: Exception) {
            Result(emptyList(), (System.nanoTime() - t0) / 1_000_000, -1, e.message ?: "Xəta")
        }
    }

    private fun rdata(b: ByteArray, p: Int, len: Int, type: Int): String = when (type) {
        1 -> "${b[p].toInt() and 255}.${b[p + 1].toInt() and 255}.${b[p + 2].toInt() and 255}.${b[p + 3].toInt() and 255}"
        28 -> InetAddress.getByAddress(b.copyOfRange(p, p + 16)).hostAddress ?: ""
        2, 5, 12 -> name(b, p).first.trimEnd('.')
        15 -> "${u16(b, p)} ${name(b, p + 2).first.trimEnd('.')}"
        16 -> {
            val sb = StringBuilder(); var q = p
            while (q < p + len) { val l = b[q].toInt() and 255; sb.append(String(b, q + 1, l)); q += 1 + l }
            "\"$sb\""
        }
        6 -> {
            val (mn, p1) = name(b, p); val (rn, p2) = name(b, p1)
            "${mn.trimEnd('.')} ${rn.trimEnd('.')} serial=${u32(b, p2)} refresh=${u32(b, p2 + 4)} retry=${u32(b, p2 + 8)} expire=${u32(b, p2 + 12)} min=${u32(b, p2 + 16)}"
        }
        else -> "(${len} bayt)"
    }

    fun reverseName(ip: String): String = ip.split(".").reversed().joinToString(".") + ".in-addr.arpa"

    fun isIpv4(s: String) = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(s)
}

object Whois {
    private fun ask(server: String, q: String): String {
        return Socket().use { s ->
            s.connect(InetSocketAddress(server, 43), 5000); s.soTimeout = 8000
            s.getOutputStream().write((q + "\r\n").toByteArray()); s.getOutputStream().flush()
            val sb = StringBuilder(); val buf = ByteArray(4096)
            val ins = s.getInputStream()
            try {
                while (sb.length < 60000) { val n = ins.read(buf); if (n < 0) break; sb.append(String(buf, 0, n)) }
            } catch (e: SocketTimeoutException) {}
            sb.toString()
        }
    }

    private fun refer(txt: String, cur: String): String? {
        val rx = Regex("(?im)^\\s*(?:refer|whois|Registrar WHOIS Server|ReferralServer)\\s*:\\s*(?:r?whois://)?([A-Za-z0-9.\\-]+)")
        val h = rx.find(txt)?.groupValues?.get(1)?.lowercase() ?: return null
        return if (h == cur || h.isEmpty()) null else h
    }

    fun lookup(q: String): String {
        val query = q.trim()
        var server = "whois.iana.org"
        var txt = ask(server, query)
        var last = txt
        for (i in 0 until 3) {
            val next = refer(txt, server) ?: break
            val qq = if (next.contains("arin.net") && Dns.isIpv4(query)) "n + $query" else query
            val r = try { ask(next, qq) } catch (e: Exception) { break }
            if (r.isBlank()) break
            server = next; txt = r; last = r
        }
        val lines = last.lines().filter { it.isNotBlank() && !it.trimStart().startsWith("%") && !it.trimStart().startsWith("#") }
        val body = lines.joinToString("\n").take(12000)
        return "Server: $server\n\n$body"
    }
}
