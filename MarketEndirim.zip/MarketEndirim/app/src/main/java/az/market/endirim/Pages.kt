package az.market.endirim

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.github.chrisbanes.photoview.PhotoView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class PageVH(val img: PhotoView) : RecyclerView.ViewHolder(img) {
    var job: Job? = null
}

private fun newPhotoView(parent: ViewGroup) = PhotoView(parent.context).apply {
    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    scaleType = ImageView.ScaleType.FIT_CENTER
    mediumScale = 3f
    maximumScale = 8f        // yaxınlaşdırma: PDF yüksək ölçüdə render olunur, ona görə böyüdəndə də aydın qalır
}

class ImageAdapter(private val urls: List<String>) : RecyclerView.Adapter<PageVH>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PageVH(newPhotoView(parent))
    override fun getItemCount() = urls.size
    override fun onBindViewHolder(holder: PageVH, position: Int) {
        holder.img.load(urls[position]) { crossfade(true) }
    }
}

/** PDF səhifələrini slayd kimi göstərir (PdfRenderer, səhifə-səhifə). */
class PdfAdapter(
    file: File, widthPx: Int, private val scope: CoroutineScope,
    cacheBytes: Int = (Runtime.getRuntime().maxMemory() / 6).toInt()
) : RecyclerView.Adapter<PageVH>() {

    companion object {
        private const val MAX_SIDE = 4096          // GPU tekstur limiti — bundan böyük bitmap çəkilməz
        private const val MAX_PIXELS = 14_000_000  // ≈ 56 MB / səhifə

        /** Tam ekran oxuyucu üçün maksimum keyfiyyət: ekran enindən 3 dəfə (1800–3200 px). */
        fun maxWidth(screenPx: Int): Int = (screenPx * 3f).toInt().coerceIn(1800, 3200)

        /** Siyahı daxilindəki kiçik oxuyucu üçün: ekran enindən 2 dəfə (yaddaş qənaəti). */
        fun inlineWidth(screenPx: Int): Int = (screenPx * 2f).toInt().coerceIn(1400, 2200)
    }

    private val widthPx = widthPx

    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    // keş bayt ilə ölçülür (böyük səhifələr üçün): ən azı 2 səhifə
    private val cache = object : LruCache<Int, Bitmap>(cacheBytes.coerceAtLeast(2 * 48 * 1024 * 1024).coerceAtMost((Runtime.getRuntime().maxMemory() / 2).toInt())) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.allocationByteCount
    }
    private var closed = false

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PageVH(newPhotoView(parent))
    override fun getItemCount() = renderer.pageCount

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        holder.job?.cancel()
        val cached = cache.get(position)
        if (cached != null) {
            holder.img.setImageBitmap(cached)
            return
        }
        holder.img.setImageDrawable(null)
        holder.job = scope.launch {
            val bmp = withContext(Dispatchers.IO) { render(position) } ?: return@launch
            cache.put(position, bmp)
            if (holder.bindingAdapterPosition == position) holder.img.setImageBitmap(bmp)
        }
    }

    override fun onViewRecycled(holder: PageVH) {
        holder.job?.cancel()
    }

    private fun render(i: Int): Bitmap? = synchronized(renderer) {
        if (closed) return null
        val page = renderer.openPage(i)
        try {
            var w = widthPx
            var h = (w.toFloat() * page.height / page.width).toInt()
            // GPU limiti və yaddaş həddi: nisbət saxlanılaraq kiçildilir
            val k = minOf(1f, MAX_SIDE.toFloat() / maxOf(w, h), Math.sqrt(MAX_PIXELS.toDouble() / (w.toDouble() * h)).toFloat())
            if (k < 1f) { w = (w * k).toInt(); h = (h * k).toInt() }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        } finally {
            page.close()
        }
    }

    fun close() {
        synchronized(renderer) {
            if (closed) return
            closed = true
            renderer.close()
            pfd.close()
        }
    }
}
