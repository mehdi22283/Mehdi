package az.m3u.sinayici

import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object Net {
    const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    private fun open(
        start: String,
        range: String?,
        ua: String?,
        cookie: String?,
        connectMs: Int,
        readMs: Int
    ): HttpURLConnection {
        var current = start.trim()
        var hops = 0
        while (true) {
            val u = URL(current)
            val c = u.openConnection() as HttpURLConnection
            c.connectTimeout = connectMs
            c.readTimeout = readMs
            c.instanceFollowRedirects = false
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", ua ?: UA)
            if (range != null) c.setRequestProperty("Range", range)
            if (!cookie.isNullOrEmpty()) c.setRequestProperty("Cookie", cookie)
            val code = c.responseCode
            if (code in 301..308 && code != 304 && hops < 6) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrEmpty()) throw java.io.IOException("redirect without Location")
                current = URL(u, loc).toString()
                hops++
                continue
            }
            return c
        }
    }

    /** Kanalı yoxlayır: ok / dead / unknown (HTML-dəki probeUrl ilə eyni statuslar). */
    fun probe(urlStr: String): String {
        var c: HttpURLConnection? = null
        return try {
            val low = urlStr.trim().lowercase()
            if (!low.startsWith("http://") && !low.startsWith("https://")) return "unknown"
            c = open(urlStr, "bytes=0-1023", null, null, 8000, 9000)
            val code = c.responseCode
            when {
                code in 200..299 -> {
                    val buf = ByteArray(512)
                    val n = c.inputStream.read(buf)
                    if (n <= 0) "dead"
                    else if (low.contains(".m3u8")) {
                        val head = String(buf, 0, n, Charsets.UTF_8).trimStart('\uFEFF', ' ', '\n', '\r')
                        if (head.startsWith("#EXTM3U")) "ok" else "unknown"
                    } else "ok"
                }
                code == 401 || code == 403 || code == 405 || code == 416 || code == 429 || code in 300..399 -> "unknown"
                else -> "dead"
            }
        } catch (e: Exception) {
            "dead"
        } finally {
            try { c?.disconnect() } catch (_: Exception) {}
        }
    }

    /** İlk baytadək gecikmə (ms), alınmasa -1. */
    fun ttfb(urlStr: String): Long {
        var c: HttpURLConnection? = null
        return try {
            val t0 = System.nanoTime()
            c = open(urlStr, "bytes=0-1023", null, null, 6000, 6000)
            if (c.responseCode >= 400) return -1
            c.inputStream.read()
            (System.nanoTime() - t0) / 1_000_000
        } catch (e: Exception) {
            -1
        } finally {
            try { c?.disconnect() } catch (_: Exception) {}
        }
    }

    fun fetchText(urlStr: String, ua: String? = null, cookie: String? = null): String {
        var c: HttpURLConnection? = null
        try {
            c = open(urlStr, null, ua, cookie, 15000, 30000)
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP " + c.responseCode)
            val out = ByteArrayOutputStream()
            val buf = ByteArray(16 * 1024)
            val max = 25 * 1024 * 1024
            c.inputStream.use { ins ->
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > max) throw java.io.IOException("fayl çox böyükdür")
                }
            }
            return out.toString("UTF-8")
        } finally {
            try { c?.disconnect() } catch (_: Exception) {}
        }
    }

    fun looksLikePlaylist(text: String): Boolean {
        val t = text.trimStart('\uFEFF', ' ', '\n', '\r')
        return t.startsWith("#EXTM3U") || t.contains("#EXTINF")
    }

    /** Tək HLS axını (kanallar siyahısı yox). */
    fun isStreamPlaylist(text: String): Boolean =
        text.contains("#EXT-X-TARGETDURATION") || text.contains("#EXT-X-STREAM-INF") || text.contains("#EXT-X-MEDIA-SEQUENCE")

    fun countChannels(text: String): Int = Regex("(?im)^#EXTINF").findAll(text).count()
}
