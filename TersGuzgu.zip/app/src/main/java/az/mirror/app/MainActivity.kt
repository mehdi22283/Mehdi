package az.mirror.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Outline
import android.os.Bundle
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var holder: FrameLayout
    private lateinit var preview: PreviewView
    private lateinit var btnMirror: Button
    private lateinit var btnLight: Button

    private var reversed = false
    private var lightOn = false

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera()
            else Toast.makeText(this, "Kamera icazəsi lazımdır", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        holder = findViewById(R.id.holder)
        preview = findViewById(R.id.preview)
        btnMirror = findViewById(R.id.btnMirror)
        btnLight = findViewById(R.id.btnLight)

        // TextureView işlətsin ki, çevirmə (scaleX) düzgün işləsin
        preview.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        preview.scaleType = PreviewView.ScaleType.FILL_CENTER

        holder.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val r = if (lightOn) 28 * resources.displayMetrics.density else 0f
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        holder.clipToOutline = true

        btnMirror.setOnClickListener { toggleReverse() }
        btnLight.setOnClickListener { toggleLight() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else permLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val prev = Preview.Builder().build().also {
                it.setSurfaceProvider(preview.surfaceProvider)
            }
            provider.unbindAll()
            try {
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, prev)
            } catch (e: Exception) {
                Toast.makeText(this, "Ön kamera açılmadı", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // Normal selfi = güzgü kimi. Tərs güzgü = başqalarının səni gördüyü kimi (üfüqi çevrilmə)
    private fun toggleReverse() {
        reversed = !reversed
        preview.scaleX = if (reversed) -1f else 1f
        btnMirror.text = if (reversed) "🔄 Tərs güzgü: AÇIQ" else "🔄 Tərs güzgü"
    }

    // Xiaomi stili: parlaqlıq maksimum, qıraqlar ağ işıq
    private fun toggleLight() {
        lightOn = !lightOn
        val margin = (if (lightOn) 64 else 0) * resources.displayMetrics.density
        val lp = holder.layoutParams as FrameLayout.LayoutParams
        lp.setMargins(margin.toInt(), margin.toInt(), margin.toInt(), margin.toInt() + if (lightOn) (40 * resources.displayMetrics.density).toInt() else 0)
        holder.layoutParams = lp
        holder.invalidateOutline()
        root.setBackgroundColor(if (lightOn) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())

        val attrs = window.attributes
        attrs.screenBrightness =
            if (lightOn) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = attrs
        btnLight.text = if (lightOn) "💡 Işıq: AÇIQ" else "💡 Işıq"
    }
}
