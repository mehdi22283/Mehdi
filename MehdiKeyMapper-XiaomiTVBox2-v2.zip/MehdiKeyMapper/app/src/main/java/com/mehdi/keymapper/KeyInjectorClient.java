package com.mehdi.keymapper;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.KeyEvent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

public final class KeyInjectorClient {
    private static final int SHIZUKU_REQUEST_CODE = 4451;
    private static final Object LOCK = new Object();
    private static IKeyInjector remote;
    private static Context appContext;
    private static ServiceConnection connection;
    private static final ExecutorService COMMANDS = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "KeyMapper-Shizuku");
        t.setDaemon(true);
        return t;
    });

    private static final Shizuku.UserServiceArgs USER_SERVICE_ARGS =
            new Shizuku.UserServiceArgs(new ComponentName(Config.PACKAGE_NAME, PrivilegedUserService.class.getName()))
                    .daemon(true)
                    .tag("MehdiKeyMapperInjector")
                    .version(1);

    private KeyInjectorClient() {}

    public static void init(Context context) {
        appContext = context.getApplicationContext();
        try {
            if (Shizuku.pingBinder()) {
                onShizukuBinderReady();
            }
        } catch (Throwable ignored) {}
    }

    public static boolean isAvailable() {
        synchronized (LOCK) {
            try {
                return remote != null && remote.ping();
            } catch (Throwable ignored) {
                return false;
            }
        }
    }

    public static boolean hasShizukuPermission() {
        try {
            return !Shizuku.isPreV11() &&
                    Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static void requestPermission() {
        try {
            if (!Shizuku.isPreV11() && Shizuku.pingBinder() && !hasShizukuPermission()) {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE);
            }
        } catch (Throwable ignored) {}
    }

    public static boolean inject(KeyEvent event) {
        synchronized (LOCK) {
            if (remote == null) return false;
            try {
                return remote.inject(event);
            } catch (RemoteException | RuntimeException ignored) {
                return false;
            }
        }
    }

    public static void execAsync(String command) {
        synchronized (LOCK) {
            if (remote == null) return;
        }
        COMMANDS.execute(() -> {
            synchronized (LOCK) {
                if (remote == null) return;
                try {
                    remote.exec(command);
                } catch (Throwable ignored) {}
            }
        });
    }

    public static String execBlocking(String command) {
        synchronized (LOCK) {
            if (remote == null) return "";
            try {
                return remote.exec(command);
            } catch (Throwable ignored) {
                return "";
            }
        }
    }

    public static void onShizukuBinderReady() {
        Context context = appContext;
        if (context == null) return;
        try {
            if (!hasShizukuPermission()) return;
            synchronized (LOCK) {
                if (remote != null) return;
                if (connection == null) {
                    connection = new ServiceConnection() {
                        @Override
                        public void onServiceConnected(ComponentName name, IBinder service) {
                            synchronized (LOCK) {
                                remote = IKeyInjector.Stub.asInterface(service);
                            }
                        }

                        @Override
                        public void onServiceDisconnected(ComponentName name) {
                            synchronized (LOCK) {
                                remote = null;
                            }
                        }
                    };
                }
                Shizuku.bindUserService(USER_SERVICE_ARGS, connection);
            }
        } catch (Throwable ignored) {}
    }

    public static void onShizukuBinderDead() {
        synchronized (LOCK) {
            remote = null;
        }
    }
}
