package az.zengyazici;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Environment;
import android.provider.CallLog;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Xiaomi (və digər) daxili zəng yazıcısının fayllarını tətbiqin siyahısına əlavə edir. */
public class Importer {
    static final String[] DIRS = {"MIUI/sound_recorder/call_rec", "Recordings/Call", "Recordings/call_rec",
            "CallRecordings", "Call", "Music/Recordings/Call"};
    static final String[] EXT = {".mp3", ".m4a", ".amr", ".aac", ".wav", ".ogg", ".3gp", ".opus"};

    public static boolean canRead(Context c) {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    public static synchronized int run(Context c) {
        try {
            if (!canRead(c)) return 0;
            SharedPreferences sp = c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
            Set<String> done = new HashSet<>(sp.getStringSet("imp", new HashSet<String>()));
            File out = c.getExternalFilesDir("calls");
            if (out == null) return 0;
            out.mkdirs();
            int n = 0;
            for (String d : DIRS) {
                File[] fs = new File(Environment.getExternalStorageDirectory(), d).listFiles();
                if (fs == null) continue;
                for (File f : fs) {
                    if (!f.isFile()) continue;
                    String low = f.getName().toLowerCase();
                    String ext = null;
                    for (String e : EXT) if (low.endsWith(e)) ext = e;
                    if (ext == null) continue;
                    if (System.currentTimeMillis() - f.lastModified() < 5000) continue;
                    String key = f.getAbsolutePath() + "|" + f.length();
                    if (done.contains(key)) continue;

                    String base = f.getName().substring(0, f.getName().length() - ext.length());
                    String num = "";
                    Matcher m = Pattern.compile("\\(([+\\d][\\d\\s-]*)\\)").matcher(base);
                    if (m.find()) num = m.group(1);
                    else {
                        m = Pattern.compile("^([+\\d][\\d\\s-]{5,})").matcher(base);
                        if (m.find()) num = m.group(1);
                        else { int u = base.indexOf('_'); if (u > 0) num = base.substring(0, u); }
                    }
                    String dir = "out";
                    long mod = f.lastModified();
                    if (c.checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED) {
                        try (Cursor cur = c.getContentResolver().query(CallLog.Calls.CONTENT_URI,
                                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.TYPE},
                                CallLog.Calls.DATE + "<=? AND " + CallLog.Calls.DATE + ">?",
                                new String[]{"" + mod, "" + (mod - 2 * 3600000L)},
                                CallLog.Calls.DATE + " DESC LIMIT 1")) {
                            if (cur != null && cur.moveToFirst()) {
                                dir = cur.getInt(1) == CallLog.Calls.INCOMING_TYPE ? "in" : "out";
                                String cn = cur.getString(0);
                                if (num.isEmpty() && cn != null) num = cn;
                            }
                        } catch (Exception e) { }
                    }
                    File dst = new File(out, mod + "__tel__" + dir + "__" + Rec.clean(num) + "__xiaomi" + ext);
                    try (InputStream is = new FileInputStream(f); OutputStream os = new FileOutputStream(dst)) {
                        byte[] buf = new byte[16384];
                        int r;
                        while ((r = is.read(buf)) > 0) os.write(buf, 0, r);
                        done.add(key);
                        n++;
                    } catch (Exception e) { dst.delete(); }
                }
            }
            sp.edit().putStringSet("imp", done).apply();
            return n;
        } catch (Exception e) {
            return 0;
        }
    }
}
