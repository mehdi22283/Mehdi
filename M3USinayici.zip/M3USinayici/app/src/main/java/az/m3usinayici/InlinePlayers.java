package az.m3usinayici;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;

import java.util.HashMap;
import java.util.Map;

/**
 * Səhifədəki "yer tutucu" iframe-lərin üstünə yerləşdirilən daxili (inline) ExoPlayer-lər.
 * Yalnız ekranda görünənlər üçün oynadıcı yaradılır, görünməyəndə buraxılır.
 */
public class InlinePlayers {

    private static final int MAX_ACTIVE = 4;

    private static class Item {
        int id;
        String url;
        String title;
        PlayerView view;
        ExoPlayer player;
        int attempt;
        boolean hls;
        int x, y, w, h;
        Rect clip = new Rect();
        boolean visible;
    }

    private final Activity activity;
    private final FrameLayout root;
    private final float density;
    private final Map<Integer, Item> items = new HashMap<>();
    private DefaultHttpDataSource.Factory http;

    public InlinePlayers(Activity activity, FrameLayout root) {
        this.activity = activity;
        this.root = root;
        this.density = activity.getResources().getDisplayMetrics().density;
    }

    private DefaultHttpDataSource.Factory http() {
        if (http == null) {
            http = new DefaultHttpDataSource.Factory()
                    .setAllowCrossProtocolRedirects(true)
                    .setConnectTimeoutMs(15000)
                    .setReadTimeoutMs(20000)
                    .setUserAgent(NativeBridge.UA);
        }
        return http;
    }

    /* Bütün metodlar UI thread-də çağırılır. */

    public void open(int id, String url, String title) {
        Item it = new Item();
        it.id = id;
        it.url = url;
        it.title = title == null ? "" : title;
        items.put(id, it);
    }

    public void close(int id) {
        Item it = items.remove(id);
        if (it != null) teardown(it);
    }

    /** JSON: [[id,x,y,w,h,cl,ct,cr,cb], ...]  (CSS piksel; c* = görünən sahə) */
    public void layout(String json) {
        JSONArray arr;
        try {
            arr = new JSONArray(json);
        } catch (Exception e) {
            return;
        }
        int active = 0;
        for (Item it : items.values()) {
            if (it.view != null) active++;
        }
        java.util.HashSet<Integer> seen = new java.util.HashSet<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONArray r = arr.optJSONArray(i);
            if (r == null || r.length() < 9) continue;
            int id = r.optInt(0);
            Item it = items.get(id);
            if (it == null) continue;
            seen.add(id);
            it.x = Math.round((float) r.optDouble(1) * density);
            it.y = Math.round((float) r.optDouble(2) * density);
            it.w = Math.round((float) r.optDouble(3) * density);
            it.h = Math.round((float) r.optDouble(4) * density);
            int cl = Math.round((float) r.optDouble(5) * density);
            int ct = Math.round((float) r.optDouble(6) * density);
            int cr = Math.round((float) r.optDouble(7) * density);
            int cb = Math.round((float) r.optDouble(8) * density);
            boolean vis = it.w > 8 && it.h > 8 && cr - cl > 8 && cb - ct > 8;
            if (vis && it.view == null) {
                if (active >= MAX_ACTIVE) vis = false;
                else {
                    create(it);
                    active++;
                }
            }
            if (!vis) {
                if (it.view != null) {
                    teardown(it);
                    active--;
                }
                continue;
            }
            it.clip.set(cl - it.x, ct - it.y, cr - it.x, cb - it.y);
            apply(it);
        }
        for (Item it : items.values()) {
            if (!seen.contains(it.id) && it.view != null) teardown(it);
        }
    }

    public void releaseAll() {
        for (Item it : items.values()) teardown(it);
    }

    public void destroy() {
        releaseAll();
        items.clear();
    }

    private void apply(Item it) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) it.view.getLayoutParams();
        if (lp.leftMargin != it.x || lp.topMargin != it.y || lp.width != it.w || lp.height != it.h) {
            lp.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
            lp.leftMargin = it.x;
            lp.topMargin = it.y;
            lp.width = it.w;
            lp.height = it.h;
            it.view.setLayoutParams(lp);
        }
        it.view.setClipBounds(new Rect(it.clip));
    }

    private void create(final Item it) {
        PlayerView v = (PlayerView) LayoutInflater.from(activity).inflate(R.layout.inline_player, root, false);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(it.w, it.h);
        lp.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
        lp.leftMargin = it.x;
        lp.topMargin = it.y;
        v.setLayoutParams(lp);
        v.setControllerShowTimeoutMs(2500);
        v.setFullscreenButtonClickListener(new PlayerView.FullscreenButtonClickListener() {
            @Override
            public void onFullscreenButtonClick(boolean isFullScreen) {
                Intent i = new Intent(activity, PlayerActivity.class);
                i.putExtra("url", it.url);
                i.putExtra("title", it.title);
                activity.startActivity(i);
            }
        });
        root.addView(v);
        it.view = v;

        DefaultRenderersFactory rf = new DefaultRenderersFactory(activity).setEnableDecoderFallback(true);
        final ExoPlayer p = new ExoPlayer.Builder(activity, rf)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(http()))
                .build();
        it.player = p;
        it.attempt = 0;
        v.setPlayer(p);
        p.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                if (it.player != p) return;
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    p.seekToDefaultPosition();
                    p.prepare();
                    return;
                }
                if (it.attempt < 2) {
                    it.attempt++;
                    start(it);
                }
            }
        });
        start(it);
    }

    private void start(Item it) {
        ExoPlayer p = it.player;
        if (p == null) return;
        MediaItem item = MediaItem.fromUri(it.url);
        boolean hlsByExt = it.url.toLowerCase().contains(".m3u8");
        if (it.attempt == 0) {
            p.setMediaItem(item);
        } else {
            boolean useHls = (it.attempt == 1) ? !hlsByExt : hlsByExt;
            MediaSource src = useHls
                    ? new HlsMediaSource.Factory(http()).createMediaSource(item)
                    : new ProgressiveMediaSource.Factory(http()).createMediaSource(item);
            p.setMediaSource(src);
        }
        p.prepare();
        p.setPlayWhenReady(true);
    }

    private void teardown(Item it) {
        if (it.view != null) {
            it.view.setPlayer(null);
            root.removeView(it.view);
            it.view = null;
        }
        if (it.player != null) {
            it.player.release();
            it.player = null;
        }
    }
}
