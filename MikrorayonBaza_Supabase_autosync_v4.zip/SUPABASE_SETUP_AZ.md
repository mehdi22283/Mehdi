# Mikrorayon Baza — Supabase qoşulma təlimatı

Bu təlimat tətbiqi Supabase-ə qoşmaq və telefondakı dəyişiklikləri avtomatik sinxronlaşdırmaq üçündür.

## 1. Supabase layihəsi yaradın

1. https://supabase.com saytında hesabınıza daxil olun.
2. **New project** seçin və layihə yaradın.
3. Layihənin **Project URL** ünvanını və API açarını layihənin API ayarlarından götürün.

## 2. Sinxronizasiya cədvəlini yaradın

Supabase panelində **SQL Editor** bölməsini açın, aşağıdakı SQL kodunu icra edin:

```sql
create table if not exists public.baza_sync (
    id text primary key,
    data jsonb not null,
    updated_at timestamptz not null default now()
);

alter table public.baza_sync enable row level security;

grant select, insert, update, delete
on table public.baza_sync to service_role;
```

Tətbiqin bu versiyası cədvəldə `id = main` sətri saxlayır; `data` sahəsində sinxronizasiya snapshot-u olur.

## 3. Tətbiqdə bağlantını qurun

1. Mikrorayon Baza tətbiqində **Supabase** düyməsinə toxunun.
2. **Project URL** sahəsinə Supabase layihənizin URL ünvanını yazın, məsələn `https://PROJECT_REF.supabase.co`.
3. API açarını açar sahəsinə daxil edin.
4. **Bağlantını yoxla** düyməsinə toxunun. Bağlantı uğurludursa, ayarları yadda saxlayın.
5. **Dəyişiklik olanda avtomatik yüklə** seçimi aktiv qalsın.

## 4. Avtomatik və əl ilə sinxronlaşdırma

- Telefonda qeyd redaktə etmək, əlavə etmək, silmək, ad dəyişmək və import etmək kimi dəstəklənən dəyişikliklər yadda saxlandıqdan sonra avtomatik olaraq Supabase-ə yüklənir.
- Avtomatik yükləmə qısa gecikmə ilə işləyir; internet bağlantısı yoxdursa xəta göstərilə bilər. Bağlantı bərpa olunanda dəyişiklik edin və ya **Upload** düyməsindən istifadə edin.
- **Upload** telefondakı dəyişiklikləri serverə göndərir.
- **Download** serverdəki dəyişiklikləri telefona tətbiq edir. Endirmə zamanı yerli dəyişikliklərin server versiyası ilə əvəzlənə biləcəyini nəzərə alın.
- İlk dəfə istifadə edəndə telefondakı bazanı serverə göndərmək üçün **Upload** seçin. Boş serverdən **Download** etməyin.

## 5. Təhlükəsizlik

`service_role` və `sb_secret_...` açarları yüksək səlahiyyətlidir və RLS qaydalarını keçə bilər. Bu açarı Android tətbiqində saxlamaq yalnız şəxsi/test istifadəsi üçün münasibdir. APK-nı başqaları ilə paylaşmayın və açarı ictimai yerə yerləşdirməyin. İstehsalatda açarı server tərəfdə saxlayan aralıq API və istifadəçi autentifikasiyası qurulmalıdır.
