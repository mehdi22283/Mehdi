package com.example.tvopen;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.TextView;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        // Arxa planda brauzeri aça bilmək üçün "digər tətbiqlərin üstündə göstər" icazəsi
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) { }
        }

        Intent s = new Intent(this, OpenService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s);
        else startService(s);

        TextView t = new TextView(this);
        t.setTextSize(28);
        t.setGravity(Gravity.CENTER);
        t.setPadding(60, 60, 60, 60);
        t.setText("Filmə bax aktivdir\n\nTelefonda brauzerə yaz:\n\n"
                + getIp() + ":" + OpenService.PORT + "/google.com\n\n"
                + "http:// və https:// hər ikisi işləyir\n(Arxa planda da işləyir)");
        setContentView(t);
    }

    private String getIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) { }
        return "TV_IP";
    }
}
