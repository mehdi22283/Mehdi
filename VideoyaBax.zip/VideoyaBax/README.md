# Videoya bax (Android TV)

TV-yə quraşdırılır. Telefon brauzerində `TV_IP:3169` açılır, video seçilir, TV-də oynayır.

APK yığmaq: Android Studio ilə açın → Build > Build APK(s), və ya GitHub-a yükləyin (Actions avtomatik yığır).
Nəticə: app/build/outputs/apk/debug/Videoya-bax.apk
