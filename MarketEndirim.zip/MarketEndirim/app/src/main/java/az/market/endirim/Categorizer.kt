package az.market.endirim

import java.util.Locale

/** Məhsul adına görə kateqoriya təyin edir və axtarış üçün mətni normallaşdırır (ə→e, ı→i, ş→s ...). */
object Categorizer {

    const val OTHER = "Digər"

    // ---- Əsas kateqoriyalar ----
    const val G_FOOD = "Ərzaq və Qida Məhsulları"
    const val G_DRINK = "İçkilər"
    const val G_CARE = "Şəxsi Baxım və Gigiyena"
    const val G_CLEAN = "Məişət Kimyası və Təmizlik"
    const val G_HOME = "Ev, Mətbəx və Digər Mallar"

    // ---- Alt kateqoriyalar ----
    const val MEAT = "Ət və dəniz məhsulları"
    const val DAIRY = "Süd və süd məhsulları"
    const val FRUIT = "Meyvələr"
    const val VEG = "Tərəvəzlər"
    const val HERBS = "Göyərti"
    const val DRY = "Quru qidalar və dənli bitkilər"
    const val BREAD = "Çörək və un məmulatları"
    const val SWEETS = "Şirniyyat və çərəzlər"
    const val OILS = "Yağlar, ədviyyat və souslar"
    const val CANNED = "Konservlər"
    const val SOFT = "Alkoqolsuz içkilər"
    const val HOT = "İsti içkilər"
    const val ALCO = "Alkoqollu içkilər"
    const val ORAL = "Ağız boşluğuna qulluq"
    const val BODY = "Duş və bədən baxımı"
    const val BABY = "Qadın və uşaq gigiyenası"
    const val COSMETIC = "Kosmetika və ətir"
    const val LAUNDRY = "Yuyucu vasitələr"
    const val CLEANERS = "Təmizlik vasitələri"
    const val KITCHEN = "Mətbəx və birdəfəlik əşyalar"
    const val STATIONERY = "Xırdavat və kantselyariya"
    const val PETS = "Heyvan malları"

    /** Əsas kateqoriya → alt kateqoriyalar (göstərilmə sırası). "Digər" göstərilmir. */
    val GROUPS: List<Pair<String, List<String>>> = listOf(
        G_FOOD to listOf(MEAT, DAIRY, FRUIT, VEG, HERBS, DRY, BREAD, SWEETS, OILS, CANNED),
        G_DRINK to listOf(SOFT, HOT, ALCO),
        G_CARE to listOf(ORAL, BODY, BABY, COSMETIC),
        G_CLEAN to listOf(LAUNDRY, CLEANERS),
        G_HOME to listOf(KITCHEN, STATIONERY, PETS)
    )

    /** Bütün alt kateqoriyalar bir siyahıda (ORDER). */
    val ORDER: List<String> = GROUPS.flatMap { it.second }

    private val GROUP_OF: Map<String, String> = GROUPS.flatMap { (g, subs) -> subs.map { it to g } }.toMap()

    fun groupOf(sub: String): String? = GROUP_OF[sub]

    /** Bu sıra ilə yoxlanılır (əvvəlkilər üstünlük təşkil edir: məs. "Fairy limon" → Təmizlik, "Süd şokoladı" → Şirniyyat). */
    private val RULES: List<Pair<String, List<String>>> = listOf(
        BABY to listOf(
            "usaq", "pampers", "huggies", "bebek", "baby", "bebelac", "nutrilon", "hipp", "pyure", "mamalac",
            "islak", "gigiyenik", "tampon", "always", "ped", "bez"
        ),
        LAUNDRY to listOf(
            "persil", "ariel", "tide", "lenor", "comfort", "vanish", "pemolux", "yuyucu", "tozu",
            "agardici", "yumsaldici", "javel"
        ),
        KITCHEN to listOf(
            "folqa", "plyonka", "strec", "pergament", "firin", "birdefelik", "qacaq", "stakan", "pakel"
        ),
        CLEANERS to listOf(
            "fairy", "domestos", "qabyuyan", "temizlik", "salfet", "pecetka", "kagiz", "sunger", "zibil",
            "aerozol", "sprey", "mayesi", "silen", "temizleyici"
        ),
        ORAL to listOf("colgate", "dis", "mecun", "firca", "yaxalayici", "listerine", "blend", "sensodyne"),
        BODY to listOf(
            "sampun", "shampoo", "balzam", "sabun", "dus", "gel", "beden", "nivea", "dove", "tiras", "razor", "gillette"
        ),
        COSMETIC to listOf(
            "krem", "parfum", "etir", "tualet", "dezodorant", "deodorant", "makiyaj", "kosmetik", "pomada", "losyon", "maska", "lak"
        ),
        PETS to listOf("heyvan", "pisik", "whiskas", "pedigree", "felix", "friskies", "kitekat", "it", "kopek", "qum"),
        STATIONERY to listOf("defter", "qelem", "batareya", "lampa", "ampul", "alet", "tamir", "oyuncaq", "kantselyariya"),
        CANNED to listOf("konserv", "tomat", "tursu", "zeytun", "sprot"),
        MEAT to listOf("dondurulmus", "donmus", "pelmen", "nugget", "frozen", "manti"),
        SWEETS to listOf(
            "sokolad", "konfet", "pecenye", "biskvit", "vafli", "tort", "keks", "halva", "paxlava", "saqqiz", "dondurma",
            "cips", "chips", "cerez", "qoz", "findiq", "badam", "snickers", "bounty", "mars", "twix", "milka", "oreo", "nutella",
            "krujka", "draje", "marmelad", "zefir", "napoleon", "roll", "bar", "cokolad", "ceviz", "kisamis", "innab", "quru"
        ),
        ALCO to listOf("pive", "sarab", "caxir", "araq", "konyak", "viski", "vodka", "likor", "bira"),
        HOT to listOf("cay", "cayi", "caylar", "qehve", "nescafe", "jacobs", "lipton", "ahmad", "akbar", "kakao", "kofe", "coffee", "tea"),
        SOFT to listOf(
            "cola", "coca", "kola", "fanta", "sprite", "pepsi", "cappy", "mirinda", "schweppes", "sire", "limonad", "nektar",
            "kompot", "icki", "su", "mineral", "nabran", "sirab", "badamli", "qazli", "enerji", "energy", "redbull", "burn",
            "flash", "tonik", "kvas", "sok", "juice", "icecek"
        ),
        DAIRY to listOf(
            "sud", "qaymaq", "xama", "qatiq", "ayran", "pendir", "kefir", "yogurt", "jogurt", "yumurta", "smetana", "danone",
            "activia", "milk", "marqarin", "motal", "suzme", "kesmik", "sor", "yag", "yagi", "yagli", "yaglar", "gunebaxan", "kereyagi"
        ),
        MEAT to listOf(
            "et", "mal", "qoyun", "toyuq", "quş", "qus", "kolbasa", "sosis", "sucuk", "kabab", "qiyma", "dana", "hind",
            "vetchina", "sosiska", "qanad", "file", "kotlet", "pastrami", "ciyer", "bud",
            "baliq", "qizilbaliq", "siyenek", "kalmar", "krevet", "ikra", "tuna", "sardina", "hamsi", "kilka", "xalvar"
        ),
        BREAD to listOf("corek", "lavas", "tendir", "bulka", "xemir", "baton", "kruasan", "simit", "toast", "bagel", "bismis"),
        OILS to listOf("duz", "istiot", "ketcap", "ketchup", "mayonez", "sirke", "sous", "edviyyat", "zerdecal", "darcin"),
        DRY to listOf(
            "duyu", "makaron", "spagetti", "yarma", "mercimek", "lobya", "noxud", "un", "seker", "bal", "murebbe",
            "bugda", "qarabogday", "bulqur", "noodle", "dosirak", "fasilye", "pasta"
        ),
        HERBS to listOf(
            "ceferi", "kesnis", "suyud", "reyhan", "nane", "terxun", "roka", "kahi", "ispanaq", "kereviz", "aysberq", "pazi",
            "goyerti", "gogerti"
        ),
        VEG to listOf(
            "kartof", "sogan", "sarimsaq", "pomidor", "xiyar", "badimcan", "biber", "kok", "yerkoku", "kelem", "brokoli",
            "brusel", "cugundur", "turp", "salgam", "balqabaq", "kabak", "qargidali", "gobelek", "terevez", "yasil"
        ),
        FRUIT to listOf(
            "alma", "armud", "banan", "nar", "uzum", "saftali", "nektarin", "erik", "gavali", "alca", "gilas", "cilek", "moruq",
            "boyurtken", "qaragile", "heyva", "ayva", "encir", "xurma", "karalyok", "zogal", "kivi", "ananas", "mango", "papaya",
            "marakuya", "avokado", "kokos", "qarpiz", "yemis", "meyve", "albali", "enar",
            "portagal", "mandarin", "limon", "laym", "qreypfrut", "pomelo", "kinkan", "klementin", "sitrus"
        )
    )

    /** Hər iki ad forması tək hərfli işarələrdən asılı olmayaraq eyni sayılsın deyə dublikat açarı: yalnız hərf və rəqəmlər. */
    fun dedupKey(name: String): String {
        val n = norm(name)
        val sb = StringBuilder(n.length)
        for (ch in n) if (ch.isLetterOrDigit()) sb.append(ch)
        return sb.toString()
    }

    private val OIL_KINDS = listOf("qargidal", "gunebaxan", "zeytun", "kere")

    private val TOP_MEAT = listOf("sosis", "kolbas", "servelat")

    /** Kateqoriya daxilində sıralama: sosis / kolbasa / servelat ən üstdə (0), qalanları (1). */
    fun topRank(key: String, cat: String): Int =
        if (cat == MEAT && TOP_MEAT.any { key.contains(it) }) 0 else 1

    private val RULES_NORM: List<Pair<String, List<String>>> =
        RULES.map { (c, kws) -> c to kws.map { norm(it) }.distinct() }

    fun norm(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s.lowercase(Locale.ROOT)) {
            when (ch) {
                'ə' -> sb.append('e')
                'ı' -> sb.append('i')
                'ö' -> sb.append('o')
                'ü' -> sb.append('u')
                'ş' -> sb.append('s')
                'ç' -> sb.append('c')
                'ğ' -> sb.append('g')
                'ә' -> sb.append('e')       // kirill "ә" (OCR bəzən belə oxuyur)
                '\u0307' -> {}            // "İ" → "i̇" birləşən nöqtə
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /** BÜTÖV BÖYÜK HƏRFLİ OCR adlarını oxunaqlı hala gətirir: "COCA COLA 0.5L" → "Coca Cola 0.5L" (İ/I Azərbaycan qaydası ilə). */
    fun pretty(name: String): String {
        if (name.any { it.isLowerCase() }) return name
        return AzText.titleCase(name)
    }

    fun classify(name: String): String {
        val tokens = norm(name).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return OTHER
        // bitki və kərə yağları: "yağ" sözü + növü (qarğıdalı, günəbaxan, zeytun, kərə) — digər qaydalardan əvvəl yoxlanır
        if (tokens.any { it.startsWith("yag") } &&
            tokens.any { t -> OIL_KINDS.any { t.startsWith(it) } }) return DAIRY
        if (tokens.any { it == "nektarin" }) return FRUIT
        for ((cat, kws) in RULES_NORM) {
            for (kw in kws) {
                val hit = if (kw.length <= 3) tokens.any { it == kw } else tokens.any { it.startsWith(kw) }
                if (hit) return cat
            }
        }
        return OTHER
    }
}
