package az.vakansiya

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File

/** Tətbiqə əvvəlcədən əlavə edilən fayllar (CV və s.) — saytlara yükləmək üçün. */
object Files {
    private fun dir(c: Context) = File(c.filesDir, "uploads").also { it.mkdirs() }

    fun list(c: Context): List<File> =
        (dir(c).listFiles()?.filter { it.isFile } ?: emptyList()).sortedByDescending { it.lastModified() }

    /** Seçilmiş faylı (content://) tətbiqin yaddaşına kopyalayır; uğurlu olsa fayl qaytarır. */
    fun add(c: Context, src: Uri): File? {
        return try {
            var name = c.contentResolver.query(src, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            } ?: src.lastPathSegment ?: "fayl"
            name = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "fayl" }
            var out = File(dir(c), name)
            var n = 1
            while (out.exists()) {
                val base = name.substringBeforeLast('.', name)
                val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
                out = File(dir(c), "$base ($n)$ext"); n++
            }
            c.contentResolver.openInputStream(src)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } } ?: return null
            out
        } catch (e: Exception) { null }
    }

    fun uri(c: Context, f: File): Uri = FileProvider.getUriForFile(c, "az.vakansiya.files", f)

    fun mime(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"

    /** Saytın input-unun "accept" şərtinə uyğundurmu (şərt yoxdursa hamısı uyğundur). */
    fun matches(f: File, accept: Array<String>?): Boolean {
        val a = accept?.flatMap { it.split(',') }?.map { it.trim().lowercase() }?.filter { it.isNotEmpty() } ?: emptyList()
        if (a.isEmpty()) return true
        val ext = f.extension.lowercase()
        val m = mime(f)
        return a.any { t ->
            when {
                t == "*/*" -> true
                t.startsWith(".") -> ext == t.drop(1)
                t.endsWith("/*") -> m.startsWith(t.dropLast(1))
                else -> m == t
            }
        }
    }

    fun size(f: File): String {
        val b = f.length()
        return when {
            b >= 1024 * 1024 -> String.format("%.1f MB", b / 1048576.0)
            b >= 1024 -> "${b / 1024} KB"
            else -> "$b B"
        }
    }
}
