package com.zengyazici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Alarm vasitəsilə xidməti yenidən qaldırır (sistem tətbiqi bağlayıbsa). */
public class RestartReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        RecService.ensure(c);
    }
}
