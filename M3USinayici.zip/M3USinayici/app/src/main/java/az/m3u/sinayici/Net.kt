package az.m3u.sinayici

import android.net.Uri
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Serverlər fərqli oynadıcıları fərqli qəbul edir (bəziləri brauzer UA-sını, bəziləri VLC-ni, bəziləri Referer-i rədd edir).
 * Ona görə hər link bir neçə "profil"lə sınanır; işləyən profil yadda saxlanılır.
 */
object Net {
    const val CHROME = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    class Target(val url: String, val headers: Map<String, String>, val name: String)

    private val good = ConcurrentHashMap<String, String>()
    fun markGood(url: String, name: String) { good[url] = name }

    /**
     * ExoPlayer bütün profillərlə xəta verən kanallar (açar = playlistdəki xam link).
     * Belə kanal yoxlamada həmişə 🔴 sayılır; ExoPlayer onu sonradan uğurla oynadanda siyahıdan çıxır.
     */
    private val exoFailed = ConcurrentHashMap.newKeySet<String>()
    private var prefs: android.content.SharedPreferences? = null
    fun load(sp: android.content.SharedPreferences) {
        prefs = sp
        sp.getStringSet("exoFailed", emptySet())?.let { exoFailed.addAll(it) }
    }
    private fun saveExo() { prefs?.edit()?.putStringSet("exoFailed", HashSet(exoFailed))?.apply() }
    /** Oynadıcıda (ExoPlayer/VLC) real açılmış kanallar: açılan kanal heç vaxt 🔴 sayılmır (30 dəq). */
    private val played = ConcurrentHashMap<String, Long>()
    private fun recentlyPlayed(u: String): Boolean {
        val t = played[u] ?: return false
        return System.currentTimeMillis() - t < 30 * 60_000L
    }
    fun playedOk(url: String) { if (url.isNotEmpty()) { played[url] = System.currentTimeMillis(); exoOk(url) } }
    fun playedList(): List<String> = played.keys.filter { recentlyPlayed(it) }

    fun exoFail(url: String) { if (url.isNotEmpty() && !recentlyPlayed(url) && exoFailed.add(url)) saveExo() }
    fun exoOk(url: String) { if (exoFailed.remove(url)) saveExo() }
    fun exoFailedList(): List<String> = exoFailed.toList()

    private fun canon(k: String): String = when (k.trim().lowercase()) {
        "user-agent" -> "User-Agent"
        "referer", "referrer" -> "Referer"
        "origin" -> "Origin"
        else -> k.trim()
    }

    fun profiles(raw: String, hdrJson: String): List<Target> {
        val parts = raw.split("|", limit = 2)
        val url = parts[0].trim()
        val ex = LinkedHashMap<String, String>()
        if (parts.size > 1) parts[1].split("&").forEach { kv ->
            val i = kv.indexOf('=')
            if (i > 0) ex[canon(kv.substring(0, i))] = Uri.decode(kv.substring(i + 1))
        }
        try {
            val o = JSONObject(hdrJson)
            for (k in o.keys()) ex[canon(k)] = o.getString(k)
        } catch (e: Exception) { }
        val u = Uri.parse(url)
        val origin = if (u.scheme != null && u.host != null) u.scheme + "://" + u.authority else ""
        fun mk(name: String, ua: String?, ref: Boolean): Target {
            val h = LinkedHashMap(ex)
            if (ua != null && !h.containsKey("User-Agent")) h["User-Agent"] = ua
            if (ref && origin.isNotEmpty()) {
                if (!h.containsKey("Referer")) h["Referer"] = "$origin/"
                if (!h.containsKey("Origin")) h["Origin"] = origin
            }
            return Target(url, h, name)
        }
        val l = ArrayList<Target>()
        if (ex.isNotEmpty()) l.add(mk("özəl", null, false))
        l.add(mk("VLC", "VLC/3.0.20 LibVLC/3.0.20", false))
        l.add(mk("standart", null, false))
        l.add(mk("okhttp", "okhttp/4.12.0", false))
        l.add(mk("Chrome", CHROME, true))
        val g = good[url]
        val gi = l.indexOfFirst { it.name == g }
        if (gi > 0) l.add(0, l.removeAt(gi))
        return l
    }

    /** Qarışıq protokollu (http↔https) yönləndirmələri də izləyir. */
    fun connect(t: Target, range: String?, timeout: Int): HttpURLConnection {
        var cur = t.url
        repeat(6) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.connectTimeout = timeout; c.readTimeout = timeout; c.instanceFollowRedirects = false
            for ((k, v) in t.headers) c.setRequestProperty(k, v)
            if (range != null) c.setRequestProperty("Range", range)
            val code = c.responseCode
            if (code in 300..399 && code != 304) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc == null) throw IOException("redirect without location")
                cur = URL(URL(cur), loc).toString()
            } else return c
        }
        throw IOException("too many redirects")
    }

    /** Məzmun #EXTM3U ilə başlayırsa HLS-dir (uzantısı olmayan linklər üçün). */
    fun isHls(t: Target): Boolean {
        val c = connect(t, "bytes=0-31", 8000)
        try {
            val b = ByteArray(7); var r = 0
            c.inputStream.use { s ->
                while (r < 7) { val n = s.read(b, r, 7 - r); if (n < 0) break; r += n }
            }
            return String(b, 0, r) == "#EXTM3U"
        } finally { c.disconnect() }
    }

    private fun readHead(c: HttpURLConnection, n: Int): ByteArray {
        val b = ByteArray(n); var r = 0
        try {
            c.inputStream.use { st ->
                while (r < n) { val k = st.read(b, r, n - r); if (k < 0) break; r += k }
            }
        } catch (e: java.net.SocketTimeoutException) { /* yavaş canlı yayım: gələn baytlar kifayətdir */ }
        return b.copyOf(r)
    }

    /** Server Range-i rədd edirsə (400/403/405/416/501) eyni sorğu Range-siz təkrarlanır. */
    private fun openRange(t: Target, range: String?, timeout: Int): HttpURLConnection {
        var c = connect(t, range, timeout)
        if (range != null && c.responseCode in intArrayOf(400, 403, 405, 416, 501)) { c.disconnect(); c = connect(t, null, timeout) }
        return c
    }

    private fun resolve(base: String, ref: String): String? = try { URL(URL(base), ref).toString() } catch (e: Exception) { null }

    /**
     * Dərin yoxlama: 2xx + HTML xəta səhifəsi deyil + gövdə boş deyil.
     * HLS-dirsə (#EXTM3U) manifestin içindəki variant/seqment də açılır — manifest işləsə də seqmentlər 404 olan kanallar 🔴 sayılır.
     */
    private fun checkTarget(t: Target, timeout: Int, depth: Int): Boolean {
        val c = openRange(t, "bytes=0-65535", timeout)
        try {
            if (c.responseCode !in 200..299) return false
            val ct = (c.contentType ?: "").lowercase()
            val head = readHead(c, 65536)
            if (head.isEmpty()) return false
            val txt = String(head, Charsets.UTF_8).trimStart('\uFEFF', ' ', '\t', '\r', '\n')
            if (txt.startsWith("#EXTM3U")) {
                if (depth >= 3) return true
                val uris = txt.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
                if (uris.isEmpty()) return false
                val master = txt.contains("#EXT-X-STREAM-INF")
                val cand = if (master) uris.take(2) else listOf(uris.first(), uris.last()).distinct()
                for (u in cand) {
                    val abs = resolve(t.url, u) ?: continue
                    val ok = try { checkTarget(Target(abs, t.headers, t.name), timeout, depth + 1) } catch (e: Exception) { false }
                    if (ok) return true
                }
                return false
            }
            val low = txt.take(20).lowercase()
            if (ct.contains("text/html") || low.startsWith("<!doctype") || low.startsWith("<html")) return false
            if (ct.contains("mpegurl")) return false   // başlıq manifest deyir, gövdə başqa şey
            return true
        } finally { c.disconnect() }
    }

    /**
     * Hər profil sınanır (bir profilin xətası digərlərini kəsmir); yavaş/vaxt aşımı olarsa uzun timeout ilə 2-ci dövr.
     * Oynadıcıda açılmış kanal həmişə "ok"; ExoPlayer heç açmayıbsa "dead".
     */
    fun probe(raw: String, hdrJson: String, verifyHls: Boolean = false): String {
        if (recentlyPlayed(raw)) return "ok"
        if (exoFailed.contains(raw)) return "dead"   // ExoPlayer bu kanalı heç açammayıb
        for (attempt in 0..1) {
            var slow = false
            val timeout = if (attempt == 0) 9000 else 16000
            profiles@ for (p in profiles(raw, hdrJson)) {
                try {
                    if (checkTarget(p, timeout, 0)) { markGood(p.url, p.name); return "ok" }
                } catch (e: java.net.UnknownHostException) { slow = true; break@profiles }
                catch (e: java.net.SocketTimeoutException) { slow = true }
                catch (e: Exception) { }
            }
            if (!slow) break
        }
        return "dead"
    }
}
