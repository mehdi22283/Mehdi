package az.vakansiya

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONTokener
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Arxa planda saytları yoxlayır; yeni elan linki tapılsa bildiriş göndərir. */
class CheckWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {

    override fun doWork(): Result {
        val c = applicationContext
        val sites = Store.load(c).filter { !it.skip }
        if (sites.isEmpty()) return Result.success()
        val main = Handler(Looper.getMainLooper())
        val latch = CountDownLatch(sites.size)
        val results = ConcurrentHashMap<String, List<String>>()
        val wvs = ConcurrentHashMap<Int, WebView>()
        val done = Array(sites.size) { AtomicBoolean(false) }

        fun finish(i: Int) {
            if (done[i].compareAndSet(false, true)) {
                try { wvs[i]?.destroy() } catch (e: Exception) { }
                latch.countDown()
            }
        }

        main.post {
            sites.forEachIndexed { i, s ->
                try {
                    val w = WebView(c)
                    w.settings.javaScriptEnabled = true
                    w.settings.domStorageEnabled = true
                    w.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(v: WebView, u: String) {
                            main.postDelayed({
                                if (!done[i].get()) {
                                    v.evaluateJavascript(Links.js(Store.careful(s.url))) { r ->
                                        try {
                                            val str = JSONTokener(r).nextValue() as String
                                            val arr = JSONArray(str)
                                            val l = ArrayList<String>()
                                            for (k in 0 until arr.length()) l.add(arr.getString(k))
                                            results[s.url] = l
                                        } catch (e: Exception) { }
                                        finish(i)
                                    }
                                }
                            }, 4000)
                        }
                    }
                    wvs[i] = w
                    w.loadUrl(s.url)
                    main.postDelayed({ finish(i) }, 45000)
                } catch (e: Exception) { finish(i) }
            }
        }
        latch.await(70, TimeUnit.SECONDS)
        main.post { sites.indices.forEach { finish(it) } }

        val prefs = c.getSharedPreferences("seen", Context.MODE_PRIVATE)
        for (s in sites) {
            val cur = results[s.url] ?: continue
            if (cur.size < 3) continue
            val key = "s_" + s.url
            val prevStr = prefs.getString(key, null)
            val prev = ArrayList<String>()
            if (prevStr != null) {
                try { val a = JSONArray(prevStr); for (k in 0 until a.length()) prev.add(a.getString(k)) } catch (e: Exception) { }
            }
            if (prevStr != null) {
                val seen = prev.toHashSet()
                val fresh = cur.count { it !in seen }
                if (fresh in 1..60) notify(c, s, fresh)
            }
            val merged = LinkedHashSet<String>(cur)
            merged.addAll(prev)
            val arr = JSONArray()
            merged.take(1000).forEach { arr.put(it) }
            prefs.edit().putString(key, arr.toString()).apply()
        }
        return Result.success()
    }

    private fun notify(c: Context, s: Site, n: Int) {
        val nm = NotificationManagerCompat.from(c)
        if (!nm.areNotificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("vak", "Yeni vakansiyalar", NotificationManager.IMPORTANCE_DEFAULT)
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val id = s.url.hashCode()
        val intent = Intent(c, BrowserActivity::class.java)
            .putExtra("base", s.url).putExtra("start", s.url).putExtra("title", s.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(c, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val nt = NotificationCompat.Builder(c, "vak")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(s.name)
            .setContentText("$n yeni elan paylaşıldı")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { nm.notify(id, nt) } catch (e: SecurityException) { }
    }
}
