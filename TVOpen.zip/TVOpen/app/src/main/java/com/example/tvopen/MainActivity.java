package com.example.tvopen;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

public class MainActivity extends Activity {
    public static final int PORT = 3169;

    private ServerSocket server;
    private volatile boolean running = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setTextSize(28);
        t.setGravity(Gravity.CENTER);
        t.setPadding(60, 60, 60, 60);
        t.setText("TV Open aktivdir\n\nTelefonda brauzerə yaz:\n\n"
                + getIp() + ":" + PORT + "/google.com\n\n"
                + "(Yalnız bu proqram açıq olanda işləyir)");
        setContentView(t);
    }

    // Proqram ekrana çıxanda server başlayır
    @Override
    protected void onStart() {
        super.onStart();
        startServer();
    }

    // Proqramdan çıxanda (və ya sayt açılanda) server dayanır
    @Override
    protected void onStop() {
        stopServer();
        super.onStop();
    }

    private void startServer() {
        if (running) return;
        running = true;
        new Thread(() -> {
            try {
                ServerSocket ss = new ServerSocket(PORT);
                ss.setReuseAddress(true);
                server = ss;
                while (running) {
                    final Socket s = ss.accept();
                    new Thread(() -> handle(s)).start();
                }
            } catch (Exception ignored) {
            }
        }, "tvopen-server").start();
    }

    private void stopServer() {
        running = false;
        try { if (server != null) server.close(); } catch (Exception ignored) { }
        server = null;
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(3000);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            String line = in.readLine(); // GET /google.com HTTP/1.1
            if (line == null) { s.close(); return; }

            String[] parts = line.split(" ");
            String path = parts.length >= 2 ? parts[1] : "/";
            String msg;

            if (path.equals("/") || path.startsWith("/favicon")) {
                msg = "TV Open isleyir. Istifade: http://TV_IP:" + PORT + "/google.com";
            } else {
                String url = path.substring(1);
                if (!url.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
                    url = "https://" + url;
                }
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    msg = "TV-de acildi: " + url;
                } catch (Exception e) {
                    msg = "Acila bilmedi (TV-de brauzer yoxdur?): " + e.getMessage();
                }
            }

            byte[] body = ("<html><head><meta charset='utf-8'>"
                    + "<meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                    + "<body style='font-family:sans-serif;font-size:20px;padding:24px'>"
                    + msg.replace("<", "&lt;") + "</body></html>")
                    .getBytes(StandardCharsets.UTF_8);
            String head = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                    + "Content-Length: " + body.length + "\r\nConnection: close\r\n\r\n";
            OutputStream out = s.getOutputStream();
            out.write(head.getBytes(StandardCharsets.UTF_8));
            out.write(body);
            out.flush();
            s.close();
        } catch (Exception ignored) {
            try { s.close(); } catch (Exception e) { }
        }
    }

    private String getIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) { }
        return "TV_IP";
    }
}
