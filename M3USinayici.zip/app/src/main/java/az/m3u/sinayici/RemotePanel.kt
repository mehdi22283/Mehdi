package az.m3u.sinayici

import android.Manifest
import android.annotation.TargetApi
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.ConsumerIrManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executor

/**
 * Xiaomi Mi Box (2-ci nəsil) pultu — tam ekran.
 * Power / səs düymələri: telefonun IR göndəricisi ilə LG 42LF560V televizoruna (NEC protokolu).
 * Qalan düymələr: telefon Bluetooth HID (klaviatura + media düymələri) cihazı kimi Mi Box-a qoşulur.
 */
class RemotePanel(private val act: Activity) : Dialog(act, android.R.style.Theme_Material_NoActionBar_Fullscreen) {

    companion object {
        const val REQ = 4417
        /** Açıq pult paneli (MainActivity icazə nəticəsini ora ötürür). */
        @Volatile var current: RemotePanel? = null

        // LG televizorları: NEC, ünvan 0x04 (kodlar MSB-first yazılıb)
        const val LG_POWER = 0x20DF10EFL
        const val LG_VOL_UP = 0x20DF40BFL
        const val LG_VOL_DOWN = 0x20DFC03FL
        const val LG_MUTE = 0x20DF906FL
        const val LG_INPUT = 0x20DFD02FL
        const val LG_UP = 0x20DF02FDL
        const val LG_DOWN = 0x20DF827DL
        const val LG_LEFT = 0x20DFE01FL
        const val LG_RIGHT = 0x20DF609FL
        const val LG_OK = 0x20DF22DDL
        const val LG_BACK = 0x20DF14EBL

        // HID klaviatura istifadə kodları
        const val K_UP = 0x52
        const val K_DOWN = 0x51
        const val K_LEFT = 0x50
        const val K_RIGHT = 0x4F
        const val K_ENTER = 0x28

        // HID consumer istifadə kodları
        const val C_MENU = 0x0040
        const val C_PLAY_PAUSE = 0x00CD
        const val C_HOME = 0x0223
        const val C_BACK = 0x0224

        fun show(a: Activity) {
            if (current?.isShowing == true) return
            RemotePanel(a).show()
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private val ir: ConsumerIrManager? = try { act.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager } catch (e: Exception) { null }
    private var hid: HidRemote? = null
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density + 0.5f).toInt()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        window?.apply {
            addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        setContentView(buildUi())
        current = this
        setOnDismissListener { current = null; h.removeCallbacksAndMessages(null); hid?.stop(); hid = null }
        begin()
    }

    // ───────────────────────────── Bluetooth ─────────────────────────────

    private fun has(p: String) = Build.VERSION.SDK_INT < 23 || act.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun begin() {
        if (Build.VERSION.SDK_INT < 28) { setStatus("Bluetooth pult Android 9 və yuxarı tələb edir", false); return }
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            if (!has(Manifest.permission.BLUETOOTH_CONNECT)) need.add(Manifest.permission.BLUETOOTH_CONNECT)
            if (!has(Manifest.permission.BLUETOOTH_ADVERTISE)) need.add(Manifest.permission.BLUETOOTH_ADVERTISE)
        }
        if (need.isNotEmpty()) { act.requestPermissions(need.toTypedArray(), REQ); return }
        startHid()
    }

    fun onPermResult(rq: Int) {
        if (rq != REQ) return
        if (Build.VERSION.SDK_INT >= 31 && !has(Manifest.permission.BLUETOOTH_CONNECT)) {
            setStatus("Bluetooth icazəsi verilmədi", false); return
        }
        startHid()
    }

    @TargetApi(28)
    private fun startHid() {
        if (BluetoothAdapter.getDefaultAdapter() == null) { setStatus("Bu cihazda Bluetooth yoxdur", false); return }
        if (hid != null) return
        hid = HidRemote(act, h) { t, ok -> setStatus(t, ok) }.also { it.start() }
    }

    private fun setStatus(t: String, ok: Boolean) {
        if (!::status.isInitialized) return
        status.text = (if (ok) "● " else "○ ") + t
        status.setTextColor(if (ok) Color.parseColor("#3ECF8E") else Color.parseColor("#9AA3B2"))
    }

    private fun pickDevice() {
        val r = hid
        if (r == null) { toast("Bluetooth hələ hazır deyil"); return }
        val list = r.bonded()
        if (list.isEmpty()) {
            AlertDialog.Builder(act).setTitle("Cütləşmiş cihaz yoxdur")
                .setMessage("1) «Görünən et» düyməsinə basın.\n2) Mi Box-da: Ayarlar → Pultlar və aksesuarlar → Aksesuar əlavə et, siyahıdan telefonu seçin.\n3) Cütləşəndən sonra bu pəncərədə «Qoş» düyməsinə basıb Mi Box-u seçin.")
                .setPositiveButton("OK", null).show()
            return
        }
        val names = Array(list.size) { i -> r.label(list[i]) }
        AlertDialog.Builder(act).setTitle("Mi Box-u seçin").setItems(names) { _, i -> r.connect(list[i]) }
            .setNegativeButton("Ləğv et", null).show()
    }

    private fun discoverable() {
        try {
            act.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120))
        } catch (e: Exception) { toast("Görünən etmək alınmadı") }
    }

    private fun toast(t: String) = Toast.makeText(act, t, Toast.LENGTH_SHORT).show()

    // ───────────────────────────── IR (LG) ─────────────────────────────

    private fun hasIr(): Boolean {
        val ok = try { ir?.hasIrEmitter() == true } catch (e: Exception) { false }
        if (!ok) toast("Bu telefonda IR göndərici yoxdur")
        return ok
    }

    /** NEC çərçivəsi: 9ms/4.5ms başlıq, 32 bit (MSB-first), son impuls. */
    private fun nec(code: Long): IntArray {
        val p = IntArray(67)
        var i = 0
        p[i++] = 9000; p[i++] = 4500
        for (b in 31 downTo 0) {
            p[i++] = 560
            p[i++] = if (((code shr b) and 1L) == 1L) 1690 else 560
        }
        p[i] = 560
        return p
    }

    private fun irSend(code: Long) {
        try { ir?.transmit(38000, nec(code)) } catch (e: Exception) { }
    }

    private fun irBtn(v: View, code: Long, repeat: Boolean) {
        val rep = object : Runnable { override fun run() { irSend(code); h.postDelayed(this, 130) } }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.alpha = 0.6f
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    if (hasIr()) { if (repeat) h.post(rep) else irSend(code) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { view.alpha = 1f; h.removeCallbacks(rep) }
            }
            true
        }
    }

    // ───────────────────────────── Mi Box (Bluetooth) ─────────────────────────────

    private fun btBtn(v: View, consumer: Boolean, code: Int) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.alpha = 0.6f
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    val r = hid
                    if (r == null || !r.connected()) toast("Mi Box ilə Bluetooth qoşulmayıb")
                    else if (consumer) r.consumer(code, true) else r.key(code, true)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.alpha = 1f
                    val r = hid
                    if (r != null && r.connected()) { if (consumer) r.consumer(code, false) else r.key(code, false) }
                }
            }
            true
        }
    }

    // ───────────────────────────── UI ─────────────────────────────

    private fun shape(color: Int, oval: Boolean, radiusDp: Int = 16): GradientDrawable = GradientDrawable().apply {
        if (oval) setShape(GradientDrawable.OVAL) else { setShape(GradientDrawable.RECTANGLE); cornerRadius = dp(radiusDp).toFloat() }
        setColor(color)
    }

    private fun circle(text: String, size: Int, color: Int, sp: Float = 20f): TextView = TextView(act).apply {
        this.text = text; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = sp
        background = shape(color, true)
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).also { it.setMargins(dp(6), dp(6), dp(6), dp(6)) }
    }

    private fun label(t: String): TextView = TextView(act).apply {
        text = t; setTextColor(Color.parseColor("#7C8696")); textSize = 12f
        setPadding(dp(4), dp(14), dp(4), dp(2)); gravity = Gravity.CENTER
    }

    private fun row(vararg views: View): LinearLayout = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
        views.forEach { addView(it) }
    }

    private fun spacer(size: Int): View = View(act).apply {
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).also { it.setMargins(dp(6), dp(6), dp(6), dp(6)) }
    }

    private fun smallBtn(t: String, onClick: () -> Unit): TextView = TextView(act).apply {
        text = t; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
        setPadding(dp(14), dp(9), dp(14), dp(9))
        background = shape(Color.parseColor("#26303F"), false, 20)
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.setMargins(dp(4), 0, dp(4), 0) }
        setOnClickListener { onClick() }
    }

    private fun buildUi(): View {
        val bt = Color.parseColor("#2B3445")     // Mi Box (Bluetooth)
        val tv = Color.parseColor("#6B4410")     // TV (IR)
        val root = FrameLayout(act).apply { setBackgroundColor(Color.parseColor("#0F1115")) }
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(34), dp(16), dp(24))
        }

        // Yuxarı sətir: bağla + başlıq
        val close = TextView(act).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            background = shape(Color.parseColor("#26303F"), true)
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            setOnClickListener { dismiss() }
        }
        val title = TextView(act).apply {
            text = "Mi Box 2-ci nəsil pult"; setTextColor(Color.WHITE); textSize = 17f
            setPadding(dp(12), 0, 0, 0)
        }
        col.addView(LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(close); addView(title)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        status = TextView(act).apply {
            text = "○ Bluetooth hazırlanır…"; setTextColor(Color.parseColor("#9AA3B2")); textSize = 13f
            setPadding(dp(4), dp(12), dp(4), dp(8)); gravity = Gravity.CENTER
        }
        col.addView(status)
        col.addView(LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(smallBtn("🔵 Qoş") { pickDevice() })
            addView(smallBtn("👁 Görünən et") { discoverable() })
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // TV: Power + Mute
        col.addView(label("TELEVİZOR · LG 42LF560V (IR)"))
        val power = circle("⏻", 72, Color.parseColor("#C62828"), 28f)
        val mute = circle("🔇", 56, tv, 20f)
        val input = circle("INPUT", 56, tv, 11f)
        irBtn(power, LG_POWER, false); irBtn(mute, LG_MUTE, false); irBtn(input, LG_INPUT, false)
        col.addView(row(power, mute, input))

        // LG naviqasiya (IR): giriş siyahısında və TV menyusunda gəzmək üçün
        col.addView(label("LG NAVİQASİYA (IR)"))
        val lu = circle("▲", 52, tv, 16f); val ld = circle("▼", 52, tv, 16f)
        val ll = circle("◀", 52, tv, 16f); val lr = circle("▶", 52, tv, 16f)
        val lok = circle("OK", 52, Color.parseColor("#B8731A"), 14f)
        val lback = circle("↩", 52, tv, 18f)
        irBtn(lu, LG_UP, true); irBtn(ld, LG_DOWN, true); irBtn(ll, LG_LEFT, true)
        irBtn(lr, LG_RIGHT, true); irBtn(lok, LG_OK, false); irBtn(lback, LG_BACK, false)
        col.addView(row(spacer(52), lu, spacer(52)))
        col.addView(row(ll, lok, lr))
        col.addView(row(lback, ld, spacer(52)))

        // Mi Box: D-pad
        col.addView(label("MI BOX (BLUETOOTH)"))
        val up = circle("▲", 64, bt); val down = circle("▼", 64, bt)
        val left = circle("◀", 64, bt); val right = circle("▶", 64, bt)
        val ok = circle("OK", 72, Color.parseColor("#3B82F6"), 18f)
        btBtn(up, false, K_UP); btBtn(down, false, K_DOWN); btBtn(left, false, K_LEFT)
        btBtn(right, false, K_RIGHT); btBtn(ok, false, K_ENTER)
        val pad = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = shape(Color.parseColor("#171B22"), true)
            setPadding(dp(6), dp(6), dp(6), dp(6))
            addView(row(spacer(64), up, spacer(64)))
            addView(row(left, ok, right))
            addView(row(spacer(64), down, spacer(64)))
        }
        col.addView(pad)

        // Geri / Home / Menu / Play-Pause
        val back = circle("↩", 60, bt, 22f); val home = circle("⌂", 60, bt, 24f)
        val menu = circle("☰", 60, bt, 22f); val play = circle("⏯", 60, bt, 20f)
        btBtn(back, true, C_BACK); btBtn(home, true, C_HOME); btBtn(menu, true, C_MENU); btBtn(play, true, C_PLAY_PAUSE)
        col.addView(row(back, home, menu, play))

        // Səs (LG IR)
        col.addView(label("SƏS · LG (IR)"))
        val vm = circle("−", 64, tv, 28f); val vp = circle("+", 64, tv, 28f)
        irBtn(vm, LG_VOL_DOWN, true); irBtn(vp, LG_VOL_UP, true)
        col.addView(row(vm, vp))

        root.addView(ScrollView(act).apply { isFillViewport = true; addView(col) },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return root
    }
}

/** Telefonu Bluetooth HID cihazı (klaviatura + consumer control) kimi qeydiyyatdan keçirir. */
@TargetApi(28)
class HidRemote(private val ctx: Context, private val main: Handler, private val onState: (String, Boolean) -> Unit) {
    companion object {
        private const val ID_KEY = 1
        private const val ID_CONS = 2
        private val DESC: ByteArray = intArrayOf(
            // Klaviatura (Report ID 1)
            0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
            0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
            0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
            0xC0,
            // Consumer control (Report ID 2)
            0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x02,
            0x15, 0x00, 0x26, 0xFF, 0x03, 0x19, 0x00, 0x2A, 0xFF, 0x03, 0x75, 0x10, 0x95, 0x01, 0x81, 0x00,
            0xC0
        ).map { it.toByte() }.toByteArray()
    }

    private val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var proxy: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var registered = false
    private val exec = Executor { r -> main.post(r) }
    private val sp = ctx.getSharedPreferences("m3u", Context.MODE_PRIVATE)

    private val cb = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            this@HidRemote.registered = registered
            if (registered) {
                onState("Hazırdır. «Qoş» ilə Mi Box-u seçin", false)
                autoConnect()
            } else onState("Bluetooth pult qeydiyyatdan çıxdı", false)
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    try { sp.edit().putString("hidDev", device?.address).apply() } catch (e: Exception) { }
                    onState("Qoşuldu: " + (device?.let { label(it) } ?: "Mi Box"), true)
                }
                BluetoothProfile.STATE_CONNECTING -> onState("Qoşulur…", false)
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (device == null || device == host) host = null
                    onState("Qoşulmayıb", false)
                }
            }
        }
    }

    fun start() {
        val ad = adapter ?: return
        if (!ad.isEnabled) { onState("Bluetooth söndürülüb — yandırın", false); return }
        try {
            ad.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(profile: Int, p: BluetoothProfile?) {
                    if (profile != BluetoothProfile.HID_DEVICE) return
                    proxy = p as? BluetoothHidDevice
                    val sdp = BluetoothHidDeviceAppSdpSettings("M3U Pult", "Android TV pult", "M3U",
                        BluetoothHidDevice.SUBCLASS1_COMBO, DESC)
                    try { proxy?.registerApp(sdp, null, null, exec, cb) } catch (e: SecurityException) { onState("Bluetooth icazəsi yoxdur", false) }
                }
                override fun onServiceDisconnected(profile: Int) { proxy = null; registered = false; host = null }
            }, BluetoothProfile.HID_DEVICE)
        } catch (e: SecurityException) { onState("Bluetooth icazəsi yoxdur", false) }
    }

    fun stop() {
        try { proxy?.let { if (registered) it.unregisterApp(); adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) } } catch (e: Exception) { }
        proxy = null; host = null; registered = false
    }

    fun bonded(): List<BluetoothDevice> = try { adapter?.bondedDevices?.toList() ?: emptyList() } catch (e: SecurityException) { emptyList() }

    fun label(d: BluetoothDevice): String = try { d.name ?: d.address } catch (e: SecurityException) { d.address }

    private fun autoConnect() {
        val last = sp.getString("hidDev", null) ?: return
        val d = bonded().firstOrNull { it.address == last } ?: return
        connect(d)
    }

    fun connect(d: BluetoothDevice) {
        if (!registered) { onState("Bluetooth pult hələ hazır deyil", false); return }
        try {
            val ok = proxy?.connect(d) == true
            if (!ok) onState("Qoşulmaq alınmadı — Mi Box-dan cütləşdirin", false)
        } catch (e: SecurityException) { onState("Bluetooth icazəsi yoxdur", false) }
    }

    fun connected() = host != null

    fun key(code: Int, down: Boolean) {
        val d = host ?: return
        val r = ByteArray(8)
        if (down) r[2] = code.toByte()
        try { proxy?.sendReport(d, ID_KEY, r) } catch (e: SecurityException) { }
    }

    fun consumer(usage: Int, down: Boolean) {
        val d = host ?: return
        val r = ByteArray(2)
        if (down) { r[0] = (usage and 0xFF).toByte(); r[1] = ((usage shr 8) and 0xFF).toByte() }
        try { proxy?.sendReport(d, ID_CONS, r) } catch (e: SecurityException) { }
    }
}
