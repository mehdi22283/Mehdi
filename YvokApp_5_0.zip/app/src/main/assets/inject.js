(function () {
  var timer = null, rtimer = null;

  function send(fn, a, b, c) {
    try { if (window.AndroidEbel && AndroidEbel[fn]) AndroidEbel[fn](a, b, c); } catch (e) {}
  }

  // Real format:
  // "10011MBM2046 / MUSTAFAYEV BARAT MEHDİ adına Binəqədi bələdiyyəsi üzrə olan vergi borcu: 0 manat."
  // Kodu dəqiq uyğunlaşdırdığı üçün əvvəlki sorğunun köhnə nəticəsini götürmür.
  function readResult(val) {
    var text = (document.body ? document.body.innerText : '').replace(/\u00a0/g, ' ');
    var re = new RegExp(val + '\\s*[\\/\\\\|]\\s*(.+?)\\s+ad[\\u0131i]na[^\\n]*?borcu\\s*:?\\s*(\\d[\\d ]*(?:[.,]\\d{1,2})?)', 'i');
    var m = re.exec(text);
    if (!m) return null;
    return {
      name: m[1].trim(),
      debt: m[2].replace(/ /g, '').replace(',', '.')
    };
  }

  // "Yoxla"-dan sonra səhifədə YENİ (əvvəl olmayan) "tapılmadı" tipli sətir çıxıbsa, sayt cavab verib
  var baseLines = {};
  function snapshot() {
    baseLines = {};
    ((document.body ? document.body.innerText : '') + '').split('\n').forEach(function (l) { baseLines[l.trim()] = 1; });
  }
  function notFound() {
    var ls = ((document.body ? document.body.innerText : '') + '').split('\n');
    for (var i = 0; i < ls.length; i++) {
      var l = ls[i].trim();
      if (l && !baseLines[l] && /tap[\u0131i]lmad[\u0131i]|tap[\u0131i]lmay[\u0131i]b|m[\u00f6o]vcud deyil|d[\u00fcu]zg[\u00fcu]n deyil|m[\u0259e]lumat yoxdur/i.test(l)) return true;
    }
    return false;
  }

  function watchResult(val) {
    if (rtimer) clearInterval(rtimer);
    // "Yoxla"-dan dərhal sonra nəticəni tez-tez yoxla
    (function () {
      var k = 0;
      rtimer = setInterval(function () {
        k++;
        var r = readResult(val);
        if (r) {
          clearInterval(rtimer);
          send('result', val, r.name, r.debt);
          return;
        }
        if (k > 1000) {                   // ~40 saniyə: nəticə gələnə qədər gözlənilir, əsas limit Java tərəfindədir
          clearInterval(rtimer);
          send('retry', val, 'cavab gəlmədi');   // saytın cavabı yoxdur: Java tərəfi təzə səhifədə təkrar edir
        }
        if (notFound()) {                 // sayt "tapılmadı" cavabını verdi: bu cavabdır
          clearInterval(rtimer);
          send('fail', val, 'Bu YVÖK üçün məlumat tapılmadı');
        }
      }, 40);
    })();
  }

  window.__yvokRun = function (val) {
    if (timer) clearInterval(timer);
    if (rtimer) clearInterval(rtimer);
    var n = 0, filled = false;
    timer = setInterval(function () {
      n++;
      var ins = [].slice.call(document.querySelectorAll('input')).filter(function (i) {
        return ['hidden', 'checkbox', 'radio', 'button', 'submit'].indexOf(i.type) < 0 && i.offsetParent !== null;
      });
      var inp = ins.filter(function (i) {
        return /yv[\u00f6o]k|v[\u00f6o]en/i.test((i.placeholder || '') + (i.name || '') + (i.id || ''));
      })[0] || ins[0];
      var btn = [].slice.call(document.querySelectorAll('button,input[type=submit],a,div[role=button]'))
        .filter(function (x) { return /yoxla/i.test(x.innerText || x.value || ''); })[0];

      if (inp && inp.value !== val) {
        // focus() ÇAĞIRILMIR: gizli səhifə klaviaturanı/fokusu ələ keçirməsin
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(inp, val);
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        inp.dispatchEvent(new Event('change', { bubbles: true }));
        filled = true;
      } else if (inp && inp.value === val) {
        filled = true;
      }
      if (filled && btn && !btn.disabled) {
        clearInterval(timer);
        snapshot(); btn.click(); watchResult(val);
        return;
      }
      if (n > 1000) {                   // ~40 saniyə: səhifə gec hazırlaşa bilər; əsas limit Java tərəfindədir
        clearInterval(timer);
        send('retry', val, 'forma hazır olmadı');   // səhifə hazırlaşmadı: Java tərəfi təzə səhifədə təkrar edir
      }
    }, 40);
  };
})();
