package az.market.endirim

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/** OCR sətri və koordinatları. */
data class OLine(val text: String, val l: Int, val t: Int, val r: Int, val b: Int) {
    val w get() = r - l
    val h get() = b - t
}

/**
 * OCR sətirlərindən məhsulun ADINI və NÖVÜNÜ çıxarır. Bütün marketlərdə məhsul belə yazılır:
 *   Məhsulun adı  — QALIN (tünd) şriftlə
 *   Növü          — normal şriftlə
 *   Çəkisi/həcmi  — kiçik şriftlə (lazım deyil, atılır)
 * Şriftin qalınlığı sətirin hərf xətlərinin qalınlığından ölçülür (Stroke). Qalın sətir yeni məhsul adı başlayır,
 * ondan sonrakı normal sətirlər həmin məhsulun növüdür; çəki/həcm sətirləri və ad sonundakı çəki atılır.
 */
data class NameType(val name: String, val type: String)

object ProductParser {

    private val STOP = listOf(
        "endirim", "aksiya", "kampaniya", "qiymet", "tarix", "unvan", "www", "http", "instagram", "facebook", "whatsapp",
        "kataloq", "jurnal", "supermarket", "magaza", "bonus", "kassa", "hediyye", "mehsullar", "tel", "mob", "filial",
        "bitir", "baslayir", "yeni", "super", "teklif", "sertlerle", "qaydalar", "oktyabr", "noyabr", "dekabr", "yanvar",
        "fevral", "mart", "aprel", "may", "iyun", "iyul", "avqust", "sentyabr",
        "guzest", "daha", "qenaetli", "uzvlerine", "endirimli", "secilmis", "magazalarda", "mehdud", "saydadir", "limitlidir",
        "kampaniyada", "muddeti", "yararlanmaga", "telesin", "hemcinin",
        "scm", "yalniz", "tamstore", "dek", "ela", "quvvededir", "pensiyacilara",
        "скидка", "акция", "цена", "каталог", "магазин", "бонус", "касса", "адрес", "новинка", "предложение"
    )
    private val STOP_NORM: List<String> = STOP.map { Categorizer.norm(it) }.distinct()

    /** Faiz ifadələri (-30%, 30 %, %30), valyuta işarələri və qalıqları ad mətnindən çıxarılır. */
    private val JUNK = Regex("""(?iu)(?:[-–−+]\s?\d{1,3}(?:[.,]\d+)?\s?%)|(?<![\d.,])\d{1,3}\s?%|(?<![\d.,])%\s?\d{1,3}(?![.,]\d)|(?<!\p{L})endirim\p{L}*|(?<!\p{L})-d[əe]k(?!\p{L})|₼|\bazn\b|\bman\.?(?![\p{L}])|\bqəp\.?(?![\p{L}])|\bкоп\.?(?![\p{L}])|\bруб\.?(?![\p{L}])""")
    private val NON_WORD_EDGES = charArrayOf('-', '.', ',', ':', ';', '/', ' ')
    private val SPLIT = Regex("[^\\p{L}\\p{N}]+")
    private val SPACES = Regex("\\s+")
    private val BAD_CHARS = Regex("[|_•*«»\"“”]+")

    private fun clean(raw: String): String =
        JUNK.replace(raw, " ").replace(BAD_CHARS, " ").replace(SPACES, " ").trim(*NON_WORD_EDGES)

    private fun isStopToken(tk: String): Boolean =
        STOP_NORM.any { sw -> tk == sw || (sw.length >= 5 && tk.startsWith(sw)) }

    /** Bütün sözləri reklam/xidmət sözü olan sətir ("Aksiya", "Oktyabr", "Yeni") ada qarışdırılmır. */
    private fun isNoiseLine(text: String): Boolean {
        val tokens = Categorizer.norm(clean(text)).split(SPLIT).filter { tk -> tk.length >= 3 && tk.any { it.isLetter() } }
        if (tokens.isEmpty()) return true
        return tokens.all { isStopToken(it) }
    }

    private fun isValidName(n: String): Boolean {
        val letters = n.count { it.isLetter() }
        if (letters < 3 || n.length > 70) return false
        if (letters.toFloat() / n.count { !it.isWhitespace() }.coerceAtLeast(1) < 0.6f) return false
        val tokens = Categorizer.norm(n).split(SPLIT).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return false
        return tokens.any { tk -> tk.length >= 3 && tk.any { it.isLetter() } && !isStopToken(tk) }
    }

    private val UNITS = setOf(
        "kq", "kg", "qr", "gr", "g", "q", "ml", "l", "lt", "litr", "ed", "eded", "dest", "sm", "m", "mm", "pk", "paket", "cubuq", "x",
        "кг", "г", "гр", "мл", "л", "шт", "мг", "уп"
    )
    private val NUM_UNIT_SPLIT = Regex("(?<=\\d)(?=\\p{L})|(?<=\\p{L})(?=\\d)")
    private val TRAIL_WEIGHT = Regex("""(?iu)[\s,;/-]*\d+(?:[.,]\d+)?\s*(?:[x×]\s*\d+\s*)?(?:kq|kg|qr|gr|g|q|ml|l|lt|litr|ədəd|əd|ed|dəst|sm|кг|гр|г|мл|л|шт)\.?\s*$""")

    /** Yalnız çəki/həcm/say olan sətir ("500 q", "1.5 L", "6 x 0.33 l", "10 əd") — ada qarışdırılmır. */
    private fun isWeightLine(text: String): Boolean {
        val n = Categorizer.norm(text)
        if (n.none { it.isDigit() }) return false
        val toks = NUM_UNIT_SPLIT.replace(n, " ").split(SPLIT).filter { it.isNotEmpty() }
        return toks.all { tk -> tk.any { it.isDigit() } || tk in UNITS }
    }

    private fun stripWeight(s: String): String = TRAIL_WEIGHT.replace(s, "").trim(*NON_WORD_EDGES)

    private fun related(a: OLine, b: OLine): Boolean {
        val minH = min(a.h, b.h).coerceAtLeast(1)
        val maxH = max(a.h, b.h)
        val vgap = max(a.t, b.t) - min(a.b, b.b)
        val ox = min(a.r, b.r) - max(a.l, b.l)
        val minW = min(a.w, b.w).coerceAtLeast(1)
        return vgap >= -0.25f * minH && vgap <= 0.9f * minH && ox >= 0.35f * minW && maxH <= 2.0f * minH
    }

    private const val BOLD_RATIO = 1.18f

    /**
     * Səhifədəki məhsullar: ad (qalın) + növ (normal). strokeOf — sətirin xətt qalınlığını ölçür (ölçülə bilmirsə -1).
     * Qalınlıq fərqi tapılmasa (hamısı eyni) — ilk sətir ad, qalanları növ sayılır.
     */
    fun parse(lines0: List<OLine>, pageH: Int, strokeOf: (OLine) -> Float): List<NameType> {
        val lines = lines0.filter { ln ->
            ln.text.count { it.isLetter() } >= 3 && ln.h <= 0.07f * pageH && (ln.t + ln.h / 2) <= 0.94f * pageH && !isNoiseLine(ln.text) && !isWeightLine(ln.text)
        }.sortedBy { it.t }
        val n = lines.size
        if (n == 0) return emptyList()

        val parent = IntArray(n) { it }
        fun find(x: Int): Int { var a = x; while (parent[a] != a) { parent[a] = parent[parent[a]]; a = parent[a] }; return a }
        for (i in 0 until n) {
            val a = lines[i]
            val limit = a.b + 0.9f * a.h
            for (j in i + 1 until n) {
                val b = lines[j]
                if (b.t > limit) break
                if (related(a, b)) parent[find(i)] = find(j)
            }
        }
        val groups = LinkedHashMap<Int, MutableList<OLine>>()
        for (i in 0 until n) groups.getOrPut(find(i)) { ArrayList() }.add(lines[i])

        val out = LinkedHashMap<String, NameType>()
        fun emit(nameLines: List<OLine>, typeLines: List<OLine>, pre: OLine?) {
            if (nameLines.isEmpty()) return
            val name = stripWeight(clean(nameLines.take(3).joinToString(" ") { it.text }))
            if (!isValidName(name)) return
            // növ: qalın adın üstündəki normal sətir (Oba: "Nefis Dad" + qalın "Sosis") + altındakı normal sətirlər (Bravo növü 3-4 sətirə bölünə bilir)
            val tl = ArrayList<OLine>(); if (pre != null) tl.add(pre); tl.addAll(typeLines)
            var type = stripWeight(clean(tl.take(4).joinToString(" ") { it.text }))
            if (type.count { it.isLetter() } < 2 || !isValidName(type) && Categorizer.norm(type).split(SPLIT).all { it.length < 3 || isStopToken(it) }) type = ""
            if (type.length > 70) type = ""
            out.putIfAbsent(Categorizer.norm("$name|$type"), NameType(name, type))
        }

        for (g in groups.values) {
            g.sortBy { it.t }
            val sg = g.take(6)
            val bold = BooleanArray(sg.size)
            val st = if (sg.size >= 2) sg.map { strokeOf(it) } else emptyList()
            val ref = if (st.isNotEmpty() && st.all { it > 0f }) st.min() else 0f
            if (ref > 0f && st.max() >= ref * BOLD_RATIO) {
                for (i in sg.indices) bold[i] = st[i] >= ref * BOLD_RATIO
            } else {
                // qalınlıq fərqi yoxdur / ölçülmədi: ölçüyə görə — iri sətirlər ad, xeyli kiçik sətirlər növ
                val hMax = sg.maxOf { it.h }
                for (i in sg.indices) bold[i] = sg[i].h >= 0.85f * hMax
            }
            var nameLines = ArrayList<OLine>()
            var typeLines = ArrayList<OLine>()
            var pre: OLine? = null           // qalın adın üstündəki normal sətir (Oba: "Nefis Dad" + qalın "Sosis") — adın NÖVÜdür (ad = qalın sətir)
            var namePre: OLine? = null
            for (i in sg.indices) {
                if (bold[i]) {
                    if (typeLines.isNotEmpty()) {            // növdən sonra yenidən qalın sətir — yeni məhsul
                        emit(nameLines, typeLines, namePre)
                        nameLines = ArrayList(); typeLines = ArrayList(); namePre = null
                    }
                    if (nameLines.isEmpty()) { namePre = pre; pre = null }
                    nameLines.add(sg[i])
                } else if (nameLines.isNotEmpty()) {
                    typeLines.add(sg[i])
                } else {
                    pre = sg[i]
                }
            }
            emit(nameLines, typeLines, namePre)
        }
        return out.values.toList()
    }
}

/** Sətirin hərf xətlərinin qalınlığı (sətir hündürlüyünə nisbətən) — qalın şrift daha böyük dəyər verir. */
object Stroke {
    fun of(bmp: Bitmap, ln: OLine): Float {
        val l = max(0, ln.l - 2)
        val t = max(0, ln.t)
        val r = min(bmp.width, ln.r + 2)
        val b = min(bmp.height, ln.b)
        val w = r - l
        val h = b - t
        if (w < 24 || h < 8) return -1f
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, l, t, w, h)
        fun lum(c: Int): Int = ((c shr 16 and 255) * 299 + (c shr 8 and 255) * 587 + (c and 255) * 114) / 1000
        // fon parlaqlığı: üst və alt kənar sətirlərin median dəyəri (yazı rəngindən asılı olmayaraq)
        val edge = IntArray(2 * w)
        for (x in 0 until w) { edge[x] = lum(px[x]); edge[w + x] = lum(px[(h - 1) * w + x]) }
        edge.sort()
        val bg = edge[w]
        val runs = ArrayList<Int>()
        val y0 = (h * 0.25f).toInt()
        val y1 = (h * 0.75f).toInt().coerceAtLeast(y0 + 1)
        val step = max(1, h / 12)
        val maxRun = (h * 0.5f).toInt()
        var y = y0
        while (y < y1) {
            var x = 0
            val row = y * w
            while (x < w) {
                if (Math.abs(lum(px[row + x]) - bg) > 70) {
                    var e = x
                    while (e < w && Math.abs(lum(px[row + e]) - bg) > 70) e++
                    if (e - x <= maxRun) runs.add(e - x)
                    x = e
                } else x++
            }
            y += step
        }
        if (runs.size < 8) return -1f
        runs.sort()
        val a = runs.size / 5
        val z = runs.size - a
        var sum = 0L
        for (k in a until z) sum += runs[k]
        return sum.toFloat() / (z - a).coerceAtLeast(1) / h
    }
}
