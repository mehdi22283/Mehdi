package az.zeng.yazici;

interface IRecorder {
    void destroy() = 16777114;
    boolean start(String path, int mode) = 1;
    long stop() = 2;
    boolean isRecording() = 3;
    String getLog() = 4;
}
