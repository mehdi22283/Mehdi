# Videoya bax

Telefon tətbiqi tələb etməyən Android TV video qəbul playeri.

## İş prinsipi
1. APK-ni TV-yə quraşdır.
2. `Videoya bax` tətbiqini aç.
3. TV-də göstərilən `http://TV-IP:3169` ünvanını telefonda brauzerdə aç.
4. `Video seç` → videonu seç → `TV-də aç`.
5. TV video stream-i RAM-dan oxuyur və Media3 playerdə oynadır.

**Qeyd:** Bu versiyada seçilmiş video TV-də disk faylı kimi yaradılmır; upload RAM-da saxlanılır. Bu, telefonun tam sərbəst işləməsi üçün browser upload-un bir dəfə tamamlanmasını tələb edir. Böyük fayllar üçün növbəti versiyada diskə yazmadan həqiqi byte-stream proxy arxitekturası əlavə edilə bilər.
