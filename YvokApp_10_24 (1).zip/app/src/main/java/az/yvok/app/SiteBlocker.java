package az.yvok.app;

import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.util.HashMap;

/**
 * Gizli səhifələr (e-belediyye.gov.az və hesab.az) üçün ORTAQ filtr.
 * Yalnız səhifənin işləməsi üçün vacib olanlar yüklənir: əsas səhifə, onun skriptləri (JS), üslubları (CSS)
 * və saytın öz məlumat sorğuları (XHR/fetch). Qalan hər şey (şəkil, şrift, video/səs, fayllar, ikon, reklam,
 * izləmə, sosial şəbəkə vidjetləri, xarici iframe-lər və s.) 204 ilə dərhal "yoxdur" cavabı alır.
 */
public final class SiteBlocker {
    private SiteBlocker() { }

    private static final String[] BAD_EXT = {
            ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".avif", ".bmp", ".ico", ".cur", ".tif", ".tiff", ".heic", ".apng",
            ".woff", ".woff2", ".ttf", ".otf", ".eot",
            ".mp4", ".webm", ".mp3", ".ogg", ".wav", ".m4a", ".avi", ".mov", ".m3u8", ".mpd",
            ".pdf", ".zip", ".rar", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
            ".map", ".webmanifest"};

    private static final String[] BAD_PATH = {
            "/images/", "/image/", "/img/", "/fonts/", "/font/", "/icons/", "/icon/", "/media/", "/video/", "/videos/",
            "/photos/", "/gallery/", "/banners/", "favicon", "manifest.json"};

    private static final String[] BAD_HOST = {
            "google-analytics", "googletagmanager", "googlesyndication", "googleadservices", "doubleclick", "analytics",
            "facebook", "fbcdn", "instagram", "twitter", "tiktok", "linkedin", "youtube", "ytimg", "vimeo",
            "yandex", "hotjar", "clarity.ms", "fonts.googleapis", "fonts.gstatic", "gravatar",
            "tawk", "jivo", "livechat", "intercom", "crisp.chat", "hubspot", "sentry", "newrelic", "mixpanel", "segment"};

    private static boolean isSiteHost(String host) {
        return host.endsWith(".az") || host.equals("az");     // saytın öz domenləri (e-belediyye.gov.az, hesab.az və alt domenlər)
    }

    private static WebResourceResponse empty() {
        return new WebResourceResponse("text/plain", "utf-8", 204, "No Content",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    /** null: sorğu normal yüklənir; qeyri-null: sorğu boş cavabla əvəz olunur */
    public static WebResourceResponse intercept(WebResourceRequest r) {
        if (r == null || r.getUrl() == null || r.isForMainFrame()) return null;
        String path = r.getUrl().getPath() == null ? "" : r.getUrl().getPath().toLowerCase();
        String host = r.getUrl().getHost() == null ? "" : r.getUrl().getHost().toLowerCase();
        String accept = "";
        if (r.getRequestHeaders() != null && r.getRequestHeaders().get("Accept") != null)
            accept = r.getRequestHeaders().get("Accept").toLowerCase();

        if (accept.startsWith("image/") || accept.startsWith("video/") || accept.startsWith("audio/") || accept.startsWith("font/")
                || accept.startsWith("application/font") || accept.startsWith("application/pdf")) return empty();
        for (String e : BAD_EXT) if (path.endsWith(e)) return empty();
        for (String p : BAD_PATH) if (path.contains(p)) return empty();
        for (String h : BAD_HOST) if (host.contains(h)) return empty();

        if (!isSiteHost(host)) {
            // Xarici domen: yalnız skript və üslub faylına icazə (saytın işləməsi onlardan asılı ola bilər), qalan hər şey bloklanır
            boolean ok = path.endsWith(".js") || path.endsWith(".mjs") || path.endsWith(".css");
            if (!ok) return empty();
        }
        return null;
    }
}
