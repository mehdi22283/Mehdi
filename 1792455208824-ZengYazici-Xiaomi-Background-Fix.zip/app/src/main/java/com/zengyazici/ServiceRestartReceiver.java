package com.zengyazici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Best-effort recovery if a device vendor stops the service while dismissing the app task. */
public class ServiceRestartReceiver extends BroadcastReceiver {
    public static final String ACTION_RECOVER = "com.zengyazici.action.RECOVER_SERVICE";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION_RECOVER.equals(intent.getAction())) return;
        if (!context.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("autostart", false)) return;
        try {
            Intent service = new Intent(context, RecService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service);
            else context.startService(service);
            RecService.log("Ehtiyat bərpa: fon xidməti yenidən başladılmağa göndərildi");
        } catch (Throwable e) {
            RecService.log("Ehtiyat bərpa alınmadı (sistem məhdudiyyəti ola bilər): " + e);
        }
    }
}
