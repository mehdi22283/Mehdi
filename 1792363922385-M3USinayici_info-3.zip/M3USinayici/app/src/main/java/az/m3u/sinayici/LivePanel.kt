package az.m3u.sinayici

import android.app.Activity
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Ottplayer proseslərini canlı göstərən tam ekran panel: yuxarıda status sətri + "Gizlət", altında WebView. */
class LivePanel(act: Activity, web: WebView) {
    val panel = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val host = act.window.decorView as ViewGroup
    private val status: TextView

    init {
        val dp = act.resources.displayMetrics.density
        val sbId = act.resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (sbId > 0) act.resources.getDimensionPixelSize(sbId) else (24 * dp).toInt()
        status = TextView(act).apply {
            text = "🔄 Ottplayer açılır..."
            setTextColor(Color.WHITE); textSize = 14f
            setPadding((12 * dp).toInt(), 0, (8 * dp).toInt(), 0)
            gravity = Gravity.CENTER_VERTICAL
        }
        val hide = Button(act).apply {
            text = "Gizlət"; textSize = 12f; isAllCaps = false
            setOnClickListener { panel.visibility = View.GONE }
        }
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#CC1B1B1B"))
            gravity = Gravity.CENTER_VERTICAL
            addView(status, LinearLayout.LayoutParams(0, (48 * dp).toInt(), 1f))
            addView(hide, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (40 * dp).toInt()))
        }
        web.setBackgroundColor(Color.BLACK)
        panel.setBackgroundColor(Color.BLACK)
        panel.setPadding(0, sb, 0, 0)
        panel.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        panel.addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        panel.elevation = 100f * dp
        host.addView(panel, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
    }

    fun setStatus(t: String) { status.text = t }
    fun remove() { try { host.removeView(panel) } catch (e: Exception) { } }
}
