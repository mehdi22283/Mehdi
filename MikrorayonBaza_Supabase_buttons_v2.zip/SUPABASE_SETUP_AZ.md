# Supabase qoşulması — Mikrorayon Baza

## 1. Supabase layihəsi yaradın

1. https://supabase.com saytında daxil olun və yeni layihə yaradın.
2. Layihənin **Project URL** dəyərini götürün. Adətən `https://....supabase.co` formasındadır.
3. **SQL Editor** bölməsini açıb aşağıdakı SQL-i işlədin:

```sql
create table if not exists public.baza_sync (
    id text primary key,
    data jsonb not null,
    updated_at timestamptz not null default now()
);

alter table public.baza_sync enable row level security;
grant select, insert, update, delete on table public.baza_sync to service_role;
```

Tətbiqin bu versiyası sinxronizasiya üçün `public.baza_sync` cədvəlinin `id`, `data` və `updated_at` sütunlarından istifadə edir. İlk yükləmə cədvələ `id = 'main'` olan sətri əlavə edir.

## 2. Tətbiqdə qoşulun

1. Tətbiqin yuxarısındakı **Supabase** düyməsinə toxunun.
2. **Project URL** xanasına 2-ci addımda götürdüyünüz URL-i yazın.
3. Açar xanasına cari tətbiq quruluşunun tələb etdiyi `service_role` (köhnə açar) və ya `sb_secret_...` açarını daxil edin.
4. **Bağlantını yoxla** düyməsinə basın. Uğurlu mesaj çıxarsa cədvəl əlçatandır.
5. **Upload** serverə bu telefondakı dəyişiklikləri göndərir. **Download** serverdəki dəyişiklikləri telefona tətbiq edir. Download zamanı təsdiqləmə pəncərəsini diqqətlə oxuyun.

## Vacib təhlükəsizlik qeydi

**`service_role` / `sb_secret_...` açarını Android tətbiqində saxlamaq istehsalat üçün təhlükəsiz deyil.** Bu açar Row Level Security qaydalarını keçir və sızarsa layihədəki məlumatları dəyişdirmək/oxumaq mümkün ola bilər. Bu build onu telefonda tətbiqin ayarlarında saxlayır. APK-nı paylaşmayın və açarı söhbətə, e-poçta, repozitoriyaya və ya açıq sənədə qoymayın.

Tətbiqi başqa şəxslərlə paylaşmaq və ya şəxsi məlumatları real istifadədə sinxronlaşdırmaq üçün tövsiyə edilən həll: `sb_secret` açarını server tərəfində saxlayan Supabase Edge Function arxitekturasına keçmək və mobil tətbiqə həmin funksiyaya təhlükəsiz giriş vermək; yaxud Supabase Auth ilə istifadəçi girişi və `authenticated` roluna bağlı RLS siyasətləri tətbiq etmək. Bu layihənin mövcud birbaşa REST sinxronizasiyası hələ həmin autentifikasiyanı tətbiq etmir.

## Düymələr

- **Supabase** — sinxronizasiya menyusu və ayarlar.
- **Upload** — yerli dəyişiklikləri indi serverə yazır.
- **Download** — server snapshot-ını endirib bu telefondakı sinxronizasiya dəyişikliklərini əvəz edir. Yerli borc dəyərləri saxlanılır.
- **Bağlantını yoxla** — `baza_sync` cədvəlinə REST sorğusu göndərir.
