package com.mehdi.keymapper;

import android.app.Application;

public class KeyMapperApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        try {
            rikka.shizuku.Shizuku.addBinderReceivedListenerSticky(KeyInjectorClient::onShizukuBinderReady);
            rikka.shizuku.Shizuku.addBinderDeadListener(KeyInjectorClient::onShizukuBinderDead);
        } catch (Throwable ignored) {
            // Shizuku is an optional privileged backend.
        }
    }
}
