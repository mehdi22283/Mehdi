package az.mehdi.callrec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.CallLog
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import java.io.File

class RecService : Service() {
    companion object {
        @Volatile var inst: RecService? = null
        @Volatile var onChange: (() -> Unit)? = null
    }

    private var mr: MediaRecorder? = null
    private var out: File? = null
    private var t0 = 0L
    private var app = "Phone"
    private var incoming = true
    private var ringing = false
    private var waName = ""
    private var tm: TelephonyManager? = null
    private var cb: Any? = null
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        inst = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Zəng yazıcı", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "rec").setContentTitle("Zəng yazıcı aktivdir")
            .setContentText("Phone və WhatsApp zəngləri izlənir")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Exception) { stopSelf(); return }
        listen()
    }

    @Suppress("DEPRECATION")
    private fun listen() {
        val t = getSystemService(TelephonyManager::class.java)
        tm = t
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val c = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) { onState(state) }
                }
                cb = c
                t.registerTelephonyCallback(mainExecutor, c)
            } else {
                val l = object : PhoneStateListener() {
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) { onState(state) }
                }
                cb = l
                t.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
            }
        } catch (e: SecurityException) { }
    }

    private fun onState(s: Int) {
        when (s) {
            TelephonyManager.CALL_STATE_RINGING -> ringing = true
            TelephonyManager.CALL_STATE_OFFHOOK -> if (mr == null) {
                incoming = ringing; ringing = false; begin("Phone")
            }
            TelephonyManager.CALL_STATE_IDLE -> { ringing = false; if (app == "Phone") finish() }
        }
    }

    @Suppress("DEPRECATION")
    private fun newMr(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun begin(a: String) {
        if (mr != null) return
        app = a
        val dir = File(getExternalFilesDir(null), "rec").apply { mkdirs() }
        val f = File(dir, "${a}_${System.currentTimeMillis()}.m4a")
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_CALL,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC)
        for (src in sources) {
            val r = newMr()
            try {
                r.setAudioSource(src)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioSamplingRate(44100)
                r.setAudioEncodingBitRate(96000)
                r.setOutputFile(f.absolutePath)
                r.prepare(); r.start()
                mr = r; out = f; t0 = System.currentTimeMillis()
                return
            } catch (e: Exception) {
                try { r.release() } catch (_: Exception) { }
            }
        }
    }

    private fun finish() {
        val r = mr ?: return
        val f = out ?: return
        mr = null; out = null
        try { r.stop() } catch (_: Exception) { }
        r.release()
        val dur = System.currentTimeMillis() - t0
        val a = app; val inc = incoming; val start = t0; val name = waName
        if (dur < 1500 || f.length() < 1000) { f.delete(); return }
        if (a == "Phone") {
            h.postDelayed({
                Store.add(this, phoneRec(f, start, dur, inc))
                onChange?.invoke()
            }, 1500)
        } else {
            Store.add(this, Rec(f.absolutePath, name.ifEmpty { "WhatsApp" }, "WhatsApp", inc, start, dur))
            onChange?.invoke()
        }
    }

    private fun phoneRec(f: File, t: Long, d: Long, inc0: Boolean): Rec {
        var num = ""; var inc = inc0
        try {
            contentResolver.query(CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.CACHED_NAME),
                null, null, "date DESC")?.use {
                if (it.moveToFirst()) {
                    val n = it.getString(0) ?: ""
                    val nm = it.getString(2) ?: ""
                    num = if (nm.isNotEmpty()) "$nm ($n)" else n
                    inc = it.getInt(1) != CallLog.Calls.OUTGOING_TYPE
                }
            }
        } catch (e: Exception) { }
        return Rec(f.absolutePath, num, "Phone", inc, t, d)
    }

    fun waStart(name: String, inc: Boolean) { waName = name; incoming = inc; begin("WhatsApp") }
    fun waStop() { if (app == "WhatsApp") finish() }

    @Suppress("DEPRECATION")
    override fun onDestroy() {
        inst = null
        try {
            val t = tm; val c = cb
            if (t != null && c != null) {
                if (Build.VERSION.SDK_INT >= 31) t.unregisterTelephonyCallback(c as TelephonyCallback)
                else t.listen(c as PhoneStateListener, PhoneStateListener.LISTEN_NONE)
            }
        } catch (e: Exception) { }
        finish()
        super.onDestroy()
    }
}
