package az.zeng.yazici;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Zəng tarixçəsi: hər zəng (yazılan, xətalı və cavabsız) tarixi ilə birlikdə history.json faylında saxlanılır. */
final class HistoryStore {
    static final class Item {
        String id = "", src = "ph", dir = "in", label = "", status = "ok", note = "";
        long ts, ms;
    }

    private static final Object LOCK = new Object();
    private static final int MAX = 1000;

    private HistoryStore() {
    }

    private static File file(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), "history.json");
    }

    private static List<Item> read(Context c) {
        List<Item> r = new ArrayList<>();
        File f = file(c);
        if (!f.exists()) return r;
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            JSONArray a = new JSONArray(bo.toString("UTF-8"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.id = o.optString("id");
                it.src = o.optString("src", "ph");
                it.dir = o.optString("dir", "in");
                it.label = o.optString("label");
                it.status = o.optString("status", "ok");
                it.note = o.optString("note");
                it.ts = o.optLong("ts");
                it.ms = o.optLong("ms");
                r.add(it);
            }
        } catch (Exception ignored) {
        }
        return r;
    }

    private static void write(Context c, List<Item> l) {
        try {
            JSONArray a = new JSONArray();
            for (Item it : l) {
                JSONObject o = new JSONObject();
                o.put("id", it.id);
                o.put("src", it.src);
                o.put("dir", it.dir);
                o.put("label", it.label);
                o.put("status", it.status);
                o.put("note", it.note);
                o.put("ts", it.ts);
                o.put("ms", it.ms);
                a.put(o);
            }
            File f = file(c);
            File t = new File(f.getPath() + ".tmp");
            try (FileOutputStream out = new FileOutputStream(t)) {
                out.write(a.toString().getBytes("UTF-8"));
            }
            if (!t.renameTo(f)) {
                f.delete();
                t.renameTo(f);
            }
        } catch (Exception ignored) {
        }
    }

    /** Ən yeni əvvəldə olmaqla bütün qeydlər. */
    static List<Item> all(Context c) {
        synchronized (LOCK) {
            List<Item> l = read(c);
            Collections.sort(l, (x, y) -> Long.compare(y.ts, x.ts));
            return l;
        }
    }

    static void add(Context c, Item it) {
        synchronized (LOCK) {
            List<Item> l = read(c);
            l.add(it);
            Collections.sort(l, (x, y) -> Long.compare(y.ts, x.ts));
            while (l.size() > MAX) l.remove(l.size() - 1);
            write(c, l);
        }
    }

    static void update(Context c, String id, long ms, String status, String note) {
        synchronized (LOCK) {
            List<Item> l = read(c);
            for (Item it : l) {
                if (it.id.equals(id)) {
                    it.ms = ms;
                    it.status = status;
                    it.note = note == null ? "" : note;
                    break;
                }
            }
            write(c, l);
        }
    }

    static void remove(Context c, String id) {
        synchronized (LOCK) {
            List<Item> l = read(c);
            for (int i = 0; i < l.size(); i++) {
                if (l.get(i).id.equals(id)) {
                    l.remove(i);
                    break;
                }
            }
            write(c, l);
        }
    }

    static String stamp(Context c) {
        File f = file(c);
        return f.lastModified() + ":" + f.length();
    }
}
