package az.market.endirim

import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Bir marketin Instagram səhifəsini və son 15 postunun İÇİNİ offline arxivə yazır (videolar və reels yüklənmir).
 *   filesDir/insta/<istifadəçi>.mht            → profil (post şəbəkəsi)
 *   filesDir/insta/<istifadəçi>/<kod>.mht      → hər postun öz səhifəsi
 * Həm əl ilə (InstaBrowserActivity), həm də gündəlik avtomatik (InstaWorker) istifadə olunur.
 */
class InstaSaver(private val ctx: Context, private val web: WebView) {

    enum class Res { OK, FAILED, LOGIN }

    var pageDone: CompletableDeferred<Unit>? = null

    companion object {
        const val TARGET = 15
        const val UA =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
        val lock = Mutex()

        private val MARKETS = listOf("Bravo Market", "Araz Market", "Al Market", "Rahat Market", "Tamstore", "Bolmart")

        fun users(): List<Pair<String, String>> =
            MARKETS.mapNotNull { m -> Brand.socials[m]?.instagram?.let { m to it } }

        private fun root(ctx: Context) = File(ctx.filesDir, "insta").apply { mkdirs() }
        fun archive(ctx: Context, user: String) = File(root(ctx), "$user.mht")
        fun postFile(ctx: Context, user: String, code: String) =
            File(File(root(ctx), user).apply { mkdirs() }, "$code.mht")

        fun prefs(ctx: Context) = ctx.getSharedPreferences("insta", Context.MODE_PRIVATE)
        fun lastOk(ctx: Context, user: String) = prefs(ctx).getLong("ok_$user", 0L)
        fun needLogin(ctx: Context) = prefs(ctx).getBoolean("need_login", false)

        /** Bu gün (təqvim günü) artıq yenilənibsə true — 24 saat gözlənmir, yeni gün başlayan kimi yenilənir. */
        fun doneToday(ctx: Context, user: String): Boolean {
            val t = lastOk(ctx, user)
            if (t == 0L) return false
            val f = SimpleDateFormat("yyyyMMdd", Locale.US)
            return f.format(Date(t)) == f.format(Date())
        }

        fun loggedIn(): Boolean =
            android.webkit.CookieManager.getInstance().getCookie("https://www.instagram.com")?.contains("sessionid=") == true

        /** Video sorğularını boş cavabla kəsir ki, heç bir video yaddaşa düşməsin. */
        fun blockVideo(req: WebResourceRequest): WebResourceResponse? {
            val u = req.url.toString().lowercase()
            val video = u.contains(".mp4") || u.contains(".webm") || u.contains(".m3u8") || u.contains(".mpd") ||
                u.contains("/o1/v/") || u.contains("/v/t16/")
            return if (video) WebResourceResponse("text/plain", "utf-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0))) else null
        }
    }

    private suspend fun load(url: String): Boolean {
        val done = CompletableDeferred<Unit>()
        pageDone = done
        web.loadUrl(url)
        return withTimeoutOrNull(30_000) { done.await(); true } ?: false
    }

    private suspend fun evalString(js: String): String = suspendCoroutine { c ->
        web.evaluateJavascript(js) { raw ->
            val v = try { (JSONTokener(raw ?: "null").nextValue() as? String) ?: "" } catch (e: Exception) { "" }
            c.resume(v)
        }
    }

    private suspend fun saveArchive(f: File): Boolean = suspendCoroutine { c ->
        f.parentFile?.mkdirs()
        val tmp = File(f.path + ".part")
        tmp.delete()
        web.saveWebArchive(tmp.absolutePath, false) { path ->
            if (path != null && tmp.length() > 0 && tmp.renameTo(f)) c.resume(true)
            else {
                tmp.delete()
                c.resume(false)
            }
        }
    }

    private val collectJs = """(function(){window.scrollTo(0,document.body.scrollHeight);var s=[],m={};
document.querySelectorAll('a[href*="/p/"]').forEach(function(a){var h=a.getAttribute('href');if(!m[h]){m[h]=1;s.push(h);}});
return s.join('|');})()"""

    private val hideJs = """(function(){var seen={},k=0;
document.querySelectorAll('a[href*="/reel/"]').forEach(function(a){a.style.display='none';});
document.querySelectorAll('a[href*="/p/"]').forEach(function(a){var h=a.getAttribute('href');
if(!seen[h]){seen[h]=1;k++;}if(k>$TARGET){a.style.display='none';}});window.scrollTo(0,0);return String(k);})()"""

    /** Profili sürüşdürüb post linklərini toplayır (ən çox TARGET ədəd). */
    private suspend fun collectPosts(): List<String> {
        var best = emptyList<String>()
        var stale = 0
        for (step in 0 until 30) {
            val list = evalString(collectJs).split('|').filter { it.isNotBlank() }
            if (list.size > best.size) { best = list; stale = 0 } else stale++
            if (best.size >= TARGET || stale >= 4) break
            delay(1200)
        }
        if (best.isNotEmpty()) evalString(hideJs)
        return best.take(TARGET)
    }

    suspend fun saveUser(user: String, status: (String) -> Unit): Res {
        web.settings.javaScriptEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        status("profil yüklənir…")
        if (!load("https://www.instagram.com/$user/")) return Res.FAILED
        delay(2500)
        if (web.url?.contains("accounts/login") == true) {
            prefs(ctx).edit().putBoolean("need_login", true).apply()
            return Res.LOGIN
        }
        val hrefs = collectPosts()
        if (hrefs.isEmpty()) return Res.FAILED
        status("${hrefs.size} post tapıldı, profil saxlanılır…")
        delay(1000)
        if (!saveArchive(archive(ctx, user))) return Res.FAILED

        val posts = LinkedHashMap<String, String>()   // kod -> p | reel
        val re = Regex("/(p|reel)/([^/?#]+)")
        hrefs.forEach { h -> re.find(h)?.let { posts[it.groupValues[2]] = it.groupValues[1] } }
        var i = 0
        for ((code, type) in posts) {
            i++
            status("post $i/${posts.size} yüklənir…")
            if (!load("https://www.instagram.com/$type/$code/")) continue
            delay(1500)
            if (web.url?.contains("accounts/login") == true) {
                prefs(ctx).edit().putBoolean("need_login", true).apply()
                return Res.LOGIN
            }
            if (evalString("document.querySelector('video')?'1':'0'") == "1") {
                postFile(ctx, user, code).delete()   // video post — offline saxlanmır
                continue
            }
            saveArchive(postFile(ctx, user, code))
        }
        // artıq ilk 20-də olmayan köhnə postlar silinir
        if (posts.isNotEmpty()) {
            File(root(ctx), user).listFiles()?.forEach { if (it.name.removeSuffix(".mht") !in posts.keys) it.delete() }
        }
        prefs(ctx).edit().putLong("ok_$user", System.currentTimeMillis()).putBoolean("need_login", false).apply()
        return Res.OK
    }
}
