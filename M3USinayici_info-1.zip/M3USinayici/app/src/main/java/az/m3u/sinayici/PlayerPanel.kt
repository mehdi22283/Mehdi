package az.m3u.sinayici

import android.app.Activity
import android.app.Application
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.LinearLayout
import android.widget.Toast
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.LoadEventInfo
import androidx.media3.exoplayer.source.MediaLoadData
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia
import org.videolan.libvlc.util.VLCVideoLayout
import java.lang.ref.WeakReference
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

class QItem(val name: String, val url: String, val hdr: String)
object PlayQueue { var items: List<QItem> = emptyList(); var index = 0 }

/**
 * Tətbiqdaxili PiP (Android sistem PiP-i YOXDUR).
 * Player tək bir View-dur: kiçik rejimdə (MINI) tətbiqin hazırkı ekranının üstündə sürüklənən pəncərə kimi durur,
 * "Böyüt" düyməsi ilə tam ekran (FULL) olur, "Kiçilt" ilə geri qayıdır. Activity-lər arasında (əsas ekran ↔ brauzer)
 * və axtarış dialoqunun üstündə qalır. Tətbiqdən çıxanda dayanır, qayıdanda davam edir.
 */
class PlayerPanel private constructor(private val ctx: Context) : FrameLayout(ctx) {
    private val h = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("m3u", Context.MODE_PRIVATE)
    private val pv = PlayerView(ctx)
    private val vl = VLCVideoLayout(ctx)
    private var m3: ExoPlayer? = null
    private var m3Ds: ResolvingDataSource.Factory? = null   // HLS üçün ayrıca mənbə qurmaqda istifadə olunur
    private var m3Retry = 0                                  // keçici xətada eyni profilin təkrar cəhd sayı
    private var m3Behind = 0                                 // ardıcıl "canlı pəncərədən geri qaldı" sayı
    private var switching = false                            // Ott ↔ VLC keçidi gedir: təkrar toxunuşlar yox sayılır
    private var vlcLib: LibVLC? = null
    @Volatile private var vlc: MediaPlayer? = null
    private val vlcExec: ExecutorService = Executors.newSingleThreadExecutor()   // VLC-nin bütün native əmrləri (setMedia/play/stop/release) ARXA FONDA, ardıcıl — əsas axın (UI) ilişmir
    private var sniffTried = false                           // növ aşkarlama təkcə Media3 "format tanınmadı" xətasında (kanal açılışını yubatmamaq üçün)
    private var lastLoadMs = 0L                              // son kanal açılış anı: ilk saniyələrdə əlavə probe bağlantısı açılmır
    private var lastStepMs = 0L                              // ardıcıl sürətli ◀ ▶ basışlarını birləşdirmək üçün
    private val stepRun = Runnable { if (alive) loadCurrent() }
    private lateinit var linkBtn: TextView
    private lateinit var statsTv: TextView
    private lateinit var nameTv: TextView
    private lateinit var miniNameTv: TextView
    private lateinit var miniStatsTv: TextView
    private lateinit var engM3: TextView
    private lateinit var engVlc: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var miniPlay: ImageButton
    private lateinit var miniEng: TextView
    private lateinit var infoOverlay: FrameLayout
    private lateinit var infoTv: TextView
    private lateinit var bottomBox: LinearLayout
    private lateinit var miniTop: LinearLayout
    private lateinit var miniCtl: LinearLayout
    private var engine = "media3"
    private var url = ""
    private var curName = ""
    @Volatile private var target = Net.Target("", emptyMap(), "")
    private var profiles: List<Net.Target> = emptyList()
    private var pIdx = 0
    private var msg = ""
    @Volatile private var gen = 0
    private var latency = -1L
    private var speedBps = -1L
    private var prevAhead = -1L
    private var vlcBuf = 100f
    private var vlcPlaying = false
    private var speed = 1f
    @Volatile private var alive = true
    private var full = false
    private var userPaused = false
    private var resumeOnFg = false
    private var lastIcon = 0
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var startTx = 0f
    private var startTy = 0f
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var lockedAct: WeakReference<Activity>? = null
    private var prevOrient = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private val hideCtl = Runnable { miniCtl.visibility = View.GONE }
    private val glowCache = HashMap<Int, Drawable>()   // init-dən əvvəl elan olunmalıdır
    private val RED_GLOW = 0xFFFF1A1A.toInt()

    companion object {
        private var inst: PlayerPanel? = null
        private var actRef: WeakReference<Activity>? = null
        private var dlgRef: WeakReference<Dialog>? = null
        private var hostCount = 0
        private var started = 0
        private var posFx = 1f
        private var posFy = 0.88f

        private fun isHost(a: Activity) = a is MainActivity || a is BrowserActivity
        private fun inFg() = started > 0

        /** App.onCreate-də bir dəfə çağırılır. */
        fun install(app: Application) {
            app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
                override fun onActivityCreated(a: Activity, b: Bundle?) { if (isHost(a)) hostCount++ }
                override fun onActivityStarted(a: Activity) {
                    if (!isHost(a)) return
                    started++
                    if (started == 1) inst?.onForeground()
                }
                override fun onActivityResumed(a: Activity) {
                    if (!isHost(a)) return
                    actRef = WeakReference(a)
                    inst?.attachHost()
                }
                override fun onActivityPaused(a: Activity) {}
                override fun onActivityStopped(a: Activity) {
                    if (!isHost(a)) return
                    started = (started - 1).coerceAtLeast(0)
                    if (started == 0) inst?.onBackground()
                }
                override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
                override fun onActivityDestroyed(a: Activity) {
                    if (!isHost(a)) return
                    hostCount = (hostCount - 1).coerceAtLeast(0)
                    val p = inst ?: return
                    if (hostCount == 0) {
                        if (a.isChangingConfigurations) { actRef = null; p.detach() }   // activity yenidən yaranır, pleyer qalır
                        else p.closePlayer()
                        return
                    }
                    val cur = actRef?.get()
                    if (cur == null || cur === a) { actRef = null; p.detach() }
                }
            })
        }

        /** PlayQueue hazırlandıqdan sonra çağırılır: kiçik pəncərə açılır / kanal dəyişir. [d] axtarış dialoqudursa pəncərə onun üstündə qalır. */
        fun open(a: Activity, d: Dialog? = null) {
            actRef = WeakReference(a)
            dlgRef = if (d != null) WeakReference(d) else null
            var p = inst
            if (p == null) { p = PlayerPanel(a.applicationContext); inst = p }
            p.attachHost()
            p.loadCurrent()
        }

        /** Dialoq bağlananda pəncərə yenidən activity-yə qayıdır. */
        fun dialogGone(d: Dialog) {
            if (dlgRef?.get() === d) { dlgRef = null; inst?.attachHost() }
        }

        /** "Geri" düyməsi: tam ekrandırsa kiçildir (true qaytarır). */
        fun handleBack(): Boolean = inst?.backPressed() ?: false

        /** Player kanalı oynada bilməyəndə (məs. ERROR_CODE_IO_UNSPECIFIED) çağırılır: siyahıda kanal dərhal 🔴 olur. */
        var onDead: ((String) -> Unit)? = null
    }

    init {
        buildUi()
        applyMode()
        tick(); probeLoop()
    }

    // ---------- interfeys ----------
    /** Hazırda oynayan kanalın linkini panoya kopyalayır. */
    private fun copyLink() {
        val cur = PlayQueue.items.getOrNull(PlayQueue.index) ?: return
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("kanal linki", cur.url))
            Toast.makeText(ctx, "🔗 Link kopyalandı", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Kopyalamaq alınmadı", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
    }

    private fun iconBtn(res: Int, f: () -> Unit): ImageButton = ImageButton(ctx).apply {
        setImageResource(res)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = rounded(0xFF2563EB.toInt(), 36)
        setOnClickListener { f() }
    }

    /** İkonun öz kənarları boyunca qırmızı kölgə (glow) çəkilmiş drawable; fon yoxdur, tam şəffafdır. */
    private fun glowIcon(res: Int): Drawable = glowCache.getOrPut(res) {
        val src = ctx.getDrawable(res)!!.mutate()
        val sz = dp(24) * 3
        val pad = dp(12) * 3 / 2
        val icon = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
        src.setBounds(0, 0, sz, sz); src.draw(Canvas(icon))
        val out = Bitmap.createBitmap(sz + pad * 2, sz + pad * 2, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val blur = Paint(Paint.ANTI_ALIAS_FLAG).apply { maskFilter = BlurMaskFilter(dp(3) * 1.5f, BlurMaskFilter.Blur.NORMAL) }
        val off = IntArray(2)
        val alpha = icon.extractAlpha(blur, off)
        // qalın qara kölgə: geniş bulanıq qara ləkə (ən altda), üstündən qırmızı glow
        val blurBlack = Paint(Paint.ANTI_ALIAS_FLAG).apply { maskFilter = BlurMaskFilter(dp(8) * 1.5f, BlurMaskFilter.Blur.NORMAL) }
        val offB = IntArray(2)
        val alphaB = icon.extractAlpha(blurBlack, offB)
        val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        repeat(8) { c.drawBitmap(alphaB, (pad + offB[0]).toFloat(), (pad + offB[1]).toFloat(), black) }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = RED_GLOW }
        repeat(3) { c.drawBitmap(alpha, (pad + off[0]).toFloat(), (pad + off[1]).toFloat(), fill) }
        c.drawBitmap(icon, pad.toFloat(), pad.toFloat(), null)
        BitmapDrawable(ctx.resources, out)
    }

    /** Mətn düymələrinin (✕, Ott/VLC) arxasında hamar, dairəvi qara kölgə (kənara doğru tədricən yox olur). */
    private class SoftCircle : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var cx = 0f; private var cy = 0f; private var r = 0f
        override fun onBoundsChange(b: android.graphics.Rect) {
            cx = b.exactCenterX(); cy = b.exactCenterY(); r = minOf(b.width(), b.height()) / 2f
            if (r <= 0f) return
            paint.shader = RadialGradient(cx, cy, r,
                intArrayOf(0xF2000000.toInt(), 0xE6000000.toInt(), 0xC0000000.toInt(), 0x8C000000.toInt(), 0x52000000, 0x24000000, 0x00000000),
                floatArrayOf(0f, 0.35f, 0.5f, 0.64f, 0.78f, 0.9f, 1f), Shader.TileMode.CLAMP)
        }
        override fun draw(c: Canvas) { if (r > 0f) c.drawCircle(cx, cy, r, paint) }
        override fun setAlpha(a: Int) { paint.alpha = a }
        override fun setColorFilter(f: ColorFilter?) { paint.colorFilter = f }
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    private fun blackBlob(): Drawable = SoftCircle()

    private fun miniBtn(res: Int, f: () -> Unit): ImageButton = ImageButton(ctx).apply {
        setImageDrawable(glowIcon(res))
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(2), dp(2), dp(2), dp(2))
        setBackgroundColor(Color.TRANSPARENT)
        setOnClickListener { f(); keepCtl() }
    }

    private fun segment(t: String, f: () -> Unit): TextView = TextView(ctx).apply {
        text = t; textSize = 18f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setOnClickListener { f() }
    }

    private fun buildUi() {
        keepScreenOn = true
        setBackgroundColor(Color.BLACK)
        engine = (prefs.getString("engine", "media3") ?: "media3").let { if (it == "exo") "media3" else it }
        pv.useController = false
        pv.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)

        statsTv = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 0); setBackgroundColor(Color.TRANSPARENT)
        }
        nameTv = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER; maxLines = 2
            typeface = Typeface.DEFAULT_BOLD
        }
        engM3 = segment("Ott") { setEngine("media3") }
        engVlc = segment("VLC") { setEngine("vlc") }
        val seg = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(0xFF1F2937.toInt(), 28)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(engM3, LinearLayout.LayoutParams(0, dp(50), 1f))
            addView(engVlc, LinearLayout.LayoutParams(0, dp(50), 1f))
        }
        playBtn = iconBtn(R.drawable.ic_pause) { togglePause() }
        val nav = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(iconBtn(R.drawable.ic_prev) { step(-1) }, LinearLayout.LayoutParams(dp(72), dp(72)))
            addView(playBtn, LinearLayout.LayoutParams(dp(84), dp(84)).apply { setMargins(dp(28), 0, dp(28), 0) })
            addView(iconBtn(R.drawable.ic_next) { step(1) }, LinearLayout.LayoutParams(dp(72), dp(72)))
        }
        val minBtn = TextView(ctx).apply {
            text = "▼ Kiçilt"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(0xFF2563EB.toInt(), 24)
            setOnClickListener { setFull(false) }
        }
        val closeBtn = TextView(ctx).apply {
            text = "✖ Bağla"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(0xFF4B5563.toInt(), 24)
            setOnClickListener { closePlayer() }
        }
        val infoBtn = TextView(ctx).apply {
            text = "ℹ️ Məlumat"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(0xFF1F2937.toInt(), 24)
            setOnClickListener { showInfo(true) }
        }
        // tam ekranda "Linki kopyala" yazısı əvəzinə kanalın linkinin özü yazılır; toxunanda kopyalanır
        linkBtn = TextView(ctx).apply {
            text = ""; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            maxLines = 3; ellipsize = TextUtils.TruncateAt.END
            minHeight = dp(46)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = rounded(0xFF059669.toInt(), 24)
            setOnClickListener { copyLink() }
        }
        val actRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(minBtn, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(4) })
            addView(infoBtn, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
            addView(closeBtn, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(4) })
        }
        bottomBox = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(14), dp(8), dp(14), dp(18))
            // kanal sayı/adı və statuslar TƏK bölmədə, eyni yazı ölçüsü (18sp)
            addView(nameTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(4) })
            addView(statsTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(10) })
            addView(nav)
            addView(seg, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
            addView(linkBtn, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
            addView(actRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
        }

        // kiçik rejim: yuxarıda kanal adı + ✕, toxunanda aşağıda idarə düymələri
        miniNameTv = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 11f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(4), dp(4), dp(4))
            setShadowLayer(dp(4).toFloat(), 0f, 0f, RED_GLOW)
        }
        miniStatsTv = TextView(ctx).apply {
            setTextColor(0xFFE5E7EB.toInt()); textSize = 9f; maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(4), dp(3))
            setShadowLayer(dp(4).toFloat(), 0f, 0f, RED_GLOW)
        }
        val miniInfo = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(miniNameTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(miniStatsTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        val miniClose = TextView(ctx).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(0, 0, 0, 0)
            background = blackBlob()
            setShadowLayer(dp(5).toFloat(), 0f, 0f, RED_GLOW)
            setOnClickListener { closePlayer() }
        }
        miniTop = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
            addView(miniInfo, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(miniBtn(R.drawable.ic_copy) { copyLink() }, LinearLayout.LayoutParams(dp(34), dp(34)))
            addView(miniClose, LinearLayout.LayoutParams(dp(46), dp(46)))
        }
        miniPlay = miniBtn(R.drawable.ic_pause) { togglePause() }
        miniEng = TextView(ctx).apply {
            textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 0); includeFontPadding = false
            background = blackBlob()
            setShadowLayer(dp(5).toFloat(), 0f, 0f, RED_GLOW)
            setOnClickListener { setEngine(if (engine == "media3") "vlc" else "media3"); keepCtl() }
        }
        miniCtl = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(4), dp(2), dp(4), dp(2))
            addView(miniBtn(R.drawable.ic_prev) { step(-1) }, LinearLayout.LayoutParams(dp(38), dp(38)))
            addView(miniPlay, LinearLayout.LayoutParams(dp(38), dp(38)).apply { setMargins(dp(6), 0, dp(6), 0) })
            addView(miniBtn(R.drawable.ic_next) { step(1) }, LinearLayout.LayoutParams(dp(38), dp(38)))
            addView(miniEng, LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(dp(4), 0, dp(2), 0) })
            addView(miniBtn(R.drawable.ic_expand) { setFull(true) }, LinearLayout.LayoutParams(dp(38), dp(38)))
            visibility = View.GONE
        }

        // pəncərə ölçüsü dəyişəndə (kiçik ↔ tam ekran) VLC görüntüsü yenidən tam sahəyə sığdırılır
        vl.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) { applyResize(); vl.post { applyResize() } }
        }
        pv.setOnClickListener { if (full) togglePause() else toggleCtl() }
        vl.setOnClickListener { if (full) togglePause() else toggleCtl() }
        val videoBox = FrameLayout(ctx).apply {
            addView(pv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(vl, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(miniTop, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.TOP))
            addView(miniCtl, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(videoBox, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(bottomBox, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        addView(col, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        // ℹ️ kanal məlumatı örtüyü (tam ekranda, video üstündə)
        infoTv = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 14f
            setPadding(dp(16), dp(8), dp(16), dp(24)); setLineSpacing(0f, 1.15f)
        }
        val infoTitle = TextView(ctx).apply {
            text = "ℹ️ Kanal məlumatı"; textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(16), 0, 0, 0); gravity = Gravity.CENTER_VERTICAL
        }
        val infoClose = TextView(ctx).apply {
            text = "✖ Bağla"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(0xFF4B5563.toInt(), 24)
            setOnClickListener { showInfo(false) }
        }
        val infoHead = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), dp(12), dp(6))
            addView(infoTitle, LinearLayout.LayoutParams(0, dp(44), 1f))
            addView(infoClose, LinearLayout.LayoutParams(dp(110), dp(40)))
        }
        val infoScroll = ScrollView(ctx).apply { addView(infoTv, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)) }
        infoOverlay = FrameLayout(ctx).apply {
            setBackgroundColor(0xF2000000.toInt()); visibility = View.GONE; isClickable = true
            addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(infoHead, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
                addView(infoScroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            }, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        }
        addView(infoOverlay, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        applyEngineViews()
    }

    // ---------- kiçik / tam ekran rejimi ----------
    private fun miniW(): Int {
        val dm = ctx.resources.displayMetrics
        return minOf(dp(300), (minOf(dm.widthPixels, dm.heightPixels) * 0.62f).toInt())
    }

    private fun makeLp(): FrameLayout.LayoutParams =
        if (full) FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        else FrameLayout.LayoutParams(miniW(), miniW() * 9 / 16, Gravity.TOP or Gravity.START)

    private fun applyMode() {
        val vis = if (full) View.VISIBLE else View.GONE
        statsTv.visibility = vis
        bottomBox.visibility = vis
        miniTop.visibility = if (full) View.GONE else View.VISIBLE
        h.removeCallbacks(hideCtl)
        miniCtl.visibility = View.GONE
        if (full) {
            translationX = 0f; translationY = 0f; foreground = null
        } else {
            foreground = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(2), 0xFF2563EB.toInt()) }
        }
        if (parent != null) layoutParams = makeLp()
        updatePlayIcon()
    }

    private fun setFull(on: Boolean) {
        if (on == full) return
        full = on
        if (!on) showInfo(false)
        if (on) {   // tam ekran dialoqun altında qalmasın
            val d = dlgRef?.get()
            if (d != null && d.isShowing) d.dismiss()
        }
        applyMode()
        attachHost()
        lockPortrait(on)
        applyAllResize()
        for (d in longArrayOf(120, 400, 900, 1800)) h.postDelayed({ if (alive) applyAllResize() }, d)
    }

    private fun backPressed(): Boolean {
        if (infoOverlay.visibility == View.VISIBLE) { showInfo(false); return true }
        if (full) { setFull(false); return true }
        return false
    }

    /** Tam ekranda portret (köhnə player kimi); kiçiləndə əvvəlki istiqamət qaytarılır. */
    private fun lockPortrait(on: Boolean) {
        if (on) {
            val a = actRef?.get() ?: return
            if (lockedAct?.get() !== a) { prevOrient = a.requestedOrientation; lockedAct = WeakReference(a) }
            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            val la = lockedAct?.get()
            if (la != null && !la.isFinishing) la.requestedOrientation = prevOrient
            lockedAct = null
        }
    }

    // ---------- yerləşmə (activity / dialoq) ----------
    private fun pickContainer(): ViewGroup? {
        if (!full) {
            val d = dlgRef?.get()
            if (d != null && d.isShowing) {
                val c = d.window?.decorView?.findViewById<ViewGroup>(android.R.id.content)
                if (c != null) return c
            }
        }
        val a = actRef?.get() ?: return null
        if (a.isFinishing || a.isDestroyed) return null
        return a.findViewById<ViewGroup>(android.R.id.content)
    }

    fun attachHost() {
        if (!alive) return
        val c = pickContainer() ?: return
        if (parent === c) { bringToFront(); return }
        (parent as? ViewGroup)?.removeView(this)
        c.addView(this, makeLp())
        bringToFront()
    }

    fun detach() { (parent as? ViewGroup)?.removeView(this) }

    private fun placeMini() {
        if (full) return
        val p = parent as? View ?: return
        if (p.width <= 0 || p.height <= 0) return
        val freeX = (p.width - width).coerceAtLeast(0)
        val freeY = (p.height - height).coerceAtLeast(0)
        translationX = posFx.coerceIn(0f, 1f) * freeX
        translationY = posFy.coerceIn(0f, 1f) * freeY
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (!dragging) placeMini()
    }

    // ---------- sürükləmə / toxunma ----------
    private fun startDrag(ev: MotionEvent) {
        downX = ev.rawX; downY = ev.rawY
        startTx = translationX; startTy = translationY
        dragging = false
    }

    private fun moveTo(ev: MotionEvent) {
        val p = parent as? View ?: return
        val maxX = (p.width - width).coerceAtLeast(0).toFloat()
        val maxY = (p.height - height).coerceAtLeast(0).toFloat()
        translationX = (startTx + ev.rawX - downX).coerceIn(0f, maxX)
        translationY = (startTy + ev.rawY - downY).coerceIn(0f, maxY)
    }

    private fun savePos() {
        val p = parent as? View ?: return
        val freeX = (p.width - width).coerceAtLeast(0)
        val freeY = (p.height - height).coerceAtLeast(0)
        posFx = if (freeX > 0) translationX / freeX else 1f
        posFy = if (freeY > 0) translationY / freeY else 1f
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (full) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> startDrag(ev)
            MotionEvent.ACTION_MOVE -> if (!dragging && (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)) {
                dragging = true
                return true
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (full) return super.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { startDrag(ev); return true }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)) dragging = true
                if (dragging) moveTo(ev)
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) savePos() else toggleCtl()
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; return true }
        }
        return true
    }

    private fun toggleCtl() {
        h.removeCallbacks(hideCtl)
        if (miniCtl.visibility == View.VISIBLE) miniCtl.visibility = View.GONE
        else { miniCtl.visibility = View.VISIBLE; h.postDelayed(hideCtl, 3500) }
    }

    private fun keepCtl() { h.removeCallbacks(hideCtl); h.postDelayed(hideCtl, 3500) }

    // ---------- tətbiq fona keçəndə / qayıdanda ----------
    fun onBackground() {
        if (!alive) return
        resumeOnFg = !userPaused
        gen++                                   // gözləyən təkrar cəhdlər ləğv olunur
        if (engine == "vlc") { val vp = vlc; try { vlcExec.execute { try { vp?.stop() } catch (e: Exception) { } } } catch (e: Exception) { } }
        else m3?.stop()
    }

    fun onForeground() {
        if (!alive || !resumeOnFg) return
        resumeOnFg = false
        if (profiles.isNotEmpty()) begin()      // canlı yayım üçün təzədən qoşulur (köhnə mövqedən yox)
    }

    fun closePlayer() {
        if (!alive) return
        alive = false
        h.removeCallbacksAndMessages(null)
        lockPortrait(false)
        releaseM3(); releaseVlc(true)
        try { vlcExec.shutdown() } catch (e: Exception) { }   // növbədəki release bitəndən sonra xətt bağlanır
        (parent as? ViewGroup)?.removeView(this)
        if (inst === this) inst = null
    }

    private fun setEngine(e: String) {
        if (e == engine || switching) return      // keçid bitməmiş yeni keçid başlamır (sürətli təkrar toxunuş çökmə/donma verirdi)
        switching = true
        engine = e
        prefs.edit().putString("engine", engine).apply()
        gen++
        h.removeCallbacks(okRun); h.removeCallbacks(stallRun)
        releaseM3(); releaseVlc()                 // VLC-nin bağlanması arxa fonda gedir (əsas axını bloklamır)
        applyEngineViews()
        val g = gen
        h.postDelayed({
            switching = false
            if (alive && g == gen) loadCurrent()  // yeni player səthi (surface) hazır olandan sonra başlayır
        }, 350)
    }

    private fun applyEngineViews() {
        pv.visibility = if (engine == "media3") View.VISIBLE else View.GONE
        vl.visibility = if (engine == "vlc") View.VISIBLE else View.GONE
        val on = rounded(0xFF2563EB.toInt(), 24); val off = rounded(0x00000000, 24)
        miniEng.text = if (engine == "vlc") "VLC" else "Ott"
        engM3.background = if (engine == "media3") on else off
        engVlc.background = if (engine == "vlc") on else off
        engM3.setTextColor(if (engine == "media3") Color.WHITE else 0xFF9CA3AF.toInt())
        engVlc.setTextColor(if (engine == "vlc") Color.WHITE else 0xFF9CA3AF.toInt())
    }

    // ---------- kanal naviqasiyası ----------
    private fun showName() {
        val cur = PlayQueue.items.getOrNull(PlayQueue.index) ?: return
        curName = cur.name
        nameTv.text = "${PlayQueue.index + 1}/${PlayQueue.items.size}  ${cur.name}"
        miniNameTv.text = "📺 " + cur.name
        linkBtn.text = cur.url
    }

    fun loadCurrent() {
        val cur = PlayQueue.items.getOrNull(PlayQueue.index) ?: return
        h.removeCallbacks(stepRun)
        showName()
        url = cur.url
        prefs.edit().putString("lastUrl", cur.url).apply()
        profiles = Net.profiles(cur.url, cur.hdr); pIdx = 0
        msg = ""; prevAhead = -1; latency = -1; speedBps = -1; vlcBuf = 100f; vlcPlaying = false
        userPaused = false; resumeOnFg = false
        begin()
    }

    /** Tək basışda kanal DƏRHAL açılır; sürətli ardıcıl basışlarda ad/link dərhal dəyişir, yalnız SON kanal açılır (aralıq kanallara boş yerə qoşulmur). */
    private fun step(d: Int) {
        val n = PlayQueue.items.size
        if (n == 0) return
        PlayQueue.index = (PlayQueue.index + d + n) % n
        val now = SystemClock.uptimeMillis()
        val rapid = now - lastStepMs < 500
        lastStepMs = now
        h.removeCallbacks(stepRun)
        if (rapid) { showName(); h.postDelayed(stepRun, 220) } else loadCurrent()
    }

    // ---------- ortaq başlatma / xəta ----------
    private fun begin() {
        val t = profiles[pIdx]; target = t
        gen++
        prevAhead = -1
        m3Retry = 0; m3Behind = 0
        lastLoadMs = SystemClock.uptimeMillis()
        sniffTried = false
        if (engine == "vlc") startVlc(t)
        else startM3(t, Media3Cfg.fastKind(t))   // şəbəkə sorğusu gözlənmir: kanal dərhal açılır
    }

    private fun onEngineError(d: String, why: Why.R? = null) {
        if (pIdx < profiles.size - 1) {
            pIdx++; msg = "🔁 Profil: ${profiles[pIdx].name} ($d)"; begin()
        } else {
            msg = "❌ $d"; pIdx = 0
            if (engine == "media3") {
                if (why != null) Net.forceReason(url, why)   // niyə açılmadığı kanal adının yanında qırmızı mötərizədə görünür
                Net.exoFail(url)   // Media3 xəta mesajı verdi (məs. IO_UNSPECIFIED: link açılır, canlı yayım gəlmir) → siyahıda kanal 🔴
                onDead?.invoke(url)
            }
            val g = gen
            h.postDelayed({ if (alive && g == gen) begin() }, 5000)
        }
    }

    // ---------- Media3 (androidx.media3) ----------
    /** READY olandan 3 san sonra hələ də oynayırsa kanal işləkdir (yalnız manifest açılıb, yayım gəlmirsə → xəta gəlir və 🔴 olur). */
    private val okRun = Runnable {
        val p = m3 ?: return@Runnable
        if (alive && p.playbackState == Player.STATE_READY && p.isPlaying) { Net.markGood(target.url, target.name); Net.exoOk(url) }
    }

    /** Bufer 20 saniyədir dolmur (yayım gəlmir / donub) → xəta sayılır: növbəti profil, sonda kanal 🔴. */
    private val stallRun = Runnable {
        val p = m3 ?: return@Runnable
        if (alive && !userPaused && p.playbackState == Player.STATE_BUFFERING)
            onEngineError("bufer 20 san dolmur", Why.R("yayım gəlmir (bufer 20 san dolmur)", 1))
    }

    private fun ensureM3(): ExoPlayer {
        m3?.let { return it }
        // Bir sıra IPTV serverləri Media3-in standart User-Agent-ını qəbul etmir.
        // Chrome UA ehtiyatı, daha uzun timeout və yönləndirmə canlı yayımda IO xətalarını azaldır.
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(target.headers["User-Agent"] ?: Net.CHROME)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val ds = ResolvingDataSource.Factory(http, ResolvingDataSource.Resolver { spec -> spec.withAdditionalHeaders(target.headers) })
        m3Ds = ds
        // Canlı IPTV üçün tənzimlənmiş Media3: tez start, TS bayraqları, dekoder ehtiyatı, səs fokusu, altyazısız yüngül izlər
        val p = ExoPlayer.Builder(ctx, Media3Cfg.renderers(ctx))
            .setMediaSourceFactory(Media3Cfg.mediaSourceFactory(ds))
            .setLoadControl(Media3Cfg.loadControl())
            .setTrackSelector(Media3Cfg.trackSelector(ctx))
            .setAudioAttributes(Media3Cfg.audio(), true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                h.removeCallbacks(okRun); h.removeCallbacks(stallRun)
                if (state == Player.STATE_READY) { msg = ""; m3Retry = 0; m3Behind = 0; h.postDelayed(okRun, 3000) }   // 3 san xətasız davam edərsə → həqiqətən işləyir
                else if (state == Player.STATE_BUFFERING && !userPaused) h.postDelayed(stallRun, 20000)
            }
            override fun onPlayerError(e: PlaybackException) {
                h.removeCallbacks(okRun); h.removeCallbacks(stallRun)
                val pl = m3 ?: return
                // canlı yayım pəncərəsindən geri qalıb: xəta deyil, canlı kənara qayıdıb yenidən hazırlanır
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW && m3Behind < 5) {
                    m3Behind++
                    pl.seekToDefaultPosition(); pl.prepare()
                    return
                }
                // format tanınmadı (uzantısız/yönləndirici HLS-DASH ola bilər): yalnız indi növ aşkarlanıb bir dəfə yenidən başlayır
                if (!sniffTried && (e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                        e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED)) {
                    sniffTried = true
                    val t = target; val g = gen
                    Thread {
                        val k = try { Media3Cfg.kindOf(t) } catch (x: Exception) { 0 }
                        h.post {
                            if (alive && g == gen && engine == "media3") {
                                if (k != 0) startM3(t, k) else onEngineError(errText(e), Why.fromPlayback(e))
                            }
                        }
                    }.start()
                    return
                }
                // keçici xəta: dərhal növbəti profilə keçmədən eyni profil 2 dəfə (artan fasilə ilə) təkrar sınanır
                if (Media3Cfg.transient(e.errorCode) && m3Retry < 3) {
                    m3Retry++
                    msg = "🔁 Təkrar cəhd $m3Retry/3 (${e.errorCodeName})"
                    val g = gen
                    h.postDelayed({
                        if (alive && g == gen) m3?.let { it.seekToDefaultPosition(); it.prepare() }
                    }, 1000L * m3Retry)
                    return
                }
                onEngineError(errText(e), Why.fromPlayback(e))
            }
        })
        p.addAnalyticsListener(object : AnalyticsListener {
            override fun onLoadCompleted(t: AnalyticsListener.EventTime, i: LoadEventInfo, d: MediaLoadData) {
                if (i.loadDurationMs > 0) speedBps = i.bytesLoaded * 8000 / i.loadDurationMs
            }
        })
        p.setPlaybackSpeed(speed)
        pv.player = p
        applyM3Resize()
        m3 = p
        return p
    }

    /** kind: 0 avto/TS/progressiv, 1 HLS, 2 DASH. HLS ayrıca mənbə ilə qurulur (TS bayraqları + tez hazırlıq). */
    private fun startM3(t: Net.Target, kind: Int) {
        val p = ensureM3()
        val mi = MediaItem.Builder().setUri(t.url)
        if (kind == 1) mi.setMimeType(MimeTypes.APPLICATION_M3U8)
        else if (kind == 2) mi.setMimeType(MimeTypes.APPLICATION_MPD)
        val item = mi.build()
        val ds = m3Ds
        if (kind == 1 && ds != null) p.setMediaSource(Media3Cfg.hlsSource(ds, item)) else p.setMediaItem(item)
        p.prepare(); p.playWhenReady = true
    }

    private fun errText(e: PlaybackException): String {
        var c: Throwable? = e.cause
        var code = ""
        while (c != null) {
            if (c is HttpDataSource.InvalidResponseCodeException) { code = " HTTP " + c.responseCode; break }
            c = c.cause
        }
        return e.errorCodeName + code + (e.cause?.message?.let { " – $it" } ?: "")
    }

    private fun releaseM3() {
        h.removeCallbacks(stallRun); h.removeCallbacks(okRun)
        pv.player = null
        val p = m3; m3 = null
        try { p?.release() } catch (e: Exception) { }
    }

    // ---------- LibVLC ----------
    private fun startVlc(t: Net.Target) {
        val lib = vlcLib ?: LibVLC(ctx, arrayListOf("--http-reconnect", "--network-caching=1000", "--no-stats")).also { vlcLib = it }
        val p = vlc ?: MediaPlayer(lib).also { vp ->
            vp.attachViews(vl, null, false, false)
            vp.setEventListener(object : MediaPlayer.EventListener {
                override fun onEvent(event: MediaPlayer.Event) { onVlcEvent(event) }
            })
            vlc = vp
        }
        val my = gen
        val spd = speed
        // setMedia/play native tərəfdə əvvəlki axını bağlayır (şəbəkə) və əsas axını ilişdirirdi → arxa fonda, ardıcıl icra olunur;
        // növbədə gözləyən köhnə kanal sorğuları (gen dəyişib) atlanır.
        try {
            vlcExec.execute {
                if (!alive || my != gen || vlc !== p) return@execute
                try {
                    val m = Media(lib, Uri.parse(t.url))
                    t.headers["User-Agent"]?.let { m.addOption(":http-user-agent=$it") }
                    t.headers["Referer"]?.let { m.addOption(":http-referrer=$it") }
                    m.addOption(":network-caching=1000")
                    p.setMedia(m)
                    m.release()
                    p.play()
                    if (spd != 1f) p.setRate(spd)
                } catch (x: Exception) { }
                h.post { if (alive && my == gen && vlc === p) applyResize() }
            }
        } catch (x: Exception) { }
    }

    private fun onVlcEvent(e: MediaPlayer.Event) {
        when (e.type) {
            MediaPlayer.Event.Playing -> { vlcPlaying = true; msg = ""; Net.markGood(target.url, target.name) }
            MediaPlayer.Event.Vout -> { applyResize(); h.postDelayed({ applyResize() }, 400) }   // video çıxışı hazır olanda ekrana sığdır
            MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> vlcPlaying = false
            MediaPlayer.Event.Buffering -> vlcBuf = e.buffering
            MediaPlayer.Event.EncounteredError -> { vlcPlaying = false; onEngineError("VLC xətası") }
            else -> {}
        }
    }

    /**
     * VLC-nin stop()/release() çağırışları native tərəfdə bloklaya bilir; əsas axında çağırılanda tətbiq donurdu,
     * LibVLC dərhal yenidən yaradılanda isə çökürdü. İndi: dinləyici söndürülür və görüntü əsas axında qoparılır (sürətli),
     * stop/release isə arxa fonda gedir. LibVLC keçidlər arasında saxlanır, yalnız panel bağlananda (withLib) buraxılır.
     */
    private fun releaseVlc(withLib: Boolean = false) {
        val p = vlc
        vlc = null
        vlcPlaying = false
        val lib = if (withLib) vlcLib else null
        if (withLib) vlcLib = null
        if (p == null && lib == null) return
        try { p?.setEventListener(null) } catch (e: Exception) { }
        try { p?.detachViews() } catch (e: Exception) { }
        val job = Runnable {
            try { p?.stop() } catch (e: Exception) { }
            try { p?.release() } catch (e: Exception) { }
            try { lib?.release() } catch (e: Exception) { }
        }
        // eyni ardıcıllıq xəttində: işləyən/gözləyən setMedia-play bitməmiş stop/release başlamır (native çökmə olmur)
        try { vlcExec.execute(job) } catch (e: Exception) { Thread(job).start() }
    }

    private fun togglePause() {
        if (engine == "vlc") {
            val p = vlc ?: return
            if (p.isPlaying) { p.pause(); userPaused = true } else { p.play(); userPaused = false }
        } else {
            val p = m3 ?: return
            if (p.playWhenReady) { p.pause(); userPaused = true } else { p.play(); userPaused = false }
        }
        updatePlayIcon()
    }

    private fun updatePlayIcon() {
        val playing = if (engine == "vlc") (vlc?.isPlaying == true) else (m3?.playWhenReady == true)
        val res = if (playing) R.drawable.ic_pause else R.drawable.ic_play
        if (res == lastIcon) return
        lastIcon = res
        playBtn.setImageResource(res)
        miniPlay.setImageDrawable(glowIcon(res))
    }

    /** Video həmişə "Sığdır" rejimindədir (kiçik və tam ekranda). */
    private fun applyM3Resize() { pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT }

    private fun applyAllResize() { applyM3Resize(); applyResize() }

    private fun applyResize() {
        val p = vlc ?: return
        p.setAspectRatio(null); p.setScale(0f); p.setVideoScale(MediaPlayer.ScaleType.SURFACE_BEST_FIT)
        // VLC pəncərə ölçüsünü köhnə (kiçik) qiymətdə saxlayırdı → görüntü tam sahəni tutmurdu
        val w = vl.width; val ht = vl.height
        if (w > 0 && ht > 0) try { p.vlcVout.setWindowSize(w, ht) } catch (e: Exception) { }
    }

    // ---------- ℹ️ kanal məlumatı ----------
    private fun showInfo(on: Boolean) {
        if (on) { infoTv.text = buildInfo(); infoOverlay.visibility = View.VISIBLE }
        else infoOverlay.visibility = View.GONE
    }

    private fun codecName(m: String?): String = when (m) {
        null -> "?"
        "video/avc" -> "H.264 (AVC)"; "video/hevc" -> "H.265 (HEVC)"; "video/av01" -> "AV1"
        "video/mpeg2" -> "MPEG-2"; "video/x-vnd.on2.vp9" -> "VP9"; "video/x-vnd.on2.vp8" -> "VP8"
        "audio/mp4a-latm" -> "AAC"; "audio/ac3" -> "AC-3 (Dolby Digital)"; "audio/eac3" -> "E-AC-3 (Dolby Digital+)"
        "audio/mpeg" -> "MP3"; "audio/mpeg-L2" -> "MP2"; "audio/opus" -> "Opus"; "audio/vorbis" -> "Vorbis"
        "audio/true-hd" -> "Dolby TrueHD"; "audio/vnd.dts" -> "DTS"; "audio/vnd.dts.hd" -> "DTS-HD"
        "application/x-subrip" -> "SRT"; "text/vtt" -> "WebVTT"; "application/cea-608" -> "CEA-608"; "application/cea-708" -> "CEA-708"
        "application/dvbsubs" -> "DVB altyazı"; "application/x-mpegURL" -> "HLS"
        else -> m.substringAfter('/')
    }

    private fun chName(n: Int) = when (n) { 1 -> "mono"; 2 -> "stereo"; 6 -> "5.1"; 8 -> "7.1"; else -> if (n > 0) "$n kanal" else "?" }

    private fun kbps(b: Int) = if (b > 0) (if (b >= 1_000_000) "%.2f Mbps".format(b / 1e6) else "${b / 1000} kbps") else "naməlum"

    private fun fmtLine(f: Format, video: Boolean): String {
        val parts = ArrayList<String>()
        parts += codecName(f.sampleMimeType)
        if (!f.codecs.isNullOrEmpty()) parts += "(${f.codecs})"
        if (video) {
            if (f.width > 0) parts += "${f.width}×${f.height}"
            if (f.frameRate > 0f) parts += "${"%.2f".format(f.frameRate).trimEnd('0').trimEnd('.')} fps"
        } else {
            if (f.channelCount > 0) parts += chName(f.channelCount)
            if (f.sampleRate > 0) parts += "${f.sampleRate} Hz"
        }
        val br = if (f.bitrate > 0) f.bitrate else f.averageBitrate
        if (br > 0) parts += kbps(br)
        return parts.joinToString(" · ")
    }

    private fun langOf(lang: String?, label: String?): String {
        val l = listOfNotNull(label?.takeIf { it.isNotBlank() }, lang?.takeIf { it.isNotBlank() && it != "und" }).joinToString(" / ")
        return if (l.isEmpty()) "adsız" else l
    }

    private fun urlFormat(u: String): String {
        val p = u.substringBefore('?').lowercase()
        return when {
            p.endsWith(".m3u8") -> "HLS (m3u8)"; p.endsWith(".mpd") -> "DASH (mpd)"; p.endsWith(".ts") -> "MPEG-TS"
            p.endsWith(".mp4") -> "MP4"; p.endsWith(".mkv") -> "MKV"; p.endsWith(".flv") -> "FLV"
            else -> "naməlum (birbaşa axın / TS ola bilər)"
        }
    }

    private fun buildInfo(): String {
        val sb = StringBuilder()
        sb.append("📺 ").append(curName.ifEmpty { "—" }).append("\n")
        sb.append("⚙️ Player: ").append(if (engine == "vlc") "VLC" else "Ott (Media3)").append("\n\n")
        try {
            if (engine == "vlc") vlcInfo(sb) else m3Info(sb)
        } catch (e: Exception) {
            sb.append("Məlumat oxunmadı: ").append(e.message ?: e.javaClass.simpleName).append("\n")
        }
        sb.append("\n🛰 Gecikmə: ").append(if (latency >= 0) "$latency ms" else "naməlum")
        sb.append("\n⬇ Sürət: ").append(fmt(speedBps))
        sb.append("\n\n🔗 ").append(target.url.ifEmpty { url })
        return sb.toString()
    }

    private fun m3Info(sb: StringBuilder) {
        val p = m3
        if (p == null) { sb.append("Player hələ hazır deyil.\n"); return }
        val man = p.currentManifest?.javaClass?.simpleName ?: ""
        val container = when {
            man.contains("Hls", true) -> "HLS"
            man.contains("Dash", true) -> "DASH"
            else -> urlFormat(target.url)
        }
        sb.append("📦 Format: ").append(container)
        p.videoFormat?.containerMimeType?.let { sb.append(" · ").append(codecName(it)) }
        sb.append("\n\n")
        val groups = p.currentTracks.groups
        for ((type, title, icon) in listOf(Triple(C.TRACK_TYPE_VIDEO, "Video", "🎞"), Triple(C.TRACK_TYPE_AUDIO, "Audio", "🔊"), Triple(C.TRACK_TYPE_TEXT, "Altyazı", "💬"))) {
            val lines = ArrayList<String>()
            for (g in groups) {
                if (g.type != type) continue
                for (i in 0 until g.length) {
                    val f = g.getTrackFormat(i)
                    val mark = if (g.isTrackSelected(i)) "✅" else if (g.isTrackSupported(i)) "▫️" else "⛔"
                    val lang = if (type == C.TRACK_TYPE_VIDEO) "" else langOf(f.language, f.label) + " — "
                    lines += "$mark $lang${fmtLine(f, type == C.TRACK_TYPE_VIDEO)}"
                }
            }
            sb.append(icon).append(" ").append(title).append(" izləri (").append(lines.size).append(")\n")
            if (lines.isEmpty()) sb.append("   yoxdur\n") else lines.forEachIndexed { i, l -> sb.append("   ${i + 1}. ").append(l).append("\n") }
            sb.append("\n")
        }
        p.videoFormat?.let { f ->
            sb.append("🔲 Aktiv video: ").append(fmtLine(f, true)).append("\n")
            if (f.pixelWidthHeightRatio != 1f && f.pixelWidthHeightRatio > 0f) sb.append("   Piksel nisbəti: ").append("%.3f".format(f.pixelWidthHeightRatio)).append("\n")
            f.colorInfo?.let { ci -> sb.append("   Rəng: ").append(ci.toString().take(80)).append("\n") }
        }
        p.audioFormat?.let { sb.append("🔉 Aktiv audio: ").append(fmtLine(it, false)).append("\n") }
        sb.append("\n✅ aktiv   ▫️ mövcud   ⛔ dəstəklənmir\n")
    }

    private fun vlcInfo(sb: StringBuilder) {
        val p = vlc
        if (p == null) { sb.append("Player hələ hazır deyil.\n"); return }
        sb.append("📦 Format: ").append(urlFormat(target.url)).append("\n\n")
        val vt = p.getCurrentVideoTrack()
        sb.append("🎞 Video\n")
        if (vt != null && vt.width > 0) {
            val fr = if (vt.frameRateDen > 0) vt.frameRateNum.toFloat() / vt.frameRateDen else 0f
            sb.append("   ").append(vt.codec ?: "?").append(" · ${vt.width}×${vt.height}")
            if (fr > 0f) sb.append(" · ${"%.2f".format(fr).trimEnd('0').trimEnd('.')} fps")
            if (vt.bitrate > 0) sb.append(" · ").append(kbps(vt.bitrate))
            sb.append("\n")
        } else sb.append("   hələ məlum deyil\n")
        sb.append("\n")
        // izlərin təfsilatı (codec, kanal, tezlik) Media-dan; adlar və aktiv iz MediaPlayer-dən
        val det = HashMap<Int, String>()
        var subs = 0
        try {
            val md = p.media
            if (md != null) {
                for (i in 0 until md.trackCount) {
                    val t = md.getTrack(i)
                    if (t.type == IMedia.Track.Type.Audio) {
                        val a = t as IMedia.AudioTrack
                        val parts = ArrayList<String>()
                        parts += (a.codec ?: "?")
                        if (a.channels > 0) parts += chName(a.channels)
                        if (a.rate > 0) parts += "${a.rate} Hz"
                        if (a.bitrate > 0) parts += kbps(a.bitrate)
                        det[a.id] = parts.joinToString(" · ")
                    } else if (t.type == IMedia.Track.Type.Text) subs++
                }
                md.release()
            }
        } catch (e: Exception) { }
        val at = p.audioTracks?.filter { it.id >= 0 } ?: emptyList()
        val cur = p.audioTrack
        sb.append("🔊 Audio izləri (").append(at.size).append(")\n")
        if (at.isEmpty()) sb.append("   yoxdur\n")
        at.forEachIndexed { i, t ->
            sb.append("   ${i + 1}. ").append(if (t.id == cur) "✅ " else "▫️ ").append(t.name ?: "adsız")
            det[t.id]?.let { sb.append(" — ").append(it) }
            sb.append("\n")
        }
        val st = p.spuTracks?.filter { it.id >= 0 } ?: emptyList()
        sb.append("\n💬 Altyazı izləri (").append(st.size).append(")\n")
        if (st.isEmpty()) sb.append("   yoxdur\n")
        st.forEachIndexed { i, t -> sb.append("   ${i + 1}. ").append(if (t.id == p.spuTrack) "✅ " else "▫️ ").append(t.name ?: "adsız").append("\n") }
        sb.append("\n✅ aktiv   ▫️ mövcud\n")
    }

    // ---------- statistika ----------
    private fun fmt(bps: Long) = when {
        bps <= 0 -> "naməlum"; bps >= 1_000_000 -> "%.2f Mbps".format(bps / 1e6); else -> "${bps / 1000} kbps"
    }

    private fun tick() {
        if (!alive) return
        var res = "naməlum"
        var br = -1L
        val lab: String
        if (engine == "vlc") {
            val vt = vlc?.getCurrentVideoTrack()
            if (vt != null && vt.width > 0) res = "${vt.width}×${vt.height}"
            if (vt != null && vt.bitrate > 0) br = vt.bitrate.toLong()
            lab = if (!vlcPlaying) "🔴" else if (vlcBuf < 100f) "🟠" else "🟢"
        } else {
            val p = m3
            val f = p?.videoFormat
            if (f != null && f.width > 0) res = "${f.width}×${f.height}"
            if (f != null) br = (if (f.bitrate > 0) f.bitrate else f.averageBitrate).toLong()
            val ahead = p?.totalBufferedDuration ?: 0L
            lab = Net.bucketEmoji(Net.bucket(p != null && p.playbackState == Player.STATE_READY, ahead, prevAhead))   // yoxlayıcı ilə eyni qayda
            prevAhead = ahead
        }
        val lat = if (latency >= 0) "$latency ms" else "naməlum"
        if (full) {
            val ready = if (engine == "vlc") vlcPlaying else (m3?.playbackState == Player.STATE_READY)
            val head = if (msg.isNotEmpty() && !ready) msg + "\n" else ""
            statsTv.text = head + "🔲 $res   ⚡ ${fmt(br)}\n🛰 $lat   ⬇ ${fmt(speedBps)}   🪣 $lab"
        } else {
            // kiçik pəncərədə eyni ölçmələr kompakt şəkildə
            miniNameTv.text = "$lab $curName"
            miniStatsTv.text = "🔲 $res  🛰 $lat\n⚡ ${fmt(br)}  ⬇ ${fmt(speedBps)}"
        }
        if (full && infoOverlay.visibility == View.VISIBLE) infoTv.text = buildInfo()
        updatePlayIcon()
        h.postDelayed({ tick() }, 1000)
    }

    /** Gecikmə (ilk bayta qədər) və VLC üçün təxmini endirmə sürəti; hər 6 saniyədə bir (kiçik və tam ekranda). */
    private fun probeOnce() {
        // kanal yeni açılıb: yayımla yarışan əlavə bağlantı açılmır (ilk 6 san), Ott üçün yalnız gecikmə ölçülür
        if (SystemClock.uptimeMillis() - lastLoadMs < 6000) return
        val t = target
        val vlcMode = engine == "vlc"
        Thread {
            try {
                val t0 = System.nanoTime()
                val c = Net.connect(t, "bytes=0-262143", 8000)
                val s = c.inputStream
                if (s.read() >= 0) {
                    latency = (System.nanoTime() - t0) / 1_000_000
                    if (!vlcMode) { c.disconnect(); return@Thread }
                    var total = 1L
                    val buf = ByteArray(16384)
                    while (total < 262144) { val n = s.read(buf); if (n < 0) break; total += n }
                    val ms = (System.nanoTime() - t0) / 1_000_000
                    if (engine == "vlc" && ms > 0 && total >= 65536) speedBps = total * 8000 / ms
                }
                c.disconnect()
            } catch (e: Exception) { }
        }.start()
    }

    private fun probeLoop() {
        if (!alive) return
        if (inFg()) probeOnce()
        h.postDelayed({ probeLoop() }, 6000)
    }
}
