package az.mehdi.iptvplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.Normalizer

/** Loqolar yalnız EPG_NOARCH XMLTV faylındakı <icon src="..."> mənbəyindən götürülür. */
class LogoStore(private val ctx: Context, private val scope: CoroutineScope, private val epg: EpgStore) {
    private val dir = File(ctx.filesDir, "epg_logo_cache").apply { mkdirs() }
    private val sem = Semaphore(4)
    private val mem = object : LruCache<String, Bitmap>(8 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = (value.byteCount / 1024).coerceAtLeast(1)
    }

    private fun norm(s: String): String {
        var t = s.lowercase().replace('ə', 'e').replace('ı', 'i')
        t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        t = t.replace(Regex("\\b(hd|fhd|uhd|sd|4k|8k|hevc|h265|backup)\\b"), " ")
        return t.replace(Regex("[^a-z0-9]"), "")
    }
    private fun hash(s: String) = MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun fileFor(key: String) = File(dir, hash(key) + ".img")
    private fun urlFile(key: String) = File(dir, hash(key) + ".url")

    private fun decode(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 256) sample *= 2
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private suspend fun download(url: String, dest: File): Bitmap? = sem.withPermit {
        withContext(Dispatchers.IO) {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000; readTimeout = 12000; instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) MehdiPlayer")
            }
            val tmp = File(dest.path + ".tmp")
            try {
                if (conn.responseCode !in 200..299) return@withContext null
                conn.inputStream.use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
                val bitmap = decode(tmp) ?: return@withContext null
                if (dest.exists()) dest.delete(); tmp.renameTo(dest)
                bitmap
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { tmp.delete(); null }
            finally { conn.disconnect() }
        }
    }

    suspend fun bitmapFor(ch: Channel): Bitmap? {
        val key = norm(ch.name)
        if (key.isEmpty()) return null
        mem.get(key)?.let { return it }
        val file = fileFor(key)
        if (file.exists() && file.length() > 0) {
            val cached = withContext(Dispatchers.IO) { decode(file) }
            if (cached != null) { mem.put(key, cached); return cached }
        }
        epg.awaitReady()
        val url = epg.logoFor(ch.name) ?: return null
        val previousUrl = runCatching { urlFile(key).readText() }.getOrNull()
        if (file.exists() && previousUrl == url) {
            val cached = withContext(Dispatchers.IO) { decode(file) }
            if (cached != null) { mem.put(key, cached); return cached }
        }
        val bitmap = download(url, file) ?: return null
        runCatching { urlFile(key).writeText(url) }
        mem.put(key, bitmap)
        return bitmap
    }

    suspend fun refreshAll(channels: List<Channel>): Int {
        epg.awaitReady()
        var updated = 0
        val seen = HashSet<String>()
        for (ch in channels) {
            val key = norm(ch.name)
            if (key.isEmpty() || !seen.add(key)) continue
            val url = epg.logoFor(ch.name) ?: continue
            val file = fileFor(key)
            val stored = runCatching { urlFile(key).readText() }.getOrNull()
            if (!file.exists() || stored != url) {
                val bmp = download(url, file) ?: continue
                urlFile(key).writeText(url); mem.put(key, bmp); updated++
            }
        }
        return updated
    }
}
