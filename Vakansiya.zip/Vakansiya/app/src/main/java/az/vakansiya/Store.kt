package az.vakansiya

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Site(var name: String, var url: String, var last: String = "", var today: Int = -1, var yest: Int = -1, var skip: Boolean = false) {
    // yalnız iş zamanı (yadda saxlanmır)
    var links: List<String>? = null
    var fresh: Int = -1
}

object Store {
    private val DEFAULTS = listOf(
        "HelloJob" to "https://www.hellojob.az/vakansiyalar",
        "Work.az" to "https://www.work.az/vakansiyalar?orderBy=DATE&orderDirection=DESC",
        "Busy.az" to "https://busy.az/vacancies",
        "HRIN" to "https://hrin.az/",
        "Glorri Jobs" to "https://jobs.glorri.az/?cityId=62f1516b22d84be76acb9d2d",
        "JobSearch" to "https://jobsearch.az/vacancies",
        "JobSearch Staj" to "https://jobsearch.az/internship-program",
        "eJob" to "https://ejob.az/is-elanlari/",
        "AzVak" to "https://azvak.az/",
        "AzJob" to "https://azjob.az/",
        "İşəqəbul" to "https://iseqebul.az/",
        "Boss.az" to "https://boss.az/search/vacancies",
        "EasyJob" to "https://easyjob.az/?search=&company_id=&category_id=&date=three_days&salary=",
        "HumanPro" to "https://humanpro.az/az/vakansiyalar",
        "Jooble" to "https://jooble.az/",
        "JobSite (İT)" to "https://jobsite.az/vakansiya-is-elanlari/informasiya-texnologiyalari",
        "JobSite Staj" to "https://jobsite.az/vakansiya-is-elanlari#staj",
        "Jobing (Bakı)" to "https://jobing.az/baki",
        "Vəzifə" to "https://vezife.az/",
        "Jobu" to "https://jobu.az/vakansiyalar/?filter-orderby=newest"
    )

    /** Yoxlanılmayan saytlar (istifadəçi sonradan dəyişə bilər). */
    fun defaultSkip(url: String) = listOf("hrin.az", "easyjob.az").any { url.contains(it) }

    /** "#staj" ilə bitən JobSite ünvanı: yalnız təcrübə/staj elanları sayılır. */
    fun stajFilter(url: String) = url.contains("jobsite.az") && url.endsWith("#staj")

    /** Elan tarixi yalnız elanın öz səhifəsində olan saytlar. */
    fun detail(url: String) = url.contains("jobsite.az")

    /** Daha diqqətli (kart əsaslı) yoxlanılan saytlar. */
    fun careful(url: String) = listOf("jobsearch.az", "jobing.az", "jobu.az").any { url.contains(it) }

    private fun p(c: Context) = c.getSharedPreferences("vak", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Site> {
        val s = p(c).getString("sites", null)
        val l = mutableListOf<Site>()
        if (s == null) {
            DEFAULTS.forEach { l.add(Site(it.first, it.second, skip = defaultSkip(it.second))) }
            save(c, l)
            return l
        }
        val a = JSONArray(s)
        val migrated = p(c).getBoolean("mig_jobsite", false)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            l.add(Site(o.getString("n"), o.getString("u"), o.optString("l", ""), o.optInt("t", -1), o.optInt("y", -1),
                if (o.has("k")) o.getBoolean("k") else defaultSkip(o.getString("u"))))
        }
        if (!p(c).getBoolean("mig_staj", false)) {
            if (l.none { it.url.endsWith("#staj") }) {
                val idx = l.indexOfFirst { it.url.contains("jobsite.az") }
                l.add(if (idx >= 0) idx + 1 else l.size, Site("JobSite Staj", "https://jobsite.az/vakansiya-is-elanlari#staj"))
            }
            p(c).edit().putBoolean("mig_staj", true).apply()
            save(c, l)
        }
        if (!migrated) {
            l.filter { it.url.contains("jobsite.az") }.forEach { it.skip = false }
            p(c).edit().putBoolean("mig_jobsite", true).apply()
            save(c, l)
        }
        return l
    }

    fun save(c: Context, l: List<Site>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("n", it.name).put("u", it.url).put("l", it.last).put("t", it.today).put("y", it.yest).put("k", it.skip))
        }
        p(c).edit().putString("sites", a.toString()).apply()
    }

    fun setLast(c: Context, base: String, last: String) {
        val l = load(c)
        l.firstOrNull { it.url == base }?.last = last
        save(c, l)
    }
}
