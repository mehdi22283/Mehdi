package az.zengyazici

import android.Manifest
import android.app.*
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.*

class RecorderService : Service() {

    companion object {
        @Volatile var lastVoipSeen = 0L
        @Volatile var running = false
        const val CH_STATUS = "status"
        const val CH_REC = "rec"
        const val CH_DONE = "done"
        const val ID_STATUS = 1
        const val ID_REC = 2
        const val ID_DONE = 3
        const val FOLDER = "ZengYazici"
    }

    private enum class Kind { PHONE, WHATSAPP }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var audio: AudioManager
    private lateinit var nm: NotificationManager
    private var recorder: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var fileName = ""
    private var kind: Kind? = null
    private var misses = 0
    private var telCallback: Any? = null

    private val poller = object : Runnable {
        override fun run() {
            poll()
            handler.postDelayed(this, 1500)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(AudioManager::class.java)
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_STATUS, "Xidmət statusu", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_REC, "Zəng yazılır", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Zəng yazıldı", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return START_NOT_STICKY
        }
        try {
            startForeground(ID_STATUS, statusNotification("Arxa fonda işləyir – zəngləri gözləyir"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            stopSelf(); return START_NOT_STICKY
        }
        if (!running) {
            running = true
            registerPhone()
            handler.post(poller)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopRec()
        handler.removeCallbacks(poller)
        unregisterPhone()
        running = false
        super.onDestroy()
    }

    // ---------- Telefon zəngi ----------
    private fun registerPhone() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        val tm = getSystemService(TelephonyManager::class.java)
        if (Build.VERSION.SDK_INT >= 31) {
            val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) = handlePhone(state)
            }
            tm.registerTelephonyCallback(mainExecutor, cb)
            telCallback = cb
        } else {
            @Suppress("DEPRECATION")
            val l = object : PhoneStateListener() {
                @Deprecated("old")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) = handlePhone(state)
            }
            @Suppress("DEPRECATION")
            tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
            telCallback = l
        }
    }

    private fun unregisterPhone() {
        val tm = getSystemService(TelephonyManager::class.java)
        val cb = telCallback ?: return
        try {
            if (Build.VERSION.SDK_INT >= 31 && cb is TelephonyCallback) tm.unregisterTelephonyCallback(cb)
            else if (cb is PhoneStateListener) {
                @Suppress("DEPRECATION")
                tm.listen(cb, PhoneStateListener.LISTEN_NONE)
            }
        } catch (e: Exception) { }
        telCallback = null
    }

    private fun handlePhone(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_OFFHOOK -> if (recorder == null) startRec(Kind.PHONE)
            TelephonyManager.CALL_STATE_IDLE -> if (kind == Kind.PHONE) stopRec()
        }
    }

    // ---------- WhatsApp zəngi ----------
    private fun poll() {
        val inComm = audio.mode == AudioManager.MODE_IN_COMMUNICATION
        val now = System.currentTimeMillis()
        if (recorder == null) {
            if (inComm && lastVoipSeen > 0 && now - lastVoipSeen < 120_000) startRec(Kind.WHATSAPP)
        } else if (kind == Kind.WHATSAPP) {
            if (inComm) misses = 0 else if (++misses >= 3) stopRec()
        }
    }

    // ---------- Yazma ----------
    private fun startRec(k: Kind) {
        if (recorder != null) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return

        val prefix = if (k == Kind.PHONE) "Telefon" else "WhatsApp"
        val name = "${prefix}_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a"
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/$FOLDER")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val u = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return

        val sources = if (k == Kind.PHONE)
            intArrayOf(MediaRecorder.AudioSource.VOICE_CALL, MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)
        else
            intArrayOf(MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)

        for (src in sources) {
            var r: MediaRecorder? = null
            var p: ParcelFileDescriptor? = null
            try {
                p = contentResolver.openFileDescriptor(u, "wt")!!
                r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
                r.setAudioSource(src)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioEncodingBitRate(96_000)
                r.setAudioSamplingRate(44_100)
                r.setOutputFile(p.fileDescriptor)
                r.prepare()
                r.start()
                recorder = r; pfd = p; uri = u; kind = k; fileName = name; misses = 0
                showRecording(prefix)
                return
            } catch (e: Exception) {
                runCatching { r?.release() }
                runCatching { p?.close() }
            }
        }
        contentResolver.delete(u, null, null)
    }

    private fun stopRec() {
        val r = recorder ?: return
        val u = uri
        val k = kind
        var ok = true
        try { r.stop() } catch (e: Exception) { ok = false }
        runCatching { r.release() }
        runCatching { pfd?.close() }
        recorder = null; pfd = null; uri = null; kind = null
        nm.cancel(ID_REC)
        if (k == Kind.WHATSAPP) lastVoipSeen = 0
        nm.notify(ID_STATUS, statusNotification("Arxa fonda işləyir – zəngləri gözləyir"))
        if (u == null) return
        if (ok) {
            contentResolver.update(u, ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }, null, null)
            showDone(u)
        } else {
            contentResolver.delete(u, null, null)
        }
    }

    // ---------- Bildirişlər ----------
    private fun openApp() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun statusNotification(text: String): Notification =
        NotificationCompat.Builder(this, CH_STATUS)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Zəng Yazıcı işləyir")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openApp())
            .build()

    private fun showRecording(what: String) {
        nm.notify(ID_STATUS, statusNotification("$what zəngi yazılır..."))
        val n = NotificationCompat.Builder(this, CH_REC)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("● Zəng yazılır")
            .setContentText("$what zəngi qeydə alınır")
            .setOngoing(true)
            .setUsesChronometer(true)
            .setWhen(System.currentTimeMillis())
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setContentIntent(openApp())
            .build()
        nm.notify(ID_REC, n)
    }

    private fun showDone(u: Uri) {
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(u, "audio/mp4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val pi = PendingIntent.getActivity(this, 1, view, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Zəng yazıldı")
            .setContentText("$fileName – dinləmək üçün toxunun")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        nm.notify(ID_DONE, n)
    }
}
