# Zəng Yazıları (Android, Xiaomi üçün tənzimlənmiş)

Android Studio ilə açın: File > Open > bu qovluq. Sync-dən sonra telefona Run edin.

## Xiaomi (MIUI / HyperOS) quraşdırma - mütləq edin
Tətbiqdə "Xiaomi quraşdırması" > Aç bölməsindən:
1. Avtostart: aç.
2. Batareya: "Məhdudiyyət yoxdur".
3. Əlçatanlıq > Zəng Yazıları köməkçisi: aç (ekran məzmununu oxumur, yalnız tətbiqin arxa fonda ölməsinin qarşısını alır).
4. İcazələr: mikrofon, telefon, zəng jurnalı, bildiriş - hamısı "İcazə ver".
5. Bildirişlərə giriş: "WhatsApp zənglərini aktiv et" düyməsi ilə.
6. Son tətbiqlər ekranında tətbiqi kilidləyin.
Əlavə: Ayarlar > Əlavə ayarlar > Developer options > "MIUI optimization" söndürmək bəzi telefonlarda kömək edir.

## Yazı mənbələri (avtomatik keçid)
Avtomatik rejimdə 11 mənbə sırayla sınanır: VOICE_CALL, VOICE_DOWNLINK, VOICE_UPLINK, REMOTE_SUBMIX, UNPROCESSED,
VOICE_RECOGNITION, MIC, CAMCORDER, VOICE_PERFORMANCE, VOICE_COMMUNICATION, DEFAULT.
Başlamayan və ya ilk 3 saniyəsi səssiz olan mənbə atlanır. İstəsəniz "Səs mənbəyi" menyusundan tək mənbə seçə bilərsiniz.
Hazırda işləyən mənbə yuxarıdakı qırmızı zolaqda göstərilir.
"Zəngdə avtomatik dinamik rejimi" açıq olanda zəng dinamikə keçir ki, qarşı tərəfin səsi mikrofona düşsün.

## Məhdudiyyətlər
- Android 10+ adi tətbiqlərə zəng səsini vermir; hər cür cəhd etsək də nəticə model və proqram versiyasından asılıdır.
- Daha etibarlı yollar: Xiaomi-nin öz Telefon tətbiqindəki zəng yazısı (Telefon > Ayarlar > Zəng yazısı), ya da root (Magisk) ilə sistem səviyyəsində yazı.
- Qarşı tərəfin razılığı olmadan yazmaq qanunsuz ola bilər.
