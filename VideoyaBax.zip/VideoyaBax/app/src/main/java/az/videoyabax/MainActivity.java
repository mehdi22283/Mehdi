package az.videoyabax;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

public class MainActivity extends Activity {
    private LinearLayout idle;
    private TextView ipView;
    private PlayerView pv;
    private ExoPlayer player;
    private int playedGen = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0B1437);

        idle = new LinearLayout(this);
        idle.setOrientation(LinearLayout.VERTICAL);
        idle.setGravity(Gravity.CENTER);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        idle.addView(logo, new LinearLayout.LayoutParams(220, 220));
        idle.addView(text("Videoya bax", 44, 0xFFFFFFFF, true));
        idle.addView(text("Telefonun brauzerində bu ünvanı yazın:", 24, 0xFFB8C4FF, false));
        ipView = text("", 56, 0xFFFFC857, true);
        idle.addView(ipView);
        idle.addView(text("Sonra telefondakı videonu seçin – TV-də avtomatik açılacaq.", 22, 0xFF8FA0E0, false));

        pv = new PlayerView(this);
        pv.setVisibility(android.view.View.GONE);
        pv.setKeepScreenOn(true);

        ViewGroup.LayoutParams mp = new ViewGroup.LayoutParams(-1, -1);
        root.addView(idle, mp);
        root.addView(pv, new ViewGroup.LayoutParams(-1, -1));
        setContentView(root);

        Intent s = new Intent(this, VideoService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        askOverlayOnce();
    }

    private TextView text(String t, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(40, 12, 40, 12);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private void askOverlayOnce() {
        if (Build.VERSION.SDK_INT < 23) return;
        SharedPreferences sp = getSharedPreferences("vb", MODE_PRIVATE);
        if (sp.getBoolean("asked", false) || Settings.canDrawOverlays(this)) return;
        sp.edit().putBoolean("asked", true).apply();
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) { }
    }

    static String localIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) { }
        return "TV-nin-IP-si";
    }

    @Override
    protected void onResume() {
        super.onResume();
        ipView.setText(localIp() + ":" + VideoServer.PORT);
        check();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        check();
    }

    private void check() {
        if (VideoServer.gen > 0 && VideoServer.gen != playedGen) play(VideoServer.gen);
    }

    private void play(int g) {
        playedGen = g;
        releasePlayer();
        DefaultHttpDataSource.Factory df = new DefaultHttpDataSource.Factory()
                .setConnectTimeoutMs(600000).setReadTimeoutMs(600000);
        player = new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(df)).build();
        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException e) {
                Toast.makeText(MainActivity.this, "Video açılmadı: " + e.getErrorCodeName(), Toast.LENGTH_LONG).show();
            }
        });
        pv.setPlayer(player);
        idle.setVisibility(android.view.View.GONE);
        pv.setVisibility(android.view.View.VISIBLE);
        pv.requestFocus();
        player.setMediaItem(MediaItem.fromUri("http://127.0.0.1:" + VideoServer.PORT + "/stream?g=" + g));
        player.prepare();
        player.setPlayWhenReady(true);
    }

    private void releasePlayer() {
        if (player != null) { pv.setPlayer(null); player.release(); player = null; }
    }

    @Override
    public void onBackPressed() {
        if (player != null) {
            releasePlayer();
            pv.setVisibility(android.view.View.GONE);
            idle.setVisibility(android.view.View.VISIBLE);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}
