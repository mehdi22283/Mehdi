package az.m3usinayici;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** WebView-dəki səhifənin (JS) çağırdığı yerli (native) funksiyalar. */
public class NativeBridge {

    static final String UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";

    private final Activity activity;
    private final WebView webView;
    private final InlinePlayers inline;
    private final ExecutorService probePool = Executors.newFixedThreadPool(12);
    private final ExecutorService fetchPool = Executors.newFixedThreadPool(4);
    private final Object stateLock = new Object();

    public NativeBridge(Activity activity, WebView webView, InlinePlayers inline) {
        this.activity = activity;
        this.webView = webView;
        this.inline = inline;
    }

    /* ---------------- daimi yaddaş (birinci playlist + statistika) ---------------- */

    @JavascriptInterface
    public String loadState() {
        synchronized (stateLock) {
            File f = new File(activity.getFilesDir(), "state.json");
            if (!f.exists()) return "";
            try (InputStream in = new FileInputStream(f)) {
                return new String(readAll(in, 100 * 1024 * 1024), StandardCharsets.UTF_8);
            } catch (IOException e) {
                return "";
            }
        }
    }

    @JavascriptInterface
    public void saveState(String json) {
        if (json == null) return;
        synchronized (stateLock) {
            try {
                File dir = activity.getFilesDir();
                File tmp = new File(dir, "state.json.tmp");
                try (FileOutputStream out = new FileOutputStream(tmp)) {
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    out.getFD().sync();
                }
                File dst = new File(dir, "state.json");
                if (!tmp.renameTo(dst)) {
                    dst.delete();
                    tmp.renameTo(dst);
                }
            } catch (IOException ignored) {
            }
        }
    }

    /* ---------------- kanal yoxlaması ---------------- */

    @JavascriptInterface
    public void probe(final int id, final String url) {
        probePool.execute(new Runnable() {
            @Override
            public void run() {
                String r = doProbe(url);
                callJs("window.__nativeProbeDone(" + id + ",\"" + r + "\")");
            }
        });
    }

    private String doProbe(String url) {
        String lower = url == null ? "" : url.toLowerCase();
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return "unknown";
        HttpURLConnection c = null;
        try {
            Map<String, String> h = new HashMap<>();
            h.put("Range", "bytes=0-64");
            c = open(url, "GET", h, 8000);
            int code = c.getResponseCode();
            if (code >= 200 && code < 300) return "ok";
            if (code == 404 || code == 410) return "dead";
            return "unknown";
        } catch (Exception e) {
            return "dead";
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /* ---------------- CORS-suz GET (playlist linki, GitHub API) ---------------- */

    @JavascriptInterface
    public void httpGet(final int id, final String url, final String headersJson) {
        fetchPool.execute(new Runnable() {
            @Override
            public void run() {
                int status = 0;
                String hdrB64 = "";
                String bodyB64 = "";
                HttpURLConnection c = null;
                try {
                    Map<String, String> h = new HashMap<>();
                    if (headersJson != null && headersJson.length() > 2) {
                        JSONObject jo = new JSONObject(headersJson);
                        Iterator<String> it = jo.keys();
                        while (it.hasNext()) {
                            String k = it.next();
                            h.put(k, jo.getString(k));
                        }
                    }
                    c = open(url, "GET", h, 15000);
                    status = c.getResponseCode();
                    JSONObject hj = new JSONObject();
                    for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet()) {
                        String k = e.getKey();
                        if (k == null) continue;
                        k = k.toLowerCase();
                        if (k.equals("content-encoding") || k.equals("content-length")
                                || k.equals("transfer-encoding")) continue;
                        StringBuilder sb = new StringBuilder();
                        for (String v : e.getValue()) {
                            if (sb.length() > 0) sb.append(", ");
                            sb.append(v);
                        }
                        hj.put(k, sb.toString());
                    }
                    InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    byte[] body = in == null ? new byte[0] : readAll(in, 30 * 1024 * 1024);
                    bodyB64 = Base64.encodeToString(body, Base64.NO_WRAP);
                    hdrB64 = Base64.encodeToString(hj.toString().getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                } catch (Exception e) {
                    status = 0;
                    bodyB64 = "";
                    hdrB64 = "";
                } finally {
                    if (c != null) c.disconnect();
                }
                callJs("window.__nativeFetchDone(" + id + "," + status + ",\"" + hdrB64 + "\",\"" + bodyB64 + "\")");
            }
        });
    }

    /* ---------------- ExoPlayer ---------------- */

    @JavascriptInterface
    public void playUrl(final String url, final String title) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(activity, PlayerActivity.class);
                i.putExtra("url", url);
                i.putExtra("title", title == null ? "" : title);
                activity.startActivity(i);
            }
        });
    }

    /* ---------------- Səhifə daxilində (inline) ExoPlayer ---------------- */

    @JavascriptInterface
    public void inlineOpen(final int id, final String url, final String title) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                inline.open(id, url, title);
            }
        });
    }

    @JavascriptInterface
    public void inlineLayout(final String json) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                inline.layout(json);
            }
        });
    }

    @JavascriptInterface
    public void inlineClose(final int id) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                inline.close(id);
            }
        });
    }

    /* ---------------- İxrac (fayl yazma) ---------------- */

    @JavascriptInterface
    public void saveFile(String name, String base64) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            String safe = (name == null || name.isEmpty() ? "playlist.m3u8" : name)
                    .replaceAll("[\\\\/:*?\"<>|]", "_");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                v.put(MediaStore.Downloads.MIME_TYPE, "audio/x-mpegurl");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new IOException("insert failed");
                try (OutputStream os = activity.getContentResolver().openOutputStream(uri)) {
                    if (os == null) throw new IOException("stream null");
                    os.write(data);
                }
                toast("Yükləmələr qovluğuna yazıldı: " + safe);
            } else {
                File dir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) dir = activity.getFilesDir();
                if (!dir.exists()) dir.mkdirs();
                File out = new File(dir, safe);
                try (FileOutputStream os = new FileOutputStream(out)) {
                    os.write(data);
                }
                toast("Fayl yazıldı: " + out.getAbsolutePath());
            }
        } catch (Exception e) {
            toast("Fayl yazıla bilmədi: " + e.getMessage());
        }
    }

    /* ---------------- köməkçilər ---------------- */

    private void toast(final String msg) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(activity, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void callJs(final String js) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript(js, null);
            }
        });
    }

    /** http→https kimi protokol dəyişən yönləndirmələri də izləyir. */
    private static HttpURLConnection open(String url, String method, Map<String, String> headers, int timeoutMs)
            throws IOException {
        String cur = url;
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(timeoutMs);
            c.setReadTimeout(timeoutMs);
            c.setRequestMethod(method);
            c.setRequestProperty("User-Agent", UA);
            for (Map.Entry<String, String> e : headers.entrySet()) {
                c.setRequestProperty(e.getKey(), e.getValue());
            }
            int code = c.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("redirect without location");
                cur = new URL(new URL(cur), loc).toString();
                continue;
            }
            return c;
        }
        throw new IOException("too many redirects");
    }

    private static byte[] readAll(InputStream in, int max) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        int total = 0;
        while ((n = in.read(buf)) != -1) {
            total += n;
            if (total > max) throw new IOException("too large");
            bo.write(buf, 0, n);
        }
        return bo.toByteArray();
    }
}
