package com.mehdi.keymapper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String action = intent != null ? intent.getAction() : null;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            return;
        }

        final Context app = context.getApplicationContext();
        Handler h = new Handler(Looper.getMainLooper());
        h.postDelayed(() -> {
            AccessibilityState.ensureEnabled(app);
            KeyInjectorClient.init(app);
            try {
                Intent service = new Intent(app, KeepAliveService.class);
                if (Build.VERSION.SDK_INT >= 26) {
                    app.startForegroundService(service);
                } else {
                    app.startService(service);
                }
            } catch (Throwable ignored) {}
        }, 2500L);
    }
}
