package az.m3u.sinayici

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/**
 * Yoxlama bitəndə 🔴 qalan kanallar real oynadıcılarla (səssiz, ekransız) yoxlanır:
 * əvvəl ExoPlayer (bir neçə profillə), olmasa LibVLC. Açılan kanal Net.playedOk ilə 🟢 sayılır.
 * Eyni anda az sayda kanal yoxlanır ki, cihaz və şəbəkə yorulmasın.
 */
object PlayerCheck {
    private const val MAX_PARALLEL = 6
    private const val EXO_PROFILES = 2
    private const val ATTEMPT_MS = 8000L

    private val h = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<Item>()
    private val queued = HashSet<String>()
    private var running = 0
    private var vlcLib: LibVLC? = null
    private var total = 0
    private var done = 0
    private var fixed = 0

    private class Item(val ctx: Context, val raw: String, val hdr: String, val onResult: (String, Boolean) -> Unit, val onDone: (Int, Int) -> Unit)

    /** İstənilən thread-dən çağırıla bilər. */
    fun submit(ctx: Context, items: List<Pair<String, String>>, onResult: (String, Boolean) -> Unit, onDone: (Int, Int) -> Unit) {
        val app = ctx.applicationContext
        h.post {
            var added = 0
            for ((raw, hdr) in items) {
                if (raw.isEmpty() || !queued.add(raw)) continue
                queue.addLast(Item(app, raw, hdr, onResult, onDone)); added++
            }
            if (added > 0) { total += added; pump() }
        }
    }

    private fun pump() {
        while (running < MAX_PARALLEL && queue.isNotEmpty()) {
            val it = queue.removeFirst()
            running++
            Job(it).start()
        }
    }

    private fun jobFinished(it: Item, ok: Boolean) {
        running--; done++
        queued.remove(it.raw)
        if (ok) fixed++
        it.onResult(it.raw, ok)
        if (queue.isEmpty() && running == 0) {
            val d = done; val f = fixed
            total = 0; done = 0; fixed = 0
            it.onDone(d, f)
        } else pump()
    }

    private class Job(val item: Item) {
        private val profiles = Net.profiles(item.raw, item.hdr)
        private var finished = false
        private var step = 0          // 0..EXO_PROFILES-1 = Exo, sonra bir VLC cəhdi
        private var exo: ExoPlayer? = null
        private var vlc: MediaPlayer? = null
        private var timeout: Runnable? = null

        fun start() = next()

        private fun cleanup() {
            timeout?.let { h.removeCallbacks(it) }; timeout = null
            exo?.let { try { it.release() } catch (e: Exception) { } }; exo = null
            vlc?.let { try { it.setEventListener(null); it.stop(); it.release() } catch (e: Exception) { } }; vlc = null
        }

        private fun finish(ok: Boolean) {
            if (finished) return
            finished = true
            cleanup()
            if (ok) Net.playedOk(item.raw)
            jobFinished(item, ok)
        }

        private fun next() {
            if (finished) return
            cleanup()
            val exoCount = minOf(EXO_PROFILES, profiles.size)
            when {
                step < exoCount -> tryExo(profiles[step++])
                step == exoCount -> { step++; tryVlc(profiles[0]) }
                else -> finish(false)
            }
        }

        private fun arm() {
            val r = Runnable { next() }
            timeout = r
            h.postDelayed(r, ATTEMPT_MS)
        }

        private fun tryExo(t: Net.Target) {
            Thread {
                val hls = try { Net.isHls(t) } catch (e: Exception) { false }
                h.post {
                    if (finished) return@post
                    try {
                        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
                            .setConnectTimeoutMs(7000).setReadTimeoutMs(7000)
                        val ds = ResolvingDataSource.Factory(http, ResolvingDataSource.Resolver { spec -> spec.withAdditionalHeaders(t.headers) })
                        val p = ExoPlayer.Builder(item.ctx).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build()
                        p.volume = 0f
                        p.addListener(object : Player.Listener {
                            override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_READY && exo === p) finish(true) }
                            override fun onPlayerError(e: PlaybackException) { if (exo === p) next() }
                        })
                        exo = p
                        val mi = MediaItem.Builder().setUri(t.url)
                        if (hls) mi.setMimeType(MimeTypes.APPLICATION_M3U8)
                        p.setMediaItem(mi.build()); p.prepare(); p.playWhenReady = true
                        arm()
                    } catch (e: Exception) { next() }
                }
            }.start()
        }

        private fun tryVlc(t: Net.Target) {
            try {
                val lib = vlcLib ?: LibVLC(item.ctx, arrayListOf("--http-reconnect", "--network-caching=1500")).also { vlcLib = it }
                val p = MediaPlayer(lib)
                vlc = p
                val m = Media(lib, Uri.parse(t.url))
                t.headers["User-Agent"]?.let { m.addOption(":http-user-agent=$it") }
                t.headers["Referer"]?.let { m.addOption(":http-referrer=$it") }
                m.addOption(":no-audio")
                p.setEventListener(MediaPlayer.EventListener { e ->
                    when (e.type) {
                        MediaPlayer.Event.Playing -> h.postDelayed({
                            // Playing xəbəri tək yetərli deyil: 1.5 san sonra hələ də oynayırsa kanal açılıb
                            if (!finished && vlc === p && p.isPlaying) finish(true)
                        }, 1500)
                        MediaPlayer.Event.EncounteredError -> if (vlc === p) finish(false)
                        else -> {}
                    }
                })
                p.setMedia(m); m.release(); p.play()
                arm()
            } catch (e: Throwable) { finish(false) }
        }
    }
}
