# Zəng Yazıları (Android)

Android Studio (Koala və ya yeni) ilə açın: File > Open > bu qovluq. Sync bitəndən sonra telefona Run edin.

## İlk istifadə
1. Tətbiqi açın, xəbərdarlığı təsdiqləyin və icazələri verin (mikrofon, telefon, zəng jurnalı, bildiriş).
2. "WhatsApp zənglərini aktiv et" düyməsi ilə bildirişlərə giriş icazəsi verin.
3. Zəng zamanı ekranın yuxarısında qırmızı "Zəng yazılır" zolağı çıxır.

## Məhdudiyyətlər
- Android 10+ üçüncü tərəf tətbiqlərə zəng səsini (VOICE_CALL) vermir. Tətbiq əvvəl onu yoxlayır, alınmasa mikrofona keçir.
  Mikrofon rejimində qarşı tərəfin səsi yalnız zəng DİNAMİK (speaker) rejimində olanda aydın yazılır.
- Android 14+ arxa fonda mikrofon xidmətini başlatmağı məhdudlaşdırır; bəzi telefonlarda batareya
  optimallaşdırmasını söndürmək lazım ola bilər.
- WhatsApp zənglərində nömrə yerinə bildirişdəki ad/nömrə göstərilir.
- Google Play zəng yazan tətbiqlərə icazə vermir; yalnız APK kimi yayıla bilər.
- Qarşı tərəfin razılığı olmadan yazmaq qanunsuz ola bilər.
