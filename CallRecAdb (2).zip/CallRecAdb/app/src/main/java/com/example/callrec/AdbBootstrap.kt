package com.example.callrec

import android.content.Context
import android.provider.Settings

/**
 * 1) 127.0.0.1:5555 (tcpip) varsa -> birbaşa qoşul (Wi-Fi lazım deyil)
 * 2) yoxdursa Wireless debugging ilə qoşul -> "tcpip:5555" -> 5555-ə keç
 * 3) shell-də ShellRecorder prosesini işə sal
 */
object AdbBootstrap {
    private fun shell(m: AdbConnectionManager, cmd: String): String {
        val s = m.openStream("shell:$cmd")
        val out = s.openInputStream().bufferedReader().readText()
        try { s.close() } catch (_: Throwable) {}
        return out
    }

    private fun connectLocal(m: AdbConnectionManager): Boolean {
        try { m.connect("127.0.0.1", 5555) } catch (_: Throwable) {}
        return m.isConnected
    }

    fun ensure(ctx: Context, status: (String) -> Unit): Boolean {
        val client = RecorderClient(ctx)
        if (client.ping()) return true
        val m = AdbConnectionManager.getInstance(ctx)
        try {
            status("Localhost:5555 yoxlanır…")
            if (!connectLocal(m)) {
                try { Settings.Global.putInt(ctx.contentResolver, "adb_wifi_enabled", 1) } catch (_: Throwable) {}
                status("Wireless debugging axtarılır (Wi-Fi lazımdır)…")
                try { m.autoConnect(ctx, 15000) } catch (_: Throwable) {}
                if (!m.isConnected) { status("Wi-Fi/Wireless debugging tapılmadı"); return false }
                status("TCP 5555 rejiminə keçilir…")
                try { m.openStream("tcpip:5555").close() } catch (_: Throwable) {}
                try { m.disconnect() } catch (_: Throwable) {}
                Thread.sleep(3500)
                if (!connectLocal(m)) { status("5555 portuna qoşulmaq alınmadı"); return false }
            }
            status("Yazıcı prosesi başladılır…")
            try { shell(m, "pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS") } catch (_: Throwable) {}
            val apk = shell(m, "pm path ${ctx.packageName}").lineSequence().first().trim().removePrefix("package:")
            shell(m, "(CLASSPATH=$apk setsid nohup app_process /system/bin --nice-name=callrec_daemon " +
                "com.example.callrec.ShellRecorder ${Prefs.token(ctx)} >/data/local/tmp/callrec.log 2>&1 &)")
            Thread.sleep(2500)
            return client.ping()
        } catch (e: Throwable) {
            status("Xəta: ${e.javaClass.simpleName}")
            return false
        } finally {
            try { m.disconnect() } catch (_: Throwable) {}
        }
    }
}
