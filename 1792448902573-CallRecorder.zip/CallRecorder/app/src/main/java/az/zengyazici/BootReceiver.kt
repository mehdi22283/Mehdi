package az.zengyazici

import android.app.*
import android.content.*

/** Android 14 mikrofon xidmətinin boot-dan başlamasını qadağan edir: istifadəçiyə bir toxunuşluq bildiriş göstərilir. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alert", "Zəng yazısı", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(4, Notification.Builder(c, "alert").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Zəng Yazıcı dayanıb").setContentText("Başlatmaq üçün toxunun").setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build())
    }
}
