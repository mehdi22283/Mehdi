package com.example.m3utester

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class CheckWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val l = Store.load(applicationContext)
        if (l.isEmpty()) return Result.success()
        val old = l.map { it.ok }
        testAll(l)
        val ev = diff(old, l)
        History.add(applicationContext, ev)
        ev.forEach {
            alarm(applicationContext, if (it.ok) "🟢 Kanal işləyir" else "🔴 Kanal dayandı", it.name, it.url.hashCode())
        }
        Store.save(applicationContext, l)
        return Result.success()
    }
}
