package az.wifiscan

import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

fun speedPage(u: Ui): Page {
    val p = u.vbox()
    p.addView(u.tv("Download / Upload sürəti", 22f, u.ACC, true))
    val big = u.tv("0.0 Mbps", 40f, u.TXT, true).apply { gravity = Gravity.CENTER; setPadding(0, u.dp(14), 0, u.dp(4)) }
    val phase = u.tv("", 14f, u.ACC, true).apply { gravity = Gravity.CENTER }
    val info = u.tv("", 13f, u.SUB).apply { gravity = Gravity.CENTER }
    val summary = u.tv("", 14f, u.GRN, true).apply { gravity = Gravity.CENTER; setPadding(0, u.dp(6), 0, u.dp(6)) }
    val pb = ProgressBar(u.act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
    val chart = LineChartView(u.act, "Mbps", u.ACC)
    val running = AtomicBoolean(false)
    var downRes = ""; var upRes = ""
    lateinit var dBtn: Button
    lateinit var uBtn: Button

    fun setIdle() { dBtn.text = "⬇ Download testi"; uBtn.text = "⬆ Upload testi"; dBtn.isEnabled = true; uBtn.isEnabled = true }

    fun test(up: Boolean) {
        if (running.get()) { running.set(false); return }
        running.set(true); pb.progress = 0; chart.clear()
        val btnActive = if (up) uBtn else dBtn
        (if (up) dBtn else uBtn).isEnabled = false
        btnActive.text = "⏹ Dayandır"
        phase.text = if (up) "⬆ Upload ölçülür…" else "⬇ Download ölçülür…"
        Thread {
            val total = AtomicLong(0); val start = System.nanoTime(); val durMs = 10000L
            val payload = ByteArray(65536).also { java.util.Random().nextBytes(it) }
            val ws = (1..4).map {
                Thread {
                    try {
                        if (up) {
                            val c = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
                            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 5000; c.readTimeout = 5000
                            c.setRequestProperty("Content-Type", "application/octet-stream")
                            c.setFixedLengthStreamingMode(200_000_000L)
                            val os = c.outputStream
                            while (running.get() && (System.nanoTime() - start) / 1_000_000 < durMs) {
                                os.write(payload); total.addAndGet(payload.size.toLong())
                            }
                            try { c.disconnect() } catch (e: Exception) {}
                        } else {
                            val c = URL("https://speed.cloudflare.com/__down?bytes=100000000").openConnection() as HttpURLConnection
                            c.connectTimeout = 5000; c.readTimeout = 5000
                            val ins = c.inputStream; val buf = ByteArray(65536)
                            while (running.get() && (System.nanoTime() - start) / 1_000_000 < durMs) {
                                val n = ins.read(buf); if (n < 0) break; total.addAndGet(n.toLong())
                            }
                            try { ins.close(); c.disconnect() } catch (e: Exception) {}
                        }
                    } catch (e: Exception) {}
                }.also { it.start() }
            }
            var peak = 0.0; var lastB = 0L; var lastT = start
            val samples = ArrayList<Float>()
            while (running.get() && (System.nanoTime() - start) / 1_000_000 < durMs && ws.any { it.isAlive }) {
                try { Thread.sleep(250) } catch (e: InterruptedException) {}
                val now = System.nanoTime(); val b = total.get()
                val inst = (b - lastB) * 8.0 / ((now - lastT) / 1e9) / 1e6
                lastB = b; lastT = now; peak = maxOf(peak, inst)
                samples.add(inst.toFloat())
                val avg = b * 8.0 / ((now - start) / 1e9) / 1e6
                val pr = (((now - start) / 1e6) * 100 / durMs).toInt()
                val pk = peak; val snap = ArrayList(samples)
                u.post {
                    big.text = String.format("%.1f Mbps", inst)
                    info.text = String.format("Orta: %.1f • Maks: %.1f Mbps • %.1f MB", avg, pk, b / 1e6)
                    pb.progress = pr; chart.set(snap)
                }
            }
            running.set(false)
            ws.forEach { try { it.join(1500) } catch (e: InterruptedException) {} }
            val el = maxOf((System.nanoTime() - start) / 1e9, 0.001)
            val avg = total.get() * 8.0 / el / 1e6
            val pk = peak; val mb = total.get() / 1e6
            u.post {
                big.text = String.format("%.1f Mbps", avg)
                info.text = String.format("Yekun orta: %.1f Mbps • Maks: %.1f • %.1f MB / %.1f san", avg, pk, mb, el)
                if (up) upRes = String.format("%.1f", avg) else downRes = String.format("%.1f", avg)
                summary.text = "⬇ ${if (downRes.isEmpty()) "—" else downRes} Mbps   •   ⬆ ${if (upRes.isEmpty()) "—" else upRes} Mbps"
                phase.text = if (mb < 0.01) "❌ Test alınmadı (internet yoxdur?)" else "✅ Bitdi"
                pb.progress = 100; setIdle()
            }
        }.start()
    }

    dBtn = u.btn("⬇ Download testi") { test(false) }
    uBtn = u.btn("⬆ Upload testi") { test(true) }
    val row = LinearLayout(u.act).apply { orientation = LinearLayout.HORIZONTAL }
    row.addView(dBtn, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(uBtn, LinearLayout.LayoutParams(0, -2, 1f))
    p.addView(phase); p.addView(big); p.addView(info); p.addView(pb); p.addView(row); p.addView(summary)
    p.addView(chart, LinearLayout.LayoutParams(-1, u.dp(200)))
    p.addView(u.tv("Test Cloudflare serverləri ilə 4 paralel bağlantıda 10 saniyə aparılır. Upload nəticəsi göndərilmiş bayta əsaslanır, bir qədər yüksək çıxa bilər.", 11f, u.SUB).apply { setPadding(0, u.dp(8), 0, 0) })
    return Page(p)
}
