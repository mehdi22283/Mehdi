package com.example.callrec

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class RecorderService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val boot = Executors.newSingleThreadExecutor()
    private lateinit var am: AudioManager
    private lateinit var nm: NotificationManager
    private lateinit var client: RecorderClient

    @Volatile private var daemonOk = false
    @Volatile private var recording = false
    @Volatile private var starting = false
    @Volatile private var bootBusy = false
    @Volatile private var retryAt = 0L
    private var lastPing = 0L
    private var lastBoot = 0L
    private var fileName = ""

    private val poll = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            val mode = am.mode
            val active = mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION
            if (active && !recording && !starting && now > retryAt) startRec(mode == AudioManager.MODE_IN_CALL)
            else if (!active && recording) stopRec()

            if (!recording && !starting && now - lastPing > 5000) {
                lastPing = now
                io.execute {
                    val ok = client.ping()
                    if (ok != daemonOk) {
                        daemonOk = ok
                        status(if (ok) "Hazırdır ✔ Wi-Fi olmadan da işləyir" else "Yazıcı prosesi yoxdur")
                    }
                    if (!ok) maybeBoot()
                }
            }
            h.postDelayed(this, 700)
        }
    }

    private fun maybeBoot() {
        val now = SystemClock.elapsedRealtime()
        if (bootBusy || now - lastBoot < 20000) return
        bootBusy = true; lastBoot = now
        boot.execute {
            try {
                val ok = AdbBootstrap.ensure(this) { status(it) }
                if (ok) { daemonOk = true; status("Hazırdır ✔ Wi-Fi olmadan da işləyir"); nm.cancel(5) }
                else if (!Prefs.paired(this)) Notif.pairPrompt(this)
            } finally { bootBusy = false }
        }
    }

    override fun onCreate() {
        super.onCreate()
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        client = RecorderClient(this)
        Notif.channels(this)
        val first = idle("Başladılır…")
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, first)
        h.post(poll)
    }

    private fun idle(text: String) = Notification.Builder(this, "idle")
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Zəng yazıcı işləyir").setContentText(text).setOngoing(true)
        .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE)).build()

    private fun status(t: String) = nm.notify(1, idle(t))

    private fun startRec(phone: Boolean) {
        val src = if (phone) "Telefon" else "WhatsApp"
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        fileName = "${src}_$ts.m4a"
        val sources = if (phone) intArrayOf(4, 1) else intArrayOf(8, 7, 1)
        starting = true
        io.execute {
            val ok = client.start("/sdcard/Music/CallRec/$fileName", sources)
            if (ok) {
                recording = true
                nm.notify(2, Notification.Builder(this, "rec")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("$src zəngi yazılır…").setContentText("Yazı davam edir")
                    .setOngoing(true).setCategory(Notification.CATEGORY_CALL).build())
            } else {
                retryAt = SystemClock.elapsedRealtime() + 5000
                daemonOk = false
                status("Yazı başlamadı (prosesi yoxlayın)")
            }
            starting = false
        }
    }

    private fun stopRec() {
        recording = false
        val name = fileName
        io.execute {
            client.stop()
            nm.cancel(2)
            nm.notify(System.currentTimeMillis().toInt(), Notification.Builder(this, "done")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Zəng yazıldı").setContentText("Music/CallRec/$name")
                .setAutoCancel(true).build())
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() {
        h.removeCallbacks(poll)
        if (recording) io.execute { client.stop() }
        io.shutdown(); boot.shutdownNow()
        super.onDestroy()
    }
}
