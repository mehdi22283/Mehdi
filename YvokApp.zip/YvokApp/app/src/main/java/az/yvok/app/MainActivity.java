package az.yvok.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String EBEL_URL = "https://e-belediyye.gov.az/tax-debts";
    private static final Pattern CODE = Pattern.compile("^10011[A-Z0-9]{7}$");

    private WebView ui, ebel;
    private String injectJs;
    private boolean ebelLoaded = false;
    private String pending = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        injectJs = readAsset("inject.js");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        ui = new WebView(this);
        ui.setBackgroundColor(Color.BLACK);
        ebel = new WebView(this);
        ebel.setBackgroundColor(Color.WHITE);

        root.addView(ui, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        View line = new View(this);
        line.setBackgroundColor(Color.parseColor("#007bff"));
        root.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 4));
        root.addView(ebel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        setupCommon(ui);
        setupCommon(ebel);

        // ---- Yuxarı: öz səhifəmiz (assets/index.html) ----
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        ui.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {                                   // whatsapp:// və xarici linklər
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Tətbiq tapılmadı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        ui.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void fill(String code) {
                final String v = "10011" + (code == null ? "" : code.toUpperCase());
                if (!CODE.matcher(v).matches()) return;
                runOnUiThread(() -> fillEbel(v));
            }
        }, "Android");
        ui.loadUrl("https://" + HOST + "/assets/index.html");

        // ---- Aşağı: e-belediyye.gov.az (WebView) ----
        ebel.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                ebelLoaded = true;
                if (pending != null) {
                    String p = pending;
                    pending = null;
                    runFill(p);
                }
            }
        });
        ebel.loadUrl(EBEL_URL);
    }

    private void setupCommon(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("OK", (d, x) -> res.confirm())
                        .setOnCancelListener(d -> res.confirm()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("Bəli", (d, x) -> res.confirm())
                        .setNegativeButton("Xeyr", (d, x) -> res.cancel())
                        .setOnCancelListener(d -> res.cancel()).show();
                return true;
            }
        });
    }

    private void fillEbel(String value) {
        if (ebelLoaded) runFill(value); else pending = value;
    }

    private void runFill(String value) {
        ebel.evaluateJavascript(injectJs + ";window.__yvokRun('" + value + "');", null);
    }

    @Override
    public void onBackPressed() {
        if (ebel.canGoBack()) ebel.goBack(); else super.onBackPressed();
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
