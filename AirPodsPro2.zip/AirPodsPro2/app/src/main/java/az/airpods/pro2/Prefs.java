package az.airpods.pro2;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("pods", 0); }
    static boolean popup(Context c) { return sp(c).getBoolean("popup", true); }
    static boolean boot(Context c) { return sp(c).getBoolean("boot", false); }
    static boolean wantRun(Context c) { return sp(c).getBoolean("run", true); }
    static void set(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
    private Prefs() {}
}
