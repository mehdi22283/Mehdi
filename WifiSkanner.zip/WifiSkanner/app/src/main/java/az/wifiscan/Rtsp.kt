package az.wifiscan

import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest

/** RTSP (port 554) üçün yüngül DESCRIBE yoxlaması: yol mövcuddurmu, parol tələb olunurmu. */
object Rtsp {
    class Probe(val code: Int, val auth: String, val server: String)

    val PATHS = linkedMapOf(
        "Hikvision (əsas)" to "/Streaming/Channels/101",
        "Hikvision (əlavə)" to "/Streaming/Channels/102",
        "Dahua / Amcrest (əsas)" to "/cam/realmonitor?channel=1&subtype=0",
        "Dahua / Amcrest (əlavə)" to "/cam/realmonitor?channel=1&subtype=1",
        "Reolink (əsas)" to "/h264Preview_01_main",
        "Reolink (əlavə)" to "/h264Preview_01_sub",
        "Uniview" to "/media/video1",
        "Axis" to "/axis-media/media.amp",
        "XMeye / DVR" to "/user=admin&password=&channel=1&stream=0.sdp?real_stream",
        "Ümumi /live" to "/live",
        "Ümumi /stream1" to "/stream1",
        "Ümumi /h264" to "/h264",
        "Ümumi /11" to "/11",
        "Ümumi /1" to "/1",
        "Ümumi /ch0_0.h264" to "/ch0_0.h264",
        "Ümumi /onvif1" to "/onvif1",
        "Ümumi /cam1/h264" to "/cam1/h264",
        "Kök (/)" to "/"
    )

    fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun param(h: String, k: String): String =
        Regex("$k=\"?([^\",]*)\"?", RegexOption.IGNORE_CASE).find(h)?.groupValues?.get(1) ?: ""

    private fun exchange(ip: String, port: Int, uri: String, authHeader: String?): Triple<Int, String, String> {
        return Socket().use { s ->
            s.connect(InetSocketAddress(ip, port), 1500); s.soTimeout = 2000
            val req = StringBuilder()
            req.append("DESCRIBE $uri RTSP/1.0\r\nCSeq: 1\r\nAccept: application/sdp\r\nUser-Agent: WifiSkan\r\n")
            if (authHeader != null) req.append("Authorization: $authHeader\r\n")
            req.append("\r\n")
            s.getOutputStream().write(req.toString().toByteArray())
            val buf = ByteArray(2048)
            val n = s.getInputStream().read(buf)
            if (n <= 0) return Triple(-1, "", "")
            val txt = String(buf, 0, n)
            val code = Regex("RTSP/\\d\\.\\d\\s+(\\d{3})").find(txt)?.groupValues?.get(1)?.toIntOrNull() ?: -1
            val auth = Regex("(?i)WWW-Authenticate:\\s*(.+)").find(txt)?.groupValues?.get(1)?.trim() ?: ""
            val server = Regex("(?i)Server:\\s*(.+)").find(txt)?.groupValues?.get(1)?.trim() ?: ""
            Triple(code, auth, server)
        }
    }

    fun describe(ip: String, port: Int, path: String, user: String = "", pass: String = ""): Probe {
        val p = if (path.startsWith("/")) path else "/$path"
        val uri = "rtsp://$ip:$port$p"
        return try {
            val (c1, a1, sv) = exchange(ip, port, uri, null)
            if (c1 != 401 || user.isEmpty()) return Probe(c1, a1, sv)
            val hdr = if (a1.startsWith("Digest", true)) {
                val realm = param(a1, "realm"); val nonce = param(a1, "nonce"); val qop = param(a1, "qop")
                val ha1 = md5("$user:$realm:$pass"); val ha2 = md5("DESCRIBE:$uri")
                if (qop.contains("auth")) {
                    val nc = "00000001"; val cn = md5(System.nanoTime().toString()).take(16)
                    val resp = md5("$ha1:$nonce:$nc:$cn:auth:$ha2")
                    "Digest username=\"$user\", realm=\"$realm\", nonce=\"$nonce\", uri=\"$uri\", response=\"$resp\", qop=auth, nc=$nc, cnonce=\"$cn\""
                } else {
                    val resp = md5("$ha1:$nonce:$ha2")
                    "Digest username=\"$user\", realm=\"$realm\", nonce=\"$nonce\", uri=\"$uri\", response=\"$resp\""
                }
            } else {
                "Basic " + android.util.Base64.encodeToString("$user:$pass".toByteArray(), android.util.Base64.NO_WRAP)
            }
            val (c2, a2, sv2) = exchange(ip, port, uri, hdr)
            Probe(c2, a2, sv2.ifEmpty { sv })
        } catch (e: Exception) { Probe(-1, "", "") }
    }
}
