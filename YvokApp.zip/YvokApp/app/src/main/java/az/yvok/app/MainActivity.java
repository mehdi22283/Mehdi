package az.yvok.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String EBEL_URL = "https://e-belediyye.gov.az/tax-debts";
    private static final Pattern CODE = Pattern.compile("^10011[A-Z0-9]{7}$");
    private static final Pattern NAME_OK = Pattern.compile("^[\\p{L}\\s.'\\-]{3,100}$");
    private static final Pattern DEBT_OK = Pattern.compile("^(\\d{1,9}(\\.\\d{1,2})?)?$");
    private static final int MAX_WORKERS = 3;   // toplu yoxlama üçün paralel gizli səhifə sayı

    private static class Job {
        final String code;
        final boolean batch;
        Job(String code, boolean batch) { this.code = code; this.batch = batch; }
    }

    // Hər Worker = e-belediyye.gov.az açıq olan bir gizli WebView (ui-nin ARXASINDA işləyir)
    private class Worker {
        final WebView wv;
        boolean loaded = false;
        String pending = null;
        Job current = null;
        final Runnable watchdog = () -> onWatchdog(this);
        Worker(WebView wv) { this.wv = wv; }
    }

    private FrameLayout root;
    private WebView ui;
    private String injectJs;
    private final ArrayList<Worker> workers = new ArrayList<>();
    private final ArrayDeque<Job> jobs = new ArrayDeque<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        injectJs = readAsset("inject.js");

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ui = new WebView(this);
        ui.setBackgroundColor(Color.BLACK);
        ui.setFocusable(true);
        ui.setFocusableInTouchMode(true);
        root.addView(ui, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        setupCommon(ui);

        // ---- Yuxarı: öz səhifəmiz (assets/index.html) ----
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        ui.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                ui.requestFocus();
                ui.evaluateJavascript("document.getElementById('phone-input').focus();", null);
                ui.postDelayed(() -> {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(ui, InputMethodManager.SHOW_IMPLICIT);
                }, 350);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {                                   // whatsapp:// və xarici linklər
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Tətbiq tapılmadı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        ui.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void reset() {
                runOnUiThread(() -> {
                    jobs.removeIf(j -> !j.batch);
                    for (Worker w : workers) {
                        if (w.current != null && w.current.batch) continue;   // işləyən toplu sorğuya toxunma
                        w.wv.removeCallbacks(w.watchdog);
                        w.current = null;
                        w.pending = null;
                        w.loaded = false;
                        w.wv.stopLoading();
                        w.wv.loadUrl(EBEL_URL);   // sayt ilkin vəziyyətə qayıdır, xanalar təmizlənir
                    }
                    pump();
                });
            }

            @JavascriptInterface
            public void fill(String code) {
                final String v = "10011" + (code == null ? "" : code.toUpperCase());
                if (!CODE.matcher(v).matches()) return;
                runOnUiThread(() -> {
                    jobs.removeIf(j -> !j.batch);
                    for (Worker w : workers) {                 // əvvəlki tək sorğunu ləğv et
                        if (w.current != null && !w.current.batch) {
                            w.wv.removeCallbacks(w.watchdog);
                            w.current = null;
                        }
                    }
                    jobs.addFirst(new Job(v, false));
                    status("loading");
                    pump();
                });
            }

            // Toplu yoxlama səhifələrini əvvəlcədən hazırla (mətn qutusuna toxunanda)
            @JavascriptInterface
            public void warm() {
                runOnUiThread(() -> { while (workers.size() < MAX_WORKERS) createWorker(); });
            }

            // Toplu yoxlama: vergüllə ayrılmış tam kodlar (10011XXXXXXX)
            @JavascriptInterface
            public void batch(String csv) {
                if (csv == null) return;
                final String[] parts = csv.split(",");
                runOnUiThread(() -> {
                    for (String c : parts) {
                        c = c.trim().toUpperCase();
                        if (!CODE.matcher(c).matches()) continue;
                        boolean dup = false;
                        for (Worker w : workers) {
                            if (w.current != null && w.current.batch && w.current.code.equals(c)) { dup = true; break; }
                        }
                        if (!dup) for (Job j : jobs) if (j.batch && j.code.equals(c)) { dup = true; break; }
                        if (!dup) jobs.addLast(new Job(c, true));
                    }
                    pump();
                });
            }

            @JavascriptInterface
            public void batchStop() {
                runOnUiThread(() -> jobs.removeIf(j -> j.batch));
            }
        }, "Android");
        ui.loadUrl("https://" + HOST + "/assets/index.html");

        // ---- Aşağı: e-belediyye.gov.az (gizli WebView-lar) ----
        createWorker();
    }

    private Worker createWorker() {
        final WebView wv = new WebView(this);
        wv.setBackgroundColor(Color.WHITE);
        wv.setFocusable(false);                       // klaviaturanı/fokusu oğurlamasın
        wv.setFocusableInTouchMode(false);
        // ui-nin ARXASINA (index 0) əlavə olunur: tam ölçüdə layout alır, amma görünmür
        root.addView(wv, 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setupCommon(wv);
        final Worker w = new Worker(wv);
        workers.add(w);
        wv.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void result(final String code, final String name, final String debt) {
                runOnUiThread(() -> onEbelResult(w, code, name, debt));
            }

            @JavascriptInterface
            public void fail(final String code, final String reason) {
                runOnUiThread(() -> onEbelFail(w, code, reason));
            }
        }, "AndroidEbel");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                w.loaded = true;
                if (w.pending != null) {
                    String p = w.pending;
                    w.pending = null;
                    runFill(w, p);
                }
            }
        });
        wv.loadUrl(EBEL_URL);
        return w;
    }

    private Worker pickWorker() {
        for (int i = workers.size() - 1; i >= 0; i--) {
            Worker w = workers.get(i);
            if (w.current == null) return w;
        }
        if (workers.size() < MAX_WORKERS) return createWorker();
        return null;
    }

    private void pump() {
        for (Iterator<Job> it = jobs.iterator(); it.hasNext(); ) {
            Job j = it.next();
            Worker w = pickWorker();
            if (w == null) return;
            it.remove();
            w.current = j;
            w.wv.removeCallbacks(w.watchdog);
            w.wv.postDelayed(w.watchdog, 45000);
            if (w.loaded) runFill(w, j.code); else w.pending = j.code;
        }
    }

    private void runFill(Worker w, String value) {
        w.wv.evaluateJavascript(injectJs + ";window.__yvokRun('" + value + "');", null);
    }

    private void onEbelResult(Worker w, String code, String name, String debt) {
        Job j = w.current;
        if (j == null || code == null || !j.code.equals(code)) return;   // köhnə/yad nəticə
        w.current = null;
        w.wv.removeCallbacks(w.watchdog);
        final String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        final String d = debt == null ? "" : debt.trim();
        if (!NAME_OK.matcher(n).matches() || !DEBT_OK.matcher(d).matches()) {
            failJob(j, "Məlumat formatı tanınmadı");
        } else if (j.batch) {
            ui.evaluateJavascript("window.setBatchResult(" + JSONObject.quote(j.code) + ","
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
        } else {
            ui.evaluateJavascript("window.setEbelStatus('ok');window.setEbelResult("
                    + JSONObject.quote(n) + "," + JSONObject.quote(d) + ");", null);
            if (d.isEmpty()) toast("Borc məbləği tapılmadı");
        }
        pump();
    }

    private void onEbelFail(Worker w, String code, String reason) {
        Job j = w.current;
        if (j == null || (code != null && !j.code.equals(code))) return;
        w.current = null;
        w.wv.removeCallbacks(w.watchdog);
        failJob(j, reason == null || reason.length() > 80 ? "Məlumat tapılmadı" : reason);
        pump();
    }

    private void onWatchdog(Worker w) {
        Job j = w.current;
        if (j == null) return;
        w.current = null;
        failJob(j, "Sayt cavab vermədi");
        w.pending = null;
        w.loaded = false;
        w.wv.stopLoading();
        w.wv.loadUrl(EBEL_URL);   // ilişən səhifəni təzələ, növbə davam etsin
        pump();
    }

    private void failJob(Job j, String msg) {
        if (j.batch) {
            ui.evaluateJavascript("window.setBatchFail(" + JSONObject.quote(j.code) + ","
                    + JSONObject.quote(msg) + ");", null);
        } else {
            status("fail");
            toast(msg);
        }
    }

    private void setupCommon(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("OK", (d, x) -> res.confirm())
                        .setOnCancelListener(d -> res.confirm()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult res) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("Bəli", (d, x) -> res.confirm())
                        .setNegativeButton("Xeyr", (d, x) -> res.cancel())
                        .setOnCancelListener(d -> res.cancel()).show();
                return true;
            }
        });
    }

    private void status(final String st) {
        runOnUiThread(() -> ui.evaluateJavascript("window.setEbelStatus('" + st + "');", null));
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
