plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.tvopen"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.tvopen"
        minSdk = 21
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}
