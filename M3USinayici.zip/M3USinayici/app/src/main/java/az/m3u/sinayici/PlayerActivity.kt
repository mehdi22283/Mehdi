package az.m3u.sinayici

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.*
import androidx.media3.common.*
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.LoadEventInfo
import androidx.media3.exoplayer.source.MediaLoadData
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

class QItem(val name: String, val url: String, val hdr: String)
object PlayQueue { var items: List<QItem> = emptyList(); var index = 0 }

/** Portret oynadıcı. Mühərrik seçimi: Media3/ExoPlayer və ya LibVLC. Əvvəlki/sonrakı kanal. */
class PlayerActivity : Activity() {
    private var exo: ExoPlayer? = null
    private var vlcLib: LibVLC? = null
    private var vlc: MediaPlayer? = null
    private lateinit var pv: PlayerView
    private lateinit var vl: VLCVideoLayout
    private lateinit var statsTv: TextView
    private lateinit var nameTv: TextView
    private lateinit var engExo: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var engVlc: TextView
    private val h = Handler(Looper.getMainLooper())
    private var engine = "exo"
    private var url = ""
    @Volatile private var target = Net.Target("", emptyMap(), "")
    private var profiles: List<Net.Target> = emptyList()
    private var pIdx = 0
    private var msg = ""
    private var gen = 0
    private var latency = -1L
    private var speedBps = -1L
    private var prevAhead = -1L
    private var vlcBuf = 100f
    private var vlcPlaying = false
    private var speed = 1f
    private var resizeIdx = 0
    private var alive = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        engine = getSharedPreferences("m3u", MODE_PRIVATE).getString("engine", "exo") ?: "exo"
        pv = PlayerView(this)
        pv.useController = false
        pv.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        vl = VLCVideoLayout(this)
        statsTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(Color.BLACK)
        }
        nameTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER; maxLines = 2
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        engExo = segment("ExoPlayer") { setEngine("exo") }
        engVlc = segment("VLC") { setEngine("vlc") }
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(0xFF1F2937.toInt(), 28)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(engExo, LinearLayout.LayoutParams(0, dp(50), 1f))
            addView(engVlc, LinearLayout.LayoutParams(0, dp(50), 1f))
        }
        playBtn = iconBtn(R.drawable.ic_pause) { togglePause() }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(iconBtn(R.drawable.ic_prev) { step(-1) }, LinearLayout.LayoutParams(dp(72), dp(72)))
            addView(playBtn, LinearLayout.LayoutParams(dp(84), dp(84)).apply { setMargins(dp(28), 0, dp(28), 0) })
            addView(iconBtn(R.drawable.ic_next) { step(1) }, LinearLayout.LayoutParams(dp(72), dp(72)))
        }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(14), dp(8), dp(14), dp(18))
            addView(nameTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(8) })
            addView(nav)
            addView(seg, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
        }
        pv.setOnClickListener { togglePause() }
        vl.setOnClickListener { togglePause() }
        val videoBox = FrameLayout(this).apply {
            addView(pv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(vl, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(statsTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(videoBox, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(bottom, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        })
        applyEngineViews()
        loadCurrent(); tick(); probeLoop()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
    }

    private fun iconBtn(res: Int, f: () -> Unit): ImageButton = ImageButton(this).apply {
        setImageResource(res)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = rounded(0xFF2563EB.toInt(), 36)
        setOnClickListener { f() }
    }

    private fun segment(t: String, f: () -> Unit): TextView = TextView(this).apply {
        text = t; textSize = 18f; gravity = Gravity.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setOnClickListener { f() }
    }

    private fun setEngine(e: String) {
        if (e == engine) return
        engine = e
        getSharedPreferences("m3u", MODE_PRIVATE).edit().putString("engine", engine).apply()
        gen++
        releaseExo(); releaseVlc()
        applyEngineViews()
        loadCurrent()
    }

    private fun applyEngineViews() {
        pv.visibility = if (engine == "exo") View.VISIBLE else View.GONE
        vl.visibility = if (engine == "vlc") View.VISIBLE else View.GONE
        val on = rounded(0xFF2563EB.toInt(), 24); val off = rounded(0x00000000, 24)
        engExo.background = if (engine == "exo") on else off
        engVlc.background = if (engine == "vlc") on else off
        engExo.setTextColor(if (engine == "exo") Color.WHITE else 0xFF9CA3AF.toInt())
        engVlc.setTextColor(if (engine == "vlc") Color.WHITE else 0xFF9CA3AF.toInt())
    }

    // ---------- kanal naviqasiyası ----------
    private fun loadCurrent() {
        val cur = PlayQueue.items.getOrNull(PlayQueue.index) ?: return
        nameTv.text = "${PlayQueue.index + 1}/${PlayQueue.items.size}  ${cur.name}"
        url = cur.url
        getSharedPreferences("m3u", MODE_PRIVATE).edit().putString("lastUrl", cur.url).apply()
        profiles = Net.profiles(cur.url, cur.hdr); pIdx = 0
        msg = ""; prevAhead = -1; latency = -1; speedBps = -1; vlcBuf = 100f; vlcPlaying = false
        begin()
    }

    private fun step(d: Int) {
        val n = PlayQueue.items.size
        if (n == 0) return
        PlayQueue.index = (PlayQueue.index + d + n) % n
        loadCurrent()
    }

    // ---------- ortaq başlatma / xəta ----------
    private fun begin() {
        val t = profiles[pIdx]; target = t
        gen++
        val my = gen
        prevAhead = -1
        if (engine == "vlc") startVlc(t)
        else Thread {
            val hls = try { Net.isHls(t) } catch (e: Exception) { false }
            runOnUiThread { if (alive && my == gen && engine == "exo") startExo(t, hls) }
        }.start()
    }

    private fun onEngineError(d: String) {
        if (pIdx < profiles.size - 1) {
            pIdx++; msg = "🔁 Profil: ${profiles[pIdx].name} ($d)"; begin()
        } else {
            msg = "❌ $d"; pIdx = 0
            if (engine == "exo") Net.exoFail(url)   // ExoPlayer xəta mesajı verdi → siyahıda kanal 🔴
            val g = gen
            h.postDelayed({ if (alive && g == gen) begin() }, 5000)
        }
    }

    // ---------- ExoPlayer (Media3) ----------
    private fun ensureExo(): ExoPlayer {
        exo?.let { return it }
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000).setReadTimeoutMs(10000)
        val ds = ResolvingDataSource.Factory(http, ResolvingDataSource.Resolver { spec -> spec.withAdditionalHeaders(target.headers) })
        val p = ExoPlayer.Builder(this).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { msg = ""; Net.markGood(target.url, target.name); Net.exoOk(url) }
            }
            override fun onPlayerError(e: PlaybackException) { onEngineError(errText(e)) }
        })
        p.addAnalyticsListener(object : AnalyticsListener {
            override fun onLoadCompleted(t: AnalyticsListener.EventTime, i: LoadEventInfo, d: MediaLoadData) {
                if (i.loadDurationMs > 0) speedBps = i.bytesLoaded * 8000 / i.loadDurationMs
            }
        })
        p.setPlaybackSpeed(speed)
        pv.player = p
        pv.resizeMode = intArrayOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM)[resizeIdx]
        exo = p
        return p
    }

    private fun startExo(t: Net.Target, hls: Boolean) {
        val p = ensureExo()
        val mi = MediaItem.Builder().setUri(t.url)
        if (hls) mi.setMimeType(MimeTypes.APPLICATION_M3U8)
        p.setMediaItem(mi.build()); p.prepare(); p.playWhenReady = true
    }

    private fun errText(e: PlaybackException): String {
        var c: Throwable? = e.cause
        var code = ""
        while (c != null) {
            if (c is HttpDataSource.InvalidResponseCodeException) { code = " HTTP " + c.responseCode; break }
            c = c.cause
        }
        return e.errorCodeName + code + (e.cause?.message?.let { " – $it" } ?: "")
    }

    private fun releaseExo() { pv.player = null; exo?.release(); exo = null }

    // ---------- LibVLC ----------
    private fun startVlc(t: Net.Target) {
        val lib = vlcLib ?: LibVLC(this, arrayListOf("--http-reconnect", "--network-caching=2000")).also { vlcLib = it }
        val p = vlc ?: MediaPlayer(lib).also { vp ->
            vp.attachViews(vl, null, false, false)
            vp.setEventListener(object : MediaPlayer.EventListener {
                override fun onEvent(event: MediaPlayer.Event) { onVlcEvent(event) }
            })
            vlc = vp
        }
        val m = Media(lib, Uri.parse(t.url))
        t.headers["User-Agent"]?.let { m.addOption(":http-user-agent=$it") }
        t.headers["Referer"]?.let { m.addOption(":http-referrer=$it") }
        m.addOption(":network-caching=2000")
        p.setMedia(m)
        m.release()
        p.play()
        p.setRate(speed)
        applyResize()
    }

    private fun onVlcEvent(e: MediaPlayer.Event) {
        when (e.type) {
            MediaPlayer.Event.Playing -> { vlcPlaying = true; msg = ""; Net.markGood(target.url, target.name) }
            MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> vlcPlaying = false
            MediaPlayer.Event.Buffering -> vlcBuf = e.buffering
            MediaPlayer.Event.EncounteredError -> { vlcPlaying = false; onEngineError("VLC xətası") }
            else -> {}
        }
    }

    private fun releaseVlc() {
        vlc?.let { it.setEventListener(null); it.stop(); it.detachViews(); it.release() }
        vlcLib?.release()
        vlc = null; vlcLib = null
    }

    private fun togglePause() {
        if (engine == "vlc") {
            val p = vlc ?: return
            if (p.isPlaying) p.pause() else p.play()
        } else {
            val p = exo ?: return
            if (p.playWhenReady) p.pause() else p.play()
        }
        updatePlayIcon()
    }

    private fun updatePlayIcon() {
        val playing = if (engine == "vlc") (vlc?.isPlaying == true) else (exo?.playWhenReady == true)
        playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun applyResize() {
        val st = arrayOf(MediaPlayer.ScaleType.SURFACE_BEST_FIT, MediaPlayer.ScaleType.SURFACE_FILL, MediaPlayer.ScaleType.SURFACE_FIT_SCREEN)
        vlc?.setVideoScale(st[resizeIdx])
    }

    // ---------- statistika ----------
    private fun fmt(bps: Long) = when {
        bps <= 0 -> "naməlum"; bps >= 1_000_000 -> "%.2f Mbps".format(bps / 1e6); else -> "${bps / 1000} kbps"
    }

    private fun tick() {
        if (!alive) return
        var res = "naməlum"
        var br = -1L
        val lab: String
        if (engine == "vlc") {
            val vt = vlc?.getCurrentVideoTrack()
            if (vt != null && vt.width > 0) res = "${vt.width}×${vt.height}"
            if (vt != null && vt.bitrate > 0) br = vt.bitrate.toLong()
            lab = if (!vlcPlaying) "🔴" else if (vlcBuf < 100f) "🟠" else "🟢"
        } else {
            val p = exo
            val f = p?.videoFormat
            if (f != null && f.width > 0) res = "${f.width}×${f.height}"
            if (f != null) br = (if (f.bitrate > 0) f.bitrate else f.averageBitrate).toLong()
            val ahead = p?.totalBufferedDuration ?: 0L
            lab = when {
                p == null || p.playbackState != Player.STATE_READY || ahead <= 100 -> "🔴"
                ahead < 2000 -> "🟠"
                prevAhead >= 0 && ahead - prevAhead < -200 -> "🟡"
                else -> "🟢"
            }
            prevAhead = ahead
        }
        val ready = if (engine == "vlc") vlcPlaying else (exo?.playbackState == Player.STATE_READY)
        val head = if (msg.isNotEmpty() && !ready) msg + "\n" else ""
        statsTv.text = head + "🔲 $res   ⚡ ${fmt(br)}\n🛰 ${if (latency >= 0) "$latency ms" else "naməlum"}   ⬇ ${fmt(speedBps)}   🪣 $lab"
        updatePlayIcon()
        h.postDelayed({ tick() }, 1000)
    }

    /** Gecikmə (ilk bayta qədər) və VLC üçün təxmini endirmə sürəti; hər 6 saniyədə bir. */
    private fun probeLoop() {
        if (!alive) return
        val t = target
        Thread {
            try {
                val t0 = System.nanoTime()
                val c = Net.connect(t, "bytes=0-262143", 8000)
                val s = c.inputStream
                if (s.read() >= 0) {
                    latency = (System.nanoTime() - t0) / 1_000_000
                    var total = 1L
                    val buf = ByteArray(16384)
                    while (total < 262144) { val n = s.read(buf); if (n < 0) break; total += n }
                    val ms = (System.nanoTime() - t0) / 1_000_000
                    if (engine == "vlc" && ms > 0 && total >= 65536) speedBps = total * 8000 / ms
                }
                c.disconnect()
            } catch (e: Exception) { }
        }.start()
        h.postDelayed({ probeLoop() }, 6000)
    }

    override fun onDestroy() {
        alive = false; h.removeCallbacksAndMessages(null)
        releaseExo(); releaseVlc()
        super.onDestroy()
    }
}
