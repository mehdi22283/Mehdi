package az.m3u.sinayici

import android.app.PictureInPictureParams
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.AudioAttributes
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import java.util.Locale

/** Tam ExoPlayer (Media3) oynadıcı: keyfiyyət, sürət, səs, altyazı, ekran rejimi, linklər, statistika. */
@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var statsView: TextView
    private lateinit var topBar: View
    private lateinit var titleView: TextView
    private lateinit var bandwidth: DefaultBandwidthMeter
    private lateinit var trackSelector: DefaultTrackSelector

    private var urls: List<String> = emptyList()
    private var index = 0
    private var name = ""
    private var statsOn = true
    private var forcedHls = false
    private var retries = 0
    private var latencyMs = -1L
    private var prevAhead = -1.0
    private var bufferLabel = "🔴"
    private var errorText: String? = null
    private var inPip = false
    private var aspectIdx = 0

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 1000)
        }
    }
    private val latTick = object : Runnable {
        override fun run() {
            measureLatency()
            handler.postDelayed(this, 6000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.playerView)
        statsView = findViewById(R.id.statsView)
        topBar = findViewById(R.id.topBar)
        titleView = findViewById(R.id.titleView)
        hideSystemBars()

        playerView.setControllerVisibilityListener(object : PlayerView.ControllerVisibilityListener {
            override fun onVisibilityChanged(visibility: Int) {
                topBar.visibility = if (inPip) View.GONE else if (visibility == View.VISIBLE) View.VISIBLE else View.GONE
            }
        })

        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.btnQuality).setOnClickListener { showTrackDialog(C.TRACK_TYPE_VIDEO, "Keyfiyyət (resolution)", false) }
        findViewById<View>(R.id.btnAudio).setOnClickListener { showTrackDialog(C.TRACK_TYPE_AUDIO, "Səs yolu", false) }
        findViewById<View>(R.id.btnText).setOnClickListener { showTrackDialog(C.TRACK_TYPE_TEXT, "Altyazı", true) }
        findViewById<View>(R.id.btnSpeed).setOnClickListener { showSpeed() }
        findViewById<View>(R.id.btnAspect).setOnClickListener { showAspect() }
        findViewById<View>(R.id.btnLinks).setOnClickListener { showLinks() }
        findViewById<View>(R.id.btnCopy).setOnClickListener { copyLink() }
        findViewById<View>(R.id.btnStats).setOnClickListener {
            statsOn = !statsOn
            updateStats()
        }
        findViewById<View>(R.id.btnReloadP).setOnClickListener {
            forcedHls = false
            retries = 0
            load()
        }
        findViewById<View>(R.id.btnPip).setOnClickListener { enterPip() }

        parse(intent)
        initPlayer()
        load()
        handler.post(tick)
        handler.post(latTick)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        parse(intent)
        forcedHls = false
        retries = 0
        load()
    }

    private fun parse(i: Intent) {
        name = i.getStringExtra("name") ?: ""
        val list = ArrayList<String>()
        try {
            val arr = JSONArray(i.getStringExtra("urls") ?: "[]")
            for (k in 0 until arr.length()) {
                val u = arr.optString(k)
                if (u.isNotBlank()) list.add(u.trim())
            }
        } catch (_: Exception) {
        }
        urls = list
        index = 0
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun initPlayer() {
        bandwidth = DefaultBandwidthMeter.Builder(this).build()
        trackSelector = DefaultTrackSelector(this)
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(Net.UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(15000)
        val ds = DefaultDataSource.Factory(this, http)
        val p = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setTrackSelector(trackSelector)
            .setBandwidthMeter(bandwidth)
            .setMediaSourceFactory(DefaultMediaSourceFactory(ds))
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) = handleError(error)
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    retries = 0
                    errorText = null
                }
                updateStats()
            }
            override fun onTracksChanged(tracks: Tracks) = updateStats()
            override fun onVideoSizeChanged(videoSize: VideoSize) = updateStats()
        })
        playerView.player = p
        player = p
    }

    private fun load() {
        val p = player ?: return
        if (urls.isEmpty()) {
            errorText = "❌ Link yoxdur"
            updateStats()
            return
        }
        val b = MediaItem.Builder().setUri(urls[index])
        if (forcedHls) b.setMimeType(MimeTypes.APPLICATION_M3U8)
        p.setMediaItem(b.build())
        p.prepare()
        p.playWhenReady = true
        errorText = null
        prevAhead = -1.0
        titleView.text = if (urls.size > 1) "$name — Link ${index + 1}/${urls.size}" else name
    }

    private fun handleError(e: PlaybackException) {
        val p = player ?: return
        when (e.errorCode) {
            PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW -> {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED -> {
                if (!forcedHls) {
                    forcedHls = true
                    load()
                    return
                }
            }
            else -> {}
        }
        val network = e.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
            e.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ||
            e.errorCode == PlaybackException.ERROR_CODE_IO_UNSPECIFIED
        if (retries < 2 && network) {
            retries++
            handler.postDelayed({ load() }, 1500)
            return
        }
        if (index + 1 < urls.size) {
            index++
            forcedHls = false
            retries = 0
            Toast.makeText(this, "Link ${index + 1}/${urls.size}-ə keçilir", Toast.LENGTH_SHORT).show()
            load()
            return
        }
        errorText = "❌ Oynatma xətası: ${e.errorCodeName}"
        updateStats()
    }

    // ---------------- statistika (HTML-dəki overlay ilə eyni) ----------------

    private fun fmtBps(bps: Long): String = when {
        bps <= 0 -> "naməlum"
        bps >= 1_000_000 -> String.format(Locale.US, "%.2f Mbps", bps / 1_000_000.0)
        else -> "${bps / 1000} kbps"
    }

    private fun updateStats() {
        val p = player ?: return
        statsView.visibility = if (statsOn && !inPip) View.VISIBLE else View.GONE
        if (!statsOn) return
        val w = p.videoSize.width
        val h = p.videoSize.height
        val res = if (w > 0 && h > 0) "${w}×${h}" else "naməlum"
        val br = p.videoFormat?.let { if (it.bitrate > 0) it.bitrate.toLong() else 0L } ?: 0L
        val lat = if (latencyMs >= 0) "$latencyMs ms" else "naməlum"
        val speed = fmtBps(bandwidth.bitrateEstimate)

        val ahead = (p.bufferedPosition - p.currentPosition) / 1000.0
        val st = p.playbackState
        bufferLabel = when {
            st == Player.STATE_BUFFERING || st == Player.STATE_IDLE || ahead <= 0.1 -> "🔴"
            ahead < 2 -> "🟠"
            prevAhead < 0 -> "🟢"
            ahead - prevAhead > 0.2 -> "🟢"
            ahead - prevAhead < -0.2 -> "🟡"
            else -> "🟢"
        }
        prevAhead = ahead

        val sp = p.playbackParameters.speed
        val spTxt = if (sp != 1f) "  ⏩ ${sp}x" else ""
        statsView.text = "🔲 $res  ⚡ ${fmtBps(br)}  🛰 $lat  ⬇ $speed  🪣 $bufferLabel$spTxt" +
            (errorText?.let { "\n$it" } ?: "")
    }

    private fun measureLatency() {
        val u = urls.getOrNull(index) ?: return
        Thread {
            val ms = Net.ttfb(u)
            runOnUiThread { latencyMs = ms }
        }.start()
    }

    // ---------------- dialoqlar ----------------

    private class TrackItem(val kind: Int, val group: Tracks.Group?, val idx: Int, val label: String, val selected: Boolean)

    private fun showTrackDialog(type: Int, title: String, withOff: Boolean) {
        val p = player ?: return
        val params = p.trackSelectionParameters
        val disabled = params.disabledTrackTypes.contains(type)
        val overridden = params.overrides.values.any { it.type == type }
        val items = ArrayList<TrackItem>()
        if (withOff) items.add(TrackItem(1, null, 0, "Söndür", disabled))
        items.add(TrackItem(0, null, 0, "Avto", !disabled && !overridden))

        val tracks = ArrayList<TrackItem>()
        for (g in p.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                val label = when (type) {
                    C.TRACK_TYPE_VIDEO -> {
                        val hh = if (f.height > 0) "${f.height}p" else "?"
                        val br = if (f.bitrate > 0) "  •  ${fmtBps(f.bitrate.toLong())}" else ""
                        hh + br
                    }
                    C.TRACK_TYPE_AUDIO -> listOfNotNull(
                        f.label, f.language,
                        if (f.channelCount > 0) "${f.channelCount}ch" else null,
                        if (f.bitrate > 0) fmtBps(f.bitrate.toLong()) else null
                    ).joinToString(" • ").ifEmpty { "Səs ${tracks.size + 1}" }
                    else -> listOfNotNull(f.label, f.language).joinToString(" • ").ifEmpty { "Altyazı ${tracks.size + 1}" }
                }
                tracks.add(TrackItem(2, g, i, label, !disabled && overridden && g.isTrackSelected(i)))
            }
        }
        if (type == C.TRACK_TYPE_VIDEO) {
            tracks.sortByDescending { it.group!!.getTrackFormat(it.idx).height }
        }
        items.addAll(tracks)
        if (tracks.isEmpty() && !withOff) {
            Toast.makeText(this, "Bu axında seçim yoxdur", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = items.map { (if (it.selected) "✔ " else "") + it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels) { _, which ->
                val item = items[which]
                val b = p.trackSelectionParameters.buildUpon()
                when (item.kind) {
                    1 -> b.setTrackTypeDisabled(type, true)
                    0 -> b.clearOverridesOfType(type).setTrackTypeDisabled(type, false)
                    else -> b.setTrackTypeDisabled(type, false)
                        .setOverrideForType(TrackSelectionOverride(item.group!!.mediaTrackGroup, item.idx))
                }
                p.trackSelectionParameters = b.build()
            }
            .show()
    }

    private fun showSpeed() {
        val p = player ?: return
        val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
        val cur = p.playbackParameters.speed
        val labels = speeds.map { (if (it == cur) "✔ " else "") + (if (it == 1f) "Normal (1x)" else "${it}x") }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Oxutma sürəti")
            .setItems(labels) { _, which -> p.setPlaybackSpeed(speeds[which]); updateStats() }
            .show()
    }

    private fun showAspect() {
        val modes = intArrayOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FILL,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
            AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
        )
        val names = arrayOf("Sığdır", "Uzat (doldur)", "Kəs (zoom)", "Enə görə", "Hündürlüyə görə")
        val labels = names.mapIndexed { i, n -> (if (i == aspectIdx) "✔ " else "") + n }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Ekran nisbəti")
            .setItems(labels) { _, which ->
                aspectIdx = which
                playerView.resizeMode = modes[which]
            }
            .show()
    }

    private fun showLinks() {
        if (urls.isEmpty()) return
        val labels = urls.mapIndexed { i, u -> (if (i == index) "✔ " else "") + "Link ${i + 1}: " + u }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Alternativ linklər")
            .setItems(labels) { _, which ->
                index = which
                forcedHls = false
                retries = 0
                load()
            }
            .show()
    }

    private fun copyLink() {
        val u = urls.getOrNull(index) ?: return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("url", u))
        Toast.makeText(this, "✔ Link kopyalandı", Toast.LENGTH_SHORT).show()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
            } catch (_: Exception) {
                Toast.makeText(this, "PiP dəstəklənmir", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "PiP bu Android versiyasında yoxdur", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        playerView.useController = !isInPictureInPictureMode
        topBar.visibility = View.GONE
        updateStats()
    }

    override fun onStop() {
        super.onStop()
        if (!inPip) player?.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }
}
