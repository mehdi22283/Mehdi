package com.example.callrec

import android.content.Context
import java.net.InetSocketAddress
import java.net.Socket

/** Shell prosesi ilə 127.0.0.1 üzərindən danışır (Wi-Fi tələb etmir). */
class RecorderClient(ctx: Context) {
    private val token = Prefs.token(ctx)

    private fun send(line: String): String? = try {
        Socket().use { s ->
            s.connect(InetSocketAddress("127.0.0.1", Prefs.PORT), 800)
            s.soTimeout = 4000
            s.getOutputStream().apply { write("$token $line\n".toByteArray()); flush() }
            s.getInputStream().bufferedReader().readLine()
        }
    } catch (_: Throwable) { null }

    fun ping() = send("PING") == "OK"
    fun start(path: String, sources: IntArray) = send("START $path ${sources.joinToString(",")}") == "OK"
    fun stop() = send("STOP") == "OK"
    fun quit() = send("QUIT") == "OK"
}
