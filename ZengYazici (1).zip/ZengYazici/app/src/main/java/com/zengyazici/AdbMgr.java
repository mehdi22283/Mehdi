package com.zengyazici;

import android.content.Context;
import android.os.Build;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import java.math.BigInteger;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

/** Lokal ADB bağlantısı. Açar bir dəfə yaradılır və saxlanılır (yenidən icazə soruşulmasın deyə). */
public class AdbMgr extends AbsAdbConnectionManager {
    private static AdbMgr I;

    public static synchronized AdbMgr get(Context c) throws Exception {
        if (I == null) I = new AdbMgr(c.getApplicationContext());
        return I;
    }

    public static AdbMgr peek() { return I; }

    private PrivateKey pk;
    private Certificate cert;

    private AdbMgr(Context c) throws Exception {
        setApi(Build.VERSION.SDK_INT);
        File kf = new File(c.getFilesDir(), "adb.key");
        File cf = new File(c.getFilesDir(), "adb.crt");
        if (kf.exists() && cf.exists()) {
            try {
                pk = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(kf.toPath())));
                cert = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(Files.readAllBytes(cf.toPath())));
            } catch (Exception e) { pk = null; cert = null; }
        }
        if (pk == null) {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048, SecureRandom.getInstance("SHA1PRNG"));
            KeyPair kp = g.generateKeyPair();
            PublicKey pub = kp.getPublic();
            pk = kp.getPrivate();
            Date nb = new Date();
            Date na = new Date(System.currentTimeMillis() + 3650L * 86400000L);
            X500Name name = new X500Name("CN=ZengYazici");
            JcaX509v3CertificateBuilder b = new JcaX509v3CertificateBuilder(
                    name, BigInteger.valueOf(System.nanoTime() & Long.MAX_VALUE), nb, na, name, pub);
            cert = new JcaX509CertificateConverter().getCertificate(
                    b.build(new JcaContentSignerBuilder("SHA256withRSA").build(pk)));
            Files.write(kf.toPath(), pk.getEncoded());
            Files.write(cf.toPath(), cert.getEncoded());
        }
    }

    public PrivateKey getPrivateKey() { return pk; }
    public Certificate getCertificate() { return cert; }
    public String getDeviceName() { return "ZengYazici"; }
}
