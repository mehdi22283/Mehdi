package com.example.callrec;

import android.content.AttributionSource;
import android.content.Context;
import android.content.ContextWrapper;

public class FakeContext extends ContextWrapper {
    public FakeContext(Context base) { super(base); }
    public String getPackageName() { return "com.android.shell"; }
    public String getOpPackageName() { return "com.android.shell"; }
    public AttributionSource getAttributionSource() {
        return new AttributionSource.Builder(2000).setPackageName("com.android.shell").build();
    }
    public Context getApplicationContext() { return this; }

    public static Context create() throws Exception {
        Class<?> at = Class.forName("android.app.ActivityThread");
        Object thread = at.getMethod("systemMain").invoke(null);
        Context sys = (Context) at.getMethod("getSystemContext").invoke(thread);
        return new FakeContext(sys);
    }
}
