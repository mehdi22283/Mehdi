package com.example.adbtv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

class AdbService : Service() {

    private val host = "192.168.31.220"
    private val port = 5555
    private val command = "sh /storage/emulated/0/Android/data/io.github.sds100.keymapper/start.sh"

    @Volatile private var running = false
    private var worker: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val triggers = LinkedBlockingQueue<Boolean>()
    private var lastRun = 0L
    private var lastAutoRestart = 0L
    private var restarts = 0

    // Key Mapper-in ADB ilə başladılan prosesinin adı. Fərqli olarsa bunu dəyişin.
    private val processName = "keymapper_sysbridge"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "ADB", NotificationManager.IMPORTANCE_LOW)
        )
        val n = buildNotification(status.lineSequence().first())
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        if (intent?.action == ACTION_RUN) triggers.offer(true)

        if (worker?.isAlive != true) {
            running = true
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "adbtv:svc").apply { acquire() }
            worker = Thread { loop() }.also { it.start() }
        }
        return START_STICKY
    }

    private fun loop() {
        while (running) {
            try {
                val priv = File(filesDir, "adbkey")
                val pub = File(filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val keyPair = AdbKeyPair.read(priv, pub)

                update("Qoşulur: $host:$port")
                Dadb.create(host, port, keyPair).use { adb ->
                    runCommand(adb)
                    triggers.clear()
                    while (running) {
                        // Əl ilə tetikləmə gəlsə dərhal oyanır, yoxsa 30 san. gözləyir
                        val manual = triggers.poll(30, TimeUnit.SECONDS) != null
                        val minutes = getSharedPreferences(PREFS, MODE_PRIVATE)
                            .getInt(KEY_INTERVAL, DEFAULT_INTERVAL)
                        val due = minutes > 0 &&
                            System.currentTimeMillis() - lastRun >= minutes * 60_000L
                        val watch = getSharedPreferences(PREFS, MODE_PRIVATE)
                            .getBoolean(KEY_WATCH, true)
                        if (manual || due) {
                            runCommand(adb)
                        } else if (watch && !isRunning(adb)) {
                            val now = System.currentTimeMillis()
                            // Sonsuz restart dövrünün qarşısı: iki restart arası min. 60 san.
                            if (now - lastAutoRestart >= 60_000L) {
                                lastAutoRestart = now
                                restarts++
                                update("Key Mapper dayanmışdı, yenidən başladılır...")
                                runCommand(adb, "Avto-restart #$restarts")
                            }
                        } else {
                            adb.shell("echo ok") // bağlantı canlıdır?
                        }
                    }
                }
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                update("Xəta: ${e.message}\n10 san. sonra təkrar cəhd olunacaq")
            }
            try { Thread.sleep(10_000) } catch (e: InterruptedException) { break }
        }
    }

    private fun isRunning(adb: Dadb): Boolean =
        adb.shell("(ps -A 2>/dev/null || ps) | grep -q '[${processName.first()}]${processName.drop(1)}'").exitCode == 0

    private fun runCommand(adb: Dadb, label: String = "Son icra") {
        update("Əmr icra olunur...")
        val r = adb.shell(command)
        lastRun = System.currentTimeMillis()
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(lastRun))
        val out = r.allOutput.trim().take(500)
        update("Qoşuludur. $label: $time (exit ${r.exitCode})" + if (out.isNotEmpty()) "\n$out" else "")
    }

    private fun buildNotification(text: String): Notification =
        Notification.Builder(this, CHANNEL)
            .setContentTitle("ADB Launcher")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
            .setDeleteIntent(
                PendingIntent.getService(
                    this, 0, Intent(this, AdbService::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            .build()

    private fun update(text: String) {
        status = text
        getSystemService(NotificationManager::class.java)
            .notify(1, buildNotification(text.lineSequence().first()))
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    companion object {
        const val ACTION_RUN = "com.example.adbtv.RUN"
        const val PREFS = "cfg"
        const val KEY_INTERVAL = "interval_min"
        const val KEY_WATCH = "watch"
        const val DEFAULT_INTERVAL = 15
        private const val CHANNEL = "adb_channel"

        @Volatile var status: String = "Başladılır..."
    }
}
