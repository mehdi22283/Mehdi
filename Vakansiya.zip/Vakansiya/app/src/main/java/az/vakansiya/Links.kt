package az.vakansiya

/** Səhifədəki elan linklərini JSON massivi kimi qaytaran JS. */
object Links {
    fun js(heads: Boolean): String = """(function(){var o=location.origin,a=document.querySelectorAll('a[href]'),s={},r=[];
for(var i=0;i<a.length;i++){var h=a[i].href;if(h.indexOf(o)!==0)continue;h=h.split('#')[0];
if(!/[0-9]{3,}|vakans|vacanc|elan|job/i.test(h.replace(o,'')))continue;
if(s[h])continue;s[h]=1;r.push(h)}
if($heads){var q=document.querySelectorAll('h1 a[href],h2 a[href],h3 a[href],h4 a[href]');
for(var j=0;j<q.length;j++){var g=q[j].href.split('#')[0];if(g.indexOf('http')!==0||s[g])continue;s[g]=1;r.push(g)}}
return JSON.stringify(r.slice(0,300))})()"""
}
