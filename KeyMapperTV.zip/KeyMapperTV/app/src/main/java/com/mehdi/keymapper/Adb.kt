package com.mehdi.keymapper

import android.content.Context
import android.provider.Settings
import dadb.AdbKeyPair
import dadb.AdbStream
import dadb.Dadb
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

object Adb {
    enum class State { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

    @Volatile var state = State.DISCONNECTED
        private set
    @Volatile var error: String? = null
        private set
    /** true = düymələr daimi injector prosesi ilə (gecikmə ~1-3 ms) göndərilir */
    @Volatile var fast = false
        private set
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    private val io = Executors.newSingleThreadExecutor()
    private val inj = Executors.newSingleThreadExecutor()
    @Volatile private var dadb: Dadb? = null
    @Volatile private var stream: AdbStream? = null
    private lateinit var app: Context

    fun init(c: Context) { app = c.applicationContext }

    private fun notifyChange() {
        listeners.forEach { try { it() } catch (_: Exception) {} }
    }

    private fun set(s: State, e: String? = null) {
        state = s
        error = e
        notifyChange()
    }

    fun connect(force: Boolean = false) {
        if (!force && (state == State.CONNECTING || state == State.CONNECTED)) return
        io.execute { doConnect() }
    }

    private fun doConnect(): Boolean {
        set(State.CONNECTING)
        fast = false
        try { stream?.close() } catch (_: Exception) {}
        stream = null
        try { dadb?.close() } catch (_: Exception) {}
        dadb = null
        return try {
            val priv = File(app.filesDir, "adbkey")
            val pub = File(app.filesDir, "adbkey.pub")
            if (!priv.exists()) AdbKeyPair.generate(priv, pub)
            val d = Dadb.create(Store.host, Store.port, AdbKeyPair.read(priv, pub))
            val r = d.shell("echo ok")
            if (!r.output.contains("ok")) throw RuntimeException("cavab yoxdur")
            dadb = d
            set(State.CONNECTED)
            startInjector()
            afterConnect()
            true
        } catch (e: Throwable) {
            dadb = null
            set(State.ERROR, e.message ?: e.javaClass.simpleName)
            false
        }
    }

    /** TV-də daimi işləyən sürətli düymə göndərici prosesi başladır. */
    private fun startInjector() {
        fast = false
        try { stream?.close() } catch (_: Exception) {}
        stream = null
        val d = dadb ?: return
        try {
            try { d.shell("pkill -f 'com.mehdi.keymapper.Injecto[r]'") } catch (_: Exception) {}
            val apk = app.applicationInfo.sourceDir
            val st = d.open("shell:CLASSPATH=$apk exec app_process /system/bin com.mehdi.keymapper.Injector")
            var ok = false
            for (i in 0 until 6) {
                val l = st.source.readUtf8Line() ?: break
                if (l.startsWith("READY")) { ok = true; break }
                if (l.startsWith("FAIL")) break
            }
            if (ok) { stream = st; fast = true } else st.close()
        } catch (_: Throwable) {
            fast = false
        }
        notifyChange()
    }

    private fun exec(cmd: String): String {
        val d = dadb ?: throw IllegalStateException("ADB qoşulmayıb")
        return d.shell(cmd).output
    }

    fun shell(cmd: String, cb: ((String) -> Unit)? = null) {
        io.execute {
            try {
                if (dadb == null && !doConnect()) return@execute
                val out = try { exec(cmd) } catch (e: Throwable) {
                    if (!doConnect()) return@execute
                    exec(cmd)
                }
                cb?.invoke(out)
            } catch (e: Throwable) {
                set(State.ERROR, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    // ---- Sürətli düymə göndərmə ----
    fun keyDown(code: Int, repeat: Int) = send("D $code $repeat")
    fun keyUp(code: Int) = send("U $code")
    fun tap(code: Int) = send("T $code")

    private fun send(line: String) {
        inj.execute {
            val s = stream
            if (fast && s != null) {
                try {
                    s.sink.writeUtf8(line).writeUtf8("\n")
                    s.sink.flush()
                    return@execute
                } catch (e: Throwable) {
                    fast = false
                    notifyChange()
                    io.execute { if (state == State.CONNECTED) startInjector() }
                }
            }
            // ehtiyat rejim: yavaş "input keyevent"
            val p = line.split(" ")
            if (p[0] == "T" || (p[0] == "D" && (p.getOrNull(2) ?: "0") == "0")) {
                shell("input keyevent ${p[1]}")
            }
        }
    }

    fun ping() {
        if (state != State.CONNECTED) return
        io.execute {
            try { exec("echo ok") } catch (e: Throwable) { doConnect() }
        }
    }

    /** Əlçatımlılıq servisini ayarlara girmədən ADB ilə aktiv edir. */
    private fun enableAccessibility() {
        val pkg = app.packageName
        val cn = "$pkg/$pkg.KeyMapperService"
        val cur = exec("settings get secure enabled_accessibility_services").trim()
        if (!cur.contains("$pkg/")) {
            val v = if (cur.isEmpty() || cur == "null") cn else "$cur:$cn"
            exec("settings put secure enabled_accessibility_services $v")
        }
        exec("settings put secure accessibility_enabled 1")
    }

    fun enableAccessibilityAsync() {
        io.execute {
            try {
                if (dadb == null && !doConnect()) return@execute
                enableAccessibility()
            } catch (e: Throwable) {
                set(State.ERROR, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun afterConnect() {
        try {
            val pkg = app.packageName
            val on = Settings.Secure.getString(
                app.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            if (!on.contains("$pkg/") || !KeyMapperService.running) enableAccessibility()
            exec("dumpsys deviceidle whitelist +$pkg")
            exec("cmd appops set $pkg RUN_IN_BACKGROUND allow")
            exec("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow")
        } catch (_: Throwable) {}
    }
}
