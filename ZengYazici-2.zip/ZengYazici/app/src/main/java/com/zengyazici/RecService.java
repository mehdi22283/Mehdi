package com.zengyazici;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.IBinder;
import android.provider.CallLog;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyManager;
import io.github.muntashirakon.adb.AdbStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RecService extends Service {
    public static final String CH_FG = "fg", CH_EV = "ev";
    public static final String A_STOP = "stop", A_WA_ON = "wa_on", A_WA_OFF = "wa_off";
    public static volatile boolean running;
    public static final StringBuilder LOG = new StringBuilder();

    public static void log(String s) {
        synchronized (LOG) {
            LOG.append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date())).append(' ').append(s).append('\n');
            if (LOG.length() > 20000) LOG.delete(0, 5000);
        }
    }

    private NotificationManager nm;
    private AdbMgr mgr;
    private TelephonyManager tm;
    private Object cb;
    private boolean listening, ringing, stopping;
    private volatile boolean rec;
    private String app = "", dir = "in", num = "";
    private long t0;
    private File file;
    private ServerSocket ss;
    private AdbStream st;
    private Thread wt;
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final Handler h = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wl;
    private boolean lastFail;
    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            if (!running) return;
            if (!rec && (mgr == null || !mgr.isConnected())) ex.execute(RecService.this::tryConnect);
            listen();
            h.postDelayed(this, 30000);
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH_FG, "Xidmət", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CH_EV, "Zəng yazıları", NotificationManager.IMPORTANCE_HIGH));
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        String a = i == null ? null : i.getAction();
        if (A_STOP.equals(a)) {
            getSharedPreferences("cfg", 0).edit().putBoolean("autostart", false).apply();
            h.removeCallbacks(watchdog);
            if (rec) stopRec();
            running = false;
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            startFg("Zəng gözlənilir");
            listen();
            ex.execute(this::tryConnect);
            h.postDelayed(watchdog, 30000);
        }
        if (A_WA_ON.equals(a)) startRec("WhatsApp", i.getStringExtra("dir"), i.getStringExtra("name"));
        if (A_WA_OFF.equals(a) && "WhatsApp".equals(app)) stopRec();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacks(watchdog);
        release();
        try {
            if (cb != null && tm != null) {
                if (Build.VERSION.SDK_INT >= 31) tm.unregisterTelephonyCallback((TelephonyCallback) cb);
                else tm.listen((PhoneStateListener) cb, PhoneStateListener.LISTEN_NONE);
            }
        } catch (Throwable e) { }
        ex.shutdown();
        super.onDestroy();
    }

    // ---------- bildirişlər ----------
    private PendingIntent openApp() {
        return PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification fgNotif(String text) {
        return new Notification.Builder(this, CH_FG)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Zəng Yazıcı işləyir")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(openApp())
                .build();
    }

    private void startFg(String text) {
        Notification n = fgNotif(text);
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    private void updateFg(String text) { nm.notify(1, fgNotif(text)); }

    private void notifyEv(int id, String title, String text, boolean ongoing) {
        nm.notify(id, new Notification.Builder(this, CH_EV)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(ongoing)
                .setAutoCancel(!ongoing)
                .setCategory(Notification.CATEGORY_STATUS)
                .setContentIntent(openApp())
                .build());
    }

    // ---------- ADB ----------
    private void ensureConnected() throws Exception {
        if (mgr == null) mgr = AdbMgr.get(this);
        if (mgr.isConnected()) return;
        SharedPreferences p = getSharedPreferences("cfg", 0);
        String ip = p.getString("ip", "");
        int port = p.getInt("port", 0);
        if (ip.isEmpty() || port == 0) throw new Exception("IP/port daxil edilməyib");
        mgr.connect(ip, port);
        if (!mgr.isConnected()) throw new Exception("ADB qoşulmadı");
    }

    private void tryConnect() {
        try {
            ensureConnected();
            if (lastFail) log("ADB yenidən qoşuldu");
            lastFail = false;
            updateFg("ADB qoşulub · zəng gözlənilir");
        } catch (Throwable e) {
            if (!lastFail) log("ADB: " + e);
            lastFail = true;
            updateFg("ADB qoşulmayıb — yenidən cəhd edilir");
        }
    }

    // ---------- zəng izləmə ----------
    private void listen() {
        if (listening) return;
        try {
            tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            if (Build.VERSION.SDK_INT >= 31) {
                cb = new Cb31();
                tm.registerTelephonyCallback(getMainExecutor(), (TelephonyCallback) cb);
            } else {
                PhoneStateListener l = new PhoneStateListener() {
                    @Override public void onCallStateChanged(int s, String n) { onState(s); }
                };
                cb = l;
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE);
            }
            listening = true;
            log("Zəng dinləyicisi aktiv");
        } catch (Throwable e) {
            log("Dinləyici: " + e);
        }
    }

    @android.annotation.TargetApi(31)
    private class Cb31 extends TelephonyCallback implements TelephonyCallback.CallStateListener {
        @Override public void onCallStateChanged(int s) { onState(s); }
    }

    private void onState(int s) {
        if (s == TelephonyManager.CALL_STATE_RINGING) {
            ringing = true;
        } else if (s == TelephonyManager.CALL_STATE_OFFHOOK) {
            if (!rec) startRec("Telefon", ringing ? "in" : "out", "");
        } else if (s == TelephonyManager.CALL_STATE_IDLE) {
            ringing = false;
            if (rec && "Telefon".equals(app)) stopRec();
        }
    }

    // ---------- yazı ----------
    private String label() {
        return app + " · " + ("out".equals(dir) ? "gedən" : "gələn") + (num.isEmpty() ? "" : " · " + num);
    }

    private static String fmt(int s) { return String.format(Locale.US, "%d:%02d", s / 60, s % 60); }

    private void startRec(String a, String d, String n) {
        if (rec) return;
        rec = true;
        app = a;
        dir = d == null || d.isEmpty() ? "in" : d;
        num = n == null ? "" : n;
        t0 = System.currentTimeMillis();
        try {
            if (wl == null) wl = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zengyazici:rec");
            wl.acquire(4 * 60 * 60 * 1000L);
        } catch (Throwable e) { }
        ex.execute(() -> {
            try {
                ensureConnected();
                File dirF = new File(getFilesDir(), "rec");
                dirF.mkdirs();
                final File f = new File(dirF, "rec_" + t0 + ".wav");
                file = f;
                final ServerSocket s = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
                ss = s;
                s.setSoTimeout(20000);
                String src = "Telefon".equals(app) ? "4,3,7,1" : "8,7,1";
                final AdbStream stream = mgr.openStream("shell:CLASSPATH=" + getPackageCodePath()
                        + " app_process /system/bin com.zengyazici.Rec " + s.getLocalPort() + " " + src);
                st = stream;
                Thread rt = new Thread(() -> {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(stream.openInputStream()))) {
                        String l;
                        while ((l = br.readLine()) != null) log("rec: " + l);
                    } catch (Exception e) { }
                });
                rt.setDaemon(true);
                rt.start();
                wt = new Thread(() -> pump(s, f));
                wt.setDaemon(true);
                wt.start();
                notifyEv(2, "🔴 Zəng yazılır", label(), true);
                updateFg("Yazılır: " + label());
            } catch (Throwable e) {
                log("Yazı başlamadı: " + e);
                rec = false;
                release();
                notifyEv(4, "Zəng yazıla bilmədi", String.valueOf(e.getMessage()), false);
            }
        });
    }

    private void release() {
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable e) { }
    }

    private void pump(ServerSocket s, File f) {
        long total = 0;
        try (RandomAccessFile r = new RandomAccessFile(f, "rw")) {
            r.write(new byte[44]);
            try {
                Socket c = s.accept();
                InputStream in = c.getInputStream();
                int src = in.read();
                log("Audio mənbəyi: " + src);
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) > 0) { r.write(b, 0, n); total += n; }
            } catch (Exception e) {
                log("Audio axını: " + e);
            }
            header(r, total);
        } catch (Exception e) {
            log("Fayl: " + e);
        }
    }

    private static void header(RandomAccessFile r, long n) throws Exception {
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes()).putInt((int) (36 + n)).put("WAVE".getBytes()).put("fmt ".getBytes())
                .putInt(16).putShort((short) 1).putShort((short) 1).putInt(16000).putInt(32000)
                .putShort((short) 2).putShort((short) 16).put("data".getBytes()).putInt((int) n);
        r.seek(0);
        r.write(b.array());
    }

    private void stopRec() {
        if (!rec || stopping) return;
        stopping = true;
        ex.execute(() -> {
            try { if (st != null) st.close(); } catch (Throwable e) { }
            try { if (ss != null) ss.close(); } catch (Throwable e) { }
            try { if (wt != null) wt.join(5000); } catch (Throwable e) { }
            st = null; ss = null; wt = null;
            nm.cancel(2);
            int dur = (int) ((System.currentTimeMillis() - t0) / 1000);
            File f = file;
            if (f != null && f.length() > 8000) {
                resolve();
                Db.Item it = new Db.Item();
                it.path = f.getAbsolutePath();
                it.num = num;
                it.app = app;
                it.dir = dir;
                it.ts = t0;
                it.dur = dur;
                Db.add(this, it);
                notifyEv(3, "✅ Zəng yazıldı", label() + " · " + fmt(dur), false);
            } else {
                if (f != null) f.delete();
                notifyEv(4, "Zəng yazıla bilmədi", "Audio alınmadı — Log-a baxın", false);
            }
            rec = false;
            stopping = false;
            release();
            if (running) updateFg("ADB qoşulub · zəng gözlənilir");
        });
    }

    /** Nömrə/ad və istiqaməti zəng jurnalından dəqiqləşdirir. */
    private void resolve() {
        if (!"Telefon".equals(app)) {
            if (num.isEmpty()) num = "WhatsApp";
            return;
        }
        try { Thread.sleep(1200); } catch (Exception e) { }
        try {
            Bundle b = new Bundle();
            b.putInt(ContentResolver.QUERY_ARG_LIMIT, 1);
            b.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, new String[]{CallLog.Calls.DATE});
            b.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING);
            Cursor c = getContentResolver().query(CallLog.Calls.CONTENT_URI,
                    new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE}, b, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        String nu = c.getString(0), na = c.getString(1);
                        int ty = c.getInt(2);
                        if (na != null && !na.isEmpty()) num = na;
                        else if (nu != null && !nu.isEmpty()) num = nu;
                        if (ty == CallLog.Calls.OUTGOING_TYPE) dir = "out";
                        else if (ty == CallLog.Calls.INCOMING_TYPE) dir = "in";
                    }
                } finally { c.close(); }
            }
        } catch (Throwable e) {
            log("Zəng jurnalı: " + e);
        }
        if (num.isEmpty()) num = "Naməlum";
    }
}
