# M3U Sınayıcı — Android APK

HTML tətbiqiniz (`app/src/main/assets/m3u-sinayici.html`) WebView içində işləyir, oxutma isə tam **Media3 ExoPlayer**-dir.

## Funksiyalar
- **Daxili brauzer** (qaranlıq mövzu): ana səhifədə `🌐 Daxili brauzer` düyməsi. Endirilən və ya toxunulan `.m3u` / `.m3u8` fayl avtomatik **1-ci Playlist**ə yazılır, brauzer bağlanır və kanallar dərhal test olunur. Fayl daimi saxlanır (tətbiq yenidən açılanda yenə 1-ci playlistdədir).
- **1-ci Playlist məlumat qutusu**: son giriş tarixi, bu giriş, indiyə qədər xarab olan kanalların sayı və siyahısı (hazırda xarab / sonradan düzəlib), tarixçəni təmizləmə.
- **2-ci Playlist** əvvəlki kimi müstəqil işləyir.
- **ExoPlayer**: keyfiyyət (resolution) seçimi / Avto-ABR, oxutma sürəti (0.25x–2x), səs yolu, altyazı, ekran nisbəti, alternativ linklər (`#http://...` ehtiyat linklər) və avtomatik növbəti linkə keçid, link kopyala, PiP, yenilə, HLS-ə avtomatik fallback və yenidən cəhd; HTML-dəki statistika (🔲 resolution ⚡ bitrate 🛰 gecikmə ⬇ sürət 🪣 bufer).
- Kanal yoxlaması native (CORS-suz) aparılır.
- İxrac edilən playlist `Yüklənənlər` qovluğuna yazılır. Fayl menecerindən `.m3u` açmaq da 1-ci playlistə yükləyir.

## APK necə yığılır
**Variant 1 — Android Studio:** qovluğu `Open` edin → Gradle sync → `Build > Build APK(s)`. Nəticə: `app/build/outputs/apk/debug/app-debug.apk`.

**Variant 2 — GitHub Actions:** layihəni GitHub repoya yükləyin; `Actions > APK yığ` işləyəcək və `M3U-Sinayici-apk` artefaktında `app-debug.apk` olacaq.

**Variant 3 — komanda xətti** (Android SDK + Gradle 8.7 + JDK 17): `gradle assembleDebug`.
