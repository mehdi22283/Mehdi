package az.m3u.sinayici

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * 🛠 Ottplayer canlı edit: https://ottplayer.tv/playlist/edit/215091118 səhifəsini açır (giriş ekranı gəlsə avtomatik doldurur),
 * "Channels" düyməsinə basır və kanalların yanına testerdəki kimi 🟢/🔴 statusu (və qırmızı səbəb) qoyur.
 * Dəyişikliklər Ottplayer-in öz redaktorunda canlı görünür; 💾 Save düyməsi saytın Save düyməsinə basır.
 */
class OttEditActivity : Activity() {
    companion object { const val EDIT = "https://ottplayer.tv/playlist/edit/215091118" }

    private lateinit var web: WebView
    private lateinit var stat: TextView
    private val pool = Executors.newFixedThreadPool(24)
    private var redOnly = false
    private var redirects = 0
    private lateinit var btnRed: Button

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK); fitsSystemWindows = true }

        fun btn(t: String, click: () -> Unit) = Button(this).apply {
            text = t; textSize = 13f; isAllCaps = false; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            setBackgroundColor(Color.parseColor("#21262D")); minWidth = 0; minimumWidth = 0
            setPadding((10 * d).toInt(), 0, (10 * d).toInt(), 0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (40 * d).toInt()).apply { setMargins((3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt()) }
            setOnClickListener { click() }
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(btn("◀") { if (web.canGoBack()) web.goBack() else finish() })
        bar.addView(btn("📺 Channels") { js("__edOpenChannels(true)") })
        bar.addView(btn("🧪 Test") { stat.text = "⏳ Yoxlanılır..."; js("__edTest()") })
        btnRed = btn("🔴 Xarab") {
            redOnly = !redOnly
            btnRed.text = if (redOnly) "📋 Hamısı" else "🔴 Xarab"
            js("__edFilter(" + redOnly + ")")
        }
        bar.addView(btnRed)
        bar.addView(btn("💾 Save") { stat.text = "⏳ Save..."; js("__edSave()") })
        bar.addView(btn("✖") { finish() })
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setBackgroundColor(Color.parseColor("#161B22")); addView(bar) }
        stat = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt()); setBackgroundColor(Color.parseColor("#0D1117")); text = "Ottplayer edit açılır..." }
        web = WebView(this); web.setBackgroundColor(Color.BLACK)
        root.addView(hs, LinearLayout.LayoutParams(-1, -2))
        root.addView(stat, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; javaScriptCanOpenWindowsAutomatically = false; setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false }
        CookieManager.getInstance().setAcceptCookie(true)
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean {
                android.app.AlertDialog.Builder(this@OttEditActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r?.confirm() }
                    .setNegativeButton("Ləğv et") { _, _ -> r?.cancel() }.setOnCancelListener { r?.cancel() }.show(); return true
            }
            override fun onJsAlert(v: WebView?, u: String?, m: String?, r: JsResult?): Boolean { r?.confirm(); return true }
        }
        web.addJavascriptInterface(Bridge(), "OttEditBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = !OttLogin.host(r.url.host)
            override fun onPageFinished(v: WebView, url: String?) {
                super.onPageFinished(v, url)
                val h = try { android.net.Uri.parse(url ?: "").host } catch (e: Exception) { null }
                if (!OttLogin.host(h)) return
                v.evaluateJavascript("(function(){return !!document.querySelector('input[type=password]');})()") { r ->
                    if (r == "true") {                      // giriş ekranı: avtomatik doldur
                        stat.text = "🔑 Giriş edilir..."
                        v.evaluateJavascript(OttLogin.js(), null)
                    } else if (url == null || !url.contains("/playlist/edit/")) {
                        // giriş edildi, amma başqa səhifəyə düşdük: edit səhifəsinə keç (sonsuz dövrə girmə)
                        if (redirects++ < 3) v.loadUrl(EDIT) else stat.text = "⚠️ Edit səhifəsi açılmadı"
                    } else {
                        v.evaluateJavascript(SCRIPT, null)
                        stat.text = "📺 Channels açılır..."
                        v.evaluateJavascript("__edOpenChannels(false)", null)
                    }
                }
            }
        }
        web.loadUrl(EDIT)
    }

    private fun js(code: String) = web.evaluateJavascript("if(window.__edInit){" + code + "}else{OttEditBridge.msg('Səhifə hələ hazır deyil')}", null)

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (PlayerPanel.handleBack()) return; if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    override fun onDestroy() { try { web.destroy() } catch (e: Exception) { }; super.onDestroy() }

    inner class Bridge {
        @JavascriptInterface fun probe(url: String, id: Int) {
            pool.execute {
                Net.deviceOnline = Net.online(this@OttEditActivity)
                val r = try { Net.probe(url, "{}") } catch (e: Throwable) { "unknown" }
                val why = if (r == "dead") Net.reasonOf(url) else ""
                runOnUiThread { web.evaluateJavascript("__edRes($id," + JSONObject.quote(r) + "," + JSONObject.quote(why) + ")", null) }
            }
        }
        @JavascriptInterface fun counts(g: Int, r: Int, u: Int, total: Int) = runOnUiThread {
            stat.text = "🟢 $g   🔴 $r   🟡 $u   (cəmi $total)"
        }
        @JavascriptInterface fun msg(t: String) = runOnUiThread { stat.text = t; Toast.makeText(this@OttEditActivity, t, Toast.LENGTH_SHORT).show() }
        @JavascriptInterface fun play(url: String, name: String) = runOnUiThread {
            PlayQueue.items = listOf(QItem(name.ifEmpty { url }, url, "{}")); PlayQueue.index = 0
            PlayerPanel.open(this@OttEditActivity)
        }
    }

    /** Edit səhifəsinə yeridilən skript: kanal sətirlərini tapır, 🟢/🔴 nişanı qoyur, Channels və Save düymələrinə basır. */
    private val SCRIPT = """
(function(){
  if(window.__edInit) return; window.__edInit = true;
  var URL_RE = /^\s*(https?|rtmp|rtsp|udp):\/\/\S+\s*${'$'}/i;
  var ID = 0, items = {};
  function vis(e){ return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length); }
  function rowOf(e){ return e.closest('tr, li, [class*=channel], [class*=item], .uk-card') || (e.parentElement && e.parentElement.parentElement) || e; }
  function nameOf(e){
    var row = rowOf(e);
    var ins = [].slice.call(row.querySelectorAll('input[type=text], input:not([type])')).filter(function(x){ return x !== e && !URL_RE.test(x.value || '') && (x.value||'').trim(); });
    return ins.length ? ins[0].value.trim() : '';
  }
  function badge(e, it){
    if(it.badge && document.contains(it.badge)) return it.badge;
    var s = document.createElement('span');
    s.className = '__edb'; s.textContent = '🟡';
    s.style.cssText = 'margin:0 6px;font-size:18px;cursor:pointer;white-space:nowrap;vertical-align:middle';
    s.addEventListener('click', function(ev){ ev.stopPropagation(); ev.preventDefault(); try{ OttEditBridge.play(it.url, nameOf(e)); }catch(x){} }, true);
    var w = document.createElement('span'); w.className = '__edw';
    w.appendChild(s);
    var why = document.createElement('span'); why.className = '__edy'; why.style.cssText = 'color:#ff5252;font-size:12px;margin-right:6px';
    w.appendChild(why);
    e.insertAdjacentElement('afterend', w);
    it.badge = s; it.why = why;
    return s;
  }
  window.__edScan = function(){
    var out = [];
    var fields = [].slice.call(document.querySelectorAll('input, textarea')).filter(function(e){ return URL_RE.test(e.value || '') && vis(e); });
    var leafs = [].slice.call(document.querySelectorAll('td, span, div, a, p')).filter(function(e){
      return e.children.length === 0 && !e.classList.contains('__edb') && !e.classList.contains('__edy') && URL_RE.test(e.textContent || '') && vis(e);
    });
    fields.concat(leafs).forEach(function(e){
      var it = e.__ed;
      var u = ((e.value !== undefined && (e.tagName === 'INPUT' || e.tagName === 'TEXTAREA')) ? e.value : e.textContent).trim();
      if(!it){ it = e.__ed = { id: ++ID, el: e, url: u, st: 'pending' }; items[it.id] = it; }
      else if(it.url !== u){ it.url = u; it.st = 'pending'; }
      badge(e, it);
      out.push({ id: it.id, url: it.url });
    });
    return out;
  };
  function counts(){
    var g = 0, r = 0, u = 0, t = 0;
    Object.keys(items).forEach(function(k){ var it = items[k]; if(!it.el || !document.contains(it.el)) return; t++; if(it.st === 'ok') g++; else if(it.st === 'dead') r++; else u++; });
    try { OttEditBridge.counts(g, r, u, t); } catch(e){}
  }
  window.__edTest = function(){
    var list = window.__edScan();
    if(!list.length){ try{ OttEditBridge.msg('Kanal linki tapılmadı — əvvəlcə "Channels" bölməsini açın'); }catch(e){} return; }
    list.forEach(function(x){ var it = items[x.id]; it.st = 'pending'; if(it.badge) it.badge.textContent = '🟡'; if(it.why) it.why.textContent = ''; });
    counts();
    list.forEach(function(x){ try { OttEditBridge.probe(x.url, x.id); } catch(e){} });
  };
  window.__edRes = function(id, st, why){
    var it = items[id]; if(!it) return;
    it.st = st;
    if(it.badge) it.badge.textContent = st === 'ok' ? '🟢' : (st === 'dead' ? '🔴' : '🟡');
    if(it.why) it.why.textContent = (st === 'dead' && why) ? '(' + why + ')' : '';
    counts();
  };
  window.__edFilter = function(redOnly){
    window.__edScan();
    Object.keys(items).forEach(function(k){
      var it = items[k]; if(!it.el || !document.contains(it.el)) return;
      var row = rowOf(it.el);
      row.style.display = (redOnly && it.st !== 'dead') ? 'none' : '';
    });
  };
  function txt(e){ return ((e.innerText || e.value || e.textContent || '') + '').trim(); }
  var chOpened = false;
  window.__edOpenChannels = function(manual){
    var tries = 0;
    var t = setInterval(function(){
      tries++;
      var c = [].slice.call(document.querySelectorAll('a, button, li, span, div[role=tab], [role=button], input[type=button]')).filter(function(e){ return vis(e) && /^channels?$/i.test(txt(e)); });
      // ən içdəki (yarpaq) uyğun element, tercihən a/button
      var pick = c.filter(function(e){ return /^(a|button|input)$/i.test(e.tagName); })[0] || c[c.length - 1];
      if(pick){
        clearInterval(t);
        if(chOpened && !manual) return;
        chOpened = true;
        ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(n){ try{ pick.dispatchEvent(new MouseEvent(n, {bubbles:true, cancelable:true, view:window})); }catch(e){} });
        try { pick.click(); } catch(e){}
        setTimeout(function(){ var n = window.__edScan().length; try{ OttEditBridge.msg('📺 Channels açıldı: ' + n + ' link tapıldı — 🧪 Test düyməsinə basın'); }catch(e){} }, 1500);
      } else if(tries > 40){
        clearInterval(t);
        try{ OttEditBridge.msg('"Channels" düyməsi tapılmadı — əl ilə basın'); }catch(e){}
      }
    }, 500);
  };
  window.__edSave = function(){
    var c = [].slice.call(document.querySelectorAll('button, input[type=submit], input[type=button], a, [role=button]')).filter(function(e){ return vis(e) && /^save$/i.test(txt(e)); });
    var pick = c[0];
    if(!pick){ try{ OttEditBridge.msg('❌ Saytda "Save" düyməsi tapılmadı'); }catch(e){} return; }
    ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(n){ try{ pick.dispatchEvent(new MouseEvent(n, {bubbles:true, cancelable:true, view:window})); }catch(e){} });
    try { pick.click(); } catch(e){}
    var done = false, t0 = Date.now();
    var w = setInterval(function(){
      var body = ''; try { body = document.body.innerText || ''; } catch(e){}
      if(/saved|playlist\s*updat|успешно|сохранен/i.test(body)){ done = true; clearInterval(w); try{ OttEditBridge.msg('✅ Save edildi (Ottplayer təsdiq etdi)'); }catch(e){} }
      else if(Date.now() - t0 > 20000){ clearInterval(w); try{ OttEditBridge.msg('⚠️ Save basıldı, amma təsdiq bildirişi gəlmədi'); }catch(e){} }
    }, 300);
  };
})();
"""
}
