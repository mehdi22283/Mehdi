# Mehdi KeyMapper — Xiaomi TV Box 2 (Android TV)

Bu layihə Xiaomi TV Box 2 və bütün Android TV / Android cihazlarında pult düymələrini gecikməsiz (low latency) əvəzləmək, xüsusi funksiyalar (Long press tətbiq açma, tətbiq bağlama) icra etmək və arxa planda dayanmadan işləmək üçün hazırlanmışdır.

---

## 🚀 Əsas Xüsusiyyətlər
1. **Daimi Arxa Plan Servisi (Foreground Service)**:
   - Sistem bildirişi ilə arxa planda həmişə aktiv qalır, sistem tərəfindən öldürülmür (`START_STICKY`).
2. **Boot Auto-Start**:
   - TV hər dəfə elektrikə taxıldıqda və ya restart olduqda (`BOOT_COMPLETED`), xidmət və ADB şəbəkə bağlantısı avtomatik işə düşür.
3. **ADB İcazələri və Əlçatımlılıq Menyusuz Aktivləşmə**:
   - `192.168.31.220:5555` IP ünvanına avtomatik bağlanır.
   - Background standby limitləri söndürülür.
   - Accessibility Service menyuya girmədən avtomatik aktiv olunur.
4. **Əvvəlcədən Təyin Olunmuş Düymə Qaydaları**:
   - `KEYCODE_BUTTON_6` (204) → `KEYCODE_DPAD_LEFT` (21)
   - `KEYCODE_BUTTON_5` (203) → `KEYCODE_DPAD_CENTER` (23 - Select/OK)
   - `KEYCODE_BUTTON_7` (205) → `KEYCODE_DPAD_RIGHT` (22)
   - **Long Press `KEYCODE_BUTTON_5`** → `es.ottplayer.tv` tətbiqini açır.
   - **Long Press `KEYCODE_HOME`** → Cari aktiv tətbiqi məcburi bağlayır (`force-stop`).
5. **İnteraktiv İdarəetmə Paneli**:
   - Tətbiqin içində yeni düymə əvəzləmələri əlavə etmək, redaktə etmək, silmək və ADB statusuna baxacaq UI interfeysi.

---

## 🛠 Şəbəkə & İlk Qurulum ADB Komandaları (Manual)

Əgər kompyuterdən TV-yə ilk dəfə icazə vermək istəyirsinizsə:

```bash
# 1. TV-yə bağlanın
adb connect 192.168.31.220:5555

# 2. Arxa plan limitlərini söndürün
adb shell settings put global app_standby_enabled 0
adb shell cmd appops set com.mehdi.keymapper RUN_IN_BACKGROUND allow
adb shell cmd appops set com.mehdi.keymapper RUN_ANY_IN_BACKGROUND allow

# 3. Əlçatımlılıq xidmətini aktivləşdirin
adb shell settings put secure enabled_accessibility_services com.mehdi.keymapper/.KeyMapperAccessibilityService
adb shell settings put secure accessibility_enabled 1
```

---

## 📦 Layihəni Yığmaq (Build)
1. Android Studio-da layihəni açın.
2. `Build > Build APK(s)` seçin.
3. APK-nı Xiaomi TV Box 2-yə daxil edin və ya `adb install app-release.apk` əmri ilə yükləyin.
