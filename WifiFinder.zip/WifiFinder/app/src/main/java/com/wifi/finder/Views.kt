package com.wifi.finder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class OverlayView(ctx: Context) : View(ctx) {
    var heading = 0f
    var rel = Float.NaN
    var ar = false
    var label = ""
    var ssid = ""

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.parseColor("#4DD0E1")
    }
    private val arrow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#FF5252")
    }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.WHITE
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 44f
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B0BEC5"); textAlign = Paint.Align.CENTER; textSize = 34f
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#9900E676")
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (ar) drawAr(c, w, h) else drawCompass(c, w, h)
    }

    private fun drawCompass(c: Canvas, w: Float, h: Float) {
        val cx = w / 2
        val cy = h / 2
        val r = min(w, h) * 0.42f
        c.drawCircle(cx, cy, r, ring)
        c.save()
        c.rotate(-heading, cx, cy)
        for (k in 0 until 36) {
            val len = if (k % 9 == 0) 30f else if (k % 3 == 0) 18f else 10f
            c.drawLine(cx, cy - r, cx, cy - r + len, ring)
            c.rotate(10f, cx, cy)
        }
        c.restore()
        val names = arrayOf("N", "E", "S", "W")
        for (i in 0 until 4) {
            val th = Math.toRadians((-heading + i * 90f).toDouble())
            val x = cx + (r - 62f) * sin(th).toFloat()
            val y = cy - (r - 62f) * cos(th).toFloat() + 14f
            val p = if (i == 0) arrow else white
            c.drawText(names[i], x - 12f, y, Paint(p).apply { textSize = 40f })
        }
        // fixed "forward" marker
        val tri = Path().apply {
            moveTo(cx, cy - r - 4f); lineTo(cx - 16f, cy - r - 34f); lineTo(cx + 16f, cy - r - 34f); close()
        }
        c.drawPath(tri, white)

        if (!rel.isNaN()) {
            c.save()
            c.rotate(rel, cx, cy)
            val a = Path().apply {
                moveTo(cx, cy - r * 0.8f)
                lineTo(cx - 48f, cy + r * 0.25f)
                lineTo(cx, cy + r * 0.1f)
                lineTo(cx + 48f, cy + r * 0.25f)
                close()
            }
            c.drawPath(a, arrow)
            c.restore()
        } else {
            c.drawText("Telefonla yavaş 360° dönün", cx, cy, small)
        }
        c.drawText(ssid, cx, cy + r + 60f, small)
    }

    private fun drawAr(c: Canvas, w: Float, h: Float) {
        val cx = w / 2
        val cy = h / 2
        c.drawLine(cx - 30f, cy, cx + 30f, cy, ring)
        c.drawLine(cx, cy - 30f, cx, cy + 30f, ring)
        if (rel.isNaN()) {
            c.drawText("Telefonu yavaş dönün...", cx, h * 0.2f, txt)
            return
        }
        val fov = 60f
        if (abs(rel) <= fov / 2) {
            val x = cx + rel / fov * w
            c.drawCircle(x, cy, 56f, mark)
            c.drawCircle(x, cy, 56f, ring)
            c.drawText(label, x, cy - 80f, txt)
            c.drawText(ssid, x, cy + 100f, small)
        } else {
            val left = rel < 0
            val x = if (left) 50f else w - 50f
            val dir = if (left) -1f else 1f
            val a = Path().apply {
                moveTo(x + dir * 30f, cy)
                lineTo(x - dir * 20f, cy - 45f)
                lineTo(x - dir * 20f, cy + 45f)
                close()
            }
            c.drawPath(a, arrow)
            c.drawText(label, cx, cy - 120f, txt)
            c.drawText(if (left) "◀ sola dönün" else "sağa dönün ▶", cx, cy - 70f, small)
        }
    }
}

class GraphView(ctx: Context) : View(ctx) {
    var data: List<Float> = emptyList()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.parseColor("#00E676")
    }
    private val grid = Paint().apply { color = Color.parseColor("#33FFFFFF"); strokeWidth = 1f }
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY; textSize = 24f }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(Color.parseColor("#101820"))
        for (v in intArrayOf(-40, -60, -80)) {
            val y = h - (v + 100f) / 70f * h
            c.drawLine(0f, y, w, y, grid)
            c.drawText("$v", 6f, y - 4f, t)
        }
        if (data.size < 2) return
        val p = Path()
        data.forEachIndexed { i, v ->
            val x = i.toFloat() / (data.size - 1) * w
            val y = (h - (v.coerceIn(-100f, -30f) + 100f) / 70f * h)
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        c.drawPath(p, line)
    }
}
