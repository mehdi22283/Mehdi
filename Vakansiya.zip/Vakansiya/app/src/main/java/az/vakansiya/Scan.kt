package az.vakansiya

import android.content.Context
import java.util.Calendar

/** Saytlardakı elanları sayan və "Xüsusi Vakansiya" açar sözlərini axtaran JS skriptləri (həm Counter, həm CheckWorker istifadə edir). */
object Scan {
    // ay adları: azərbaycanca, qısaltma, ingiliscə, rusca
    private val months = arrayOf(
        "yanvar|yan|january|jan|января",
        "fevral|fev|february|feb|февраля",
        "mart|mar|march|марта",
        "aprel|apr|april|апреля",
        "may|мая",
        "iyun|iyn|june|jun|июня",
        "iyul|iyl|july|jul|июля",
        "avqust|avq|august|aug|августа",
        "sentyabr|sen|september|sep|сентября",
        "oktyabr|okt|october|oct|октября",
        "noyabr|noy|november|nov|ноября",
        "dekabr|dek|december|dec|декабря"
    )
    private val end = "\$"
    private val nb = "(^|[^0-9])"
    private val na = "([^0-9]|$end)"

    private fun datePat(c: Calendar): String {
        val d = c.get(Calendar.DAY_OF_MONTH)
        val m = c.get(Calendar.MONTH) + 1
        val y = c.get(Calendar.YEAR)
        val yy = y % 100
        val mn = months[m - 1]
        return listOf(
            "${nb}0?$d[./-]0?$m[./-]($y|$yy)$na",
            "$y[./-]0?$m[./-]0?$d$na",
            "${nb}0?$d[ .]*($mn)",
            "($mn)[ .]*0?$d$na"
        ).joinToString("|")
    }

    private val tw = "bu gün|bugün|bu gun|bugun|bu gündən|bu gunden|bu günkü|bu gunku|today|сегодня|indicə|indice|az əvvəl|az evvel|saniyə əvvəl|saniye evvel|bir neçə dəqiqə|bir necə dəqiqə|just now"
    private val yw = "dünən|dunen|yesterday|вчера|${nb}(1|bir)[ ]*(gün|gun)[ ]*(əvvəl|evvel|öncə)|1 day ago"
    private val d3w = "${nb}(2|iki|two)[ ]*(gün|gun|days?|дня|дн)[a-zəöüçşğı.]*[ ]*(əvvəl|evvel|öncə|oncə|ago|назад)"
    private val hr = "([0-9]+|bir)[ ]*(saat|hour|hr|час)[a-zəöüçşğı.]*[ ]*(əvvəl|evvel|öncə|ago|назад)"
    private val mn = "([0-9]+|bir)[ ]*(dəq|dəqiqə|min|мин)[a-zəöüçşğı.]*[ ]*(əvvəl|evvel|öncə|ago|назад)"

    /** Ümumi (və "diqqətli" kart əsaslı) sayma skripti. */
    fun js(ctx: Context, careful: Boolean): String {
        val cal = Calendar.getInstance()
        val td = datePat(cal)
        cal.add(Calendar.DAY_OF_MONTH, -1)
        val yd = datePat(cal)
        cal.add(Calendar.DAY_OF_MONTH, -1)
        val wd = datePat(cal)
        return """(function(){
var L=JSON.parse(${Links.js(careful)});
var careful=$careful;
${Keywords.js(ctx)}
var TW=new RegExp("$tw"),YW=new RegExp("$yw"),D3=new RegExp("$d3w"),WD=new RegExp("$wd"),TD=new RegExp("$td"),YD=new RegExp("$yd"),HR=new RegExp("$hr"),MN=new RegExp("$mn");
var DL=/(son tarix|son müraciət tarixi|son müraciət|son gün|deadline|bitmə tarixi|bitmə|bitir|bitər|bitəcək|başa çatır|müraciət müddəti|expires|expire|valid until|until)[: ]*[0-9]{1,2}[ .\/-]+[a-zəıöüçşğ0-9]+([ .\/-]+[0-9]{2,4})?/g;
var DL2=/[0-9]{1,2}[ .\/-]+[a-zəıöüçşğ0-9]+([ .\/-]+[0-9]{2,4})?[a-zəı-]* ?(tarixinə |tarixədək )?(qədər|dək)/g;
var RG=/([0-9]{1,2}[.\/-][0-9]{1,2}[.\/-][0-9]{2,4}) ?[-–—] ?[0-9]{1,2}[.\/-][0-9]{1,2}[.\/-][0-9]{2,4}/g;
var LBL=/^(son tarix|son müraciət( tarixi)?|son gün|bitmə( tarixi)?|bitir|bitər|deadline|müraciət müddəti)[: ]*${'$'}/;
var MRX=/(^|[^0-9])([0-9]{1,2}) ?(yanvar|fevral|mart|aprel|may|iyun|iyul|avqust|sentyabr|oktyabr|noyabr|dekabr)[a-zəı]*[ .,]*([0-9]{4})?/g;
function ageYMD(y,m,d){var a=new Date(y,m-1,d),b=new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate());return Math.round((b-a)/86400000)}
/* mətndəki ən köhnə tarixin yaşı (gün): elan tarixi + bitmə tarixi birgə yazılıbsa, bitmə tarixi bu günə uyğun gəlib köhnə elanı saymasın */
function oldest(x){var mx=-9999,m,re1=/(^|[^0-9])([0-9]{1,2})[.\/-]([0-9]{1,2})[.\/-]([0-9]{4}|[0-9]{2})(?![0-9])/g,re2=/(^|[^0-9])([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})(?![0-9])/g,a;
 while((m=re1.exec(x))){var yy=parseInt(m[4]);if(yy<100)yy+=2000;a=ageYMD(yy,parseInt(m[3]),parseInt(m[2]));if(a>mx)mx=a}
 while((m=re2.exec(x))){a=ageYMD(parseInt(m[2]),parseInt(m[3]),parseInt(m[4]));if(a>mx)mx=a}
 var MS=['yanvar','fevral','mart','aprel','may','iyun','iyul','avqust','sentyabr','oktyabr','noyabr','dekabr'];
 while((m=MRX.exec(x))){var mo=MS.indexOf(m[3])+1,y2=m[4]?parseInt(m[4]):new Date().getFullYear();a=ageYMD(y2,mo,parseInt(m[2]));if(!m[4]&&a<-60)a=ageYMD(y2-1,mo,parseInt(m[2]));if(a>mx)mx=a}
 MRX.lastIndex=0;return mx}
var GL=location.hostname.indexOf('glorri')>=0,TM=/(^|[^0-9:.])([01]?[0-9]|2[0-3]):[0-5][0-9]([^0-9:]|$)/;
var HN=location.hostname,SCR=/glorri|work\.az|jobsearch|azvak|boss\.az|jobu|iseqebul/.test(HN),JU=HN.indexOf('jobu')>=0,IQ=HN.indexOf('iseqebul')>=0,JO=HN.indexOf('jooble')>=0,RS=[];
var DATEISH=/([0-9]{1,2})[ .\/-]+([a-zəıöüçşğ]{3,9}|[0-9]{1,2})[ .\/-]+[0-9]{2,4}|[0-9]+ ?(gün|saat|dəq|day|hour|min)|dünən|bu gün|bugün|today|yesterday/;
var now=new Date(),mins=now.getHours()*60+now.getMinutes();
function cls(x){x=x.toLowerCase().replace(/\u0307/g,'').replace(/\s+/g,' ').replace(RG,function(m,a){return a}).replace(DL,' ').replace(DL2,' ');
if(IQ){var qm=x.match(/([0-9]+) ?gün qal[ıi]b/);if(qm){var qa=30-parseInt(qm[1]);return qa==0?1:(qa==1?2:(qa==2?3:0))}}
if(YW.test(x))return 2;if(D3.test(x))return 3;if(TW.test(x))return 1;
var m=x.match(HR);if(m){var n=(m[1]=='bir')?1:parseInt(m[1]);return n*60>mins?2:1}
m=x.match(MN);if(m){var q=(m[1]=='bir')?1:parseInt(m[1]);return q>mins?2:1}
if(oldest(x)>2)return 0;if(TD.test(x))return 1;if(YD.test(x))return 2;if(WD.test(x))return 3;if(GL&&TM.test(x))return 1;return 0}
function lineCount(){RS=[];var lines=(document.body?document.body.innerText:'').split('\n'),t=0,y=0,w=0,p='';
for(var i=0;i<lines.length;i++){var l=lines[i].replace(/\s+/g,' ').trim().toLowerCase();if(l.length<3||l===p)continue;var p0=p;p=l;var r=cls(l);if(r>0&&LBL.test(p0))r=0;if(r>0||DATEISH.test(l))RS.push(r);if(r==1)t++;else if(r==2)y++;else if(r==3)w++}
return [t,y,w]}
function isoL(v){v=(v||'').trim();if(!/^[0-9]{4}-[0-9]{2}-[0-9]{2}/.test(v))return v;var d=new Date(v);if(isNaN(d.getTime()))return v;return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()}
function dattr(el){var s='';try{var q=el.querySelectorAll('time,[datetime],[data-date],[data-created],[data-time],[data-posted]');
 for(var i=0;i<q.length&&i<8;i++){var e=q[i],v=e.getAttribute('datetime')||e.getAttribute('data-date')||e.getAttribute('data-created')||e.getAttribute('data-time')||e.getAttribute('data-posted')||'';if(v)s+=' '+isoL(v)}}catch(e){}return s}
function dayDiff(v){var d=new Date(v);if(isNaN(d.getTime()))return -1;var a=new Date(d.getFullYear(),d.getMonth(),d.getDate()),b=new Date(now.getFullYear(),now.getMonth(),now.getDate());return Math.round((b-a)/86400000)}
function jsonCount(){RS=[];
 var found=[],seenT={};
 function add(t,v,u){if(!t||!v||typeof t!='string')return;var dd=dayDiff(v);if(dd<0)return;t=t.replace(/\s+/g,' ').trim();if(t.length<3||seenT[t+'|'+v])return;seenT[t+'|'+v]=1;found.push({t:t,d:dd,u:u||''})}
 function walk(o,dep){if(!o||dep>14)return;
  if(Array.isArray(o)){for(var i=0;i<o.length&&i<600;i++)walk(o[i],dep+1);return}
  if(typeof o!='object')return;
  var t=o.title||o.name||o.position||o.vacancy_title||o.job_title||o.jobTitle,v=o.datePosted||o.created_at||o.createdAt||o.created||o.posted_at||o.postedAt||o.published_at||o.publishedAt||o.start_date||o.startDate||o.date||o.publish_date,u=o.url||o.link||o.href||'';
  if(typeof t=='string'&&typeof v=='string'&&/^[0-9]{4}-[0-9]{2}-[0-9]{2}/.test(v))add(t,v,(typeof u=='string')?u:'');
  for(var k in o){if(o.hasOwnProperty(k)&&o[k]&&typeof o[k]=='object')walk(o[k],dep+1)}}
 var sc=document.querySelectorAll('script[type="application/ld+json"],script#__NEXT_DATA__,script[type="application/json"]');
 for(var i=0;i<sc.length;i++){try{walk(JSON.parse(sc[i].textContent),0)}catch(e){}}
 if(found.length<3)return null;
 var an=document.querySelectorAll('a[href]'),t=0,y=0,w=0;
 for(var i=0;i<found.length;i++){var f=found[i],h=f.u;
  if(!h||h.indexOf('http')!=0){h='';var ft=fold(f.t);
   for(var j=0;j<an.length;j++){var at=fold(an[j].innerText||'');if(at.length>3&&at.indexOf(ft)>=0&&an[j].href.indexOf('http')==0){h=an[j].href;break}}
   if(!h)h=(f.u&&f.u.charAt(0)=='/')?location.origin+f.u:location.href}
  if(f.d==0)t++;else if(f.d==1)y++;else if(f.d==2)w++;RS.push(f.d==0?1:(f.d==1?2:(f.d==2?3:0)));
  if(f.d==0||f.d==1||f.d==2)S.push({n:f.t.substring(0,140),h:h,d:f.d,k:kindOf(f.t)})}
 return [t,y,found.length,w]}
var GLS=0;
function ageOf(lw){var b=new Date(now.getFullYear(),now.getMonth(),now.getDate()),m;
 if(/^(dünən|dunen)/.test(lw))return 1;
 if(/^(bu gün|bugün)/.test(lw)||/^([01]?[0-9]|2[0-3]):[0-5][0-9]( |$)/.test(lw)||/^[0-9]+ (saat|dəq)/.test(lw))return 0;
 m=lw.match(/^([0-9]+) gün/);if(m)return parseInt(m[1]);
 m=lw.match(/^([0-9]{1,2})[-.\/]([0-9]{1,2})[-.\/]([0-9]{2,4})/);
 if(m){var yr=parseInt(m[3]);if(yr<100)yr+=2000;return Math.round((b-new Date(yr,parseInt(m[2])-1,parseInt(m[1])))/86400000)}
 return -1}
function glorriScan(){
 var Z=[],R=(document.body?document.body.innerText:'').split('\n');
 for(var i=0;i<R.length;i++){var z=R[i].replace(/\s+/g,' ').trim();if(z)Z.push(z)}
 var DRX=/^[0-9]{1,2}[-.\/][0-9]{1,2}[-.\/][0-9]{2,4}( |$)/,RX=/^(bu gün|bugün|dünən|dunen|[0-9]+ (saat|gün|dəq)[a-zəı]* əvvəl)/,TX=/^([01]?[0-9]|2[0-3]):[0-5][0-9]( |$)/;
 var st=0,RES=/[0-9]+ ?\/ ?[0-9]+/,q0=0;
 for(var q=0;q<Z.length;q++){if(/^esas vakansiya/.test(fold(Z[q]))){q0=q;break}}
 for(var q=q0;q<Z.length;q++){var fz=fold(Z[q]);if(Z[q].length<60&&RES.test(fz)&&(fz.indexOf('netic')>=0||/^[0-9]+ ?\/ ?[0-9]+$/.test(fz))){st=q+1;break}}
 var t=0,y=0,w=0,n=0,seen={},seenNew=false,oldAfter=0,an=document.querySelectorAll('a[href]');
 for(var i=st+2;i<Z.length;i++){var l=Z[i],lw=l.toLowerCase();
  if(l.length>40)continue;
  if(!(DRX.test(lw)||RX.test(lw)||TX.test(lw)))continue;
  var title=Z[i-2];if(/^pro$/i.test(title)&&i-3>=st)title=Z[i-3];
  var comp=Z[i-1];
  if(!title||title.length<3||title.length>200||DRX.test(title.toLowerCase()))continue;
  var key=title+'|'+comp;if(seen[key])continue;seen[key]=1;n++;
  var r=cls(lw),h='',ft=fold(title);
  for(var j=0;j<an.length;j++){var at=fold(an[j].innerText||'');if(at.length>0&&at.length<ft.length+250&&at.indexOf(ft)>=0&&an[j].href.indexOf('http')==0){h=an[j].href.split('#')[0];break}}
  if(!h)h=location.href.split('#')[0]+'#g'+n;
  if(L.indexOf(h)<0)L.push(h);
  var ag=ageOf(lw);if(ag>=0&&ag<=2)seenNew=true;else if(ag>2&&seenNew)oldAfter++;
  if(r>0){if(r==1)t++;else if(r==2)y++;else w++;S.push({n:title.substring(0,140),h:h,d:(r==1?0:(r==2?1:2)),k:kindOf(title)})}}
 if(oldAfter<2){try{var se=document.scrollingElement||document.documentElement;window.scrollTo(0,se.scrollHeight);
  var al=document.querySelectorAll('div,main,section,ul');
  for(var k=0;k<al.length&&k<500;k++){var e2=al[k];if(e2.clientHeight>100&&e2.scrollHeight>e2.clientHeight+80){var oy=getComputedStyle(e2).overflowY;if(oy=='auto'||oy=='scroll')e2.scrollTop=e2.scrollHeight}}
  window.dispatchEvent(new Event('scroll'));
  var bs=document.querySelectorAll('button,[role=button]');
  for(var k=0;k<bs.length;k++){var tx=fold(bs[k].innerText||'');if(tx.length<30&&/^(daha cox( goster| yukle)?|load more|show more|more)$/.test(tx)){bs[k].click();break}}}catch(e){}}
 GLS=n>=3?(oldAfter>=2?2:1):0;
 return n>=3?[t,y,n,w]:null}
function cardCount(){RS=[];
var A=[],hs=document.querySelectorAll('h1 a[href],h2 a[href],h3 a[href],h4 a[href]');
for(var i=0;i<hs.length;i++){if(hs[i].innerText.trim().length>3&&hs[i].href.indexOf('http')==0)A.push(hs[i])}
if(A.length<3){
 for(var pass=0;pass<2&&A.length<3;pass++){A=[];var all=document.querySelectorAll('a[href]'),sig={},c=[];
  for(var i=0;i<all.length;i++){var a=all[i],u;try{u=new URL(a.href)}catch(e){continue}
   if(u.origin!==location.origin)continue;var seg=u.pathname.split('/').filter(Boolean);
   if(seg.length<1)continue;if(pass==0?!/[0-9]{3,}/.test(u.pathname):seg.length<2)continue;
   if(a.innerText.trim().length<4)continue;sig[seg[0]]=(sig[seg[0]]||0)+1;c.push([seg[0],a])}
  var best='',bn=0;for(var k in sig){if(sig[k]>bn){bn=sig[k];best=k}}
  for(var i=0;i<c.length;i++){if(c[i][0]===best)A.push(c[i][1])}}}
var JSX=HN.indexOf('jobsearch')>=0,ONST=location.pathname.indexOf('internship')>=0,STJ=/staj|intern|təcrübə proq|təcrübəçi|stajyor|стаж/,ANYI=false;
if(JSX&&ONST){for(var q=0;q<A.length;q++){if(/internship/.test(A[q].pathname)){ANYI=true;break}}}
var seen={},t=0,y=0,w=0,n=0;
function dh(el){var d={},m=0;for(var i=0;i<A.length;i++){if(el.contains(A[i])&&!d[A[i].href]){d[A[i].href]=1;m++}}return m}
for(var i=0;i<A.length;i++){var h=A[i].href;if(seen[h])continue;seen[h]=1;
 if(JSX){var pth=A[i].pathname.toLowerCase(),isInt=/internship/.test(pth);
  if(ONST&&ANYI&&!isInt)continue}
 n++;
 var el=A[i],card=A[i];
 for(var k=0;k<8&&el.parentElement&&el.parentElement!==document.body;k++){el=el.parentElement;if(dh(el)>1)break;card=el}
 var r=cls((card.innerText||'')+' '+dattr(card));RS.push(r);if(r>0){if(r==1)t++;else if(r==2)y++;else w++;var tt=titleOf(A[i],card);S.push({n:tt,h:h,d:(r==1?0:(r==2?1:2)),k:kindOf(tt)})}}
return [t,y,n,w]}
/* Aşağı sürüşdürən saytlar (Glorri qaydası): 0 = elan azdır, 1 = daha yükləmək lazımdır, 2 = köhnə elanlara çatdıq */
function scrollState(){var n=RS.length;if(n<3)return 0;var tail=0;for(var i=n-1;i>=0&&RS[i]==0;i--)tail++;return tail>=(IQ?6:3)?2:1}
function moreLoad(){try{if(IQ){var ja=document.querySelectorAll('a[href*="/job/"]');if(ja.length)ja[ja.length-1].scrollIntoView({block:'end'});
 var ye=document.querySelectorAll('div,span,p,button'),ys=null;for(var k=0;k<ye.length&&k<4000;k++){var e3=ye[k];if(e3.children.length>1)continue;var t3=fold(e3.textContent||'');if(t3.length<25&&t3.indexOf('yuklen')==0){ys=e3}}
 if(ys){ys.scrollIntoView({block:'center'});try{ys.click()}catch(e){}}}
 var se=document.scrollingElement||document.documentElement;window.scrollTo(0,se.scrollHeight);
 var al=document.querySelectorAll('div,main,section,ul');
 for(var k=0;k<al.length&&k<500;k++){var e2=al[k];if(e2.clientHeight>100&&e2.scrollHeight>e2.clientHeight+80){var oy=getComputedStyle(e2).overflowY;if(oy=='auto'||oy=='scroll')e2.scrollTop=e2.scrollHeight}}
 window.dispatchEvent(new Event('scroll'));
 var bs=document.querySelectorAll('button,[role=button],a,span,div,li');
 for(var k=0;k<bs.length&&k<4000;k++){var e=bs[k];if(e.children.length>2)continue;var tx=fold(e.textContent||'');
  if(tx.length>=30||!/^(daha cox( goster| yukle)?|load more|show more|more)$/.test(tx))continue;
  if(e.tagName=='A'){var hr=e.getAttribute('href')||'';if(hr&&hr!='#'&&hr.indexOf('javascript')!=0)continue}
  if(e.disabled)continue;var rc=e.getBoundingClientRect();if(rc.width==0&&rc.height==0)continue;
  e.click();break}}catch(e){}}
/* Jobu.az: "N Nəticədən 1 – 24 aralığı göstərilir" yazısından AŞAĞIdakı kartlar oxunur (tarix sətrindən kart tapılır) */
function jobuScan(){
 var RS0=RS;RS=[];
 var mk=null,all=document.querySelectorAll('*'),best=1e9;
 for(var i=0;i<all.length;i++){var e=all[i];if(e.children.length>6)continue;var tc=(e.textContent||'');if(tc.length>120)continue;var f=fold(tc);
  if(f.indexOf('neticeden')>=0&&f.indexOf('araligi')>=0&&tc.length<best){best=tc.length;mk=e}}
 if(JO)mk=null;
 if(!mk&&!JO){RS=RS0;return null}
 var tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null,false),nd,dl=[],lastEl=null;
 while((nd=tw.nextNode())){
  var pe=nd.parentElement;if(!pe||(mk&&(mk.contains(pe)||!(mk.compareDocumentPosition(pe)&4))))continue;
  var tx=(nd.nodeValue||'').replace(/\s+/g,' ').trim();
  if(tx.length<4||tx.length>40)continue;
  var lw=tx.toLowerCase();
  if(cls(lw)>0||DATEISH.test(lw)){if(pe!==lastEl){dl.push({e:pe,t:tx});lastEl=pe}}}
 var t=0,y=0,w=0,n=0,hits=[],seen={};
 for(var i=0;i<dl.length;i++){
  var card=dl[i].e;
  for(var k=0;k<10&&card.parentElement&&card.parentElement!==document.body;k++){
   var p=card.parentElement,multi=false;
   for(var j=0;j<dl.length;j++){if(j!=i&&p.contains(dl[j].e)){multi=true;break}}
   if(multi||((p.innerText||'').length>700))break;
   card=p}
  var lines=lns(card),title='',hh=null;
  try{hh=card.querySelector('h1,h2,h3,h4,h5,h6')}catch(e){}
  if(hh&&(hh.innerText||'').trim().length>2)title=hh.innerText.trim().split('\n')[0].trim();
  if(!title){for(var q=0;q<lines.length;q++){var z=lines[q];if(z.length<3||isSal(z)||DATEISH.test(z.toLowerCase())||/^(vip|premium|yeni|new|pro|top)$/i.test(z))continue;title=z;break}}
  if(!title)continue;
  if(JO&&/jooble|is elanlari ve vakansiyalar/.test(fold(title)))continue;
  var a=null,ft=fold(title),as=card.querySelectorAll('a[href]');
  for(var j=0;j<as.length;j++){if(as[j].href.indexOf('http')!=0)continue;if(fold(as[j].innerText||'').indexOf(ft)>=0){a=as[j];break}}
  if(!a){for(var j=0;j<as.length;j++){if(as[j].href.indexOf(location.origin)==0){a=as[j];break}}}
  if(!a&&card.closest){a=card.closest('a[href]')}
  var h=a?a.href.split('#')[0]:'';
  if(!h)h=location.href.split('#')[0]+'#j'+(i+1);
  var key=h+'|'+title;if(seen[key])continue;seen[key]=1;n++;
  if(L.indexOf(h)<0)L.push(h);
  var r=cls(dl[i].t.toLowerCase());RS.push(r);
  if(r>0){if(r==1)t++;else if(r==2)y++;else w++;hits.push({n:title.substring(0,140),h:h,d:(r==1?0:(r==2?1:2)),k:kindOf(title)})}}
 if(n<3){RS=RS0;return null}
 return {r:[t,y,n,w],h:hits}}
/* İşəqəbul: kartlar /job/kateqoriya/elan/ linkləridir; \"N gün qalıb\" yazısı elanın yaşını göstərir (30 = bu gün, 29 = dünən, 28 = 2 gün əvvəl) */
function iqScan(){RS=[];
 var as=document.querySelectorAll('a[href]'),seen={},t=0,y=0,w=0,n=0;
 for(var i=0;i<as.length;i++){var u;try{u=new URL(as[i].href)}catch(e){continue}
  if(u.origin!==location.origin||!/^\/job\/[^\/]+\/[^\/]+\/?${'$'}/.test(u.pathname))continue;
  var h=u.origin+u.pathname;if(seen[h])continue;
  var card=as[i].closest('tr')||as[i].closest('article,li');
  if(!card){card=as[i];for(var k=0;k<6&&card.parentElement&&card.parentElement!==document.body;k++){card=card.parentElement;if(/gün qal[ıi]b/i.test(card.innerText||''))break}}
  var tx=(card.innerText||'').replace(/\u0307/g,'');
  if(!/gün qal[ıi]b/i.test(tx))continue;
  seen[h]=1;n++;
  var r=cls(tx.toLowerCase().replace(/\s+/g,' '));RS.push(r);
  if(L.indexOf(h)<0)L.push(h);
  if(r>0){var title='',BG=/^(vip|yen[iİIı]|new|ətraflı)${'$'}/i,hh=null;
   try{hh=card.querySelector('h1,h2,h3,h4,h5,h6')}catch(e){}
   if(hh&&(hh.innerText||'').trim().length>3)title=hh.innerText.replace(/\s+/g,' ').trim();
   if(!title){var ls=tx.split(/[\n\t]|\s{2,}/);
    for(var q=0;q<ls.length;q++){var z=ls[q].replace(/\s+/g,' ').trim();if(z.length<4||BG.test(z)||/gün qal[ıi]b/i.test(z)||/₼|azn/i.test(z))continue;title=z;break}}
   title=title.replace(/^(vip|yen[iİIı]|new) /i,'');
   if(!title)title=(as[i].innerText||'').trim()||h;
   if(r==1)t++;else if(r==2)y++;else w++;
   S.push({n:title.substring(0,140),h:h,d:(r==1?0:(r==2?1:2)),k:kindOf(title)})}}
 return n>=3?[t,y,n,w]:null}
/* Elan linki kimi görünən link (adi menyu linklərini sayma): yolda 3+ rəqəm və ya 2+ hissə, səhifənin özü deyil */
function postLike(a){var u;try{u=new URL(a.href)}catch(e){return false}
 if(u.origin!==location.origin||u.pathname.length<2||u.pathname===location.pathname)return false;
 if((a.innerText||'').trim().length<4)return false;
 return /[0-9]{3,}/.test(u.pathname)||u.pathname.split('/').filter(Boolean).length>=2}
function postCount(){var as=document.querySelectorAll('a[href]'),sg={},n=0;for(var i=0;i<as.length;i++){if(postLike(as[i])){var h=as[i].href.split('#')[0];if(!sg[h]){sg[h]=1;n++}}}return n}
/* Tarix yazan mətn qovşağından elan kartını və linkini tapır: tarixi olub kartı/linki olmayan yazılar (məs. "bu gün: 2 yeni elan" başlığı) sayılmır */
function lineMap(){var out=[],seen={},tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null,false),nd;
 while((nd=tw.nextNode())){var tx=(nd.nodeValue||'').replace(/\s+/g,' ').trim();if(tx.length<3||tx.length>60)continue;
  var r=cls(tx.toLowerCase());if(r<=0)continue;
  var el=nd.parentElement,a=null,card=null;
  for(var k=0;k<8&&el&&el!==document.body;k++){
   var as=el.querySelectorAll('a[href]'),hs={},nh=0,first=null;
   for(var j=0;j<as.length;j++){if(!postLike(as[j]))continue;var hh=as[j].href.split('#')[0];if(!hs[hh]){hs[hh]=1;nh++;if(!first)first=as[j]}}
   if(nh>=1){if(nh==1&&(el.innerText||'').length<=700){a=first;card=el}break}
   el=el.parentElement}
  if(!a)continue;
  var h=a.href.split('#')[0];if(seen[h])continue;seen[h]=1;
  var tt=titleOf(a,card);if(!tt||tt.length<3)continue;
  out.push({n:tt,h:h,r:r,k:kindOf(tt)})}
 return out}
var res=null,cc=cardCount(),w=0;
if(GL){S.length=0;res=glorriScan();if(!res)S.length=0}
else if(IQ){S.length=0;res=iqScan();if(!res)S.length=0}
else if(JU||JO){try{var jr=jobuScan();if(jr){S.length=0;for(var ji=0;ji<jr.h.length;ji++)S.push(jr.h[ji]);res=jr.r}}catch(e){}}
if(!res&&careful){res=cc;if(res[2]<3||res[0]+res[1]+res[3]==0){S.length=0;res=jsonCount();if(!res)S.length=0}}
if(res){w=res[3]}else{res=lineCount();w=res[2];
 if(S.length==0&&(res[0]>0||res[1]>0||res[2]>0)){var lm=[];try{lm=lineMap()}catch(e){}
  if(lm.length>0){var t2=0,y2=0,w2=0;S.length=0;
   for(var li=0;li<lm.length;li++){var q=lm[li];if(L.indexOf(q.h)<0)L.push(q.h);if(q.r==1)t2++;else if(q.r==2)y2++;else w2++;S.push({n:q.n.substring(0,140),h:q.h,d:(q.r==1?0:(q.r==2?1:2)),k:q.k})}
   res=[t2,y2,w2];w=w2}
  else if(postCount()>=3){res=[0,0,0];w=0}}}
if(SCR&&!GL){GLS=scrollState();if(GLS==1)moreLoad()}
return JSON.stringify({t:res[0],y:res[1],w:w,l:L,s:S,g:GLS});})()"""
    }

    /**
     * JobSite.az: siyahıda yerləşdirmə tarixi yoxdur (yalnız "Son Tarix" - bitmə tarixi görünür).
     * Ona görə ən yeni elanların öz səhifələri açılır və "Yerləşdirilib ..." tarixi oxunur.
     */
    fun detailJs(ctx: Context, url: String): String {
        fun arr(c: Calendar) = "[${c.get(Calendar.DAY_OF_MONTH)},${c.get(Calendar.MONTH) + 1},${c.get(Calendar.YEAR)}]"
        val c1 = Calendar.getInstance()
        val c2 = Calendar.getInstance(); c2.add(Calendar.DAY_OF_MONTH, -1)
        val c3 = Calendar.getInstance(); c3.add(Calendar.DAY_OF_MONTH, -2)
        val staj = Store.stajFilter(url)
        return """(function(){
var L=JSON.parse(${Links.js(false)});
var T=${arr(c1)},Y=${arr(c2)},W=${arr(c3)};
var F=$staj;
${Keywords.js(ctx)}
var t0=Date.now(),DEADLINE=40000;
var MON=['yanvar','fevral','mart','aprel','may','iyun','iyul','avqust','sentyabr','oktyabr','noyabr','dekabr'];
function eq(d,m,y,Z){return d==Z[0]&&m==Z[1]&&y==Z[2]}
function norm(z){return z.replace(/\s+/g,' ').toLowerCase().replace(/\u0307/g,'').trim()}
var W='[^a-zəıöüçşğ]';
var TITLE=new RegExp('(^|'+W+')(staj|stajçı|stajyor|intern|internship)('+W+'|${'$'})|təcrübəçi|təcrübə proqram|təcrübə keçmə');
var HEAD=new RegExp('(^|'+W+')(stajçı|stajyor|internship)('+W+'|${'$'})|təcrübəçi|təcrübə proqram');
var DRE=/yerləşdirilib ([0-9]{1,2}) ([a-zəıöüçşğ]+) ([0-9]{4})/;
function idOf(u){var m=u.match(/-([0-9]+)${'$'}/);return m?parseInt(m[1]):0}
function abs(a){try{return new URL(a.getAttribute('href'),location.href).href.split('#')[0]}catch(e){return ''}}
function jobLinks(root){var out=[],a=root.querySelectorAll('a[href]');
 for(var i=0;i<a.length;i++){var h=abs(a[i]);if(h.indexOf('/vakansiya-is-elani/')<0||!/-[0-9]+${'$'}/.test(h))continue;out.push(h)}return out}
function pn(h){var m=h.match(/(?:[?&](?:page|p)=|\/page\/)([0-9]+)/);return m?parseInt(m[1]):0}
function pageLinks(root){var r=[],a=root.querySelectorAll('a[href]');
 for(var i=0;i<a.length;i++){var h=abs(a[i]);if(!h||h.indexOf(location.origin)!==0)continue;
  if(pn(h)>0&&r.indexOf(h)<0)r.push(h)}
 r.sort(function(x,y){return pn(x)-pn(y)});return r.slice(0,7)}
function get(h,n){return new Promise(function(res){var c=new AbortController(),tm=setTimeout(function(){c.abort()},10000);
 fetch(h,{credentials:'omit',signal:c.signal}).then(function(r){clearTimeout(tm);if(!r.ok)throw 0;return r.text()})
 .then(res,function(){clearTimeout(tm);if(n>0)res(get(h,n-1));else res(null)})})}
var all={},list=[];
function addLinks(a){a.forEach(function(h){if(!all[h]){all[h]=1;list.push(h)}})}
addLinks(jobLinks(document));
var keep=[],fetched=[],t=0,y=0,w=0,fails=[],fin=false;
function proc(h,html){
 fetched.push(h);
 var x=norm(html.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi,' ').replace(/<[^>]*>/g,' '));
 var hd=x.split(' təsvir ')[0];
 var m=hd.match(DRE)||x.match(DRE),isT=false,isY=false,isW=false;
 if(m){var dd=parseInt(m[1]),mo=MON.indexOf(m[2])+1,yr=parseInt(m[3]);isT=eq(dd,mo,yr,T);isY=!isT&&eq(dd,mo,yr,Y);isW=!isT&&!isY&&eq(dd,mo,yr,W)}
 if((isT||isY||isW)&&!F){var rt='';try{var d0=new DOMParser().parseFromString(html,'text/html');var e0=d0.querySelector('h1');rt=((e0&&e0.textContent)||d0.title||'').replace(/\s+/g,' ').trim()}catch(er){}S.push({n:rt,h:h,d:(isT?0:(isY?1:2)),k:kindOf(rt)})}
 if(F){var ttl='';try{var d=new DOMParser().parseFromString(html,'text/html');var e=d.querySelector('h1');ttl=norm((e&&e.textContent)||d.title||'')}catch(er){}
  var hw=hd.substring(Math.max(0,hd.length-450));
  if(!(TITLE.test(ttl)||HEAD.test(hw)))return isT||isY||isW}
 keep.push(h);
 if(isT)t++;else if(isY)y++;else if(isW)w++;
 return isT||isY||isW}
function send(){if(fin)return;fin=true;
 Bridge.done(JSON.stringify({t:t,y:y,w:w,l:F?keep:L.concat(list),s:S}))}
function retryFails(){
 if(!fails.length||Date.now()-t0>DEADLINE+8000)return send();
 var f=fails;fails=[];
 Promise.all(f.map(function(h){return get(h,2)})).then(function(arr){
  arr.forEach(function(html,k){if(html!==null)proc(f[k],html)});send()})}
function run(){
 list.sort(function(a,b){return idOf(b)-idOf(a)});list=list.slice(0,250);
 if(list.length==0)return;
 var i=0,quiet=0;
 function step(){
  if(i>=list.length||Date.now()-t0>DEADLINE||quiet>=2)return retryFails();
  var batch=list.slice(i,i+15);i+=15;
  Promise.all(batch.map(function(h){return get(h,2)})).then(function(arr){
   var hit=0;
   arr.forEach(function(html,k){if(html===null){fails.push(batch[k]);return}if(proc(batch[k],html))hit++});
   quiet=hit>0?0:quiet+1;step()})}
 step()}
var pls=pageLinks(document);
Promise.all(pls.map(function(h){return get(h,2).then(function(html){
 if(!html)return;try{addLinks(jobLinks(new DOMParser().parseFromString(html,'text/html')))}catch(e){}})})).then(run,run);
})()"""
    }

    /** Hansı skriptin işləyəcəyini seçir: Telegram kanalı və ya JobSite tipli (elanın öz səhifəsi). */
    fun detailScript(ctx: Context, url: String): String = if (Store.telegram(url)) tgJs(ctx) else detailJs(ctx, url)

    /**
     * Telegram kanalı (t.me/s/KANAL): hər paylaşımda 10 elan var, paylaşımın saatı məlum olur.
     * Elan ilk dəfə kanalda göründüyü gün "yerləşdirilib" sayılır (təkrar paylaşımlar köhnə günə yazılır).
     * Nəticə: ən yeni paylaşımdan köhnəyə doğru, saatla birlikdə sıralanır.
     */
    fun tgJs(ctx: Context): String = """(function(){
${Keywords.js(ctx)}
var t0=Date.now(),DEADLINE=40000,MAXP=16,posts={},fin=false;
var now=new Date(),b=new Date(now.getFullYear(),now.getMonth(),now.getDate());
function dd(ts){var d=new Date(ts),a=new Date(d.getFullYear(),d.getMonth(),d.getDate());return Math.round((b-a)/86400000)}
function p2(n){return n<10?'0'+n:''+n}
function parse(root){var ws=root.querySelectorAll('.tgme_widget_message'),minId=1e12;
 for(var i=0;i<ws.length;i++){var w=ws[i],dp=w.getAttribute('data-post')||'',id=parseInt(dp.split('/').pop()||'0');
  if(!id)continue;if(id<minId)minId=id;
  var te=w.querySelector('.tgme_widget_message_date time')||w.querySelector('time'),ts=te?Date.parse(te.getAttribute('datetime')):NaN,tx=w.querySelector('.tgme_widget_message_text');
  if(!tx||isNaN(ts))continue;
  var ads=[],last='',nodes=tx.childNodes;
  for(var j=0;j<nodes.length;j++){var nd=nodes[j];
   if(nd.nodeType==3){var v=(nd.nodeValue||'').replace(/\s+/g,' ').trim();if(v)last=v}
   else if(nd.nodeName=='A'){var h=nd.getAttribute('href')||'';if(h.indexOf('hrin.az/vakansiya/')>=0){ads.push({t:last,u:h.split('?')[0].split('#')[0]});last=''}}
   else if(nd.nodeName!='BR'){if(nd.querySelector&&nd.querySelector('a')){var aa=nd.querySelectorAll('a[href*="hrin.az/vakansiya/"]');for(var q=0;q<aa.length;q++){ads.push({t:last,u:aa[q].getAttribute('href').split('?')[0]});last=''}}
    else{var v3=(nd.textContent||'').replace(/\s+/g,' ').trim();if(v3)last=v3}}}
  posts[id]={id:id,ts:ts,ads:ads}}
 return minId}
function get(u){return new Promise(function(res){var c=new AbortController(),tm=setTimeout(function(){c.abort()},10000);
 fetch(u,{credentials:'omit',signal:c.signal}).then(function(r){clearTimeout(tm);if(!r.ok)throw 0;return r.text()}).then(res,function(){clearTimeout(tm);res(null)})})}
function send(){if(fin)return;fin=true;
 var ids=Object.keys(posts).map(Number).sort(function(a,b){return a-b});
 if(!ids.length)return;
 var best={},order=[];
 /* paylaşımın tarixinə görə: bu gün / dünən / 2 gün əvvəl paylaşılan postlardakı BÜTÜN elanlar; təkrar elan ən yeni postunun gününə yazılır */
 ids.forEach(function(id){var p=posts[id],d=dd(p.ts);if(d<0||d>2)return;
  p.ads.forEach(function(a){
   var n=parseInt(a.u.replace(/\/+${'$'}/,'').split('-').pop())||0,k=n||a.u,f=best[k];
   var ttl=a.t;if(!ttl){ttl=a.u.split('/').pop().replace(/-[0-9]+${'$'}/,'').replace(/-/g,' ')}
   if(!f){best[k]={t:ttl,u:a.u,ts:p.ts,n:n,d:d};order.push(k)}
   else if(p.ts>f.ts){f.ts=p.ts;f.d=d;if(a.t)f.t=a.t}})});
 var res=[];
 order.forEach(function(k){var f=best[k];res.push({f:f,d:f.d})});
 res.sort(function(x,y){return y.f.ts-x.f.ts});
 var t=0,y=0,w=0,S=[],L=[];
 res.forEach(function(r){var f=r.f,dt=new Date(f.ts);
  if(r.d==0)t++;else if(r.d==1)y++;else w++;
  L.push(f.u);
  S.push({n:(p2(dt.getHours())+':'+p2(dt.getMinutes())+' · '+f.t).substring(0,140),h:f.u,d:r.d,k:kindOf(f.t)})});
 Bridge.done(JSON.stringify({t:t,y:y,w:w,l:L,s:S}))}
function oldest(){var m=1e15;for(var k in posts){if(posts[k].ts<m)m=posts[k].ts}return m}
function more(minId,n){
 if(n>=MAXP||Date.now()-t0>DEADLINE||oldest()<b.getTime()-4*86400000)return send();
 get(location.pathname+'?before='+minId).then(function(html){
  if(!html)return send();
  var m=1e12;try{m=parse(new DOMParser().parseFromString(html,'text/html'))}catch(e){}
  if(!m||m>=minId)return send();more(m,n+1)})}
try{var m0=parse(document);if(m0>=1e12)return;more(m0,0)}catch(e){send()}
})()"""
}
