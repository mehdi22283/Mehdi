package com.zengyazici

import android.app.*
import android.content.*
import android.media.AudioManager
import android.os.*
import rikka.shizuku.Shizuku
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class CallWatcherService : Service() {

    companion object {
        @Volatile var status: String = "Dayandı"
        @Volatile var running = false
        fun dir(c: Context): File = File(c.getExternalFilesDir(null), "recordings").apply { mkdirs() }
    }

    private var rec: IRecorder? = null
    private var recording = false
    private val h = Handler(Looper.getMainLooper())
    private lateinit var am: AudioManager

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            rec = IRecorder.Stub.asInterface(b); status = "Hazırdır, zəng gözlənilir"
        }
        override fun onServiceDisconnected(n: ComponentName?) { rec = null; status = "Shizuku xidməti qopdu" }
    }

    private val tick = object : Runnable {
        override fun run() {
            val inCall = am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION
            if (inCall && !recording) startRec() else if (!inCall && recording) stopRec()
            h.postDelayed(this, 1000)
        }
    }

    private fun startRec() {
        val r = rec ?: return
        try {
            val f = File(dir(this), SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".wav")
            f.createNewFile(); f.setWritable(true, false)
            val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_WRITE)
            val res = r.start(pfd)
            pfd.close()
            recording = res.startsWith("OK")
            status = if (recording) "Yazılır ($res)" else res
        } catch (t: Throwable) { status = "XƏTA: ${t.message}" }
    }

    private fun stopRec() {
        try { rec?.stop() } catch (_: Throwable) {}
        recording = false; status = "Hazırdır, zəng gözlənilir"
    }

    override fun onCreate() {
        super.onCreate()
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Zəng yazısı", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "rec").setContentTitle("Zəng Yazıcı aktivdir")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n)
        running = true
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            val args = Shizuku.UserServiceArgs(ComponentName(packageName, RecorderUserService::class.java.name))
                .daemon(false).processNameSuffix("rec").version(1)
            Shizuku.bindUserService(args, conn)
            status = "Shizuku-ya qoşulur..."
        } else status = "Shizuku icazəsi yoxdur"
        h.post(tick)
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        stopRec(); running = false; status = "Dayandı"
        try { Shizuku.unbindUserService(Shizuku.UserServiceArgs(ComponentName(packageName, RecorderUserService::class.java.name)).processNameSuffix("rec").version(1), conn, true) } catch (_: Throwable) {}
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
