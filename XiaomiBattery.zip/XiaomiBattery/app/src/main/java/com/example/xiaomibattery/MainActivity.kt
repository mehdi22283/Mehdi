package com.example.xiaomibattery

import android.app.Activity
import android.content.*
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var big: TextView
    private lateinit var bar: ProgressBar
    private var maxT = -100f
    private var minT = 100f
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { update(it) }; h.postDelayed(this, 2000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((16*dp).toInt(), (40*dp).toInt(), (16*dp).toInt(), (16*dp).toInt()); setBackgroundColor(Color.parseColor("#121212")) }
        big = TextView(this).apply { textSize = 56f; setTextColor(Color.parseColor("#FF6900")); gravity = Gravity.CENTER }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        info = TextView(this).apply { textSize = 16f; setTextColor(Color.WHITE); setLineSpacing(8f, 1f); setPadding(0, (16*dp).toInt(), 0, (16*dp).toInt()) }
        root.addView(big); root.addView(bar)
        root.addView(ScrollView(this).apply { addView(info) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(btn("🔋 Batareya qənaəti (Xiaomi)") { open(arrayOf("com.miui.powerkeeper" to "com.miui.powerkeeper.ui.HiddenAppsConfigActivity")) })
        root.addView(btn("🚀 Avtomatik başlama (Autostart)") { open(arrayOf("com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity")) })
        root.addView(btn("⚙️ Batareya optimallaşdırması") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        root.addView(btn("📊 Sistem batareya istifadəsi") { startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) })
        setContentView(root)
    }

    private fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }

    private fun open(c: Array<Pair<String, String>>) {
        for ((p, cl) in c) try { startActivity(Intent().setComponent(ComponentName(p, cl))); return } catch (_: Exception) {}
        try { startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) } catch (_: Exception) { Toast.makeText(this, "Bu səhifə tapılmadı", Toast.LENGTH_SHORT).show() }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun update(i: Intent) {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val lvl = i.getIntExtra("level", 0); val sc = i.getIntExtra("scale", 100)
        val pct = lvl * 100 / sc
        val status = when (i.getIntExtra("status", 0)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Şarj olur ⚡"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Boşalır"
            BatteryManager.BATTERY_STATUS_FULL -> "Dolu ✅"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Şarj olmur"
            else -> "Naməlum" }
        val plug = when (i.getIntExtra("plugged", 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Adapter (AC)"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Simsiz"
            0 -> "Qoşulmayıb"
            else -> "Digər" }
        val health = when (i.getIntExtra("health", 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Yaxşı"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Həddən artıq isti 🔥"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Ölü"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Yüksək gərginlik"
            BatteryManager.BATTERY_HEALTH_COLD -> "Soyuq ❄️"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Xəta"
            else -> "Naməlum" }
        val temp = i.getIntExtra("temperature", 0) / 10f
        if (temp > maxT) maxT = temp; if (temp < minT) minT = temp
        val mv = i.getIntExtra("voltage", 0)
        val tech = i.getStringExtra("technology") ?: "-"
        val cycles = i.getIntExtra("android.os.extra.CYCLE_COUNT", -1)
        val cur = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val avg = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE)
        val cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        // Xiaomi bəzi modellərdə µA, bəzilərində mA verir
        fun toMa(v: Long) = if (abs(v) > 20000) v / 1000.0 else v.toDouble()
        val ma = toMa(cur)
        val watt = abs(ma) * mv / 1_000_000.0
        val capNow = if (cc > 0) (if (cc > 100000) cc / 1000 else cc) else -1
        val capFull = if (capNow > 0 && pct > 0) capNow * 100 / pct else -1
        val remain = if (Build.VERSION.SDK_INT >= 28) bm.computeChargeTimeRemaining() else -1L
        fun fmt(ms: Long) = "${ms / 3_600_000} saat ${(ms / 60_000) % 60} dəq"

        big.text = "$pct%"; bar.progress = pct
        info.text = buildString {
            appendLine("📱 Cihaz: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("🧩 Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
            appendLine("Vəziyyət: $status")
            appendLine("Mənbə: $plug")
            appendLine("Sağlamlıq: $health")
            appendLine("Temperatur: $temp °C  (min ${"%.1f".format(minT)} / max ${"%.1f".format(maxT)})")
            appendLine("Gərginlik: $mv mV")
            appendLine("Cərəyan (indi): ${"%.0f".format(ma)} mA")
            appendLine("Cərəyan (orta): ${"%.0f".format(toMa(avg))} mA")
            appendLine("Güc: ${"%.2f".format(watt)} W")
            if (capNow > 0) appendLine("Qalan yük: $capNow mAh")
            if (capFull > 0) appendLine("Təxmini tutum: $capFull mAh")
            if (remain > 0) appendLine("Dolmağa qalan: ${fmt(remain)}")
            if (cycles >= 0) appendLine("Şarj dövrü: $cycles")
            appendLine("Texnologiya: $tech")
            appendLine("\nQeyd: Xiaomi-də bəzi dəyərlər (cərəyan, dövr) modeldən asılıdır.")
        }
    }
}
