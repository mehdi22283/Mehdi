package az.wifiscan

import android.view.View
import android.widget.*
import org.json.JSONObject
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

class GeoPt(val lat: Double, val lon: Double, val label: String)

private fun role(h: String): String {
    val s = h.lowercase()
    return when {
        Regex("(^|[.-])(gw|gateway)\\d*").containsMatchIn(s) -> "Gateway"
        s.contains("core") || Regex("(^|[.-])cr\\d").containsMatchIn(s) -> "Core router (magistral)"
        s.contains("edge") || s.contains("border") || Regex("(^|[.-])(br|er)\\d").containsMatchIn(s) -> "Edge / Border router"
        Regex("(^|[.-])ix").containsMatchIn(s) || s.contains("peering") -> "IXP / peering nöqtəsi"
        s.contains("backbone") || Regex("(^|[.-])bb").containsMatchIn(s) -> "Backbone"
        s.contains("agg") || s.contains("dist") -> "Aqreqasiya / paylayıcı"
        s.contains("google") || s.contains("cloudflare") || s.contains("cdn") || s.contains("amazon") -> "Hədəf / CDN serveri"
        else -> "Router"
    }
}

private fun geoLookup(ip: String): JSONObject? = try {
    val q = if (ip.isEmpty()) "" else ip
    val c = URL("http://ip-api.com/json/$q?fields=status,country,countryCode,regionName,city,isp,org,as,lat,lon").openConnection() as HttpURLConnection
    c.connectTimeout = 3000; c.readTimeout = 3000
    val j = JSONObject(c.inputStream.bufferedReader().readText())
    if (j.optString("status") == "success") j else null
} catch (e: Exception) { null }

fun tracePage(u: Ui): Page {
    val p = u.vbox()
    p.addView(u.tv("Traceroute", 22f, u.ACC, true))
    val host = u.edit("Host / IP", "google.com"); p.addView(host)
    val head = u.tv("", 13f, u.SUB)
    val box = LinearLayout(u.act).apply { orientation = LinearLayout.VERTICAL }
    val sv = ScrollView(u.act).apply { addView(box) }
    val tracing = AtomicBoolean(false)
    val stop = AtomicBoolean(false)
    val proc = AtomicReference<Process?>(null)
    lateinit var btn: Button

    // ---- XƏRİTƏ ----
    val map = MapView(u.act)
    map.setTileSource(TileSourceFactory.MAPNIK)
    map.setMultiTouchControls(true)
    map.isTilesScaledToDpi = true
    map.overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERT_COLORS)
    map.controller.setZoom(2.5)
    map.controller.setCenter(GeoPoint(30.0, 20.0))
    val geoPts = ConcurrentHashMap<Int, GeoPt>()

    fun updateMap(zoom: Boolean) {
        map.overlays.clear()
        val keys = geoPts.keys.sorted()
        val pts = ArrayList<GeoPoint>()
        for (k in keys) { val g = geoPts[k] ?: continue; pts.add(GeoPoint(g.lat, g.lon)) }
        if (pts.size >= 2) {
            val line = Polyline(map)
            line.setPoints(pts)
            line.outlinePaint.color = u.ACC
            line.outlinePaint.strokeWidth = 7f
            map.overlays.add(line)
        }
        for (k in keys) {
            val g = geoPts[k] ?: continue
            val m = Marker(map)
            m.position = GeoPoint(g.lat, g.lon)
            m.title = if (k == 0) "Siz" else "Hop #$k"
            m.snippet = g.label
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            map.overlays.add(m)
        }
        map.invalidate()
        if (zoom && pts.isNotEmpty()) {
            map.post {
                try {
                    val lats = pts.map { it.latitude }; val lons = pts.map { it.longitude }
                    val span = maxOf(lats.max() - lats.min(), lons.max() - lons.min())
                    if (pts.size == 1 || span < 0.05) {
                        map.controller.setZoom(8.0); map.controller.setCenter(pts[0])
                    } else map.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, 100)
                } catch (e: Exception) {}
            }
        }
    }

    fun endTrace() { tracing.set(false); btn.text = "▶ Traceroute" }

    fun hopInfo(ip: String, ttl: Int, cc: MutableMap<Int, String>): String {
        val sb = StringBuilder()
        val rdns = try { val n = InetAddress.getByName(ip).canonicalHostName; if (n != ip) n else "" } catch (e: Exception) { "" }
        val dev = Store.devices[ip]
        if (Net.isPrivate(ip)) {
            when {
                ip == Store.gateway || (ttl == 1 && dev == null) ->
                    sb.append("🌐 Router / Gateway (sizin şəbəkənin çıxışı)" + (dev?.let { "\n   ${it.vendor} ${it.model}".trimEnd() } ?: ""))
                dev != null -> sb.append("🏠 Lokal cihaz: ${dev.type}\n   ${dev.vendor} ${dev.model}".trimEnd())
                ip.startsWith("100.") -> sb.append("🏢 Provayder daxili (CGNAT) cihazı")
                else -> sb.append("🏢 Provayderin daxili şəbəkə cihazı (private IP, xəritədə göstərilmir)")
            }
        } else {
            val j = geoLookup(ip)
            if (j != null) {
                cc[ttl] = j.optString("countryCode")
                sb.append("📍 ${j.optString("city")}, ${j.optString("regionName")}, ${j.optString("country")}\n")
                sb.append("🏢 ${j.optString("isp")} (${j.optString("org")})\n🔢 ${j.optString("as")}")
                geoPts[ttl] = GeoPt(j.optDouble("lat"), j.optDouble("lon"), "$ip • ${j.optString("city")}, ${j.optString("country")} • ${j.optString("isp")}")
            } else sb.append("📍 Geo məlumatı alınmadı")
        }
        if (rdns.isNotEmpty()) sb.append("\n🔖 $rdns\n   → ${role(rdns)}")
        return sb.toString()
    }

    fun start() {
        if (tracing.get()) { stop.set(true); proc.get()?.destroy(); return }
        val h = host.text.toString().trim(); if (h.isEmpty()) return
        tracing.set(true); stop.set(false); box.removeAllViews(); geoPts.clear(); updateMap(false)
        btn.text = "⏹ Dayandır"; head.text = "Həll edilir: $h …"
        Thread {
            val dest = try { InetAddress.getByName(h).hostAddress ?: h } catch (e: Exception) {
                u.post { head.text = "❌ Host tapılmadı: $h"; endTrace() }; return@Thread
            }
            u.post { head.text = "🎯 Hədəf: $h ($dest) • maks. 30 hop" }
            val cc = ConcurrentHashMap<Int, String>()
            val workers = ArrayList<Thread>()
            // Başlanğıc nöqtəsi: öz public IP-nin yeri
            val own = Thread {
                val j = geoLookup("")
                if (j != null) {
                    geoPts[0] = GeoPt(j.optDouble("lat"), j.optDouble("lon"), "${j.optString("city")}, ${j.optString("country")} • ${j.optString("isp")}")
                    u.post { updateMap(false) }
                }
            }
            own.start(); workers.add(own)
            var miss = 0; var hops = 0
            for (ttl in 1..30) {
                if (stop.get()) break
                var v: TextView? = null
                u.onUiSync {
                    val t = u.tv("#$ttl  …", 13f, u.TXT, false, true).apply { setBackgroundColor(u.CARD); setPadding(u.dp(10), u.dp(8), u.dp(10), u.dp(8)) }
                    v = t
                    box.addView(t, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = u.dp(6) })
                    sv.post { sv.fullScroll(View.FOCUS_DOWN) }
                }
                val view = v ?: break
                val t0 = System.nanoTime()
                val out = try {
                    val pr = ProcessBuilder("/system/bin/ping", "-c", "1", "-W", "2", "-t", "$ttl", dest).redirectErrorStream(true).start()
                    proc.set(pr)
                    val s = pr.inputStream.bufferedReader().readText(); pr.waitFor(); s
                } catch (e: Exception) { "" }
                val wall = (System.nanoTime() - t0) / 1_000_000
                val ip = Regex("[Ff]rom\\s+(\\d+\\.\\d+\\.\\d+\\.\\d+)").find(out)?.groupValues?.get(1)
                if (ip == null) {
                    miss++
                    u.post { view.text = "#$ttl  * * *   cavab yoxdur (ICMP bloklana bilər)" }
                    if (miss >= 6) break else continue
                }
                miss = 0; hops++
                val exact = Regex("time=([0-9.]+)").find(out)?.groupValues?.get(1)
                val rtt = if (exact != null) "$exact ms" else "~$wall ms"
                u.post { view.text = "#$ttl  $ip   $rtt\n⏳ məlumat toplanır…" }
                val w = Thread {
                    val info = hopInfo(ip, ttl, cc)
                    u.post { view.text = "#$ttl  $ip   $rtt\n$info"; updateMap(false) }
                }
                w.start(); workers.add(w)
                if (ip == dest) break
            }
            workers.forEach { it.join(6000) }
            val path = (1..30).mapNotNull { cc[it] }.fold(ArrayList<String>()) { a, c -> if (a.lastOrNull() != c) a.add(c); a }
            u.post {
                head.text = "✅ Bitdi: $hops hop cavab verdi • xəritədə ${geoPts.size} nöqtə" + (if (path.isNotEmpty()) "\n🌍 Marşrut: ${path.joinToString(" → ")}" else "")
                updateMap(true)
                endTrace()
            }
        }.start()
    }

    btn = u.btn("▶ Traceroute") { start() }
    p.addView(btn); p.addView(head)
    p.addView(map, LinearLayout.LayoutParams(-1, u.dp(250)))
    p.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
    return Page(p, open = { h -> host.setText(h); if (!tracing.get()) start() }, resume = { map.onResume() }, pause = { map.onPause() })
}
