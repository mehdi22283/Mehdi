package com.example.m3utester

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class HistoryActivity : AppCompatActivity() {
    private val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
    private val from = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    private val to = Calendar.getInstance()
    private lateinit var bFrom: Button
    private lateinit var bTo: Button
    private lateinit var summary: TextView
    private lateinit var lv: ListView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        bFrom = Button(this).apply { setOnClickListener { pick(from, 0) } }
        bTo = Button(this).apply { setOnClickListener { pick(to, 59) } }
        summary = TextView(this).apply { textSize = 18f; setPadding(0, 16, 0, 16) }
        lv = ListView(this)
        root.addView(bFrom); root.addView(bTo); root.addView(summary); root.addView(lv)
        setContentView(root)
        refresh()
    }

    private fun pick(c: Calendar, sec: Int) {
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                c.set(y, m, d, h, min, sec); c.set(Calendar.MILLISECOND, 0); refresh()
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun refresh() {
        bFrom.text = "Başlanğıc: ${fmt.format(from.time)}"
        bTo.text = "Son: ${fmt.format(to.time)}"
        val ev = History.load(this).filter { it.t in from.timeInMillis..to.timeInMillis }.sortedByDescending { it.t }
        val broke = ev.filter { !it.ok }.map { it.url }.toSet().size
        val fixed = ev.filter { it.ok }.map { it.url }.toSet().size
        summary.text = "🔴 Xarab olan: $broke kanal\n🟢 Düzələn: $fixed kanal"
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            ev.map { "${if (it.ok) "🟢" else "🔴"} ${it.name}\n${fmt.format(Date(it.t))}" })
    }
}
