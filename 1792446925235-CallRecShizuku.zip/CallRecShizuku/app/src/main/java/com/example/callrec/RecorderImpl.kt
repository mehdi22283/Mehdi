package com.example.callrec

import android.media.MediaRecorder
import java.io.File
import kotlin.system.exitProcess

/** Shizuku vasitəsilə SHELL (uid 2000) kimi işləyir -> VOICE_CALL / REMOTE_SUBMIX icazəsi var. */
class RecorderImpl : IRecorder.Stub() {
    private var mr: MediaRecorder? = null

    override fun start(path: String, sources: IntArray): Boolean {
        stop()
        File(path).parentFile?.mkdirs()
        for (s in sources) {
            try {
                val r = MediaRecorder(FakeContext.create())
                r.setAudioSource(s)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioEncodingBitRate(96000)
                r.setAudioSamplingRate(44100)
                r.setOutputFile(path)
                r.prepare(); r.start()
                mr = r
                return true
            } catch (e: Throwable) {
                File(path).delete()
            }
        }
        return false
    }

    override fun stop() {
        try { mr?.stop() } catch (_: Throwable) {}
        try { mr?.release() } catch (_: Throwable) {}
        mr = null
    }

    override fun destroy() { stop(); exitProcess(0) }
}
