package az.zengyazi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.File

class RecorderService : Service() {
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var idx = 0
    private var prevSpeaker = false
    private var speakerForced = false
    private val h = Handler(Looper.getMainLooper())

    private var list: List<Pair<String, Int>> = Sources.all

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            START -> start(
                intent.getStringExtra("number") ?: "Naməlum",
                intent.getStringExtra("app") ?: "Telefon",
                intent.getBooleanExtra("incoming", true)
            )
            else -> { stopRec(); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun start(number: String, app: String, incoming: Boolean) {
        if (!Repo.hasConsent(this) || rec != null) { stopSelf(); return }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Zəng yazısı", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = NotificationCompat.Builder(this, "rec")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Zəng yazılır")
            .setContentText("$number · $app")
            .setOngoing(true).build()
        try {
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) { stopSelf(); return }

        val info = Info(number, app, incoming, System.currentTimeMillis())
        val f = Repo.newFile(this, info)
        file = f
        val sel = Repo.source(this)
        list = if (sel in Sources.all.indices) listOf(Sources.all[sel]) else Sources.all
        if (Repo.speaker(this)) forceSpeaker(true)
        if (!begin(0, f)) { stopRec(); stopSelf(); return }
        RecState.active.value = info
    }

    /** from indeksindən başlayaraq işləyən ilk mənbəni tapır. */
    private fun begin(from: Int, f: File): Boolean {
        for (i in from until list.size) {
            val r = tryRecorder(list[i].second, f) ?: continue
            rec = r; idx = i
            RecState.source.value = list[i].first
            if (i < list.size - 1) {
                // 2 san-dən sonra səs səviyyəsi 0-dırsa (səssiz yazı), növbəti mənbəyə keç.
                h.postDelayed({ try { rec?.maxAmplitude } catch (_: Exception) {} }, 1500)
                h.postDelayed({ checkSilence(f) }, 3000)
            }
            return true
        }
        return false
    }

    private fun checkSilence(f: File) {
        val r = rec ?: return
        val amp = try { r.maxAmplitude } catch (e: Exception) { -1 }
        if (amp == 0 && idx < list.size - 1) {
            try { r.stop() } catch (_: RuntimeException) {}
            r.release(); rec = null
            f.delete()
            if (!begin(idx + 1, f)) { stopRec(); stopSelf() }
        }
    }

    private fun tryRecorder(src: Int, f: File): MediaRecorder? = try {
        (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()).apply {
            setAudioSource(src)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(96000)
            setAudioSamplingRate(44100)
            setOutputFile(f.path)
            prepare(); start()
        }
    } catch (e: Exception) { f.delete(); null }

    @Suppress("DEPRECATION")
    private fun forceSpeaker(on: Boolean) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (on) {
                prevSpeaker = am.isSpeakerphoneOn
                am.isSpeakerphoneOn = true
                am.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                    am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0)
                speakerForced = true
            } else if (speakerForced) {
                am.isSpeakerphoneOn = prevSpeaker
                speakerForced = false
            }
        } catch (_: Exception) {}
    }

    private fun stopRec() {
        h.removeCallbacksAndMessages(null)
        rec?.let {
            try { it.stop() } catch (e: RuntimeException) { file?.delete() }
            it.release()
        }
        rec = null; file = null
        forceSpeaker(false)
        RecState.active.value = null
        RecState.source.value = ""
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() { stopRec(); super.onDestroy() }

    companion object {
        const val START = "az.zengyazi.START"
        const val STOP = "az.zengyazi.STOP"

        fun start(c: Context, number: String, app: String, incoming: Boolean) {
            val i = Intent(c, RecorderService::class.java).setAction(START)
                .putExtra("number", number).putExtra("app", app).putExtra("incoming", incoming)
            ContextCompat.startForegroundService(c, i)
        }

        fun stop(c: Context) {
            c.startService(Intent(c, RecorderService::class.java).setAction(STOP))
        }
    }
}
