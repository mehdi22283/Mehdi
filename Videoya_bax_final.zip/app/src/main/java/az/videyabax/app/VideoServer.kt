package az.videyabax.app

import java.io.*
import java.net.*
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

class VideoServer(
    private val port:Int,
    private val onVideoReady:(String)->Unit
) {
    private var socket:ServerSocket?=null
    private val pool=Executors.newCachedThreadPool()
    private val current=AtomicReference<StreamFile?>(null)
    private val web= """
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Videoya bax</title><style>
body{font-family:Arial;background:#111;color:#fff;text-align:center;padding:35px}
.box{max-width:600px;margin:auto;background:#222;border-radius:18px;padding:30px}
input{font-size:18px;margin:25px 0}button{font-size:18px;padding:14px 25px;border:0;border-radius:10px}
</style></head><body><div class="box"><h1>▶ Videoya bax</h1>
<p>Telefondakı videonu TV-də aç</p>
<form method="POST" enctype="multipart/form-data"><input type="file" name="video" accept="video/*" required><br>
<button type="submit">TV-də aç</button></form></div></body></html>
""".trimIndent()

    fun start() {
        pool.execute {
            try {
                socket=ServerSocket(port)
                while(!socket!!.isClosed) pool.execute { handle(socket!!.accept()) }
            } catch(_:Exception){}
        }
    }

    private fun handle(s:Socket) {
        try {
            s.soTimeout=0
            val input=BufferedInputStream(s.getInputStream())
            val output=BufferedOutputStream(s.getOutputStream())
            val request=readHeaders(input)
            val first=request.firstLine
            if(first.startsWith("GET /stream")) {
                serveStream(s,input,output)
            } else if(first.startsWith("GET /")) {
                send(output,"HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\n\r\n$web")
                s.close()
            } else if(first.startsWith("POST /")) {
                receiveMultipart(s,input,output,request.headers)
            } else {
                send(output,"HTTP/1.1 405 Method Not Allowed\r\nConnection: close\r\n\r\n")
                s.close()
            }
        } catch(_:Exception) { try{s.close()}catch(_:Exception){} }
    }

    private data class Headers(val firstLine:String,val headers:Map<String,String>)
    private fun readHeaders(input:InputStream):Headers {
        val b=ByteArrayOutputStream()
        var state=0
        while(true) {
            val c=input.read()
            if(c<0) break
            b.write(c)
            state=when {
                state==0 && c==13 -> 1
                state==1 && c==10 -> 2
                state==2 && c==13 -> 3
                state==3 && c==10 -> { break }
                state==1 -> 0
                state==3 -> 0
                else -> state
            }
        }
        val text=b.toString("ISO-8859-1")
        val lines=text.split("\r\n")
        val map=mutableMapOf<String,String>()
        lines.drop(1).forEach {
            val p=it.indexOf(':')
            if(p>0) map[it.substring(0,p).trim().lowercase()]=it.substring(p+1).trim()
        }
        return Headers(lines.firstOrNull()?:"",map)
    }

    private fun receiveMultipart(s:Socket,input:InputStream,output:OutputStream,h:Map<String,String>) {
        val len=h["content-length"]?.toLongOrNull() ?: throw IOException()
        val body=ByteArrayOutputStream()
        var remaining=len
        val buf=ByteArray(8192)
        while(remaining>0) {
            val n=input.read(buf,0,minOf(buf.size,remaining.toInt()))
            if(n<0) break
            body.write(buf,0,n); remaining-=n
        }
        val data=body.toByteArray()
        val ct=h["content-type"] ?: ""
        val boundary=ct.substringAfter("boundary=","").trim().trim('"')
        val marker=("--$boundary").toByteArray(StandardCharsets.ISO_8859_1)
        val headerEnd="\r\n\r\n".toByteArray()
        val start=indexOf(data,headerEnd,0)+4
        val end=indexOf(data,marker,start)-2
        if(start<4 || end<=start) throw IOException("multipart")
        val bytes=data.copyOfRange(start,end)

        // Store only in RAM. No file is created on TV.
        current.set(StreamFile(bytes))
        val streamUrl="/stream"
        send(output,"HTTP/1.1 303 See Other\r\nLocation: /\r\nConnection: close\r\n\r\n")
        s.close()
        onVideoReady("http://${s.localAddress.hostAddress}:$port$streamUrl")
    }

    private fun serveStream(s:Socket,input:InputStream,output:OutputStream) {
        val sf=current.get() ?: run {
            send(output,"HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n")
            s.close(); return
        }
        val contentType=guessType(sf.bytes)
        val rangeHeader=readHeaders(input).headers["range"]
        val total=sf.bytes.size.toLong()
        var start=0L
        var end=total-1
        var status="200 OK"
        if(rangeHeader?.startsWith("bytes=")==true) {
            val r=rangeHeader.substringAfter("bytes=").substringBefore(',')
            val parts=r.split('-')
            start=parts[0].toLongOrNull() ?: 0
            end=parts.getOrNull(1)?.toLongOrNull() ?: end
            if(start> end || start>=total) {
                send(output,"HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */$total\r\n\r\n")
                s.close(); return
            }
            end=minOf(end,total-1); status="206 Partial Content"
        }
        val count=end-start+1
        val head="HTTP/1.1 $status\r\nContent-Type: $contentType\r\nAccept-Ranges: bytes\r\nContent-Length: $count\r\n"+
                (if(status=="206 Partial Content") "Content-Range: bytes $start-$end/$total\r\n" else "")+
                "Connection: close\r\n\r\n"
        send(output,head)
        output.flush()
        output.write(sf.bytes,start.toInt(),count.toInt())
        output.flush()
        s.close()
    }

    private fun guessType(b:ByteArray):String =
        if(b.size>12 && String(b.copyOfRange(4,8),Charsets.ISO_8859_1)=="ftyp") "video/mp4"
        else "video/mp4"

    private fun send(out:OutputStream,text:String) {
        out.write(text.toByteArray(StandardCharsets.UTF_8)); out.flush()
    }

    private fun indexOf(a:ByteArray,needle:ByteArray,from:Int):Int {
        outer@ for(i in from..a.size-needle.size) {
            for(j in needle.indices) if(a[i+j]!=needle[j]) continue@outer
            return i
        }
        return -1
    }

    fun stop() {
        try{socket?.close()}catch(_:Exception){}
        pool.shutdownNow()
        current.set(null)
    }

    private class StreamFile(val bytes:ByteArray)
}
