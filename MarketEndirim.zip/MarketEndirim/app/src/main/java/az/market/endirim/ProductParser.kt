package az.market.endirim

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** OCR sətri və koordinatları. */
data class OLine(val text: String, val l: Int, val t: Int, val r: Int, val b: Int) {
    val w get() = r - l
    val h get() = b - t
}

data class RawProduct(val name: String, val price: Double, val old: Double?)

/**
 * OCR sətirlərindən "məhsul adı + qiymət" cütlərini çıxarır (evristika):
 *  1) qiymət sətirləri (2.49, 2,49 ₼, 2 49 AZN) ayrılır;
 *  2) qalan mətn sətirləri bir-birinə yaxın olduqda (üst-üstə) məhsul adına birləşdirilir;
 *  3) hər qiymət ən yaxın ad qrupuna bağlanır; iki qiymət varsa kiçiyi yeni, böyüyü köhnə qiymətdir.
 */
object ProductParser {

    private const val UNITS = "q|l|lt|ltr|litr|litre|ml|cl|kq|kg|qr|gr|g|mq|mg|ədəd|eded|əd|ed|sm|mm|m|pc|pcs|шт|кг|г|гр|л|мл|уп"
    private val PRICE = Regex("""(?iu)(?<![\d.,])(\d{1,3})\s?[.,]\s?(\d{2})(?![\d]|[.,]\d)(?!\s?(?:$UNITS)(?![\p{L}\d]))""")
    private val PRICE_INT = Regex("""(?i)(?<![\d.,])(\d{1,3})\s?(?:₼|azn|man\b)""")
    private val PRICE_SPLIT = Regex("""(?i)^\s*(\d{1,2})\s(\d{2})\s*(?:₼|azn|man\.?|qəp\.?|qep\.?)?\s*$""")

    private val STOP = listOf(
        "endirim", "aksiya", "kampaniya", "qiymet", "tarix", "unvan", "www", "http", "instagram", "facebook", "whatsapp",
        "kataloq", "jurnal", "supermarket", "magaza", "bonus", "kassa", "hediyye", "mehsullar", "tel", "mob", "filial",
        "bitir", "baslayir", "yeni", "super", "teklif", "sertlerle", "qaydalar", "oktyabr", "noyabr", "dekabr", "yanvar",
        "fevral", "mart", "aprel", "may", "iyun", "iyul", "avqust", "sentyabr"
    )

    fun findPrices(text: String): List<Double> {
        val out = ArrayList<Double>()
        PRICE_SPLIT.matchEntire(text)?.let { m ->
            out.add("${m.groupValues[1]}.${m.groupValues[2]}".toDouble())
            return out
        }
        for (m in PRICE.findAll(text)) out.add("${m.groupValues[1]}.${m.groupValues[2]}".toDouble())
        if (out.isEmpty()) for (m in PRICE_INT.findAll(text)) out.add(m.groupValues[1].toDouble())
        return out.filter { it in 0.05..999.0 }
    }

    private val LONE_INT = Regex("^\\s*(\\d{1,2})\\s*$")

    /** Sətirdə yalnız bir-iki rəqəm varsa ("5") — Bravo-da tam qiymətdir (səhifə kənarındakı nömrələr istisna). */
    private fun loneInt(ln: OLine, pageH: Int): List<Double> {
        val m = LONE_INT.matchEntire(ln.text) ?: return emptyList()
        if (ln.t < 0.04f * pageH || ln.b > 0.96f * pageH) return emptyList()
        val v = m.groupValues[1].toDouble()
        return if (v >= 1) listOf(v) else emptyList()
    }

    private fun stripPrices(text: String): String =
        text.replace(PRICE, " ").replace(PRICE_INT, " ").replace("₼", " ")
            .replace(Regex("(?i)\\bazn\\b|\\bman\\.?\\b|\\bqəp\\.?"), " ")

    private fun cleanName(raw: String): String =
        raw.replace(Regex("[|_•*«»\"“”]+"), " ").replace(Regex("\\s+"), " ").trim(' ', '-', '.', ',', ':', ';', '/')

    private fun isValidName(n: String): Boolean {
        val letters = n.count { it.isLetter() }
        if (letters < 3 || n.length > 90) return false
        if (letters.toFloat() / n.count { !it.isWhitespace() }.coerceAtLeast(1) < 0.6f) return false
        val tokens = Categorizer.norm(n).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return false
        // bütün sözlər texniki/reklam sözüdürsə — məhsul deyil
        return tokens.any { tk -> tk.length >= 3 && STOP.none { sw -> tk == sw || (sw.length >= 5 && tk.startsWith(sw)) } }
    }

    private class Group(val lines: MutableList<OLine>) {
        var l = Int.MAX_VALUE; var t = Int.MAX_VALUE; var r = 0; var b = 0
        fun fit() { lines.forEach { l = min(l, it.l); t = min(t, it.t); r = max(r, it.r); b = max(b, it.b) } }
    }

    private fun related(a: OLine, b: OLine): Boolean {
        val minH = min(a.h, b.h).coerceAtLeast(1)
        val maxH = max(a.h, b.h)
        val vgap = max(a.t, b.t) - min(a.b, b.b)
        val ox = min(a.r, b.r) - max(a.l, b.l)
        val minW = min(a.w, b.w).coerceAtLeast(1)
        return vgap >= -0.25f * minH && vgap <= 0.9f * minH && ox >= 0.35f * minW && maxH <= 1.7f * minH
    }

    fun parse(lines: List<OLine>, pageW: Int, pageH: Int): List<RawProduct> {
        val priceLines = ArrayList<Pair<OLine, List<Double>>>()
        val nameLines = ArrayList<OLine>()
        val result = ArrayList<RawProduct>()

        for (ln in lines) {
            val prices = findPrices(ln.text).ifEmpty { loneInt(ln, pageH) }
            if (prices.isEmpty()) {
                if (ln.text.count { it.isLetter() } >= 3) nameLines.add(ln)
                continue
            }
            val rest = cleanName(stripPrices(ln.text))
            if (rest.count { it.isLetter() } <= 5) {
                priceLines.add(ln to prices)
            } else if (isValidName(rest)) {
                result.add(makeRaw(rest, prices))     // ad və qiymət eyni sətirdə
            }
        }

        // ad sətirlərini qruplaşdır (union-find)
        val parent = IntArray(nameLines.size) { it }
        fun find(x: Int): Int { var a = x; while (parent[a] != a) { parent[a] = parent[parent[a]]; a = parent[a] }; return a }
        for (i in nameLines.indices) for (j in i + 1 until nameLines.size) {
            if (related(nameLines[i], nameLines[j])) parent[find(i)] = find(j)
        }
        val byRoot = LinkedHashMap<Int, Group>()
        for (i in nameLines.indices) byRoot.getOrPut(find(i)) { Group(ArrayList()) }.lines.add(nameLines[i])
        val groups = byRoot.values.toList()
        groups.forEach { g -> g.lines.sortBy { it.t }; g.fit() }

        // yaxın qiymət sətirləri (yeni + köhnə) bir "qiymət qrupu" olur: eyni pəncərənin qiymətləri
        val pp = IntArray(priceLines.size) { it }
        fun pf(x: Int): Int { var a = x; while (pp[a] != a) { pp[a] = pp[pp[a]]; a = pp[a] }; return a }
        for (i in priceLines.indices) for (j in i + 1 until priceLines.size) {
            val a = priceLines[i].first; val b = priceLines[j].first
            val maxH = max(a.h, b.h).coerceAtLeast(1)
            val maxW = max(a.w, b.w).coerceAtLeast(1)
            val dcx = kotlin.math.abs((a.l + a.r) / 2 - (b.l + b.r) / 2)
            val dcy = kotlin.math.abs((a.t + a.b) / 2 - (b.t + b.b) / 2)
            if (dcx <= 1.7f * maxW && dcy <= 2.4f * maxH) pp[pf(i)] = pf(j)
        }
        class PG { var l = Int.MAX_VALUE; var t = Int.MAX_VALUE; var r = 0; var b = 0; val prices = ArrayList<Double>() }
        val pgs = LinkedHashMap<Int, PG>()
        for (i in priceLines.indices) {
            val (ln, prices) = priceLines[i]
            val g = pgs.getOrPut(pf(i)) { PG() }
            g.l = min(g.l, ln.l); g.t = min(g.t, ln.t); g.r = max(g.r, ln.r); g.b = max(g.b, ln.b)
            g.prices.addAll(prices)
        }

        // hər qiymət qrupunu ən yaxın ad qrupuna bağla (bir adın bir neçə qiyməti ola bilər)
        for (pg in pgs.values) {
            var best: Group? = null
            var bestD = Double.MAX_VALUE
            for (g in groups) {
                val dx = max(0, max(g.l - pg.r, pg.l - g.r))
                val dy = max(0, max(g.t - pg.b, pg.t - g.b))
                if (dx > 0.18f * pageW || dy > 0.12f * pageH) continue
                var d = hypot(dx.toDouble(), dy * 1.3)
                if (pg.b < g.t) d *= 1.6          // qiymət adın üstündədirsə — az ehtimal
                if (d < bestD) { bestD = d; best = g }
            }
            val g = best ?: continue
            val name = cleanName(g.lines.take(3).joinToString(" ") { it.text })
            if (!isValidName(name)) continue
            result.add(makeRaw(name, pg.prices))
        }
        return result
    }

    private fun makeRaw(name: String, prices: List<Double>): RawProduct {
        val lo = prices.minOrNull() ?: 0.0
        val hi = prices.maxOrNull() ?: lo
        val old = if (prices.size >= 2 && hi > lo * 1.02 && hi <= lo * 6) hi else null
        return RawProduct(name, lo, old)
    }
}
