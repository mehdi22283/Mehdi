package az.market.endirim

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** PDF-in ilk 2 səhifəsindən OCR ilə tarix oxuyur (nəticə yadda saxlanır). */
object Ocr {
    suspend fun pdfDate(ctx: Context, file: File): String? {
        val prefs = ctx.getSharedPreferences("ocr", Context.MODE_PRIVATE)
        if (prefs.contains(file.name)) return prefs.getString(file.name, "")?.ifEmpty { null }
        return try {
            val sb = StringBuilder()
            for (i in 0..1) {
                val bmp = withContext(Dispatchers.IO) { renderPage(file, i) } ?: break
                sb.append(recognize(bmp)).append('\n')
            }
            val d = DateUtil.find(sb.toString())
            prefs.edit().putString(file.name, d ?: "").apply()
            d
        } catch (e: Exception) {
            null
        }
    }

    private fun renderPage(file: File, index: Int): Bitmap? = try {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            val r = PdfRenderer(pfd)
            try {
                if (index >= r.pageCount) null else {
                    val p = r.openPage(index)
                    try {
                        val w = 1600
                        val h = (w.toFloat() * p.height / p.width).toInt()
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bmp
                    } finally {
                        p.close()
                    }
                }
            } finally {
                r.close()
            }
        }
    } catch (e: Exception) {
        null
    }

    suspend fun recognize(bmp: Bitmap): String = suspendCancellableCoroutine { c ->
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { c.resume(it.text) }
            .addOnFailureListener { c.resumeWithException(it) }
    }
}
