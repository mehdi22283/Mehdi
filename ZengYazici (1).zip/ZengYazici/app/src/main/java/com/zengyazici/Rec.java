package com.zengyazici;

import android.media.AudioFormat;
import android.media.AudioRecord;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * ADB shell (uid 2000) icazələri ilə app_process vasitəsilə işə salınır:
 * CLASSPATH=<apk> app_process /system/bin com.zengyazici.Rec <port> <planlar>
 * planlar: "4;3+1;3+2;7;1" — ";" ilə ayrılmış planlar, "+" ilə eyni anda yazılan mənbələr (qarışdırılır).
 * Qarşı tərəfi tuta bilən mənbələr: 3 (DOWNLINK), 4 (VOICE_CALL), 8 (REMOTE_SUBMIX).
 * 1-ci mərhələ: yalnız qarşı tərəf mənbəyi olan planlar; 2 saniyə ərzində həmin mənbədə səs gəlməlidir.
 * 2-ci mərhələ: mikrofon planları (qarşı tərəf yalnız dinamikdən mikrofona düşə bilər).
 * Nəticə stderr-ə yazılır: FAR=ok / FAR=none.
 */
public class Rec {
    static final int RATE = 16000, CH = AudioFormat.CHANNEL_IN_MONO, ENC = AudioFormat.ENCODING_PCM_16BIT;
    static final int CHUNK = 1600;

    static class Plan {
        String name;
        int[] src;
        float[] gain;
        List<AudioRecord> recs = new ArrayList<>();
    }

    static void err(String s) { System.err.println(s); }

    static boolean isFar(int s) { return s == 3 || s == 4 || s == 8; }

    /** "5*6+1": mənbə 5 (6 dəfə gücləndirilir) + mənbə 1. */
    static int[] parse(String plan) {
        String[] xs = plan.split("\\+");
        int[] r = new int[xs.length];
        for (int i = 0; i < xs.length; i++) r[i] = Integer.parseInt(xs[i].split("\\*")[0].trim());
        return r;
    }

    static float[] parseGain(String plan) {
        String[] xs = plan.split("\\+");
        float[] g = new float[xs.length];
        for (int i = 0; i < xs.length; i++) {
            String[] q = xs[i].split("\\*");
            g[i] = q.length > 1 ? Float.parseFloat(q[1].trim()) : 1f;
        }
        return g;
    }

    static boolean hasFar(String plan) {
        try { for (int s : parse(plan)) if (isFar(s)) return true; } catch (Throwable e) { }
        return false;
    }

    static AudioRecord open(int src) {
        try {
            int min = AudioRecord.getMinBufferSize(RATE, CH, ENC);
            int size = Math.max(min, RATE) * 4;
            AudioRecord r = new AudioRecord(src, RATE, CH, ENC, size);
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                err("Menbe " + src + ": INITIALIZED deyil"); r.release(); return null;
            }
            r.startRecording();
            if (r.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                err("Menbe " + src + ": baslamadi"); r.release(); return null;
            }
            return r;
        } catch (Throwable e) {
            err("Menbe " + src + ": " + e);
            return null;
        }
    }

    static Plan openPlan(String plan) {
        Plan p = new Plan();
        p.name = plan;
        try { p.src = parse(plan); p.gain = parseGain(plan); } catch (Throwable e) { return null; }
        for (int s : p.src) {
            AudioRecord r = open(s);
            if (r == null) { release(p); return null; }
            p.recs.add(r);
        }
        return p;
    }

    static void release(Plan p) {
        for (AudioRecord r : p.recs) { try { r.stop(); } catch (Throwable e) { } try { r.release(); } catch (Throwable e) { } }
    }

    static boolean readFully(AudioRecord r, short[] b) {
        int off = 0;
        while (off < b.length) {
            int k = r.read(b, off, b.length - off);
            if (k < 0) return false;
            off += k;
        }
        return true;
    }

    /** Bir hissə oxuyub qarışdırır; peaks[j]-ə j-ci mənbənin maksimum amplitudunu yazır. */
    static boolean chunk(Plan p, short[] out, int[] peaks) {
        short[] tmp = new short[out.length];
        int[] sum = new int[out.length];
        for (int j = 0; j < p.recs.size(); j++) {
            if (!readFully(p.recs.get(j), tmp)) return false;
            for (int i = 0; i < tmp.length; i++) {
                sum[i] += Math.round(tmp[i] * p.gain[j]);
                int ab = Math.abs((int) tmp[i]);
                if (ab > peaks[j]) peaks[j] = ab;
            }
        }
        for (int i = 0; i < out.length; i++) out[i] = (short) Math.max(-32768, Math.min(32767, sum[i]));
        return true;
    }

    static int farPeak(Plan p, int[] peaks) {
        int m = 0;
        for (int j = 0; j < p.src.length; j++) if (isFar(p.src[j]) && peaks[j] > m) m = peaks[j];
        return m;
    }

    static int maxPeak(int[] peaks) {
        int m = 0;
        for (int v : peaks) if (v > m) m = v;
        return m;
    }

    static void write(OutputStream o, short[] s) throws Exception {
        byte[] b = new byte[s.length * 2];
        for (int i = 0; i < s.length; i++) { b[2 * i] = (byte) (s[i] & 0xff); b[2 * i + 1] = (byte) ((s[i] >> 8) & 0xff); }
        o.write(b);
    }

    /** Planı sınaqdan keçirir: probe baytlarını qaytarır, peaks-i doldurur; uğursuzsa null. */
    static ByteArrayOutputStream probe(Plan p, int chunks, int[] peaks) throws Exception {
        ByteArrayOutputStream pr = new ByteArrayOutputStream();
        short[] buf = new short[CHUNK];
        for (int k = 0; k < chunks; k++) {
            if (!chunk(p, buf, peaks)) return null;
            write(pr, buf);
        }
        return pr;
    }

    public static void main(String[] a) {
        try {
            int port = Integer.parseInt(a[0]);
            String[] plans = a[1].split(";");
            Plan chosen = null;
            int chosenIdx = -1;
            ByteArrayOutputStream pre = new ByteArrayOutputStream();
            String far = "none";

            // 1-ci mərhələ: qarşı tərəfi tutan planlar
            for (int pi = 0; pi < plans.length && chosen == null; pi++) {
                if (!hasFar(plans[pi])) continue;
                Plan p = openPlan(plans[pi]);
                if (p == null) { err("Plan " + plans[pi] + ": acilmadi"); continue; }
                int[] peaks = new int[p.recs.size()];
                ByteArrayOutputStream pr = probe(p, 20, peaks);
                err("Plan " + plans[pi] + ": qarsi-teref peak=" + (pr == null ? -1 : farPeak(p, peaks)) + ", hamisi=" + maxPeak(peaks));
                if (pr != null && farPeak(p, peaks) > 2) {
                    chosen = p; chosenIdx = pi; pre = pr; far = "ok";
                } else {
                    release(p);
                }
            }

            // 2-ci mərhələ: mikrofon planları
            if (chosen == null) {
                Plan firstOpen = null;
                int firstIdx = -1;
                for (int pi = 0; pi < plans.length && chosen == null; pi++) {
                    if (hasFar(plans[pi])) continue;
                    Plan p = openPlan(plans[pi]);
                    if (p == null) { err("Plan " + plans[pi] + ": acilmadi"); continue; }
                    int[] peaks = new int[p.recs.size()];
                    ByteArrayOutputStream pr = probe(p, 10, peaks);
                    err("Plan " + plans[pi] + ": peak=" + maxPeak(peaks));
                    if (pr != null && maxPeak(peaks) > 2) {
                        chosen = p; chosenIdx = pi; pre = pr;
                    } else if (firstOpen == null) {
                        firstOpen = p; firstIdx = pi;   // açıq saxlayırıq, ehtiyat olaraq
                    } else {
                        release(p);
                    }
                }
                if (chosen == null && firstOpen != null) {
                    err("Butun menbeler sessizdir; " + firstOpen.name + " ile davam edilir");
                    chosen = firstOpen; chosenIdx = firstIdx;
                } else if (firstOpen != null) {
                    release(firstOpen);
                }
            }

            if (chosen == null) {
                err("Hec bir audio menbeyi acilmadi");
                System.exit(2);
            }
            err("FAR=" + far);
            err("Secilen plan: " + chosen.name);

            Socket sock = new Socket("127.0.0.1", port);
            OutputStream o = sock.getOutputStream();
            o.write(chosenIdx);
            o.write(pre.toByteArray());
            short[] buf = new short[CHUNK];
            int[] peaks = new int[chosen.recs.size()];
            while (true) {
                if (!chunk(chosen, buf, peaks)) break;
                write(o, buf);
            }
        } catch (Throwable e) {
            err("Rec: " + e);
            System.exit(1);
        }
        System.exit(0);
    }
}
