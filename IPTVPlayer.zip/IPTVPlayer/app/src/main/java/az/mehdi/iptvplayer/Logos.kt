package az.mehdi.iptvplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Collections

/**
 * Kanal adına görə loqonu internetdən (iptv-org bazası) tapıb tətbiqin daxili yaddaşına (filesDir/logos) yazır.
 * Bir dəfə endirilən loqo bir daha endirilmir.
 */
class LogoStore(private val ctx: Context, scope: CoroutineScope) {
    private val dir = File(ctx.filesDir, "logos").apply { mkdirs() }
    private val index = HashMap<String, String>()
    private val failed = Collections.synchronizedSet(HashSet<String>())
    private val sem = Semaphore(4)
    private val mem = LruCache<String, Bitmap>(200)
    private val indexJob: Job = scope.launch(Dispatchers.IO) { runCatching { buildIndex() } }

    private fun norm(s: String): String {
        var t = s.lowercase().replace('ə', 'e').replace('ı', 'i')
        t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        t = t.replace(Regex("[\\[(].*?[\\])]"), " ")
        t = t.replace(Regex("\\b(hd|fhd|uhd|sd|4k|8k|hevc|h265|backup)\\b"), " ")
        return t.replace(Regex("[^a-z0-9]"), "")
    }

    private fun buildIndex() {
        val tsv = File(ctx.filesDir, "logo_index.tsv")
        val fresh = tsv.exists() && System.currentTimeMillis() - tsv.lastModified() < 14L * 24 * 3600 * 1000
        if (!fresh) runCatching {
            val ch = File(ctx.filesDir, "channels.json")
            val lg = File(ctx.filesDir, "logos.json")
            fetchToFile("https://iptv-org.github.io/api/channels.json", ch, 30000)
            fetchToFile("https://iptv-org.github.io/api/logos.json", lg, 30000)
            val urls = HashMap<String, String>()
            val la = JSONArray(lg.readText())
            for (i in 0 until la.length()) {
                val o = la.getJSONObject(i)
                val id = o.optString("channel")
                val u = o.optString("url")
                if (id.isNotEmpty() && u.startsWith("http") && !urls.containsKey(id)) urls[id] = u
            }
            val sb = StringBuilder()
            val ca = JSONArray(ch.readText())
            for (i in 0 until ca.length()) {
                val o = ca.getJSONObject(i)
                val u = urls[o.optString("id")] ?: continue
                sb.append(norm(o.optString("name"))).append('\t').append(u).append('\n')
                val alt = o.optJSONArray("alt_names")
                if (alt != null) for (j in 0 until alt.length()) sb.append(norm(alt.getString(j))).append('\t').append(u).append('\n')
            }
            tsv.writeText(sb.toString())
            ch.delete(); lg.delete()
        }
        if (tsv.exists()) synchronized(index) {
            tsv.forEachLine { l ->
                val p = l.split('\t')
                if (p.size == 2 && p[0].isNotEmpty()) index.putIfAbsent(p[0], p[1])
            }
        }
    }

    private fun lookup(name: String): String? {
        val n = norm(name)
        if (n.isEmpty()) return null
        return synchronized(index) { index[n] ?: index[n.removeSuffix("tv")] ?: index[n + "tv"] }
    }

    private fun md5(s: String) = MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun decode(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0) return null
        var s = 1
        while (o.outWidth / s > 256) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private suspend fun loadUrl(u: String): Bitmap? {
        val f = File(dir, md5(u) + ".img")
        if (!f.exists() || f.length() == 0L) {
            try {
                sem.withPermit { withContext(Dispatchers.IO) { fetchToFile(u, f, 10000) } }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return null
            }
        }
        return withContext(Dispatchers.IO) { decode(f) ?: run { f.delete(); null } }
    }

    suspend fun bitmapFor(ch: Channel): Bitmap? {
        val key = norm(ch.name)
        mem.get(key)?.let { return it }
        if (failed.contains(key)) return null
        indexJob.join()
        for (u in listOfNotNull(ch.logo, lookup(ch.name)).distinct()) {
            val bmp = loadUrl(u)
            if (bmp != null) { mem.put(key, bmp); return bmp }
        }
        failed.add(key)
        return null
    }
}
